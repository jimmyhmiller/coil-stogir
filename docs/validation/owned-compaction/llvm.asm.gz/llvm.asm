
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/owned-compaction/build/owned-compaction-verifier/llvm.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	cbz	x2, 0x20 <ltmp0+0x20>
       4:      	stp	x29, x30, [sp, #-0x10]!
       8:      	mov	x29, sp
       c:      	bl	0xc <ltmp0+0xc>
		000000000000000c:  ARM64_RELOC_BRANCH26	_memcmp
      10:      	cmp	w0, #0x0
      14:      	cset	w0, eq
      18:      	ldp	x29, x30, [sp], #0x10
      1c:      	ret
      20:      	mov	w0, #0x1                ; =1
      24:      	ret

0000000000000028 <_coil.hashmap.bytewise-hash>:
      28:      	mov	x8, x0
      2c:      	mov	x0, #0x2325             ; =8997
      30:      	cmp	x1, #0x1
      34:      	movk	x0, #0x8422, lsl #16
      38:      	movk	x0, #0x9ce4, lsl #32
      3c:      	movk	x0, #0xcbf2, lsl #48
      40:      	b.lt	0x60 <_coil.hashmap.bytewise-hash+0x38>
      44:      	mov	x9, #0x1b3              ; =435
      48:      	movk	x9, #0x100, lsl #32
      4c:      	ldrsb	x10, [x8], #0x1
      50:      	subs	x1, x1, #0x1
      54:      	eor	x10, x0, x10
      58:      	mul	x0, x10, x9
      5c:      	b.ne	0x4c <_coil.hashmap.bytewise-hash+0x24>
      60:      	ret

0000000000000064 <_gap_verify_graph>:
      64:      	ldr	x8, [x0, #0x8]
      68:      	ldr	x9, [x0, #0x80]
      6c:      	cmp	x8, x9
      70:      	b.ne	0x478 <_gap_verify_graph+0x414>
      74:      	stp	x28, x27, [sp, #-0x60]!
      78:      	stp	x26, x25, [sp, #0x10]
      7c:      	stp	x24, x23, [sp, #0x20]
      80:      	stp	x22, x21, [sp, #0x30]
      84:      	stp	x20, x19, [sp, #0x40]
      88:      	stp	x29, x30, [sp, #0x50]
      8c:      	add	x29, sp, #0x50
      90:      	sub	sp, sp, #0x1d0
      94:      	mov	x19, x0
      98:      	mov	w9, #0x1                ; =1
      9c:      	adrp	x10, 0x0 <ltmp0>
		000000000000009c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.INPUT-COUNTS
      a0:      	add	x10, x10, #0x0
		00000000000000a0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.INPUT-COUNTS
      a4:      	mov	w11, #0x24              ; =36
      a8:      	mov	w12, #0x15              ; =21
      ac:      	mov	w15, #0x5e1c            ; =24092
      b0:      	mov	w17, #0x18              ; =24
      b4:      	adrp	x16, 0x0 <ltmp0>
		00000000000000b4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
      b8:      	add	x16, x16, #0x0
		00000000000000b8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
      bc:      	mov	w1, #0x5                ; =5
      c0:      	mov	w2, #0x818              ; =2072
      c4:      	mov	w3, #0x1                ; =1
      c8:      	b	0xd4 <_gap_verify_graph+0x70>
      cc:      	mov	x3, x20
      d0:      	cbnz	x28, 0x3b68 <_gap_verify_graph+0x3b04>
      d4:      	cmp	x3, x8
      d8:      	b.ge	0x480 <_gap_verify_graph+0x41c>
      dc:      	ldr	x4, [x19, #0x78]
      e0:      	mov	x0, #-0x1               ; =-1
      e4:      	ldr	w5, [x4, x3, lsl #2]
      e8:      	lsr	w13, w5, #16
      ec:      	cbnz	w13, 0x3b6c <_gap_verify_graph+0x3b08>
      f0:      	ldr	x6, [x19]
      f4:      	lsl	x13, x3, #4
      f8:      	ldr	x20, [x6, x13]
      fc:      	and	w21, w20, #0xff
     100:      	cmp	w21, #0x82
     104:      	b.hi	0x3b6c <_gap_verify_graph+0x3b08>
     108:      	ubfx	w22, w20, #8, #8
     10c:      	cmp	w22, #0xe
     110:      	b.lo	0x130 <_gap_verify_graph+0xcc>
     114:      	sub	w13, w22, #0x80
     118:      	cmn	w13, #0x70
     11c:      	b.lo	0x3b6c <_gap_verify_graph+0x3b08>
     120:      	ubfx	w13, w20, #8, #4
     124:      	sub	w13, w13, #0xe
     128:      	cmn	w13, #0xd
     12c:      	b.lo	0x3b6c <_gap_verify_graph+0x3b08>
     130:      	and	x7, x20, #0xff
     134:      	adrp	x13, 0x0 <ltmp0>
		0000000000000134:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.OPERAND-SLOTS
     138:      	add	x13, x13, #0x0
		0000000000000138:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.OPERAND-SLOTS
     13c:      	ldrsb	w13, [x13, x7]
     140:      	tbnz	w13, #0x1f, 0x14c <_gap_verify_graph+0xe8>
     144:      	cmp	w5, w13
     148:      	b.ne	0x3b6c <_gap_verify_graph+0x3b08>
     14c:      	ldrb	w13, [x10, x7]
     150:      	add	x0, x5, #0x4
     154:      	lsr	w20, w20, #16
     158:      	lsr	x0, x0, #2
     15c:      	cmp	w13, #0xff
     160:      	ccmp	w5, w20, #0x4, eq
     164:      	add	x20, x3, x0
     168:      	csel	x13, x11, xzr, ne
     16c:      	cmp	x20, x8
     170:      	csel	x28, x12, x13, gt
     174:      	cmp	w5, #0x4
     178:      	b.lo	0x1b0 <_gap_verify_graph+0x14c>
     17c:      	cbnz	x28, 0x1b0 <_gap_verify_graph+0x14c>
     180:      	add	x13, x4, x3, lsl #2
     184:      	mov	w24, #0x2               ; =2
     188:      	add	x23, x13, #0x4
     18c:      	ldr	w25, [x23], #0x4
     190:      	cmn	w25, #0x1
     194:      	b.ne	0x1a4 <_gap_verify_graph+0x140>
     198:      	cmp	x24, x0
     19c:      	add	x24, x24, #0x1
     1a0:      	b.lo	0x18c <_gap_verify_graph+0x128>
     1a4:      	cmn	w25, #0x1
     1a8:      	mov	w13, #0x1b              ; =27
     1ac:      	csel	x28, xzr, x13, eq
     1b0:      	cbz	w5, 0xcc <_gap_verify_graph+0x68>
     1b4:      	cbnz	x28, 0xcc <_gap_verify_graph+0x68>
     1b8:      	cmp	w21, #0x78
     1bc:      	mov	w24, #0x2               ; =2
     1c0:      	ccmp	w22, #0x0, #0x0, eq
     1c4:      	and	x22, x3, #0x7fffffff
     1c8:      	cset	w21, ne
     1cc:      	cmp	w3, #0x1
     1d0:      	ccmp	x8, x22, #0x4, ge
     1d4:      	cset	w23, le
     1d8:      	sub	w25, w24, #0x1
     1dc:      	cmp	w25, #0x1
     1e0:      	b.lt	0x208 <_gap_verify_graph+0x1a4>
     1e4:      	cmp	w25, #0x5
     1e8:      	ldr	w0, [x16, x7, lsl #2]
     1ec:      	csel	w13, w25, w1, lo
     1f0:      	lsl	w13, w13, #2
     1f4:      	sub	w13, w13, #0x4
     1f8:      	lsr	w13, w0, w13
     1fc:      	and	w0, w13, #0xf
     200:      	tbz	w23, #0x0, 0x210 <_gap_verify_graph+0x1ac>
     204:      	b	0x224 <_gap_verify_graph+0x1c0>
     208:      	mov	w0, wzr
     20c:      	tbnz	w23, #0x0, 0x224 <_gap_verify_graph+0x1c0>
     210:      	ldr	w13, [x4, x22, lsl #2]
     214:      	cmp	w25, w13
     218:      	ccmp	w13, #0x0, #0x8, ls
     21c:      	ccmp	w25, #0x1, #0x8, pl
     220:      	b.ge	0x230 <_gap_verify_graph+0x1cc>
     224:      	mov	x26, xzr
     228:      	cbnz	w26, 0x248 <_gap_verify_graph+0x1e4>
     22c:      	b	0x3b68 <_gap_verify_graph+0x3b04>
     230:      	add	w13, w3, w25, lsr #2
     234:      	and	w26, w25, #0x3
     238:      	add	x13, x6, w13, uxtw #4
     23c:      	ldr	w27, [x13, w26, uxtw #2]
     240:      	mov	w26, #0x1               ; =1
     244:      	cbz	w26, 0x3b68 <_gap_verify_graph+0x3b04>
     248:      	cmp	w0, #0x2
     24c:      	b.eq	0x258 <_gap_verify_graph+0x1f4>
     250:      	cmp	w0, #0x9
     254:      	b.ne	0x2a0 <_gap_verify_graph+0x23c>
     258:      	cmp	w27, #0x1
     25c:      	b.lt	0x2d4 <_gap_verify_graph+0x270>
     260:      	and	x26, x27, #0x7fffffff
     264:      	cmp	x8, x26
     268:      	b.le	0x39c <_gap_verify_graph+0x338>
     26c:      	ldr	w13, [x4, x26, lsl #2]
     270:      	tbnz	w13, #0x1f, 0x39c <_gap_verify_graph+0x338>
     274:      	add	x26, x6, x26, lsl #4
     278:      	cbz	x26, 0x39c <_gap_verify_graph+0x338>
     27c:      	ldrb	w13, [x26]
     280:      	mov	w26, #0x1               ; =1
     284:      	mov	w30, #0x1               ; =1
     288:      	cmp	w13, #0x48
     28c:      	mov	w13, #0x25              ; =37
     290:      	csel	x28, x13, xzr, eq
     294:      	cmp	w0, #0x8
     298:      	b.eq	0x3b0 <_gap_verify_graph+0x34c>
     29c:      	b	0x2b4 <_gap_verify_graph+0x250>
     2a0:      	mov	w26, wzr
     2a4:      	mov	w30, wzr
     2a8:      	mov	x28, xzr
     2ac:      	cmp	w0, #0x8
     2b0:      	b.eq	0x3b0 <_gap_verify_graph+0x34c>
     2b4:      	cmp	w0, #0xf
     2b8:      	b.eq	0x464 <_gap_verify_graph+0x400>
     2bc:      	lsl	w13, w9, w0
     2c0:      	and	w13, w13, w15
     2c4:      	cbz	w13, 0x464 <_gap_verify_graph+0x400>
     2c8:      	tbz	w26, #0x0, 0x338 <_gap_verify_graph+0x2d4>
     2cc:      	tbnz	w30, #0x0, 0x464 <_gap_verify_graph+0x400>
     2d0:      	b	0x2ec <_gap_verify_graph+0x288>
     2d4:      	tbnz	w27, #0x1f, 0x358 <_gap_verify_graph+0x2f4>
     2d8:      	cmp	w0, #0x8
     2dc:      	b.eq	0x3b68 <_gap_verify_graph+0x3b04>
     2e0:      	lsr	w13, w15, w0
     2e4:      	mov	x28, xzr
     2e8:      	tbz	w13, #0x0, 0x464 <_gap_verify_graph+0x400>
     2ec:      	cmp	w25, #0x1
     2f0:      	mov	x0, #-0x1               ; =-1
     2f4:      	b.lt	0x3b6c <_gap_verify_graph+0x3b08>
     2f8:      	cbnz	w27, 0x3b6c <_gap_verify_graph+0x3b08>
     2fc:      	cmp	w25, #0x5
     300:      	ldr	w14, [x16, x7, lsl #2]
     304:      	csel	w13, w25, w1, lo
     308:      	lsl	w13, w13, #2
     30c:      	sub	w13, w13, #0x4
     310:      	lsr	w13, w14, w13
     314:      	and	w13, w13, #0xf
     318:      	cmp	w13, #0xb
     31c:      	b.hi	0x328 <_gap_verify_graph+0x2c4>
     320:      	lsr	w13, w2, w13
     324:      	tbnz	w13, #0x0, 0x464 <_gap_verify_graph+0x400>
     328:      	cmp	w24, #0x3
     32c:      	csinc	w13, w21, wzr, eq
     330:      	tbz	w13, #0x0, 0x464 <_gap_verify_graph+0x400>
     334:      	b	0x3b68 <_gap_verify_graph+0x3b04>
     338:      	cmp	w27, #0x1
     33c:      	b.lt	0x424 <_gap_verify_graph+0x3c0>
     340:      	and	x13, x27, #0x7fffffff
     344:      	cmp	x8, x13
     348:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
     34c:      	ldr	w13, [x4, x13, lsl #2]
     350:      	tbz	w13, #0x1f, 0x464 <_gap_verify_graph+0x400>
     354:      	b	0x3b68 <_gap_verify_graph+0x3b04>
     358:      	ldr	x26, [x19, #0x30]
     35c:      	ldr	x13, [x19, #0x58]
     360:      	cmp	x26, x13
     364:      	b.ne	0x39c <_gap_verify_graph+0x338>
     368:      	sxtw	x28, w27
     36c:      	cmn	x26, x28
     370:      	b.lt	0x39c <_gap_verify_graph+0x338>
     374:      	ldr	x13, [x19, #0x50]
     378:      	mvn	x26, x28
     37c:      	ldr	w13, [x13, x26, lsl #2]
     380:      	cmp	w13, #0x0
     384:      	b.le	0x39c <_gap_verify_graph+0x338>
     388:      	ldr	x13, [x19, #0x28]
     38c:      	mvn	w26, w27
     390:      	and	x26, x26, #0x7fffffff
     394:      	add	x26, x13, x26, lsl #4
     398:      	cbnz	x26, 0x27c <_gap_verify_graph+0x218>
     39c:      	mov	w30, wzr
     3a0:      	mov	x28, xzr
     3a4:      	mov	w26, #0x1               ; =1
     3a8:      	cmp	w0, #0x8
     3ac:      	b.ne	0x2b4 <_gap_verify_graph+0x250>
     3b0:      	cmp	w27, #0x1
     3b4:      	b.lt	0x3d8 <_gap_verify_graph+0x374>
     3b8:      	ldr	x14, [x19, #0x140]
     3bc:      	and	x13, x27, #0x7fffffff
     3c0:      	cmp	x14, x13
     3c4:      	b.ge	0x3e8 <_gap_verify_graph+0x384>
     3c8:      	mov	w28, #0x21              ; =33
     3cc:      	cmp	w0, #0xf
     3d0:      	b.ne	0x2bc <_gap_verify_graph+0x258>
     3d4:      	b	0x464 <_gap_verify_graph+0x400>
     3d8:      	mov	w28, #0x21              ; =33
     3dc:      	cmp	w0, #0xf
     3e0:      	b.ne	0x2bc <_gap_verify_graph+0x258>
     3e4:      	b	0x464 <_gap_verify_graph+0x400>
     3e8:      	ldr	x14, [x19, #0x138]
     3ec:      	umaddl	x13, w13, w17, x14
     3f0:      	ldr	x14, [x19, #0x118]
     3f4:      	ldp	x16, x13, [x13, #-0x18]
     3f8:      	subs	x14, x14, x16
     3fc:      	ccmp	x16, #0x0, #0x8, ge
     400:      	adrp	x16, 0x0 <ltmp0>
		0000000000000400:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     404:      	add	x16, x16, #0x0
		0000000000000404:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     408:      	ccmp	x13, #0x0, #0x8, pl
     40c:      	ccmp	x13, x14, #0x0, pl
     410:      	mov	w13, #0x21              ; =33
     414:      	csel	x28, x13, x28, gt
     418:      	cmp	w0, #0xf
     41c:      	b.ne	0x2bc <_gap_verify_graph+0x258>
     420:      	b	0x464 <_gap_verify_graph+0x400>
     424:      	tbnz	w27, #0x1f, 0x434 <_gap_verify_graph+0x3d0>
     428:      	cmp	w25, #0x1
     42c:      	b.ge	0x2fc <_gap_verify_graph+0x298>
     430:      	b	0x3b68 <_gap_verify_graph+0x3b04>
     434:      	ldr	x13, [x19, #0x30]
     438:      	ldr	x14, [x19, #0x58]
     43c:      	cmp	x13, x14
     440:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
     444:      	sxtw	x0, w27
     448:      	cmn	x13, x0
     44c:      	b.lt	0x3b68 <_gap_verify_graph+0x3b04>
     450:      	ldr	x13, [x19, #0x50]
     454:      	mvn	x14, x0
     458:      	ldr	w13, [x13, x14, lsl #2]
     45c:      	cmp	w13, #0x0
     460:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
     464:      	cmp	w24, w5
     468:      	b.gt	0xcc <_gap_verify_graph+0x68>
     46c:      	add	w24, w24, #0x1
     470:      	cbz	x28, 0x1d8 <_gap_verify_graph+0x174>
     474:      	b	0xcc <_gap_verify_graph+0x68>
     478:      	mov	x0, #-0x1               ; =-1
     47c:      	ret
     480:      	add	x8, sp, #0xd0
     484:      	adrp	x26, 0x0 <ltmp0>
		0000000000000484:  ARM64_RELOC_PAGE21	l_str.688
     488:      	add	x26, x26, #0x0
		0000000000000488:  ARM64_RELOC_PAGEOFF12	l_str.688
     48c:      	add	x9, x8, #0x8
     490:      	add	x8, sp, #0xe8
     494:      	mov	w27, #0x1e              ; =30
     498:      	add	x8, x8, #0x8
     49c:      	mov	w1, #0x5                ; =5
     4a0:      	mov	w20, #0x1               ; =1
     4a4:      	stp	x9, x8, [sp, #0x58]
     4a8:      	b	0x4c8 <_gap_verify_graph+0x464>
     4ac:      	cmp	w8, w9
     4b0:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
     4b4:      	adds	x8, x22, #0x4
     4b8:      	add	x9, x22, #0x7
     4bc:      	csel	x8, x9, x8, mi
     4c0:      	add	x20, x20, x8, asr #2
     4c4:      	cbnz	x21, 0x3b68 <_gap_verify_graph+0x3b04>
     4c8:      	ldr	x0, [x19, #0x8]
     4cc:      	cmp	x20, x0
     4d0:      	b.ge	0x3b6c <_gap_verify_graph+0x3b08>
     4d4:      	ldr	x5, [x19]
     4d8:      	add	x8, x5, x20, lsl #4
     4dc:      	ldr	x2, [x8]
     4e0:      	and	w24, w2, #0xff
     4e4:      	cmp	w24, #0xe
     4e8:      	b.lo	0x514 <_gap_verify_graph+0x4b0>
     4ec:      	cmp	w24, #0x18
     4f0:      	cset	w9, lo
     4f4:      	cmp	w24, #0x1a
     4f8:      	b.lo	0x520 <_gap_verify_graph+0x4bc>
     4fc:      	cmp	w24, #0x1f
     500:      	b.hs	0x8a4 <_gap_verify_graph+0x840>
     504:      	mov	w9, #0x1                ; =1
     508:      	str	wzr, [sp, #0x8c]
     50c:      	str	w9, [sp, #0x7c]
     510:      	b	0x530 <_gap_verify_graph+0x4cc>
     514:      	str	wzr, [sp, #0x7c]
     518:      	str	wzr, [sp, #0x8c]
     51c:      	b	0x528 <_gap_verify_graph+0x4c4>
     520:      	str	w9, [sp, #0x8c]
     524:      	str	wzr, [sp, #0x7c]
     528:      	cmp	w24, #0x3b
     52c:      	cset	w9, eq
     530:      	lsr	w12, w2, #8
     534:      	str	w9, [sp, #0x88]
     538:      	ubfx	w10, w2, #8, #4
     53c:      	cmp	w24, #0x3a
     540:      	and	w9, w12, #0xf0
     544:      	cset	w13, lo
     548:      	sub	w10, w10, #0x1
     54c:      	sub	w9, w9, #0x10
     550:      	cmp	w9, #0x70
     554:      	sub	w9, w24, #0x1f
     558:      	ccmp	w10, #0xd, #0x2, lo
     55c:      	sub	w10, w24, #0xe
     560:      	cset	w23, lo
     564:      	cmp	w9, #0x2
     568:      	ccmp	w10, #0xc, #0x0, hs
     56c:      	b.hs	0x578 <_gap_verify_graph+0x514>
     570:      	mov	w9, #0x1                ; =1
     574:      	b	0x594 <_gap_verify_graph+0x530>
     578:      	cmp	w24, #0x1a
     57c:      	b.lo	0x58c <_gap_verify_graph+0x528>
     580:      	cmp	w24, #0x3a
     584:      	ccmp	w24, #0x1e, #0x0, ne
     588:      	b.lo	0x570 <_gap_verify_graph+0x50c>
     58c:      	cmp	w24, #0x3b
     590:      	cset	w9, eq
     594:      	ldr	x28, [x19, #0x78]
     598:      	ldr	x3, [x8, #0x8]
     59c:      	eor	w10, w23, #0x1
     5a0:      	lsr	x8, x2, #32
     5a4:      	ands	w9, w9, w10
     5a8:      	stp	w12, w13, [sp, #0x80]
     5ac:      	ldrsw	x22, [x28, x20, lsl #2]
     5b0:      	b.eq	0x620 <_gap_verify_graph+0x5bc>
     5b4:      	cmp	w8, #0x1
     5b8:      	b.lt	0x63c <_gap_verify_graph+0x5d8>
     5bc:      	cmp	x0, x8
     5c0:      	b.le	0x680 <_gap_verify_graph+0x61c>
     5c4:      	ldr	x10, [x19, #0x80]
     5c8:      	cmp	x10, x8
     5cc:      	b.le	0x680 <_gap_verify_graph+0x61c>
     5d0:      	ldr	w10, [x28, x8, lsl #2]
     5d4:      	tbnz	w10, #0x1f, 0x680 <_gap_verify_graph+0x61c>
     5d8:      	add	x10, x5, x8, lsl #4
     5dc:      	cbz	x10, 0x680 <_gap_verify_graph+0x61c>
     5e0:      	ldr	w10, [x10]
     5e4:      	lsr	w10, w10, #8
     5e8:      	and	w11, w10, #0xf
     5ec:      	and	w10, w10, #0xff
     5f0:      	sub	w11, w11, #0x1
     5f4:      	sub	w12, w10, #0x10
     5f8:      	cmp	w11, #0xd
     5fc:      	mov	w11, #0x70              ; =112
     600:      	ccmp	w12, w11, #0x2, lo
     604:      	b.hs	0x684 <_gap_verify_graph+0x620>
     608:      	str	wzr, [sp, #0x9c]
     60c:      	cmp	w22, #0x1
     610:      	lsr	x4, x3, #32
     614:      	csinc	w11, w23, wzr, ge
     618:      	tbz	w11, #0x0, 0x6c0 <_gap_verify_graph+0x65c>
     61c:      	b	0x8f8 <_gap_verify_graph+0x894>
     620:      	str	wzr, [sp, #0x9c]
     624:      	mov	w10, #-0x1              ; =-1
     628:      	cmp	w22, #0x1
     62c:      	lsr	x4, x3, #32
     630:      	csinc	w11, w23, wzr, ge
     634:      	tbz	w11, #0x0, 0x6c0 <_gap_verify_graph+0x65c>
     638:      	b	0x8f8 <_gap_verify_graph+0x894>
     63c:      	tbz	x2, #0x3f, 0x680 <_gap_verify_graph+0x61c>
     640:      	ldr	x10, [x19, #0x30]
     644:      	ldr	x11, [x19, #0x58]
     648:      	cmp	x10, x11
     64c:      	b.ne	0x680 <_gap_verify_graph+0x61c>
     650:      	asr	x11, x2, #32
     654:      	cmn	x10, x11
     658:      	b.lt	0x680 <_gap_verify_graph+0x61c>
     65c:      	ldr	x10, [x19, #0x50]
     660:      	mvn	x11, x11
     664:      	ldr	w10, [x10, x11, lsl #2]
     668:      	cmp	w10, #0x0
     66c:      	b.le	0x680 <_gap_verify_graph+0x61c>
     670:      	ldr	x10, [x19, #0x28]
     674:      	eor	x11, x8, #0xffffffff
     678:      	add	x10, x10, x11, lsl #4
     67c:      	cbnz	x10, 0x5e0 <_gap_verify_graph+0x57c>
     680:      	mov	w10, #-0x1              ; =-1
     684:      	and	w11, w2, #0xfe00
     688:      	and	w12, w2, #0xfe
     68c:      	cmp	w11, #0xc00
     690:      	ccmp	w12, #0x18, #0x4, ne
     694:      	b.ne	0x6a0 <_gap_verify_graph+0x63c>
     698:      	mov	w11, #0x1               ; =1
     69c:      	b	0x6ac <_gap_verify_graph+0x648>
     6a0:      	and	w11, w10, #0xfffffffe
     6a4:      	cmp	w11, #0xc
     6a8:      	cset	w11, eq
     6ac:      	str	w11, [sp, #0x9c]
     6b0:      	cmp	w22, #0x1
     6b4:      	lsr	x4, x3, #32
     6b8:      	csinc	w11, w23, wzr, ge
     6bc:      	tbnz	w11, #0x0, 0x8f8 <_gap_verify_graph+0x894>
     6c0:      	sub	w11, w10, #0x10
     6c4:      	and	w10, w10, #0xf
     6c8:      	sub	w10, w10, #0x1
     6cc:      	cmp	w11, #0x70
     6d0:      	ccmp	w10, #0xd, #0x2, lo
     6d4:      	cset	w10, lo
     6d8:      	cmp	w24, #0x83
     6dc:      	b.hs	0x884 <_gap_verify_graph+0x820>
     6e0:      	mov	w11, w20
     6e4:      	cmp	w20, #0x0
     6e8:      	and	x12, x2, #0xff
     6ec:      	ccmp	x0, x11, #0x4, gt
     6f0:      	mov	w14, #0x1               ; =1
     6f4:      	cset	w13, gt
     6f8:      	cmp	w14, #0x1
     6fc:      	b.lt	0x810 <_gap_verify_graph+0x7ac>
     700:      	cmp	w14, #0x5
     704:      	ldr	w16, [x16, x12, lsl #2]
     708:      	csel	w15, w14, w1, lo
     70c:      	lsl	w15, w15, #2
     710:      	sub	w15, w15, #0x4
     714:      	lsr	w15, w16, w15
     718:      	and	w15, w15, #0xf
     71c:      	cmp	w15, #0x9
     720:      	ccmp	w15, #0x2, #0x4, ne
     724:      	b.ne	0x864 <_gap_verify_graph+0x800>
     728:      	cmp	w14, #0x1
     72c:      	mov	w23, w10
     730:      	adrp	x16, 0x0 <ltmp0>
		0000000000000730:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     734:      	add	x16, x16, #0x0
		0000000000000734:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     738:      	csel	w15, wzr, w9, ne
     73c:      	tbnz	w15, #0x0, 0x814 <_gap_verify_graph+0x7b0>
     740:      	mov	w15, w8
     744:      	b.eq	0x7b4 <_gap_verify_graph+0x750>
     748:      	cmp	w14, #0x2
     74c:      	mov	w15, w3
     750:      	b.eq	0x7b4 <_gap_verify_graph+0x750>
     754:      	cmp	w14, #0x3
     758:      	mov	w15, w4
     75c:      	b.eq	0x7b4 <_gap_verify_graph+0x750>
     760:      	cbz	w13, 0x7a0 <_gap_verify_graph+0x73c>
     764:      	ldr	x15, [x19, #0x80]
     768:      	cmp	x15, x11
     76c:      	b.le	0x7a0 <_gap_verify_graph+0x73c>
     770:      	ldr	w16, [x28, x11, lsl #2]
     774:      	mov	x15, xzr
     778:      	tbnz	w16, #0x1f, 0x860 <_gap_verify_graph+0x7fc>
     77c:      	cmp	w14, w16
     780:      	b.hi	0x7a4 <_gap_verify_graph+0x740>
     784:      	add	w15, w20, w14, lsr #2
     788:      	and	w16, w14, #0x3
     78c:      	add	x15, x5, w15, uxtw #4
     790:      	ldr	w16, [x15, w16, uxtw #2]
     794:      	mov	w15, #0x1               ; =1
     798:      	cbnz	w15, 0x7a8 <_gap_verify_graph+0x744>
     79c:      	b	0x864 <_gap_verify_graph+0x800>
     7a0:      	mov	x15, xzr
     7a4:      	cbz	w15, 0x864 <_gap_verify_graph+0x800>
     7a8:      	mov	w15, w16
     7ac:      	adrp	x16, 0x0 <ltmp0>
		00000000000007ac:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     7b0:      	add	x16, x16, #0x0
		00000000000007b0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     7b4:      	cmp	w15, #0x1
     7b8:      	b.lt	0x80c <_gap_verify_graph+0x7a8>
     7bc:      	mov	w15, w15
     7c0:      	cmp	x0, x15
     7c4:      	b.le	0x810 <_gap_verify_graph+0x7ac>
     7c8:      	ldr	x16, [x19, #0x80]
     7cc:      	cmp	x16, x15
     7d0:      	b.le	0x864 <_gap_verify_graph+0x800>
     7d4:      	ldr	w16, [x28, x15, lsl #2]
     7d8:      	tbnz	w16, #0x1f, 0x864 <_gap_verify_graph+0x800>
     7dc:      	add	x15, x5, x15, lsl #4
     7e0:      	cbz	x15, 0x864 <_gap_verify_graph+0x800>
     7e4:      	ldr	w15, [x15]
     7e8:      	lsr	w15, w15, #8
     7ec:      	and	w16, w15, #0xf0
     7f0:      	and	w15, w15, #0xf
     7f4:      	sub	w16, w16, #0x10
     7f8:      	sub	w15, w15, #0x1
     7fc:      	cmp	w16, #0x70
     800:      	ccmp	w15, #0xd, #0x2, lo
     804:      	cset	w23, lo
     808:      	b	0x868 <_gap_verify_graph+0x804>
     80c:      	tbnz	w15, #0x1f, 0x81c <_gap_verify_graph+0x7b8>
     810:      	mov	w23, wzr
     814:      	tbz	w23, #0x0, 0x874 <_gap_verify_graph+0x810>
     818:      	b	0x8f8 <_gap_verify_graph+0x894>
     81c:      	ldr	x16, [x19, #0x30]
     820:      	ldr	x17, [x19, #0x58]
     824:      	cmp	x16, x17
     828:      	b.ne	0x864 <_gap_verify_graph+0x800>
     82c:      	sxtw	x17, w15
     830:      	cmn	x16, x17
     834:      	b.lt	0x864 <_gap_verify_graph+0x800>
     838:      	ldr	x16, [x19, #0x50]
     83c:      	mvn	x17, x17
     840:      	ldr	w16, [x16, x17, lsl #2]
     844:      	cmp	w16, #0x0
     848:      	b.le	0x864 <_gap_verify_graph+0x800>
     84c:      	ldr	x16, [x19, #0x28]
     850:      	mvn	w15, w15
     854:      	add	x15, x16, w15, uxtw #4
     858:      	cbnz	x15, 0x7e4 <_gap_verify_graph+0x780>
     85c:      	b	0x864 <_gap_verify_graph+0x800>
     860:      	cbnz	w15, 0x7a8 <_gap_verify_graph+0x744>
     864:      	mov	w23, wzr
     868:      	adrp	x16, 0x0 <ltmp0>
		0000000000000868:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     86c:      	add	x16, x16, #0x0
		000000000000086c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     870:      	tbnz	w23, #0x0, 0x8f8 <_gap_verify_graph+0x894>
     874:      	add	w14, w14, #0x1
     878:      	cmp	w14, w22
     87c:      	b.le	0x6f8 <_gap_verify_graph+0x694>
     880:      	b	0x8f8 <_gap_verify_graph+0x894>
     884:      	mov	w8, #-0x7fffffff        ; =-2147483647
     888:      	mov	w9, #0x5                ; =5
     88c:      	add	w8, w22, w8
     890:      	movk	w9, #0x8000, lsl #16
     894:      	cmp	w8, w9
     898:      	b.hs	0x8cc <_gap_verify_graph+0x868>
     89c:      	mov	w8, #0x1                ; =1
     8a0:      	b	0x8e8 <_gap_verify_graph+0x884>
     8a4:      	cmp	w24, #0x2e
     8a8:      	b.lo	0xb70 <_gap_verify_graph+0xb0c>
     8ac:      	cmp	w24, #0x3a
     8b0:      	mov	w9, #0x36               ; =54
     8b4:      	str	wzr, [sp, #0x8c]
     8b8:      	ccmp	w24, w9, #0x0, ne
     8bc:      	mov	w9, #0x1                ; =1
     8c0:      	str	w9, [sp, #0x7c]
     8c4:      	b.hs	0x528 <_gap_verify_graph+0x4c4>
     8c8:      	b	0x530 <_gap_verify_graph+0x4cc>
     8cc:      	and	w9, w22, #0x7ffffffc
     8d0:      	and	w10, w22, #0x7ffffffc
     8d4:      	orr	w8, w9, #0x1
     8d8:      	subs	w10, w10, #0x4
     8dc:      	b.ne	0x8d8 <_gap_verify_graph+0x874>
     8e0:      	cmp	w22, w9
     8e4:      	b.eq	0x8f4 <_gap_verify_graph+0x890>
     8e8:      	add	w8, w8, #0x1
     8ec:      	cmp	w8, w22
     8f0:      	b.le	0x8e8 <_gap_verify_graph+0x884>
     8f4:      	mov	w23, wzr
     8f8:      	sub	w8, w24, #0x3d
     8fc:      	ldr	w9, [sp, #0x9c]
     900:      	sturb	w23, [x29, #-0x80]
     904:      	cmp	w8, #0x3
     908:      	str	x2, [sp, #0x90]
     90c:      	cset	w8, lo
     910:      	sturb	w9, [x29, #-0xc0]
     914:      	orr	w8, w8, w23
     918:      	str	x3, [sp, #0x70]
     91c:      	tbz	w8, #0x0, 0x984 <_gap_verify_graph+0x920>
     920:      	cmp	w20, #0x1
     924:      	b.lt	0x98c <_gap_verify_graph+0x928>
     928:      	and	x8, x20, #0x7fffffff
     92c:      	cmp	x0, x8
     930:      	b.le	0x9ac <_gap_verify_graph+0x948>
     934:      	ldr	x17, [x19, #0x80]
     938:      	cmp	x17, x8
     93c:      	b.le	0x9ac <_gap_verify_graph+0x948>
     940:      	ldr	w27, [x28, x8, lsl #2]
     944:      	tbnz	w27, #0x1f, 0x9ac <_gap_verify_graph+0x948>
     948:      	add	x8, x5, x8, lsl #4
     94c:      	ldr	x1, [x8]
     950:      	and	w11, w1, #0xff
     954:      	cmp	w11, #0x24
     958:      	b.eq	0xd04 <_gap_verify_graph+0xca0>
     95c:      	cmp	w11, #0x3c
     960:      	b.eq	0xcec <_gap_verify_graph+0xc88>
     964:      	cmp	w11, #0x44
     968:      	b.ne	0xd3c <_gap_verify_graph+0xcd8>
     96c:      	add	x0, sp, #0xa0
     970:      	mov	x1, x19
     974:      	mov	w2, w20
     978:      	str	x4, [sp, #0x50]
     97c:      	bl	0x97c <_gap_verify_graph+0x918>
		000000000000097c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
     980:      	b	0xd18 <_gap_verify_graph+0xcb4>
     984:      	mov	x25, xzr
     988:      	b	0x9c4 <_gap_verify_graph+0x960>
     98c:      	tbz	w20, #0x1f, 0x9ac <_gap_verify_graph+0x948>
     990:      	ldr	x8, [x19, #0x30]
     994:      	ldr	x9, [x19, #0x58]
     998:      	cmp	x8, x9
     99c:      	b.ne	0x9ac <_gap_verify_graph+0x948>
     9a0:      	sxtw	x9, w20
     9a4:      	cmn	x8, x9
     9a8:      	b.ge	0xca0 <_gap_verify_graph+0xc3c>
     9ac:      	mov	x21, x26
     9b0:      	mov	w25, #0x1a              ; =26
     9b4:      	mov	w8, #0x1                ; =1
     9b8:      	stp	x21, x25, [sp, #0xa8]
     9bc:      	mov	w27, #0x1e              ; =30
     9c0:      	str	w8, [sp, #0xa0]
     9c4:      	cmp	w24, #0x44
     9c8:      	cset	w8, ne
     9cc:      	orr	w8, w8, w23
     9d0:      	tbz	w8, #0x0, 0xa48 <_gap_verify_graph+0x9e4>
     9d4:      	sub	w8, w24, #0x1d
     9d8:      	cmp	w8, #0x1
     9dc:      	b.hi	0xa6c <_gap_verify_graph+0xa08>
     9e0:      	cbz	x4, 0x174c <_gap_verify_graph+0x16e8>
     9e4:      	cmp	w4, #0x1
     9e8:      	b.lt	0xc10 <_gap_verify_graph+0xbac>
     9ec:      	ldr	x8, [x19, #0x8]
     9f0:      	cmp	x8, x4
     9f4:      	b.le	0xc30 <_gap_verify_graph+0xbcc>
     9f8:      	ldr	x8, [x19, #0x80]
     9fc:      	cmp	x8, x4
     a00:      	b.le	0xc30 <_gap_verify_graph+0xbcc>
     a04:      	ldr	x8, [x19, #0x78]
     a08:      	ldr	w8, [x8, x4, lsl #2]
     a0c:      	tbnz	w8, #0x1f, 0xc30 <_gap_verify_graph+0xbcc>
     a10:      	ldr	x8, [x19]
     a14:      	lsl	x9, x4, #4
     a18:      	ldr	w8, [x8, x9]
     a1c:      	and	w9, w8, #0xfe
     a20:      	and	w8, w8, #0xff
     a24:      	sub	w9, w9, #0x68
     a28:      	cmp	w9, #0xa
     a2c:      	mov	w9, #0x65               ; =101
     a30:      	ccmp	w8, w9, #0x4, hs
     a34:      	b.eq	0x174c <_gap_verify_graph+0x16e8>
     a38:      	cmp	w8, #0x66
     a3c:      	mov	w8, #0x2d               ; =45
     a40:      	csel	x8, x25, x8, eq
     a44:      	b	0x1750 <_gap_verify_graph+0x16ec>
     a48:      	add	x0, sp, #0xb8
     a4c:      	mov	x1, x19
     a50:      	mov	w2, w20
     a54:      	bl	0xa54 <_gap_verify_graph+0x9f0>
		0000000000000a54:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
     a58:      	ldr	w8, [sp, #0xb8]
     a5c:      	ldr	x9, [sp, #0xc8]
     a60:      	cmp	w8, #0x1
     a64:      	csel	x8, x9, x25, eq
     a68:      	b	0x1750 <_gap_verify_graph+0x16ec>
     a6c:      	sub	w8, w24, #0x29
     a70:      	cmp	w8, #0x3
     a74:      	b.hs	0xaa8 <_gap_verify_graph+0xa44>
     a78:      	add	x0, sp, #0xe8
     a7c:      	mov	x1, x19
     a80:      	mov	w2, w20
     a84:      	add	x21, sp, #0xe8
     a88:      	bl	0xa88 <_gap_verify_graph+0xa24>
		0000000000000a88:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
     a8c:      	ldr	x10, [sp, #0x60]
     a90:      	ldr	w8, [x21]
     a94:      	cmp	w8, #0x1
     a98:      	mov	x8, x25
     a9c:      	b.ne	0x1750 <_gap_verify_graph+0x16ec>
     aa0:      	ldr	x8, [x10, #0x8]
     aa4:      	b	0x1750 <_gap_verify_graph+0x16ec>
     aa8:      	cmp	w24, #0x2c
     aac:      	b.ne	0xb80 <_gap_verify_graph+0xb1c>
     ab0:      	cmp	w20, #0x1
     ab4:      	b.lt	0xc38 <_gap_verify_graph+0xbd4>
     ab8:      	ldr	x8, [x19, #0x8]
     abc:      	and	x12, x20, #0x7fffffff
     ac0:      	cmp	x8, x12
     ac4:      	b.le	0xc7c <_gap_verify_graph+0xc18>
     ac8:      	ldr	x9, [x19, #0x80]
     acc:      	cmp	x9, x12
     ad0:      	b.le	0xc7c <_gap_verify_graph+0xc18>
     ad4:      	ldr	x10, [x19, #0x78]
     ad8:      	ldr	w13, [x10, x12, lsl #2]
     adc:      	tbnz	w13, #0x1f, 0xc7c <_gap_verify_graph+0xc18>
     ae0:      	ldr	x11, [x19]
     ae4:      	lsl	x12, x12, #4
     ae8:      	ldr	x12, [x11, x12]
     aec:      	and	x14, x12, #0xffff
     af0:      	cmp	x14, #0x12c
     af4:      	ccmp	w13, #0x1, #0x0, eq
     af8:      	b.ne	0xc6c <_gap_verify_graph+0xc08>
     afc:      	lsr	x2, x12, #32
     b00:      	cmp	w2, #0x1
     b04:      	b.lt	0x11a4 <_gap_verify_graph+0x1140>
     b08:      	cmp	x8, x2
     b0c:      	b.ls	0x11a8 <_gap_verify_graph+0x1144>
     b10:      	cmp	x9, x2
     b14:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b14:  ARM64_RELOC_PAGE21	l_str.370
     b18:      	add	x8, x8, #0x0
		0000000000000b18:  ARM64_RELOC_PAGEOFF12	l_str.370
     b1c:      	mov	w9, #0x17               ; =23
     b20:      	b.ls	0xc88 <_gap_verify_graph+0xc24>
     b24:      	ldr	w8, [x10, x2, lsl #2]
     b28:      	tbnz	w8, #0x1f, 0x11a8 <_gap_verify_graph+0x1144>
     b2c:      	add	x8, x11, x2, lsl #4
     b30:      	ldr	x8, [x8]
     b34:      	and	w9, w8, #0xff
     b38:      	sub	w9, w9, #0x29
     b3c:      	cmp	w9, #0x2
     b40:      	b.hi	0x13c0 <_gap_verify_graph+0x135c>
     b44:      	add	x0, sp, #0xd0
     b48:      	mov	x1, x19
     b4c:      	add	x21, sp, #0xd0
     b50:      	bl	0xb50 <_gap_verify_graph+0xaec>
		0000000000000b50:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
     b54:      	ldr	x10, [sp, #0x58]
     b58:      	mov	w27, #0x1e              ; =30
     b5c:      	ldr	w8, [x21]
     b60:      	cmp	w8, #0x1
     b64:      	mov	x8, x25
     b68:      	b.eq	0xaa0 <_gap_verify_graph+0xa3c>
     b6c:      	b	0x1750 <_gap_verify_graph+0x16ec>
     b70:      	mov	w9, #0x1                ; =1
     b74:      	str	wzr, [sp, #0x8c]
     b78:      	str	w9, [sp, #0x7c]
     b7c:      	b	0x528 <_gap_verify_graph+0x4c4>
     b80:      	sub	w8, w24, #0x7e
     b84:      	cmp	w8, #0x4
     b88:      	b.hi	0x174c <_gap_verify_graph+0x16e8>
     b8c:      	cmp	w20, #0x1
     b90:      	b.lt	0xe38 <_gap_verify_graph+0xdd4>
     b94:      	ldr	x9, [x19, #0x8]
     b98:      	and	x8, x20, #0x7fffffff
     b9c:      	cmp	x9, x8
     ba0:      	b.le	0x1170 <_gap_verify_graph+0x110c>
     ba4:      	ldr	x9, [x19, #0x80]
     ba8:      	cmp	x9, x8
     bac:      	b.le	0x1170 <_gap_verify_graph+0x110c>
     bb0:      	ldr	x9, [x19, #0x78]
     bb4:      	ldr	w9, [x9, x8, lsl #2]
     bb8:      	tbnz	w9, #0x1f, 0x1170 <_gap_verify_graph+0x110c>
     bbc:      	ldr	x9, [x19]
     bc0:      	add	x11, x9, x8, lsl #4
     bc4:      	cmp	w20, #0x1
     bc8:      	ldr	x10, [x11]
     bcc:      	and	w12, w10, #0xff
     bd0:      	b.lt	0x1100 <_gap_verify_graph+0x109c>
     bd4:      	sub	w8, w12, #0x7e
     bd8:      	cmp	w8, #0x4
     bdc:      	mov	w8, #0x20               ; =32
     be0:      	b.hi	0x1104 <_gap_verify_graph+0x10a0>
     be4:      	ldr	x8, [x19, #0x78]
     be8:      	and	x9, x20, #0x7fffffff
     bec:      	and	x13, x10, #0xff
     bf0:      	ldr	w8, [x8, x9, lsl #2]
     bf4:      	adrp	x9, 0x0 <ltmp0>
		0000000000000bf4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.OPERAND-SLOTS
     bf8:      	add	x9, x9, #0x0
		0000000000000bf8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.OPERAND-SLOTS
     bfc:      	ldrsb	w9, [x9, x13]
     c00:      	cmp	w8, w9
     c04:      	mov	w8, #0x20               ; =32
     c08:      	csel	x8, x8, xzr, ne
     c0c:      	b	0x1104 <_gap_verify_graph+0x10a0>
     c10:      	ldr	x8, [x19, #0x30]
     c14:      	ldr	x9, [x19, #0x58]
     c18:      	cmp	x8, x9
     c1c:      	b.ne	0xc30 <_gap_verify_graph+0xbcc>
     c20:      	ldr	x9, [sp, #0x70]
     c24:      	asr	x9, x9, #32
     c28:      	cmn	x8, x9
     c2c:      	b.ge	0xccc <_gap_verify_graph+0xc68>
     c30:      	mov	w8, #0x16               ; =22
     c34:      	b	0x1750 <_gap_verify_graph+0x16ec>
     c38:      	tbz	w20, #0x1f, 0xc7c <_gap_verify_graph+0xc18>
     c3c:      	ldr	x8, [x19, #0x30]
     c40:      	ldr	x9, [x19, #0x58]
     c44:      	cmp	x8, x9
     c48:      	b.ne	0xc7c <_gap_verify_graph+0xc18>
     c4c:      	sxtw	x9, w20
     c50:      	cmn	x8, x9
     c54:      	b.lt	0xc7c <_gap_verify_graph+0xc18>
     c58:      	ldr	x8, [x19, #0x50]
     c5c:      	mvn	x9, x9
     c60:      	ldr	w8, [x8, x9, lsl #2]
     c64:      	cmp	w8, #0x0
     c68:      	b.le	0xc7c <_gap_verify_graph+0xc18>
     c6c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000c6c:  ARM64_RELOC_PAGE21	l_str.375
     c70:      	add	x8, x8, #0x0
		0000000000000c70:  ARM64_RELOC_PAGEOFF12	l_str.375
     c74:      	mov	w9, #0x1c               ; =28
     c78:      	b	0xc88 <_gap_verify_graph+0xc24>
     c7c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000c7c:  ARM64_RELOC_PAGE21	l_str.374
     c80:      	add	x8, x8, #0x0
		0000000000000c80:  ARM64_RELOC_PAGEOFF12	l_str.374
     c84:      	mov	w9, #0x10               ; =16
     c88:      	mov	w10, #0x1               ; =1
     c8c:      	stp	x8, x9, [sp, #0xd8]
     c90:      	str	w10, [sp, #0xd0]
     c94:      	ldr	x10, [sp, #0x58]
     c98:      	ldr	x8, [x10, #0x8]
     c9c:      	b	0x1750 <_gap_verify_graph+0x16ec>
     ca0:      	ldr	x8, [x19, #0x50]
     ca4:      	mvn	x9, x9
     ca8:      	ldr	w8, [x8, x9, lsl #2]
     cac:      	mov	w9, #0x3b               ; =59
     cb0:      	cmp	w8, #0x0
     cb4:      	adrp	x8, 0x0 <ltmp0>
		0000000000000cb4:  ARM64_RELOC_PAGE21	l_str.689
     cb8:      	add	x8, x8, #0x0
		0000000000000cb8:  ARM64_RELOC_PAGEOFF12	l_str.689
     cbc:      	csel	x21, x8, x26, gt
     cc0:      	mov	w8, #0x1a               ; =26
     cc4:      	csel	x25, x9, x8, gt
     cc8:      	b	0x9b4 <_gap_verify_graph+0x950>
     ccc:      	ldr	x8, [x19, #0x50]
     cd0:      	mvn	x9, x9
     cd4:      	ldr	w8, [x8, x9, lsl #2]
     cd8:      	mov	w9, #0x2d               ; =45
     cdc:      	cmp	w8, #0x0
     ce0:      	mov	w8, #0x16               ; =22
     ce4:      	csel	x8, x9, x8, gt
     ce8:      	b	0x1750 <_gap_verify_graph+0x16ec>
     cec:      	add	x0, sp, #0xa0
     cf0:      	mov	x1, x19
     cf4:      	mov	w2, w20
     cf8:      	str	x4, [sp, #0x50]
     cfc:      	bl	0xcfc <_gap_verify_graph+0xc98>
		0000000000000cfc:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
     d00:      	b	0xd18 <_gap_verify_graph+0xcb4>
     d04:      	add	x0, sp, #0xa0
     d08:      	mov	x1, x19
     d0c:      	mov	w2, w20
     d10:      	str	x4, [sp, #0x50]
     d14:      	bl	0xd14 <_gap_verify_graph+0xcb0>
		0000000000000d14:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
     d18:      	ldr	w8, [sp, #0xa0]
     d1c:      	ldr	x9, [sp, #0xb0]
     d20:      	adrp	x16, 0x0 <ltmp0>
		0000000000000d20:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     d24:      	add	x16, x16, #0x0
		0000000000000d24:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     d28:      	ldr	x4, [sp, #0x50]
     d2c:      	mov	w27, #0x1e              ; =30
     d30:      	cmp	w8, #0x1
     d34:      	csel	x25, x9, xzr, eq
     d38:      	b	0x9c4 <_gap_verify_graph+0x960>
     d3c:      	ldr	x10, [x8, #0x8]
     d40:      	sub	w8, w11, #0x3d
     d44:      	lsr	x12, x1, #32
     d48:      	ubfx	w15, w1, #8, #8
     d4c:      	mov	w25, w1
     d50:      	cmp	w8, #0x2
     d54:      	b.hi	0xe44 <_gap_verify_graph+0xde0>
     d58:      	cmp	w11, #0x3e
     d5c:      	mov	w8, #0x3                ; =3
     d60:      	mov	w9, #0x2                ; =2
     d64:      	csinc	w8, w8, wzr, eq
     d68:      	cmp	w11, #0x3d
     d6c:      	csel	w8, w9, w8, eq
     d70:      	cmp	w27, w8
     d74:      	b.ne	0x1194 <_gap_verify_graph+0x1130>
     d78:      	cmp	w12, #0x1
     d7c:      	b.lt	0x11b8 <_gap_verify_graph+0x1154>
     d80:      	cmp	x0, x12
     d84:      	stp	x0, x10, [sp, #0x38]
     d88:      	str	w15, [sp, #0x48]
     d8c:      	b.ls	0x11bc <_gap_verify_graph+0x1158>
     d90:      	cmp	x17, x12
     d94:      	adrp	x21, 0x0 <ltmp0>
		0000000000000d94:  ARM64_RELOC_PAGE21	l_str.667
     d98:      	add	x21, x21, #0x0
		0000000000000d98:  ARM64_RELOC_PAGEOFF12	l_str.667
     d9c:      	mov	w25, #0x1b              ; =27
     da0:      	stp	x17, x5, [sp, #0x28]
     da4:      	b.ls	0x9b4 <_gap_verify_graph+0x950>
     da8:      	mov	x8, x12
     dac:      	mov	x9, x12
     db0:      	ldr	w8, [x28, x8, lsl #2]
     db4:      	tbnz	w8, #0x1f, 0x15b4 <_gap_verify_graph+0x1550>
     db8:      	ldr	x8, [sp, #0x30]
     dbc:      	str	x4, [sp, #0x50]
     dc0:      	add	x8, x8, x9, lsl #4
     dc4:      	ldr	w9, [sp, #0x48]
     dc8:      	cmp	w11, #0x3d
     dcc:      	ldr	x8, [x8]
     dd0:      	ubfx	w10, w8, #8, #8
     dd4:      	mov	w27, w10
     dd8:      	csel	w10, w10, w9, eq
     ddc:      	sub	w9, w10, #0x10
     de0:      	str	x10, [sp]
     de4:      	and	w10, w10, #0xf
     de8:      	str	w10, [sp, #0xc]
     dec:      	sub	w10, w10, #0x1
     df0:      	cmp	w9, #0x70
     df4:      	ccmp	w10, #0xd, #0x2, lo
     df8:      	cset	w9, lo
     dfc:      	str	w9, [sp, #0x10]
     e00:      	b.hs	0x2938 <_gap_verify_graph+0x28d4>
     e04:      	and	w8, w8, #0xff
     e08:      	mov	w9, #0x46               ; =70
     e0c:      	cmp	w8, #0x48
     e10:      	ccmp	w8, w9, #0x4, ne
     e14:      	mov	w8, #0x36               ; =54
     e18:      	adrp	x9, 0x0 <ltmp0>
		0000000000000e18:  ARM64_RELOC_PAGE21	l_str.668
     e1c:      	add	x9, x9, #0x0
		0000000000000e1c:  ARM64_RELOC_PAGEOFF12	l_str.668
     e20:      	csel	x8, x8, xzr, eq
     e24:      	str	x8, [sp, #0x20]
     e28:      	adrp	x8, 0x0 <ltmp0>
		0000000000000e28:  ARM64_RELOC_PAGE21	l_str.669
     e2c:      	add	x8, x8, #0x0
		0000000000000e2c:  ARM64_RELOC_PAGEOFF12	l_str.669
     e30:      	csel	x8, x8, x9, eq
     e34:      	b	0x2948 <_gap_verify_graph+0x28e4>
     e38:      	tbnz	w20, #0x1f, 0x10b0 <_gap_verify_graph+0x104c>
     e3c:      	mov	w25, #0x1a              ; =26
     e40:      	b	0x18f0 <_gap_verify_graph+0x188c>
     e44:      	and	w14, w25, #0xfe
     e48:      	lsr	w21, w1, #8
     e4c:      	ubfx	w30, w25, #8, #4
     e50:      	sub	w8, w14, #0xe
     e54:      	cmp	w8, #0xb
     e58:      	b.hi	0x1054 <_gap_verify_graph+0xff0>
     e5c:      	and	w8, w21, #0xf0
     e60:      	sub	w9, w30, #0x1
     e64:      	sub	w8, w8, #0x10
     e68:      	cmp	w9, #0xd
     e6c:      	mov	w9, #0x70               ; =112
     e70:      	ccmp	w8, w9, #0x2, lo
     e74:      	b.hs	0x1054 <_gap_verify_graph+0xff0>
     e78:      	cmp	w27, #0x2
     e7c:      	b.ne	0x11cc <_gap_verify_graph+0x1168>
     e80:      	mov	w2, w30
     e84:      	mov	w14, w11
     e88:      	mov	x11, x10
     e8c:      	mov	w13, w15
     e90:      	mov	x27, x26
     e94:      	cmp	w12, #0x1
     e98:      	str	x4, [sp, #0x50]
     e9c:      	b.lt	0x2b64 <_gap_verify_graph+0x2b00>
     ea0:      	cmp	x0, x12
     ea4:      	b.ls	0x2c14 <_gap_verify_graph+0x2bb0>
     ea8:      	ldr	x4, [sp, #0x50]
     eac:      	mov	x10, x12
     eb0:      	cmp	x17, x12
     eb4:      	adrp	x21, 0x0 <ltmp0>
		0000000000000eb4:  ARM64_RELOC_PAGE21	l_str.662
     eb8:      	add	x21, x21, #0x0
		0000000000000eb8:  ARM64_RELOC_PAGEOFF12	l_str.662
     ebc:      	mov	w25, #0x21              ; =33
     ec0:      	adrp	x16, 0x0 <ltmp0>
		0000000000000ec0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     ec4:      	add	x16, x16, #0x0
		0000000000000ec4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     ec8:      	mov	x26, x27
     ecc:      	b.ls	0x9b4 <_gap_verify_graph+0x950>
     ed0:      	ldr	w8, [x28, x10, lsl #2]
     ed4:      	tbnz	w8, #0x1f, 0x2dec <_gap_verify_graph+0x2d88>
     ed8:      	mov	x9, x0
     edc:      	add	x8, x5, x10, lsl #4
     ee0:      	ldr	x8, [x8]
     ee4:      	cmp	w11, #0x1
     ee8:      	b.lt	0x2bb4 <_gap_verify_graph+0x2b50>
     eec:      	and	x10, x11, #0x7fffffff
     ef0:      	cmp	x9, x10
     ef4:      	b.ls	0x2df4 <_gap_verify_graph+0x2d90>
     ef8:      	ldr	x4, [sp, #0x50]
     efc:      	cmp	x17, x10
     f00:      	adrp	x21, 0x0 <ltmp0>
		0000000000000f00:  ARM64_RELOC_PAGE21	l_str.663
     f04:      	add	x21, x21, #0x0
		0000000000000f04:  ARM64_RELOC_PAGEOFF12	l_str.663
     f08:      	mov	w25, #0x21              ; =33
     f0c:      	adrp	x16, 0x0 <ltmp0>
		0000000000000f0c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     f10:      	add	x16, x16, #0x0
		0000000000000f10:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     f14:      	mov	x26, x27
     f18:      	b.ls	0x9b4 <_gap_verify_graph+0x950>
     f1c:      	ldr	w9, [x28, x10, lsl #2]
     f20:      	tbnz	w9, #0x1f, 0x2dec <_gap_verify_graph+0x2d88>
     f24:      	add	x9, x5, x10, lsl #4
     f28:      	sub	w10, w14, #0xe
     f2c:      	cmp	w10, #0xb
     f30:      	b.hi	0x2c04 <_gap_verify_graph+0x2ba0>
     f34:      	lsr	x10, x8, #8
     f38:      	ubfx	x12, x8, #8, #8
     f3c:      	and	w11, w10, #0xf
     f40:      	str	x12, [sp]
     f44:      	sub	w12, w12, #0x10
     f48:      	sub	w11, w11, #0x1
     f4c:      	and	w28, w10, #0xf
     f50:      	cmp	w11, #0xd
     f54:      	mov	w11, #0x70              ; =112
     f58:      	ccmp	w12, w11, #0x2, lo
     f5c:      	b.hs	0x2c04 <_gap_verify_graph+0x2ba0>
     f60:      	and	w11, w10, #0xe
     f64:      	cmp	w14, #0x18
     f68:      	ccmp	w11, #0xc, #0x4, hs
     f6c:      	b.ne	0x2c04 <_gap_verify_graph+0x2ba0>
     f70:      	ldr	x9, [x9]
     f74:      	and	w10, w10, #0xff
     f78:      	ldr	x4, [sp, #0x50]
     f7c:      	adrp	x21, 0x0 <ltmp0>
		0000000000000f7c:  ARM64_RELOC_PAGE21	l_str.664
     f80:      	add	x21, x21, #0x0
		0000000000000f80:  ARM64_RELOC_PAGEOFF12	l_str.664
     f84:      	mov	w25, #0x33              ; =51
     f88:      	lsr	x11, x9, #8
     f8c:      	adrp	x16, 0x0 <ltmp0>
		0000000000000f8c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
     f90:      	add	x16, x16, #0x0
		0000000000000f90:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
     f94:      	mov	x26, x27
     f98:      	cmp	w10, w11, uxtb
     f9c:      	b.ne	0x9b4 <_gap_verify_graph+0x950>
     fa0:      	and	w8, w8, #0xff
     fa4:      	cmp	w8, #0x46
     fa8:      	b.eq	0x3acc <_gap_verify_graph+0x3a68>
     fac:      	ldr	x4, [sp, #0x50]
     fb0:      	cmp	w8, #0x48
     fb4:      	mov	w25, #0x33              ; =51
     fb8:      	mov	x26, x27
     fbc:      	b.eq	0x9b4 <_gap_verify_graph+0x950>
     fc0:      	and	w8, w9, #0xff
     fc4:      	cmp	w8, #0x46
     fc8:      	b.eq	0x3acc <_gap_verify_graph+0x3a68>
     fcc:      	ldr	x4, [sp, #0x50]
     fd0:      	cmp	w8, #0x48
     fd4:      	mov	w25, #0x33              ; =51
     fd8:      	mov	x26, x27
     fdc:      	b.eq	0x9b4 <_gap_verify_graph+0x950>
     fe0:      	sub	w8, w13, #0x10
     fe4:      	cmp	w2, #0xc
     fe8:      	mov	w9, #0x70               ; =112
     fec:      	ccmp	w8, w9, #0x2, lo
     ff0:      	b.hs	0x3acc <_gap_verify_graph+0x3a68>
     ff4:      	ldr	x9, [sp]
     ff8:      	lsr	w8, w13, #4
     ffc:      	mov	w10, #0x1               ; =1
    1000:      	lsr	w9, w9, #4
    1004:      	sub	w8, w8, #0x1
    1008:      	lsl	w8, w10, w8
    100c:      	sub	w9, w9, #0x1
    1010:      	lsl	w9, w10, w9
    1014:      	cmp	w8, w9
    1018:      	b.ne	0x3acc <_gap_verify_graph+0x3a68>
    101c:      	mov	w0, w2
    1020:      	bl	0x1020 <_gap_verify_graph+0xfbc>
		0000000000001020:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    1024:      	mov	w21, w0
    1028:      	mov	w0, w28
    102c:      	bl	0x102c <_gap_verify_graph+0xfc8>
		000000000000102c:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    1030:      	cmp	w21, w0
    1034:      	b.ne	0x2c04 <_gap_verify_graph+0x2ba0>
    1038:      	ldr	x4, [sp, #0x50]
    103c:      	ldr	x0, [sp]
    1040:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001040:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1044:      	add	x16, x16, #0x0
		0000000000001044:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1048:      	str	wzr, [sp, #0xa0]
    104c:      	mov	x26, x27
    1050:      	b	0x3860 <_gap_verify_graph+0x37fc>
    1054:      	and	w8, w25, #0xff
    1058:      	sub	w8, w8, #0x41
    105c:      	cmp	w8, #0x37
    1060:      	b.hi	0x11dc <_gap_verify_graph+0x1178>
    1064:      	mov	x9, #0xc0c1             ; =49345
    1068:      	movk	x9, #0x80, lsl #48
    106c:      	lsr	x8, x9, x8
    1070:      	tbz	w8, #0x0, 0x11dc <_gap_verify_graph+0x1178>
    1074:      	and	x8, x1, #0xfe
    1078:      	cmp	x8, #0x3a
    107c:      	b.eq	0x126c <_gap_verify_graph+0x1208>
    1080:      	and	w8, w25, #0xff
    1084:      	sub	w8, w8, #0x1a
    1088:      	cmp	w8, #0x2e
    108c:      	b.hi	0x12f4 <_gap_verify_graph+0x1290>
    1090:      	mov	w9, #0x1f               ; =31
    1094:      	movk	w9, #0xff0, lsl #16
    1098:      	lsr	x9, x9, x8
    109c:      	tbnz	w9, #0x0, 0x126c <_gap_verify_graph+0x1208>
    10a0:      	mov	x9, #0x408000000000     ; =70918499991552
    10a4:      	lsr	x8, x9, x8
    10a8:      	tbnz	w8, #0x0, 0x1300 <_gap_verify_graph+0x129c>
    10ac:      	b	0x12f4 <_gap_verify_graph+0x1290>
    10b0:      	ldr	x8, [x19, #0x30]
    10b4:      	ldr	x9, [x19, #0x58]
    10b8:      	cmp	x8, x9
    10bc:      	b.ne	0x1170 <_gap_verify_graph+0x110c>
    10c0:      	sxtw	x9, w20
    10c4:      	cmn	x8, x9
    10c8:      	b.lt	0x1170 <_gap_verify_graph+0x110c>
    10cc:      	ldr	x8, [x19, #0x50]
    10d0:      	mvn	x9, x9
    10d4:      	ldr	w8, [x8, x9, lsl #2]
    10d8:      	cmp	w8, #0x0
    10dc:      	b.le	0x1170 <_gap_verify_graph+0x110c>
    10e0:      	mvn	w8, w20
    10e4:      	ldr	x9, [x19, #0x28]
    10e8:      	and	x8, x8, #0x7fffffff
    10ec:      	add	x11, x9, x8, lsl #4
    10f0:      	cmp	w20, #0x1
    10f4:      	ldr	x10, [x11]
    10f8:      	and	w12, w10, #0xff
    10fc:      	b.ge	0xbd4 <_gap_verify_graph+0xb70>
    1100:      	mov	w8, #0x20               ; =32
    1104:      	lsr	x9, x10, #32
    1108:      	cmp	w9, #0x1
    110c:      	b.lt	0x1178 <_gap_verify_graph+0x1114>
    1110:      	ldr	x13, [x19, #0x8]
    1114:      	cmp	x13, x9
    1118:      	b.le	0x1178 <_gap_verify_graph+0x1114>
    111c:      	ldr	x13, [x19, #0x80]
    1120:      	cmp	x13, x9
    1124:      	b.le	0x1178 <_gap_verify_graph+0x1114>
    1128:      	ldr	x13, [x19, #0x78]
    112c:      	ldr	w13, [x13, x9, lsl #2]
    1130:      	tbnz	w13, #0x1f, 0x1434 <_gap_verify_graph+0x13d0>
    1134:      	ldr	x13, [x19]
    1138:      	lsl	x9, x9, #4
    113c:      	ldr	x9, [x13, x9]
    1140:      	and	w13, w9, #0xff
    1144:      	sub	w13, w13, #0x4f
    1148:      	cmp	w13, #0x33
    114c:      	b.hi	0x1434 <_gap_verify_graph+0x13d0>
    1150:      	and	x9, x9, #0xff
    1154:      	adrp	x13, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001154:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    1158:      	add	x13, x13, #0x0
		0000000000001158:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    115c:      	ldrb	w9, [x13, x9]
    1160:      	tst	w9, #0x4
    1164:      	mov	w9, #0x16               ; =22
    1168:      	csel	x8, x8, x9, eq
    116c:      	b	0x1438 <_gap_verify_graph+0x13d4>
    1170:      	mov	w8, #0x1a               ; =26
    1174:      	b	0x1750 <_gap_verify_graph+0x16ec>
    1178:      	mov	w8, #0x16               ; =22
    117c:      	ubfx	w9, w10, #8, #8
    1180:      	cmp	w12, #0x82
    1184:      	b.ne	0x1448 <_gap_verify_graph+0x13e4>
    1188:      	cbz	w9, 0x1748 <_gap_verify_graph+0x16e4>
    118c:      	mov	w8, #0x19               ; =25
    1190:      	b	0x1750 <_gap_verify_graph+0x16ec>
    1194:      	adrp	x21, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001194:  ARM64_RELOC_PAGE21	l_str.681
    1198:      	add	x21, x21, #0x0
		0000000000001198:  ARM64_RELOC_PAGEOFF12	l_str.681
    119c:      	mov	w25, #0x25              ; =37
    11a0:      	b	0x9b4 <_gap_verify_graph+0x950>
    11a4:      	tbnz	x12, #0x3f, 0x1370 <_gap_verify_graph+0x130c>
    11a8:      	adrp	x8, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000011a8:  ARM64_RELOC_PAGE21	l_str.370
    11ac:      	add	x8, x8, #0x0
		00000000000011ac:  ARM64_RELOC_PAGEOFF12	l_str.370
    11b0:      	mov	w9, #0x17               ; =23
    11b4:      	b	0xc88 <_gap_verify_graph+0xc24>
    11b8:      	tbnz	x1, #0x3f, 0x13e8 <_gap_verify_graph+0x1384>
    11bc:      	adrp	x21, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000011bc:  ARM64_RELOC_PAGE21	l_str.667
    11c0:      	add	x21, x21, #0x0
		00000000000011c0:  ARM64_RELOC_PAGEOFF12	l_str.667
    11c4:      	mov	w25, #0x1b              ; =27
    11c8:      	b	0x9b4 <_gap_verify_graph+0x950>
    11cc:      	adrp	x21, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000011cc:  ARM64_RELOC_PAGE21	l_str.666
    11d0:      	add	x21, x21, #0x0
		00000000000011d0:  ARM64_RELOC_PAGEOFF12	l_str.666
    11d4:      	mov	w25, #0x2b              ; =43
    11d8:      	b	0x9b4 <_gap_verify_graph+0x950>
    11dc:      	and	w8, w25, #0xfe
    11e0:      	str	w30, [sp, #0x18]
    11e4:      	str	w8, [sp, #0xc]
    11e8:      	sub	w8, w11, #0x55
    11ec:      	cmp	w8, #0x4
    11f0:      	str	x1, [sp, #0x10]
    11f4:      	stp	x12, x17, [sp, #0x20]
    11f8:      	stp	x0, x10, [sp, #0x38]
    11fc:      	str	w15, [sp, #0x48]
    1200:      	str	x5, [sp, #0x30]
    1204:      	str	x4, [sp, #0x50]
    1208:      	b.lo	0x121c <_gap_verify_graph+0x11b8>
    120c:      	mov	x0, x19
    1210:      	mov	w1, w20
    1214:      	bl	0x1214 <_gap_verify_graph+0x11b0>
		0000000000001214:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    1218:      	cbz	w0, 0x2cf0 <_gap_verify_graph+0x2c8c>
    121c:      	ldp	x5, x0, [sp, #0x30]
    1220:      	and	w8, w25, #0xff
    1224:      	ldp	x12, x17, [sp, #0x20]
    1228:      	cmp	w8, #0x39
    122c:      	ldr	x4, [sp, #0x50]
    1230:      	ldr	w15, [sp, #0x48]
    1234:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001234:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1238:      	add	x16, x16, #0x0
		0000000000001238:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    123c:      	ldr	x10, [sp, #0x40]
    1240:      	ldr	x1, [sp, #0x10]
    1244:      	ldr	w30, [sp, #0x18]
    1248:      	ldr	w14, [sp, #0xc]
    124c:      	and	w11, w25, #0xff
    1250:      	b.hi	0x1074 <_gap_verify_graph+0x1010>
    1254:      	mov	x9, #0x80000000         ; =2147483648
    1258:      	and	x8, x1, #0xff
    125c:      	movk	x9, #0x2001, lsl #32
    1260:      	movk	x9, #0x3c0, lsl #48
    1264:      	lsr	x8, x9, x8
    1268:      	tbz	w8, #0x0, 0x1074 <_gap_verify_graph+0x1010>
    126c:      	and	w8, w21, #0xf0
    1270:      	sub	w9, w30, #0x1
    1274:      	sub	w8, w8, #0x10
    1278:      	cmp	w9, #0xd
    127c:      	mov	w9, #0x70               ; =112
    1280:      	ccmp	w8, w9, #0x2, lo
    1284:      	b.hs	0x12e0 <_gap_verify_graph+0x127c>
    1288:      	and	w8, w25, #0xff
    128c:      	mov	x6, x1
    1290:      	mov	x3, x25
    1294:      	cmp	w8, #0x39
    1298:      	b.hi	0x2c5c <_gap_verify_graph+0x2bf8>
    129c:      	mov	x9, #0x80000000         ; =2147483648
    12a0:      	and	x8, x6, #0xff
    12a4:      	movk	x9, #0x2001, lsl #32
    12a8:      	movk	x9, #0x3c0, lsl #48
    12ac:      	lsr	x8, x9, x8
    12b0:      	tbz	w8, #0x0, 0x2c5c <_gap_verify_graph+0x2bf8>
    12b4:      	mov	x1, x3
    12b8:      	sub	w8, w1, #0x1f
    12bc:      	and	w9, w8, #0xff
    12c0:      	cmp	w9, #0x1b
    12c4:      	b.hs	0x1318 <_gap_verify_graph+0x12b4>
    12c8:      	mov	w9, #0x4003             ; =16387
    12cc:      	movk	w9, #0x780, lsl #16
    12d0:      	lsr	w8, w9, w8
    12d4:      	tbz	w8, #0x0, 0x1318 <_gap_verify_graph+0x12b4>
    12d8:      	mov	w8, #0x1                ; =1
    12dc:      	b	0x1340 <_gap_verify_graph+0x12dc>
    12e0:      	and	w8, w25, #0xff
    12e4:      	cmp	w8, #0x41
    12e8:      	b.eq	0x1300 <_gap_verify_graph+0x129c>
    12ec:      	cmp	w8, #0x48
    12f0:      	b.eq	0x1300 <_gap_verify_graph+0x129c>
    12f4:      	sub	w8, w11, #0x55
    12f8:      	cmp	w8, #0x3
    12fc:      	b.hi	0x1584 <_gap_verify_graph+0x1520>
    1300:      	add	x0, sp, #0xa0
    1304:      	mov	x1, x19
    1308:      	mov	w2, w20
    130c:      	str	x4, [sp, #0x50]
    1310:      	bl	0x1310 <_gap_verify_graph+0x12ac>
		0000000000001310:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1314:      	b	0xd18 <_gap_verify_graph+0xcb4>
    1318:      	and	w8, w1, #0xff
    131c:      	cmp	w8, #0x1d
    1320:      	b.ne	0x1334 <_gap_verify_graph+0x12d0>
    1324:      	and	w11, w1, #0xff
    1328:      	cmp	w27, #0x3
    132c:      	b.eq	0x1358 <_gap_verify_graph+0x12f4>
    1330:      	b	0x1360 <_gap_verify_graph+0x12fc>
    1334:      	cmp	w8, #0x1e
    1338:      	mov	w8, #0x2                ; =2
    133c:      	cinc	w8, w8, eq
    1340:      	cmp	w27, w8
    1344:      	b.ne	0x1360 <_gap_verify_graph+0x12fc>
    1348:      	and	w9, w1, #0xff
    134c:      	cmp	w9, #0x1d
    1350:      	b.ne	0x2a34 <_gap_verify_graph+0x29d0>
    1354:      	and	w11, w1, #0xff
    1358:      	lsr	x8, x10, #32
    135c:      	b	0x2a44 <_gap_verify_graph+0x29e0>
    1360:      	adrp	x21, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001360:  ARM64_RELOC_PAGE21	l_str.661
    1364:      	add	x21, x21, #0x0
		0000000000001364:  ARM64_RELOC_PAGEOFF12	l_str.661
    1368:      	mov	w25, #0x2b              ; =43
    136c:      	b	0x9b4 <_gap_verify_graph+0x950>
    1370:      	ldr	x8, [x19, #0x30]
    1374:      	ldr	x9, [x19, #0x58]
    1378:      	cmp	x8, x9
    137c:      	b.ne	0x1590 <_gap_verify_graph+0x152c>
    1380:      	asr	x9, x12, #32
    1384:      	cmn	x8, x9
    1388:      	b.lt	0x1590 <_gap_verify_graph+0x152c>
    138c:      	ldr	x8, [x19, #0x50]
    1390:      	mvn	x9, x9
    1394:      	ldr	w8, [x8, x9, lsl #2]
    1398:      	cmp	w8, #0x0
    139c:      	b.le	0x1590 <_gap_verify_graph+0x152c>
    13a0:      	ldr	x8, [x19, #0x28]
    13a4:      	eor	x9, x2, #0xffffffff
    13a8:      	add	x8, x8, x9, lsl #4
    13ac:      	ldr	x8, [x8]
    13b0:      	and	w9, w8, #0xff
    13b4:      	sub	w9, w9, #0x29
    13b8:      	cmp	w9, #0x2
    13bc:      	b.ls	0xb44 <_gap_verify_graph+0xae0>
    13c0:      	and	x9, x8, #0xfe00
    13c4:      	and	x8, x8, #0xff00
    13c8:      	cmp	x9, #0xdff
    13cc:      	ccmp	x8, #0x0, #0x4, ls
    13d0:      	b.ne	0x2cb8 <_gap_verify_graph+0x2c54>
    13d4:      	adrp	x8, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000013d4:  ARM64_RELOC_PAGE21	l_str.371
    13d8:      	add	x8, x8, #0x0
		00000000000013d8:  ARM64_RELOC_PAGEOFF12	l_str.371
    13dc:      	mov	w9, #0x20               ; =32
    13e0:      	mov	w27, #0x1e              ; =30
    13e4:      	b	0xc88 <_gap_verify_graph+0xc24>
    13e8:      	ldr	x8, [x19, #0x30]
    13ec:      	ldr	x9, [x19, #0x58]
    13f0:      	stp	x0, x10, [sp, #0x38]
    13f4:      	stp	x17, x5, [sp, #0x28]
    13f8:      	cmp	x8, x9
    13fc:      	str	w15, [sp, #0x48]
    1400:      	str	x4, [sp, #0x50]
    1404:      	b.ne	0x15a4 <_gap_verify_graph+0x1540>
    1408:      	asr	x9, x1, #32
    140c:      	cmn	x8, x9
    1410:      	b.lt	0x15a4 <_gap_verify_graph+0x1540>
    1414:      	ldr	x8, [x19, #0x50]
    1418:      	mvn	x9, x9
    141c:      	ldr	w8, [x8, x9, lsl #2]
    1420:      	cmp	w8, #0x0
    1424:      	b.le	0x15a4 <_gap_verify_graph+0x1540>
    1428:      	ldr	x8, [x19, #0x28]
    142c:      	eor	x9, x12, #0xffffffff
    1430:      	b	0xdc0 <_gap_verify_graph+0xd5c>
    1434:      	mov	w8, #0x16               ; =22
    1438:      	mov	w27, #0x1e              ; =30
    143c:      	ubfx	w9, w10, #8, #8
    1440:      	cmp	w12, #0x82
    1444:      	b.eq	0x1188 <_gap_verify_graph+0x1124>
    1448:      	ldr	x11, [x11, #0x8]
    144c:      	cmp	w11, #0x1
    1450:      	b.lt	0x14d4 <_gap_verify_graph+0x1470>
    1454:      	ldr	x14, [x19, #0x8]
    1458:      	and	x13, x11, #0x7fffffff
    145c:      	cmp	x14, x13
    1460:      	b.le	0x1528 <_gap_verify_graph+0x14c4>
    1464:      	ldr	x14, [x19, #0x80]
    1468:      	cmp	x14, x13
    146c:      	b.le	0x1528 <_gap_verify_graph+0x14c4>
    1470:      	ldr	x14, [x19, #0x78]
    1474:      	ldr	w14, [x14, x13, lsl #2]
    1478:      	tbnz	w14, #0x1f, 0x1528 <_gap_verify_graph+0x14c4>
    147c:      	ldr	x14, [x19]
    1480:      	add	x13, x14, x13, lsl #4
    1484:      	ldr	x13, [x13]
    1488:      	and	x14, x13, #0xff00
    148c:      	cmp	x14, #0x600
    1490:      	b.ne	0x1528 <_gap_verify_graph+0x14c4>
    1494:      	and	w13, w13, #0xff
    1498:      	mov	w14, #0x46              ; =70
    149c:      	cmp	w13, #0x48
    14a0:      	ccmp	w13, w14, #0x4, ne
    14a4:      	mov	w13, #0x1b              ; =27
    14a8:      	csel	x8, x8, x13, ne
    14ac:      	cmp	w12, #0x7f
    14b0:      	b.eq	0x1534 <_gap_verify_graph+0x14d0>
    14b4:      	sub	w13, w9, #0x6
    14b8:      	cmn	w13, #0x4
    14bc:      	mov	w13, #0x25              ; =37
    14c0:      	csel	x8, x13, x8, lo
    14c4:      	cmp	w12, #0x7e
    14c8:      	b.eq	0x1744 <_gap_verify_graph+0x16e0>
    14cc:      	lsr	x12, x11, #32
    14d0:      	b	0x1614 <_gap_verify_graph+0x15b0>
    14d4:      	tbz	w11, #0x1f, 0x1528 <_gap_verify_graph+0x14c4>
    14d8:      	ldr	x13, [x19, #0x30]
    14dc:      	ldr	x14, [x19, #0x58]
    14e0:      	cmp	x13, x14
    14e4:      	b.ne	0x1528 <_gap_verify_graph+0x14c4>
    14e8:      	sxtw	x14, w11
    14ec:      	cmn	x13, x14
    14f0:      	b.lt	0x1528 <_gap_verify_graph+0x14c4>
    14f4:      	ldr	x13, [x19, #0x50]
    14f8:      	mvn	x14, x14
    14fc:      	ldr	w13, [x13, x14, lsl #2]
    1500:      	cmp	w13, #0x0
    1504:      	b.le	0x1528 <_gap_verify_graph+0x14c4>
    1508:      	mvn	w13, w11
    150c:      	ldr	x14, [x19, #0x28]
    1510:      	and	x13, x13, #0x7fffffff
    1514:      	add	x13, x14, x13, lsl #4
    1518:      	ldr	x13, [x13]
    151c:      	and	x14, x13, #0xff00
    1520:      	cmp	x14, #0x600
    1524:      	b.eq	0x1494 <_gap_verify_graph+0x1430>
    1528:      	mov	w8, #0x1b               ; =27
    152c:      	cmp	w12, #0x7f
    1530:      	b.ne	0x14b4 <_gap_verify_graph+0x1450>
    1534:      	lsr	x12, x11, #32
    1538:      	cmp	w9, #0x0
    153c:      	mov	w13, #0x19              ; =25
    1540:      	csel	x8, x8, x13, eq
    1544:      	cmp	w12, #0x1
    1548:      	b.lt	0x15bc <_gap_verify_graph+0x1558>
    154c:      	ldr	x13, [x19, #0x8]
    1550:      	cmp	x13, x12
    1554:      	b.le	0x1600 <_gap_verify_graph+0x159c>
    1558:      	ldr	x13, [x19, #0x80]
    155c:      	cmp	x13, x12
    1560:      	b.le	0x1600 <_gap_verify_graph+0x159c>
    1564:      	ldr	x13, [x19, #0x78]
    1568:      	ldr	w13, [x13, x12, lsl #2]
    156c:      	tbnz	w13, #0x1f, 0x1600 <_gap_verify_graph+0x159c>
    1570:      	ldr	x9, [x19]
    1574:      	add	x9, x9, x12, lsl #4
    1578:      	ldr	w9, [x9]
    157c:      	ubfx	w9, w9, #8, #8
    1580:      	b	0x1604 <_gap_verify_graph+0x15a0>
    1584:      	mov	w0, wzr
    1588:      	str	wzr, [sp, #0xa0]
    158c:      	b	0x3860 <_gap_verify_graph+0x37fc>
    1590:      	adrp	x8, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001590:  ARM64_RELOC_PAGE21	l_str.370
    1594:      	add	x8, x8, #0x0
		0000000000001594:  ARM64_RELOC_PAGEOFF12	l_str.370
    1598:      	mov	w9, #0x17               ; =23
    159c:      	mov	w27, #0x1e              ; =30
    15a0:      	b	0xc88 <_gap_verify_graph+0xc24>
    15a4:      	adrp	x21, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000015a4:  ARM64_RELOC_PAGE21	l_str.667
    15a8:      	add	x21, x21, #0x0
		00000000000015a8:  ARM64_RELOC_PAGEOFF12	l_str.667
    15ac:      	mov	w25, #0x1b              ; =27
    15b0:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    15b4:      	mov	w25, #0x1b              ; =27
    15b8:      	b	0x9b4 <_gap_verify_graph+0x950>
    15bc:      	tbz	x11, #0x3f, 0x1600 <_gap_verify_graph+0x159c>
    15c0:      	ldr	x13, [x19, #0x30]
    15c4:      	ldr	x14, [x19, #0x58]
    15c8:      	cmp	x13, x14
    15cc:      	b.ne	0x1600 <_gap_verify_graph+0x159c>
    15d0:      	asr	x14, x11, #32
    15d4:      	cmn	x13, x14
    15d8:      	b.lt	0x1600 <_gap_verify_graph+0x159c>
    15dc:      	ldr	x13, [x19, #0x50]
    15e0:      	mvn	x14, x14
    15e4:      	ldr	w13, [x13, x14, lsl #2]
    15e8:      	cmp	w13, #0x0
    15ec:      	b.le	0x1600 <_gap_verify_graph+0x159c>
    15f0:      	ldr	x9, [x19, #0x28]
    15f4:      	eor	x13, x12, #0xffffffff
    15f8:      	add	x9, x9, x13, lsl #4
    15fc:      	b	0x1578 <_gap_verify_graph+0x1514>
    1600:      	mov	w8, #0x1a               ; =26
    1604:      	sub	w13, w9, #0x6
    1608:      	cmn	w13, #0x4
    160c:      	mov	w13, #0x25              ; =37
    1610:      	csel	x8, x13, x8, lo
    1614:      	cmp	w12, #0x1
    1618:      	b.lt	0x1684 <_gap_verify_graph+0x1620>
    161c:      	ldr	x11, [x19, #0x8]
    1620:      	cmp	x11, x12
    1624:      	b.le	0x16d4 <_gap_verify_graph+0x1670>
    1628:      	ldr	x11, [x19, #0x80]
    162c:      	cmp	x11, x12
    1630:      	b.le	0x16d4 <_gap_verify_graph+0x1670>
    1634:      	ldr	x11, [x19, #0x78]
    1638:      	ldr	w11, [x11, x12, lsl #2]
    163c:      	tbnz	w11, #0x1f, 0x16d4 <_gap_verify_graph+0x1670>
    1640:      	ldr	x11, [x19]
    1644:      	add	x11, x11, x12, lsl #4
    1648:      	ldr	x11, [x11]
    164c:      	lsr	w12, w11, #8
    1650:      	cmp	w9, w12, uxtb
    1654:      	b.ne	0x16d4 <_gap_verify_graph+0x1670>
    1658:      	and	w11, w11, #0xff
    165c:      	mov	w12, #0x46              ; =70
    1660:      	cmp	w11, #0x48
    1664:      	ccmp	w11, w12, #0x4, ne
    1668:      	mov	w11, #0x22              ; =34
    166c:      	csel	x8, x11, x8, eq
    1670:      	and	w10, w10, #0xff
    1674:      	cmp	w10, #0x80
    1678:      	b.ne	0x16e4 <_gap_verify_graph+0x1680>
    167c:      	mov	w10, #0x1               ; =1
    1680:      	b	0x16f0 <_gap_verify_graph+0x168c>
    1684:      	tbz	x11, #0x3f, 0x16d4 <_gap_verify_graph+0x1670>
    1688:      	ldr	x13, [x19, #0x30]
    168c:      	ldr	x14, [x19, #0x58]
    1690:      	cmp	x13, x14
    1694:      	b.ne	0x16d4 <_gap_verify_graph+0x1670>
    1698:      	asr	x11, x11, #32
    169c:      	cmn	x13, x11
    16a0:      	b.lt	0x16d4 <_gap_verify_graph+0x1670>
    16a4:      	ldr	x13, [x19, #0x50]
    16a8:      	mvn	x11, x11
    16ac:      	ldr	w11, [x13, x11, lsl #2]
    16b0:      	cmp	w11, #0x0
    16b4:      	b.le	0x16d4 <_gap_verify_graph+0x1670>
    16b8:      	ldr	x11, [x19, #0x28]
    16bc:      	eor	x12, x12, #0xffffffff
    16c0:      	add	x11, x11, x12, lsl #4
    16c4:      	ldr	x11, [x11]
    16c8:      	lsr	w12, w11, #8
    16cc:      	cmp	w9, w12, uxtb
    16d0:      	b.eq	0x1658 <_gap_verify_graph+0x15f4>
    16d4:      	mov	w8, #0x22               ; =34
    16d8:      	and	w10, w10, #0xff
    16dc:      	cmp	w10, #0x80
    16e0:      	b.eq	0x167c <_gap_verify_graph+0x1618>
    16e4:      	cmp	w10, #0x81
    16e8:      	b.ne	0x1744 <_gap_verify_graph+0x16e0>
    16ec:      	mov	w10, wzr
    16f0:      	cmp	w20, #0x1
    16f4:      	b.lt	0x1724 <_gap_verify_graph+0x16c0>
    16f8:      	ldr	x12, [x19, #0x8]
    16fc:      	and	x11, x20, #0x7fffffff
    1700:      	cmp	x12, x11
    1704:      	b.le	0x1724 <_gap_verify_graph+0x16c0>
    1708:      	ldr	x12, [x19, #0x80]
    170c:      	cmp	x12, x11
    1710:      	b.le	0x1724 <_gap_verify_graph+0x16c0>
    1714:      	ldr	x12, [x19, #0x78]
    1718:      	ldr	w11, [x12, x11, lsl #2]
    171c:      	cmp	w11, #0x4
    1720:      	b.ge	0x2e2c <_gap_verify_graph+0x2dc8>
    1724:      	mov	x12, xzr
    1728:      	cbz	w12, 0x2e44 <_gap_verify_graph+0x2de0>
    172c:      	cbz	w10, 0x2afc <_gap_verify_graph+0x2a98>
    1730:      	cmp	w11, #0x9
    1734:      	mov	w27, #0x1e              ; =30
    1738:      	b.ls	0x1748 <_gap_verify_graph+0x16e4>
    173c:      	mov	w8, #0x1c               ; =28
    1740:      	b	0x1750 <_gap_verify_graph+0x16ec>
    1744:      	mov	w27, #0x1e              ; =30
    1748:      	cbnz	x8, 0x1750 <_gap_verify_graph+0x16ec>
    174c:      	mov	x8, x25
    1750:      	cmp	w24, #0x79
    1754:      	b.eq	0x1760 <_gap_verify_graph+0x16fc>
    1758:      	cmp	w24, #0x60
    175c:      	b.ne	0x18bc <_gap_verify_graph+0x1858>
    1760:      	cmp	w20, #0x1
    1764:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001764:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1768:      	add	x16, x16, #0x0
		0000000000001768:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    176c:      	b.lt	0x18cc <_gap_verify_graph+0x1868>
    1770:      	ldr	x9, [x19, #0x8]
    1774:      	and	x13, x20, #0x7fffffff
    1778:      	cmp	x9, x13
    177c:      	b.le	0x18ec <_gap_verify_graph+0x1888>
    1780:      	ldr	x10, [x19, #0x80]
    1784:      	cmp	x10, x13
    1788:      	b.le	0x18ec <_gap_verify_graph+0x1888>
    178c:      	ldr	x11, [x19, #0x78]
    1790:      	ldr	w16, [x11, x13, lsl #2]
    1794:      	tbnz	w16, #0x1f, 0x218c <_gap_verify_graph+0x2128>
    1798:      	ldr	x12, [x19]
    179c:      	add	x13, x12, x13, lsl #4
    17a0:      	ldp	x14, x13, [x13]
    17a4:      	and	w15, w14, #0xff
    17a8:      	cmp	w15, #0x79
    17ac:      	b.eq	0x17b8 <_gap_verify_graph+0x1754>
    17b0:      	cmp	w15, #0x60
    17b4:      	b.ne	0x219c <_gap_verify_graph+0x2138>
    17b8:      	cmp	w15, #0x60
    17bc:      	mov	w17, #0x3               ; =3
    17c0:      	and	x0, x14, #0xff00
    17c4:      	csinc	w17, w17, wzr, ne
    17c8:      	cbnz	x0, 0x219c <_gap_verify_graph+0x2138>
    17cc:      	cmp	w16, w17
    17d0:      	mov	w25, #0x1b              ; =27
    17d4:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000017d4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    17d8:      	add	x16, x16, #0x0
		00000000000017d8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    17dc:      	b.ne	0x18f0 <_gap_verify_graph+0x188c>
    17e0:      	cmp	w13, #0x0
    17e4:      	mov	w17, #0x79              ; =121
    17e8:      	ccmp	w15, w17, #0x0, ne
    17ec:      	b.eq	0x22ac <_gap_verify_graph+0x2248>
    17f0:      	lsr	x13, x13, #32
    17f4:      	cmp	w15, #0x79
    17f8:      	and	w15, w14, #0xff
    17fc:      	csel	w13, wzr, w13, ne
    1800:      	cmp	w15, #0x79
    1804:      	b.eq	0x1810 <_gap_verify_graph+0x17ac>
    1808:      	cmp	w15, #0x60
    180c:      	b.ne	0x2610 <_gap_verify_graph+0x25ac>
    1810:      	lsr	x15, x14, #32
    1814:      	cmp	w15, #0x1
    1818:      	b.lt	0x2618 <_gap_verify_graph+0x25b4>
    181c:      	cmp	x9, x15
    1820:      	b.ls	0x3298 <_gap_verify_graph+0x3234>
    1824:      	cmp	x10, x15
    1828:      	mov	w25, #0x1d              ; =29
    182c:      	b.ls	0x18f0 <_gap_verify_graph+0x188c>
    1830:      	ldr	w14, [x11, x15, lsl #2]
    1834:      	tbnz	w14, #0x1f, 0x3298 <_gap_verify_graph+0x3234>
    1838:      	lsl	x14, x15, #4
    183c:      	ldr	x14, [x12, x14]
    1840:      	and	w15, w14, #0xff
    1844:      	sub	w15, w15, #0x4f
    1848:      	cmp	w15, #0x33
    184c:      	b.hi	0x264c <_gap_verify_graph+0x25e8>
    1850:      	and	x14, x14, #0xff
    1854:      	adrp	x15, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001854:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    1858:      	add	x15, x15, #0x0
		0000000000001858:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    185c:      	ldrb	w14, [x15, x14]
    1860:      	tbnz	w14, #0x2, 0x264c <_gap_verify_graph+0x25e8>
    1864:      	mov	x14, x26
    1868:      	cbz	w13, 0x2d84 <_gap_verify_graph+0x2d20>
    186c:      	cmp	w13, #0x1
    1870:      	b.lt	0x2e00 <_gap_verify_graph+0x2d9c>
    1874:      	cmp	x9, x13
    1878:      	b.ls	0x2e1c <_gap_verify_graph+0x2db8>
    187c:      	cmp	x10, x13
    1880:      	mov	w25, #0x1d              ; =29
    1884:      	mov	x26, x14
    1888:      	mov	w27, #0x1e              ; =30
    188c:      	b.ls	0x18f0 <_gap_verify_graph+0x188c>
    1890:      	ldr	w9, [x11, x13, lsl #2]
    1894:      	tbnz	w9, #0x1f, 0x2e1c <_gap_verify_graph+0x2db8>
    1898:      	lsl	x9, x13, #4
    189c:      	mov	x25, x8
    18a0:      	mov	x26, x14
    18a4:      	mov	w27, #0x1e              ; =30
    18a8:      	ldrb	w9, [x12, x9]
    18ac:      	sub	w9, w9, #0x7a
    18b0:      	cmn	w9, #0x4
    18b4:      	b.ls	0x3290 <_gap_verify_graph+0x322c>
    18b8:      	b	0x18f0 <_gap_verify_graph+0x188c>
    18bc:      	mov	x25, x8
    18c0:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000018c0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    18c4:      	add	x16, x16, #0x0
		00000000000018c4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    18c8:      	b	0x18f0 <_gap_verify_graph+0x188c>
    18cc:      	tbz	w20, #0x1f, 0x18ec <_gap_verify_graph+0x1888>
    18d0:      	ldr	x8, [x19, #0x30]
    18d4:      	ldr	x9, [x19, #0x58]
    18d8:      	cmp	x8, x9
    18dc:      	b.ne	0x18ec <_gap_verify_graph+0x1888>
    18e0:      	sxtw	x9, w20
    18e4:      	cmn	x8, x9
    18e8:      	b.ge	0x2250 <_gap_verify_graph+0x21ec>
    18ec:      	mov	w25, #0x21              ; =33
    18f0:      	sub	w8, w24, #0x6d
    18f4:      	cmp	w8, #0x8
    18f8:      	b.hi	0x19e0 <_gap_verify_graph+0x197c>
    18fc:      	mov	w9, #0x107              ; =263
    1900:      	lsr	w8, w9, w8
    1904:      	tbz	w8, #0x0, 0x19e0 <_gap_verify_graph+0x197c>
    1908:      	cmp	w20, #0x1
    190c:      	b.lt	0x19a8 <_gap_verify_graph+0x1944>
    1910:      	ldr	x8, [x19, #0x8]
    1914:      	and	x12, x20, #0x7fffffff
    1918:      	cmp	x8, x12
    191c:      	b.le	0x19c8 <_gap_verify_graph+0x1964>
    1920:      	ldr	x11, [x19, #0x80]
    1924:      	cmp	x11, x12
    1928:      	b.le	0x19c8 <_gap_verify_graph+0x1964>
    192c:      	ldr	x9, [x19, #0x78]
    1930:      	ldr	w13, [x9, x12, lsl #2]
    1934:      	tbnz	w13, #0x1f, 0x19c8 <_gap_verify_graph+0x1964>
    1938:      	ldr	x10, [x19]
    193c:      	add	x14, x10, x12, lsl #4
    1940:      	ldr	x12, [x14]
    1944:      	and	w21, w12, #0xff
    1948:      	sub	w15, w21, #0x6d
    194c:      	cmp	w15, #0x8
    1950:      	b.hi	0x21c0 <_gap_verify_graph+0x215c>
    1954:      	mov	w16, #0x107             ; =263
    1958:      	lsr	w16, w16, w15
    195c:      	tbz	w16, #0x0, 0x21c0 <_gap_verify_graph+0x215c>
    1960:      	tst	x12, #0xff00
    1964:      	b.ne	0x21c0 <_gap_verify_graph+0x215c>
    1968:      	cmp	w15, #0x2
    196c:      	mov	w15, #0x2               ; =2
    1970:      	cinc	w15, w15, lo
    1974:      	cmp	w13, w15
    1978:      	b.ne	0x21c0 <_gap_verify_graph+0x215c>
    197c:      	ldr	x3, [x14, #0x8]
    1980:      	lsr	x2, x12, #32
    1984:      	cmp	w21, #0x75
    1988:      	b.ne	0x2550 <_gap_verify_graph+0x24ec>
    198c:      	add	x0, sp, #0x100
    1990:      	mov	x1, x19
    1994:      	bl	0x1994 <_gap_verify_graph+0x1930>
		0000000000001994:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    1998:      	ldr	w8, [sp, #0x100]
    199c:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		000000000000199c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    19a0:      	add	x16, x16, #0x0
		00000000000019a0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    19a4:      	b	0x26bc <_gap_verify_graph+0x2658>
    19a8:      	tbz	w20, #0x1f, 0x19c8 <_gap_verify_graph+0x1964>
    19ac:      	ldr	x8, [x19, #0x30]
    19b0:      	ldr	x9, [x19, #0x58]
    19b4:      	cmp	x8, x9
    19b8:      	b.ne	0x19c8 <_gap_verify_graph+0x1964>
    19bc:      	sxtw	x9, w20
    19c0:      	cmn	x8, x9
    19c4:      	b.ge	0x21ac <_gap_verify_graph+0x2148>
    19c8:      	adrp	x8, 0x1000 <_gap_verify_graph+0xf9c>
		00000000000019c8:  ARM64_RELOC_PAGE21	l_str.620
    19cc:      	add	x8, x8, #0x0
		00000000000019cc:  ARM64_RELOC_PAGEOFF12	l_str.620
    19d0:      	mov	w25, #0x1a              ; =26
    19d4:      	mov	w9, #0x1                ; =1
    19d8:      	stp	x8, x25, [sp, #0x108]
    19dc:      	str	w9, [sp, #0x100]
    19e0:      	sub	w8, w24, #0x51
    19e4:      	cmp	w8, #0x4
    19e8:      	b.lo	0x19f4 <_gap_verify_graph+0x1990>
    19ec:      	cmp	w24, #0x42
    19f0:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    19f4:      	cmp	w20, #0x1
    19f8:      	b.lt	0x1a58 <_gap_verify_graph+0x19f4>
    19fc:      	ldr	x27, [x19, #0x8]
    1a00:      	and	x9, x20, #0x7fffffff
    1a04:      	cmp	x27, x9
    1a08:      	b.le	0x1be4 <_gap_verify_graph+0x1b80>
    1a0c:      	ldr	x28, [x19, #0x80]
    1a10:      	cmp	x28, x9
    1a14:      	b.le	0x1be4 <_gap_verify_graph+0x1b80>
    1a18:      	ldr	x14, [x19, #0x78]
    1a1c:      	ldr	w8, [x14, x9, lsl #2]
    1a20:      	tbnz	w8, #0x1f, 0x1be4 <_gap_verify_graph+0x1b80>
    1a24:      	ldr	x13, [x19]
    1a28:      	add	x9, x13, x9, lsl #4
    1a2c:      	ldr	x21, [x9]
    1a30:      	and	w12, w21, #0xff
    1a34:      	cmp	w12, #0x42
    1a38:      	b.ne	0x1ac0 <_gap_verify_graph+0x1a5c>
    1a3c:      	and	x9, x21, #0xffff
    1a40:      	mov	w27, #0x1e              ; =30
    1a44:      	cmp	x9, #0x642
    1a48:      	ccmp	w8, #0x0, #0x0, eq
    1a4c:      	b.ne	0x2270 <_gap_verify_graph+0x220c>
    1a50:      	mov	x21, x25
    1a54:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    1a58:      	tbz	w20, #0x1f, 0x1ab4 <_gap_verify_graph+0x1a50>
    1a5c:      	ldr	x8, [x19, #0x30]
    1a60:      	ldr	x9, [x19, #0x58]
    1a64:      	cmp	x8, x9
    1a68:      	b.ne	0x1ab4 <_gap_verify_graph+0x1a50>
    1a6c:      	sxtw	x9, w20
    1a70:      	cmn	x8, x9
    1a74:      	b.lt	0x1ab4 <_gap_verify_graph+0x1a50>
    1a78:      	ldr	x8, [x19, #0x50]
    1a7c:      	mvn	x9, x9
    1a80:      	ldr	w8, [x8, x9, lsl #2]
    1a84:      	cmp	w8, #0x0
    1a88:      	b.le	0x1ab4 <_gap_verify_graph+0x1a50>
    1a8c:      	mvn	w8, w20
    1a90:      	ldr	x9, [x19, #0x28]
    1a94:      	and	x8, x8, #0x7fffffff
    1a98:      	lsl	x8, x8, #4
    1a9c:      	ldrb	w8, [x9, x8]
    1aa0:      	cmp	x8, #0x42
    1aa4:      	b.ne	0x1be4 <_gap_verify_graph+0x1b80>
    1aa8:      	mov	w8, #0x1e               ; =30
    1aac:      	mov	w21, #0x1e              ; =30
    1ab0:      	b	0x1bec <_gap_verify_graph+0x1b88>
    1ab4:      	mov	w8, #0x19               ; =25
    1ab8:      	mov	w21, #0x19              ; =25
    1abc:      	b	0x1bf0 <_gap_verify_graph+0x1b8c>
    1ac0:      	and	w10, w21, #0xff
    1ac4:      	ldr	x2, [x9, #0x8]
    1ac8:      	sub	w11, w10, #0x51
    1acc:      	cmp	w11, #0x4
    1ad0:      	b.lo	0x1adc <_gap_verify_graph+0x1a78>
    1ad4:      	cmp	w10, #0x42
    1ad8:      	b.ne	0x1be4 <_gap_verify_graph+0x1b80>
    1adc:      	subs	w17, w12, #0x53
    1ae0:      	mov	w9, #0x1                ; =1
    1ae4:      	mov	w10, #0x3               ; =3
    1ae8:      	cinc	w9, w9, ne
    1aec:      	cmp	w12, #0x51
    1af0:      	csel	w9, w10, w9, eq
    1af4:      	cmp	w8, w9
    1af8:      	b.ne	0x1be4 <_gap_verify_graph+0x1b80>
    1afc:      	lsr	x15, x21, #32
    1b00:      	tbnz	w21, #0x1f, 0x22d8 <_gap_verify_graph+0x2274>
    1b04:      	ubfx	w8, w21, #8, #8
    1b08:      	cmp	w17, #0x1
    1b0c:      	b.hi	0x25d4 <_gap_verify_graph+0x2570>
    1b10:      	cmp	w12, #0x53
    1b14:      	mov	w9, #0x6                ; =6
    1b18:      	csel	w9, w9, wzr, eq
    1b1c:      	cmp	w8, w9
    1b20:      	b.ne	0x26d8 <_gap_verify_graph+0x2674>
    1b24:      	cmp	w15, #0x1
    1b28:      	b.lt	0x27e0 <_gap_verify_graph+0x277c>
    1b2c:      	cmp	x27, x15
    1b30:      	mov	w8, #0x1                ; =1
    1b34:      	b.le	0x2920 <_gap_verify_graph+0x28bc>
    1b38:      	cmp	x28, x15
    1b3c:      	mov	w21, #0x1b              ; =27
    1b40:      	b.le	0x2ca4 <_gap_verify_graph+0x2c40>
    1b44:      	ldr	w8, [x14, x15, lsl #2]
    1b48:      	mov	x27, x26
    1b4c:      	tbnz	w8, #0x1f, 0x28cc <_gap_verify_graph+0x2868>
    1b50:      	lsl	x8, x15, #4
    1b54:      	ldr	x8, [x13, x8]
    1b58:      	and	w9, w8, #0xff
    1b5c:      	sub	w9, w9, #0x4f
    1b60:      	cmp	w9, #0x33
    1b64:      	b.hi	0x28cc <_gap_verify_graph+0x2868>
    1b68:      	and	x8, x8, #0xff
    1b6c:      	adrp	x9, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001b6c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    1b70:      	add	x9, x9, #0x0
		0000000000001b70:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    1b74:      	ldrb	w9, [x9, x8]
    1b78:      	ldr	x11, [sp, #0x68]
    1b7c:      	mov	w10, #0x1b              ; =27
    1b80:      	ands	w8, w9, #0x4
    1b84:      	lsr	w8, w8, #2
    1b88:      	csel	x21, x10, x11, ne
    1b8c:      	tbnz	w9, #0x2, 0x28d4 <_gap_verify_graph+0x2870>
    1b90:      	cmp	w12, #0x53
    1b94:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001b94:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1b98:      	add	x16, x16, #0x0
		0000000000001b98:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1b9c:      	mov	x26, x27
    1ba0:      	b.eq	0x2ca4 <_gap_verify_graph+0x2c40>
    1ba4:      	sub	x0, x29, #0x80
    1ba8:      	mov	x1, x19
    1bac:      	bl	0x1bac <_gap_verify_graph+0x1b48>
		0000000000001bac:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1bb0:      	ldur	w8, [x29, #-0x80]
    1bb4:      	cbz	w8, 0x28cc <_gap_verify_graph+0x2868>
    1bb8:      	ldur	w8, [x29, #-0x78]
    1bbc:      	ldr	x10, [sp, #0x68]
    1bc0:      	and	w9, w8, #0xff00
    1bc4:      	and	w8, w8, #0xff
    1bc8:      	cmp	w9, #0x600
    1bcc:      	mov	w9, #0x48               ; =72
    1bd0:      	ccmp	w8, w9, #0x4, eq
    1bd4:      	mov	w9, #0x29               ; =41
    1bd8:      	cset	w8, eq
    1bdc:      	csel	x21, x9, x10, eq
    1be0:      	b	0x28d4 <_gap_verify_graph+0x2870>
    1be4:      	mov	w8, #0x19               ; =25
    1be8:      	mov	w21, #0x19              ; =25
    1bec:      	mov	w27, #0x1e              ; =30
    1bf0:      	str	x8, [sp, #0x68]
    1bf4:      	cmp	w24, #0x41
    1bf8:      	b.eq	0x1c10 <_gap_verify_graph+0x1bac>
    1bfc:      	cmp	w24, #0x48
    1c00:      	b.eq	0x1c10 <_gap_verify_graph+0x1bac>
    1c04:      	sub	w8, w24, #0x55
    1c08:      	cmp	w8, #0x3
    1c0c:      	b.hi	0x1cd0 <_gap_verify_graph+0x1c6c>
    1c10:      	add	x0, sp, #0x118
    1c14:      	mov	x1, x19
    1c18:      	mov	w2, w20
    1c1c:      	bl	0x1c1c <_gap_verify_graph+0x1bb8>
		0000000000001c1c:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1c20:      	ldr	w8, [sp, #0x118]
    1c24:      	ldr	x9, [sp, #0x128]
    1c28:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001c28:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1c2c:      	add	x16, x16, #0x0
		0000000000001c2c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1c30:      	sub	x25, x29, #0x80
    1c34:      	cmp	w8, #0x1
    1c38:      	csel	x21, x9, x21, eq
    1c3c:      	ldr	w8, [sp, #0x9c]
    1c40:      	cbz	w8, 0x1cc0 <_gap_verify_graph+0x1c5c>
    1c44:      	cmp	w20, #0x1
    1c48:      	b.lt	0x3b68 <_gap_verify_graph+0x3b04>
    1c4c:      	ldr	x8, [x19, #0x8]
    1c50:      	and	x12, x20, #0x7fffffff
    1c54:      	cmp	x8, x12
    1c58:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    1c5c:      	ldr	x10, [x19, #0x80]
    1c60:      	cmp	x10, x12
    1c64:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    1c68:      	ldr	x9, [x19, #0x78]
    1c6c:      	ldr	w14, [x9, x12, lsl #2]
    1c70:      	tbnz	w14, #0x1f, 0x3b68 <_gap_verify_graph+0x3b04>
    1c74:      	ldr	x11, [x19]
    1c78:      	add	x12, x11, x12, lsl #4
    1c7c:      	ldp	x15, x12, [x12]
    1c80:      	and	w13, w15, #0xff
    1c84:      	sub	w2, w13, #0xe
    1c88:      	sub	w16, w13, #0x1f
    1c8c:      	cmp	w2, #0xc
    1c90:      	ccmp	w16, #0x2, #0x0, hs
    1c94:      	cset	w17, lo
    1c98:      	b.lo	0x1cb0 <_gap_verify_graph+0x1c4c>
    1c9c:      	cmp	w13, #0x1a
    1ca0:      	b.lo	0x3b68 <_gap_verify_graph+0x3b04>
    1ca4:      	cmp	w13, #0x3a
    1ca8:      	ccmp	w13, #0x1e, #0x0, ne
    1cac:      	b.hs	0x1cfc <_gap_verify_graph+0x1c98>
    1cb0:      	cmp	w16, #0x2
    1cb4:      	b.hs	0x1d04 <_gap_verify_graph+0x1ca0>
    1cb8:      	mov	w0, #0x1                ; =1
    1cbc:      	b	0x1d10 <_gap_verify_graph+0x1cac>
    1cc0:      	ldr	x14, [sp, #0x90]
    1cc4:      	mov	w1, #0x5                ; =5
    1cc8:      	tbz	w23, #0x0, 0x1fb4 <_gap_verify_graph+0x1f50>
    1ccc:      	b	0x4b4 <_gap_verify_graph+0x450>
    1cd0:      	sub	w8, w24, #0x21
    1cd4:      	sub	x25, x29, #0x80
    1cd8:      	cmp	w8, #0x6
    1cdc:      	b.hi	0x1f50 <_gap_verify_graph+0x1eec>
    1ce0:      	sub	x0, x29, #0xf0
    1ce4:      	mov	x1, x19
    1ce8:      	mov	w2, w20
    1cec:      	bl	0x1cec <_gap_verify_graph+0x1c88>
		0000000000001cec:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    1cf0:      	ldur	w8, [x29, #-0xf0]
    1cf4:      	ldur	x9, [x29, #-0xe0]
    1cf8:      	b	0x1f78 <_gap_verify_graph+0x1f14>
    1cfc:      	cmp	w13, #0x3b
    1d00:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    1d04:      	cmp	w13, #0x1d
    1d08:      	mov	w0, #0x2                ; =2
    1d0c:      	cinc	w0, w0, eq
    1d10:      	cmp	w14, w0
    1d14:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    1d18:      	lsr	x1, x15, #32
    1d1c:      	cmp	w1, #0x1
    1d20:      	b.lt	0x1d48 <_gap_verify_graph+0x1ce4>
    1d24:      	cmp	x8, x1
    1d28:      	mov	x0, #-0x1               ; =-1
    1d2c:      	b.ls	0x3b6c <_gap_verify_graph+0x3b08>
    1d30:      	cmp	x10, x1
    1d34:      	b.ls	0x3b6c <_gap_verify_graph+0x3b08>
    1d38:      	ldr	w14, [x9, x1, lsl #2]
    1d3c:      	tbnz	w14, #0x1f, 0x3b6c <_gap_verify_graph+0x3b08>
    1d40:      	add	x14, x11, x1, lsl #4
    1d44:      	b	0x1d88 <_gap_verify_graph+0x1d24>
    1d48:      	tbz	x15, #0x3f, 0x3b68 <_gap_verify_graph+0x3b04>
    1d4c:      	ldr	x14, [x19, #0x30]
    1d50:      	ldr	x0, [x19, #0x58]
    1d54:      	cmp	x14, x0
    1d58:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    1d5c:      	asr	x0, x15, #32
    1d60:      	cmn	x14, x0
    1d64:      	b.lt	0x3b68 <_gap_verify_graph+0x3b04>
    1d68:      	ldr	x14, [x19, #0x50]
    1d6c:      	mvn	x0, x0
    1d70:      	ldr	w14, [x14, x0, lsl #2]
    1d74:      	cmp	w14, #0x0
    1d78:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    1d7c:      	ldr	x14, [x19, #0x28]
    1d80:      	eor	x0, x1, #0xffffffff
    1d84:      	add	x14, x14, x0, lsl #4
    1d88:      	ldr	w0, [x14]
    1d8c:      	lsr	w3, w15, #8
    1d90:      	cmp	w2, #0xc
    1d94:      	ubfx	w14, w0, #8, #8
    1d98:      	csinc	w2, w14, wzr, hs
    1d9c:      	cmp	w2, w3, uxtb
    1da0:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    1da4:      	tbz	w17, #0x0, 0x1db8 <_gap_verify_graph+0x1d54>
    1da8:      	and	w15, w0, #0xfe00
    1dac:      	cmp	w15, #0xc00
    1db0:      	b.eq	0x1dd8 <_gap_verify_graph+0x1d74>
    1db4:      	b	0x1de0 <_gap_verify_graph+0x1d7c>
    1db8:      	and	w15, w15, #0xfe
    1dbc:      	cmp	w15, #0x3a
    1dc0:      	ccmp	w13, #0x1d, #0x0, ne
    1dc4:      	b.hi	0x1de0 <_gap_verify_graph+0x1d7c>
    1dc8:      	and	w15, w0, #0xfe00
    1dcc:      	mov	w2, #0x22               ; =34
    1dd0:      	cmp	w15, #0xc00
    1dd4:      	b.ne	0x1de4 <_gap_verify_graph+0x1d80>
    1dd8:      	mov	x2, xzr
    1ddc:      	b	0x1de4 <_gap_verify_graph+0x1d80>
    1de0:      	mov	w2, #0x22               ; =34
    1de4:      	cmp	w16, #0x2
    1de8:      	lsr	x15, x12, #32
    1dec:      	mov	x17, xzr
    1df0:      	csel	w16, w1, w12, lo
    1df4:      	cmp	x8, x10
    1df8:      	csel	x0, x8, x10, lo
    1dfc:      	stp	w1, w16, [x29, #-0x80]
    1e00:      	b	0x1e0c <_gap_verify_graph+0x1da8>
    1e04:      	mov	w2, #0x18               ; =24
    1e08:      	tbnz	w1, #0x1f, 0x1e70 <_gap_verify_graph+0x1e0c>
    1e0c:      	cmp	x17, #0x1
    1e10:      	mov	x16, x2
    1e14:      	b.gt	0x1e2c <_gap_verify_graph+0x1dc8>
    1e18:      	ldr	w1, [x25, x17, lsl #2]
    1e1c:      	add	x17, x17, #0x1
    1e20:      	mov	w2, #0x1                ; =1
    1e24:      	cbnz	w2, 0x1e38 <_gap_verify_graph+0x1dd4>
    1e28:      	b	0x1ec0 <_gap_verify_graph+0x1e5c>
    1e2c:      	mov	x2, xzr
    1e30:      	mov	w17, #0x2               ; =2
    1e34:      	cbz	w2, 0x1ec0 <_gap_verify_graph+0x1e5c>
    1e38:      	cmp	w1, #0x1
    1e3c:      	b.lt	0x1e04 <_gap_verify_graph+0x1da0>
    1e40:      	and	x1, x1, #0x7fffffff
    1e44:      	mov	w2, #0x18               ; =24
    1e48:      	cmp	x1, x0
    1e4c:      	b.ge	0x1e0c <_gap_verify_graph+0x1da8>
    1e50:      	ldr	w3, [x9, x1, lsl #2]
    1e54:      	mov	w2, #0x18               ; =24
    1e58:      	tbnz	w3, #0x1f, 0x1e0c <_gap_verify_graph+0x1da8>
    1e5c:      	add	x1, x11, x1, lsl #4
    1e60:      	ldrb	w1, [x1, #0x1]
    1e64:      	cmp	w1, w14
    1e68:      	csel	x2, x16, x27, eq
    1e6c:      	b	0x1e0c <_gap_verify_graph+0x1da8>
    1e70:      	ldr	x3, [x19, #0x30]
    1e74:      	ldr	x2, [x19, #0x58]
    1e78:      	cmp	x3, x2
    1e7c:      	mov	w2, #0x18               ; =24
    1e80:      	b.ne	0x1e0c <_gap_verify_graph+0x1da8>
    1e84:      	sxtw	x4, w1
    1e88:      	mov	w2, #0x18               ; =24
    1e8c:      	cmn	x3, x4
    1e90:      	b.lt	0x1e0c <_gap_verify_graph+0x1da8>
    1e94:      	ldr	x2, [x19, #0x50]
    1e98:      	mvn	x3, x4
    1e9c:      	ldr	w2, [x2, x3, lsl #2]
    1ea0:      	cmp	w2, #0x0
    1ea4:      	mov	w2, #0x18               ; =24
    1ea8:      	b.le	0x1e0c <_gap_verify_graph+0x1da8>
    1eac:      	mvn	w1, w1
    1eb0:      	ldr	x2, [x19, #0x28]
    1eb4:      	and	x1, x1, #0x7fffffff
    1eb8:      	add	x1, x2, x1, lsl #4
    1ebc:      	b	0x1e60 <_gap_verify_graph+0x1dfc>
    1ec0:      	cmp	x15, #0x0
    1ec4:      	ldr	x14, [sp, #0x90]
    1ec8:      	mov	w1, #0x5                ; =5
    1ecc:      	ccmp	w13, #0x1d, #0x0, ne
    1ed0:      	b.eq	0x1ef0 <_gap_verify_graph+0x1e8c>
    1ed4:      	cmp	x16, #0x0
    1ed8:      	csel	x8, x21, x16, eq
    1edc:      	mov	x21, x8
    1ee0:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001ee0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1ee4:      	add	x16, x16, #0x0
		0000000000001ee4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1ee8:      	tbz	w23, #0x0, 0x1fb4 <_gap_verify_graph+0x1f50>
    1eec:      	b	0x4b4 <_gap_verify_graph+0x450>
    1ef0:      	cmp	w15, #0x1
    1ef4:      	b.lt	0x1f84 <_gap_verify_graph+0x1f20>
    1ef8:      	cmp	x8, x15
    1efc:      	b.le	0x1fa0 <_gap_verify_graph+0x1f3c>
    1f00:      	cmp	x10, x15
    1f04:      	mov	w8, #0x16               ; =22
    1f08:      	b.le	0x1fa4 <_gap_verify_graph+0x1f40>
    1f0c:      	ldr	w8, [x9, x15, lsl #2]
    1f10:      	tbnz	w8, #0x1f, 0x1fa0 <_gap_verify_graph+0x1f3c>
    1f14:      	lsl	x8, x15, #4
    1f18:      	ldr	w8, [x11, x8]
    1f1c:      	and	w9, w8, #0xfe
    1f20:      	and	w8, w8, #0xff
    1f24:      	sub	w9, w9, #0x68
    1f28:      	sub	w8, w8, #0x65
    1f2c:      	cmp	w9, #0x9
    1f30:      	ccmp	w8, #0x1, #0x0, hi
    1f34:      	b.ls	0x1ed4 <_gap_verify_graph+0x1e70>
    1f38:      	mov	w8, #0x2d               ; =45
    1f3c:      	mov	x21, x8
    1f40:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001f40:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1f44:      	add	x16, x16, #0x0
		0000000000001f44:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1f48:      	tbz	w23, #0x0, 0x1fb4 <_gap_verify_graph+0x1f50>
    1f4c:      	b	0x4b4 <_gap_verify_graph+0x450>
    1f50:      	cmp	w24, #0x78
    1f54:      	b.eq	0x21d8 <_gap_verify_graph+0x2174>
    1f58:      	cmp	w24, #0x3c
    1f5c:      	b.ne	0x1c3c <_gap_verify_graph+0x1bd8>
    1f60:      	sub	x0, x29, #0xd8
    1f64:      	mov	x1, x19
    1f68:      	mov	w2, w20
    1f6c:      	bl	0x1f6c <_gap_verify_graph+0x1f08>
		0000000000001f6c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    1f70:      	ldur	w8, [x29, #-0xd8]
    1f74:      	ldur	x9, [x29, #-0xc8]
    1f78:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001f78:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1f7c:      	add	x16, x16, #0x0
		0000000000001f7c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1f80:      	b	0x1c34 <_gap_verify_graph+0x1bd0>
    1f84:      	ldr	x8, [x19, #0x30]
    1f88:      	ldr	x9, [x19, #0x58]
    1f8c:      	cmp	x8, x9
    1f90:      	b.ne	0x1fa0 <_gap_verify_graph+0x1f3c>
    1f94:      	asr	x9, x12, #32
    1f98:      	cmn	x8, x9
    1f9c:      	b.ge	0x227c <_gap_verify_graph+0x2218>
    1fa0:      	mov	w8, #0x16               ; =22
    1fa4:      	mov	x21, x8
    1fa8:      	adrp	x16, 0x1000 <_gap_verify_graph+0xf9c>
		0000000000001fa8:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    1fac:      	add	x16, x16, #0x0
		0000000000001fac:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    1fb0:      	tbnz	w23, #0x0, 0x4b4 <_gap_verify_graph+0x450>
    1fb4:      	ldr	w8, [sp, #0x9c]
    1fb8:      	cbnz	w8, 0x4b4 <_gap_verify_graph+0x450>
    1fbc:      	mov	x8, #0x80000000         ; =2147483648
    1fc0:      	ldr	w13, [sp, #0x8c]
    1fc4:      	movk	x8, #0x2001, lsl #32
    1fc8:      	movk	x8, #0x3c0, lsl #48
    1fcc:      	ldp	w9, w15, [sp, #0x84]
    1fd0:      	lsr	x8, x8, x14
    1fd4:      	and	w11, w9, w8
    1fd8:      	orr	w9, w13, w15
    1fdc:      	orr	w8, w9, w11
    1fe0:      	cbz	w8, 0x4b4 <_gap_verify_graph+0x450>
    1fe4:      	cmp	w20, #0x1
    1fe8:      	b.lt	0x202c <_gap_verify_graph+0x1fc8>
    1fec:      	ldr	x10, [x19, #0x8]
    1ff0:      	and	x8, x20, #0x7fffffff
    1ff4:      	cmp	x10, x8
    1ff8:      	b.le	0x202c <_gap_verify_graph+0x1fc8>
    1ffc:      	ldr	x10, [x19, #0x80]
    2000:      	cmp	x10, x8
    2004:      	b.le	0x202c <_gap_verify_graph+0x1fc8>
    2008:      	ldr	x10, [x19, #0x78]
    200c:      	ldr	w10, [x10, x8, lsl #2]
    2010:      	cmp	w10, #0x1
    2014:      	b.lt	0x202c <_gap_verify_graph+0x1fc8>
    2018:      	ldr	x10, [x19]
    201c:      	add	x8, x10, x8, lsl #4
    2020:      	mov	w10, #0x1               ; =1
    2024:      	ldr	w8, [x8, #0x4]
    2028:      	b	0x2030 <_gap_verify_graph+0x1fcc>
    202c:      	mov	x10, xzr
    2030:      	cbz	w10, 0x3b68 <_gap_verify_graph+0x3b04>
    2034:      	cmp	w8, #0x1
    2038:      	b.lt	0x206c <_gap_verify_graph+0x2008>
    203c:      	ldr	x10, [x19, #0x8]
    2040:      	and	x8, x8, #0x7fffffff
    2044:      	cmp	x10, x8
    2048:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    204c:      	ldr	x10, [x19, #0x80]
    2050:      	cmp	x10, x8
    2054:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    2058:      	ldr	x10, [x19, #0x78]
    205c:      	ldr	w10, [x10, x8, lsl #2]
    2060:      	tbnz	w10, #0x1f, 0x3b68 <_gap_verify_graph+0x3b04>
    2064:      	ldr	x10, [x19]
    2068:      	b	0x20ac <_gap_verify_graph+0x2048>
    206c:      	tbz	w8, #0x1f, 0x3b68 <_gap_verify_graph+0x3b04>
    2070:      	ldr	x10, [x19, #0x30]
    2074:      	ldr	x12, [x19, #0x58]
    2078:      	cmp	x10, x12
    207c:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    2080:      	sxtw	x12, w8
    2084:      	cmn	x10, x12
    2088:      	b.lt	0x3b68 <_gap_verify_graph+0x3b04>
    208c:      	ldr	x10, [x19, #0x50]
    2090:      	mvn	x12, x12
    2094:      	ldr	w10, [x10, x12, lsl #2]
    2098:      	cmp	w10, #0x0
    209c:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    20a0:      	ldr	x10, [x19, #0x28]
    20a4:      	mvn	w8, w8
    20a8:      	and	x8, x8, #0x7fffffff
    20ac:      	add	x8, x10, x8, lsl #4
    20b0:      	cbz	x8, 0x3b68 <_gap_verify_graph+0x3b04>
    20b4:      	ldr	w12, [x8]
    20b8:      	and	x10, x14, #0xff00
    20bc:      	cmp	x10, #0x600
    20c0:      	ubfx	w8, w12, #8, #8
    20c4:      	b.ne	0x20e0 <_gap_verify_graph+0x207c>
    20c8:      	cmp	w8, #0x6
    20cc:      	b.ne	0x20e0 <_gap_verify_graph+0x207c>
    20d0:      	and	w10, w14, #0xfe
    20d4:      	cmp	w10, #0x1a
    20d8:      	cset	w10, eq
    20dc:      	b	0x20f0 <_gap_verify_graph+0x208c>
    20e0:      	sub	w10, w8, #0x1
    20e4:      	cmp	w10, #0xa
    20e8:      	mov	w10, wzr
    20ec:      	b.hi	0x23e4 <_gap_verify_graph+0x2380>
    20f0:      	cbz	w11, 0x2128 <_gap_verify_graph+0x20c4>
    20f4:      	cmp	w24, #0x39
    20f8:      	b.hi	0x23e4 <_gap_verify_graph+0x2380>
    20fc:      	mov	x11, #0x80000000        ; =2147483648
    2100:      	movk	x11, #0x2001, lsl #32
    2104:      	movk	x11, #0x3c0, lsl #48
    2108:      	lsr	x11, x11, x24
    210c:      	tbz	w11, #0x0, 0x23e4 <_gap_verify_graph+0x2380>
    2110:      	cmp	w24, #0x2d
    2114:      	b.ne	0x2160 <_gap_verify_graph+0x20fc>
    2118:      	mov	w11, #0x1               ; =1
    211c:      	and	w12, w15, w11
    2120:      	tbnz	w12, #0x0, 0x212c <_gap_verify_graph+0x20c8>
    2124:      	b	0x2158 <_gap_verify_graph+0x20f4>
    2128:      	cbz	w15, 0x23e8 <_gap_verify_graph+0x2384>
    212c:      	ldr	w11, [sp, #0x7c]
    2130:      	cbz	w11, 0x23e4 <_gap_verify_graph+0x2380>
    2134:      	cmp	w24, #0x1f
    2138:      	b.hs	0x2230 <_gap_verify_graph+0x21cc>
    213c:      	cmp	w8, #0x1
    2140:      	b.ne	0x23e8 <_gap_verify_graph+0x2384>
    2144:      	cmp	w24, #0x3b
    2148:      	b.hi	0x23e4 <_gap_verify_graph+0x2380>
    214c:      	mov	x11, #0xc00000000000    ; =211106232532992
    2150:      	movk	x11, #0xc01, lsl #48
    2154:      	lsr	x11, x11, x24
    2158:      	tbnz	w11, #0x0, 0x23e8 <_gap_verify_graph+0x2384>
    215c:      	b	0x23e4 <_gap_verify_graph+0x2380>
    2160:      	cmp	w8, #0x1
    2164:      	b.eq	0x23e4 <_gap_verify_graph+0x2380>
    2168:      	cmp	w24, #0x36
    216c:      	b.eq	0x23c4 <_gap_verify_graph+0x2360>
    2170:      	cmp	w24, #0x20
    2174:      	b.eq	0x23b4 <_gap_verify_graph+0x2350>
    2178:      	cmp	w24, #0x1f
    217c:      	b.ne	0x2118 <_gap_verify_graph+0x20b4>
    2180:      	cmp	w8, #0x6
    2184:      	cset	w11, ne
    2188:      	b	0x211c <_gap_verify_graph+0x20b8>
    218c:      	mov	w25, #0x21              ; =33
    2190:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002190:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2194:      	add	x16, x16, #0x0
		0000000000002194:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2198:      	b	0x18f0 <_gap_verify_graph+0x188c>
    219c:      	mov	w25, #0x1b              ; =27
    21a0:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000021a0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    21a4:      	add	x16, x16, #0x0
		00000000000021a4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    21a8:      	b	0x18f0 <_gap_verify_graph+0x188c>
    21ac:      	ldr	x8, [x19, #0x50]
    21b0:      	mvn	x9, x9
    21b4:      	ldr	w8, [x8, x9, lsl #2]
    21b8:      	cmp	w8, #0x0
    21bc:      	b.le	0x22b4 <_gap_verify_graph+0x2250>
    21c0:      	adrp	x8, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000021c0:  ARM64_RELOC_PAGE21	l_str.621
    21c4:      	add	x8, x8, #0x0
		00000000000021c4:  ARM64_RELOC_PAGEOFF12	l_str.621
    21c8:      	mov	w25, #0x20              ; =32
    21cc:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000021cc:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    21d0:      	add	x16, x16, #0x0
		00000000000021d0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    21d4:      	b	0x19d4 <_gap_verify_graph+0x1970>
    21d8:      	ldr	x8, [sp, #0x90]
    21dc:      	ubfx	w8, w8, #8, #8
    21e0:      	cbz	w8, 0x22c4 <_gap_verify_graph+0x2260>
    21e4:      	ldr	x11, [sp, #0x70]
    21e8:      	cmp	w11, #0x1
    21ec:      	b.lt	0x2504 <_gap_verify_graph+0x24a0>
    21f0:      	ldr	x10, [x19, #0x8]
    21f4:      	and	x9, x11, #0x7fffffff
    21f8:      	cmp	x10, x9
    21fc:      	b.le	0x2548 <_gap_verify_graph+0x24e4>
    2200:      	ldr	x10, [x19, #0x80]
    2204:      	cmp	x10, x9
    2208:      	b.le	0x2548 <_gap_verify_graph+0x24e4>
    220c:      	ldr	x10, [x19, #0x78]
    2210:      	ldr	w10, [x10, x9, lsl #2]
    2214:      	tbnz	w10, #0x1f, 0x2548 <_gap_verify_graph+0x24e4>
    2218:      	ldr	x10, [x19]
    221c:      	add	x9, x10, x9, lsl #4
    2220:      	ldrb	w9, [x9, #0x1]
    2224:      	cmp	w9, w8
    2228:      	mov	w8, #0x1a               ; =26
    222c:      	b	0x22d0 <_gap_verify_graph+0x226c>
    2230:      	cmp	w24, #0x2e
    2234:      	b.lo	0x23e4 <_gap_verify_graph+0x2380>
    2238:      	and	w11, w14, #0xfe
    223c:      	cmp	w11, #0x3a
    2240:      	mov	w11, #0x35              ; =53
    2244:      	ccmp	w24, w11, #0x0, ne
    2248:      	b.ls	0x213c <_gap_verify_graph+0x20d8>
    224c:      	b	0x23e4 <_gap_verify_graph+0x2380>
    2250:      	ldr	x8, [x19, #0x50]
    2254:      	mvn	x9, x9
    2258:      	ldr	w8, [x8, x9, lsl #2]
    225c:      	mov	w9, #0x21               ; =33
    2260:      	cmp	w8, #0x0
    2264:      	mov	w8, #0x1b               ; =27
    2268:      	csel	x25, x8, x9, gt
    226c:      	b	0x18f0 <_gap_verify_graph+0x188c>
    2270:      	mov	w8, #0x1e               ; =30
    2274:      	mov	w21, #0x1e              ; =30
    2278:      	b	0x1bf0 <_gap_verify_graph+0x1b8c>
    227c:      	ldr	x8, [x19, #0x50]
    2280:      	mvn	x9, x9
    2284:      	ldr	w8, [x8, x9, lsl #2]
    2288:      	mov	w9, #0x2d               ; =45
    228c:      	cmp	w8, #0x0
    2290:      	mov	w8, #0x16               ; =22
    2294:      	csel	x8, x9, x8, gt
    2298:      	mov	x21, x8
    229c:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		000000000000229c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    22a0:      	add	x16, x16, #0x0
		00000000000022a0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    22a4:      	tbz	w23, #0x0, 0x1fb4 <_gap_verify_graph+0x1f50>
    22a8:      	b	0x4b4 <_gap_verify_graph+0x450>
    22ac:      	mov	w25, #0x1b              ; =27
    22b0:      	b	0x18f0 <_gap_verify_graph+0x188c>
    22b4:      	adrp	x8, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000022b4:  ARM64_RELOC_PAGE21	l_str.620
    22b8:      	add	x8, x8, #0x0
		00000000000022b8:  ARM64_RELOC_PAGEOFF12	l_str.620
    22bc:      	mov	w25, #0x1a              ; =26
    22c0:      	b	0x21cc <_gap_verify_graph+0x2168>
    22c4:      	ldr	x8, [sp, #0x70]
    22c8:      	cmp	w8, #0x0
    22cc:      	mov	w8, #0x1f               ; =31
    22d0:      	csel	x21, x21, x8, eq
    22d4:      	b	0x1c3c <_gap_verify_graph+0x1bd8>
    22d8:      	mov	w8, #-0xff01            ; =-65281
    22dc:      	mov	w9, #0x51               ; =81
    22e0:      	and	x8, x21, x8
    22e4:      	movk	w9, #0x8000, lsl #16
    22e8:      	cmp	x8, x9
    22ec:      	b.ne	0x28c0 <_gap_verify_graph+0x285c>
    22f0:      	cmp	x27, x28
    22f4:      	mov	w10, w15
    22f8:      	csel	x8, x27, x28, lo
    22fc:      	cmp	w10, #0x1
    2300:      	b.lt	0x2818 <_gap_verify_graph+0x27b4>
    2304:      	mov	w9, w10
    2308:      	cmp	x8, x9
    230c:      	b.ls	0x28c0 <_gap_verify_graph+0x285c>
    2310:      	ldr	w11, [x14, x9, lsl #2]
    2314:      	tbnz	w11, #0x1f, 0x28c0 <_gap_verify_graph+0x285c>
    2318:      	add	x11, x13, x9, lsl #4
    231c:      	ldrb	w12, [x11]
    2320:      	ldr	w9, [x11, #0x4]
    2324:      	cmp	w12, #0x68
    2328:      	b.eq	0x286c <_gap_verify_graph+0x2808>
    232c:      	cmp	w12, #0x51
    2330:      	b.ne	0x28c0 <_gap_verify_graph+0x285c>
    2334:      	cmp	w9, #0x1
    2338:      	b.lt	0x28c0 <_gap_verify_graph+0x285c>
    233c:      	cmp	w10, w9
    2340:      	b.ls	0x28c0 <_gap_verify_graph+0x285c>
    2344:      	ldr	x10, [x11, #0x8]
    2348:      	tbz	w10, #0x1f, 0x28c0 <_gap_verify_graph+0x285c>
    234c:      	ldr	x11, [x19, #0x30]
    2350:      	ldr	x12, [x19, #0x58]
    2354:      	cmp	x11, x12
    2358:      	b.ne	0x28c0 <_gap_verify_graph+0x285c>
    235c:      	sxtw	x12, w10
    2360:      	cmn	x11, x12
    2364:      	b.lt	0x28c0 <_gap_verify_graph+0x285c>
    2368:      	ldr	x11, [x19, #0x50]
    236c:      	mvn	x12, x12
    2370:      	ldr	w11, [x11, x12, lsl #2]
    2374:      	cmp	w11, #0x0
    2378:      	b.le	0x28c0 <_gap_verify_graph+0x285c>
    237c:      	mvn	w10, w10
    2380:      	ldr	x11, [x19, #0x28]
    2384:      	and	x10, x10, #0x7fffffff
    2388:      	lsl	x10, x10, #4
    238c:      	ldr	w11, [x11, x10]
    2390:      	mov	w10, w9
    2394:      	and	w12, w11, #0xff
    2398:      	cmp	w12, #0x49
    239c:      	b.eq	0x22fc <_gap_verify_graph+0x2298>
    23a0:      	ubfx	w10, w11, #8, #8
    23a4:      	cmp	w12, w10
    23a8:      	mov	w10, w9
    23ac:      	b.eq	0x22fc <_gap_verify_graph+0x2298>
    23b0:      	b	0x28c0 <_gap_verify_graph+0x285c>
    23b4:      	sub	w11, w8, #0x7
    23b8:      	cmp	w11, #0x5
    23bc:      	cset	w11, lo
    23c0:      	b	0x211c <_gap_verify_graph+0x20b8>
    23c4:      	lsr	w11, w12, #8
    23c8:      	sub	w11, w11, #0x3
    23cc:      	and	w12, w11, #0xff
    23d0:      	cmp	w12, #0x8
    23d4:      	b.hi	0x23e4 <_gap_verify_graph+0x2380>
    23d8:      	mov	w12, #0x1cf             ; =463
    23dc:      	lsr	w11, w12, w11
    23e0:      	tbnz	w11, #0x0, 0x2118 <_gap_verify_graph+0x20b4>
    23e4:      	mov	w21, #0x1c              ; =28
    23e8:      	cmp	w13, #0x0
    23ec:      	ldr	w12, [sp, #0x80]
    23f0:      	csinc	w11, w8, wzr, eq
    23f4:      	cmp	w11, w12, uxtb
    23f8:      	mov	w11, #0x26              ; =38
    23fc:      	csel	x21, x21, x11, eq
    2400:      	cbz	w9, 0x4b4 <_gap_verify_graph+0x450>
    2404:      	cmp	w20, #0x1
    2408:      	b.lt	0x2438 <_gap_verify_graph+0x23d4>
    240c:      	ldr	x11, [x19, #0x8]
    2410:      	and	x9, x20, #0x7fffffff
    2414:      	cmp	x11, x9
    2418:      	b.le	0x2438 <_gap_verify_graph+0x23d4>
    241c:      	ldr	x11, [x19, #0x80]
    2420:      	cmp	x11, x9
    2424:      	b.le	0x2438 <_gap_verify_graph+0x23d4>
    2428:      	ldr	x11, [x19, #0x78]
    242c:      	ldr	w11, [x11, x9, lsl #2]
    2430:      	cmp	w11, #0x2
    2434:      	b.ge	0x24ec <_gap_verify_graph+0x2488>
    2438:      	mov	x11, xzr
    243c:      	cbz	w11, 0x3b68 <_gap_verify_graph+0x3b04>
    2440:      	cmp	w9, #0x1
    2444:      	b.lt	0x2478 <_gap_verify_graph+0x2414>
    2448:      	ldr	x11, [x19, #0x8]
    244c:      	and	x9, x9, #0x7fffffff
    2450:      	cmp	x11, x9
    2454:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    2458:      	ldr	x11, [x19, #0x80]
    245c:      	cmp	x11, x9
    2460:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    2464:      	ldr	x11, [x19, #0x78]
    2468:      	ldr	w11, [x11, x9, lsl #2]
    246c:      	tbnz	w11, #0x1f, 0x3b68 <_gap_verify_graph+0x3b04>
    2470:      	ldr	x11, [x19]
    2474:      	b	0x24b8 <_gap_verify_graph+0x2454>
    2478:      	tbz	w9, #0x1f, 0x3b68 <_gap_verify_graph+0x3b04>
    247c:      	ldr	x11, [x19, #0x30]
    2480:      	ldr	x12, [x19, #0x58]
    2484:      	cmp	x11, x12
    2488:      	b.ne	0x3b68 <_gap_verify_graph+0x3b04>
    248c:      	sxtw	x12, w9
    2490:      	cmn	x11, x12
    2494:      	b.lt	0x3b68 <_gap_verify_graph+0x3b04>
    2498:      	ldr	x11, [x19, #0x50]
    249c:      	mvn	x12, x12
    24a0:      	ldr	w11, [x11, x12, lsl #2]
    24a4:      	cmp	w11, #0x0
    24a8:      	b.le	0x3b68 <_gap_verify_graph+0x3b04>
    24ac:      	ldr	x11, [x19, #0x28]
    24b0:      	mvn	w9, w9
    24b4:      	and	x9, x9, #0x7fffffff
    24b8:      	add	x9, x11, x9, lsl #4
    24bc:      	cbz	x9, 0x3b68 <_gap_verify_graph+0x3b04>
    24c0:      	ldr	w9, [x9]
    24c4:      	eor	w10, w10, #0x1
    24c8:      	ubfx	w9, w9, #8, #8
    24cc:      	cmp	w8, w9
    24d0:      	csinc	w10, w10, wzr, ne
    24d4:      	tbnz	w10, #0x0, 0x4ac <_gap_verify_graph+0x448>
    24d8:      	cmp	w9, #0x5
    24dc:      	b.eq	0x4b4 <_gap_verify_graph+0x450>
    24e0:      	cmp	w9, #0xb
    24e4:      	b.eq	0x4b4 <_gap_verify_graph+0x450>
    24e8:      	b	0x3b68 <_gap_verify_graph+0x3b04>
    24ec:      	ldr	x11, [x19]
    24f0:      	add	x9, x11, x9, lsl #4
    24f4:      	mov	w11, #0x1               ; =1
    24f8:      	ldr	w9, [x9, #0x8]
    24fc:      	cbnz	w11, 0x2440 <_gap_verify_graph+0x23dc>
    2500:      	b	0x3b68 <_gap_verify_graph+0x3b04>
    2504:      	tbz	w11, #0x1f, 0x2548 <_gap_verify_graph+0x24e4>
    2508:      	ldr	x9, [x19, #0x30]
    250c:      	ldr	x10, [x19, #0x58]
    2510:      	cmp	x9, x10
    2514:      	b.ne	0x2548 <_gap_verify_graph+0x24e4>
    2518:      	sxtw	x10, w11
    251c:      	cmn	x9, x10
    2520:      	b.lt	0x2548 <_gap_verify_graph+0x24e4>
    2524:      	ldr	x9, [x19, #0x50]
    2528:      	mvn	x10, x10
    252c:      	ldr	w9, [x9, x10, lsl #2]
    2530:      	cmp	w9, #0x0
    2534:      	b.le	0x2548 <_gap_verify_graph+0x24e4>
    2538:      	mvn	w9, w11
    253c:      	ldr	x10, [x19, #0x28]
    2540:      	and	x9, x9, #0x7fffffff
    2544:      	b	0x221c <_gap_verify_graph+0x21b8>
    2548:      	mov	w21, #0x14              ; =20
    254c:      	b	0x1c3c <_gap_verify_graph+0x1bd8>
    2550:      	cmp	w2, #0x1
    2554:      	b.lt	0x2654 <_gap_verify_graph+0x25f0>
    2558:      	cmp	x8, x2
    255c:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		000000000000255c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2560:      	add	x16, x16, #0x0
		0000000000002560:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2564:      	b.ls	0x26a4 <_gap_verify_graph+0x2640>
    2568:      	cmp	x11, x2
    256c:      	b.ls	0x26a4 <_gap_verify_graph+0x2640>
    2570:      	ldr	w8, [x9, x2, lsl #2]
    2574:      	tbnz	w8, #0x1f, 0x26a4 <_gap_verify_graph+0x2640>
    2578:      	add	x9, x10, x2, lsl #4
    257c:      	ldr	x10, [x9]
    2580:      	and	x11, x10, #0xffff
    2584:      	cmp	x11, #0x75
    2588:      	b.ne	0x2690 <_gap_verify_graph+0x262c>
    258c:      	sub	w11, w21, #0x70
    2590:      	cmn	w11, #0x3
    2594:      	ccmp	w8, #0x2, #0x0, hs
    2598:      	b.ne	0x2690 <_gap_verify_graph+0x262c>
    259c:      	str	x3, [sp, #0x50]
    25a0:      	ldr	x3, [x9, #0x8]
    25a4:      	lsr	x2, x10, #32
    25a8:      	sub	x0, x29, #0x98
    25ac:      	mov	x1, x19
    25b0:      	mov	x27, x26
    25b4:      	bl	0x25b4 <_gap_verify_graph+0x2550>
		00000000000025b4:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    25b8:      	ldur	w8, [x29, #-0x98]
    25bc:      	cmp	w8, #0x1
    25c0:      	b.ne	0x2d58 <_gap_verify_graph+0x2cf4>
    25c4:      	ldp	x9, x10, [x29, #-0x90]
    25c8:      	str	w8, [sp, #0x100]
    25cc:      	stp	x9, x10, [sp, #0x108]
    25d0:      	b	0x2d70 <_gap_verify_graph+0x2d0c>
    25d4:      	lsr	x9, x2, #32
    25d8:      	cmp	w12, #0x51
    25dc:      	b.ne	0x26f4 <_gap_verify_graph+0x2690>
    25e0:      	cmp	w8, #0x6
    25e4:      	b.ne	0x2704 <_gap_verify_graph+0x26a0>
    25e8:      	cbz	x9, 0x2720 <_gap_verify_graph+0x26bc>
    25ec:      	cmp	w9, #0x1
    25f0:      	mov	w8, #0x1                ; =1
    25f4:      	b.lt	0x2ca0 <_gap_verify_graph+0x2c3c>
    25f8:      	asr	x10, x2, #32
    25fc:      	mov	w21, #0x29              ; =41
    2600:      	sub	x11, x10, #0x1
    2604:      	and	x10, x10, x11
    2608:      	cbz	x10, 0x2720 <_gap_verify_graph+0x26bc>
    260c:      	b	0x2ca4 <_gap_verify_graph+0x2c40>
    2610:      	mov	w25, #0x25              ; =37
    2614:      	b	0x18f0 <_gap_verify_graph+0x188c>
    2618:      	tbz	x14, #0x3f, 0x3298 <_gap_verify_graph+0x3234>
    261c:      	ldr	x8, [x19, #0x30]
    2620:      	ldr	x9, [x19, #0x58]
    2624:      	cmp	x8, x9
    2628:      	b.ne	0x3298 <_gap_verify_graph+0x3234>
    262c:      	asr	x9, x14, #32
    2630:      	cmn	x8, x9
    2634:      	b.lt	0x3298 <_gap_verify_graph+0x3234>
    2638:      	ldr	x8, [x19, #0x50]
    263c:      	mvn	x9, x9
    2640:      	ldr	w8, [x8, x9, lsl #2]
    2644:      	cmp	w8, #0x0
    2648:      	b.le	0x3298 <_gap_verify_graph+0x3234>
    264c:      	mov	w25, #0x2c              ; =44
    2650:      	b	0x18f0 <_gap_verify_graph+0x188c>
    2654:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002654:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2658:      	add	x16, x16, #0x0
		0000000000002658:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    265c:      	tbz	x12, #0x3f, 0x26a4 <_gap_verify_graph+0x2640>
    2660:      	ldr	x8, [x19, #0x30]
    2664:      	ldr	x9, [x19, #0x58]
    2668:      	cmp	x8, x9
    266c:      	b.ne	0x26a4 <_gap_verify_graph+0x2640>
    2670:      	asr	x9, x12, #32
    2674:      	cmn	x8, x9
    2678:      	b.lt	0x26a4 <_gap_verify_graph+0x2640>
    267c:      	ldr	x8, [x19, #0x50]
    2680:      	mvn	x9, x9
    2684:      	ldr	w8, [x8, x9, lsl #2]
    2688:      	cmp	w8, #0x0
    268c:      	b.le	0x26a4 <_gap_verify_graph+0x2640>
    2690:      	adrp	x9, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002690:  ARM64_RELOC_PAGE21	l_str.601
    2694:      	add	x10, x9, #0x0
		0000000000002694:  ARM64_RELOC_PAGEOFF12	l_str.601
    2698:      	mov	w8, #0x1                ; =1
    269c:      	mov	w9, #0x1f               ; =31
    26a0:      	b	0x26b4 <_gap_verify_graph+0x2650>
    26a4:      	adrp	x9, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000026a4:  ARM64_RELOC_PAGE21	l_str.600
    26a8:      	add	x10, x9, #0x0
		00000000000026a8:  ARM64_RELOC_PAGEOFF12	l_str.600
    26ac:      	mov	w8, #0x1                ; =1
    26b0:      	mov	w9, #0x1a               ; =26
    26b4:      	str	w8, [sp, #0x100]
    26b8:      	stp	x10, x9, [sp, #0x108]
    26bc:      	ldr	x9, [sp, #0x110]
    26c0:      	cmp	w8, #0x1
    26c4:      	csel	x25, x9, x25, eq
    26c8:      	sub	w8, w24, #0x51
    26cc:      	cmp	w8, #0x4
    26d0:      	b.lo	0x19f4 <_gap_verify_graph+0x1990>
    26d4:      	b	0x19ec <_gap_verify_graph+0x1988>
    26d8:      	mov	w8, #0x1                ; =1
    26dc:      	mov	w21, #0x22              ; =34
    26e0:      	cmp	w8, #0x1
    26e4:      	mov	w27, #0x1e              ; =30
    26e8:      	str	x21, [sp, #0x68]
    26ec:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    26f0:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    26f4:      	cmp	w8, #0x0
    26f8:      	mov	w8, #0x52               ; =82
    26fc:      	ccmp	w12, w8, #0x0, eq
    2700:      	b.eq	0x2720 <_gap_verify_graph+0x26bc>
    2704:      	mov	w8, #0x1                ; =1
    2708:      	mov	w21, #0x29              ; =41
    270c:      	cmp	w8, #0x1
    2710:      	mov	w27, #0x1e              ; =30
    2714:      	str	x21, [sp, #0x68]
    2718:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    271c:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2720:      	cmp	w15, #0x1
    2724:      	b.lt	0x27fc <_gap_verify_graph+0x2798>
    2728:      	cmp	x27, x15
    272c:      	mov	w8, #0x1                ; =1
    2730:      	b.le	0x2c34 <_gap_verify_graph+0x2bd0>
    2734:      	cmp	x28, x15
    2738:      	mov	w21, #0x1f              ; =31
    273c:      	b.le	0x2ca4 <_gap_verify_graph+0x2c40>
    2740:      	ldr	w8, [x14, x15, lsl #2]
    2744:      	tbnz	w8, #0x1f, 0x28f4 <_gap_verify_graph+0x2890>
    2748:      	lsl	x8, x15, #4
    274c:      	ldr	x8, [x13, x8]
    2750:      	and	w10, w8, #0xff
    2754:      	sub	w10, w10, #0x4f
    2758:      	cmp	w10, #0x33
    275c:      	b.hi	0x28f4 <_gap_verify_graph+0x2890>
    2760:      	and	x8, x8, #0xff
    2764:      	adrp	x10, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002764:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    2768:      	add	x10, x10, #0x0
		0000000000002768:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    276c:      	ldrb	w8, [x10, x8]
    2770:      	tbnz	w8, #0x2, 0x28f4 <_gap_verify_graph+0x2890>
    2774:      	cmp	w2, #0x1
    2778:      	b.lt	0x2ff0 <_gap_verify_graph+0x2f8c>
    277c:      	and	x10, x2, #0x7fffffff
    2780:      	mov	w8, #0x1                ; =1
    2784:      	cmp	x27, x10
    2788:      	b.ls	0x3308 <_gap_verify_graph+0x32a4>
    278c:      	cmp	x28, x10
    2790:      	mov	w21, #0x18              ; =24
    2794:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002794:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2798:      	add	x16, x16, #0x0
		0000000000002798:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    279c:      	adrp	x26, 0x2000 <_gap_verify_graph+0x1f9c>
		000000000000279c:  ARM64_RELOC_PAGE21	l_str.688
    27a0:      	add	x26, x26, #0x0
		00000000000027a0:  ARM64_RELOC_PAGEOFF12	l_str.688
    27a4:      	b.ls	0x2ca4 <_gap_verify_graph+0x2c40>
    27a8:      	ldr	w8, [x14, x10, lsl #2]
    27ac:      	tbnz	w8, #0x1f, 0x3428 <_gap_verify_graph+0x33c4>
    27b0:      	add	x8, x13, x10, lsl #4
    27b4:      	ldr	x8, [x8]
    27b8:      	ubfx	w10, w8, #8, #8
    27bc:      	and	x8, x8, #0xff
    27c0:      	sub	w10, w10, #0xc
    27c4:      	cmn	w10, #0xb
    27c8:      	mov	w10, #0x48              ; =72
    27cc:      	ccmp	x8, x10, #0x4, hs
    27d0:      	b.ne	0x3454 <_gap_verify_graph+0x33f0>
    27d4:      	mov	w8, #0x1                ; =1
    27d8:      	mov	w21, #0x29              ; =41
    27dc:      	b	0x28fc <_gap_verify_graph+0x2898>
    27e0:      	mov	w8, #0x1                ; =1
    27e4:      	mov	w21, #0x1b              ; =27
    27e8:      	cmp	w8, #0x1
    27ec:      	mov	w27, #0x1e              ; =30
    27f0:      	str	x21, [sp, #0x68]
    27f4:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    27f8:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    27fc:      	mov	w8, #0x1                ; =1
    2800:      	mov	w21, #0x1f              ; =31
    2804:      	cmp	w8, #0x1
    2808:      	mov	w27, #0x1e              ; =30
    280c:      	str	x21, [sp, #0x68]
    2810:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    2814:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2818:      	tbz	w10, #0x1f, 0x28c0 <_gap_verify_graph+0x285c>
    281c:      	ldr	x8, [x19, #0x30]
    2820:      	ldr	x9, [x19, #0x58]
    2824:      	cmp	x8, x9
    2828:      	b.ne	0x28c0 <_gap_verify_graph+0x285c>
    282c:      	sxtw	x9, w10
    2830:      	cmn	x8, x9
    2834:      	b.lt	0x28c0 <_gap_verify_graph+0x285c>
    2838:      	ldr	x8, [x19, #0x50]
    283c:      	mvn	x9, x9
    2840:      	ldr	w8, [x8, x9, lsl #2]
    2844:      	cmp	w8, #0x0
    2848:      	b.le	0x28c0 <_gap_verify_graph+0x285c>
    284c:      	mvn	w8, w10
    2850:      	ldr	x9, [x19, #0x28]
    2854:      	ubfiz	x8, x8, #4, #32
    2858:      	ldr	x8, [x9, x8]
    285c:      	and	x9, x8, #0xff
    2860:      	cmp	x9, #0x68
    2864:      	b.ne	0x28c0 <_gap_verify_graph+0x285c>
    2868:      	lsr	x9, x8, #32
    286c:      	tbz	w2, #0x1f, 0x28c0 <_gap_verify_graph+0x285c>
    2870:      	cbnz	w9, 0x28c0 <_gap_verify_graph+0x285c>
    2874:      	sub	x0, x29, #0x80
    2878:      	mov	x1, x19
    287c:      	mov	w3, #0x10               ; =16
    2880:      	stp	x13, x2, [sp, #0x48]
    2884:      	stp	x15, x14, [sp, #0x38]
    2888:      	str	w17, [sp, #0x30]
    288c:      	bl	0x288c <_gap_verify_graph+0x2828>
		000000000000288c:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    2890:      	ldp	x15, x14, [sp, #0x38]
    2894:      	and	w12, w21, #0xff
    2898:      	ldp	x13, x2, [sp, #0x48]
    289c:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		000000000000289c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    28a0:      	add	x16, x16, #0x0
		00000000000028a0:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    28a4:      	ldur	w8, [x29, #-0x80]
    28a8:      	ldr	w17, [sp, #0x30]
    28ac:      	cmp	w8, #0x1
    28b0:      	b.eq	0x28c0 <_gap_verify_graph+0x285c>
    28b4:      	ldur	x8, [x29, #-0x78]
    28b8:      	cmp	x8, #0x1
    28bc:      	b.ge	0x1b04 <_gap_verify_graph+0x1aa0>
    28c0:      	mov	w8, #0x26               ; =38
    28c4:      	mov	w21, #0x26              ; =38
    28c8:      	b	0x1bec <_gap_verify_graph+0x1b88>
    28cc:      	mov	w8, #0x1                ; =1
    28d0:      	mov	w21, #0x1b              ; =27
    28d4:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000028d4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    28d8:      	add	x16, x16, #0x0
		00000000000028d8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    28dc:      	mov	x26, x27
    28e0:      	cmp	w8, #0x1
    28e4:      	mov	w27, #0x1e              ; =30
    28e8:      	str	x21, [sp, #0x68]
    28ec:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    28f0:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    28f4:      	mov	w8, #0x1                ; =1
    28f8:      	mov	w21, #0x1f              ; =31
    28fc:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000028fc:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2900:      	add	x16, x16, #0x0
		0000000000002900:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2904:      	adrp	x26, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002904:  ARM64_RELOC_PAGE21	l_str.688
    2908:      	add	x26, x26, #0x0
		0000000000002908:  ARM64_RELOC_PAGEOFF12	l_str.688
    290c:      	cmp	w8, #0x1
    2910:      	mov	w27, #0x1e              ; =30
    2914:      	str	x21, [sp, #0x68]
    2918:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    291c:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2920:      	mov	w21, #0x1b              ; =27
    2924:      	cmp	w8, #0x1
    2928:      	mov	w27, #0x1e              ; =30
    292c:      	str	x21, [sp, #0x68]
    2930:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    2934:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2938:      	mov	w8, #0x36               ; =54
    293c:      	str	x8, [sp, #0x20]
    2940:      	adrp	x8, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002940:  ARM64_RELOC_PAGE21	l_str.669
    2944:      	add	x8, x8, #0x0
		0000000000002944:  ARM64_RELOC_PAGEOFF12	l_str.669
    2948:      	cmp	w11, #0x3f
    294c:      	str	x8, [sp, #0x18]
    2950:      	b.ne	0x29ec <_gap_verify_graph+0x2988>
    2954:      	ldr	w8, [sp, #0x48]
    2958:      	cmp	w8, #0xe
    295c:      	b.lo	0x2c4c <_gap_verify_graph+0x2be8>
    2960:      	ldp	w9, w10, [sp, #0xc]
    2964:      	sub	w8, w27, #0x1
    2968:      	cmp	w10, #0x0
    296c:      	csinv	w0, w9, wzr, ne
    2970:      	cmp	w8, #0xd
    2974:      	csel	w8, wzr, w10, hs
    2978:      	cbz	w8, 0x2c4c <_gap_verify_graph+0x2be8>
    297c:      	cmp	w0, w27
    2980:      	b.eq	0x3248 <_gap_verify_graph+0x31e4>
    2984:      	sub	w8, w0, #0x1
    2988:      	cmp	w8, #0xa
    298c:      	b.hi	0x2c4c <_gap_verify_graph+0x2be8>
    2990:      	ldr	x4, [sp, #0x50]
    2994:      	cmp	w27, #0xb
    2998:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002998:  ARM64_RELOC_PAGE21	l_str.670
    299c:      	add	x21, x21, #0x0
		000000000000299c:  ARM64_RELOC_PAGEOFF12	l_str.670
    29a0:      	mov	w25, #0x24              ; =36
    29a4:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000029a4:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    29a8:      	add	x16, x16, #0x0
		00000000000029a8:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    29ac:      	adrp	x26, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000029ac:  ARM64_RELOC_PAGE21	l_str.688
    29b0:      	add	x26, x26, #0x0
		00000000000029b0:  ARM64_RELOC_PAGEOFF12	l_str.688
    29b4:      	b.hi	0x9b4 <_gap_verify_graph+0x950>
    29b8:      	bl	0x29b8 <_gap_verify_graph+0x2954>
		00000000000029b8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    29bc:      	mov	w21, w0
    29c0:      	mov	w0, w27
    29c4:      	bl	0x29c4 <_gap_verify_graph+0x2960>
		00000000000029c4:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    29c8:      	cmp	w21, w0
    29cc:      	b.eq	0x3248 <_gap_verify_graph+0x31e4>
    29d0:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000029d0:  ARM64_RELOC_PAGE21	l_str.670
    29d4:      	add	x21, x21, #0x0
		00000000000029d4:  ARM64_RELOC_PAGEOFF12	l_str.670
    29d8:      	mov	w25, #0x24              ; =36
    29dc:      	ldr	x4, [sp, #0x50]
    29e0:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		00000000000029e0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    29e4:      	add	x16, x16, #0x0
		00000000000029e4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    29e8:      	b	0x9b4 <_gap_verify_graph+0x950>
    29ec:      	mov	w21, w11
    29f0:      	cmp	w11, #0x3d
    29f4:      	b.ne	0x2ccc <_gap_verify_graph+0x2c68>
    29f8:      	cmp	w27, #0xe
    29fc:      	b.lo	0x30dc <_gap_verify_graph+0x3078>
    2a00:      	ldp	w9, w10, [sp, #0xc]
    2a04:      	ldr	w8, [sp, #0x48]
    2a08:      	cmp	w10, #0x0
    2a0c:      	sub	w8, w8, #0x1
    2a10:      	csinv	w0, w9, wzr, ne
    2a14:      	cmp	w8, #0xd
    2a18:      	csel	w8, wzr, w10, hs
    2a1c:      	cbz	w8, 0x30dc <_gap_verify_graph+0x3078>
    2a20:      	ldr	w8, [sp, #0x48]
    2a24:      	cmp	w0, w8
    2a28:      	b.ne	0x3088 <_gap_verify_graph+0x3024>
    2a2c:      	ldp	x9, x8, [sp, #0x18]
    2a30:      	b	0x30e8 <_gap_verify_graph+0x3084>
    2a34:      	lsr	x8, x10, #32
    2a38:      	cmp	w9, #0x1e
    2a3c:      	and	w11, w1, #0xff
    2a40:      	csel	w8, w8, wzr, eq
    2a44:      	sub	w9, w15, #0x10
    2a48:      	mov	x7, x6
    2a4c:      	mov	x16, x10
    2a50:      	cmp	w9, #0x6f
    2a54:      	b.hi	0x2ea8 <_gap_verify_graph+0x2e44>
    2a58:      	and	w9, w1, #0xff
    2a5c:      	cmp	w9, #0x39
    2a60:      	b.hi	0x2e78 <_gap_verify_graph+0x2e14>
    2a64:      	mov	x10, #0x80000000        ; =2147483648
    2a68:      	and	x9, x7, #0xff
    2a6c:      	movk	x10, #0x2001, lsl #32
    2a70:      	movk	x10, #0x3c0, lsl #48
    2a74:      	lsr	x9, x10, x9
    2a78:      	tbz	w9, #0x0, 0x2e78 <_gap_verify_graph+0x2e14>
    2a7c:      	and	w9, w1, #0xff
    2a80:      	cmp	w9, #0x39
    2a84:      	b.hi	0x2ec4 <_gap_verify_graph+0x2e60>
    2a88:      	mov	x10, #0x80000000        ; =2147483648
    2a8c:      	and	x9, x7, #0xff
    2a90:      	movk	x10, #0x2001, lsl #32
    2a94:      	movk	x10, #0x3c0, lsl #48
    2a98:      	lsr	x9, x10, x9
    2a9c:      	tbz	w9, #0x0, 0x2ec4 <_gap_verify_graph+0x2e60>
    2aa0:      	and	w9, w1, #0xff
    2aa4:      	and	w11, w1, #0xff
    2aa8:      	mov	x13, x12
    2aac:      	cmp	w9, #0x39
    2ab0:      	b.hi	0x33cc <_gap_verify_graph+0x3368>
    2ab4:      	and	x9, x7, #0xff
    2ab8:      	lsr	x9, x10, x9
    2abc:      	tbz	w9, #0x0, 0x33cc <_gap_verify_graph+0x3368>
    2ac0:      	cmp	w30, #0xb
    2ac4:      	b.hi	0x33cc <_gap_verify_graph+0x3368>
    2ac8:      	cmp	w11, #0x2d
    2acc:      	b.eq	0x33e0 <_gap_verify_graph+0x337c>
    2ad0:      	cmp	w30, #0x1
    2ad4:      	b.ne	0x2f7c <_gap_verify_graph+0x2f18>
    2ad8:      	mov	x1, x3
    2adc:      	mov	w14, #0x37              ; =55
    2ae0:      	adrp	x2, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002ae0:  ARM64_RELOC_PAGE21	l_str.653
    2ae4:      	add	x2, x2, #0x0
		0000000000002ae4:  ARM64_RELOC_PAGEOFF12	l_str.653
    2ae8:      	and	w9, w1, #0xff
    2aec:      	and	w11, w1, #0xff
    2af0:      	mov	x13, x12
    2af4:      	mov	x7, x6
    2af8:      	b	0x3494 <_gap_verify_graph+0x3430>
    2afc:      	cmp	w11, #0x1
    2b00:      	b.lt	0x2d8c <_gap_verify_graph+0x2d28>
    2b04:      	ldr	x12, [x19, #0x8]
    2b08:      	and	x10, x11, #0x7fffffff
    2b0c:      	cmp	x12, x10
    2b10:      	b.le	0x2de0 <_gap_verify_graph+0x2d7c>
    2b14:      	ldr	x11, [x19, #0x80]
    2b18:      	cmp	x11, x10
    2b1c:      	b.le	0x2de0 <_gap_verify_graph+0x2d7c>
    2b20:      	ldr	x11, [x19, #0x78]
    2b24:      	ldr	w11, [x11, x10, lsl #2]
    2b28:      	tbnz	w11, #0x1f, 0x2de0 <_gap_verify_graph+0x2d7c>
    2b2c:      	ldr	x11, [x19]
    2b30:      	add	x10, x11, x10, lsl #4
    2b34:      	ldr	x10, [x10]
    2b38:      	lsr	w11, w10, #8
    2b3c:      	cmp	w9, w11, uxtb
    2b40:      	b.ne	0x2de0 <_gap_verify_graph+0x2d7c>
    2b44:      	and	w9, w10, #0xff
    2b48:      	mov	w10, #0x46              ; =70
    2b4c:      	mov	w27, #0x1e              ; =30
    2b50:      	cmp	w9, #0x48
    2b54:      	ccmp	w9, w10, #0x4, ne
    2b58:      	b.ne	0x1748 <_gap_verify_graph+0x16e4>
    2b5c:      	mov	w8, #0x24               ; =36
    2b60:      	b	0x1750 <_gap_verify_graph+0x16ec>
    2b64:      	tbz	x1, #0x3f, 0x2c14 <_gap_verify_graph+0x2bb0>
    2b68:      	ldr	x8, [x19, #0x30]
    2b6c:      	ldr	x10, [x19, #0x58]
    2b70:      	cmp	x8, x10
    2b74:      	b.ne	0x2c14 <_gap_verify_graph+0x2bb0>
    2b78:      	asr	x10, x1, #32
    2b7c:      	cmn	x8, x10
    2b80:      	b.lt	0x2c14 <_gap_verify_graph+0x2bb0>
    2b84:      	ldr	x8, [x19, #0x50]
    2b88:      	mvn	x10, x10
    2b8c:      	ldr	w8, [x8, x10, lsl #2]
    2b90:      	cmp	w8, #0x0
    2b94:      	b.le	0x2c14 <_gap_verify_graph+0x2bb0>
    2b98:      	ldr	x8, [x19, #0x28]
    2b9c:      	eor	x10, x12, #0xffffffff
    2ba0:      	mov	x9, x0
    2ba4:      	add	x8, x8, x10, lsl #4
    2ba8:      	ldr	x8, [x8]
    2bac:      	cmp	w11, #0x1
    2bb0:      	b.ge	0xeec <_gap_verify_graph+0xe88>
    2bb4:      	tbz	w11, #0x1f, 0x2df4 <_gap_verify_graph+0x2d90>
    2bb8:      	ldr	x9, [x19, #0x30]
    2bbc:      	ldr	x10, [x19, #0x58]
    2bc0:      	cmp	x9, x10
    2bc4:      	b.ne	0x2df4 <_gap_verify_graph+0x2d90>
    2bc8:      	sxtw	x10, w11
    2bcc:      	cmn	x9, x10
    2bd0:      	b.lt	0x2df4 <_gap_verify_graph+0x2d90>
    2bd4:      	ldr	x9, [x19, #0x50]
    2bd8:      	mvn	x10, x10
    2bdc:      	ldr	w9, [x9, x10, lsl #2]
    2be0:      	cmp	w9, #0x0
    2be4:      	b.le	0x2df4 <_gap_verify_graph+0x2d90>
    2be8:      	mvn	w9, w11
    2bec:      	ldr	x10, [x19, #0x28]
    2bf0:      	and	x9, x9, #0x7fffffff
    2bf4:      	add	x9, x10, x9, lsl #4
    2bf8:      	sub	w10, w14, #0xe
    2bfc:      	cmp	w10, #0xb
    2c00:      	b.ls	0xf34 <_gap_verify_graph+0xed0>
    2c04:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c04:  ARM64_RELOC_PAGE21	l_str.664
    2c08:      	add	x21, x21, #0x0
		0000000000002c08:  ARM64_RELOC_PAGEOFF12	l_str.664
    2c0c:      	mov	w25, #0x33              ; =51
    2c10:      	b	0x2c20 <_gap_verify_graph+0x2bbc>
    2c14:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c14:  ARM64_RELOC_PAGE21	l_str.662
    2c18:      	add	x21, x21, #0x0
		0000000000002c18:  ARM64_RELOC_PAGEOFF12	l_str.662
    2c1c:      	mov	w25, #0x21              ; =33
    2c20:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c20:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2c24:      	add	x16, x16, #0x0
		0000000000002c24:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2c28:      	ldr	x4, [sp, #0x50]
    2c2c:      	mov	x26, x27
    2c30:      	b	0x9b4 <_gap_verify_graph+0x950>
    2c34:      	mov	w21, #0x1f              ; =31
    2c38:      	cmp	w8, #0x1
    2c3c:      	mov	w27, #0x1e              ; =30
    2c40:      	str	x21, [sp, #0x68]
    2c44:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    2c48:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2c4c:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c4c:  ARM64_RELOC_PAGE21	l_str.670
    2c50:      	add	x21, x21, #0x0
		0000000000002c50:  ARM64_RELOC_PAGEOFF12	l_str.670
    2c54:      	mov	w25, #0x24              ; =36
    2c58:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    2c5c:      	and	x8, x6, #0xfe
    2c60:      	cmp	x8, #0x3a
    2c64:      	b.eq	0x12b4 <_gap_verify_graph+0x1250>
    2c68:      	and	w8, w3, #0xff
    2c6c:      	cmp	w8, #0x35
    2c70:      	b.hi	0x3894 <_gap_verify_graph+0x3830>
    2c74:      	mov	x9, #0x3fc00000000000   ; =17944029765304320
    2c78:      	and	x8, x6, #0xff
    2c7c:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c7c:  ARM64_RELOC_PAGE21	l_str.661
    2c80:      	add	x21, x21, #0x0
		0000000000002c80:  ARM64_RELOC_PAGEOFF12	l_str.661
    2c84:      	movk	x9, #0x7c00, lsl #16
    2c88:      	mov	w25, #0x2b              ; =43
    2c8c:      	lsr	x8, x9, x8
    2c90:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002c90:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2c94:      	add	x16, x16, #0x0
		0000000000002c94:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2c98:      	tbnz	w8, #0x0, 0x12b4 <_gap_verify_graph+0x1250>
    2c9c:      	b	0x9b4 <_gap_verify_graph+0x950>
    2ca0:      	mov	w21, #0x29              ; =41
    2ca4:      	cmp	w8, #0x1
    2ca8:      	mov	w27, #0x1e              ; =30
    2cac:      	str	x21, [sp, #0x68]
    2cb0:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    2cb4:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    2cb8:      	str	wzr, [sp, #0xd0]
    2cbc:      	mov	x8, x25
    2cc0:      	mov	w27, #0x1e              ; =30
    2cc4:      	str	wzr, [sp, #0xd8]
    2cc8:      	b	0x1750 <_gap_verify_graph+0x16ec>
    2ccc:      	ldr	w8, [sp, #0x48]
    2cd0:      	ldp	x10, x9, [sp, #0x18]
    2cd4:      	cmp	w27, w8
    2cd8:      	mov	w8, #0x27               ; =39
    2cdc:      	csel	x8, x9, x8, eq
    2ce0:      	adrp	x9, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002ce0:  ARM64_RELOC_PAGE21	l_str.672
    2ce4:      	add	x9, x9, #0x0
		0000000000002ce4:  ARM64_RELOC_PAGEOFF12	l_str.672
    2ce8:      	csel	x9, x10, x9, eq
    2cec:      	b	0x30e8 <_gap_verify_graph+0x3084>
    2cf0:      	and	w8, w25, #0xff
    2cf4:      	sub	w9, w8, #0x5b
    2cf8:      	cmp	w9, #0x2
    2cfc:      	b.lo	0x2ef0 <_gap_verify_graph+0x2e8c>
    2d00:      	sub	w9, w8, #0x5d
    2d04:      	cmp	w9, #0x2
    2d08:      	b.hs	0x2f1c <_gap_verify_graph+0x2eb8>
    2d0c:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002d0c:  ARM64_RELOC_PAGE21	l_str.691
    2d10:      	add	x21, x21, #0x0
		0000000000002d10:  ARM64_RELOC_PAGEOFF12	l_str.691
    2d14:      	mov	w25, #0x1a              ; =26
    2d18:      	cmp	w27, #0x3
    2d1c:      	b.ne	0x3a90 <_gap_verify_graph+0x3a2c>
    2d20:      	ldr	x4, [sp, #0x50]
    2d24:      	ldr	w8, [sp, #0x48]
    2d28:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002d28:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2d2c:      	add	x16, x16, #0x0
		0000000000002d2c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2d30:      	adrp	x26, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002d30:  ARM64_RELOC_PAGE21	l_str.688
    2d34:      	add	x26, x26, #0x0
		0000000000002d34:  ARM64_RELOC_PAGEOFF12	l_str.688
    2d38:      	cbnz	w8, 0x9b4 <_gap_verify_graph+0x950>
    2d3c:      	ldr	x3, [sp, #0x40]
    2d40:      	add	x0, sp, #0xa0
    2d44:      	mov	x1, x19
    2d48:      	ldr	x2, [sp, #0x20]
    2d4c:      	lsr	x4, x3, #32
    2d50:      	bl	0x2d50 <_gap_verify_graph+0x2cec>
		0000000000002d50:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    2d54:      	b	0xd18 <_gap_verify_graph+0xcb4>
    2d58:      	ldur	w28, [x29, #-0x90]
    2d5c:      	cmp	w21, #0x6f
    2d60:      	b.ne	0x2e50 <_gap_verify_graph+0x2dec>
    2d64:      	mov	w8, wzr
    2d68:      	str	wzr, [sp, #0x100]
    2d6c:      	str	w28, [sp, #0x108]
    2d70:      	adrp	x16, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002d70:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    2d74:      	add	x16, x16, #0x0
		0000000000002d74:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    2d78:      	mov	x26, x27
    2d7c:      	mov	w27, #0x1e              ; =30
    2d80:      	b	0x26bc <_gap_verify_graph+0x2658>
    2d84:      	mov	x25, x8
    2d88:      	b	0x2e20 <_gap_verify_graph+0x2dbc>
    2d8c:      	tbz	w11, #0x1f, 0x2de0 <_gap_verify_graph+0x2d7c>
    2d90:      	ldr	x10, [x19, #0x30]
    2d94:      	ldr	x12, [x19, #0x58]
    2d98:      	cmp	x10, x12
    2d9c:      	b.ne	0x2de0 <_gap_verify_graph+0x2d7c>
    2da0:      	sxtw	x12, w11
    2da4:      	cmn	x10, x12
    2da8:      	b.lt	0x2de0 <_gap_verify_graph+0x2d7c>
    2dac:      	ldr	x10, [x19, #0x50]
    2db0:      	mvn	x12, x12
    2db4:      	ldr	w10, [x10, x12, lsl #2]
    2db8:      	cmp	w10, #0x0
    2dbc:      	b.le	0x2de0 <_gap_verify_graph+0x2d7c>
    2dc0:      	mvn	w10, w11
    2dc4:      	ldr	x11, [x19, #0x28]
    2dc8:      	and	x10, x10, #0x7fffffff
    2dcc:      	add	x10, x11, x10, lsl #4
    2dd0:      	ldr	x10, [x10]
    2dd4:      	lsr	w11, w10, #8
    2dd8:      	cmp	w9, w11, uxtb
    2ddc:      	b.eq	0x2b44 <_gap_verify_graph+0x2ae0>
    2de0:      	mov	w8, #0x24               ; =36
    2de4:      	mov	w27, #0x1e              ; =30
    2de8:      	b	0x1750 <_gap_verify_graph+0x16ec>
    2dec:      	mov	w25, #0x21              ; =33
    2df0:      	b	0x2c28 <_gap_verify_graph+0x2bc4>
    2df4:      	adrp	x21, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002df4:  ARM64_RELOC_PAGE21	l_str.663
    2df8:      	add	x21, x21, #0x0
		0000000000002df8:  ARM64_RELOC_PAGEOFF12	l_str.663
    2dfc:      	b	0x2c1c <_gap_verify_graph+0x2bb8>
    2e00:      	ldr	x8, [x19, #0x30]
    2e04:      	ldr	x9, [x19, #0x58]
    2e08:      	cmp	x8, x9
    2e0c:      	b.ne	0x2e1c <_gap_verify_graph+0x2db8>
    2e10:      	sxtw	x9, w13
    2e14:      	cmn	x8, x9
    2e18:      	b.ge	0x3274 <_gap_verify_graph+0x3210>
    2e1c:      	mov	w25, #0x1d              ; =29
    2e20:      	mov	x26, x14
    2e24:      	mov	w27, #0x1e              ; =30
    2e28:      	b	0x18f0 <_gap_verify_graph+0x188c>
    2e2c:      	add	w11, w20, #0x1
    2e30:      	ldr	x12, [x19]
    2e34:      	ubfiz	x11, x11, #4, #32
    2e38:      	ldr	w11, [x12, x11]
    2e3c:      	mov	w12, #0x1               ; =1
    2e40:      	cbnz	w12, 0x172c <_gap_verify_graph+0x16c8>
    2e44:      	mov	w8, #0x1d               ; =29
    2e48:      	mov	w27, #0x1e              ; =30
    2e4c:      	b	0x1750 <_gap_verify_graph+0x16ec>
    2e50:      	sub	x0, x29, #0xc0
    2e54:      	mov	x1, x19
    2e58:      	ldr	x2, [sp, #0x50]
    2e5c:      	mov	w3, w28
    2e60:      	bl	0x2e60 <_gap_verify_graph+0x2dfc>
		0000000000002e60:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    2e64:      	ldur	w8, [x29, #-0xc0]
    2e68:      	cmp	w8, #0x1
    2e6c:      	b.ne	0x2fb8 <_gap_verify_graph+0x2f54>
    2e70:      	ldp	x9, x10, [x29, #-0xb8]
    2e74:      	b	0x25c8 <_gap_verify_graph+0x2564>
    2e78:      	cmp	w14, #0x3a
    2e7c:      	b.eq	0x2a7c <_gap_verify_graph+0x2a18>
    2e80:      	and	w9, w1, #0xff
    2e84:      	cmp	w9, #0x35
    2e88:      	b.hi	0x2ad8 <_gap_verify_graph+0x2a74>
    2e8c:      	mov	x10, #0x3fc00000000000  ; =17944029765304320
    2e90:      	and	x9, x6, #0xff
    2e94:      	mov	x7, x6
    2e98:      	movk	x10, #0x7c00, lsl #16
    2e9c:      	mov	x1, x3
    2ea0:      	lsr	x9, x10, x9
    2ea4:      	tbnz	w9, #0x0, 0x2a7c <_gap_verify_graph+0x2a18>
    2ea8:      	and	w9, w1, #0xff
    2eac:      	mov	w14, #0x37              ; =55
    2eb0:      	adrp	x2, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002eb0:  ARM64_RELOC_PAGE21	l_str.653
    2eb4:      	add	x2, x2, #0x0
		0000000000002eb4:  ARM64_RELOC_PAGEOFF12	l_str.653
    2eb8:      	and	w11, w1, #0xff
    2ebc:      	mov	x13, x12
    2ec0:      	b	0x3494 <_gap_verify_graph+0x3430>
    2ec4:      	sub	w9, w11, #0x31
    2ec8:      	cmp	w9, #0x5
    2ecc:      	b.hs	0x3038 <_gap_verify_graph+0x2fd4>
    2ed0:      	sub	w9, w30, #0x2
    2ed4:      	mov	x1, x3
    2ed8:      	mov	x13, x12
    2edc:      	cmp	w9, #0x9
    2ee0:      	and	w11, w1, #0xff
    2ee4:      	mov	x7, x6
    2ee8:      	b.ls	0x33e0 <_gap_verify_graph+0x337c>
    2eec:      	b	0x3484 <_gap_verify_graph+0x3420>
    2ef0:      	cmp	w27, #0x2
    2ef4:      	b.ne	0x306c <_gap_verify_graph+0x3008>
    2ef8:      	ldr	w2, [sp, #0x48]
    2efc:      	add	x0, sp, #0xa0
    2f00:      	mov	x1, x19
    2f04:      	ldr	x3, [sp, #0x20]
    2f08:      	ldr	x4, [sp, #0x40]
    2f0c:      	bl	0x2f0c <_gap_verify_graph+0x2ea8>
		0000000000002f0c:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    2f10:      	adrp	x26, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002f10:  ARM64_RELOC_PAGE21	l_str.688
    2f14:      	add	x26, x26, #0x0
		0000000000002f14:  ARM64_RELOC_PAGEOFF12	l_str.688
    2f18:      	b	0xd18 <_gap_verify_graph+0xcb4>
    2f1c:      	cmp	w8, #0x43
    2f20:      	b.ne	0x3078 <_gap_verify_graph+0x3014>
    2f24:      	ldr	w8, [sp, #0x18]
    2f28:      	ldr	w9, [sp, #0x48]
    2f2c:      	sub	w8, w8, #0x1
    2f30:      	sub	w9, w9, #0x10
    2f34:      	cmp	w8, #0xd
    2f38:      	mov	w8, #0x70               ; =112
    2f3c:      	ccmp	w9, w8, #0x2, lo
    2f40:      	b.hs	0x3310 <_gap_verify_graph+0x32ac>
    2f44:      	ldr	w0, [sp, #0x48]
    2f48:      	bl	0x2f48 <_gap_verify_graph+0x2ee4>
		0000000000002f48:  ARM64_RELOC_BRANCH26	_stogir.types.size
    2f4c:      	cmp	w27, #0x3
    2f50:      	adrp	x9, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002f50:  ARM64_RELOC_PAGE21	l_str.692
    2f54:      	add	x9, x9, #0x0
		0000000000002f54:  ARM64_RELOC_PAGEOFF12	l_str.692
    2f58:      	ccmp	w0, #0x1, #0x8, hs
    2f5c:      	cset	w8, lt
    2f60:      	cmp	w8, #0x0
    2f64:      	adrp	x8, 0x2000 <_gap_verify_graph+0x1f9c>
		0000000000002f64:  ARM64_RELOC_PAGE21	l_str.693
    2f68:      	add	x8, x8, #0x0
		0000000000002f68:  ARM64_RELOC_PAGEOFF12	l_str.693
    2f6c:      	csel	x21, x8, x9, ne
    2f70:      	mov	w8, #0x20               ; =32
    2f74:      	csel	x25, x8, xzr, ne
    2f78:      	b	0x331c <_gap_verify_graph+0x32b8>
    2f7c:      	and	w9, w3, #0xff
    2f80:      	cmp	w9, #0x36
    2f84:      	b.eq	0x33f4 <_gap_verify_graph+0x3390>
    2f88:      	cmp	w9, #0x20
    2f8c:      	b.eq	0x33b4 <_gap_verify_graph+0x3350>
    2f90:      	mov	x1, x3
    2f94:      	cmp	w9, #0x1f
    2f98:      	mov	x13, x12
    2f9c:      	and	w11, w1, #0xff
    2fa0:      	mov	x7, x6
    2fa4:      	b.ne	0x33e0 <_gap_verify_graph+0x337c>
    2fa8:      	cmp	w30, #0x6
    2fac:      	b.ne	0x33e0 <_gap_verify_graph+0x337c>
    2fb0:      	mov	w9, #0x1f               ; =31
    2fb4:      	b	0x3488 <_gap_verify_graph+0x3424>
    2fb8:      	ldr	x8, [sp, #0x50]
    2fbc:      	cmp	w21, #0x6d
    2fc0:      	ldur	x26, [x29, #-0xb8]
    2fc4:      	sub	x0, x29, #0x80
    2fc8:      	mov	x1, x19
    2fcc:      	mov	w3, w28
    2fd0:      	lsr	x9, x8, #32
    2fd4:      	csel	w2, w8, w9, eq
    2fd8:      	bl	0x2fd8 <_gap_verify_graph+0x2f74>
		0000000000002fd8:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    2fdc:      	ldur	w8, [x29, #-0x80]
    2fe0:      	cmp	w8, #0x1
    2fe4:      	b.ne	0x32a0 <_gap_verify_graph+0x323c>
    2fe8:      	ldp	x9, x10, [x29, #-0x78]
    2fec:      	b	0x25c8 <_gap_verify_graph+0x2564>
    2ff0:      	tbz	w2, #0x1f, 0x3060 <_gap_verify_graph+0x2ffc>
    2ff4:      	ldr	x8, [x19, #0x30]
    2ff8:      	ldr	x10, [x19, #0x58]
    2ffc:      	cmp	x8, x10
    3000:      	b.ne	0x3060 <_gap_verify_graph+0x2ffc>
    3004:      	sxtw	x10, w2
    3008:      	cmn	x8, x10
    300c:      	b.lt	0x3060 <_gap_verify_graph+0x2ffc>
    3010:      	ldr	x8, [x19, #0x50]
    3014:      	mvn	x10, x10
    3018:      	ldr	w8, [x8, x10, lsl #2]
    301c:      	cmp	w8, #0x0
    3020:      	b.le	0x3060 <_gap_verify_graph+0x2ffc>
    3024:      	mvn	w8, w2
    3028:      	ldr	x10, [x19, #0x28]
    302c:      	and	x8, x8, #0x7fffffff
    3030:      	add	x8, x10, x8, lsl #4
    3034:      	b	0x27b4 <_gap_verify_graph+0x2750>
    3038:      	sub	w9, w11, #0x2e
    303c:      	cmp	w9, #0x2
    3040:      	b.hi	0x32c8 <_gap_verify_graph+0x3264>
    3044:      	mov	x1, x3
    3048:      	cmp	w30, #0xc
    304c:      	mov	x13, x12
    3050:      	and	w11, w1, #0xff
    3054:      	mov	x7, x6
    3058:      	b.lo	0x33e0 <_gap_verify_graph+0x337c>
    305c:      	b	0x3484 <_gap_verify_graph+0x3420>
    3060:      	mov	w8, #0x1                ; =1
    3064:      	mov	w21, #0x18              ; =24
    3068:      	b	0x28fc <_gap_verify_graph+0x2898>
    306c:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000306c:  ARM64_RELOC_PAGE21	l_str.690
    3070:      	add	x21, x21, #0x0
		0000000000003070:  ARM64_RELOC_PAGEOFF12	l_str.690
    3074:      	b	0x344c <_gap_verify_graph+0x33e8>
    3078:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003078:  ARM64_RELOC_PAGE21	l_str.701
    307c:      	add	x21, x21, #0x0
		000000000000307c:  ARM64_RELOC_PAGEOFF12	l_str.701
    3080:      	mov	w25, #0x28              ; =40
    3084:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3088:      	sub	w8, w0, #0x1
    308c:      	cmp	w8, #0xa
    3090:      	b.hi	0x30dc <_gap_verify_graph+0x3078>
    3094:      	ldr	w8, [sp, #0x48]
    3098:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003098:  ARM64_RELOC_PAGE21	l_str.671
    309c:      	add	x9, x9, #0x0
		000000000000309c:  ARM64_RELOC_PAGEOFF12	l_str.671
    30a0:      	cmp	w8, #0xb
    30a4:      	mov	w8, #0x26               ; =38
    30a8:      	b.hi	0x30e8 <_gap_verify_graph+0x3084>
    30ac:      	bl	0x30ac <_gap_verify_graph+0x3048>
		00000000000030ac:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    30b0:      	mov	w25, w0
    30b4:      	ldr	w0, [sp, #0x48]
    30b8:      	bl	0x30b8 <_gap_verify_graph+0x3054>
		00000000000030b8:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    30bc:      	ldp	x10, x9, [sp, #0x18]
    30c0:      	cmp	w25, w0
    30c4:      	mov	w8, #0x26               ; =38
    30c8:      	csel	x8, x8, x9, ne
    30cc:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000030cc:  ARM64_RELOC_PAGE21	l_str.671
    30d0:      	add	x9, x9, #0x0
		00000000000030d0:  ARM64_RELOC_PAGEOFF12	l_str.671
    30d4:      	csel	x9, x9, x10, ne
    30d8:      	b	0x30e8 <_gap_verify_graph+0x3084>
    30dc:      	mov	w8, #0x26               ; =38
    30e0:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000030e0:  ARM64_RELOC_PAGE21	l_str.671
    30e4:      	add	x9, x9, #0x0
		00000000000030e4:  ARM64_RELOC_PAGEOFF12	l_str.671
    30e8:      	ldr	x10, [sp, #0x40]
    30ec:      	cmp	w10, #0x1
    30f0:      	b.lt	0x3174 <_gap_verify_graph+0x3110>
    30f4:      	ldp	x11, x10, [sp, #0x38]
    30f8:      	and	x10, x10, #0x7fffffff
    30fc:      	cmp	x11, x10
    3100:      	b.ls	0x322c <_gap_verify_graph+0x31c8>
    3104:      	ldr	x11, [sp, #0x28]
    3108:      	cmp	x11, x10
    310c:      	mov	w11, #0x19              ; =25
    3110:      	str	x11, [sp, #0x20]
    3114:      	adrp	x11, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003114:  ARM64_RELOC_PAGE21	l_str.673
    3118:      	add	x11, x11, #0x0
		0000000000003118:  ARM64_RELOC_PAGEOFF12	l_str.673
    311c:      	str	x11, [sp, #0x18]
    3120:      	b.ls	0x3240 <_gap_verify_graph+0x31dc>
    3124:      	ldr	w11, [x28, x10, lsl #2]
    3128:      	tbnz	w11, #0x1f, 0x322c <_gap_verify_graph+0x31c8>
    312c:      	ldr	x11, [sp, #0x30]
    3130:      	add	x10, x11, x10, lsl #4
    3134:      	ldr	x12, [x10]
    3138:      	ubfx	w11, w12, #8, #8
    313c:      	sub	w13, w11, #0x1
    3140:      	cmp	w13, #0xb
    3144:      	b.hs	0x31d8 <_gap_verify_graph+0x3174>
    3148:      	and	w13, w12, #0xff
    314c:      	mov	w14, #0x46              ; =70
    3150:      	cmp	w13, #0x48
    3154:      	ccmp	w13, w14, #0x4, ne
    3158:      	mov	w13, #0x2b              ; =43
    315c:      	csel	x8, x13, x8, eq
    3160:      	str	x8, [sp, #0x20]
    3164:      	adrp	x8, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003164:  ARM64_RELOC_PAGE21	l_str.674
    3168:      	add	x8, x8, #0x0
		0000000000003168:  ARM64_RELOC_PAGEOFF12	l_str.674
    316c:      	csel	x8, x8, x9, eq
    3170:      	b	0x31e8 <_gap_verify_graph+0x3184>
    3174:      	ldr	x10, [sp, #0x40]
    3178:      	tbz	w10, #0x1f, 0x322c <_gap_verify_graph+0x31c8>
    317c:      	ldr	x10, [x19, #0x30]
    3180:      	ldr	x11, [x19, #0x58]
    3184:      	cmp	x10, x11
    3188:      	b.ne	0x322c <_gap_verify_graph+0x31c8>
    318c:      	ldr	x11, [sp, #0x40]
    3190:      	sxtw	x11, w11
    3194:      	cmn	x10, x11
    3198:      	b.lt	0x322c <_gap_verify_graph+0x31c8>
    319c:      	ldr	x10, [x19, #0x50]
    31a0:      	mvn	x11, x11
    31a4:      	ldr	w10, [x10, x11, lsl #2]
    31a8:      	cmp	w10, #0x0
    31ac:      	b.le	0x322c <_gap_verify_graph+0x31c8>
    31b0:      	ldr	x10, [sp, #0x40]
    31b4:      	ldr	x11, [x19, #0x28]
    31b8:      	mvn	w10, w10
    31bc:      	and	x10, x10, #0x7fffffff
    31c0:      	add	x10, x11, x10, lsl #4
    31c4:      	ldr	x12, [x10]
    31c8:      	ubfx	w11, w12, #8, #8
    31cc:      	sub	w13, w11, #0x1
    31d0:      	cmp	w13, #0xb
    31d4:      	b.lo	0x3148 <_gap_verify_graph+0x30e4>
    31d8:      	mov	w8, #0x2b               ; =43
    31dc:      	str	x8, [sp, #0x20]
    31e0:      	adrp	x8, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000031e0:  ARM64_RELOC_PAGE21	l_str.674
    31e4:      	add	x8, x8, #0x0
		00000000000031e4:  ARM64_RELOC_PAGEOFF12	l_str.674
    31e8:      	str	x8, [sp, #0x18]
    31ec:      	ldr	x8, [sp, #0x40]
    31f0:      	tbz	w8, #0x1f, 0x3240 <_gap_verify_graph+0x31dc>
    31f4:      	and	w9, w12, #0xff
    31f8:      	ldr	x8, [x10, #0x8]
    31fc:      	cmp	w9, #0x49
    3200:      	b.eq	0x320c <_gap_verify_graph+0x31a8>
    3204:      	cmp	w9, w11
    3208:      	b.ne	0x3240 <_gap_verify_graph+0x31dc>
    320c:      	ldr	w9, [sp, #0x10]
    3210:      	cbz	w9, 0x3878 <_gap_verify_graph+0x3814>
    3214:      	ldr	x9, [sp]
    3218:      	mov	w10, #0x1               ; =1
    321c:      	lsr	w9, w9, #4
    3220:      	sub	w9, w9, #0x1
    3224:      	lsl	w9, w10, w9
    3228:      	b	0x38ec <_gap_verify_graph+0x3888>
    322c:      	mov	w8, #0x19               ; =25
    3230:      	str	x8, [sp, #0x20]
    3234:      	adrp	x8, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003234:  ARM64_RELOC_PAGE21	l_str.673
    3238:      	add	x8, x8, #0x0
		0000000000003238:  ARM64_RELOC_PAGEOFF12	l_str.673
    323c:      	str	x8, [sp, #0x18]
    3240:      	cmp	w21, #0x3d
    3244:      	b.ne	0x3914 <_gap_verify_graph+0x38b0>
    3248:      	ldp	x21, x8, [sp, #0x18]
    324c:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000324c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3250:      	add	x16, x16, #0x0
		0000000000003250:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3254:      	ldr	x4, [sp, #0x50]
    3258:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003258:  ARM64_RELOC_PAGE21	l_str.688
    325c:      	add	x26, x26, #0x0
		000000000000325c:  ARM64_RELOC_PAGEOFF12	l_str.688
    3260:      	mov	x25, x8
    3264:      	cbnz	x8, 0x9b4 <_gap_verify_graph+0x950>
    3268:      	ldr	x0, [sp]
    326c:      	str	wzr, [sp, #0xa0]
    3270:      	b	0x3860 <_gap_verify_graph+0x37fc>
    3274:      	ldr	x8, [x19, #0x50]
    3278:      	mvn	x9, x9
    327c:      	mov	x26, x14
    3280:      	mov	w27, #0x1e              ; =30
    3284:      	ldr	w8, [x8, x9, lsl #2]
    3288:      	cmp	w8, #0x0
    328c:      	b.le	0x3298 <_gap_verify_graph+0x3234>
    3290:      	mov	w25, #0x2e              ; =46
    3294:      	b	0x18f0 <_gap_verify_graph+0x188c>
    3298:      	mov	w25, #0x1d              ; =29
    329c:      	b	0x18f0 <_gap_verify_graph+0x188c>
    32a0:      	ldur	x8, [x29, #-0x78]
    32a4:      	cmp	x26, x8
    32a8:      	b.ls	0x2d64 <_gap_verify_graph+0x2d00>
    32ac:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000032ac:  ARM64_RELOC_PAGE21	l_str.602
    32b0:      	add	x10, x9, #0x0
		00000000000032b0:  ARM64_RELOC_PAGEOFF12	l_str.602
    32b4:      	mov	w8, #0x1                ; =1
    32b8:      	mov	w9, #0x1a               ; =26
    32bc:      	str	w8, [sp, #0x100]
    32c0:      	stp	x10, x9, [sp, #0x108]
    32c4:      	b	0x2d70 <_gap_verify_graph+0x2d0c>
    32c8:      	and	w9, w3, #0xe00
    32cc:      	cmp	w9, #0xc00
    32d0:      	b.ne	0x3464 <_gap_verify_graph+0x3400>
    32d4:      	mov	x1, x3
    32d8:      	mov	x13, x12
    32dc:      	mov	x7, x6
    32e0:      	and	w11, w1, #0xff
    32e4:      	cmp	w11, #0x1e
    32e8:      	b.ne	0x33e0 <_gap_verify_graph+0x337c>
    32ec:      	mov	w1, #0x1e               ; =30
    32f0:      	mov	w9, #0x1                ; =1
    32f4:      	mov	w10, #0x1               ; =1
    32f8:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000032f8:  ARM64_RELOC_PAGE21	l_str.653
    32fc:      	add	x2, x2, #0x0
		00000000000032fc:  ARM64_RELOC_PAGEOFF12	l_str.653
    3300:      	mov	w14, #0x37              ; =55
    3304:      	b	0x34ac <_gap_verify_graph+0x3448>
    3308:      	mov	w21, #0x18              ; =24
    330c:      	b	0x28fc <_gap_verify_graph+0x2898>
    3310:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003310:  ARM64_RELOC_PAGE21	l_str.693
    3314:      	add	x21, x21, #0x0
		0000000000003314:  ARM64_RELOC_PAGEOFF12	l_str.693
    3318:      	mov	w25, #0x20              ; =32
    331c:      	sub	x0, x29, #0xc0
    3320:      	mov	x1, x19
    3324:      	ldr	x2, [sp, #0x20]
    3328:      	bl	0x3328 <_gap_verify_graph+0x32c4>
		0000000000003328:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    332c:      	ldur	w8, [x29, #-0xc0]
    3330:      	cbz	w8, 0x3444 <_gap_verify_graph+0x33e0>
    3334:      	ldr	x8, [sp, #0x20]
    3338:      	cmp	w8, #0x1
    333c:      	b.lt	0x33a8 <_gap_verify_graph+0x3344>
    3340:      	ldur	w8, [x29, #-0xb8]
    3344:      	and	w8, w8, #0xfe
    3348:      	cmp	w8, #0x70
    334c:      	b.ne	0x33a8 <_gap_verify_graph+0x3344>
    3350:      	ldr	x8, [sp, #0x20]
    3354:      	ldr	w8, [x28, x8, lsl #2]
    3358:      	add	w8, w8, #0x1
    335c:      	cmp	w27, w8
    3360:      	b.ne	0x33a8 <_gap_verify_graph+0x3344>
    3364:      	ldr	x4, [sp, #0x50]
    3368:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003368:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    336c:      	add	x16, x16, #0x0
		000000000000336c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3370:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003370:  ARM64_RELOC_PAGE21	l_str.688
    3374:      	add	x26, x26, #0x0
		0000000000003374:  ARM64_RELOC_PAGEOFF12	l_str.688
    3378:      	cbnz	x25, 0x9b4 <_gap_verify_graph+0x950>
    337c:      	cmp	w27, #0x2
    3380:      	b.hs	0x3ae8 <_gap_verify_graph+0x3a84>
    3384:      	ldr	w0, [sp, #0x48]
    3388:      	str	wzr, [sp, #0xa0]
    338c:      	bl	0x338c <_gap_verify_graph+0x3328>
		000000000000338c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3390:      	ldr	x4, [sp, #0x50]
    3394:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003394:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3398:      	add	x16, x16, #0x0
		0000000000003398:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    339c:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000339c:  ARM64_RELOC_PAGE21	l_str.688
    33a0:      	add	x26, x26, #0x0
		00000000000033a0:  ARM64_RELOC_PAGEOFF12	l_str.688
    33a4:      	b	0x3860 <_gap_verify_graph+0x37fc>
    33a8:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000033a8:  ARM64_RELOC_PAGE21	l_str.695
    33ac:      	add	x21, x21, #0x0
		00000000000033ac:  ARM64_RELOC_PAGEOFF12	l_str.695
    33b0:      	b	0x344c <_gap_verify_graph+0x33e8>
    33b4:      	mov	x1, x3
    33b8:      	cmp	w30, #0x6
    33bc:      	mov	x13, x12
    33c0:      	and	w11, w1, #0xff
    33c4:      	mov	x7, x6
    33c8:      	b.hi	0x33e0 <_gap_verify_graph+0x337c>
    33cc:      	and	w9, w1, #0xe00
    33d0:      	cmp	w9, #0xc00
    33d4:      	mov	w9, #0x21               ; =33
    33d8:      	ccmp	w11, w9, #0x2, eq
    33dc:      	b.hs	0x3484 <_gap_verify_graph+0x3420>
    33e0:      	mov	x14, xzr
    33e4:      	and	w9, w1, #0xff
    33e8:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000033e8:  ARM64_RELOC_PAGE21	l_str.652
    33ec:      	add	x2, x2, #0x0
		00000000000033ec:  ARM64_RELOC_PAGEOFF12	l_str.652
    33f0:      	b	0x3494 <_gap_verify_graph+0x3430>
    33f4:      	cmp	w30, #0xb
    33f8:      	b.hi	0x3ad4 <_gap_verify_graph+0x3a70>
    33fc:      	mov	w10, #0xe78             ; =3704
    3400:      	mov	x1, x3
    3404:      	mov	w14, #0x37              ; =55
    3408:      	lsr	w10, w10, w30
    340c:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000340c:  ARM64_RELOC_PAGE21	l_str.653
    3410:      	add	x2, x2, #0x0
		0000000000003410:  ARM64_RELOC_PAGEOFF12	l_str.653
    3414:      	and	w11, w1, #0xff
    3418:      	mov	x13, x12
    341c:      	mov	x7, x6
    3420:      	tbnz	w10, #0x0, 0x33e0 <_gap_verify_graph+0x337c>
    3424:      	b	0x3494 <_gap_verify_graph+0x3430>
    3428:      	mov	w8, #0x1                ; =1
    342c:      	mov	w21, #0x18              ; =24
    3430:      	cmp	w8, #0x1
    3434:      	mov	w27, #0x1e              ; =30
    3438:      	str	x21, [sp, #0x68]
    343c:      	b.ne	0x1a50 <_gap_verify_graph+0x19ec>
    3440:      	b	0x1bf4 <_gap_verify_graph+0x1b90>
    3444:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003444:  ARM64_RELOC_PAGE21	l_str.694
    3448:      	add	x21, x21, #0x0
		0000000000003448:  ARM64_RELOC_PAGEOFF12	l_str.694
    344c:      	mov	w25, #0x19              ; =25
    3450:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3454:      	tbnz	w2, #0x1f, 0x38ac <_gap_verify_graph+0x3848>
    3458:      	ldr	x21, [sp, #0x68]
    345c:      	mov	w8, wzr
    3460:      	b	0x28fc <_gap_verify_graph+0x2898>
    3464:      	cmp	w30, #0x1
    3468:      	mov	w9, #0x3a               ; =58
    346c:      	mov	x1, x3
    3470:      	ccmp	w14, w9, #0x4, eq
    3474:      	and	w11, w1, #0xff
    3478:      	mov	x13, x12
    347c:      	mov	x7, x6
    3480:      	b.eq	0x33e0 <_gap_verify_graph+0x337c>
    3484:      	and	w9, w1, #0xff
    3488:      	mov	w14, #0x37              ; =55
    348c:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000348c:  ARM64_RELOC_PAGE21	l_str.653
    3490:      	add	x2, x2, #0x0
		0000000000003490:  ARM64_RELOC_PAGEOFF12	l_str.653
    3494:      	sub	w10, w11, #0x36
    3498:      	sub	w9, w9, #0x1d
    349c:      	cmn	w10, #0x5
    34a0:      	cset	w10, lo
    34a4:      	cmp	w9, #0x2
    34a8:      	cset	w9, lo
    34ac:      	mov	x3, x1
    34b0:      	cmp	w13, #0x0
    34b4:      	b.le	0x3530 <_gap_verify_graph+0x34cc>
    34b8:      	cmp	x0, x13
    34bc:      	b.ls	0x35d4 <_gap_verify_graph+0x3570>
    34c0:      	cmp	x17, x13
    34c4:      	mov	w11, #0x21              ; =33
    34c8:      	adrp	x1, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000034c8:  ARM64_RELOC_PAGE21	l_str.654
    34cc:      	add	x1, x1, #0x0
		00000000000034cc:  ARM64_RELOC_PAGEOFF12	l_str.654
    34d0:      	mov	x13, x16
    34d4:      	b.ls	0x35e4 <_gap_verify_graph+0x3580>
    34d8:      	ldr	w13, [x28, x12, lsl #2]
    34dc:      	mov	x11, x5
    34e0:      	tbnz	w13, #0x1f, 0x3758 <_gap_verify_graph+0x36f4>
    34e4:      	lsl	x13, x12, #4
    34e8:      	ldr	x11, [x11, x13]
    34ec:      	lsr	w13, w11, #8
    34f0:      	cmp	w15, w13, uxtb
    34f4:      	b.ne	0x3580 <_gap_verify_graph+0x351c>
    34f8:      	and	w11, w11, #0xff
    34fc:      	cmp	w11, #0x46
    3500:      	b.eq	0x3580 <_gap_verify_graph+0x351c>
    3504:      	cmp	w11, #0x48
    3508:      	mov	w11, #0x32              ; =50
    350c:      	adrp	x1, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000350c:  ARM64_RELOC_PAGE21	l_str.655
    3510:      	add	x1, x1, #0x0
		0000000000003510:  ARM64_RELOC_PAGEOFF12	l_str.655
    3514:      	mov	x13, x16
    3518:      	b.eq	0x35e4 <_gap_verify_graph+0x3580>
    351c:      	mov	x11, x14
    3520:      	mov	x1, x2
    3524:      	cmp	w13, #0x1
    3528:      	b.ge	0x35ec <_gap_verify_graph+0x3588>
    352c:      	b	0x3598 <_gap_verify_graph+0x3534>
    3530:      	tbz	x7, #0x3f, 0x35d4 <_gap_verify_graph+0x3570>
    3534:      	ldr	x11, [x19, #0x30]
    3538:      	ldr	x13, [x19, #0x58]
    353c:      	cmp	x11, x13
    3540:      	b.ne	0x35d4 <_gap_verify_graph+0x3570>
    3544:      	asr	x13, x6, #32
    3548:      	cmn	x11, x13
    354c:      	b.lt	0x35d4 <_gap_verify_graph+0x3570>
    3550:      	ldr	x11, [x19, #0x50]
    3554:      	mvn	x13, x13
    3558:      	ldr	w11, [x11, x13, lsl #2]
    355c:      	cmp	w11, #0x1
    3560:      	b.lt	0x35d4 <_gap_verify_graph+0x3570>
    3564:      	ldr	x11, [x19, #0x28]
    3568:      	eor	x12, x12, #0xffffffff
    356c:      	lsl	x13, x12, #4
    3570:      	ldr	x11, [x11, x13]
    3574:      	lsr	w13, w11, #8
    3578:      	cmp	w15, w13, uxtb
    357c:      	b.eq	0x34f8 <_gap_verify_graph+0x3494>
    3580:      	mov	w11, #0x32              ; =50
    3584:      	adrp	x1, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003584:  ARM64_RELOC_PAGE21	l_str.655
    3588:      	add	x1, x1, #0x0
		0000000000003588:  ARM64_RELOC_PAGEOFF12	l_str.655
    358c:      	mov	x13, x16
    3590:      	cmp	w13, #0x1
    3594:      	b.ge	0x35ec <_gap_verify_graph+0x3588>
    3598:      	tbnz	w13, #0x1f, 0x36a4 <_gap_verify_graph+0x3640>
    359c:      	and	w10, w3, #0xff
    35a0:      	cmp	w10, #0x39
    35a4:      	b.hi	0x37dc <_gap_verify_graph+0x3778>
    35a8:      	mov	x12, #0x80000000        ; =2147483648
    35ac:      	mov	w10, w3
    35b0:      	mov	x2, x1
    35b4:      	movk	x12, #0x2001, lsl #32
    35b8:      	and	x10, x10, #0xff
    35bc:      	movk	x12, #0x3c0, lsl #48
    35c0:      	lsr	x10, x12, x10
    35c4:      	mov	x12, x11
    35c8:      	tbz	w10, #0x0, 0x37dc <_gap_verify_graph+0x3778>
    35cc:      	cbnz	w8, 0x361c <_gap_verify_graph+0x35b8>
    35d0:      	b	0x3844 <_gap_verify_graph+0x37e0>
    35d4:      	mov	w11, #0x21              ; =33
    35d8:      	adrp	x1, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000035d8:  ARM64_RELOC_PAGE21	l_str.654
    35dc:      	add	x1, x1, #0x0
		00000000000035dc:  ARM64_RELOC_PAGEOFF12	l_str.654
    35e0:      	mov	x13, x16
    35e4:      	cmp	w13, #0x1
    35e8:      	b.lt	0x3598 <_gap_verify_graph+0x3534>
    35ec:      	and	w12, w3, #0xff
    35f0:      	cmp	w12, #0x39
    35f4:      	b.hi	0x376c <_gap_verify_graph+0x3708>
    35f8:      	mov	x13, #0x80000000        ; =2147483648
    35fc:      	and	x12, x3, #0xff
    3600:      	movk	x13, #0x2001, lsl #32
    3604:      	movk	x13, #0x3c0, lsl #48
    3608:      	lsr	x12, x13, x12
    360c:      	tbz	w12, #0x0, 0x376c <_gap_verify_graph+0x3708>
    3610:      	mov	x12, x11
    3614:      	mov	x2, x1
    3618:      	cbz	w8, 0x3844 <_gap_verify_graph+0x37e0>
    361c:      	cbz	w9, 0x368c <_gap_verify_graph+0x3628>
    3620:      	cmp	w8, #0x1
    3624:      	b.lt	0x3724 <_gap_verify_graph+0x36c0>
    3628:      	mov	w8, w8
    362c:      	cmp	x0, x8
    3630:      	b.ls	0x3740 <_gap_verify_graph+0x36dc>
    3634:      	cmp	x17, x8
    3638:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003638:  ARM64_RELOC_PAGE21	l_str.657
    363c:      	add	x21, x21, #0x0
		000000000000363c:  ARM64_RELOC_PAGEOFF12	l_str.657
    3640:      	mov	w25, #0x1d              ; =29
    3644:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003644:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3648:      	add	x16, x16, #0x0
		0000000000003648:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    364c:      	b.ls	0x9b4 <_gap_verify_graph+0x950>
    3650:      	ldr	w9, [x28, x8, lsl #2]
    3654:      	tbnz	w9, #0x1f, 0x37f0 <_gap_verify_graph+0x378c>
    3658:      	lsl	x8, x8, #4
    365c:      	ldr	w8, [x5, x8]
    3660:      	and	w9, w8, #0xfe
    3664:      	and	w8, w8, #0xff
    3668:      	sub	w9, w9, #0x68
    366c:      	sub	w8, w8, #0x65
    3670:      	cmp	w9, #0x9
    3674:      	ccmp	w8, #0x1, #0x0, hi
    3678:      	b.ls	0x3844 <_gap_verify_graph+0x37e0>
    367c:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000367c:  ARM64_RELOC_PAGE21	l_str.658
    3680:      	add	x21, x21, #0x0
		0000000000003680:  ARM64_RELOC_PAGEOFF12	l_str.658
    3684:      	mov	w25, #0x34              ; =52
    3688:      	b	0x9b4 <_gap_verify_graph+0x950>
    368c:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000368c:  ARM64_RELOC_PAGE21	l_str.656
    3690:      	add	x21, x21, #0x0
		0000000000003690:  ARM64_RELOC_PAGEOFF12	l_str.656
    3694:      	mov	w25, #0x23              ; =35
    3698:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003698:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    369c:      	add	x16, x16, #0x0
		000000000000369c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    36a0:      	b	0x9b4 <_gap_verify_graph+0x950>
    36a4:      	and	w12, w3, #0xff
    36a8:      	cmp	w12, #0x39
    36ac:      	b.hi	0x36cc <_gap_verify_graph+0x3668>
    36b0:      	mov	x13, #0x80000000        ; =2147483648
    36b4:      	mov	w12, w3
    36b8:      	movk	x13, #0x2001, lsl #32
    36bc:      	and	x12, x12, #0xff
    36c0:      	movk	x13, #0x3c0, lsl #48
    36c4:      	lsr	x12, x13, x12
    36c8:      	tbnz	w12, #0x0, 0x3610 <_gap_verify_graph+0x35ac>
    36cc:      	ldr	x12, [x19, #0x30]
    36d0:      	ldr	x13, [x19, #0x58]
    36d4:      	cmp	x12, x13
    36d8:      	b.ne	0x37dc <_gap_verify_graph+0x3778>
    36dc:      	mov	w13, w16
    36e0:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000036e0:  ARM64_RELOC_PAGE21	l_str.654
    36e4:      	add	x2, x2, #0x0
		00000000000036e4:  ARM64_RELOC_PAGEOFF12	l_str.654
    36e8:      	sxtw	x13, w13
    36ec:      	neg	x14, x13
    36f0:      	cmp	x12, x14
    36f4:      	mov	w12, #0x21              ; =33
    36f8:      	b.lt	0x35cc <_gap_verify_graph+0x3568>
    36fc:      	ldr	x12, [x19, #0x50]
    3700:      	mvn	x13, x13
    3704:      	ldr	w12, [x12, x13, lsl #2]
    3708:      	cmp	w12, #0x1
    370c:      	b.lt	0x3ac0 <_gap_verify_graph+0x3a5c>
    3710:      	mvn	w12, w16
    3714:      	ldr	x13, [x19, #0x28]
    3718:      	lsl	x12, x12, #4
    371c:      	ldr	x12, [x13, x12]
    3720:      	b	0x379c <_gap_verify_graph+0x3738>
    3724:      	ldr	x9, [x19, #0x30]
    3728:      	ldr	x10, [x19, #0x58]
    372c:      	cmp	x9, x10
    3730:      	b.ne	0x3740 <_gap_verify_graph+0x36dc>
    3734:      	sxtw	x8, w8
    3738:      	cmn	x9, x8
    373c:      	b.ge	0x37f8 <_gap_verify_graph+0x3794>
    3740:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003740:  ARM64_RELOC_PAGE21	l_str.657
    3744:      	add	x21, x21, #0x0
		0000000000003744:  ARM64_RELOC_PAGEOFF12	l_str.657
    3748:      	mov	w25, #0x1d              ; =29
    374c:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000374c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3750:      	add	x16, x16, #0x0
		0000000000003750:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3754:      	b	0x9b4 <_gap_verify_graph+0x950>
    3758:      	mov	w11, #0x21              ; =33
    375c:      	mov	x13, x16
    3760:      	cmp	w13, #0x1
    3764:      	b.ge	0x35ec <_gap_verify_graph+0x3588>
    3768:      	b	0x3598 <_gap_verify_graph+0x3534>
    376c:      	mov	w13, w16
    3770:      	cmp	x0, x13
    3774:      	b.ls	0x37dc <_gap_verify_graph+0x3778>
    3778:      	cmp	x17, x13
    377c:      	mov	w12, #0x21              ; =33
    3780:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003780:  ARM64_RELOC_PAGE21	l_str.654
    3784:      	add	x2, x2, #0x0
		0000000000003784:  ARM64_RELOC_PAGEOFF12	l_str.654
    3788:      	b.ls	0x35cc <_gap_verify_graph+0x3568>
    378c:      	ldr	w12, [x28, x13, lsl #2]
    3790:      	tbnz	w12, #0x1f, 0x3870 <_gap_verify_graph+0x380c>
    3794:      	lsl	x12, x13, #4
    3798:      	ldr	x12, [x5, x12]
    379c:      	ubfx	w13, w12, #8, #8
    37a0:      	cmp	w13, w15
    37a4:      	b.eq	0x37b8 <_gap_verify_graph+0x3754>
    37a8:      	sub	w13, w13, #0xc
    37ac:      	cmn	w13, #0xb
    37b0:      	csinc	w10, w10, wzr, hs
    37b4:      	tbnz	w10, #0x0, 0x3834 <_gap_verify_graph+0x37d0>
    37b8:      	and	w10, w12, #0xff
    37bc:      	cmp	w10, #0x46
    37c0:      	b.eq	0x3834 <_gap_verify_graph+0x37d0>
    37c4:      	cmp	w10, #0x48
    37c8:      	mov	w12, #0x32              ; =50
    37cc:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000037cc:  ARM64_RELOC_PAGE21	l_str.655
    37d0:      	add	x2, x2, #0x0
		00000000000037d0:  ARM64_RELOC_PAGEOFF12	l_str.655
    37d4:      	b.eq	0x35cc <_gap_verify_graph+0x3568>
    37d8:      	b	0x3610 <_gap_verify_graph+0x35ac>
    37dc:      	mov	w12, #0x21              ; =33
    37e0:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000037e0:  ARM64_RELOC_PAGE21	l_str.654
    37e4:      	add	x2, x2, #0x0
		00000000000037e4:  ARM64_RELOC_PAGEOFF12	l_str.654
    37e8:      	cbnz	w8, 0x361c <_gap_verify_graph+0x35b8>
    37ec:      	b	0x3844 <_gap_verify_graph+0x37e0>
    37f0:      	mov	w25, #0x1d              ; =29
    37f4:      	b	0x9b4 <_gap_verify_graph+0x950>
    37f8:      	ldr	x9, [x19, #0x50]
    37fc:      	mvn	x8, x8
    3800:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003800:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3804:      	add	x16, x16, #0x0
		0000000000003804:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3808:      	ldr	w8, [x9, x8, lsl #2]
    380c:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000380c:  ARM64_RELOC_PAGE21	l_str.658
    3810:      	add	x9, x9, #0x0
		0000000000003810:  ARM64_RELOC_PAGEOFF12	l_str.658
    3814:      	cmp	w8, #0x0
    3818:      	adrp	x8, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003818:  ARM64_RELOC_PAGE21	l_str.657
    381c:      	add	x8, x8, #0x0
		000000000000381c:  ARM64_RELOC_PAGEOFF12	l_str.657
    3820:      	csel	x21, x9, x8, gt
    3824:      	mov	w8, #0x1d               ; =29
    3828:      	mov	w9, #0x34               ; =52
    382c:      	csel	x25, x9, x8, gt
    3830:      	b	0x9b4 <_gap_verify_graph+0x950>
    3834:      	mov	w12, #0x32              ; =50
    3838:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003838:  ARM64_RELOC_PAGE21	l_str.655
    383c:      	add	x2, x2, #0x0
		000000000000383c:  ARM64_RELOC_PAGEOFF12	l_str.655
    3840:      	cbnz	w8, 0x361c <_gap_verify_graph+0x35b8>
    3844:      	mov	x21, x2
    3848:      	mov	x25, x12
    384c:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		000000000000384c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3850:      	add	x16, x16, #0x0
		0000000000003850:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3854:      	cbnz	x12, 0x9b4 <_gap_verify_graph+0x950>
    3858:      	str	wzr, [sp, #0xa0]
    385c:      	mov	w0, w15
    3860:      	mov	x25, xzr
    3864:      	str	w0, [sp, #0xa8]
    3868:      	mov	w27, #0x1e              ; =30
    386c:      	b	0x9c4 <_gap_verify_graph+0x960>
    3870:      	mov	w12, #0x21              ; =33
    3874:      	b	0x35cc <_gap_verify_graph+0x3568>
    3878:      	ldr	x9, [sp]
    387c:      	cmp	w9, #0xd
    3880:      	b.hi	0x38e8 <_gap_verify_graph+0x3884>
    3884:      	ldr	x9, [sp]
    3888:      	cmp	w9, #0x0
    388c:      	cset	w9, ne
    3890:      	b	0x38ec <_gap_verify_graph+0x3888>
    3894:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003894:  ARM64_RELOC_PAGE21	l_str.661
    3898:      	add	x21, x21, #0x0
		0000000000003898:  ARM64_RELOC_PAGEOFF12	l_str.661
    389c:      	mov	w25, #0x2b              ; =43
    38a0:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000038a0:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    38a4:      	add	x16, x16, #0x0
		00000000000038a4:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    38a8:      	b	0x9b4 <_gap_verify_graph+0x950>
    38ac:      	cmp	w9, #0x10
    38b0:      	mov	w10, #0x10              ; =16
    38b4:      	sub	x0, x29, #0x80
    38b8:      	csel	w8, w9, w10, gt
    38bc:      	cmp	w12, #0x51
    38c0:      	mov	x1, x19
    38c4:      	csel	w3, w8, w10, eq
    38c8:      	bl	0x38c8 <_gap_verify_graph+0x3864>
		00000000000038c8:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    38cc:      	ldur	w8, [x29, #-0x80]
    38d0:      	ldur	x9, [x29, #-0x70]
    38d4:      	ldr	x10, [sp, #0x68]
    38d8:      	cmp	w8, #0x1
    38dc:      	cset	w8, eq
    38e0:      	csel	x21, x9, x10, eq
    38e4:      	b	0x28fc <_gap_verify_graph+0x2898>
    38e8:      	mov	w9, #-0x1               ; =-1
    38ec:      	cmp	x8, w9, sxtw
    38f0:      	ldp	x9, x11, [sp, #0x18]
    38f4:      	mov	w8, #0x28               ; =40
    38f8:      	csel	x10, x8, x11, hs
    38fc:      	adrp	x8, 0x3000 <_gap_verify_graph+0x2f9c>
		00000000000038fc:  ARM64_RELOC_PAGE21	l_str.675
    3900:      	add	x8, x8, #0x0
		0000000000003900:  ARM64_RELOC_PAGEOFF12	l_str.675
    3904:      	csel	x9, x8, x9, hs
    3908:      	stp	x9, x10, [sp, #0x18]
    390c:      	cmp	w21, #0x3d
    3910:      	b.eq	0x3248 <_gap_verify_graph+0x31e4>
    3914:      	ldr	x8, [sp, #0x40]
    3918:      	lsr	x8, x8, #32
    391c:      	cmp	w8, #0x1
    3920:      	b.lt	0x3a1c <_gap_verify_graph+0x39b8>
    3924:      	ldr	x9, [sp, #0x38]
    3928:      	cmp	x9, x8
    392c:      	b.ls	0x3a84 <_gap_verify_graph+0x3a20>
    3930:      	ldr	x9, [sp, #0x28]
    3934:      	ldr	x4, [sp, #0x50]
    3938:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003938:  ARM64_RELOC_PAGE21	l_str.676
    393c:      	add	x21, x21, #0x0
		000000000000393c:  ARM64_RELOC_PAGEOFF12	l_str.676
    3940:      	mov	w25, #0x20              ; =32
    3944:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003944:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3948:      	add	x16, x16, #0x0
		0000000000003948:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    394c:      	cmp	x9, x8
    3950:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003950:  ARM64_RELOC_PAGE21	l_str.688
    3954:      	add	x26, x26, #0x0
		0000000000003954:  ARM64_RELOC_PAGEOFF12	l_str.688
    3958:      	b.ls	0x9b4 <_gap_verify_graph+0x950>
    395c:      	ldr	w9, [x28, x8, lsl #2]
    3960:      	tbnz	w9, #0x1f, 0x3aa8 <_gap_verify_graph+0x3a44>
    3964:      	ldr	x9, [sp, #0x30]
    3968:      	add	x8, x9, x8, lsl #4
    396c:      	ldr	x8, [x8]
    3970:      	and	w9, w8, #0xff
    3974:      	cmp	w9, #0x46
    3978:      	b.eq	0x3a74 <_gap_verify_graph+0x3a10>
    397c:      	ldr	x4, [sp, #0x50]
    3980:      	cmp	w9, #0x48
    3984:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003984:  ARM64_RELOC_PAGE21	l_str.677
    3988:      	add	x21, x21, #0x0
		0000000000003988:  ARM64_RELOC_PAGEOFF12	l_str.677
    398c:      	mov	w25, #0x27              ; =39
    3990:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003990:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3994:      	add	x16, x16, #0x0
		0000000000003994:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3998:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003998:  ARM64_RELOC_PAGE21	l_str.688
    399c:      	add	x26, x26, #0x0
		000000000000399c:  ARM64_RELOC_PAGEOFF12	l_str.688
    39a0:      	b.eq	0x9b4 <_gap_verify_graph+0x950>
    39a4:      	ldr	w9, [sp, #0x48]
    39a8:      	cmp	w9, #0xe
    39ac:      	b.lo	0x3ab4 <_gap_verify_graph+0x3a50>
    39b0:      	ldp	w9, w10, [sp, #0xc]
    39b4:      	ubfx	w27, w8, #8, #8
    39b8:      	cmp	w10, #0x0
    39bc:      	sub	w8, w27, #0x1
    39c0:      	csinv	w0, w9, wzr, ne
    39c4:      	cmp	w8, #0xd
    39c8:      	csel	w8, wzr, w10, hs
    39cc:      	cbz	w8, 0x3ab4 <_gap_verify_graph+0x3a50>
    39d0:      	cmp	w0, w27
    39d4:      	b.eq	0x3248 <_gap_verify_graph+0x31e4>
    39d8:      	sub	w8, w0, #0x1
    39dc:      	cmp	w8, #0xa
    39e0:      	b.hi	0x3ab4 <_gap_verify_graph+0x3a50>
    39e4:      	ldr	x4, [sp, #0x50]
    39e8:      	cmp	w27, #0xb
    39ec:      	mov	w25, #0x27              ; =39
    39f0:      	b.hi	0x9b4 <_gap_verify_graph+0x950>
    39f4:      	bl	0x39f4 <_gap_verify_graph+0x3990>
		00000000000039f4:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    39f8:      	mov	w21, w0
    39fc:      	mov	w0, w27
    3a00:      	bl	0x3a00 <_gap_verify_graph+0x399c>
		0000000000003a00:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    3a04:      	cmp	w21, w0
    3a08:      	b.eq	0x3248 <_gap_verify_graph+0x31e4>
    3a0c:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003a0c:  ARM64_RELOC_PAGE21	l_str.677
    3a10:      	add	x21, x21, #0x0
		0000000000003a10:  ARM64_RELOC_PAGEOFF12	l_str.677
    3a14:      	mov	w25, #0x27              ; =39
    3a18:      	b	0x29dc <_gap_verify_graph+0x2978>
    3a1c:      	ldr	x9, [sp, #0x40]
    3a20:      	tbz	x9, #0x3f, 0x3a84 <_gap_verify_graph+0x3a20>
    3a24:      	ldr	x9, [x19, #0x30]
    3a28:      	ldr	x10, [x19, #0x58]
    3a2c:      	cmp	x9, x10
    3a30:      	b.ne	0x3a84 <_gap_verify_graph+0x3a20>
    3a34:      	ldr	x10, [sp, #0x40]
    3a38:      	asr	x10, x10, #32
    3a3c:      	cmn	x9, x10
    3a40:      	b.lt	0x3a84 <_gap_verify_graph+0x3a20>
    3a44:      	ldr	x9, [x19, #0x50]
    3a48:      	mvn	x10, x10
    3a4c:      	ldr	w9, [x9, x10, lsl #2]
    3a50:      	cmp	w9, #0x0
    3a54:      	b.le	0x3a84 <_gap_verify_graph+0x3a20>
    3a58:      	ldr	x9, [x19, #0x28]
    3a5c:      	eor	x8, x8, #0xffffffff
    3a60:      	add	x8, x9, x8, lsl #4
    3a64:      	ldr	x8, [x8]
    3a68:      	and	w9, w8, #0xff
    3a6c:      	cmp	w9, #0x46
    3a70:      	b.ne	0x397c <_gap_verify_graph+0x3918>
    3a74:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003a74:  ARM64_RELOC_PAGE21	l_str.677
    3a78:      	add	x21, x21, #0x0
		0000000000003a78:  ARM64_RELOC_PAGEOFF12	l_str.677
    3a7c:      	mov	w25, #0x27              ; =39
    3a80:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3a84:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003a84:  ARM64_RELOC_PAGE21	l_str.676
    3a88:      	add	x21, x21, #0x0
		0000000000003a88:  ARM64_RELOC_PAGEOFF12	l_str.676
    3a8c:      	mov	w25, #0x20              ; =32
    3a90:      	ldr	x4, [sp, #0x50]
    3a94:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003a94:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.METADATA
    3a98:      	add	x16, x16, #0x0
		0000000000003a98:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.METADATA
    3a9c:      	adrp	x26, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003a9c:  ARM64_RELOC_PAGE21	l_str.688
    3aa0:      	add	x26, x26, #0x0
		0000000000003aa0:  ARM64_RELOC_PAGEOFF12	l_str.688
    3aa4:      	b	0x9b4 <_gap_verify_graph+0x950>
    3aa8:      	ldr	x4, [sp, #0x50]
    3aac:      	mov	w25, #0x20              ; =32
    3ab0:      	b	0x9b4 <_gap_verify_graph+0x950>
    3ab4:      	ldr	x4, [sp, #0x50]
    3ab8:      	mov	w25, #0x27              ; =39
    3abc:      	b	0x9b4 <_gap_verify_graph+0x950>
    3ac0:      	mov	w12, #0x21              ; =33
    3ac4:      	cbnz	w8, 0x361c <_gap_verify_graph+0x35b8>
    3ac8:      	b	0x3844 <_gap_verify_graph+0x37e0>
    3acc:      	mov	w25, #0x33              ; =51
    3ad0:      	b	0x2c28 <_gap_verify_graph+0x2bc4>
    3ad4:      	mov	w14, #0x37              ; =55
    3ad8:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003ad8:  ARM64_RELOC_PAGE21	l_str.653
    3adc:      	add	x2, x2, #0x0
		0000000000003adc:  ARM64_RELOC_PAGEOFF12	l_str.653
    3ae0:      	mov	x1, x3
    3ae4:      	b	0x2aec <_gap_verify_graph+0x2a88>
    3ae8:      	mov	w21, #0x2               ; =2
    3aec:      	mov	x0, x19
    3af0:      	mov	w1, w20
    3af4:      	mov	w2, w21
    3af8:      	bl	0x3af8 <_gap_verify_graph+0x3a94>
		0000000000003af8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    3afc:      	cbz	w0, 0x3b38 <_gap_verify_graph+0x3ad4>
    3b00:      	mov	x2, x1
    3b04:      	sub	x0, x29, #0x80
    3b08:      	mov	x1, x19
    3b0c:      	bl	0x3b0c <_gap_verify_graph+0x3aa8>
		0000000000003b0c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3b10:      	ldur	w8, [x29, #-0x80]
    3b14:      	cbz	w8, 0x3b48 <_gap_verify_graph+0x3ae4>
    3b18:      	ldurb	w8, [x29, #-0x77]
    3b1c:      	ldr	w9, [sp, #0x48]
    3b20:      	cmp	w8, w9
    3b24:      	b.ne	0x3b58 <_gap_verify_graph+0x3af4>
    3b28:      	add	w21, w21, #0x1
    3b2c:      	cmp	w21, w27
    3b30:      	b.le	0x3aec <_gap_verify_graph+0x3a88>
    3b34:      	b	0x3384 <_gap_verify_graph+0x3320>
    3b38:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003b38:  ARM64_RELOC_PAGE21	l_str.697
    3b3c:      	add	x21, x21, #0x0
		0000000000003b3c:  ARM64_RELOC_PAGEOFF12	l_str.697
    3b40:      	mov	w25, #0x18              ; =24
    3b44:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3b48:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003b48:  ARM64_RELOC_PAGE21	l_str.698
    3b4c:      	add	x21, x21, #0x0
		0000000000003b4c:  ARM64_RELOC_PAGEOFF12	l_str.698
    3b50:      	mov	w25, #0x18              ; =24
    3b54:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3b58:      	adrp	x21, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003b58:  ARM64_RELOC_PAGE21	l_str.699
    3b5c:      	add	x21, x21, #0x0
		0000000000003b5c:  ARM64_RELOC_PAGEOFF12	l_str.699
    3b60:      	mov	w25, #0x1e              ; =30
    3b64:      	b	0x3a90 <_gap_verify_graph+0x3a2c>
    3b68:      	mov	x0, #-0x1               ; =-1
    3b6c:      	add	sp, sp, #0x1d0
    3b70:      	ldp	x29, x30, [sp, #0x50]
    3b74:      	ldp	x20, x19, [sp, #0x40]
    3b78:      	ldp	x22, x21, [sp, #0x30]
    3b7c:      	ldp	x24, x23, [sp, #0x20]
    3b80:      	ldp	x26, x25, [sp, #0x10]
    3b84:      	ldp	x28, x27, [sp], #0x60
    3b88:      	ret

0000000000003b8c <_stogir.checked.validate>:
    3b8c:      	cmp	w2, #0x1
    3b90:      	b.lt	0x3d18 <_stogir.checked.validate+0x18c>
    3b94:      	ldr	x13, [x1, #0x8]
    3b98:      	mov	w10, w2
    3b9c:      	cmp	x13, x10
    3ba0:      	b.le	0x3d68 <_stogir.checked.validate+0x1dc>
    3ba4:      	ldr	x14, [x1, #0x80]
    3ba8:      	cmp	x14, x10
    3bac:      	b.le	0x3d68 <_stogir.checked.validate+0x1dc>
    3bb0:      	ldr	x8, [x1, #0x78]
    3bb4:      	ldr	w11, [x8, x10, lsl #2]
    3bb8:      	tbnz	w11, #0x1f, 0x3d68 <_stogir.checked.validate+0x1dc>
    3bbc:      	ldr	x9, [x1]
    3bc0:      	cmp	w11, #0x2
    3bc4:      	add	x12, x9, x10, lsl #4
    3bc8:      	ldr	x15, [x12]
    3bcc:      	and	w10, w15, #0xff
    3bd0:      	sub	w10, w10, #0x29
    3bd4:      	ccmp	w10, #0x3, #0x2, eq
    3bd8:      	b.hs	0x3d4c <_stogir.checked.validate+0x1c0>
    3bdc:      	sub	sp, sp, #0x10
    3be0:      	ubfx	w10, w15, #8, #8
    3be4:      	lsr	x15, x15, #32
    3be8:      	ldr	x12, [x12, #0x8]
    3bec:      	mov	w16, #0x36              ; =54
    3bf0:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003bf0:  ARM64_RELOC_PAGE21	l_str.363
    3bf4:      	add	x2, x2, #0x0
		0000000000003bf4:  ARM64_RELOC_PAGEOFF12	l_str.363
    3bf8:      	sub	w17, w10, #0xc
    3bfc:      	mov	x11, xzr
    3c00:      	stp	w15, w12, [sp, #0x8]
    3c04:      	cmn	w17, #0xa
    3c08:      	adrp	x17, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003c08:  ARM64_RELOC_PAGE21	l_str.364
    3c0c:      	add	x17, x17, #0x0
		0000000000003c0c:  ARM64_RELOC_PAGEOFF12	l_str.364
    3c10:      	csel	x4, x16, xzr, lo
    3c14:      	csel	x5, x17, x2, lo
    3c18:      	cmp	x13, x14
    3c1c:      	add	x12, sp, #0x8
    3c20:      	csel	x13, x13, x14, lt
    3c24:      	adrp	x14, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003c24:  ARM64_RELOC_PAGE21	l_str.365
    3c28:      	add	x14, x14, #0x0
		0000000000003c28:  ARM64_RELOC_PAGEOFF12	l_str.365
    3c2c:      	mov	w15, #0x28              ; =40
    3c30:      	adrp	x16, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003c30:  ARM64_RELOC_PAGE21	l_str.366
    3c34:      	add	x16, x16, #0x0
		0000000000003c34:  ARM64_RELOC_PAGEOFF12	l_str.366
    3c38:      	b	0x3c48 <_stogir.checked.validate+0xbc>
    3c3c:      	mov	w4, #0x22               ; =34
    3c40:      	mov	x5, x14
    3c44:      	tbnz	w3, #0x1f, 0x3cbc <_stogir.checked.validate+0x130>
    3c48:      	cmp	x11, #0x1
    3c4c:      	mov	x17, x5
    3c50:      	mov	x2, x4
    3c54:      	b.gt	0x3c6c <_stogir.checked.validate+0xe0>
    3c58:      	ldr	w3, [x12, x11, lsl #2]
    3c5c:      	add	x11, x11, #0x1
    3c60:      	mov	w4, #0x1                ; =1
    3c64:      	cbnz	w4, 0x3c78 <_stogir.checked.validate+0xec>
    3c68:      	b	0x3d84 <_stogir.checked.validate+0x1f8>
    3c6c:      	mov	x4, xzr
    3c70:      	mov	w11, #0x2               ; =2
    3c74:      	cbz	w4, 0x3d84 <_stogir.checked.validate+0x1f8>
    3c78:      	cmp	w3, #0x1
    3c7c:      	b.lt	0x3c3c <_stogir.checked.validate+0xb0>
    3c80:      	and	x3, x3, #0x7fffffff
    3c84:      	mov	w4, #0x22               ; =34
    3c88:      	mov	x5, x14
    3c8c:      	cmp	x3, x13
    3c90:      	b.ge	0x3c48 <_stogir.checked.validate+0xbc>
    3c94:      	ldr	w6, [x8, x3, lsl #2]
    3c98:      	mov	w4, #0x22               ; =34
    3c9c:      	mov	x5, x14
    3ca0:      	tbnz	w6, #0x1f, 0x3c48 <_stogir.checked.validate+0xbc>
    3ca4:      	add	x3, x9, x3, lsl #4
    3ca8:      	ldrb	w3, [x3, #0x1]
    3cac:      	cmp	w3, w10
    3cb0:      	csel	x4, x2, x15, eq
    3cb4:      	csel	x5, x17, x16, eq
    3cb8:      	b	0x3c48 <_stogir.checked.validate+0xbc>
    3cbc:      	ldr	x6, [x1, #0x30]
    3cc0:      	ldr	x4, [x1, #0x58]
    3cc4:      	mov	x5, x14
    3cc8:      	cmp	x6, x4
    3ccc:      	mov	w4, #0x22               ; =34
    3cd0:      	b.ne	0x3c48 <_stogir.checked.validate+0xbc>
    3cd4:      	sxtw	x7, w3
    3cd8:      	mov	w4, #0x22               ; =34
    3cdc:      	mov	x5, x14
    3ce0:      	cmn	x6, x7
    3ce4:      	b.lt	0x3c48 <_stogir.checked.validate+0xbc>
    3ce8:      	ldr	x4, [x1, #0x50]
    3cec:      	mvn	x5, x7
    3cf0:      	ldr	w4, [x4, x5, lsl #2]
    3cf4:      	mov	x5, x14
    3cf8:      	cmp	w4, #0x0
    3cfc:      	mov	w4, #0x22               ; =34
    3d00:      	b.le	0x3c48 <_stogir.checked.validate+0xbc>
    3d04:      	mvn	w3, w3
    3d08:      	ldr	x4, [x1, #0x28]
    3d0c:      	and	x3, x3, #0x7fffffff
    3d10:      	add	x3, x4, x3, lsl #4
    3d14:      	b	0x3ca8 <_stogir.checked.validate+0x11c>
    3d18:      	tbz	w2, #0x1f, 0x3d68 <_stogir.checked.validate+0x1dc>
    3d1c:      	ldr	x8, [x1, #0x30]
    3d20:      	ldr	x9, [x1, #0x58]
    3d24:      	cmp	x8, x9
    3d28:      	b.ne	0x3d68 <_stogir.checked.validate+0x1dc>
    3d2c:      	sxtw	x9, w2
    3d30:      	cmn	x8, x9
    3d34:      	b.lt	0x3d68 <_stogir.checked.validate+0x1dc>
    3d38:      	ldr	x8, [x1, #0x50]
    3d3c:      	mvn	x9, x9
    3d40:      	ldr	w8, [x8, x9, lsl #2]
    3d44:      	cmp	w8, #0x0
    3d48:      	b.le	0x3d68 <_stogir.checked.validate+0x1dc>
    3d4c:      	mov	w8, #0x1                ; =1
    3d50:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003d50:  ARM64_RELOC_PAGE21	l_str.373
    3d54:      	add	x9, x9, #0x0
		0000000000003d54:  ARM64_RELOC_PAGEOFF12	l_str.373
    3d58:      	str	w8, [x0]
    3d5c:      	mov	w8, #0x26               ; =38
    3d60:      	stp	x9, x8, [x0, #0x8]
    3d64:      	ret
    3d68:      	mov	w8, #0x1                ; =1
    3d6c:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003d6c:  ARM64_RELOC_PAGE21	l_str.372
    3d70:      	add	x9, x9, #0x0
		0000000000003d70:  ARM64_RELOC_PAGEOFF12	l_str.372
    3d74:      	str	w8, [x0]
    3d78:      	mov	w8, #0x1a               ; =26
    3d7c:      	stp	x9, x8, [x0, #0x8]
    3d80:      	ret
    3d84:      	add	sp, sp, #0x10
    3d88:      	cbz	x2, 0x3d9c <_stogir.checked.validate+0x210>
    3d8c:      	mov	w8, #0x1                ; =1
    3d90:      	stp	x17, x2, [x0, #0x8]
    3d94:      	str	w8, [x0]
    3d98:      	ret
    3d9c:      	str	w10, [x0, #0x8]
    3da0:      	str	wzr, [x0]
    3da4:      	ret

0000000000003da8 <_stogir.conditional.validate>:
    3da8:      	cmp	w2, #0x1
    3dac:      	b.lt	0x3e28 <_stogir.conditional.validate+0x80>
    3db0:      	ldr	x11, [x1, #0x8]
    3db4:      	mov	w10, w2
    3db8:      	cmp	x11, x10
    3dbc:      	b.le	0x3e78 <_stogir.conditional.validate+0xd0>
    3dc0:      	ldr	x12, [x1, #0x80]
    3dc4:      	cmp	x12, x10
    3dc8:      	b.le	0x3e78 <_stogir.conditional.validate+0xd0>
    3dcc:      	ldr	x8, [x1, #0x78]
    3dd0:      	ldr	w13, [x8, x10, lsl #2]
    3dd4:      	tbnz	w13, #0x1f, 0x3e78 <_stogir.conditional.validate+0xd0>
    3dd8:      	ldr	x9, [x1]
    3ddc:      	cmp	w13, #0x3
    3de0:      	mov	w13, #0x3c              ; =60
    3de4:      	add	x14, x9, x10, lsl #4
    3de8:      	ldr	x17, [x14]
    3dec:      	and	x10, x17, #0xff
    3df0:      	ccmp	x10, x13, #0x0, eq
    3df4:      	b.ne	0x3e5c <_stogir.conditional.validate+0xb4>
    3df8:      	ubfx	w10, w17, #8, #8
    3dfc:      	lsr	x16, x17, #32
    3e00:      	adrp	x13, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003e00:  ARM64_RELOC_PAGE21	l_str.378
    3e04:      	add	x13, x13, #0x0
		0000000000003e04:  ARM64_RELOC_PAGEOFF12	l_str.378
    3e08:      	cbz	w10, 0x3e94 <_stogir.conditional.validate+0xec>
    3e0c:      	cmp	w10, #0xe
    3e10:      	adrp	x2, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003e10:  ARM64_RELOC_PAGE21	l_str.377
    3e14:      	add	x2, x2, #0x0
		0000000000003e14:  ARM64_RELOC_PAGEOFF12	l_str.377
    3e18:      	b.hs	0x3e9c <_stogir.conditional.validate+0xf4>
    3e1c:      	mov	x15, xzr
    3e20:      	mov	x13, x2
    3e24:      	b	0x3ec4 <_stogir.conditional.validate+0x11c>
    3e28:      	tbz	w2, #0x1f, 0x3e78 <_stogir.conditional.validate+0xd0>
    3e2c:      	ldr	x8, [x1, #0x30]
    3e30:      	ldr	x9, [x1, #0x58]
    3e34:      	cmp	x8, x9
    3e38:      	b.ne	0x3e78 <_stogir.conditional.validate+0xd0>
    3e3c:      	sxtw	x9, w2
    3e40:      	cmn	x8, x9
    3e44:      	b.lt	0x3e78 <_stogir.conditional.validate+0xd0>
    3e48:      	ldr	x8, [x1, #0x50]
    3e4c:      	mvn	x9, x9
    3e50:      	ldr	w8, [x8, x9, lsl #2]
    3e54:      	cmp	w8, #0x0
    3e58:      	b.le	0x3e78 <_stogir.conditional.validate+0xd0>
    3e5c:      	mov	w8, #0x1                ; =1
    3e60:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003e60:  ARM64_RELOC_PAGE21	l_str.385
    3e64:      	add	x9, x9, #0x0
		0000000000003e64:  ARM64_RELOC_PAGEOFF12	l_str.385
    3e68:      	str	w8, [x0]
    3e6c:      	mov	w8, #0x18               ; =24
    3e70:      	stp	x9, x8, [x0, #0x8]
    3e74:      	ret
    3e78:      	mov	w8, #0x1                ; =1
    3e7c:      	adrp	x9, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003e7c:  ARM64_RELOC_PAGE21	l_str.384
    3e80:      	add	x9, x9, #0x0
		0000000000003e80:  ARM64_RELOC_PAGEOFF12	l_str.384
    3e84:      	str	w8, [x0]
    3e88:      	mov	w8, #0x18               ; =24
    3e8c:      	stp	x9, x8, [x0, #0x8]
    3e90:      	ret
    3e94:      	mov	w15, #0x2b              ; =43
    3e98:      	b	0x3ec4 <_stogir.conditional.validate+0x11c>
    3e9c:      	ubfx	w15, w17, #8, #4
    3ea0:      	sub	w3, w10, #0x80
    3ea4:      	cmn	w3, #0x70
    3ea8:      	sub	w15, w15, #0xe
    3eac:      	ccmn	w15, #0xd, #0x0, hs
    3eb0:      	cset	w15, lo
    3eb4:      	cmp	w15, #0x0
    3eb8:      	mov	w15, #0x2b              ; =43
    3ebc:      	csel	x15, x15, xzr, ne
    3ec0:      	csel	x13, x13, x2, ne
    3ec4:      	ldr	x14, [x14, #0x8]
    3ec8:      	cmp	w16, #0x1
    3ecc:      	b.lt	0x3f44 <_stogir.conditional.validate+0x19c>
    3ed0:      	cmp	x11, x16
    3ed4:      	adrp	x3, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003ed4:  ARM64_RELOC_PAGE21	l_str.379
    3ed8:      	add	x3, x3, #0x0
		0000000000003ed8:  ARM64_RELOC_PAGEOFF12	l_str.379
    3edc:      	mov	w4, #0x16               ; =22
    3ee0:      	b.ls	0x3f94 <_stogir.conditional.validate+0x1ec>
    3ee4:      	cmp	x12, x16
    3ee8:      	b.ls	0x3f94 <_stogir.conditional.validate+0x1ec>
    3eec:      	ldr	w17, [x8, x16, lsl #2]
    3ef0:      	tbnz	w17, #0x1f, 0x3f90 <_stogir.conditional.validate+0x1e8>
    3ef4:      	add	x16, x9, x16, lsl #4
    3ef8:      	ldr	x16, [x16]
    3efc:      	adrp	x3, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003efc:  ARM64_RELOC_PAGE21	l_str.380
    3f00:      	add	x3, x3, #0x0
		0000000000003f00:  ARM64_RELOC_PAGEOFF12	l_str.380
    3f04:      	mov	w4, #0x2a               ; =42
    3f08:      	and	w17, w16, #0xff
    3f0c:      	cmp	w17, #0x48
    3f10:      	b.eq	0x3f94 <_stogir.conditional.validate+0x1ec>
    3f14:      	cmp	w17, #0x46
    3f18:      	b.eq	0x3f94 <_stogir.conditional.validate+0x1ec>
    3f1c:      	tst	x16, #0xff00
    3f20:      	and	x16, x16, #0xfe00
    3f24:      	mov	w17, #0xdff             ; =3583
    3f28:      	ccmp	x16, x17, #0x2, ne
    3f2c:      	cset	w16, hi
    3f30:      	cmp	w16, #0x0
    3f34:      	mov	w16, #0x2a              ; =42
    3f38:      	csel	x4, x16, x15, ne
    3f3c:      	csel	x3, x3, x13, ne
    3f40:      	b	0x3f94 <_stogir.conditional.validate+0x1ec>
    3f44:      	tbz	x17, #0x3f, 0x3f88 <_stogir.conditional.validate+0x1e0>
    3f48:      	ldr	x2, [x1, #0x30]
    3f4c:      	ldr	x3, [x1, #0x58]
    3f50:      	cmp	x2, x3
    3f54:      	b.ne	0x3f88 <_stogir.conditional.validate+0x1e0>
    3f58:      	asr	x17, x17, #32
    3f5c:      	cmn	x2, x17
    3f60:      	b.lt	0x3f88 <_stogir.conditional.validate+0x1e0>
    3f64:      	ldr	x2, [x1, #0x50]
    3f68:      	mvn	x17, x17
    3f6c:      	ldr	w17, [x2, x17, lsl #2]
    3f70:      	cmp	w17, #0x0
    3f74:      	b.le	0x3f88 <_stogir.conditional.validate+0x1e0>
    3f78:      	ldr	x17, [x1, #0x28]
    3f7c:      	eor	x16, x16, #0xffffffff
    3f80:      	add	x16, x17, x16, lsl #4
    3f84:      	b	0x3ef8 <_stogir.conditional.validate+0x150>
    3f88:      	adrp	x3, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003f88:  ARM64_RELOC_PAGE21	l_str.379
    3f8c:      	add	x3, x3, #0x0
		0000000000003f8c:  ARM64_RELOC_PAGEOFF12	l_str.379
    3f90:      	mov	w4, #0x16               ; =22
    3f94:      	sub	sp, sp, #0x10
    3f98:      	cmp	x11, x12
    3f9c:      	mov	x13, xzr
    3fa0:      	str	x14, [sp, #0x8]
    3fa4:      	add	x14, sp, #0x8
    3fa8:      	csel	x11, x11, x12, lt
    3fac:      	adrp	x12, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003fac:  ARM64_RELOC_PAGE21	l_str.381
    3fb0:      	add	x12, x12, #0x0
		0000000000003fb0:  ARM64_RELOC_PAGEOFF12	l_str.381
    3fb4:      	adrp	x15, 0x3000 <_gap_verify_graph+0x2f9c>
		0000000000003fb4:  ARM64_RELOC_PAGE21	l_str.382
    3fb8:      	add	x15, x15, #0x0
		0000000000003fb8:  ARM64_RELOC_PAGEOFF12	l_str.382
    3fbc:      	mov	w16, #0x21              ; =33
    3fc0:      	b	0x3fd0 <_stogir.conditional.validate+0x228>
    3fc4:      	mov	w4, #0x10               ; =16
    3fc8:      	mov	x3, x12
    3fcc:      	tbnz	w5, #0x1f, 0x406c <_stogir.conditional.validate+0x2c4>
    3fd0:      	cmp	x13, #0x1
    3fd4:      	mov	x17, x3
    3fd8:      	mov	x2, x4
    3fdc:      	b.gt	0x3ff4 <_stogir.conditional.validate+0x24c>
    3fe0:      	ldr	w5, [x14, x13, lsl #2]
    3fe4:      	add	x13, x13, #0x1
    3fe8:      	mov	w3, #0x1                ; =1
    3fec:      	cbnz	w3, 0x4000 <_stogir.conditional.validate+0x258>
    3ff0:      	b	0x40e0 <_stogir.conditional.validate+0x338>
    3ff4:      	mov	x3, xzr
    3ff8:      	mov	w13, #0x2               ; =2
    3ffc:      	cbz	w3, 0x40e0 <_stogir.conditional.validate+0x338>
    4000:      	cmp	w5, #0x1
    4004:      	b.lt	0x3fc4 <_stogir.conditional.validate+0x21c>
    4008:      	and	x5, x5, #0x7fffffff
    400c:      	mov	w4, #0x10               ; =16
    4010:      	mov	x3, x12
    4014:      	cmp	x5, x11
    4018:      	b.ge	0x3fd0 <_stogir.conditional.validate+0x228>
    401c:      	ldr	w6, [x8, x5, lsl #2]
    4020:      	mov	w4, #0x10               ; =16
    4024:      	mov	x3, x12
    4028:      	tbnz	w6, #0x1f, 0x3fd0 <_stogir.conditional.validate+0x228>
    402c:      	add	x3, x9, x5, lsl #4
    4030:      	ldr	x5, [x3]
    4034:      	mov	w4, #0x21               ; =33
    4038:      	mov	x3, x15
    403c:      	and	w6, w5, #0xff
    4040:      	cmp	w6, #0x46
    4044:      	b.eq	0x3fd0 <_stogir.conditional.validate+0x228>
    4048:      	cmp	w6, #0x48
    404c:      	mov	w4, #0x21               ; =33
    4050:      	mov	x3, x15
    4054:      	b.eq	0x3fd0 <_stogir.conditional.validate+0x228>
    4058:      	ubfx	w3, w5, #8, #8
    405c:      	cmp	w3, w10
    4060:      	csel	x4, x16, x2, ne
    4064:      	csel	x3, x15, x17, ne
    4068:      	b	0x3fd0 <_stogir.conditional.validate+0x228>
    406c:      	ldr	x6, [x1, #0x30]
    4070:      	ldr	x3, [x1, #0x58]
    4074:      	mov	w4, #0x10               ; =16
    4078:      	cmp	x6, x3
    407c:      	mov	x3, x12
    4080:      	b.ne	0x3fd0 <_stogir.conditional.validate+0x228>
    4084:      	sxtw	x7, w5
    4088:      	mov	w4, #0x10               ; =16
    408c:      	mov	x3, x12
    4090:      	cmn	x6, x7
    4094:      	b.lt	0x3fd0 <_stogir.conditional.validate+0x228>
    4098:      	ldr	x3, [x1, #0x50]
    409c:      	mvn	x4, x7
    40a0:      	ldr	w3, [x3, x4, lsl #2]
    40a4:      	mov	w4, #0x10               ; =16
    40a8:      	cmp	w3, #0x0
    40ac:      	mov	x3, x12
    40b0:      	b.le	0x3fd0 <_stogir.conditional.validate+0x228>
    40b4:      	mvn	w3, w5
    40b8:      	ldr	x4, [x1, #0x28]
    40bc:      	and	x3, x3, #0x7fffffff
    40c0:      	add	x3, x4, x3, lsl #4
    40c4:      	ldr	x5, [x3]
    40c8:      	mov	w4, #0x21               ; =33
    40cc:      	mov	x3, x15
    40d0:      	and	w6, w5, #0xff
    40d4:      	cmp	w6, #0x46
    40d8:      	b.ne	0x4048 <_stogir.conditional.validate+0x2a0>
    40dc:      	b	0x3fd0 <_stogir.conditional.validate+0x228>
    40e0:      	add	sp, sp, #0x10
    40e4:      	cbz	x2, 0x40f8 <_stogir.conditional.validate+0x350>
    40e8:      	mov	w8, #0x1                ; =1
    40ec:      	stp	x17, x2, [x0, #0x8]
    40f0:      	str	w8, [x0]
    40f4:      	ret
    40f8:      	str	w10, [x0, #0x8]
    40fc:      	str	wzr, [x0]
    4100:      	ret

0000000000004104 <_stogir.conversion.policy>:
    4104:      	cmp	w1, #0x24
    4108:      	b.ne	0x41c0 <_stogir.conversion.policy+0xbc>
    410c:      	and	w8, w2, #0xf
    4110:      	sub	w10, w2, #0x10
    4114:      	sub	w9, w8, #0x1
    4118:      	cmp	w9, #0xd
    411c:      	mov	w9, #0x70               ; =112
    4120:      	ccmp	w10, w9, #0x2, lo
    4124:      	b.hs	0x4190 <_stogir.conversion.policy+0x8c>
    4128:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004128:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size
    412c:      	add	x9, x9, #0x0
		000000000000412c:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size
    4130:      	add	x8, x9, w8, uxtw
    4134:      	lsr	w9, w2, #4
    4138:      	ldurb	w8, [x8, #-0x1]
    413c:      	sub	w9, w9, #0x1
    4140:      	lsl	w8, w8, w9
    4144:      	lsl	w8, w8, #3
    4148:      	and	w9, w3, #0xf
    414c:      	sub	w11, w3, #0x10
    4150:      	sub	w10, w9, #0x1
    4154:      	cmp	w10, #0xd
    4158:      	mov	w10, #0x70              ; =112
    415c:      	ccmp	w11, w10, #0x2, lo
    4160:      	b.hs	0x4210 <_stogir.conversion.policy+0x10c>
    4164:      	adrp	x10, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004164:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size
    4168:      	add	x10, x10, #0x0
		0000000000004168:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size
    416c:      	add	x9, x10, w9, uxtw
    4170:      	lsr	w10, w3, #4
    4174:      	ldurb	w9, [x9, #-0x1]
    4178:      	sub	w10, w10, #0x1
    417c:      	lsl	w9, w9, w10
    4180:      	lsl	w9, w9, #3
    4184:      	cmp	w8, #0x1
    4188:      	b.ge	0x42a8 <_stogir.conversion.policy+0x1a4>
    418c:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4190:      	and	w8, w3, #0xf
    4194:      	sub	w10, w3, #0x10
    4198:      	sub	w8, w8, #0x1
    419c:      	cmp	w8, #0xd
    41a0:      	ccmp	w10, w9, #0x2, lo
    41a4:      	b.hs	0x41c0 <_stogir.conversion.policy+0xbc>
    41a8:      	cmp	w2, #0xe
    41ac:      	b.hs	0x4264 <_stogir.conversion.policy+0x160>
    41b0:      	adrp	x8, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000041b0:  ARM64_RELOC_PAGE21	l_switch.table.stogir.conversion.policy.22
    41b4:      	add	x8, x8, #0x0
		00000000000041b4:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.conversion.policy.22
    41b8:      	ldrb	w8, [x8, w2, uxtw]
    41bc:      	b	0x4148 <_stogir.conversion.policy+0x44>
    41c0:      	cmp	w2, #0xe
    41c4:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000041c4:  ARM64_RELOC_PAGE21	l_switch.table.stogir.conversion.policy.22
    41c8:      	add	x9, x9, #0x0
		00000000000041c8:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.conversion.policy.22
    41cc:      	b.hs	0x41f0 <_stogir.conversion.policy+0xec>
    41d0:      	ldrb	w8, [x9, w2, uxtw]
    41d4:      	cmp	w3, #0xd
    41d8:      	b.ls	0x41fc <_stogir.conversion.policy+0xf8>
    41dc:      	mov	w9, #-0x8               ; =-8
    41e0:      	sub	w10, w1, #0x21
    41e4:      	cmp	w10, #0x6
    41e8:      	b.ls	0x42a0 <_stogir.conversion.policy+0x19c>
    41ec:      	b	0x4388 <_stogir.conversion.policy+0x284>
    41f0:      	mov	w8, #-0x8               ; =-8
    41f4:      	cmp	w3, #0xd
    41f8:      	b.hi	0x41dc <_stogir.conversion.policy+0xd8>
    41fc:      	ldrb	w9, [x9, w3, uxtw]
    4200:      	sub	w10, w1, #0x21
    4204:      	cmp	w10, #0x6
    4208:      	b.ls	0x42a0 <_stogir.conversion.policy+0x19c>
    420c:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4210:      	cmp	w3, #0x6
    4214:      	mov	w9, #0x8                ; =8
    4218:      	b.le	0x4244 <_stogir.conversion.policy+0x140>
    421c:      	cmp	w3, #0x9
    4220:      	b.le	0x426c <_stogir.conversion.policy+0x168>
    4224:      	sub	w9, w3, #0xb
    4228:      	cmp	w9, #0x2
    422c:      	b.lo	0x429c <_stogir.conversion.policy+0x198>
    4230:      	cmp	w3, #0xa
    4234:      	b.eq	0x437c <_stogir.conversion.policy+0x278>
    4238:      	cmp	w3, #0xd
    423c:      	b.eq	0x437c <_stogir.conversion.policy+0x278>
    4240:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4244:      	cmp	w3, #0x3
    4248:      	b.gt	0x4290 <_stogir.conversion.policy+0x18c>
    424c:      	sub	w10, w3, #0x1
    4250:      	cmp	w10, #0x2
    4254:      	b.lo	0x42a0 <_stogir.conversion.policy+0x19c>
    4258:      	cmp	w3, #0x3
    425c:      	b.eq	0x4280 <_stogir.conversion.policy+0x17c>
    4260:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4264:      	mov	w8, #-0x8               ; =-8
    4268:      	b	0x4148 <_stogir.conversion.policy+0x44>
    426c:      	sub	w10, w3, #0x7
    4270:      	cmp	w10, #0x2
    4274:      	b.lo	0x42a0 <_stogir.conversion.policy+0x19c>
    4278:      	cmp	w3, #0x9
    427c:      	b.ne	0x4388 <_stogir.conversion.policy+0x284>
    4280:      	mov	w9, #0x10               ; =16
    4284:      	cmp	w8, #0x1
    4288:      	b.ge	0x42a8 <_stogir.conversion.policy+0x1a4>
    428c:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4290:      	sub	w9, w3, #0x5
    4294:      	cmp	w9, #0x2
    4298:      	b.hs	0x4374 <_stogir.conversion.policy+0x270>
    429c:      	mov	w9, #0x40               ; =64
    42a0:      	cmp	w8, #0x1
    42a4:      	b.lt	0x4388 <_stogir.conversion.policy+0x284>
    42a8:      	cmp	w9, #0x1
    42ac:      	b.lt	0x4388 <_stogir.conversion.policy+0x284>
    42b0:      	sub	w10, w1, #0x25
    42b4:      	cmp	w10, #0x2
    42b8:      	b.hi	0x42e4 <_stogir.conversion.policy+0x1e0>
    42bc:      	cmp	w1, #0x27
    42c0:      	b.eq	0x4328 <_stogir.conversion.policy+0x224>
    42c4:      	cmp	w1, #0x26
    42c8:      	b.ne	0x4340 <_stogir.conversion.policy+0x23c>
    42cc:      	sub	w10, w3, #0x1
    42d0:      	and	w11, w2, #0xfe
    42d4:      	cmp	w10, #0xb
    42d8:      	ccmp	w11, #0xc, #0x0, lo
    42dc:      	b.eq	0x4360 <_stogir.conversion.policy+0x25c>
    42e0:      	b	0x4388 <_stogir.conversion.policy+0x284>
    42e4:      	cmp	w1, #0x24
    42e8:      	b.ne	0x42f8 <_stogir.conversion.policy+0x1f4>
    42ec:      	cmp	w8, w9
    42f0:      	b.eq	0x4360 <_stogir.conversion.policy+0x25c>
    42f4:      	b	0x4388 <_stogir.conversion.policy+0x284>
    42f8:      	sub	w10, w3, #0x1
    42fc:      	sub	w11, w2, #0x1
    4300:      	cmp	w10, #0xb
    4304:      	ccmp	w11, #0xb, #0x2, lo
    4308:      	b.hs	0x4388 <_stogir.conversion.policy+0x284>
    430c:      	cmp	w1, #0x23
    4310:      	b.ne	0x4358 <_stogir.conversion.policy+0x254>
    4314:      	cmp	w9, w8
    4318:      	b.hs	0x4388 <_stogir.conversion.policy+0x284>
    431c:      	str	wzr, [x0]
    4320:      	str	w9, [x0, #0x8]
    4324:      	ret
    4328:      	and	w10, w3, #0xfe
    432c:      	and	w11, w2, #0xfe
    4330:      	cmp	w10, #0xc
    4334:      	ccmp	w11, #0xc, #0x0, eq
    4338:      	b.eq	0x4360 <_stogir.conversion.policy+0x25c>
    433c:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4340:      	and	w10, w3, #0xfe
    4344:      	sub	w11, w2, #0x1
    4348:      	cmp	w10, #0xc
    434c:      	ccmp	w11, #0xb, #0x2, eq
    4350:      	b.lo	0x4360 <_stogir.conversion.policy+0x25c>
    4354:      	b	0x4388 <_stogir.conversion.policy+0x284>
    4358:      	cmp	w9, w8
    435c:      	b.ls	0x4388 <_stogir.conversion.policy+0x284>
    4360:      	cmp	w1, #0x26
    4364:      	str	wzr, [x0]
    4368:      	csel	w9, w9, w8, eq
    436c:      	str	w9, [x0, #0x8]
    4370:      	ret
    4374:      	cmp	w3, #0x4
    4378:      	b.ne	0x4388 <_stogir.conversion.policy+0x284>
    437c:      	mov	w9, #0x20               ; =32
    4380:      	cmp	w8, #0x1
    4384:      	b.ge	0x42a8 <_stogir.conversion.policy+0x1a4>
    4388:      	mov	w8, #0x1                ; =1
    438c:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		000000000000438c:  ARM64_RELOC_PAGE21	l_str.391
    4390:      	add	x9, x9, #0x0
		0000000000004390:  ARM64_RELOC_PAGEOFF12	l_str.391
    4394:      	str	w8, [x0]
    4398:      	mov	w8, #0x22               ; =34
    439c:      	stp	x9, x8, [x0, #0x8]
    43a0:      	ret

00000000000043a4 <_stogir.conversion.validate>:
    43a4:      	cmp	w2, #0x1
    43a8:      	b.lt	0x4450 <_stogir.conversion.validate+0xac>
    43ac:      	ldr	x11, [x1, #0x8]
    43b0:      	mov	w8, w2
    43b4:      	cmp	x11, x8
    43b8:      	b.le	0x44a0 <_stogir.conversion.validate+0xfc>
    43bc:      	ldr	x13, [x1, #0x80]
    43c0:      	cmp	x13, x8
    43c4:      	b.le	0x44a0 <_stogir.conversion.validate+0xfc>
    43c8:      	ldr	x12, [x1, #0x78]
    43cc:      	ldr	w10, [x12, x8, lsl #2]
    43d0:      	tbnz	w10, #0x1f, 0x44a0 <_stogir.conversion.validate+0xfc>
    43d4:      	ldr	x14, [x1]
    43d8:      	lsl	x8, x8, #4
    43dc:      	cmp	w10, #0x1
    43e0:      	ldr	x9, [x14, x8]
    43e4:      	and	w8, w9, #0xff
    43e8:      	sub	w15, w8, #0x21
    43ec:      	ccmp	w15, #0x7, #0x2, eq
    43f0:      	b.hs	0x4484 <_stogir.conversion.validate+0xe0>
    43f4:      	lsr	x10, x9, #32
    43f8:      	cmp	w10, #0x1
    43fc:      	b.lt	0x44bc <_stogir.conversion.validate+0x118>
    4400:      	cmp	x11, x10
    4404:      	b.ls	0x4510 <_stogir.conversion.validate+0x16c>
    4408:      	cmp	x13, x10
    440c:      	b.ls	0x4510 <_stogir.conversion.validate+0x16c>
    4410:      	ldr	w11, [x12, x10, lsl #2]
    4414:      	tbnz	w11, #0x1f, 0x4510 <_stogir.conversion.validate+0x16c>
    4418:      	add	x10, x14, x10, lsl #4
    441c:      	ldr	x10, [x10]
    4420:      	and	w11, w10, #0xff
    4424:      	cmp	w11, #0x48
    4428:      	b.eq	0x4434 <_stogir.conversion.validate+0x90>
    442c:      	cmp	w11, #0x46
    4430:      	b.ne	0x452c <_stogir.conversion.validate+0x188>
    4434:      	mov	w8, #0x1                ; =1
    4438:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004438:  ARM64_RELOC_PAGE21	l_str.395
    443c:      	add	x9, x9, #0x0
		000000000000443c:  ARM64_RELOC_PAGEOFF12	l_str.395
    4440:      	str	w8, [x0]
    4444:      	mov	w8, #0x25               ; =37
    4448:      	stp	x9, x8, [x0, #0x8]
    444c:      	ret
    4450:      	tbz	w2, #0x1f, 0x44a0 <_stogir.conversion.validate+0xfc>
    4454:      	ldr	x8, [x1, #0x30]
    4458:      	ldr	x9, [x1, #0x58]
    445c:      	cmp	x8, x9
    4460:      	b.ne	0x44a0 <_stogir.conversion.validate+0xfc>
    4464:      	sxtw	x9, w2
    4468:      	cmn	x8, x9
    446c:      	b.lt	0x44a0 <_stogir.conversion.validate+0xfc>
    4470:      	ldr	x8, [x1, #0x50]
    4474:      	mvn	x9, x9
    4478:      	ldr	w8, [x8, x9, lsl #2]
    447c:      	cmp	w8, #0x0
    4480:      	b.le	0x44a0 <_stogir.conversion.validate+0xfc>
    4484:      	mov	w8, #0x1                ; =1
    4488:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004488:  ARM64_RELOC_PAGE21	l_str.393
    448c:      	add	x9, x9, #0x0
		000000000000448c:  ARM64_RELOC_PAGEOFF12	l_str.393
    4490:      	str	w8, [x0]
    4494:      	mov	w8, #0x1e               ; =30
    4498:      	stp	x9, x8, [x0, #0x8]
    449c:      	ret
    44a0:      	mov	w8, #0x1                ; =1
    44a4:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000044a4:  ARM64_RELOC_PAGE21	l_str.392
    44a8:      	add	x9, x9, #0x0
		00000000000044a8:  ARM64_RELOC_PAGEOFF12	l_str.392
    44ac:      	str	w8, [x0]
    44b0:      	mov	w8, #0x12               ; =18
    44b4:      	stp	x9, x8, [x0, #0x8]
    44b8:      	ret
    44bc:      	tbz	x9, #0x3f, 0x4510 <_stogir.conversion.validate+0x16c>
    44c0:      	ldr	x11, [x1, #0x30]
    44c4:      	ldr	x12, [x1, #0x58]
    44c8:      	cmp	x11, x12
    44cc:      	b.ne	0x4510 <_stogir.conversion.validate+0x16c>
    44d0:      	asr	x12, x9, #32
    44d4:      	cmn	x11, x12
    44d8:      	b.lt	0x4510 <_stogir.conversion.validate+0x16c>
    44dc:      	ldr	x11, [x1, #0x50]
    44e0:      	mvn	x12, x12
    44e4:      	ldr	w11, [x11, x12, lsl #2]
    44e8:      	cmp	w11, #0x0
    44ec:      	b.le	0x4510 <_stogir.conversion.validate+0x16c>
    44f0:      	ldr	x11, [x1, #0x28]
    44f4:      	eor	x10, x10, #0xffffffff
    44f8:      	add	x10, x11, x10, lsl #4
    44fc:      	ldr	x10, [x10]
    4500:      	and	w11, w10, #0xff
    4504:      	cmp	w11, #0x48
    4508:      	b.ne	0x442c <_stogir.conversion.validate+0x88>
    450c:      	b	0x4434 <_stogir.conversion.validate+0x90>
    4510:      	mov	w8, #0x1                ; =1
    4514:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004514:  ARM64_RELOC_PAGE21	l_str.394
    4518:      	add	x9, x9, #0x0
		0000000000004518:  ARM64_RELOC_PAGEOFF12	l_str.394
    451c:      	str	w8, [x0]
    4520:      	mov	w8, #0x19               ; =25
    4524:      	stp	x9, x8, [x0, #0x8]
    4528:      	ret
    452c:      	ubfx	w2, w10, #8, #8
    4530:      	ubfx	w3, w9, #8, #8
    4534:      	mov	w1, w8
    4538:      	b	0x4538 <_stogir.conversion.validate+0x194>
		0000000000004538:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy

000000000000453c <_stogir.copy.validate>:
    453c:      	cmp	w2, #0x1
    4540:      	b.lt	0x4600 <_stogir.copy.validate+0xc4>
    4544:      	ldr	x10, [x1, #0x8]
    4548:      	mov	w8, w2
    454c:      	cmp	x10, x8
    4550:      	b.le	0x4650 <_stogir.copy.validate+0x114>
    4554:      	ldr	x12, [x1, #0x80]
    4558:      	cmp	x12, x8
    455c:      	b.le	0x4650 <_stogir.copy.validate+0x114>
    4560:      	ldr	x11, [x1, #0x78]
    4564:      	ldr	w14, [x11, x8, lsl #2]
    4568:      	tbnz	w14, #0x1f, 0x4650 <_stogir.copy.validate+0x114>
    456c:      	ldr	x13, [x1]
    4570:      	lsl	x8, x8, #4
    4574:      	ldr	x9, [x13, x8]
    4578:      	and	x8, x9, #0xff
    457c:      	cmp	x8, #0x44
    4580:      	b.ne	0x4634 <_stogir.copy.validate+0xf8>
    4584:      	ubfx	x8, x9, #8, #8
    4588:      	cmp	w14, #0x2
    458c:      	ccmp	w8, #0x0, #0x4, eq
    4590:      	b.eq	0x4634 <_stogir.copy.validate+0xf8>
    4594:      	cmp	w8, #0xe
    4598:      	b.lo	0x45bc <_stogir.copy.validate+0x80>
    459c:      	lsr	x14, x9, #8
    45a0:      	sub	w15, w8, #0x80
    45a4:      	and	w14, w14, #0xf
    45a8:      	sub	w14, w14, #0xe
    45ac:      	cmn	w14, #0xd
    45b0:      	mov	w14, #-0x70             ; =-112
    45b4:      	ccmp	w15, w14, #0x0, hs
    45b8:      	b.lo	0x4634 <_stogir.copy.validate+0xf8>
    45bc:      	lsr	x14, x9, #32
    45c0:      	cmp	w14, #0x1
    45c4:      	b.lt	0x466c <_stogir.copy.validate+0x130>
    45c8:      	cmp	x10, x14
    45cc:      	b.ls	0x46d8 <_stogir.copy.validate+0x19c>
    45d0:      	cmp	x12, x14
    45d4:      	b.ls	0x46d8 <_stogir.copy.validate+0x19c>
    45d8:      	ldr	w10, [x11, x14, lsl #2]
    45dc:      	tbnz	w10, #0x1f, 0x46d8 <_stogir.copy.validate+0x19c>
    45e0:      	add	x10, x13, x14, lsl #4
    45e4:      	lsr	w9, w9, #8
    45e8:      	ldrb	w10, [x10, #0x1]
    45ec:      	cmp	w10, w9, uxtb
    45f0:      	b.ne	0x46bc <_stogir.copy.validate+0x180>
    45f4:      	str	wzr, [x0]
    45f8:      	str	w8, [x0, #0x8]
    45fc:      	ret
    4600:      	tbz	w2, #0x1f, 0x4650 <_stogir.copy.validate+0x114>
    4604:      	ldr	x8, [x1, #0x30]
    4608:      	ldr	x9, [x1, #0x58]
    460c:      	cmp	x8, x9
    4610:      	b.ne	0x4650 <_stogir.copy.validate+0x114>
    4614:      	sxtw	x9, w2
    4618:      	cmn	x8, x9
    461c:      	b.lt	0x4650 <_stogir.copy.validate+0x114>
    4620:      	ldr	x8, [x1, #0x50]
    4624:      	mvn	x9, x9
    4628:      	ldr	w8, [x8, x9, lsl #2]
    462c:      	cmp	w8, #0x0
    4630:      	b.le	0x4650 <_stogir.copy.validate+0x114>
    4634:      	mov	w8, #0x1                ; =1
    4638:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004638:  ARM64_RELOC_PAGE21	l_str.397
    463c:      	add	x9, x9, #0x0
		000000000000463c:  ARM64_RELOC_PAGEOFF12	l_str.397
    4640:      	str	w8, [x0]
    4644:      	mov	w8, #0x21               ; =33
    4648:      	stp	x9, x8, [x0, #0x8]
    464c:      	ret
    4650:      	mov	w8, #0x1                ; =1
    4654:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004654:  ARM64_RELOC_PAGE21	l_str.396
    4658:      	add	x9, x9, #0x0
		0000000000004658:  ARM64_RELOC_PAGEOFF12	l_str.396
    465c:      	str	w8, [x0]
    4660:      	mov	w8, #0x18               ; =24
    4664:      	stp	x9, x8, [x0, #0x8]
    4668:      	ret
    466c:      	tbz	x9, #0x3f, 0x46d8 <_stogir.copy.validate+0x19c>
    4670:      	ldr	x10, [x1, #0x30]
    4674:      	ldr	x11, [x1, #0x58]
    4678:      	cmp	x10, x11
    467c:      	b.ne	0x46d8 <_stogir.copy.validate+0x19c>
    4680:      	asr	x11, x9, #32
    4684:      	cmn	x10, x11
    4688:      	b.lt	0x46d8 <_stogir.copy.validate+0x19c>
    468c:      	ldr	x10, [x1, #0x50]
    4690:      	mvn	x11, x11
    4694:      	ldr	w10, [x10, x11, lsl #2]
    4698:      	cmp	w10, #0x0
    469c:      	b.le	0x46d8 <_stogir.copy.validate+0x19c>
    46a0:      	ldr	x10, [x1, #0x28]
    46a4:      	eor	x11, x14, #0xffffffff
    46a8:      	add	x10, x10, x11, lsl #4
    46ac:      	lsr	w9, w9, #8
    46b0:      	ldrb	w10, [x10, #0x1]
    46b4:      	cmp	w10, w9, uxtb
    46b8:      	b.eq	0x45f4 <_stogir.copy.validate+0xb8>
    46bc:      	mov	w8, #0x1                ; =1
    46c0:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000046c0:  ARM64_RELOC_PAGE21	l_str.399
    46c4:      	add	x9, x9, #0x0
		00000000000046c4:  ARM64_RELOC_PAGEOFF12	l_str.399
    46c8:      	str	w8, [x0]
    46cc:      	mov	w8, #0x20               ; =32
    46d0:      	stp	x9, x8, [x0, #0x8]
    46d4:      	ret
    46d8:      	mov	w8, #0x1                ; =1
    46dc:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000046dc:  ARM64_RELOC_PAGE21	l_str.398
    46e0:      	add	x9, x9, #0x0
		00000000000046e0:  ARM64_RELOC_PAGEOFF12	l_str.398
    46e4:      	str	w8, [x0]
    46e8:      	mov	w8, #0x13               ; =19
    46ec:      	stp	x9, x8, [x0, #0x8]
    46f0:      	ret

00000000000046f4 <_stogir.graph.lookup>:
    46f4:      	cmp	w2, #0x1
    46f8:      	b.lt	0x473c <_stogir.graph.lookup+0x48>
    46fc:      	ldr	x9, [x1, #0x8]
    4700:      	mov	w8, w2
    4704:      	cmp	x9, x8
    4708:      	b.le	0x478c <_stogir.graph.lookup+0x98>
    470c:      	ldr	x9, [x1, #0x80]
    4710:      	cmp	x9, x8
    4714:      	b.le	0x478c <_stogir.graph.lookup+0x98>
    4718:      	ldr	x9, [x1, #0x78]
    471c:      	ldr	w9, [x9, x8, lsl #2]
    4720:      	tbnz	w9, #0x1f, 0x478c <_stogir.graph.lookup+0x98>
    4724:      	ldr	x9, [x1]
    4728:      	mov	w10, #0x1               ; =1
    472c:      	ldr	q0, [x9, x8, lsl #4]
    4730:      	str	w10, [x0]
    4734:      	stur	q0, [x0, #0x8]
    4738:      	ret
    473c:      	tbz	w2, #0x1f, 0x478c <_stogir.graph.lookup+0x98>
    4740:      	ldr	x8, [x1, #0x30]
    4744:      	ldr	x9, [x1, #0x58]
    4748:      	cmp	x8, x9
    474c:      	b.ne	0x478c <_stogir.graph.lookup+0x98>
    4750:      	sxtw	x9, w2
    4754:      	cmn	x8, x9
    4758:      	b.lt	0x478c <_stogir.graph.lookup+0x98>
    475c:      	ldr	x8, [x1, #0x50]
    4760:      	mvn	x9, x9
    4764:      	ldr	w8, [x8, x9, lsl #2]
    4768:      	cmp	w8, #0x0
    476c:      	b.le	0x478c <_stogir.graph.lookup+0x98>
    4770:      	ldr	x8, [x1, #0x28]
    4774:      	mvn	w9, w2
    4778:      	mov	w10, #0x1               ; =1
    477c:      	ldr	q0, [x8, w9, uxtw #4]
    4780:      	str	w10, [x0]
    4784:      	stur	q0, [x0, #0x8]
    4788:      	ret
    478c:      	str	wzr, [x0]
    4790:      	ret

0000000000004794 <_stogir.graph.operand>:
    4794:      	cmp	w1, #0x1
    4798:      	b.lt	0x47d0 <_stogir.graph.operand+0x3c>
    479c:      	ldr	x9, [x0, #0x8]
    47a0:      	mov	w8, w1
    47a4:      	cmp	x9, x8
    47a8:      	b.le	0x47d0 <_stogir.graph.operand+0x3c>
    47ac:      	ldr	x9, [x0, #0x80]
    47b0:      	cmp	x9, x8
    47b4:      	b.le	0x47d0 <_stogir.graph.operand+0x3c>
    47b8:      	ldr	x9, [x0, #0x78]
    47bc:      	ldr	w8, [x9, x8, lsl #2]
    47c0:      	cmp	w2, w8
    47c4:      	ccmp	w2, #0x1, #0x8, ls
    47c8:      	ccmp	w8, #0x0, #0x8, ge
    47cc:      	b.pl	0x47d8 <_stogir.graph.operand+0x44>
    47d0:      	mov	x0, xzr
    47d4:      	ret
    47d8:      	add	w8, w1, w2, lsr #2
    47dc:      	ldr	x9, [x0]
    47e0:      	mov	w0, #0x1                ; =1
    47e4:      	add	x8, x9, w8, uxtw #4
    47e8:      	and	w9, w2, #0x3
    47ec:      	ldr	w1, [x8, w9, uxtw #2]
    47f0:      	ret

00000000000047f4 <_stogir.locals.validate>:
    47f4:      	sub	sp, sp, #0xe0
    47f8:      	cmp	w2, #0x1
    47fc:      	stp	x28, x27, [sp, #0x80]
    4800:      	stp	x26, x25, [sp, #0x90]
    4804:      	stp	x24, x23, [sp, #0xa0]
    4808:      	stp	x22, x21, [sp, #0xb0]
    480c:      	stp	x20, x19, [sp, #0xc0]
    4810:      	stp	x29, x30, [sp, #0xd0]
    4814:      	add	x29, sp, #0xd0
    4818:      	b.lt	0x4888 <_stogir.locals.validate+0x94>
    481c:      	ldr	x9, [x1, #0x8]
    4820:      	mov	w8, w2
    4824:      	cmp	x9, x8
    4828:      	b.le	0x4948 <_stogir.locals.validate+0x154>
    482c:      	ldr	x9, [x1, #0x80]
    4830:      	cmp	x9, x8
    4834:      	b.le	0x4948 <_stogir.locals.validate+0x154>
    4838:      	ldr	x9, [x1, #0x78]
    483c:      	ldr	w9, [x9, x8, lsl #2]
    4840:      	tbnz	w9, #0x1f, 0x4948 <_stogir.locals.validate+0x154>
    4844:      	ldr	x9, [x1]
    4848:      	add	x8, x9, x8, lsl #4
    484c:      	ldr	x22, [x8]
    4850:      	mov	w10, #0x2               ; =2
    4854:      	and	w25, w22, #0xff
    4858:      	subs	w9, w25, #0x55
    485c:      	b.eq	0x48dc <_stogir.locals.validate+0xe8>
    4860:      	cmp	w25, #0x56
    4864:      	cinc	w10, w10, ne
    4868:      	cmp	w25, #0x57
    486c:      	b.ne	0x48dc <_stogir.locals.validate+0xe8>
    4870:      	mov	w23, #0x1               ; =1
    4874:      	cmp	w25, #0x41
    4878:      	csinc	w10, w10, wzr, ne
    487c:      	cmp	w2, #0x1
    4880:      	b.ge	0x48f4 <_stogir.locals.validate+0x100>
    4884:      	b	0x4980 <_stogir.locals.validate+0x18c>
    4888:      	tbz	w2, #0x1f, 0x4948 <_stogir.locals.validate+0x154>
    488c:      	ldr	x8, [x1, #0x30]
    4890:      	ldr	x9, [x1, #0x58]
    4894:      	cmp	x8, x9
    4898:      	b.ne	0x4948 <_stogir.locals.validate+0x154>
    489c:      	sxtw	x9, w2
    48a0:      	cmn	x8, x9
    48a4:      	b.lt	0x4948 <_stogir.locals.validate+0x154>
    48a8:      	ldr	x8, [x1, #0x50]
    48ac:      	mvn	x9, x9
    48b0:      	ldr	w8, [x8, x9, lsl #2]
    48b4:      	cmp	w8, #0x0
    48b8:      	b.le	0x4948 <_stogir.locals.validate+0x154>
    48bc:      	ldr	x8, [x1, #0x28]
    48c0:      	mvn	w9, w2
    48c4:      	add	x8, x8, w9, uxtw #4
    48c8:      	ldr	x22, [x8]
    48cc:      	mov	w10, #0x2               ; =2
    48d0:      	and	w25, w22, #0xff
    48d4:      	subs	w9, w25, #0x55
    48d8:      	b.ne	0x4860 <_stogir.locals.validate+0x6c>
    48dc:      	cmp	w25, #0x58
    48e0:      	cset	w23, eq
    48e4:      	cmp	w25, #0x41
    48e8:      	csinc	w10, w10, wzr, ne
    48ec:      	cmp	w2, #0x1
    48f0:      	b.lt	0x4980 <_stogir.locals.validate+0x18c>
    48f4:      	and	w11, w22, #0xff
    48f8:      	ldr	x26, [x8, #0x8]
    48fc:      	ldr	w24, [x8]
    4900:      	cmp	w11, #0x41
    4904:      	b.eq	0x4918 <_stogir.locals.validate+0x124>
    4908:      	cmp	w11, #0x48
    490c:      	b.eq	0x4918 <_stogir.locals.validate+0x124>
    4910:      	cmp	w9, #0x3
    4914:      	b.hi	0x4980 <_stogir.locals.validate+0x18c>
    4918:      	ldr	x8, [x1, #0x78]
    491c:      	ldr	w9, [x8, w2, uxtw #2]
    4920:      	cmp	w9, w10
    4924:      	b.ne	0x4980 <_stogir.locals.validate+0x18c>
    4928:      	lsr	x19, x22, #32
    492c:      	cmp	w25, #0x41
    4930:      	mov	w9, w19
    4934:      	b.eq	0x4994 <_stogir.locals.validate+0x1a0>
    4938:      	cmp	w25, #0x48
    493c:      	b.ne	0x4990 <_stogir.locals.validate+0x19c>
    4940:      	mov	w10, w2
    4944:      	b	0x49a4 <_stogir.locals.validate+0x1b0>
    4948:      	mov	w8, #0x1                ; =1
    494c:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		000000000000494c:  ARM64_RELOC_PAGE21	l_str.442
    4950:      	add	x9, x9, #0x0
		0000000000004950:  ARM64_RELOC_PAGEOFF12	l_str.442
    4954:      	str	w8, [x0]
    4958:      	mov	w8, #0x17               ; =23
    495c:      	stp	x9, x8, [x0, #0x8]
    4960:      	ldp	x29, x30, [sp, #0xd0]
    4964:      	ldp	x20, x19, [sp, #0xc0]
    4968:      	ldp	x22, x21, [sp, #0xb0]
    496c:      	ldp	x24, x23, [sp, #0xa0]
    4970:      	ldp	x26, x25, [sp, #0x90]
    4974:      	ldp	x28, x27, [sp, #0x80]
    4978:      	add	sp, sp, #0xe0
    497c:      	ret
    4980:      	mov	w8, #0x1                ; =1
    4984:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004984:  ARM64_RELOC_PAGE21	l_str.443
    4988:      	add	x9, x9, #0x0
		0000000000004988:  ARM64_RELOC_PAGEOFF12	l_str.443
    498c:      	b	0x4954 <_stogir.locals.validate+0x160>
    4990:      	mov	w9, w26
    4994:      	cmp	w9, #0x1
    4998:      	b.lt	0x4a18 <_stogir.locals.validate+0x224>
    499c:      	mov	w10, w9
    49a0:      	mov	w2, w9
    49a4:      	ldr	x9, [x1, #0x8]
    49a8:      	cmp	x9, x10
    49ac:      	b.le	0x4a60 <_stogir.locals.validate+0x26c>
    49b0:      	ldr	x9, [x1, #0x80]
    49b4:      	cmp	x9, x10
    49b8:      	b.le	0x4a60 <_stogir.locals.validate+0x26c>
    49bc:      	ldr	w9, [x8, x10, lsl #2]
    49c0:      	tbnz	w9, #0x1f, 0x4a60 <_stogir.locals.validate+0x26c>
    49c4:      	ldr	x9, [x1]
    49c8:      	add	x10, x9, x10, lsl #4
    49cc:      	ldp	x9, x10, [x10]
    49d0:      	lsr	x11, x9, #8
    49d4:      	and	w12, w11, #0xf
    49d8:      	and	w11, w11, #0xff
    49dc:      	sub	w12, w12, #0x1
    49e0:      	sub	w13, w11, #0x10
    49e4:      	cmp	w12, #0xd
    49e8:      	mov	w12, #0x70              ; =112
    49ec:      	ccmp	w13, w12, #0x2, lo
    49f0:      	b.hs	0x4a7c <_stogir.locals.validate+0x288>
    49f4:      	ubfx	x12, x9, #8, #4
    49f8:      	adrp	x13, 0x4000 <_stogir.conditional.validate+0x258>
		00000000000049f8:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size
    49fc:      	add	x13, x13, #0x0
		00000000000049fc:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size
    4a00:      	lsr	w11, w11, #4
    4a04:      	add	x12, x13, x12
    4a08:      	ldurb	w12, [x12, #-0x1]
    4a0c:      	sub	w11, w11, #0x1
    4a10:      	lsl	w27, w12, w11
    4a14:      	b	0x4aa0 <_stogir.locals.validate+0x2ac>
    4a18:      	tbz	w9, #0x1f, 0x4a60 <_stogir.locals.validate+0x26c>
    4a1c:      	ldr	x10, [x1, #0x30]
    4a20:      	ldr	x11, [x1, #0x58]
    4a24:      	cmp	x10, x11
    4a28:      	b.ne	0x4a60 <_stogir.locals.validate+0x26c>
    4a2c:      	sxtw	x11, w9
    4a30:      	cmn	x10, x11
    4a34:      	b.lt	0x4a60 <_stogir.locals.validate+0x26c>
    4a38:      	ldr	x10, [x1, #0x50]
    4a3c:      	mvn	x11, x11
    4a40:      	ldr	w10, [x10, x11, lsl #2]
    4a44:      	cmp	w10, #0x0
    4a48:      	b.le	0x4a60 <_stogir.locals.validate+0x26c>
    4a4c:      	ldr	x10, [x1, #0x28]
    4a50:      	mvn	w11, w9
    4a54:      	mov	w2, w9
    4a58:      	add	x10, x10, w11, uxtw #4
    4a5c:      	b	0x49cc <_stogir.locals.validate+0x1d8>
    4a60:      	adrp	x10, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004a60:  ARM64_RELOC_PAGE21	l_str.438
    4a64:      	add	x10, x10, #0x0
		0000000000004a64:  ARM64_RELOC_PAGEOFF12	l_str.438
    4a68:      	mov	w11, #0x16              ; =22
    4a6c:      	mov	w8, #0x1                ; =1
    4a70:      	stp	x10, x11, [x0, #0x8]
    4a74:      	str	w8, [x0]
    4a78:      	b	0x4960 <_stogir.locals.validate+0x16c>
    4a7c:      	ubfx	w11, w9, #8, #8
    4a80:      	cmp	w11, #0xd
    4a84:      	b.hi	0x4a9c <_stogir.locals.validate+0x2a8>
    4a88:      	ubfx	x11, x9, #8, #4
    4a8c:      	adrp	x12, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004a8c:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size.24
    4a90:      	add	x12, x12, #0x0
		0000000000004a90:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size.24
    4a94:      	ldrb	w27, [x12, x11]
    4a98:      	b	0x4aa0 <_stogir.locals.validate+0x2ac>
    4a9c:      	mov	w27, #-0x1              ; =-1
    4aa0:      	lsr	x11, x10, #32
    4aa4:      	cmp	x11, #0x0
    4aa8:      	csel	w12, w27, w11, eq
    4aac:      	cmp	w10, #0x0
    4ab0:      	cset	w13, eq
    4ab4:      	cmp	w10, #0x1
    4ab8:      	b.lt	0x4b04 <_stogir.locals.validate+0x310>
    4abc:      	ldr	x11, [x1, #0x140]
    4ac0:      	and	x10, x10, #0x7fffffff
    4ac4:      	cmp	x11, x10
    4ac8:      	b.ge	0x4ad4 <_stogir.locals.validate+0x2e0>
    4acc:      	mov	w13, wzr
    4ad0:      	b	0x4b04 <_stogir.locals.validate+0x310>
    4ad4:      	mov	w11, #0x18              ; =24
    4ad8:      	ldr	x13, [x1, #0x138]
    4adc:      	umaddl	x10, w10, w11, x13
    4ae0:      	ldr	x13, [x1, #0x118]
    4ae4:      	ldp	x11, x10, [x10, #-0x18]
    4ae8:      	orr	x14, x11, x10
    4aec:      	cmn	x14, #0x1
    4af0:      	cset	w14, gt
    4af4:      	subs	x11, x13, x11
    4af8:      	csel	w13, wzr, w14, lt
    4afc:      	cmp	x10, x11
    4b00:      	csel	w13, wzr, w13, gt
    4b04:      	cmp	w2, #0x1
    4b08:      	adrp	x10, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004b08:  ARM64_RELOC_PAGE21	l_str.439
    4b0c:      	add	x10, x10, #0x0
		0000000000004b0c:  ARM64_RELOC_PAGEOFF12	l_str.439
    4b10:      	mov	w11, #0x1c              ; =28
    4b14:      	b.lt	0x4a6c <_stogir.locals.validate+0x278>
    4b18:      	and	x14, x9, #0xff
    4b1c:      	cmp	x14, #0x48
    4b20:      	b.ne	0x4a6c <_stogir.locals.validate+0x278>
    4b24:      	ldr	w8, [x8, w2, uxtw #2]
    4b28:      	cmp	w8, #0x3
    4b2c:      	ccmp	w27, #0x0, #0x4, eq
    4b30:      	cset	w8, gt
    4b34:      	tst	w8, w13
    4b38:      	b.eq	0x4ba4 <_stogir.locals.validate+0x3b0>
    4b3c:      	sxtw	x8, w12
    4b40:      	mov	w11, #0x1c              ; =28
    4b44:      	cmp	w8, #0x1
    4b48:      	b.lt	0x4a6c <_stogir.locals.validate+0x278>
    4b4c:      	sub	x12, x8, #0x1
    4b50:      	and	x8, x8, x12
    4b54:      	cbnz	x8, 0x4a6c <_stogir.locals.validate+0x278>
    4b58:      	lsr	x21, x9, #32
    4b5c:      	mov	x28, x0
    4b60:      	add	x0, sp, #0x58
    4b64:      	mov	x20, x1
    4b68:      	mov	w2, w21
    4b6c:      	bl	0x4b6c <_stogir.locals.validate+0x378>
		0000000000004b6c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4b70:      	ldr	w8, [sp, #0x58]
    4b74:      	cbz	w8, 0x4bac <_stogir.locals.validate+0x3b8>
    4b78:      	cmp	w21, #0x1
    4b7c:      	b.lt	0x4b94 <_stogir.locals.validate+0x3a0>
    4b80:      	ldr	w8, [sp, #0x60]
    4b84:      	and	w8, w8, #0xfe
    4b88:      	sub	w8, w8, #0x72
    4b8c:      	cmn	w8, #0xb
    4b90:      	b.hi	0x4bc0 <_stogir.locals.validate+0x3cc>
    4b94:      	adrp	x10, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004b94:  ARM64_RELOC_PAGE21	l_str.441
    4b98:      	add	x10, x10, #0x0
		0000000000004b98:  ARM64_RELOC_PAGEOFF12	l_str.441
    4b9c:      	mov	w11, #0x2c              ; =44
    4ba0:      	b	0x4bb8 <_stogir.locals.validate+0x3c4>
    4ba4:      	mov	w11, #0x1c              ; =28
    4ba8:      	b	0x4a6c <_stogir.locals.validate+0x278>
    4bac:      	adrp	x10, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004bac:  ARM64_RELOC_PAGE21	l_str.440
    4bb0:      	add	x10, x10, #0x0
		0000000000004bb0:  ARM64_RELOC_PAGEOFF12	l_str.440
    4bb4:      	mov	w11, #0x1d              ; =29
    4bb8:      	mov	x0, x28
    4bbc:      	b	0x4a6c <_stogir.locals.validate+0x278>
    4bc0:      	cmp	w25, #0x48
    4bc4:      	b.ne	0x4bd4 <_stogir.locals.validate+0x3e0>
    4bc8:      	str	wzr, [x28]
    4bcc:      	str	w27, [x28, #0x8]
    4bd0:      	b	0x4960 <_stogir.locals.validate+0x16c>
    4bd4:      	cmp	w25, #0x41
    4bd8:      	b.ne	0x4bf8 <_stogir.locals.validate+0x404>
    4bdc:      	and	x8, x22, #0xff00
    4be0:      	cmp	x8, #0x600
    4be4:      	b.ne	0x4ca4 <_stogir.locals.validate+0x4b0>
    4be8:      	mov	w8, #0x8                ; =8
    4bec:      	str	wzr, [x28]
    4bf0:      	str	w8, [x28, #0x8]
    4bf4:      	b	0x4960 <_stogir.locals.validate+0x16c>
    4bf8:      	add	x0, sp, #0x8
    4bfc:      	mov	x1, x20
    4c00:      	mov	w2, w19
    4c04:      	bl	0x4c04 <_stogir.locals.validate+0x410>
		0000000000004c04:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4c08:      	ldr	w8, [sp, #0x8]
    4c0c:      	cbz	w8, 0x4cbc <_stogir.locals.validate+0x4c8>
    4c10:      	cmp	w19, #0x1
    4c14:      	b.lt	0x4c94 <_stogir.locals.validate+0x4a0>
    4c18:      	ldrb	w8, [sp, #0x10]
    4c1c:      	sub	w9, w8, #0x4f
    4c20:      	cmp	w9, #0x33
    4c24:      	b.hi	0x4c94 <_stogir.locals.validate+0x4a0>
    4c28:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004c28:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    4c2c:      	add	x9, x9, #0x0
		0000000000004c2c:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    4c30:      	ldrb	w8, [x9, x8]
    4c34:      	tbnz	w8, #0x2, 0x4c94 <_stogir.locals.validate+0x4a0>
    4c38:      	cbz	w23, 0x4c58 <_stogir.locals.validate+0x464>
    4c3c:      	lsr	x2, x26, #32
    4c40:      	add	x0, sp, #0x30
    4c44:      	mov	x1, x20
    4c48:      	bl	0x4c48 <_stogir.locals.validate+0x454>
		0000000000004c48:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4c4c:      	ldr	w8, [sp, #0x30]
    4c50:      	cbz	w8, 0x4cf0 <_stogir.locals.validate+0x4fc>
    4c54:      	ldr	w24, [sp, #0x38]
    4c58:      	ubfx	w0, w24, #8, #8
    4c5c:      	bl	0x4c5c <_stogir.locals.validate+0x468>
		0000000000004c5c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    4c60:      	cmp	w0, #0x1
    4c64:      	b.lt	0x4cd8 <_stogir.locals.validate+0x4e4>
    4c68:      	cmp	w0, w27
    4c6c:      	b.hi	0x4cd8 <_stogir.locals.validate+0x4e4>
    4c70:      	tst	x22, #0xff00
    4c74:      	csel	w8, wzr, w23, eq
    4c78:      	tbnz	w8, #0x0, 0x4cd8 <_stogir.locals.validate+0x4e4>
    4c7c:      	and	w8, w24, #0xff
    4c80:      	cmp	w8, #0x48
    4c84:      	b.eq	0x4cd8 <_stogir.locals.validate+0x4e4>
    4c88:      	str	wzr, [x28]
    4c8c:      	str	w0, [x28, #0x8]
    4c90:      	b	0x4960 <_stogir.locals.validate+0x16c>
    4c94:      	mov	w8, #0x1                ; =1
    4c98:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004c98:  ARM64_RELOC_PAGE21	l_str.446
    4c9c:      	add	x9, x9, #0x0
		0000000000004c9c:  ARM64_RELOC_PAGEOFF12	l_str.446
    4ca0:      	b	0x4cc8 <_stogir.locals.validate+0x4d4>
    4ca4:      	mov	w8, #0x1                ; =1
    4ca8:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004ca8:  ARM64_RELOC_PAGE21	l_str.444
    4cac:      	add	x9, x9, #0x0
		0000000000004cac:  ARM64_RELOC_PAGEOFF12	l_str.444
    4cb0:      	str	w8, [x28]
    4cb4:      	mov	w8, #0x21               ; =33
    4cb8:      	b	0x4cd0 <_stogir.locals.validate+0x4dc>
    4cbc:      	mov	w8, #0x1                ; =1
    4cc0:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004cc0:  ARM64_RELOC_PAGE21	l_str.445
    4cc4:      	add	x9, x9, #0x0
		0000000000004cc4:  ARM64_RELOC_PAGEOFF12	l_str.445
    4cc8:      	str	w8, [x28]
    4ccc:      	mov	w8, #0x1c               ; =28
    4cd0:      	stp	x9, x8, [x28, #0x8]
    4cd4:      	b	0x4960 <_stogir.locals.validate+0x16c>
    4cd8:      	mov	w8, #0x1                ; =1
    4cdc:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004cdc:  ARM64_RELOC_PAGE21	l_str.448
    4ce0:      	add	x9, x9, #0x0
		0000000000004ce0:  ARM64_RELOC_PAGEOFF12	l_str.448
    4ce4:      	str	w8, [x28]
    4ce8:      	mov	w8, #0x23               ; =35
    4cec:      	b	0x4cd0 <_stogir.locals.validate+0x4dc>
    4cf0:      	mov	w8, #0x1                ; =1
    4cf4:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004cf4:  ARM64_RELOC_PAGE21	l_str.447
    4cf8:      	add	x9, x9, #0x0
		0000000000004cf8:  ARM64_RELOC_PAGEOFF12	l_str.447
    4cfc:      	str	w8, [x28]
    4d00:      	mov	w8, #0x19               ; =25
    4d04:      	b	0x4cd0 <_stogir.locals.validate+0x4dc>

0000000000004d08 <_stogir.stack.constant-size-aligned>:
    4d08:      	cmp	x3, #0x10
    4d0c:      	b.lt	0x4d98 <_stogir.stack.constant-size-aligned+0x90>
    4d10:      	sub	x8, x3, #0x1
    4d14:      	and	x8, x3, x8
    4d18:      	cbnz	x8, 0x4d98 <_stogir.stack.constant-size-aligned+0x90>
    4d1c:      	cmp	w2, #0x1
    4d20:      	b.lt	0x4db4 <_stogir.stack.constant-size-aligned+0xac>
    4d24:      	ldr	x9, [x1, #0x8]
    4d28:      	mov	w8, w2
    4d2c:      	cmp	x9, x8
    4d30:      	b.le	0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4d34:      	ldr	x9, [x1, #0x80]
    4d38:      	cmp	x9, x8
    4d3c:      	b.le	0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4d40:      	ldr	x9, [x1, #0x78]
    4d44:      	ldr	w9, [x9, x8, lsl #2]
    4d48:      	tbnz	w9, #0x1f, 0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4d4c:      	ldr	x9, [x1]
    4d50:      	add	x8, x9, x8, lsl #4
    4d54:      	ldp	x10, x8, [x8]
    4d58:      	ubfx	x9, x10, #8, #8
    4d5c:      	cmp	w9, #0xd
    4d60:      	b.hi	0x4e04 <_stogir.stack.constant-size-aligned+0xfc>
    4d64:      	adrp	x11, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004d64:  ARM64_RELOC_PAGE21	ltmp1
    4d68:      	add	x11, x11, #0x0
		0000000000004d68:  ARM64_RELOC_PAGEOFF12	ltmp1
    4d6c:      	mov	w12, wzr
    4d70:      	adr	x14, 0x4d88 <_stogir.stack.constant-size-aligned+0x80>
    4d74:      	ldrb	w13, [x11, x9]
    4d78:      	add	x14, x14, x13, lsl #2
    4d7c:      	mov	w11, w9
    4d80:      	mov	w13, #0x1               ; =1
    4d84:      	br	x14
    4d88:      	mov	w13, wzr
    4d8c:      	mov	w12, wzr
    4d90:      	mov	w11, #0x8               ; =8
    4d94:      	b	0x4e58 <_stogir.stack.constant-size-aligned+0x150>
    4d98:      	mov	w8, #0x1                ; =1
    4d9c:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004d9c:  ARM64_RELOC_PAGE21	l_str.582
    4da0:      	add	x9, x9, #0x0
		0000000000004da0:  ARM64_RELOC_PAGEOFF12	l_str.582
    4da4:      	str	w8, [x0]
    4da8:      	mov	w8, #0x20               ; =32
    4dac:      	stp	x9, x8, [x0, #0x8]
    4db0:      	ret
    4db4:      	tbz	w2, #0x1f, 0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4db8:      	ldr	x8, [x1, #0x30]
    4dbc:      	ldr	x9, [x1, #0x58]
    4dc0:      	cmp	x8, x9
    4dc4:      	b.ne	0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4dc8:      	sxtw	x9, w2
    4dcc:      	cmn	x8, x9
    4dd0:      	b.lt	0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4dd4:      	ldr	x8, [x1, #0x50]
    4dd8:      	mvn	x9, x9
    4ddc:      	ldr	w8, [x8, x9, lsl #2]
    4de0:      	cmp	w8, #0x0
    4de4:      	b.le	0x4e10 <_stogir.stack.constant-size-aligned+0x108>
    4de8:      	ldr	x8, [x1, #0x28]
    4dec:      	mvn	w9, w2
    4df0:      	add	x8, x8, w9, uxtw #4
    4df4:      	ldp	x10, x8, [x8]
    4df8:      	ubfx	x9, x10, #8, #8
    4dfc:      	cmp	w9, #0xd
    4e00:      	b.ls	0x4d64 <_stogir.stack.constant-size-aligned+0x5c>
    4e04:      	mov	w11, #-0x8              ; =-8
    4e08:      	mov	w13, #0x1               ; =1
    4e0c:      	b	0x4e34 <_stogir.stack.constant-size-aligned+0x12c>
    4e10:      	mov	w8, #0x1                ; =1
    4e14:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004e14:  ARM64_RELOC_PAGE21	l_str.583
    4e18:      	add	x9, x9, #0x0
		0000000000004e18:  ARM64_RELOC_PAGEOFF12	l_str.583
    4e1c:      	str	w8, [x0]
    4e20:      	mov	w8, #0x18               ; =24
    4e24:      	stp	x9, x8, [x0, #0x8]
    4e28:      	ret
    4e2c:      	mov	w13, wzr
    4e30:      	mov	w11, #0x40              ; =64
    4e34:      	mov	w12, #0x1               ; =1
    4e38:      	b	0x4e58 <_stogir.stack.constant-size-aligned+0x150>
    4e3c:      	mov	w13, wzr
    4e40:      	mov	w12, wzr
    4e44:      	mov	w11, #0x20              ; =32
    4e48:      	b	0x4e58 <_stogir.stack.constant-size-aligned+0x150>
    4e4c:      	mov	w13, wzr
    4e50:      	mov	w12, wzr
    4e54:      	mov	w11, #0x10              ; =16
    4e58:      	tbz	w2, #0x1f, 0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4e5c:      	sub	w14, w9, #0x1
    4e60:      	cmp	w14, #0xa
    4e64:      	b.hi	0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4e68:      	and	w10, w10, #0xff
    4e6c:      	cmp	w10, #0x49
    4e70:      	ccmp	w10, w9, #0x4, ne
    4e74:      	csinc	w10, w13, wzr, eq
    4e78:      	tbnz	w10, #0x0, 0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4e7c:      	lsr	x10, x8, x11
    4e80:      	cmp	x10, #0x0
    4e84:      	csinc	w10, w12, wzr, ne
    4e88:      	cbz	w10, 0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4e8c:      	sub	w9, w9, #0x7
    4e90:      	cmp	w9, #0x4
    4e94:      	b.hi	0x4ea4 <_stogir.stack.constant-size-aligned+0x19c>
    4e98:      	sub	w9, w11, #0x1
    4e9c:      	lsr	x9, x8, x9
    4ea0:      	tbnz	w9, #0x0, 0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4ea4:      	mov	x9, #-0x8000000000000000 ; =-9223372036854775808
    4ea8:      	sub	x9, x9, x3
    4eac:      	cmp	x8, x9
    4eb0:      	b.hi	0x4ed0 <_stogir.stack.constant-size-aligned+0x1c8>
    4eb4:      	add	x8, x3, x8
    4eb8:      	neg	x9, x3
    4ebc:      	str	wzr, [x0]
    4ec0:      	sub	x8, x8, #0x1
    4ec4:      	and	x8, x8, x9
    4ec8:      	str	x8, [x0, #0x8]
    4ecc:      	ret
    4ed0:      	mov	w8, #0x1                ; =1
    4ed4:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004ed4:  ARM64_RELOC_PAGE21	l_str.584
    4ed8:      	add	x9, x9, #0x0
		0000000000004ed8:  ARM64_RELOC_PAGEOFF12	l_str.584
    4edc:      	str	w8, [x0]
    4ee0:      	mov	w8, #0x30               ; =48
    4ee4:      	stp	x9, x8, [x0, #0x8]
    4ee8:      	ret

0000000000004eec <_stogir.switch.key>:
    4eec:      	sub	w9, w3, #0x1
    4ef0:      	cmp	w9, #0xb
    4ef4:      	b.hs	0x4f60 <_stogir.switch.key+0x74>
    4ef8:      	cmp	w2, #0x1
    4efc:      	b.lt	0x4f84 <_stogir.switch.key+0x98>
    4f00:      	ldr	x10, [x1, #0x8]
    4f04:      	mov	w8, w2
    4f08:      	cmp	x10, x8
    4f0c:      	b.le	0x4ff4 <_stogir.switch.key+0x108>
    4f10:      	ldr	x10, [x1, #0x80]
    4f14:      	cmp	x10, x8
    4f18:      	b.le	0x4ff4 <_stogir.switch.key+0x108>
    4f1c:      	ldr	x10, [x1, #0x78]
    4f20:      	ldr	w10, [x10, x8, lsl #2]
    4f24:      	tbnz	w10, #0x1f, 0x4ff4 <_stogir.switch.key+0x108>
    4f28:      	ldr	x10, [x1]
    4f2c:      	add	x8, x10, x8, lsl #4
    4f30:      	mov	w10, wzr
    4f34:      	cmp	w3, #0x6
    4f38:      	mov	w11, #0x8               ; =8
    4f3c:      	b.gt	0x4fd4 <_stogir.switch.key+0xe8>
    4f40:      	cmp	w3, #0x3
    4f44:      	b.le	0x4fe0 <_stogir.switch.key+0xf4>
    4f48:      	sub	w9, w3, #0x5
    4f4c:      	cmp	w9, #0x2
    4f50:      	b.hs	0x5020 <_stogir.switch.key+0x134>
    4f54:      	mov	w10, #0x1               ; =1
    4f58:      	mov	w11, #0x40              ; =64
    4f5c:      	b	0x5028 <_stogir.switch.key+0x13c>
    4f60:      	mov	w8, #0x1                ; =1
    4f64:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004f64:  ARM64_RELOC_PAGE21	l_str.613
    4f68:      	add	x9, x9, #0x0
		0000000000004f68:  ARM64_RELOC_PAGEOFF12	l_str.613
    4f6c:      	str	w8, [x0]
    4f70:      	mov	w8, #0x24               ; =36
    4f74:      	str	x9, [x0, #0x8]
    4f78:      	mov	w9, #0x10               ; =16
    4f7c:      	str	x8, [x0, x9]
    4f80:      	ret
    4f84:      	tbz	w2, #0x1f, 0x4ff4 <_stogir.switch.key+0x108>
    4f88:      	ldr	x8, [x1, #0x30]
    4f8c:      	ldr	x10, [x1, #0x58]
    4f90:      	cmp	x8, x10
    4f94:      	b.ne	0x4ff4 <_stogir.switch.key+0x108>
    4f98:      	sxtw	x10, w2
    4f9c:      	cmn	x8, x10
    4fa0:      	b.lt	0x4ff4 <_stogir.switch.key+0x108>
    4fa4:      	ldr	x8, [x1, #0x50]
    4fa8:      	mvn	x10, x10
    4fac:      	ldr	w8, [x8, x10, lsl #2]
    4fb0:      	cmp	w8, #0x0
    4fb4:      	b.le	0x4ff4 <_stogir.switch.key+0x108>
    4fb8:      	ldr	x8, [x1, #0x28]
    4fbc:      	mvn	w10, w2
    4fc0:      	add	x8, x8, w10, uxtw #4
    4fc4:      	mov	w10, wzr
    4fc8:      	cmp	w3, #0x6
    4fcc:      	mov	w11, #0x8               ; =8
    4fd0:      	b.le	0x4f40 <_stogir.switch.key+0x54>
    4fd4:      	cmp	w3, #0x9
    4fd8:      	b.gt	0x5018 <_stogir.switch.key+0x12c>
    4fdc:      	sub	w9, w3, #0x7
    4fe0:      	cmp	w9, #0x2
    4fe4:      	b.lo	0x5028 <_stogir.switch.key+0x13c>
    4fe8:      	mov	w10, wzr
    4fec:      	mov	w11, #0x10              ; =16
    4ff0:      	b	0x5028 <_stogir.switch.key+0x13c>
    4ff4:      	mov	w8, #0x1                ; =1
    4ff8:      	adrp	x9, 0x4000 <_stogir.conditional.validate+0x258>
		0000000000004ff8:  ARM64_RELOC_PAGE21	l_str.614
    4ffc:      	add	x9, x9, #0x0
		0000000000004ffc:  ARM64_RELOC_PAGEOFF12	l_str.614
    5000:      	str	w8, [x0]
    5004:      	mov	w8, #0x1c               ; =28
    5008:      	str	x9, [x0, #0x8]
    500c:      	mov	w9, #0x10               ; =16
    5010:      	str	x8, [x0, x9]
    5014:      	ret
    5018:      	cmp	w3, #0xa
    501c:      	b.ne	0x4f54 <_stogir.switch.key+0x68>
    5020:      	mov	w10, wzr
    5024:      	mov	w11, #0x20              ; =32
    5028:      	tbz	w2, #0x1f, 0x5070 <_stogir.switch.key+0x184>
    502c:      	ldr	x9, [x8]
    5030:      	mov	w13, #0x49              ; =73
    5034:      	ubfx	w12, w9, #8, #8
    5038:      	and	w9, w9, #0xff
    503c:      	cmp	w9, w12
    5040:      	ccmp	w9, w13, #0x4, ne
    5044:      	ccmp	w12, w3, #0x0, eq
    5048:      	b.ne	0x5070 <_stogir.switch.key+0x184>
    504c:      	ldr	x8, [x8, #0x8]
    5050:      	lsr	x9, x8, x11
    5054:      	cmp	x9, #0x0
    5058:      	csinc	w9, w10, wzr, ne
    505c:      	cbz	w9, 0x5070 <_stogir.switch.key+0x184>
    5060:      	cmp	w3, #0x1
    5064:      	b.ne	0x5094 <_stogir.switch.key+0x1a8>
    5068:      	cmp	x8, #0x1
    506c:      	b.ls	0x50cc <_stogir.switch.key+0x1e0>
    5070:      	mov	w8, #0x1                ; =1
    5074:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005074:  ARM64_RELOC_PAGE21	l_str.615
    5078:      	add	x9, x9, #0x0
		0000000000005078:  ARM64_RELOC_PAGEOFF12	l_str.615
    507c:      	str	w8, [x0]
    5080:      	mov	w8, #0x30               ; =48
    5084:      	str	x9, [x0, #0x8]
    5088:      	mov	w9, #0x10               ; =16
    508c:      	str	x8, [x0, x9]
    5090:      	ret
    5094:      	sub	w9, w3, #0x7
    5098:      	str	wzr, [x0]
    509c:      	cmp	w9, #0x4
    50a0:      	b.hi	0x50d0 <_stogir.switch.key+0x1e4>
    50a4:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		00000000000050a4:  ARM64_RELOC_PAGE21	l_switch.table.stogir.switch.key
    50a8:      	add	x9, x9, #0x0
		00000000000050a8:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.switch.key
    50ac:      	mov	w10, #0x1               ; =1
    50b0:      	add	x9, x9, w3, uxtw
    50b4:      	ldurb	w9, [x9, #-0x7]
    50b8:      	lsl	x9, x10, x9
    50bc:      	eor	x8, x9, x8
    50c0:      	mov	w9, #0x8                ; =8
    50c4:      	str	x8, [x0, x9]
    50c8:      	ret
    50cc:      	str	wzr, [x0]
    50d0:      	mov	w9, #0x8                ; =8
    50d4:      	str	x8, [x0, x9]
    50d8:      	ret

00000000000050dc <_stogir.switch.switch-inputs>:
    50dc:      	cmp	w2, #0x1
    50e0:      	b.lt	0x51a0 <_stogir.switch.switch-inputs+0xc4>
    50e4:      	ldr	x8, [x1, #0x8]
    50e8:      	mov	w12, w2
    50ec:      	cmp	x8, x12
    50f0:      	b.le	0x51f0 <_stogir.switch.switch-inputs+0x114>
    50f4:      	ldr	x9, [x1, #0x80]
    50f8:      	cmp	x9, x12
    50fc:      	b.le	0x51f0 <_stogir.switch.switch-inputs+0x114>
    5100:      	ldr	x10, [x1, #0x78]
    5104:      	ldr	w11, [x10, x12, lsl #2]
    5108:      	tbnz	w11, #0x1f, 0x51f0 <_stogir.switch.switch-inputs+0x114>
    510c:      	ldr	x11, [x1]
    5110:      	lsl	x12, x12, #4
    5114:      	ldr	x12, [x11, x12]
    5118:      	and	w13, w12, #0xff
    511c:      	sub	w13, w13, #0x4f
    5120:      	cmp	w13, #0x33
    5124:      	b.hi	0x51d4 <_stogir.switch.switch-inputs+0xf8>
    5128:      	and	x12, x12, #0xff
    512c:      	adrp	x13, 0x5000 <_stogir.switch.key+0x114>
		000000000000512c:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    5130:      	add	x13, x13, #0x0
		0000000000005130:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    5134:      	ldrb	w12, [x13, x12]
    5138:      	tbnz	w12, #0x2, 0x51d4 <_stogir.switch.switch-inputs+0xf8>
    513c:      	cmp	w3, #0x1
    5140:      	b.lt	0x520c <_stogir.switch.switch-inputs+0x130>
    5144:      	mov	w12, w3
    5148:      	cmp	x8, x12
    514c:      	b.ls	0x5250 <_stogir.switch.switch-inputs+0x174>
    5150:      	cmp	x9, x12
    5154:      	b.ls	0x5250 <_stogir.switch.switch-inputs+0x174>
    5158:      	ldr	w8, [x10, x12, lsl #2]
    515c:      	tbnz	w8, #0x1f, 0x5250 <_stogir.switch.switch-inputs+0x174>
    5160:      	add	x8, x11, x12, lsl #4
    5164:      	ldr	x9, [x8]
    5168:      	ubfx	w8, w9, #8, #8
    516c:      	and	x9, x9, #0xff
    5170:      	sub	w10, w8, #0xc
    5174:      	cmn	w10, #0xc
    5178:      	mov	w10, #0x48              ; =72
    517c:      	ccmp	x9, x10, #0x4, hi
    5180:      	b.ne	0x526c <_stogir.switch.switch-inputs+0x190>
    5184:      	mov	w8, #0x1                ; =1
    5188:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005188:  ARM64_RELOC_PAGE21	l_str.617
    518c:      	add	x9, x9, #0x0
		000000000000518c:  ARM64_RELOC_PAGEOFF12	l_str.617
    5190:      	str	w8, [x0]
    5194:      	mov	w8, #0x20               ; =32
    5198:      	stp	x9, x8, [x0, #0x8]
    519c:      	ret
    51a0:      	tbz	w2, #0x1f, 0x51f0 <_stogir.switch.switch-inputs+0x114>
    51a4:      	ldr	x8, [x1, #0x30]
    51a8:      	ldr	x9, [x1, #0x58]
    51ac:      	cmp	x8, x9
    51b0:      	b.ne	0x51f0 <_stogir.switch.switch-inputs+0x114>
    51b4:      	sxtw	x9, w2
    51b8:      	cmn	x8, x9
    51bc:      	b.lt	0x51f0 <_stogir.switch.switch-inputs+0x114>
    51c0:      	ldr	x8, [x1, #0x50]
    51c4:      	mvn	x9, x9
    51c8:      	ldr	w8, [x8, x9, lsl #2]
    51cc:      	cmp	w8, #0x0
    51d0:      	b.le	0x51f0 <_stogir.switch.switch-inputs+0x114>
    51d4:      	mov	w8, #0x1                ; =1
    51d8:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		00000000000051d8:  ARM64_RELOC_PAGE21	l_str.619
    51dc:      	add	x9, x9, #0x0
		00000000000051dc:  ARM64_RELOC_PAGEOFF12	l_str.619
    51e0:      	str	w8, [x0]
    51e4:      	mov	w8, #0x16               ; =22
    51e8:      	stp	x9, x8, [x0, #0x8]
    51ec:      	ret
    51f0:      	mov	w8, #0x1                ; =1
    51f4:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		00000000000051f4:  ARM64_RELOC_PAGE21	l_str.618
    51f8:      	add	x9, x9, #0x0
		00000000000051f8:  ARM64_RELOC_PAGEOFF12	l_str.618
    51fc:      	str	w8, [x0]
    5200:      	mov	w8, #0x16               ; =22
    5204:      	stp	x9, x8, [x0, #0x8]
    5208:      	ret
    520c:      	tbz	w3, #0x1f, 0x5250 <_stogir.switch.switch-inputs+0x174>
    5210:      	ldr	x8, [x1, #0x30]
    5214:      	ldr	x9, [x1, #0x58]
    5218:      	cmp	x8, x9
    521c:      	b.ne	0x5250 <_stogir.switch.switch-inputs+0x174>
    5220:      	sxtw	x9, w3
    5224:      	cmn	x8, x9
    5228:      	b.lt	0x5250 <_stogir.switch.switch-inputs+0x174>
    522c:      	ldr	x8, [x1, #0x50]
    5230:      	mvn	x9, x9
    5234:      	ldr	w8, [x8, x9, lsl #2]
    5238:      	cmp	w8, #0x0
    523c:      	b.le	0x5250 <_stogir.switch.switch-inputs+0x174>
    5240:      	ldr	x8, [x1, #0x28]
    5244:      	mvn	w9, w3
    5248:      	add	x8, x8, w9, uxtw #4
    524c:      	b	0x5164 <_stogir.switch.switch-inputs+0x88>
    5250:      	mov	w8, #0x1                ; =1
    5254:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005254:  ARM64_RELOC_PAGE21	l_str.616
    5258:      	add	x9, x9, #0x0
		0000000000005258:  ARM64_RELOC_PAGEOFF12	l_str.616
    525c:      	str	w8, [x0]
    5260:      	mov	w8, #0x17               ; =23
    5264:      	stp	x9, x8, [x0, #0x8]
    5268:      	ret
    526c:      	str	wzr, [x0]
    5270:      	str	w8, [x0, #0x8]
    5274:      	ret

0000000000005278 <_stogir.types.scalar-size>:
    5278:      	cmp	w0, #0xd
    527c:      	b.hi	0x5290 <_stogir.types.scalar-size+0x18>
    5280:      	adrp	x8, 0x5000 <_stogir.switch.key+0x114>
		0000000000005280:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size.24
    5284:      	add	x8, x8, #0x0
		0000000000005284:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size.24
    5288:      	ldrb	w0, [x8, w0, uxtw]
    528c:      	ret
    5290:      	mov	w0, #-0x1               ; =-1
    5294:      	ret

0000000000005298 <_stogir.types.size>:
    5298:      	and	w8, w0, #0xf
    529c:      	mov	w9, #0x70               ; =112
    52a0:      	sub	w11, w0, #0x10
    52a4:      	sub	w10, w8, #0x1
    52a8:      	cmp	w10, #0xd
    52ac:      	ccmp	w11, w9, #0x2, lo
    52b0:      	b.hs	0x52d4 <_stogir.types.size+0x3c>
    52b4:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		00000000000052b4:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size
    52b8:      	add	x9, x9, #0x0
		00000000000052b8:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size
    52bc:      	add	x8, x9, w8, uxtw
    52c0:      	lsr	w9, w0, #4
    52c4:      	ldurb	w8, [x8, #-0x1]
    52c8:      	sub	w9, w9, #0x1
    52cc:      	lsl	w0, w8, w9
    52d0:      	ret
    52d4:      	cmp	w0, #0xd
    52d8:      	b.hi	0x52ec <_stogir.types.size+0x54>
    52dc:      	adrp	x8, 0x5000 <_stogir.switch.key+0x114>
		00000000000052dc:  ARM64_RELOC_PAGE21	l_switch.table.stogir.types.size.24
    52e0:      	add	x8, x8, #0x0
		00000000000052e0:  ARM64_RELOC_PAGEOFF12	l_switch.table.stogir.types.size.24
    52e4:      	ldrb	w0, [x8, w0, uxtw]
    52e8:      	ret
    52ec:      	mov	w0, #-0x1               ; =-1
    52f0:      	ret

00000000000052f4 <_stogir.vector-arithmetic.node?>:
    52f4:      	cmp	w1, #0x1
    52f8:      	b.lt	0x5378 <_stogir.vector-arithmetic.node?+0x84>
    52fc:      	ldr	x9, [x0, #0x8]
    5300:      	mov	w8, w1
    5304:      	cmp	x9, x8
    5308:      	b.le	0x53fc <_stogir.vector-arithmetic.node?+0x108>
    530c:      	ldr	x9, [x0, #0x80]
    5310:      	cmp	x9, x8
    5314:      	b.le	0x53fc <_stogir.vector-arithmetic.node?+0x108>
    5318:      	ldr	x9, [x0, #0x78]
    531c:      	ldr	w9, [x9, x8, lsl #2]
    5320:      	tbnz	w9, #0x1f, 0x53fc <_stogir.vector-arithmetic.node?+0x108>
    5324:      	ldr	x9, [x0]
    5328:      	add	x8, x9, x8, lsl #4
    532c:      	ldr	x8, [x8]
    5330:      	and	w9, w8, #0xff
    5334:      	cmp	w9, #0x39
    5338:      	b.hi	0x53c8 <_stogir.vector-arithmetic.node?+0xd4>
    533c:      	mov	x10, #0x80000000        ; =2147483648
    5340:      	and	x9, x8, #0xff
    5344:      	movk	x10, #0x2001, lsl #32
    5348:      	movk	x10, #0x3c0, lsl #48
    534c:      	lsr	x9, x10, x9
    5350:      	tbz	w9, #0x0, 0x53c8 <_stogir.vector-arithmetic.node?+0xd4>
    5354:      	lsr	w9, w8, #8
    5358:      	ubfx	w8, w8, #8, #4
    535c:      	and	w9, w9, #0xf0
    5360:      	sub	w8, w8, #0x1
    5364:      	sub	w9, w9, #0x10
    5368:      	cmp	w9, #0x70
    536c:      	ccmp	w8, #0xd, #0x2, lo
    5370:      	cset	w0, lo
    5374:      	ret
    5378:      	tbz	w1, #0x1f, 0x53fc <_stogir.vector-arithmetic.node?+0x108>
    537c:      	ldr	x8, [x0, #0x30]
    5380:      	ldr	x9, [x0, #0x58]
    5384:      	cmp	x8, x9
    5388:      	b.ne	0x53fc <_stogir.vector-arithmetic.node?+0x108>
    538c:      	sxtw	x9, w1
    5390:      	cmn	x8, x9
    5394:      	b.lt	0x53fc <_stogir.vector-arithmetic.node?+0x108>
    5398:      	ldr	x8, [x0, #0x50]
    539c:      	mvn	x9, x9
    53a0:      	ldr	w8, [x8, x9, lsl #2]
    53a4:      	cmp	w8, #0x0
    53a8:      	b.le	0x53fc <_stogir.vector-arithmetic.node?+0x108>
    53ac:      	ldr	x8, [x0, #0x28]
    53b0:      	mvn	w9, w1
    53b4:      	add	x8, x8, w9, uxtw #4
    53b8:      	ldr	x8, [x8]
    53bc:      	and	w9, w8, #0xff
    53c0:      	cmp	w9, #0x39
    53c4:      	b.ls	0x533c <_stogir.vector-arithmetic.node?+0x48>
    53c8:      	and	x9, x8, #0xfe
    53cc:      	cmp	x9, #0x3a
    53d0:      	b.eq	0x5354 <_stogir.vector-arithmetic.node?+0x60>
    53d4:      	and	w9, w8, #0xff
    53d8:      	mov	w0, wzr
    53dc:      	cmp	w9, #0x35
    53e0:      	b.hi	0x5400 <_stogir.vector-arithmetic.node?+0x10c>
    53e4:      	mov	x10, #0x3fc00000000000  ; =17944029765304320
    53e8:      	and	x9, x8, #0xff
    53ec:      	movk	x10, #0x7c00, lsl #16
    53f0:      	lsr	x9, x10, x9
    53f4:      	tbnz	w9, #0x0, 0x5354 <_stogir.vector-arithmetic.node?+0x60>
    53f8:      	b	0x5400 <_stogir.vector-arithmetic.node?+0x10c>
    53fc:      	mov	w0, wzr
    5400:      	ret

0000000000005404 <_stogir.vector.memory-inputs>:
    5404:      	and	w8, w2, #0xf
    5408:      	sub	w9, w2, #0x10
    540c:      	sub	w8, w8, #0x1
    5410:      	cmp	w8, #0xd
    5414:      	mov	w8, #0x70               ; =112
    5418:      	ccmp	w9, w8, #0x2, lo
    541c:      	b.hs	0x54fc <_stogir.vector.memory-inputs+0xf8>
    5420:      	sub	sp, sp, #0x50
    5424:      	cmp	w3, #0x0
    5428:      	stp	x20, x19, [sp, #0x30]
    542c:      	stp	x29, x30, [sp, #0x40]
    5430:      	add	x29, sp, #0x40
    5434:      	b.le	0x5518 <_stogir.vector.memory-inputs+0x114>
    5438:      	ldr	x9, [x1, #0x8]
    543c:      	mov	w8, w3
    5440:      	cmp	x9, x8
    5444:      	b.le	0x5574 <_stogir.vector.memory-inputs+0x170>
    5448:      	ldr	x9, [x1, #0x80]
    544c:      	cmp	x9, x8
    5450:      	b.le	0x5574 <_stogir.vector.memory-inputs+0x170>
    5454:      	ldr	x9, [x1, #0x78]
    5458:      	ldr	w9, [x9, x8, lsl #2]
    545c:      	tbnz	w9, #0x1f, 0x5574 <_stogir.vector.memory-inputs+0x170>
    5460:      	ldr	x9, [x1]
    5464:      	lsl	x8, x8, #4
    5468:      	ldr	x8, [x9, x8]
    546c:      	and	w9, w8, #0xff
    5470:      	sub	w9, w9, #0x4f
    5474:      	cmp	w9, #0x33
    5478:      	b.hi	0x554c <_stogir.vector.memory-inputs+0x148>
    547c:      	and	x8, x8, #0xff
    5480:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005480:  ARM64_RELOC_PAGE21	_coil_def.stogir.opcode.PROPERTIES
    5484:      	add	x9, x9, #0x0
		0000000000005484:  ARM64_RELOC_PAGEOFF12	_coil_def.stogir.opcode.PROPERTIES
    5488:      	ldrb	w8, [x9, x8]
    548c:      	tbnz	w8, #0x2, 0x554c <_stogir.vector.memory-inputs+0x148>
    5490:      	mov	w19, w2
    5494:      	mov	x20, x0
    5498:      	add	x0, sp, #0x8
    549c:      	mov	w2, w4
    54a0:      	bl	0x54a0 <_stogir.vector.memory-inputs+0x9c>
		00000000000054a0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    54a4:      	ldr	w8, [sp, #0x8]
    54a8:      	cbz	w8, 0x559c <_stogir.vector.memory-inputs+0x198>
    54ac:      	ldr	w9, [sp, #0x10]
    54b0:      	and	w8, w9, #0xff00
    54b4:      	cmp	w8, #0x600
    54b8:      	mov	x8, x20
    54bc:      	b.ne	0x54d4 <_stogir.vector.memory-inputs+0xd0>
    54c0:      	and	w9, w9, #0xff
    54c4:      	cmp	w9, #0x48
    54c8:      	b.eq	0x54d4 <_stogir.vector.memory-inputs+0xd0>
    54cc:      	cmp	w9, #0x46
    54d0:      	b.ne	0x55c4 <_stogir.vector.memory-inputs+0x1c0>
    54d4:      	mov	w9, #0x1                ; =1
    54d8:      	adrp	x10, 0x5000 <_stogir.switch.key+0x114>
		00000000000054d8:  ARM64_RELOC_PAGE21	l_str.686
    54dc:      	add	x10, x10, #0x0
		00000000000054dc:  ARM64_RELOC_PAGEOFF12	l_str.686
    54e0:      	str	w9, [x8]
    54e4:      	mov	w9, #0x2b               ; =43
    54e8:      	stp	x10, x9, [x8, #0x8]
    54ec:      	ldp	x29, x30, [sp, #0x40]
    54f0:      	ldp	x20, x19, [sp, #0x30]
    54f4:      	add	sp, sp, #0x50
    54f8:      	ret
    54fc:      	mov	w8, #0x1                ; =1
    5500:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005500:  ARM64_RELOC_PAGE21	l_str.682
    5504:      	add	x9, x9, #0x0
		0000000000005504:  ARM64_RELOC_PAGEOFF12	l_str.682
    5508:      	str	w8, [x0]
    550c:      	mov	w8, #0x32               ; =50
    5510:      	stp	x9, x8, [x0, #0x8]
    5514:      	ret
    5518:      	tbz	w3, #0x1f, 0x5574 <_stogir.vector.memory-inputs+0x170>
    551c:      	ldr	x8, [x1, #0x30]
    5520:      	ldr	x9, [x1, #0x58]
    5524:      	cmp	x8, x9
    5528:      	b.ne	0x5574 <_stogir.vector.memory-inputs+0x170>
    552c:      	sxtw	x9, w3
    5530:      	cmn	x8, x9
    5534:      	b.lt	0x5574 <_stogir.vector.memory-inputs+0x170>
    5538:      	ldr	x8, [x1, #0x50]
    553c:      	mvn	x9, x9
    5540:      	ldr	w8, [x8, x9, lsl #2]
    5544:      	cmp	w8, #0x0
    5548:      	b.le	0x5574 <_stogir.vector.memory-inputs+0x170>
    554c:      	mov	w8, #0x1                ; =1
    5550:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005550:  ARM64_RELOC_PAGE21	l_str.684
    5554:      	add	x9, x9, #0x0
		0000000000005554:  ARM64_RELOC_PAGEOFF12	l_str.684
    5558:      	str	w8, [x0]
    555c:      	mov	w8, #0x2c               ; =44
    5560:      	stp	x9, x8, [x0, #0x8]
    5564:      	ldp	x29, x30, [sp, #0x40]
    5568:      	ldp	x20, x19, [sp, #0x30]
    556c:      	add	sp, sp, #0x50
    5570:      	ret
    5574:      	mov	w8, #0x1                ; =1
    5578:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005578:  ARM64_RELOC_PAGE21	l_str.683
    557c:      	add	x9, x9, #0x0
		000000000000557c:  ARM64_RELOC_PAGEOFF12	l_str.683
    5580:      	str	w8, [x0]
    5584:      	mov	w8, #0x1d               ; =29
    5588:      	stp	x9, x8, [x0, #0x8]
    558c:      	ldp	x29, x30, [sp, #0x40]
    5590:      	ldp	x20, x19, [sp, #0x30]
    5594:      	add	sp, sp, #0x50
    5598:      	ret
    559c:      	mov	w8, #0x1                ; =1
    55a0:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		00000000000055a0:  ARM64_RELOC_PAGE21	l_str.685
    55a4:      	add	x9, x9, #0x0
		00000000000055a4:  ARM64_RELOC_PAGEOFF12	l_str.685
    55a8:      	str	w8, [x20]
    55ac:      	mov	w8, #0x1d               ; =29
    55b0:      	stp	x9, x8, [x20, #0x8]
    55b4:      	ldp	x29, x30, [sp, #0x40]
    55b8:      	ldp	x20, x19, [sp, #0x30]
    55bc:      	add	sp, sp, #0x50
    55c0:      	ret
    55c4:      	mov	w0, w19
    55c8:      	str	wzr, [x8]
    55cc:      	mov	x20, x8
    55d0:      	bl	0x55d0 <_stogir.vector.memory-inputs+0x1cc>
		00000000000055d0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    55d4:      	str	w0, [x20, #0x8]
    55d8:      	ldp	x29, x30, [sp, #0x40]
    55dc:      	ldp	x20, x19, [sp, #0x30]
    55e0:      	add	sp, sp, #0x50
    55e4:      	ret

00000000000055e8 <_stogir.vector.store-inputs>:
    55e8:      	mov	w8, w3
    55ec:      	mov	w3, w2
    55f0:      	cmp	w4, #0x1
    55f4:      	b.lt	0x5634 <_stogir.vector.store-inputs+0x4c>
    55f8:      	ldr	x10, [x1, #0x8]
    55fc:      	mov	w9, w4
    5600:      	cmp	x10, x9
    5604:      	b.le	0x5680 <_stogir.vector.store-inputs+0x98>
    5608:      	ldr	x10, [x1, #0x80]
    560c:      	cmp	x10, x9
    5610:      	b.le	0x5680 <_stogir.vector.store-inputs+0x98>
    5614:      	ldr	x10, [x1, #0x78]
    5618:      	ldr	w10, [x10, x9, lsl #2]
    561c:      	tbnz	w10, #0x1f, 0x5680 <_stogir.vector.store-inputs+0x98>
    5620:      	ldr	x10, [x1]
    5624:      	add	x9, x10, x9, lsl #4
    5628:      	ldrb	w2, [x9, #0x1]
    562c:      	mov	w4, w8
    5630:      	b	0x5630 <_stogir.vector.store-inputs+0x48>
		0000000000005630:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    5634:      	tbz	w4, #0x1f, 0x5680 <_stogir.vector.store-inputs+0x98>
    5638:      	ldr	x9, [x1, #0x30]
    563c:      	ldr	x10, [x1, #0x58]
    5640:      	cmp	x9, x10
    5644:      	b.ne	0x5680 <_stogir.vector.store-inputs+0x98>
    5648:      	sxtw	x10, w4
    564c:      	cmn	x9, x10
    5650:      	b.lt	0x5680 <_stogir.vector.store-inputs+0x98>
    5654:      	ldr	x9, [x1, #0x50]
    5658:      	mvn	x10, x10
    565c:      	ldr	w9, [x9, x10, lsl #2]
    5660:      	cmp	w9, #0x0
    5664:      	b.le	0x5680 <_stogir.vector.store-inputs+0x98>
    5668:      	ldr	x9, [x1, #0x28]
    566c:      	mvn	w10, w4
    5670:      	add	x9, x9, w10, uxtw #4
    5674:      	ldrb	w2, [x9, #0x1]
    5678:      	mov	w4, w8
    567c:      	b	0x567c <_stogir.vector.store-inputs+0x94>
		000000000000567c:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    5680:      	mov	w8, #0x1                ; =1
    5684:      	adrp	x9, 0x5000 <_stogir.switch.key+0x114>
		0000000000005684:  ARM64_RELOC_PAGE21	l_str.687
    5688:      	add	x9, x9, #0x0
		0000000000005688:  ARM64_RELOC_PAGEOFF12	l_str.687
    568c:      	str	w8, [x0]
    5690:      	mov	w8, #0x1a               ; =26
    5694:      	stp	x9, x8, [x0, #0x8]
    5698:      	ret
