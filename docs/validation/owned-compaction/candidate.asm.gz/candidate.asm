
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/owned-compaction/build/owned-compaction-verifier/candidate.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x1b0
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x160]
     1b4:      	str	x20, [sp, #0x168]
     1b8:      	str	x21, [sp, #0x170]
     1bc:      	str	x22, [sp, #0x178]
     1c0:      	str	x23, [sp, #0x180]
     1c4:      	str	x24, [sp, #0x188]
     1c8:      	str	x25, [sp, #0x190]
     1cc:      	str	x26, [sp, #0x198]
     1d0:      	str	x27, [sp, #0x1a0]
     1d4:      	str	x28, [sp, #0x1a8]
     1d8:      	add	x1, x0, #0x78
     1dc:      	ldr	x2, [x0, #0x8]
     1e0:      	ldr	x1, [x1, #0x8]
     1e4:      	cmp	x2, x1
     1e8:      	b.ne	0x228 <_stogir.verify.structure+0x88>
     1ec:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001ec:  ARM64_RELOC_PAGE21	l_stogir.304
     1f0:      	ldr	x16, [x16]
		00000000000001f0:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1f4:      	orr	x1, x16, xzr
     1f8:      	movz	x2, #0x0, lsl #48
     1fc:      	b	0x238 <_stogir.verify.structure+0x98>
     200:      	ldr	x2, [sp, #0x138]
     204:      	ldr	x1, [sp, #0x140]
     208:      	add	x1, x2, x1
     20c:      	ldr	x2, [sp, #0xb0]
     210:      	add	x2, x2, #0x1
     214:      	lsr	w2, w2, #0
     218:      	sxtw	x2, w2
     21c:      	ldr	x6, [sp, #0x110]
     220:      	ldr	x8, [sp, #0x108]
     224:      	b	0x304 <_stogir.verify.structure+0x164>
     228:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000228:  ARM64_RELOC_PAGE21	l_stogir.305
     22c:      	ldr	x16, [x16]
		000000000000022c:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     230:      	orr	x1, x16, xzr
     234:      	mov	x2, #0x2c               ; =44
     238:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000238:  ARM64_RELOC_PAGE21	l_stogir.306
     23c:      	ldr	x16, [x16]
		000000000000023c:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     240:      	orr	x19, x16, xzr
     244:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000244:  ARM64_RELOC_PAGE21	l_stogir.307
     248:      	ldr	x16, [x16]
		0000000000000248:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     24c:      	orr	x20, x16, xzr
     250:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000250:  ARM64_RELOC_PAGE21	l_stogir.308
     254:      	ldr	x16, [x16]
		0000000000000254:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     258:      	orr	x21, x16, xzr
     25c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000025c:  ARM64_RELOC_PAGE21	l_stogir.309
     260:      	ldr	x16, [x16]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     264:      	orr	x22, x16, xzr
     268:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000268:  ARM64_RELOC_PAGE21	l_stogir.310
     26c:      	ldr	x16, [x16]
		000000000000026c:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     270:      	orr	x23, x16, xzr
     274:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000274:  ARM64_RELOC_PAGE21	l_stogir.311
     278:      	ldr	x16, [x16]
		0000000000000278:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     27c:      	orr	x24, x16, xzr
     280:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000280:  ARM64_RELOC_PAGE21	l_stogir.312
     284:      	ldr	x16, [x16]
		0000000000000284:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     288:      	orr	x25, x16, xzr
     28c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000028c:  ARM64_RELOC_PAGE21	l_stogir.313
     290:      	ldr	x16, [x16]
		0000000000000290:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     294:      	orr	x26, x16, xzr
     298:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000298:  ARM64_RELOC_PAGE21	l_stogir.314
     29c:      	ldr	x16, [x16]
		000000000000029c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     2a0:      	orr	x27, x16, xzr
     2a4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002a4:  ARM64_RELOC_PAGE21	l_stogir.315
     2a8:      	ldr	x16, [x16]
		00000000000002a8:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     2ac:      	orr	x28, x16, xzr
     2b0:      	add	x3, x0, #0x110
     2b4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002b4:  ARM64_RELOC_PAGE21	l_stogir.316
     2b8:      	ldr	x16, [x16]
		00000000000002b8:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2bc:      	orr	x4, x16, xzr
     2c0:      	add	x5, x0, #0x78
     2c4:      	add	x6, x0, #0x28
     2c8:      	add	x7, x0, #0x50
     2cc:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002cc:  ARM64_RELOC_PAGE21	l_stogir.316
     2d0:      	ldr	x16, [x16]
		00000000000002d0:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     2d4:      	orr	x9, x16, xzr
     2d8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000002d8:  ARM64_RELOC_PAGE21	l_stogir.317
     2dc:      	ldr	x16, [x16]
		00000000000002dc:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     2e0:      	orr	x10, x16, xzr
     2e4:      	add	x11, x3, #0x28
     2e8:      	mov	x12, x1
     2ec:      	mov	x13, x2
     2f0:      	mov	x1, #0x1                ; =1
     2f4:      	movz	x2, #0x0, lsl #48
     2f8:      	b	0x3b0 <_stogir.verify.structure+0x210>
     2fc:      	ldr	x6, [sp, #0x58]
     300:      	mov	x8, #0x16               ; =22
     304:      	b	0x35c <_stogir.verify.structure+0x1bc>
     308:      	str	x8, [sp, #0xa0]
     30c:      	str	x19, [sp, #0x40]
     310:      	str	x20, [sp, #0x58]
     314:      	str	x21, [sp, #0x60]
     318:      	mov	x21, x0
     31c:      	str	x22, [sp, #0x68]
     320:      	str	x23, [sp, #0x70]
     324:      	str	x24, [sp, #0x78]
     328:      	str	x25, [sp, #0x80]
     32c:      	str	x26, [sp, #0x88]
     330:      	str	x27, [sp, #0x90]
     334:      	str	x28, [sp, #0x98]
     338:      	str	x4, [sp, #0x100]
     33c:      	mov	x0, x5
     340:      	mov	x5, x3
     344:      	mov	x3, x11
     348:      	mov	x4, x6
     34c:      	str	x9, [sp, #0x120]
     350:      	str	x10, [sp, #0x128]
     354:      	ldr	x6, [sp, #0x40]
     358:      	mov	x8, #0x23               ; =35
     35c:      	ldr	x19, [sp, #0x40]
     360:      	ldr	x20, [sp, #0x58]
     364:      	ldr	x22, [sp, #0x68]
     368:      	ldr	x23, [sp, #0x70]
     36c:      	ldr	x24, [sp, #0x78]
     370:      	ldr	x25, [sp, #0x80]
     374:      	ldr	x26, [sp, #0x88]
     378:      	ldr	x27, [sp, #0x90]
     37c:      	ldr	x28, [sp, #0x98]
     380:      	mov	x11, x3
     384:      	mov	x3, x5
     388:      	mov	x5, x0
     38c:      	mov	x0, x21
     390:      	ldr	x21, [sp, #0x60]
     394:      	ldr	x9, [sp, #0x120]
     398:      	ldr	x10, [sp, #0x128]
     39c:      	mov	x12, x6
     3a0:      	mov	x6, x4
     3a4:      	ldr	x4, [sp, #0x100]
     3a8:      	mov	x13, x8
     3ac:      	ldr	x8, [sp, #0xa0]
     3b0:      	cmp	x13, #0x0
     3b4:      	b.ne	0xc34 <_stogir.verify.structure+0xa94>
     3b8:      	ldr	x14, [x0, #0x8]
     3bc:      	cmp	x1, x14
     3c0:      	b.ge	0xc44 <_stogir.verify.structure+0xaa4>
     3c4:      	ldr	x14, [x0]
     3c8:      	add	x14, x14, x1, lsl #4
     3cc:      	ldr	x14, [x14]
     3d0:      	ldr	x15, [x0, #0x78]
     3d4:      	add	x15, x15, x1, lsl #2
     3d8:      	ldr	w15, [x15]
     3dc:      	sxtw	x15, w15
     3e0:      	cmp	x15, #0x0
     3e4:      	b.lt	0x308 <_stogir.verify.structure+0x168>
     3e8:      	mov	x17, #0xffff            ; =65535
     3ec:      	cmp	x15, x17
     3f0:      	b.gt	0xc54 <_stogir.verify.structure+0xab4>
     3f4:      	str	x0, [sp, #0x30]
     3f8:      	uxtb	w0, w14
     3fc:      	str	w0, [sp, #0x38]
     400:      	str	x19, [sp, #0x40]
     404:      	cmp	x0, #0x83
     408:      	cset	w19, lt
     40c:      	uxtb	w16, w19
     410:      	cmp	w16, wzr
     414:      	b.eq	0xca4 <_stogir.verify.structure+0xb04>
     418:      	lsr	w14, w14, #0
     41c:      	str	x0, [sp, #0x48]
     420:      	ubfx	x0, x14, #8, #8
     424:      	str	w0, [sp, #0x50]
     428:      	lsr	w0, w0, #0
     42c:      	str	x8, [sp, #0xa0]
     430:      	str	x3, [sp, #0xd8]
     434:      	str	x5, [sp, #0xd0]
     438:      	str	x6, [sp, #0xc8]
     43c:      	str	x7, [sp, #0xa8]
     440:      	str	x11, [sp, #0xe0]
     444:      	str	x2, [sp, #0xb0]
     448:      	str	x12, [sp, #0xb8]
     44c:      	str	x13, [sp, #0xc0]
     450:      	str	x20, [sp, #0x58]
     454:      	mov	x20, x14
     458:      	str	x21, [sp, #0x60]
     45c:      	ldr	x21, [sp, #0x30]
     460:      	str	x22, [sp, #0x68]
     464:      	ldr	x22, [sp, #0x48]
     468:      	str	x23, [sp, #0x70]
     46c:      	mov	x23, x4
     470:      	str	x24, [sp, #0x78]
     474:      	ldr	w24, [sp, #0x38]
     478:      	str	x25, [sp, #0x80]
     47c:      	mov	x25, x15
     480:      	str	x26, [sp, #0x88]
     484:      	mov	x26, x1
     488:      	str	x27, [sp, #0x90]
     48c:      	mov	x27, x9
     490:      	str	x28, [sp, #0x98]
     494:      	mov	x28, x10
     498:      	str	w19, [sp, #0xe8]
     49c:      	ldr	w19, [sp, #0x50]
     4a0:      	bl	0x4a0 <_stogir.verify.structure+0x300>
		00000000000004a0:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     4a4:      	cmp	x0, #0x0
     4a8:      	b.eq	0xcf0 <_stogir.verify.structure+0xb50>
     4ac:      	add	x0, x22, x28
     4b0:      	lsr	w24, w24, #0
     4b4:      	ldrsb	w0, [x0]
     4b8:      	sxtb	x0, w0
     4bc:      	cmp	x0, #0x0
     4c0:      	b.lt	0xa34 <_stogir.verify.structure+0x894>
     4c4:      	mov	w0, w24
     4c8:      	bl	0x4c8 <_stogir.verify.structure+0x328>
		00000000000004c8:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     4cc:      	lsr	w0, w0, #0
     4d0:      	sxtw	x0, w0
     4d4:      	cmp	x25, x0
     4d8:      	b.eq	0xa34 <_stogir.verify.structure+0x894>
     4dc:      	ldr	x5, [sp, #0xd8]
     4e0:      	str	x23, [sp, #0x100]
     4e4:      	ldr	x3, [sp, #0xe0]
     4e8:      	ldr	x0, [sp, #0xd0]
     4ec:      	ldr	x4, [sp, #0xc8]
     4f0:      	ldr	x7, [sp, #0xa8]
     4f4:      	str	x27, [sp, #0x120]
     4f8:      	str	x28, [sp, #0x128]
     4fc:      	mov	x1, x26
     500:      	ldr	x2, [sp, #0xb0]
     504:      	ldr	x6, [sp, #0x60]
     508:      	mov	x8, #0x23               ; =35
     50c:      	b	0x224 <_stogir.verify.structure+0x84>
     510:      	ldr	x0, [sp, #0xc0]
     514:      	cmp	x0, #0x0
     518:      	b.ne	0x530 <_stogir.verify.structure+0x390>
     51c:      	and	x0, x2, #0xffffffff
     520:      	mov	x1, x0
     524:      	movz	x0, #0x0, lsl #48
     528:      	movz	x2, #0x0, lsl #48
     52c:      	b	0x53c <_stogir.verify.structure+0x39c>
     530:      	ldr	x1, [sp, #0xb8]
     534:      	mov	x2, x0
     538:      	mov	x0, #0x1                ; =1
     53c:      	ldr	x3, [sp, #0xa0]
     540:      	str	x0, [x3]
     544:      	str	x1, [x3, #0x8]
     548:      	str	x2, [x3, #0x10]
     54c:      	ldr	x19, [sp, #0x160]
     550:      	ldr	x20, [sp, #0x168]
     554:      	ldr	x21, [sp, #0x170]
     558:      	ldr	x22, [sp, #0x178]
     55c:      	ldr	x23, [sp, #0x180]
     560:      	ldr	x24, [sp, #0x188]
     564:      	ldr	x25, [sp, #0x190]
     568:      	ldr	x26, [sp, #0x198]
     56c:      	ldr	x27, [sp, #0x1a0]
     570:      	ldr	x28, [sp, #0x1a8]
     574:      	ldr	x29, [sp, #0x10]
     578:      	ldr	x30, [sp, #0x18]
     57c:      	add	sp, sp, #0x1b0
     580:      	ret
     584:      	mov	x12, x9
     588:      	lsl	x12, x12, #2
     58c:      	lsr	w12, w12, #0
     590:      	ubfx	x12, x12, #0, #32
     594:      	lsr	x11, x11, x12
     598:      	lsr	w11, w11, #0
     59c:      	and	x11, x11, #0xf
     5a0:      	lsr	w11, w11, #0
     5a4:      	b	0x5c0 <_stogir.verify.structure+0x420>
     5a8:      	movz	x6, #0x0, lsl #48
     5ac:      	cmp	x6, #0x0
     5b0:      	b.eq	0xa6c <_stogir.verify.structure+0x8cc>
     5b4:      	ldr	w6, [sp, #0x158]
     5b8:      	b	0x698 <_stogir.verify.structure+0x4f8>
     5bc:      	movz	x11, #0x0, lsl #48
     5c0:      	b	0x5c8 <_stogir.verify.structure+0x428>
     5c4:      	movz	x11, #0x0, lsl #48
     5c8:      	add	x16, sp, #0x20
     5cc:      	str	x16, [sp]
     5d0:      	str	w0, [sp, #0xf0]
     5d4:      	str	x4, [sp, #0x108]
     5d8:      	str	x5, [sp, #0x110]
     5dc:      	str	x9, [sp, #0x130]
     5e0:      	str	x22, [sp, #0xf8]
     5e4:      	mov	x22, x2
     5e8:      	mov	w2, w3
     5ec:      	str	x23, [sp, #0x100]
     5f0:      	mov	x23, x1
     5f4:      	mov	w1, w0
     5f8:      	mov	x0, x21
     5fc:      	str	x25, [sp, #0x118]
     600:      	mov	x25, x6
     604:      	str	x27, [sp, #0x120]
     608:      	mov	w27, w7
     60c:      	str	x28, [sp, #0x128]
     610:      	mov	w28, w8
     614:      	str	x20, [sp, #0x138]
     618:      	mov	w20, w10
     61c:      	str	x26, [sp, #0x140]
     620:      	mov	x26, x11
     624:      	bl	0x624 <_stogir.verify.structure+0x484>
		0000000000000624:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     628:      	ldr	x16, [sp]
     62c:      	str	x0, [x16]
     630:      	str	x1, [x16, #0x8]
     634:      	add	x16, sp, #0x20
     638:      	ldr	x0, [x16]
     63c:      	add	x16, sp, #0x20
     640:      	ldr	x1, [x16, #0x8]
     644:      	lsr	w0, w0, #0
     648:      	lsr	x16, x0, #0
     64c:      	cmp	x16, #0x1
     650:      	b.eq	0x66c <_stogir.verify.structure+0x4cc>
     654:      	b.lo	0x65c <_stogir.verify.structure+0x4bc>
     658:      	b	0x670 <_stogir.verify.structure+0x4d0>
     65c:      	cmp	x16, #0x0
     660:      	b.eq	0x668 <_stogir.verify.structure+0x4c8>
     664:      	b	0x670 <_stogir.verify.structure+0x4d0>
     668:      	b	0x674 <_stogir.verify.structure+0x4d4>
     66c:      	b	0x780 <_stogir.verify.structure+0x5e0>
     670:      	b	0xb84 <_stogir.verify.structure+0x9e4>
     674:      	str	x23, [sp, #0x148]
     678:      	ldr	x5, [sp, #0xd8]
     67c:      	ldr	x3, [sp, #0xe0]
     680:      	ldr	x0, [sp, #0xd0]
     684:      	ldr	x4, [sp, #0xc8]
     688:      	ldr	x7, [sp, #0xa8]
     68c:      	mov	w6, w19
     690:      	ldr	x1, [sp, #0x80]
     694:      	mov	x2, #0x17               ; =23
     698:      	ldr	x8, [sp, #0x148]
     69c:      	add	x8, x8, #0x1
     6a0:      	lsr	w8, w8, #0
     6a4:      	sxtw	x8, w8
     6a8:      	ldr	x26, [sp, #0x140]
     6ac:      	ldr	x25, [sp, #0x118]
     6b0:      	str	x5, [sp, #0xd8]
     6b4:      	str	w20, [sp, #0xe8]
     6b8:      	ldr	x20, [sp, #0x138]
     6bc:      	ldr	x23, [sp, #0x100]
     6c0:      	str	x3, [sp, #0xe0]
     6c4:      	str	x0, [sp, #0xd0]
     6c8:      	ldr	w0, [sp, #0xf0]
     6cc:      	str	x4, [sp, #0xc8]
     6d0:      	str	x7, [sp, #0xa8]
     6d4:      	mov	w19, w6
     6d8:      	ldr	x27, [sp, #0x120]
     6dc:      	ldr	x28, [sp, #0x128]
     6e0:      	mov	x3, x1
     6e4:      	mov	x1, x8
     6e8:      	mov	x4, x2
     6ec:      	mov	x2, x22
     6f0:      	ldr	x22, [sp, #0xf8]
     6f4:      	cmp	x4, #0x0
     6f8:      	b.ne	0x718 <_stogir.verify.structure+0x578>
     6fc:      	cmp	x1, x25
     700:      	cset	w5, le
     704:      	ubfx	x5, x5, #0, #8
     708:      	fmov	d31, x3
     70c:      	mov	x3, x5
     710:      	fmov	x5, d31
     714:      	b	0x720 <_stogir.verify.structure+0x580>
     718:      	mov	x5, x3
     71c:      	movz	x3, #0x0, lsl #48
     720:      	cmp	x3, #0x0
     724:      	b.eq	0xd1c <_stogir.verify.structure+0xb7c>
     728:      	lsr	w3, w1, #0
     72c:      	sxtw	x6, w3
     730:      	cmp	x6, #0x0
     734:      	cset	w7, gt
     738:      	cmp	x6, #0x4
     73c:      	cset	w8, gt
     740:      	sub	x9, x6, #0x1
     744:      	lsr	w9, w9, #0
     748:      	sxtw	x9, w9
     74c:      	ldr	w10, [sp, #0xe8]
     750:      	uxtb	w16, w10
     754:      	cmp	w16, wzr
     758:      	b.eq	0x5c4 <_stogir.verify.structure+0x424>
     75c:      	ldr	w11, [x22]
     760:      	uxtb	w16, w7
     764:      	cmp	w16, wzr
     768:      	b.eq	0x5bc <_stogir.verify.structure+0x41c>
     76c:      	uxtb	w16, w8
     770:      	cmp	w16, wzr
     774:      	b.eq	0x584 <_stogir.verify.structure+0x3e4>
     778:      	mov	x12, #0x4               ; =4
     77c:      	b	0x588 <_stogir.verify.structure+0x3e8>
     780:      	lsr	w26, w26, #0
     784:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000784:  ARM64_RELOC_PAGE21	l_stogir.318
     788:      	ldr	x16, [x16]
		0000000000000788:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     78c:      	ldr	w0, [x16]
     790:      	orr	x2, x26, xzr
     794:      	cmp	x2, x0
     798:      	b.ne	0x7a4 <_stogir.verify.structure+0x604>
     79c:      	mov	x0, #0x1                ; =1
     7a0:      	b	0x7bc <_stogir.verify.structure+0x61c>
     7a4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007a4:  ARM64_RELOC_PAGE21	l_stogir.319
     7a8:      	ldr	x16, [x16]
		00000000000007a8:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     7ac:      	ldr	w0, [x16]
     7b0:      	cmp	x2, x0
     7b4:      	cset	w0, eq
     7b8:      	ubfx	x0, x0, #0, #8
     7bc:      	lsr	w1, w1, #0
     7c0:      	cmp	x0, #0x0
     7c4:      	b.eq	0xd50 <_stogir.verify.structure+0xbb0>
     7c8:      	lsr	w1, w1, #0
     7cc:      	str	x23, [sp, #0x148]
     7d0:      	mov	x23, x2
     7d4:      	str	x25, [sp, #0x150]
     7d8:      	mov	x25, x0
     7dc:      	mov	x0, x21
     7e0:      	str	w19, [sp, #0x158]
     7e4:      	mov	w19, w1
     7e8:      	bl	0x7e8 <_stogir.verify.structure+0x648>
		00000000000007e8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
     7ec:      	cmp	x0, #0x0
     7f0:      	cset	w1, eq
     7f4:      	uxtb	w16, w1
     7f8:      	cmp	w16, wzr
     7fc:      	cset	x1, eq
     800:      	cmp	x1, #0x0
     804:      	b.eq	0x834 <_stogir.verify.structure+0x694>
     808:      	ldr	w0, [x0]
     80c:      	uxtb	w0, w0
     810:      	cmp	x0, #0x48
     814:      	b.ne	0x834 <_stogir.verify.structure+0x694>
     818:      	ldr	x0, [sp, #0x88]
     81c:      	mov	x2, #0x25               ; =37
     820:      	b	0x83c <_stogir.verify.structure+0x69c>
     824:      	ldr	x1, [sp, #0x110]
     828:      	ldr	x2, [sp, #0x108]
     82c:      	movz	x0, #0x0, lsl #48
     830:      	b	0x848 <_stogir.verify.structure+0x6a8>
     834:      	ldr	x0, [sp, #0x110]
     838:      	ldr	x2, [sp, #0x108]
     83c:      	fmov	d31, x0
     840:      	mov	x0, x1
     844:      	fmov	x1, d31
     848:      	sxtw	x19, w19
     84c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000084c:  ARM64_RELOC_PAGE21	l_stogir.320
     850:      	ldr	x16, [x16]
		0000000000000850:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     854:      	ldr	w3, [x16]
     858:      	cmp	x23, x3
     85c:      	b.ne	0xd6c <_stogir.verify.structure+0xbcc>
     860:      	cmp	x19, #0x0
     864:      	b.gt	0x9d4 <_stogir.verify.structure+0x834>
     868:      	ldr	x5, [sp, #0xd8]
     86c:      	ldr	x3, [sp, #0xe0]
     870:      	movz	x4, #0x0, lsl #48
     874:      	lsr	w4, w4, #0
     878:      	lsr	x16, x4, #0
     87c:      	cmp	x16, #0x1
     880:      	b.eq	0x89c <_stogir.verify.structure+0x6fc>
     884:      	b.lo	0x88c <_stogir.verify.structure+0x6ec>
     888:      	b	0x8a0 <_stogir.verify.structure+0x700>
     88c:      	cmp	x16, #0x0
     890:      	b.eq	0x898 <_stogir.verify.structure+0x6f8>
     894:      	b	0x8a0 <_stogir.verify.structure+0x700>
     898:      	b	0x8a4 <_stogir.verify.structure+0x704>
     89c:      	b	0x8ac <_stogir.verify.structure+0x70c>
     8a0:      	b	0xc2c <_stogir.verify.structure+0xa8c>
     8a4:      	ldr	x1, [sp, #0x90]
     8a8:      	mov	x2, #0x21               ; =33
     8ac:      	cmp	x26, #0xf
     8b0:      	b.hs	0xd78 <_stogir.verify.structure+0xbd8>
     8b4:      	mov	x16, #0x1               ; =1
     8b8:      	lsl	x4, x16, x26
     8bc:      	lsr	w4, w4, #0
     8c0:      	mov	x17, #0x5e1c            ; =24092
     8c4:      	and	x4, x4, x17
     8c8:      	lsr	w4, w4, #0
     8cc:      	cmp	x4, #0x0
     8d0:      	b.eq	0xd8c <_stogir.verify.structure+0xbec>
     8d4:      	cmp	x25, #0x0
     8d8:      	b.eq	0xaa4 <_stogir.verify.structure+0x904>
     8dc:      	ldr	x4, [sp, #0xc8]
     8e0:      	ldr	x7, [sp, #0xa8]
     8e4:      	mov	x6, x0
     8e8:      	ldr	x0, [sp, #0xd0]
     8ec:      	b	0x5ac <_stogir.verify.structure+0x40c>
     8f0:      	lsr	w0, w26, #0
     8f4:      	cmp	x22, #0x78
     8f8:      	cset	w24, eq
     8fc:      	lsr	w0, w0, #0
     900:      	add	x2, x23, x22, lsl #2
     904:      	add	x4, x27, x22, lsl #2
     908:      	cmp	x19, #0x0
     90c:      	cset	w19, eq
     910:      	orr	x22, x2, xzr
     914:      	orr	x2, x4, xzr
     918:      	mov	x4, x3
     91c:      	mov	x3, x1
     920:      	mov	x1, #0x1                ; =1
     924:      	b	0x6f4 <_stogir.verify.structure+0x554>
     928:      	ldr	x1, [sp, #0x78]
     92c:      	mov	x2, #0x1b               ; =27
     930:      	add	x0, x0, #0x1
     934:      	cmp	x2, #0x0
     938:      	b.ne	0x958 <_stogir.verify.structure+0x7b8>
     93c:      	cmp	x0, x20
     940:      	cset	w3, lt
     944:      	ubfx	x3, x3, #0, #8
     948:      	fmov	d31, x2
     94c:      	mov	x2, x3
     950:      	fmov	x3, d31
     954:      	b	0x960 <_stogir.verify.structure+0x7c0>
     958:      	mov	x3, x2
     95c:      	movz	x2, #0x0, lsl #48
     960:      	cmp	x2, #0x0
     964:      	b.eq	0x8f0 <_stogir.verify.structure+0x750>
     968:      	add	x2, x0, x26
     96c:      	ldr	x4, [x21, #0x78]
     970:      	add	x2, x4, x2, lsl #2
     974:      	ldr	w2, [x2]
     978:      	sxtw	x2, w2
     97c:      	cmn	x2, #0x1
     980:      	b.ne	0x928 <_stogir.verify.structure+0x788>
     984:      	mov	x2, x3
     988:      	b	0x930 <_stogir.verify.structure+0x790>
     98c:      	ldr	x0, [sp, #0xb8]
     990:      	ldr	x1, [sp, #0xc0]
     994:      	add	x2, x25, #0x4
     998:      	ldr	x3, [x21, #0x8]
     99c:      	asr	x16, x2, #63
     9a0:      	lsr	x16, x16, #62
     9a4:      	add	x2, x2, x16
     9a8:      	asr	x2, x2, #2
     9ac:      	orr	x20, x2, xzr
     9b0:      	add	x2, x20, x26
     9b4:      	cmp	x2, x3
     9b8:      	b.le	0x9c4 <_stogir.verify.structure+0x824>
     9bc:      	ldr	x0, [sp, #0x70]
     9c0:      	mov	x1, #0x15               ; =21
     9c4:      	mov	x2, x1
     9c8:      	mov	x1, x0
     9cc:      	mov	x0, #0x1                ; =1
     9d0:      	b	0x934 <_stogir.verify.structure+0x794>
     9d4:      	ldr	x3, [sp, #0xe0]
     9d8:      	ldr	x4, [x3, #0x8]
     9dc:      	cmp	x19, x4
     9e0:      	b.gt	0xda0 <_stogir.verify.structure+0xc00>
     9e4:      	sub	x4, x19, #0x1
     9e8:      	ldr	x5, [sp, #0xd8]
     9ec:      	ldr	x6, [x5, #0x28]
     9f0:      	mov	x17, #0x18              ; =24
     9f4:      	mul	x4, x4, x17
     9f8:      	add	x4, x4, x6
     9fc:      	ldr	x6, [x4]
     a00:      	ldr	x4, [x4, #0x8]
     a04:      	ldr	x7, [x5, #0x8]
     a08:      	cmp	x6, #0x0
     a0c:      	b.lt	0xa64 <_stogir.verify.structure+0x8c4>
     a10:      	cmp	x6, x7
     a14:      	b.gt	0xa64 <_stogir.verify.structure+0x8c4>
     a18:      	cmp	x4, #0x0
     a1c:      	b.lt	0xa64 <_stogir.verify.structure+0x8c4>
     a20:      	sub	x6, x7, x6
     a24:      	cmp	x4, x6
     a28:      	b.gt	0xa64 <_stogir.verify.structure+0x8c4>
     a2c:      	mov	x4, #0x1                ; =1
     a30:      	b	0xa68 <_stogir.verify.structure+0x8c8>
     a34:      	mov	w0, w24
     a38:      	bl	0xa38 <_stogir.verify.structure+0x898>
		0000000000000a38:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     a3c:      	lsr	w0, w0, #0
     a40:      	sxtw	x0, w0
     a44:      	cmn	x0, #0x1
     a48:      	b.ne	0x98c <_stogir.verify.structure+0x7ec>
     a4c:      	ubfx	x0, x20, #16, #16
     a50:      	cmp	x25, x0
     a54:      	b.eq	0x98c <_stogir.verify.structure+0x7ec>
     a58:      	ldr	x0, [sp, #0x68]
     a5c:      	mov	x1, #0x24               ; =36
     a60:      	b	0x994 <_stogir.verify.structure+0x7f4>
     a64:      	movz	x4, #0x0, lsl #48
     a68:      	b	0x874 <_stogir.verify.structure+0x6d4>
     a6c:      	cmp	x19, #0x0
     a70:      	b.ne	0xda8 <_stogir.verify.structure+0xc08>
     a74:      	uxtb	w16, w20
     a78:      	cmp	w16, wzr
     a7c:      	b.eq	0xb8c <_stogir.verify.structure+0x9ec>
     a80:      	ldr	w6, [x22]
     a84:      	uxtb	w16, w27
     a88:      	cmp	w16, wzr
     a8c:      	b.eq	0xbcc <_stogir.verify.structure+0xa2c>
     a90:      	uxtb	w16, w28
     a94:      	cmp	w16, wzr
     a98:      	b.eq	0xc00 <_stogir.verify.structure+0xa60>
     a9c:      	mov	x8, #0x4                ; =4
     aa0:      	b	0xc04 <_stogir.verify.structure+0xa64>
     aa4:      	cmp	x19, #0x0
     aa8:      	b.le	0xdb0 <_stogir.verify.structure+0xc10>
     aac:      	ldr	x0, [x21, #0x8]
     ab0:      	cmp	x19, x0
     ab4:      	b.ge	0xdb8 <_stogir.verify.structure+0xc18>
     ab8:      	ldr	x0, [sp, #0xd0]
     abc:      	ldr	x4, [x0, #0x8]
     ac0:      	cmp	x19, x4
     ac4:      	b.ge	0xbdc <_stogir.verify.structure+0xa3c>
     ac8:      	ldr	x4, [x21, #0x78]
     acc:      	add	x4, x4, x19, lsl #2
     ad0:      	ldr	w4, [x4]
     ad4:      	sxtw	x4, w4
     ad8:      	cmp	x4, #0x0
     adc:      	cset	w4, ge
     ae0:      	ubfx	x4, x4, #0, #8
     ae4:      	b	0xbe0 <_stogir.verify.structure+0xa40>
     ae8:      	uxtb	w16, w24
     aec:      	cmp	w16, wzr
     af0:      	b.eq	0xdc0 <_stogir.verify.structure+0xc20>
     af4:      	ldr	w6, [sp, #0x158]
     af8:      	uxtb	w16, w6
     afc:      	cmp	w16, wzr
     b00:      	b.eq	0xb10 <_stogir.verify.structure+0x970>
     b04:      	ldr	x8, [sp, #0x150]
     b08:      	cmp	x8, #0x2
     b0c:      	b.eq	0x5b8 <_stogir.verify.structure+0x418>
     b10:      	ldr	x1, [sp, #0x98]
     b14:      	mov	x2, #0x1a               ; =26
     b18:      	b	0x5b8 <_stogir.verify.structure+0x418>
     b1c:      	movz	x4, #0x0, lsl #48
     b20:      	ldr	x7, [sp, #0xa8]
     b24:      	mov	x6, x4
     b28:      	ldr	x4, [sp, #0xc8]
     b2c:      	b	0x5ac <_stogir.verify.structure+0x40c>
     b30:      	cmp	x19, #0x0
     b34:      	b.ge	0xdc8 <_stogir.verify.structure+0xc28>
     b38:      	ldr	x4, [sp, #0xc8]
     b3c:      	ldr	x6, [x4, #0x8]
     b40:      	ldr	x7, [sp, #0xa8]
     b44:      	ldr	x8, [x7, #0x8]
     b48:      	cmp	x6, x8
     b4c:      	b.ne	0xbd4 <_stogir.verify.structure+0xa34>
     b50:      	movz	x16, #0x0, lsl #48
     b54:      	sub	x8, x16, x19
     b58:      	cmp	x8, x6
     b5c:      	b.gt	0xc24 <_stogir.verify.structure+0xa84>
     b60:      	sub	x6, x8, #0x1
     b64:      	ldr	x8, [x21, #0x50]
     b68:      	add	x6, x8, x6, lsl #2
     b6c:      	ldr	w6, [x6]
     b70:      	sxtw	x6, w6
     b74:      	cmp	x6, #0x0
     b78:      	cset	w6, gt
     b7c:      	ubfx	x6, x6, #0, #8
     b80:      	b	0xc28 <_stogir.verify.structure+0xa88>
     b84:      	brk	#0
     b88:      	b	0xb84 <_stogir.verify.structure+0x9e4>
     b8c:      	movz	x6, #0x0, lsl #48
     b90:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b90:  ARM64_RELOC_PAGE21	l_stogir.321
     b94:      	ldr	x16, [x16]
		0000000000000b94:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     b98:      	ldr	w8, [x16]
     b9c:      	lsr	w6, w6, #0
     ba0:      	cmp	x6, x8
     ba4:      	b.ne	0xbb0 <_stogir.verify.structure+0xa10>
     ba8:      	ldr	w6, [sp, #0x158]
     bac:      	b	0x5b8 <_stogir.verify.structure+0x418>
     bb0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bb0:  ARM64_RELOC_PAGE21	l_stogir.322
     bb4:      	ldr	x16, [x16]
		0000000000000bb4:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     bb8:      	ldr	w8, [x16]
     bbc:      	cmp	x6, x8
     bc0:      	b.ne	0xbe4 <_stogir.verify.structure+0xa44>
     bc4:      	ldr	w6, [sp, #0x158]
     bc8:      	b	0x5b8 <_stogir.verify.structure+0x418>
     bcc:      	movz	x6, #0x0, lsl #48
     bd0:      	b	0xb90 <_stogir.verify.structure+0x9f0>
     bd4:      	movz	x6, #0x0, lsl #48
     bd8:      	b	0x5ac <_stogir.verify.structure+0x40c>
     bdc:      	movz	x4, #0x0, lsl #48
     be0:      	b	0xb20 <_stogir.verify.structure+0x980>
     be4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000be4:  ARM64_RELOC_PAGE21	l_stogir.323
     be8:      	ldr	x16, [x16]
		0000000000000be8:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     bec:      	ldr	w8, [x16]
     bf0:      	cmp	x6, x8
     bf4:      	b.ne	0xae8 <_stogir.verify.structure+0x948>
     bf8:      	ldr	w6, [sp, #0x158]
     bfc:      	b	0x5b8 <_stogir.verify.structure+0x418>
     c00:      	ldr	x8, [sp, #0x130]
     c04:      	lsl	x8, x8, #2
     c08:      	lsr	w8, w8, #0
     c0c:      	ubfx	x8, x8, #0, #32
     c10:      	lsr	x6, x6, x8
     c14:      	lsr	w6, w6, #0
     c18:      	and	x6, x6, #0xf
     c1c:      	lsr	w6, w6, #0
     c20:      	b	0xbd0 <_stogir.verify.structure+0xa30>
     c24:      	movz	x6, #0x0, lsl #48
     c28:      	b	0xbd8 <_stogir.verify.structure+0xa38>
     c2c:      	brk	#0
     c30:      	b	0xc2c <_stogir.verify.structure+0xa8c>
     c34:      	str	x8, [sp, #0xa0]
     c38:      	str	x12, [sp, #0xb8]
     c3c:      	str	x13, [sp, #0xc0]
     c40:      	b	0x510 <_stogir.verify.structure+0x370>
     c44:      	str	x8, [sp, #0xa0]
     c48:      	str	x12, [sp, #0xb8]
     c4c:      	str	x13, [sp, #0xc0]
     c50:      	b	0x510 <_stogir.verify.structure+0x370>
     c54:      	str	x8, [sp, #0xa0]
     c58:      	str	x19, [sp, #0x40]
     c5c:      	str	x20, [sp, #0x58]
     c60:      	str	x21, [sp, #0x60]
     c64:      	mov	x21, x0
     c68:      	str	x22, [sp, #0x68]
     c6c:      	str	x23, [sp, #0x70]
     c70:      	str	x24, [sp, #0x78]
     c74:      	str	x25, [sp, #0x80]
     c78:      	str	x26, [sp, #0x88]
     c7c:      	str	x27, [sp, #0x90]
     c80:      	str	x28, [sp, #0x98]
     c84:      	str	x4, [sp, #0x100]
     c88:      	mov	x0, x5
     c8c:      	mov	x5, x3
     c90:      	mov	x3, x11
     c94:      	mov	x4, x6
     c98:      	str	x9, [sp, #0x120]
     c9c:      	str	x10, [sp, #0x128]
     ca0:      	b	0x354 <_stogir.verify.structure+0x1b4>
     ca4:      	str	x8, [sp, #0xa0]
     ca8:      	str	x20, [sp, #0x58]
     cac:      	str	x21, [sp, #0x60]
     cb0:      	ldr	x21, [sp, #0x30]
     cb4:      	str	x22, [sp, #0x68]
     cb8:      	str	x23, [sp, #0x70]
     cbc:      	str	x24, [sp, #0x78]
     cc0:      	str	x25, [sp, #0x80]
     cc4:      	str	x26, [sp, #0x88]
     cc8:      	str	x27, [sp, #0x90]
     ccc:      	str	x28, [sp, #0x98]
     cd0:      	str	x4, [sp, #0x100]
     cd4:      	mov	x0, x5
     cd8:      	mov	x5, x3
     cdc:      	mov	x3, x11
     ce0:      	mov	x4, x6
     ce4:      	str	x9, [sp, #0x120]
     ce8:      	str	x10, [sp, #0x128]
     cec:      	b	0x2fc <_stogir.verify.structure+0x15c>
     cf0:      	mov	x1, x26
     cf4:      	ldr	x2, [sp, #0xb0]
     cf8:      	ldr	x5, [sp, #0xd8]
     cfc:      	str	x23, [sp, #0x100]
     d00:      	ldr	x3, [sp, #0xe0]
     d04:      	ldr	x0, [sp, #0xd0]
     d08:      	ldr	x4, [sp, #0xc8]
     d0c:      	ldr	x7, [sp, #0xa8]
     d10:      	str	x27, [sp, #0x120]
     d14:      	str	x28, [sp, #0x128]
     d18:      	b	0x2fc <_stogir.verify.structure+0x15c>
     d1c:      	str	x26, [sp, #0x140]
     d20:      	str	x20, [sp, #0x138]
     d24:      	str	x5, [sp, #0x110]
     d28:      	ldr	x5, [sp, #0xd8]
     d2c:      	str	x4, [sp, #0x108]
     d30:      	str	x23, [sp, #0x100]
     d34:      	ldr	x3, [sp, #0xe0]
     d38:      	ldr	x0, [sp, #0xd0]
     d3c:      	ldr	x4, [sp, #0xc8]
     d40:      	ldr	x7, [sp, #0xa8]
     d44:      	str	x27, [sp, #0x120]
     d48:      	str	x28, [sp, #0x128]
     d4c:      	b	0x200 <_stogir.verify.structure+0x60>
     d50:      	str	x23, [sp, #0x148]
     d54:      	mov	x23, x2
     d58:      	str	x25, [sp, #0x150]
     d5c:      	mov	x25, x0
     d60:      	str	w19, [sp, #0x158]
     d64:      	mov	w19, w1
     d68:      	b	0x824 <_stogir.verify.structure+0x684>
     d6c:      	ldr	x5, [sp, #0xd8]
     d70:      	ldr	x3, [sp, #0xe0]
     d74:      	b	0x8ac <_stogir.verify.structure+0x70c>
     d78:      	ldr	x0, [sp, #0xd0]
     d7c:      	ldr	x4, [sp, #0xc8]
     d80:      	ldr	x7, [sp, #0xa8]
     d84:      	ldr	w6, [sp, #0x158]
     d88:      	b	0x5b8 <_stogir.verify.structure+0x418>
     d8c:      	ldr	x0, [sp, #0xd0]
     d90:      	ldr	x4, [sp, #0xc8]
     d94:      	ldr	x7, [sp, #0xa8]
     d98:      	ldr	w6, [sp, #0x158]
     d9c:      	b	0x5b8 <_stogir.verify.structure+0x418>
     da0:      	ldr	x5, [sp, #0xd8]
     da4:      	b	0x870 <_stogir.verify.structure+0x6d0>
     da8:      	ldr	w6, [sp, #0x158]
     dac:      	b	0xb10 <_stogir.verify.structure+0x970>
     db0:      	ldr	x0, [sp, #0xd0]
     db4:      	b	0xb30 <_stogir.verify.structure+0x990>
     db8:      	ldr	x0, [sp, #0xd0]
     dbc:      	b	0xb1c <_stogir.verify.structure+0x97c>
     dc0:      	ldr	w6, [sp, #0x158]
     dc4:      	b	0xb10 <_stogir.verify.structure+0x970>
     dc8:      	ldr	x4, [sp, #0xc8]
     dcc:      	ldr	x7, [sp, #0xa8]
     dd0:      	b	0x5a8 <_stogir.verify.structure+0x408>

0000000000000dd4 <_stogir.verify.integer-operations-target-structured>:
     dd4:      	sub	sp, sp, #0x4a0
     dd8:      	str	x29, [sp, #0x10]
     ddc:      	str	x30, [sp, #0x18]
     de0:      	add	x29, sp, #0x10
     de4:      	str	x19, [sp, #0x448]
     de8:      	str	x20, [sp, #0x450]
     dec:      	str	x21, [sp, #0x458]
     df0:      	str	x22, [sp, #0x460]
     df4:      	str	x23, [sp, #0x468]
     df8:      	str	x24, [sp, #0x470]
     dfc:      	str	x25, [sp, #0x478]
     e00:      	str	x26, [sp, #0x480]
     e04:      	str	x27, [sp, #0x488]
     e08:      	str	x28, [sp, #0x490]
     e0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e0c:  ARM64_RELOC_PAGE21	l_stogir.324
     e10:      	ldr	x16, [x16]
		0000000000000e10:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     e14:      	orr	x2, x16, xzr
     e18:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e18:  ARM64_RELOC_PAGE21	l_stogir.325
     e1c:      	ldr	x16, [x16]
		0000000000000e1c:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     e20:      	orr	x19, x16, xzr
     e24:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e24:  ARM64_RELOC_PAGE21	l_stogir.326
     e28:      	ldr	x16, [x16]
		0000000000000e28:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     e2c:      	orr	x20, x16, xzr
     e30:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e30:  ARM64_RELOC_PAGE21	l_stogir.327
     e34:      	ldr	x16, [x16]
		0000000000000e34:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     e38:      	orr	x21, x16, xzr
     e3c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e3c:  ARM64_RELOC_PAGE21	l_stogir.328
     e40:      	ldr	x16, [x16]
		0000000000000e40:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     e44:      	orr	x22, x16, xzr
     e48:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e48:  ARM64_RELOC_PAGE21	l_stogir.329
     e4c:      	ldr	x16, [x16]
		0000000000000e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     e50:      	orr	x23, x16, xzr
     e54:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e54:  ARM64_RELOC_PAGE21	l_stogir.330
     e58:      	ldr	x16, [x16]
		0000000000000e58:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     e5c:      	orr	x24, x16, xzr
     e60:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e60:  ARM64_RELOC_PAGE21	l_stogir.331
     e64:      	ldr	x16, [x16]
		0000000000000e64:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     e68:      	orr	x25, x16, xzr
     e6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e6c:  ARM64_RELOC_PAGE21	l_stogir.332
     e70:      	ldr	x16, [x16]
		0000000000000e70:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     e74:      	orr	x26, x16, xzr
     e78:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e78:  ARM64_RELOC_PAGE21	l_stogir.333
     e7c:      	ldr	x16, [x16]
		0000000000000e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     e80:      	orr	x27, x16, xzr
     e84:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e84:  ARM64_RELOC_PAGE21	l_stogir.334
     e88:      	ldr	x16, [x16]
		0000000000000e88:  ARM64_RELOC_PAGEOFF12	l_stogir.334
     e8c:      	orr	x28, x16, xzr
     e90:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e90:  ARM64_RELOC_PAGE21	l_stogir.335
     e94:      	ldr	x16, [x16]
		0000000000000e94:  ARM64_RELOC_PAGEOFF12	l_stogir.335
     e98:      	orr	x3, x16, xzr
     e9c:      	lsr	w4, w1, #0
     ea0:      	lsr	w5, w1, #0
     ea4:      	lsr	w1, w1, #0
     ea8:      	add	x16, sp, #0x20
     eac:      	orr	x6, x16, xzr
     eb0:      	add	x16, sp, #0x30
     eb4:      	orr	x7, x16, xzr
     eb8:      	add	x7, x7, #0x8
     ebc:      	add	x16, sp, #0x50
     ec0:      	orr	x9, x16, xzr
     ec4:      	add	x9, x9, #0x8
     ec8:      	add	x16, sp, #0xe0
     ecc:      	orr	x10, x16, xzr
     ed0:      	add	x10, x10, #0x8
     ed4:      	add	x16, sp, #0x100
     ed8:      	orr	x11, x16, xzr
     edc:      	add	x11, x11, #0x8
     ee0:      	add	x16, sp, #0x120
     ee4:      	orr	x12, x16, xzr
     ee8:      	add	x12, x12, #0x8
     eec:      	add	x16, sp, #0x140
     ef0:      	orr	x13, x16, xzr
     ef4:      	add	x13, x13, #0x8
     ef8:      	add	x16, sp, #0x160
     efc:      	orr	x14, x16, xzr
     f00:      	add	x14, x14, #0x8
     f04:      	add	x16, sp, #0x180
     f08:      	orr	x15, x16, xzr
     f0c:      	add	x15, x15, #0x8
     f10:      	str	w1, [sp, #0x230]
     f14:      	add	x16, sp, #0x1a0
     f18:      	orr	x1, x16, xzr
     f1c:      	add	x1, x1, #0x8
     f20:      	str	x1, [sp, #0x238]
     f24:      	add	x16, sp, #0x1f0
     f28:      	orr	x1, x16, xzr
     f2c:      	add	x1, x1, #0x8
     f30:      	str	x19, [sp, #0x240]
     f34:      	str	x20, [sp, #0x250]
     f38:      	str	x2, [sp, #0x248]
     f3c:      	mov	x2, #0x1                ; =1
     f40:      	movz	x19, #0x0, lsl #48
     f44:      	movz	x20, #0x0, lsl #48
     f48:      	cmp	x20, #0x0
     f4c:      	b.ne	0x2228 <_stogir.verify.integer-operations-target-structured+0x1454>
     f50:      	str	x1, [sp, #0x258]
     f54:      	ldr	x1, [x0, #0x8]
     f58:      	cmp	x2, x1
     f5c:      	b.ge	0x2234 <_stogir.verify.integer-operations-target-structured+0x1460>
     f60:      	ldr	x1, [x0]
     f64:      	add	x1, x1, x2, lsl #4
     f68:      	str	x3, [sp, #0x260]
     f6c:      	ldr	x3, [x1]
     f70:      	str	x21, [sp, #0x268]
     f74:      	uxtb	w21, w3
     f78:      	ldr	x1, [x1, #0x8]
     f7c:      	str	x22, [sp, #0x270]
     f80:      	orr	x22, x21, xzr
     f84:      	add	x16, sp, #0x20
     f88:      	str	x3, [x16]
     f8c:      	add	x16, sp, #0x20
     f90:      	str	x1, [x16, #0x8]
     f94:      	ldr	x1, [x0, #0x78]
     f98:      	add	x1, x1, x2, lsl #2
     f9c:      	ldr	w1, [x1]
     fa0:      	cmp	x22, #0xe
     fa4:      	b.lt	0x17c0 <_stogir.verify.integer-operations-target-structured+0x9ec>
     fa8:      	cmp	x22, #0x17
     fac:      	cset	w3, le
     fb0:      	ubfx	x3, x3, #0, #8
     fb4:      	str	x23, [sp, #0x278]
     fb8:      	cmp	x22, #0x1a
     fbc:      	cset	w23, ge
     fc0:      	str	x24, [sp, #0x280]
     fc4:      	cmp	x22, #0x1e
     fc8:      	cset	w24, le
     fcc:      	str	x25, [sp, #0x288]
     fd0:      	cmp	x22, #0x2e
     fd4:      	cset	w25, ge
     fd8:      	str	x26, [sp, #0x290]
     fdc:      	cmp	x22, #0x35
     fe0:      	cset	w26, le
     fe4:      	str	x27, [sp, #0x298]
     fe8:      	cmp	x22, #0x3a
     fec:      	cset	w27, eq
     ff0:      	str	x28, [sp, #0x2a0]
     ff4:      	cmp	x22, #0x3b
     ff8:      	cset	w28, eq
     ffc:      	uxtb	w16, w23
    1000:      	cmp	w16, wzr
    1004:      	b.eq	0x17c8 <_stogir.verify.integer-operations-target-structured+0x9f4>
    1008:      	uxtb	w16, w24
    100c:      	cmp	w16, wzr
    1010:      	b.eq	0x17c8 <_stogir.verify.integer-operations-target-structured+0x9f4>
    1014:      	str	x0, [sp, #0x2a8]
    1018:      	mov	x0, #0x1                ; =1
    101c:      	cmp	x22, #0x1f
    1020:      	b.ne	0x1810 <_stogir.verify.integer-operations-target-structured+0xa3c>
    1024:      	str	x0, [sp, #0x2b0]
    1028:      	mov	x0, #0x1                ; =1
    102c:      	str	x0, [sp, #0x2b8]
    1030:      	lsr	w0, w2, #0
    1034:      	lsr	w1, w1, #0
    1038:      	lsr	w0, w0, #0
    103c:      	str	x8, [sp, #0x2c0]
    1040:      	str	w4, [sp, #0x2d0]
    1044:      	str	w5, [sp, #0x2d8]
    1048:      	str	x6, [sp, #0x2e0]
    104c:      	str	x15, [sp, #0x320]
    1050:      	str	x2, [sp, #0x328]
    1054:      	mov	x2, x6
    1058:      	str	w1, [sp, #0x330]
    105c:      	str	x3, [sp, #0x338]
    1060:      	mov	w3, w1
    1064:      	mov	w1, w0
    1068:      	str	w0, [sp, #0x340]
    106c:      	ldr	x0, [sp, #0x2a8]
    1070:      	str	x20, [sp, #0x2c8]
    1074:      	ldr	x20, [sp, #0x260]
    1078:      	str	w28, [sp, #0x2e8]
    107c:      	mov	x28, x7
    1080:      	str	w27, [sp, #0x2f0]
    1084:      	mov	x27, x9
    1088:      	str	w26, [sp, #0x2f8]
    108c:      	mov	x26, x10
    1090:      	str	w25, [sp, #0x300]
    1094:      	mov	x25, x11
    1098:      	str	w24, [sp, #0x308]
    109c:      	mov	x24, x12
    10a0:      	str	w23, [sp, #0x310]
    10a4:      	mov	x23, x13
    10a8:      	str	w21, [sp, #0x318]
    10ac:      	mov	x21, x14
    10b0:      	bl	0x10b0 <_stogir.verify.integer-operations-target-structured+0x2dc>
		00000000000010b0:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    10b4:      	uxtb	w1, w0
    10b8:      	cmp	x1, #0x0
    10bc:      	cset	w1, ne
    10c0:      	cmp	x22, #0x3d
    10c4:      	b.lt	0x1888 <_stogir.verify.integer-operations-target-structured+0xab4>
    10c8:      	cmp	x22, #0x3f
    10cc:      	b.gt	0x1888 <_stogir.verify.integer-operations-target-structured+0xab4>
    10d0:      	add	x8, sp, #0x30
    10d4:      	ldr	w2, [sp, #0x2d0]
    10d8:      	str	x0, [sp, #0x348]
    10dc:      	ldr	x0, [sp, #0x2a8]
    10e0:      	str	x21, [sp, #0x350]
    10e4:      	mov	w21, w1
    10e8:      	ldr	w1, [sp, #0x340]
    10ec:      	bl	0x10ec <_stogir.verify.integer-operations-target-structured+0x318>
		00000000000010ec:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    10f0:      	add	x16, sp, #0x30
    10f4:      	ldr	w0, [x16]
    10f8:      	lsr	x16, x0, #0
    10fc:      	cmp	x16, #0x1
    1100:      	b.eq	0x111c <_stogir.verify.integer-operations-target-structured+0x348>
    1104:      	b.lo	0x110c <_stogir.verify.integer-operations-target-structured+0x338>
    1108:      	b	0x1120 <_stogir.verify.integer-operations-target-structured+0x34c>
    110c:      	cmp	x16, #0x0
    1110:      	b.eq	0x1118 <_stogir.verify.integer-operations-target-structured+0x344>
    1114:      	b	0x1120 <_stogir.verify.integer-operations-target-structured+0x34c>
    1118:      	b	0x18ac <_stogir.verify.integer-operations-target-structured+0xad8>
    111c:      	b	0x1124 <_stogir.verify.integer-operations-target-structured+0x350>
    1120:      	b	0x21ac <_stogir.verify.integer-operations-target-structured+0x13d8>
    1124:      	add	x16, sp, #0x30
    1128:      	ldr	x0, [x16, #0x8]
    112c:      	ldr	x1, [x28, #0x8]
    1130:      	mov	x2, x1
    1134:      	mov	x1, x0
    1138:      	mov	x0, x19
    113c:      	mov	x19, x0
    1140:      	mov	x0, x1
    1144:      	mov	x1, x2
    1148:      	cmp	x22, #0x44
    114c:      	b.ne	0x18d0 <_stogir.verify.integer-operations-target-structured+0xafc>
    1150:      	uxtb	w16, w21
    1154:      	cmp	w16, wzr
    1158:      	b.eq	0x18c4 <_stogir.verify.integer-operations-target-structured+0xaf0>
    115c:      	mov	x2, x0
    1160:      	movz	x0, #0x0, lsl #48
    1164:      	fmov	d31, x1
    1168:      	mov	x1, x2
    116c:      	fmov	x2, d31
    1170:      	cmp	x0, #0x0
    1174:      	b.eq	0x2240 <_stogir.verify.integer-operations-target-structured+0x146c>
    1178:      	add	x8, sp, #0x50
    117c:      	ldr	x0, [sp, #0x2a8]
    1180:      	str	x1, [sp, #0x358]
    1184:      	ldr	w1, [sp, #0x340]
    1188:      	str	x2, [sp, #0x360]
    118c:      	bl	0x118c <_stogir.verify.integer-operations-target-structured+0x3b8>
		000000000000118c:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    1190:      	add	x16, sp, #0x50
    1194:      	ldr	w0, [x16]
    1198:      	lsr	x16, x0, #0
    119c:      	cmp	x16, #0x1
    11a0:      	b.eq	0x11bc <_stogir.verify.integer-operations-target-structured+0x3e8>
    11a4:      	b.lo	0x11ac <_stogir.verify.integer-operations-target-structured+0x3d8>
    11a8:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x3ec>
    11ac:      	cmp	x16, #0x0
    11b0:      	b.eq	0x11b8 <_stogir.verify.integer-operations-target-structured+0x3e4>
    11b4:      	b	0x11c0 <_stogir.verify.integer-operations-target-structured+0x3ec>
    11b8:      	b	0x18e0 <_stogir.verify.integer-operations-target-structured+0xb0c>
    11bc:      	b	0x11c4 <_stogir.verify.integer-operations-target-structured+0x3f0>
    11c0:      	b	0x18f8 <_stogir.verify.integer-operations-target-structured+0xb24>
    11c4:      	add	x16, sp, #0x50
    11c8:      	ldr	x0, [x16, #0x8]
    11cc:      	ldr	x1, [x27, #0x8]
    11d0:      	mov	x2, x1
    11d4:      	mov	x1, x0
    11d8:      	mov	x0, x19
    11dc:      	mov	x19, x0
    11e0:      	mov	x0, x1
    11e4:      	mov	x1, x2
    11e8:      	cmp	x22, #0x1d
    11ec:      	b.ne	0x190c <_stogir.verify.integer-operations-target-structured+0xb38>
    11f0:      	mov	x2, x1
    11f4:      	mov	x1, x0
    11f8:      	mov	x0, #0x1                ; =1
    11fc:      	cmp	x0, #0x0
    1200:      	b.eq	0x1934 <_stogir.verify.integer-operations-target-structured+0xb60>
    1204:      	add	x16, sp, #0x20
    1208:      	ldr	w0, [x16, #0xc]
    120c:      	sxtw	x0, w0
    1210:      	cmp	x0, #0x0
    1214:      	b.ne	0x192c <_stogir.verify.integer-operations-target-structured+0xb58>
    1218:      	movz	x0, #0x0, lsl #48
    121c:      	cmp	x0, #0x0
    1220:      	b.eq	0x224c <_stogir.verify.integer-operations-target-structured+0x1478>
    1224:      	add	x16, sp, #0x20
    1228:      	ldr	w0, [x16, #0xc]
    122c:      	lsr	w0, w0, #0
    1230:      	add	x8, sp, #0x70
    1234:      	str	x1, [sp, #0x368]
    1238:      	mov	w1, w0
    123c:      	ldr	x0, [sp, #0x2a8]
    1240:      	str	x2, [sp, #0x370]
    1244:      	bl	0x1244 <_stogir.verify.integer-operations-target-structured+0x470>
		0000000000001244:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1248:      	add	x16, sp, #0x70
    124c:      	ldr	w0, [x16]
    1250:      	lsr	x16, x0, #0
    1254:      	cmp	x16, #0x1
    1258:      	b.eq	0x1274 <_stogir.verify.integer-operations-target-structured+0x4a0>
    125c:      	b.lo	0x1264 <_stogir.verify.integer-operations-target-structured+0x490>
    1260:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x4a4>
    1264:      	cmp	x16, #0x0
    1268:      	b.eq	0x1270 <_stogir.verify.integer-operations-target-structured+0x49c>
    126c:      	b	0x1278 <_stogir.verify.integer-operations-target-structured+0x4a4>
    1270:      	b	0x127c <_stogir.verify.integer-operations-target-structured+0x4a8>
    1274:      	b	0x193c <_stogir.verify.integer-operations-target-structured+0xb68>
    1278:      	b	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    127c:      	ldr	x0, [sp, #0x240]
    1280:      	mov	x1, #0x16               ; =22
    1284:      	cmp	x22, #0x2c
    1288:      	cset	w2, eq
    128c:      	cmp	x22, #0x29
    1290:      	b.lt	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc30>
    1294:      	cmp	x22, #0x2b
    1298:      	b.gt	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc30>
    129c:      	uxtb	w16, w2
    12a0:      	cmp	w16, wzr
    12a4:      	b.eq	0x2258 <_stogir.verify.integer-operations-target-structured+0x1484>
    12a8:      	add	x8, sp, #0xa0
    12ac:      	str	x0, [sp, #0x378]
    12b0:      	ldr	x0, [sp, #0x2a8]
    12b4:      	str	x1, [sp, #0x380]
    12b8:      	ldr	w1, [sp, #0x340]
    12bc:      	bl	0x12bc <_stogir.verify.integer-operations-target-structured+0x4e8>
		00000000000012bc:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    12c0:      	add	x16, sp, #0xa0
    12c4:      	ldr	x0, [x16]
    12c8:      	add	x16, sp, #0xa0
    12cc:      	ldr	x1, [x16, #0x8]
    12d0:      	add	x16, sp, #0xa0
    12d4:      	ldr	x2, [x16, #0x10]
    12d8:      	lsr	w0, w0, #0
    12dc:      	lsr	x16, x0, #0
    12e0:      	cmp	x16, #0x1
    12e4:      	b.eq	0x1300 <_stogir.verify.integer-operations-target-structured+0x52c>
    12e8:      	b.lo	0x12f0 <_stogir.verify.integer-operations-target-structured+0x51c>
    12ec:      	b	0x1304 <_stogir.verify.integer-operations-target-structured+0x530>
    12f0:      	cmp	x16, #0x0
    12f4:      	b.eq	0x12fc <_stogir.verify.integer-operations-target-structured+0x528>
    12f8:      	b	0x1304 <_stogir.verify.integer-operations-target-structured+0x530>
    12fc:      	b	0x1a40 <_stogir.verify.integer-operations-target-structured+0xc6c>
    1300:      	b	0x1308 <_stogir.verify.integer-operations-target-structured+0x534>
    1304:      	b	0x21a4 <_stogir.verify.integer-operations-target-structured+0x13d0>
    1308:      	mov	x0, x19
    130c:      	mov	x19, x0
    1310:      	mov	x0, x1
    1314:      	mov	x1, x2
    1318:      	cmp	x22, #0x7e
    131c:      	b.lt	0x2264 <_stogir.verify.integer-operations-target-structured+0x1490>
    1320:      	cmp	x22, #0x82
    1324:      	b.gt	0x2270 <_stogir.verify.integer-operations-target-structured+0x149c>
    1328:      	add	x8, sp, #0xe0
    132c:      	str	x0, [sp, #0x388]
    1330:      	ldr	x0, [sp, #0x2a8]
    1334:      	str	x1, [sp, #0x390]
    1338:      	ldr	w1, [sp, #0x340]
    133c:      	bl	0x133c <_stogir.verify.integer-operations-target-structured+0x568>
		000000000000133c:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1340:      	add	x16, sp, #0xe0
    1344:      	ldr	w0, [x16]
    1348:      	lsr	x16, x0, #0
    134c:      	cmp	x16, #0x1
    1350:      	b.eq	0x136c <_stogir.verify.integer-operations-target-structured+0x598>
    1354:      	b.lo	0x135c <_stogir.verify.integer-operations-target-structured+0x588>
    1358:      	b	0x1370 <_stogir.verify.integer-operations-target-structured+0x59c>
    135c:      	cmp	x16, #0x0
    1360:      	b.eq	0x1368 <_stogir.verify.integer-operations-target-structured+0x594>
    1364:      	b	0x1370 <_stogir.verify.integer-operations-target-structured+0x59c>
    1368:      	b	0x1a58 <_stogir.verify.integer-operations-target-structured+0xc84>
    136c:      	b	0x1374 <_stogir.verify.integer-operations-target-structured+0x5a0>
    1370:      	b	0x1a70 <_stogir.verify.integer-operations-target-structured+0xc9c>
    1374:      	add	x16, sp, #0xe0
    1378:      	ldr	x0, [x16, #0x8]
    137c:      	ldr	x1, [x26, #0x8]
    1380:      	mov	x2, x1
    1384:      	mov	x1, x0
    1388:      	mov	x0, x19
    138c:      	mov	x19, x0
    1390:      	mov	x0, x1
    1394:      	mov	x1, x2
    1398:      	cmp	x22, #0x60
    139c:      	b.eq	0x1a84 <_stogir.verify.integer-operations-target-structured+0xcb0>
    13a0:      	cmp	x22, #0x79
    13a4:      	b.eq	0x1a84 <_stogir.verify.integer-operations-target-structured+0xcb0>
    13a8:      	cmp	x22, #0x75
    13ac:      	b.eq	0x1b10 <_stogir.verify.integer-operations-target-structured+0xd3c>
    13b0:      	cmp	x22, #0x6d
    13b4:      	b.lt	0x227c <_stogir.verify.integer-operations-target-structured+0x14a8>
    13b8:      	cmp	x22, #0x6f
    13bc:      	b.le	0x1b10 <_stogir.verify.integer-operations-target-structured+0xd3c>
    13c0:      	str	x0, [sp, #0x3a8]
    13c4:      	str	x1, [sp, #0x3b0]
    13c8:      	ldr	x0, [sp, #0x3a8]
    13cc:      	ldr	x1, [sp, #0x3b0]
    13d0:      	cmp	x22, #0x42
    13d4:      	b.eq	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdd0>
    13d8:      	cmp	x22, #0x51
    13dc:      	b.eq	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdd0>
    13e0:      	cmp	x22, #0x52
    13e4:      	b.eq	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdd0>
    13e8:      	cmp	x22, #0x53
    13ec:      	b.eq	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdd0>
    13f0:      	cmp	x22, #0x54
    13f4:      	b.eq	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xdd0>
    13f8:      	cmp	x22, #0x41
    13fc:      	b.eq	0x1c30 <_stogir.verify.integer-operations-target-structured+0xe5c>
    1400:      	cmp	x22, #0x48
    1404:      	b.eq	0x1c30 <_stogir.verify.integer-operations-target-structured+0xe5c>
    1408:      	cmp	x22, #0x55
    140c:      	b.lt	0x2288 <_stogir.verify.integer-operations-target-structured+0x14b4>
    1410:      	cmp	x22, #0x58
    1414:      	b.le	0x1c30 <_stogir.verify.integer-operations-target-structured+0xe5c>
    1418:      	str	x0, [sp, #0x3c8]
    141c:      	str	x1, [sp, #0x3d0]
    1420:      	ldr	x1, [sp, #0x350]
    1424:      	ldr	x0, [sp, #0x3c8]
    1428:      	ldr	x2, [sp, #0x3d0]
    142c:      	cmp	x22, #0x21
    1430:      	b.lt	0x2298 <_stogir.verify.integer-operations-target-structured+0x14c4>
    1434:      	cmp	x22, #0x27
    1438:      	b.gt	0x22ac <_stogir.verify.integer-operations-target-structured+0x14d8>
    143c:      	add	x8, sp, #0x180
    1440:      	str	x1, [sp, #0x350]
    1444:      	ldr	w1, [sp, #0x340]
    1448:      	str	x0, [sp, #0x3d8]
    144c:      	ldr	x0, [sp, #0x2a8]
    1450:      	str	x2, [sp, #0x3e0]
    1454:      	ldr	w2, [sp, #0x230]
    1458:      	bl	0x1458 <_stogir.verify.integer-operations-target-structured+0x684>
		0000000000001458:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    145c:      	add	x16, sp, #0x180
    1460:      	ldr	w0, [x16]
    1464:      	lsr	x16, x0, #0
    1468:      	cmp	x16, #0x1
    146c:      	b.eq	0x148c <_stogir.verify.integer-operations-target-structured+0x6b8>
    1470:      	b.lo	0x1478 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1474:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6bc>
    1478:      	cmp	x16, #0x0
    147c:      	b.eq	0x1484 <_stogir.verify.integer-operations-target-structured+0x6b0>
    1480:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6bc>
    1484:      	ldr	x1, [sp, #0x320]
    1488:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xefc>
    148c:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x6c0>
    1490:      	b	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xf14>
    1494:      	add	x16, sp, #0x180
    1498:      	ldr	x0, [x16, #0x8]
    149c:      	ldr	x1, [sp, #0x320]
    14a0:      	ldr	x2, [x1, #0x8]
    14a4:      	mov	x3, x2
    14a8:      	mov	x2, x0
    14ac:      	mov	x0, x19
    14b0:      	mov	x19, x0
    14b4:      	mov	x0, x2
    14b8:      	mov	x2, x3
    14bc:      	cmp	x22, #0x3c
    14c0:      	b.ne	0x22c0 <_stogir.verify.integer-operations-target-structured+0x14ec>
    14c4:      	add	x8, sp, #0x1a0
    14c8:      	str	x1, [sp, #0x320]
    14cc:      	ldr	w1, [sp, #0x340]
    14d0:      	str	x0, [sp, #0x3e8]
    14d4:      	ldr	x0, [sp, #0x2a8]
    14d8:      	str	x2, [sp, #0x3f0]
    14dc:      	bl	0x14dc <_stogir.verify.integer-operations-target-structured+0x708>
		00000000000014dc:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    14e0:      	add	x16, sp, #0x1a0
    14e4:      	ldr	w0, [x16]
    14e8:      	lsr	x16, x0, #0
    14ec:      	cmp	x16, #0x1
    14f0:      	b.eq	0x1510 <_stogir.verify.integer-operations-target-structured+0x73c>
    14f4:      	b.lo	0x14fc <_stogir.verify.integer-operations-target-structured+0x728>
    14f8:      	b	0x1514 <_stogir.verify.integer-operations-target-structured+0x740>
    14fc:      	cmp	x16, #0x0
    1500:      	b.eq	0x1508 <_stogir.verify.integer-operations-target-structured+0x734>
    1504:      	b	0x1514 <_stogir.verify.integer-operations-target-structured+0x740>
    1508:      	ldr	x1, [sp, #0x238]
    150c:      	b	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf28>
    1510:      	b	0x1518 <_stogir.verify.integer-operations-target-structured+0x744>
    1514:      	b	0x1d14 <_stogir.verify.integer-operations-target-structured+0xf40>
    1518:      	add	x16, sp, #0x1a0
    151c:      	ldr	x0, [x16, #0x8]
    1520:      	ldr	x1, [sp, #0x238]
    1524:      	ldr	x2, [x1, #0x8]
    1528:      	mov	x3, x2
    152c:      	mov	x2, x0
    1530:      	mov	x0, x19
    1534:      	mov	x19, x0
    1538:      	mov	x0, x2
    153c:      	mov	x2, x3
    1540:      	cmp	x22, #0x78
    1544:      	b.ne	0x22d4 <_stogir.verify.integer-operations-target-structured+0x1500>
    1548:      	add	x16, sp, #0x20
    154c:      	ldr	w3, [x16]
    1550:      	ubfx	x3, x3, #8, #8
    1554:      	cmp	x3, #0x0
    1558:      	b.ne	0x1d28 <_stogir.verify.integer-operations-target-structured+0xf54>
    155c:      	add	x16, sp, #0x20
    1560:      	ldr	w3, [x16, #0x8]
    1564:      	sxtw	x3, w3
    1568:      	cmp	x3, #0x0
    156c:      	b.eq	0x1578 <_stogir.verify.integer-operations-target-structured+0x7a4>
    1570:      	ldr	x0, [sp, #0x268]
    1574:      	mov	x2, #0x1f               ; =31
    1578:      	str	x1, [sp, #0x238]
    157c:      	mov	x1, x2
    1580:      	add	x2, x19, #0x1
    1584:      	lsr	w2, w2, #0
    1588:      	sxtw	x2, w2
    158c:      	mov	x19, x2
    1590:      	ldr	x2, [sp, #0x348]
    1594:      	uxth	w2, w2
    1598:      	mov	w17, #0x8               ; =8
    159c:      	uxth	w16, w2
    15a0:      	ubfx	w17, w17, #0, #4
    15a4:      	lsr	w2, w16, w17
    15a8:      	uxth	w2, w2
    15ac:      	uxtb	w2, w2
    15b0:      	cmp	x2, #0x0
    15b4:      	b.eq	0x22e4 <_stogir.verify.integer-operations-target-structured+0x1510>
    15b8:      	add	x8, sp, #0x1f0
    15bc:      	str	x0, [sp, #0x408]
    15c0:      	ldr	x0, [sp, #0x2a8]
    15c4:      	str	x1, [sp, #0x410]
    15c8:      	ldr	w1, [sp, #0x340]
    15cc:      	str	x20, [sp, #0x260]
    15d0:      	mov	x20, x2
    15d4:      	bl	0x15d4 <_stogir.verify.integer-operations-target-structured+0x800>
		00000000000015d4:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    15d8:      	add	x16, sp, #0x1f0
    15dc:      	ldr	w0, [x16]
    15e0:      	lsr	x16, x0, #0
    15e4:      	cmp	x16, #0x1
    15e8:      	b.eq	0x1608 <_stogir.verify.integer-operations-target-structured+0x834>
    15ec:      	b.lo	0x15f4 <_stogir.verify.integer-operations-target-structured+0x820>
    15f0:      	b	0x160c <_stogir.verify.integer-operations-target-structured+0x838>
    15f4:      	cmp	x16, #0x0
    15f8:      	b.eq	0x1600 <_stogir.verify.integer-operations-target-structured+0x82c>
    15fc:      	b	0x160c <_stogir.verify.integer-operations-target-structured+0x838>
    1600:      	ldr	x1, [sp, #0x258]
    1604:      	b	0x1de0 <_stogir.verify.integer-operations-target-structured+0x100c>
    1608:      	b	0x1610 <_stogir.verify.integer-operations-target-structured+0x83c>
    160c:      	b	0x1df8 <_stogir.verify.integer-operations-target-structured+0x1024>
    1610:      	add	x16, sp, #0x1f0
    1614:      	ldr	x0, [x16, #0x8]
    1618:      	ldr	x1, [sp, #0x258]
    161c:      	ldr	x2, [x1, #0x8]
    1620:      	mov	x3, x2
    1624:      	mov	x2, x0
    1628:      	mov	x0, x19
    162c:      	mov	x19, x0
    1630:      	mov	x0, x2
    1634:      	mov	x2, x3
    1638:      	uxtb	w16, w21
    163c:      	cmp	w16, wzr
    1640:      	b.eq	0x1e0c <_stogir.verify.integer-operations-target-structured+0x1038>
    1644:      	mov	x3, x2
    1648:      	mov	x2, x0
    164c:      	movz	x0, #0x0, lsl #48
    1650:      	cmp	x0, #0x0
    1654:      	b.eq	0x22fc <_stogir.verify.integer-operations-target-structured+0x1528>
    1658:      	cmp	x20, #0x0
    165c:      	b.eq	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1048>
    1660:      	movz	x0, #0x0, lsl #48
    1664:      	cmp	x0, #0x0
    1668:      	b.eq	0x2308 <_stogir.verify.integer-operations-target-structured+0x1534>
    166c:      	ldr	x20, [sp, #0x338]
    1670:      	cmp	x20, #0x0
    1674:      	b.eq	0x1e24 <_stogir.verify.integer-operations-target-structured+0x1050>
    1678:      	ldr	x21, [sp, #0x2b0]
    167c:      	mov	x0, #0x1                ; =1
    1680:      	cmp	x0, #0x0
    1684:      	b.eq	0x2314 <_stogir.verify.integer-operations-target-structured+0x1540>
    1688:      	add	x16, sp, #0x210
    168c:      	str	x16, [sp]
    1690:      	ldr	x0, [sp, #0x2a8]
    1694:      	str	x1, [sp, #0x258]
    1698:      	ldr	w1, [sp, #0x340]
    169c:      	str	x2, [sp, #0x418]
    16a0:      	str	x3, [sp, #0x420]
    16a4:      	mov	x2, #0x1                ; =1
    16a8:      	bl	0x16a8 <_stogir.verify.integer-operations-target-structured+0x8d4>
		00000000000016a8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    16ac:      	ldr	x16, [sp]
    16b0:      	str	x0, [x16]
    16b4:      	str	x1, [x16, #0x8]
    16b8:      	add	x16, sp, #0x210
    16bc:      	ldr	x0, [x16]
    16c0:      	add	x16, sp, #0x210
    16c4:      	ldr	x1, [x16, #0x8]
    16c8:      	lsr	w0, w0, #0
    16cc:      	lsr	x16, x0, #0
    16d0:      	cmp	x16, #0x1
    16d4:      	b.eq	0x16f0 <_stogir.verify.integer-operations-target-structured+0x91c>
    16d8:      	b.lo	0x16e0 <_stogir.verify.integer-operations-target-structured+0x90c>
    16dc:      	b	0x16f4 <_stogir.verify.integer-operations-target-structured+0x920>
    16e0:      	cmp	x16, #0x0
    16e4:      	b.eq	0x16ec <_stogir.verify.integer-operations-target-structured+0x918>
    16e8:      	b	0x16f4 <_stogir.verify.integer-operations-target-structured+0x920>
    16ec:      	b	0x16f8 <_stogir.verify.integer-operations-target-structured+0x924>
    16f0:      	b	0x1e50 <_stogir.verify.integer-operations-target-structured+0x107c>
    16f4:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13a8>
    16f8:      	str	x26, [sp, #0x440]
    16fc:      	str	x25, [sp, #0x438]
    1700:      	str	x24, [sp, #0x430]
    1704:      	str	x23, [sp, #0x428]
    1708:      	ldr	x0, [sp, #0x280]
    170c:      	mov	x1, #0x17               ; =23
    1710:      	add	x2, x19, #0x1
    1714:      	lsr	w2, w2, #0
    1718:      	sxtw	x2, w2
    171c:      	fmov	d31, x0
    1720:      	mov	x0, x2
    1724:      	mov	x2, x1
    1728:      	fmov	x1, d31
    172c:      	ldr	w3, [sp, #0x330]
    1730:      	sxtw	x3, w3
    1734:      	add	x3, x3, #0x4
    1738:      	asr	x16, x3, #63
    173c:      	lsr	x16, x16, #62
    1740:      	add	x3, x3, x16
    1744:      	asr	x3, x3, #2
    1748:      	ldr	x4, [sp, #0x328]
    174c:      	add	x3, x3, x4
    1750:      	ldr	x8, [sp, #0x2c0]
    1754:      	ldr	x6, [sp, #0x2e0]
    1758:      	ldr	x21, [sp, #0x268]
    175c:      	ldr	x22, [sp, #0x270]
    1760:      	ldr	x23, [sp, #0x278]
    1764:      	ldr	x24, [sp, #0x280]
    1768:      	ldr	x25, [sp, #0x288]
    176c:      	ldr	x26, [sp, #0x290]
    1770:      	ldr	w4, [sp, #0x2d0]
    1774:      	mov	x7, x28
    1778:      	ldr	x28, [sp, #0x2a0]
    177c:      	mov	x9, x27
    1780:      	ldr	x27, [sp, #0x298]
    1784:      	ldr	x10, [sp, #0x440]
    1788:      	ldr	x11, [sp, #0x438]
    178c:      	ldr	x12, [sp, #0x430]
    1790:      	ldr	x13, [sp, #0x428]
    1794:      	ldr	w5, [sp, #0x2d8]
    1798:      	ldr	x14, [sp, #0x350]
    179c:      	ldr	x15, [sp, #0x320]
    17a0:      	mov	x19, x0
    17a4:      	ldr	x0, [sp, #0x2a8]
    17a8:      	str	x1, [sp, #0x248]
    17ac:      	ldr	x1, [sp, #0x258]
    17b0:      	mov	x20, x2
    17b4:      	mov	x2, x3
    17b8:      	ldr	x3, [sp, #0x260]
    17bc:      	b	0xf48 <_stogir.verify.integer-operations-target-structured+0x174>
    17c0:      	movz	x3, #0x0, lsl #48
    17c4:      	b	0xfb4 <_stogir.verify.integer-operations-target-structured+0x1e0>
    17c8:      	uxtb	w16, w25
    17cc:      	cmp	w16, wzr
    17d0:      	b.eq	0x17ec <_stogir.verify.integer-operations-target-structured+0xa18>
    17d4:      	uxtb	w16, w26
    17d8:      	cmp	w16, wzr
    17dc:      	b.eq	0x17ec <_stogir.verify.integer-operations-target-structured+0xa18>
    17e0:      	str	x0, [sp, #0x2a8]
    17e4:      	mov	x0, #0x1                ; =1
    17e8:      	b	0x101c <_stogir.verify.integer-operations-target-structured+0x248>
    17ec:      	uxtb	w16, w27
    17f0:      	cmp	w16, wzr
    17f4:      	b.eq	0x1804 <_stogir.verify.integer-operations-target-structured+0xa30>
    17f8:      	str	x0, [sp, #0x2a8]
    17fc:      	mov	x0, #0x1                ; =1
    1800:      	b	0x17e8 <_stogir.verify.integer-operations-target-structured+0xa14>
    1804:      	str	x0, [sp, #0x2a8]
    1808:      	ubfx	x0, x28, #0, #8
    180c:      	b	0x1800 <_stogir.verify.integer-operations-target-structured+0xa2c>
    1810:      	cmp	x22, #0x20
    1814:      	b.ne	0x1824 <_stogir.verify.integer-operations-target-structured+0xa50>
    1818:      	str	x0, [sp, #0x2b0]
    181c:      	mov	x0, #0x1                ; =1
    1820:      	b	0x102c <_stogir.verify.integer-operations-target-structured+0x258>
    1824:      	cmp	x22, #0x2d
    1828:      	b.ne	0x1838 <_stogir.verify.integer-operations-target-structured+0xa64>
    182c:      	str	x0, [sp, #0x2b0]
    1830:      	mov	x0, #0x1                ; =1
    1834:      	b	0x1820 <_stogir.verify.integer-operations-target-structured+0xa4c>
    1838:      	cmp	x22, #0x36
    183c:      	b.ne	0x184c <_stogir.verify.integer-operations-target-structured+0xa78>
    1840:      	str	x0, [sp, #0x2b0]
    1844:      	mov	x0, #0x1                ; =1
    1848:      	b	0x1834 <_stogir.verify.integer-operations-target-structured+0xa60>
    184c:      	cmp	x22, #0x37
    1850:      	b.ne	0x1860 <_stogir.verify.integer-operations-target-structured+0xa8c>
    1854:      	str	x0, [sp, #0x2b0]
    1858:      	mov	x0, #0x1                ; =1
    185c:      	b	0x1848 <_stogir.verify.integer-operations-target-structured+0xa74>
    1860:      	cmp	x22, #0x38
    1864:      	b.ne	0x1874 <_stogir.verify.integer-operations-target-structured+0xaa0>
    1868:      	str	x0, [sp, #0x2b0]
    186c:      	mov	x0, #0x1                ; =1
    1870:      	b	0x185c <_stogir.verify.integer-operations-target-structured+0xa88>
    1874:      	str	x0, [sp, #0x2b0]
    1878:      	cmp	x22, #0x39
    187c:      	cset	w0, eq
    1880:      	ubfx	x0, x0, #0, #8
    1884:      	b	0x1870 <_stogir.verify.integer-operations-target-structured+0xa9c>
    1888:      	uxtb	w16, w1
    188c:      	cmp	w16, wzr
    1890:      	b.ne	0x10d0 <_stogir.verify.integer-operations-target-structured+0x2fc>
    1894:      	str	x0, [sp, #0x348]
    1898:      	str	x21, [sp, #0x350]
    189c:      	mov	w21, w1
    18a0:      	ldr	x0, [sp, #0x248]
    18a4:      	ldr	x1, [sp, #0x2c8]
    18a8:      	b	0x1148 <_stogir.verify.integer-operations-target-structured+0x374>
    18ac:      	add	x0, x19, #0x1
    18b0:      	lsr	w0, w0, #0
    18b4:      	sxtw	x0, w0
    18b8:      	ldr	x1, [sp, #0x248]
    18bc:      	ldr	x2, [sp, #0x2c8]
    18c0:      	b	0x113c <_stogir.verify.integer-operations-target-structured+0x368>
    18c4:      	mov	x2, x0
    18c8:      	mov	x0, #0x1                ; =1
    18cc:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x390>
    18d0:      	mov	x2, x1
    18d4:      	mov	x1, x0
    18d8:      	movz	x0, #0x0, lsl #48
    18dc:      	b	0x1170 <_stogir.verify.integer-operations-target-structured+0x39c>
    18e0:      	add	x0, x19, #0x1
    18e4:      	lsr	w0, w0, #0
    18e8:      	sxtw	x0, w0
    18ec:      	ldr	x1, [sp, #0x358]
    18f0:      	ldr	x2, [sp, #0x360]
    18f4:      	b	0x11dc <_stogir.verify.integer-operations-target-structured+0x408>
    18f8:      	brk	#0
    18fc:      	b	0x18f8 <_stogir.verify.integer-operations-target-structured+0xb24>
    1900:      	ldr	x0, [sp, #0x358]
    1904:      	ldr	x1, [sp, #0x360]
    1908:      	b	0x11e8 <_stogir.verify.integer-operations-target-structured+0x414>
    190c:      	cmp	x22, #0x1e
    1910:      	cset	w2, eq
    1914:      	ubfx	x2, x2, #0, #8
    1918:      	fmov	d31, x0
    191c:      	mov	x0, x2
    1920:      	mov	x2, x1
    1924:      	fmov	x1, d31
    1928:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x428>
    192c:      	mov	x0, #0x1                ; =1
    1930:      	b	0x121c <_stogir.verify.integer-operations-target-structured+0x448>
    1934:      	movz	x0, #0x0, lsl #48
    1938:      	b	0x121c <_stogir.verify.integer-operations-target-structured+0x448>
    193c:      	add	x16, sp, #0x70
    1940:      	ldr	x0, [x16, #0x8]
    1944:      	add	x16, sp, #0x20
    1948:      	ldr	w1, [x16, #0xc]
    194c:      	sxtw	x1, w1
    1950:      	cmp	x1, #0x0
    1954:      	b.ge	0x1978 <_stogir.verify.integer-operations-target-structured+0xba4>
    1958:      	ldr	x1, [sp, #0x368]
    195c:      	ldr	x2, [sp, #0x370]
    1960:      	mov	x0, #0x1                ; =1
    1964:      	cmp	x0, #0x0
    1968:      	b.eq	0x19e4 <_stogir.verify.integer-operations-target-structured+0xc10>
    196c:      	ldr	x0, [sp, #0x250]
    1970:      	mov	x1, #0x2d               ; =45
    1974:      	b	0x1284 <_stogir.verify.integer-operations-target-structured+0x4b0>
    1978:      	uxtb	w0, w0
    197c:      	cmp	x0, #0x83
    1980:      	b.ge	0x19d4 <_stogir.verify.integer-operations-target-structured+0xc00>
    1984:      	add	x1, x0, x20
    1988:      	ldrb	w1, [x1]
    198c:      	uxtb	w1, w1
    1990:      	and	x1, x1, #0x2
    1994:      	uxtb	w1, w1
    1998:      	cmp	x1, #0x0
    199c:      	cset	w1, eq
    19a0:      	uxtb	w16, w1
    19a4:      	cmp	w16, wzr
    19a8:      	cset	x1, eq
    19ac:      	cmp	x1, #0x0
    19b0:      	b.ne	0x19dc <_stogir.verify.integer-operations-target-structured+0xc08>
    19b4:      	cmp	x0, #0x65
    19b8:      	b.eq	0x19dc <_stogir.verify.integer-operations-target-structured+0xc08>
    19bc:      	cmp	x0, #0x66
    19c0:      	b.eq	0x19dc <_stogir.verify.integer-operations-target-structured+0xc08>
    19c4:      	mov	x0, #0x1                ; =1
    19c8:      	ldr	x1, [sp, #0x368]
    19cc:      	ldr	x2, [sp, #0x370]
    19d0:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xb90>
    19d4:      	movz	x1, #0x0, lsl #48
    19d8:      	b	0x198c <_stogir.verify.integer-operations-target-structured+0xbb8>
    19dc:      	movz	x0, #0x0, lsl #48
    19e0:      	b	0x19c8 <_stogir.verify.integer-operations-target-structured+0xbf4>
    19e4:      	mov	x0, x1
    19e8:      	mov	x1, x2
    19ec:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xba0>
    19f0:      	brk	#0
    19f4:      	b	0x19f0 <_stogir.verify.integer-operations-target-structured+0xc1c>
    19f8:      	ldr	x0, [sp, #0x368]
    19fc:      	ldr	x1, [sp, #0x370]
    1a00:      	b	0x1284 <_stogir.verify.integer-operations-target-structured+0x4b0>
    1a04:      	uxtb	w16, w2
    1a08:      	cmp	w16, wzr
    1a0c:      	b.ne	0x129c <_stogir.verify.integer-operations-target-structured+0x4c8>
    1a10:      	b	0x1318 <_stogir.verify.integer-operations-target-structured+0x544>
    1a14:      	add	x8, sp, #0xc0
    1a18:      	ldr	x0, [sp, #0x2a8]
    1a1c:      	ldr	w1, [sp, #0x340]
    1a20:      	bl	0x1a20 <_stogir.verify.integer-operations-target-structured+0xc4c>
		0000000000001a20:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1a24:      	add	x16, sp, #0xc0
    1a28:      	ldr	x0, [x16]
    1a2c:      	add	x16, sp, #0xc0
    1a30:      	ldr	x1, [x16, #0x8]
    1a34:      	add	x16, sp, #0xc0
    1a38:      	ldr	x2, [x16, #0x10]
    1a3c:      	b	0x12d8 <_stogir.verify.integer-operations-target-structured+0x504>
    1a40:      	add	x0, x19, #0x1
    1a44:      	lsr	w0, w0, #0
    1a48:      	sxtw	x0, w0
    1a4c:      	ldr	x1, [sp, #0x378]
    1a50:      	ldr	x2, [sp, #0x380]
    1a54:      	b	0x130c <_stogir.verify.integer-operations-target-structured+0x538>
    1a58:      	add	x0, x19, #0x1
    1a5c:      	lsr	w0, w0, #0
    1a60:      	sxtw	x0, w0
    1a64:      	ldr	x1, [sp, #0x388]
    1a68:      	ldr	x2, [sp, #0x390]
    1a6c:      	b	0x138c <_stogir.verify.integer-operations-target-structured+0x5b8>
    1a70:      	brk	#0
    1a74:      	b	0x1a70 <_stogir.verify.integer-operations-target-structured+0xc9c>
    1a78:      	ldr	x0, [sp, #0x388]
    1a7c:      	ldr	x1, [sp, #0x390]
    1a80:      	b	0x1398 <_stogir.verify.integer-operations-target-structured+0x5c4>
    1a84:      	add	x8, sp, #0x100
    1a88:      	str	x0, [sp, #0x398]
    1a8c:      	ldr	x0, [sp, #0x2a8]
    1a90:      	str	x1, [sp, #0x3a0]
    1a94:      	ldr	w1, [sp, #0x340]
    1a98:      	bl	0x1a98 <_stogir.verify.integer-operations-target-structured+0xcc4>
		0000000000001a98:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1a9c:      	add	x16, sp, #0x100
    1aa0:      	ldr	w0, [x16]
    1aa4:      	lsr	x16, x0, #0
    1aa8:      	cmp	x16, #0x1
    1aac:      	b.eq	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xcf4>
    1ab0:      	b.lo	0x1ab8 <_stogir.verify.integer-operations-target-structured+0xce4>
    1ab4:      	b	0x1acc <_stogir.verify.integer-operations-target-structured+0xcf8>
    1ab8:      	cmp	x16, #0x0
    1abc:      	b.eq	0x1ac4 <_stogir.verify.integer-operations-target-structured+0xcf0>
    1ac0:      	b	0x1acc <_stogir.verify.integer-operations-target-structured+0xcf8>
    1ac4:      	b	0x1af8 <_stogir.verify.integer-operations-target-structured+0xd24>
    1ac8:      	b	0x1ad0 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1acc:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13c8>
    1ad0:      	add	x16, sp, #0x100
    1ad4:      	ldr	x0, [x16, #0x8]
    1ad8:      	ldr	x1, [x25, #0x8]
    1adc:      	mov	x2, x1
    1ae0:      	mov	x1, x0
    1ae4:      	mov	x0, x19
    1ae8:      	mov	x19, x0
    1aec:      	mov	x0, x1
    1af0:      	mov	x1, x2
    1af4:      	b	0x13a8 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1af8:      	add	x0, x19, #0x1
    1afc:      	lsr	w0, w0, #0
    1b00:      	sxtw	x0, w0
    1b04:      	ldr	x1, [sp, #0x398]
    1b08:      	ldr	x2, [sp, #0x3a0]
    1b0c:      	b	0x1ae8 <_stogir.verify.integer-operations-target-structured+0xd14>
    1b10:      	add	x8, sp, #0x120
    1b14:      	str	x0, [sp, #0x3a8]
    1b18:      	ldr	x0, [sp, #0x2a8]
    1b1c:      	str	x1, [sp, #0x3b0]
    1b20:      	ldr	w1, [sp, #0x340]
    1b24:      	bl	0x1b24 <_stogir.verify.integer-operations-target-structured+0xd50>
		0000000000001b24:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    1b28:      	add	x16, sp, #0x120
    1b2c:      	ldr	w0, [x16]
    1b30:      	lsr	x16, x0, #0
    1b34:      	cmp	x16, #0x1
    1b38:      	b.eq	0x1b54 <_stogir.verify.integer-operations-target-structured+0xd80>
    1b3c:      	b.lo	0x1b44 <_stogir.verify.integer-operations-target-structured+0xd70>
    1b40:      	b	0x1b58 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b44:      	cmp	x16, #0x0
    1b48:      	b.eq	0x1b50 <_stogir.verify.integer-operations-target-structured+0xd7c>
    1b4c:      	b	0x1b58 <_stogir.verify.integer-operations-target-structured+0xd84>
    1b50:      	b	0x1b84 <_stogir.verify.integer-operations-target-structured+0xdb0>
    1b54:      	b	0x1b5c <_stogir.verify.integer-operations-target-structured+0xd88>
    1b58:      	b	0x1b9c <_stogir.verify.integer-operations-target-structured+0xdc8>
    1b5c:      	add	x16, sp, #0x120
    1b60:      	ldr	x0, [x16, #0x8]
    1b64:      	ldr	x1, [x24, #0x8]
    1b68:      	mov	x2, x1
    1b6c:      	mov	x1, x0
    1b70:      	mov	x0, x19
    1b74:      	mov	x19, x0
    1b78:      	mov	x0, x1
    1b7c:      	mov	x1, x2
    1b80:      	b	0x13d0 <_stogir.verify.integer-operations-target-structured+0x5fc>
    1b84:      	add	x0, x19, #0x1
    1b88:      	lsr	w0, w0, #0
    1b8c:      	sxtw	x0, w0
    1b90:      	ldr	x1, [sp, #0x3a8]
    1b94:      	ldr	x2, [sp, #0x3b0]
    1b98:      	b	0x1b74 <_stogir.verify.integer-operations-target-structured+0xda0>
    1b9c:      	brk	#0
    1ba0:      	b	0x1b9c <_stogir.verify.integer-operations-target-structured+0xdc8>
    1ba4:      	add	x8, sp, #0x140
    1ba8:      	str	x0, [sp, #0x3b8]
    1bac:      	ldr	x0, [sp, #0x2a8]
    1bb0:      	str	x1, [sp, #0x3c0]
    1bb4:      	ldr	w1, [sp, #0x340]
    1bb8:      	bl	0x1bb8 <_stogir.verify.integer-operations-target-structured+0xde4>
		0000000000001bb8:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1bbc:      	add	x16, sp, #0x140
    1bc0:      	ldr	w0, [x16]
    1bc4:      	lsr	x16, x0, #0
    1bc8:      	cmp	x16, #0x1
    1bcc:      	b.eq	0x1be8 <_stogir.verify.integer-operations-target-structured+0xe14>
    1bd0:      	b.lo	0x1bd8 <_stogir.verify.integer-operations-target-structured+0xe04>
    1bd4:      	b	0x1bec <_stogir.verify.integer-operations-target-structured+0xe18>
    1bd8:      	cmp	x16, #0x0
    1bdc:      	b.eq	0x1be4 <_stogir.verify.integer-operations-target-structured+0xe10>
    1be0:      	b	0x1bec <_stogir.verify.integer-operations-target-structured+0xe18>
    1be4:      	b	0x1c18 <_stogir.verify.integer-operations-target-structured+0xe44>
    1be8:      	b	0x1bf0 <_stogir.verify.integer-operations-target-structured+0xe1c>
    1bec:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13c0>
    1bf0:      	add	x16, sp, #0x140
    1bf4:      	ldr	x0, [x16, #0x8]
    1bf8:      	ldr	x1, [x23, #0x8]
    1bfc:      	mov	x2, x1
    1c00:      	mov	x1, x0
    1c04:      	mov	x0, x19
    1c08:      	mov	x19, x0
    1c0c:      	mov	x0, x1
    1c10:      	mov	x1, x2
    1c14:      	b	0x13f8 <_stogir.verify.integer-operations-target-structured+0x624>
    1c18:      	add	x0, x19, #0x1
    1c1c:      	lsr	w0, w0, #0
    1c20:      	sxtw	x0, w0
    1c24:      	ldr	x1, [sp, #0x3b8]
    1c28:      	ldr	x2, [sp, #0x3c0]
    1c2c:      	b	0x1c08 <_stogir.verify.integer-operations-target-structured+0xe34>
    1c30:      	add	x8, sp, #0x160
    1c34:      	ldr	w2, [sp, #0x2d8]
    1c38:      	str	x0, [sp, #0x3c8]
    1c3c:      	ldr	x0, [sp, #0x2a8]
    1c40:      	str	x1, [sp, #0x3d0]
    1c44:      	ldr	w1, [sp, #0x340]
    1c48:      	bl	0x1c48 <_stogir.verify.integer-operations-target-structured+0xe74>
		0000000000001c48:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    1c4c:      	add	x16, sp, #0x160
    1c50:      	ldr	w0, [x16]
    1c54:      	lsr	x16, x0, #0
    1c58:      	cmp	x16, #0x1
    1c5c:      	b.eq	0x1c7c <_stogir.verify.integer-operations-target-structured+0xea8>
    1c60:      	b.lo	0x1c68 <_stogir.verify.integer-operations-target-structured+0xe94>
    1c64:      	b	0x1c80 <_stogir.verify.integer-operations-target-structured+0xeac>
    1c68:      	cmp	x16, #0x0
    1c6c:      	b.eq	0x1c74 <_stogir.verify.integer-operations-target-structured+0xea0>
    1c70:      	b	0x1c80 <_stogir.verify.integer-operations-target-structured+0xeac>
    1c74:      	ldr	x1, [sp, #0x350]
    1c78:      	b	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xedc>
    1c7c:      	b	0x1c84 <_stogir.verify.integer-operations-target-structured+0xeb0>
    1c80:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xef4>
    1c84:      	add	x16, sp, #0x160
    1c88:      	ldr	x0, [x16, #0x8]
    1c8c:      	ldr	x1, [sp, #0x350]
    1c90:      	ldr	x2, [x1, #0x8]
    1c94:      	mov	x3, x2
    1c98:      	mov	x2, x0
    1c9c:      	mov	x0, x19
    1ca0:      	mov	x19, x0
    1ca4:      	mov	x0, x2
    1ca8:      	mov	x2, x3
    1cac:      	b	0x142c <_stogir.verify.integer-operations-target-structured+0x658>
    1cb0:      	add	x0, x19, #0x1
    1cb4:      	lsr	w0, w0, #0
    1cb8:      	sxtw	x0, w0
    1cbc:      	ldr	x2, [sp, #0x3c8]
    1cc0:      	ldr	x3, [sp, #0x3d0]
    1cc4:      	b	0x1ca0 <_stogir.verify.integer-operations-target-structured+0xecc>
    1cc8:      	brk	#0
    1ccc:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xef4>
    1cd0:      	add	x0, x19, #0x1
    1cd4:      	lsr	w0, w0, #0
    1cd8:      	sxtw	x0, w0
    1cdc:      	ldr	x2, [sp, #0x3d8]
    1ce0:      	ldr	x3, [sp, #0x3e0]
    1ce4:      	b	0x14b0 <_stogir.verify.integer-operations-target-structured+0x6dc>
    1ce8:      	brk	#0
    1cec:      	b	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xf14>
    1cf0:      	ldr	x0, [sp, #0x3d8]
    1cf4:      	ldr	x2, [sp, #0x3e0]
    1cf8:      	b	0x14bc <_stogir.verify.integer-operations-target-structured+0x6e8>
    1cfc:      	add	x0, x19, #0x1
    1d00:      	lsr	w0, w0, #0
    1d04:      	sxtw	x0, w0
    1d08:      	ldr	x2, [sp, #0x3e8]
    1d0c:      	ldr	x3, [sp, #0x3f0]
    1d10:      	b	0x1534 <_stogir.verify.integer-operations-target-structured+0x760>
    1d14:      	brk	#0
    1d18:      	b	0x1d14 <_stogir.verify.integer-operations-target-structured+0xf40>
    1d1c:      	ldr	x0, [sp, #0x3e8]
    1d20:      	ldr	x2, [sp, #0x3f0]
    1d24:      	b	0x1540 <_stogir.verify.integer-operations-target-structured+0x76c>
    1d28:      	add	x16, sp, #0x20
    1d2c:      	ldr	w3, [x16, #0x8]
    1d30:      	lsr	w3, w3, #0
    1d34:      	add	x8, sp, #0x1c0
    1d38:      	str	x1, [sp, #0x238]
    1d3c:      	mov	w1, w3
    1d40:      	str	x0, [sp, #0x3f8]
    1d44:      	ldr	x0, [sp, #0x2a8]
    1d48:      	str	x2, [sp, #0x400]
    1d4c:      	bl	0x1d4c <_stogir.verify.integer-operations-target-structured+0xf78>
		0000000000001d4c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1d50:      	add	x16, sp, #0x1c0
    1d54:      	ldr	w0, [x16]
    1d58:      	lsr	x16, x0, #0
    1d5c:      	cmp	x16, #0x1
    1d60:      	b.eq	0x1d7c <_stogir.verify.integer-operations-target-structured+0xfa8>
    1d64:      	b.lo	0x1d6c <_stogir.verify.integer-operations-target-structured+0xf98>
    1d68:      	b	0x1d80 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d6c:      	cmp	x16, #0x0
    1d70:      	b.eq	0x1d78 <_stogir.verify.integer-operations-target-structured+0xfa4>
    1d74:      	b	0x1d80 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d78:      	b	0x1d84 <_stogir.verify.integer-operations-target-structured+0xfb0>
    1d7c:      	b	0x1d90 <_stogir.verify.integer-operations-target-structured+0xfbc>
    1d80:      	b	0x1dcc <_stogir.verify.integer-operations-target-structured+0xff8>
    1d84:      	ldr	x0, [sp, #0x270]
    1d88:      	mov	x1, #0x14               ; =20
    1d8c:      	b	0x1580 <_stogir.verify.integer-operations-target-structured+0x7ac>
    1d90:      	add	x16, sp, #0x1c0
    1d94:      	ldr	x0, [x16, #0x8]
    1d98:      	add	x16, sp, #0x20
    1d9c:      	ldr	w1, [x16]
    1da0:      	lsr	w0, w0, #0
    1da4:      	ubfx	x1, x1, #8, #8
    1da8:      	ubfx	x0, x0, #8, #8
    1dac:      	cmp	x0, x1
    1db0:      	b.ne	0x1dc0 <_stogir.verify.integer-operations-target-structured+0xfec>
    1db4:      	ldr	x0, [sp, #0x3f8]
    1db8:      	ldr	x1, [sp, #0x400]
    1dbc:      	b	0x1d8c <_stogir.verify.integer-operations-target-structured+0xfb8>
    1dc0:      	ldr	x0, [sp, #0x278]
    1dc4:      	mov	x1, #0x1a               ; =26
    1dc8:      	b	0x1dbc <_stogir.verify.integer-operations-target-structured+0xfe8>
    1dcc:      	brk	#0
    1dd0:      	b	0x1dcc <_stogir.verify.integer-operations-target-structured+0xff8>
    1dd4:      	ldr	x0, [sp, #0x3f8]
    1dd8:      	ldr	x1, [sp, #0x400]
    1ddc:      	b	0x1590 <_stogir.verify.integer-operations-target-structured+0x7bc>
    1de0:      	add	x0, x19, #0x1
    1de4:      	lsr	w0, w0, #0
    1de8:      	sxtw	x0, w0
    1dec:      	ldr	x2, [sp, #0x408]
    1df0:      	ldr	x3, [sp, #0x410]
    1df4:      	b	0x162c <_stogir.verify.integer-operations-target-structured+0x858>
    1df8:      	brk	#0
    1dfc:      	b	0x1df8 <_stogir.verify.integer-operations-target-structured+0x1024>
    1e00:      	ldr	x0, [sp, #0x408]
    1e04:      	ldr	x2, [sp, #0x410]
    1e08:      	b	0x1638 <_stogir.verify.integer-operations-target-structured+0x864>
    1e0c:      	mov	x3, x2
    1e10:      	mov	x2, x0
    1e14:      	mov	x0, #0x1                ; =1
    1e18:      	b	0x1650 <_stogir.verify.integer-operations-target-structured+0x87c>
    1e1c:      	mov	x0, #0x1                ; =1
    1e20:      	b	0x1664 <_stogir.verify.integer-operations-target-structured+0x890>
    1e24:      	ldr	x21, [sp, #0x2b0]
    1e28:      	cmp	x21, #0x0
    1e2c:      	b.eq	0x1e38 <_stogir.verify.integer-operations-target-structured+0x1064>
    1e30:      	mov	x0, #0x1                ; =1
    1e34:      	b	0x1680 <_stogir.verify.integer-operations-target-structured+0x8ac>
    1e38:      	ldr	x0, [sp, #0x2b8]
    1e3c:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0x1060>
    1e40:      	movz	x0, #0x0, lsl #48
    1e44:      	b	0x1680 <_stogir.verify.integer-operations-target-structured+0x8ac>
    1e48:      	movz	x0, #0x0, lsl #48
    1e4c:      	b	0x1680 <_stogir.verify.integer-operations-target-structured+0x8ac>
    1e50:      	lsr	w1, w1, #0
    1e54:      	lsr	w1, w1, #0
    1e58:      	ldr	x0, [sp, #0x2a8]
    1e5c:      	bl	0x1e5c <_stogir.verify.integer-operations-target-structured+0x1088>
		0000000000001e5c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1e60:      	cmp	x0, #0x0
    1e64:      	b.ne	0x1e84 <_stogir.verify.integer-operations-target-structured+0x10b0>
    1e68:      	str	x26, [sp, #0x440]
    1e6c:      	str	x25, [sp, #0x438]
    1e70:      	str	x24, [sp, #0x430]
    1e74:      	str	x23, [sp, #0x428]
    1e78:      	ldr	x0, [sp, #0x280]
    1e7c:      	mov	x1, #0x17               ; =23
    1e80:      	b	0x1710 <_stogir.verify.integer-operations-target-structured+0x93c>
    1e84:      	ldr	w0, [x0]
    1e88:      	add	x16, sp, #0x20
    1e8c:      	ldr	w1, [x16]
    1e90:      	ubfx	x0, x0, #8, #8
    1e94:      	orr	x2, x0, xzr
    1e98:      	ubfx	x1, x1, #8, #8
    1e9c:      	cmp	x1, #0x6
    1ea0:      	b.ne	0x2008 <_stogir.verify.integer-operations-target-structured+0x1234>
    1ea4:      	cmp	x2, #0x6
    1ea8:      	b.ne	0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
    1eac:      	cmp	x22, #0x1a
    1eb0:      	b.ne	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x121c>
    1eb4:      	mov	x1, #0x1                ; =1
    1eb8:      	cmp	x2, #0x1
    1ebc:      	cset	w3, ge
    1ec0:      	uxtb	w16, w3
    1ec4:      	cmp	w16, wzr
    1ec8:      	b.eq	0x2334 <_stogir.verify.integer-operations-target-structured+0x1560>
    1ecc:      	cmp	x2, #0xb
    1ed0:      	cset	w4, le
    1ed4:      	uxtb	w16, w4
    1ed8:      	cmp	w16, wzr
    1edc:      	b.eq	0x2350 <_stogir.verify.integer-operations-target-structured+0x157c>
    1ee0:      	ldr	x5, [sp, #0x2b8]
    1ee4:      	cmp	x5, #0x0
    1ee8:      	b.eq	0x236c <_stogir.verify.integer-operations-target-structured+0x1598>
    1eec:      	ldr	w5, [sp, #0x318]
    1ef0:      	lsr	w5, w5, #0
    1ef4:      	lsr	w0, w0, #0
    1ef8:      	str	x23, [sp, #0x428]
    1efc:      	mov	x23, x2
    1f00:      	str	x24, [sp, #0x430]
    1f04:      	mov	x24, x1
    1f08:      	mov	w1, w0
    1f0c:      	mov	w0, w5
    1f10:      	str	x25, [sp, #0x438]
    1f14:      	mov	w25, w3
    1f18:      	str	x26, [sp, #0x440]
    1f1c:      	mov	w26, w4
    1f20:      	bl	0x1f20 <_stogir.verify.integer-operations-target-structured+0x114c>
		0000000000001f20:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    1f24:      	cmp	x0, #0x0
    1f28:      	b.ne	0x2010 <_stogir.verify.integer-operations-target-structured+0x123c>
    1f2c:      	ldr	x0, [sp, #0x288]
    1f30:      	mov	x1, #0x1c               ; =28
    1f34:      	add	x16, sp, #0x20
    1f38:      	ldr	w2, [x16]
    1f3c:      	cmp	x20, #0x0
    1f40:      	b.eq	0x20e0 <_stogir.verify.integer-operations-target-structured+0x130c>
    1f44:      	mov	x3, x0
    1f48:      	mov	x0, #0x1                ; =1
    1f4c:      	lsr	w0, w0, #0
    1f50:      	ubfx	x2, x2, #8, #8
    1f54:      	sxtw	x0, w0
    1f58:      	cmp	x2, x0
    1f5c:      	b.ne	0x20ec <_stogir.verify.integer-operations-target-structured+0x1318>
    1f60:      	mov	x0, x3
    1f64:      	mov	x22, x1
    1f68:      	cmp	x20, #0x0
    1f6c:      	b.eq	0x20f8 <_stogir.verify.integer-operations-target-structured+0x1324>
    1f70:      	mov	x20, x0
    1f74:      	mov	x0, #0x1                ; =1
    1f78:      	cmp	x0, #0x0
    1f7c:      	b.eq	0x2170 <_stogir.verify.integer-operations-target-structured+0x139c>
    1f80:      	add	x16, sp, #0x220
    1f84:      	str	x16, [sp]
    1f88:      	ldr	x0, [sp, #0x2a8]
    1f8c:      	ldr	w1, [sp, #0x340]
    1f90:      	mov	x2, #0x2                ; =2
    1f94:      	bl	0x1f94 <_stogir.verify.integer-operations-target-structured+0x11c0>
		0000000000001f94:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    1f98:      	ldr	x16, [sp]
    1f9c:      	str	x0, [x16]
    1fa0:      	str	x1, [x16, #0x8]
    1fa4:      	add	x16, sp, #0x220
    1fa8:      	ldr	x0, [x16]
    1fac:      	add	x16, sp, #0x220
    1fb0:      	ldr	x1, [x16, #0x8]
    1fb4:      	lsr	w0, w0, #0
    1fb8:      	lsr	x16, x0, #0
    1fbc:      	cmp	x16, #0x1
    1fc0:      	b.eq	0x1fdc <_stogir.verify.integer-operations-target-structured+0x1208>
    1fc4:      	b.lo	0x1fcc <_stogir.verify.integer-operations-target-structured+0x11f8>
    1fc8:      	b	0x1fe0 <_stogir.verify.integer-operations-target-structured+0x120c>
    1fcc:      	cmp	x16, #0x0
    1fd0:      	b.eq	0x1fd8 <_stogir.verify.integer-operations-target-structured+0x1204>
    1fd4:      	b	0x1fe0 <_stogir.verify.integer-operations-target-structured+0x120c>
    1fd8:      	b	0x1fe4 <_stogir.verify.integer-operations-target-structured+0x1210>
    1fdc:      	b	0x2104 <_stogir.verify.integer-operations-target-structured+0x1330>
    1fe0:      	b	0x2168 <_stogir.verify.integer-operations-target-structured+0x1394>
    1fe4:      	ldr	x0, [sp, #0x298]
    1fe8:      	mov	x1, #0x1d               ; =29
    1fec:      	b	0x1e80 <_stogir.verify.integer-operations-target-structured+0x10ac>
    1ff0:      	cmp	x22, #0x1b
    1ff4:      	cset	w1, eq
    1ff8:      	ubfx	x1, x1, #0, #8
    1ffc:      	b	0x1eb8 <_stogir.verify.integer-operations-target-structured+0x10e4>
    2000:      	movz	x1, #0x0, lsl #48
    2004:      	b	0x1eb8 <_stogir.verify.integer-operations-target-structured+0x10e4>
    2008:      	movz	x1, #0x0, lsl #48
    200c:      	b	0x1eb8 <_stogir.verify.integer-operations-target-structured+0x10e4>
    2010:      	cmp	x21, #0x0
    2014:      	b.eq	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    2018:      	ldr	w0, [sp, #0x310]
    201c:      	uxtb	w16, w0
    2020:      	cmp	w16, wzr
    2024:      	b.eq	0x2094 <_stogir.verify.integer-operations-target-structured+0x12c0>
    2028:      	ldr	w0, [sp, #0x308]
    202c:      	uxtb	w16, w0
    2030:      	cmp	w16, wzr
    2034:      	b.eq	0x2094 <_stogir.verify.integer-operations-target-structured+0x12c0>
    2038:      	ldr	w0, [sp, #0x2f0]
    203c:      	uxtb	w16, w25
    2040:      	cmp	w16, wzr
    2044:      	b.eq	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    2048:      	uxtb	w16, w26
    204c:      	cmp	w16, wzr
    2050:      	b.eq	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    2054:      	cmp	x23, #0x1
    2058:      	b.ne	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    205c:      	cmp	x22, #0x2e
    2060:      	b.eq	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    2064:      	cmp	x22, #0x2f
    2068:      	b.eq	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    206c:      	cmp	x22, #0x30
    2070:      	b.eq	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    2074:      	uxtb	w16, w0
    2078:      	cmp	w16, wzr
    207c:      	b.ne	0x2088 <_stogir.verify.integer-operations-target-structured+0x12b4>
    2080:      	cmp	x22, #0x3b
    2084:      	b.ne	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    2088:      	ldr	x0, [sp, #0x418]
    208c:      	ldr	x1, [sp, #0x420]
    2090:      	b	0x1f34 <_stogir.verify.integer-operations-target-structured+0x1160>
    2094:      	ldr	w0, [sp, #0x300]
    2098:      	uxtb	w16, w0
    209c:      	cmp	w16, wzr
    20a0:      	b.eq	0x20bc <_stogir.verify.integer-operations-target-structured+0x12e8>
    20a4:      	ldr	w0, [sp, #0x2f8]
    20a8:      	uxtb	w16, w0
    20ac:      	cmp	w16, wzr
    20b0:      	b.eq	0x20bc <_stogir.verify.integer-operations-target-structured+0x12e8>
    20b4:      	ldr	w0, [sp, #0x2f0]
    20b8:      	b	0x203c <_stogir.verify.integer-operations-target-structured+0x1268>
    20bc:      	ldr	w0, [sp, #0x2f0]
    20c0:      	uxtb	w16, w0
    20c4:      	cmp	w16, wzr
    20c8:      	b.ne	0x203c <_stogir.verify.integer-operations-target-structured+0x1268>
    20cc:      	ldr	w1, [sp, #0x2e8]
    20d0:      	uxtb	w16, w1
    20d4:      	cmp	w16, wzr
    20d8:      	b.ne	0x203c <_stogir.verify.integer-operations-target-structured+0x1268>
    20dc:      	b	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    20e0:      	mov	x3, x0
    20e4:      	mov	x0, x23
    20e8:      	b	0x1f4c <_stogir.verify.integer-operations-target-structured+0x1178>
    20ec:      	ldr	x0, [sp, #0x290]
    20f0:      	mov	x22, #0x26              ; =38
    20f4:      	b	0x1f68 <_stogir.verify.integer-operations-target-structured+0x1194>
    20f8:      	mov	x20, x0
    20fc:      	mov	x0, x21
    2100:      	b	0x1f78 <_stogir.verify.integer-operations-target-structured+0x11a4>
    2104:      	lsr	w1, w1, #0
    2108:      	lsr	w1, w1, #0
    210c:      	ldr	x0, [sp, #0x2a8]
    2110:      	bl	0x2110 <_stogir.verify.integer-operations-target-structured+0x133c>
		0000000000002110:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2114:      	cmp	x0, #0x0
    2118:      	b.ne	0x2128 <_stogir.verify.integer-operations-target-structured+0x1354>
    211c:      	ldr	x0, [sp, #0x298]
    2120:      	mov	x1, #0x1d               ; =29
    2124:      	b	0x1fec <_stogir.verify.integer-operations-target-structured+0x1218>
    2128:      	ldr	w0, [x0]
    212c:      	ubfx	x0, x0, #8, #8
    2130:      	cmp	x23, x0
    2134:      	b.eq	0x2150 <_stogir.verify.integer-operations-target-structured+0x137c>
    2138:      	cmp	x24, #0x0
    213c:      	b.eq	0x215c <_stogir.verify.integer-operations-target-structured+0x1388>
    2140:      	cmp	x0, #0x5
    2144:      	b.eq	0x2150 <_stogir.verify.integer-operations-target-structured+0x137c>
    2148:      	cmp	x0, #0xb
    214c:      	b.ne	0x215c <_stogir.verify.integer-operations-target-structured+0x1388>
    2150:      	mov	x0, x20
    2154:      	mov	x1, x22
    2158:      	b	0x2124 <_stogir.verify.integer-operations-target-structured+0x1350>
    215c:      	ldr	x0, [sp, #0x2a0]
    2160:      	mov	x1, #0x1d               ; =29
    2164:      	b	0x2158 <_stogir.verify.integer-operations-target-structured+0x1384>
    2168:      	brk	#0
    216c:      	b	0x2168 <_stogir.verify.integer-operations-target-structured+0x1394>
    2170:      	mov	x0, x20
    2174:      	mov	x1, x22
    2178:      	b	0x1fec <_stogir.verify.integer-operations-target-structured+0x1218>
    217c:      	brk	#0
    2180:      	b	0x217c <_stogir.verify.integer-operations-target-structured+0x13a8>
    2184:      	mov	x0, x19
    2188:      	ldr	x1, [sp, #0x418]
    218c:      	ldr	x2, [sp, #0x420]
    2190:      	b	0x172c <_stogir.verify.integer-operations-target-structured+0x958>
    2194:      	brk	#0
    2198:      	b	0x2194 <_stogir.verify.integer-operations-target-structured+0x13c0>
    219c:      	brk	#0
    21a0:      	b	0x219c <_stogir.verify.integer-operations-target-structured+0x13c8>
    21a4:      	brk	#0
    21a8:      	b	0x21a4 <_stogir.verify.integer-operations-target-structured+0x13d0>
    21ac:      	brk	#0
    21b0:      	b	0x21ac <_stogir.verify.integer-operations-target-structured+0x13d8>
    21b4:      	ldr	x0, [sp, #0x2c8]
    21b8:      	cmp	x0, #0x0
    21bc:      	b.ne	0x2218 <_stogir.verify.integer-operations-target-structured+0x1444>
    21c0:      	and	x0, x19, #0xffffffff
    21c4:      	mov	x1, x0
    21c8:      	movz	x0, #0x0, lsl #48
    21cc:      	movz	x2, #0x0, lsl #48
    21d0:      	ldr	x3, [sp, #0x2c0]
    21d4:      	str	x0, [x3]
    21d8:      	str	x1, [x3, #0x8]
    21dc:      	str	x2, [x3, #0x10]
    21e0:      	ldr	x19, [sp, #0x448]
    21e4:      	ldr	x20, [sp, #0x450]
    21e8:      	ldr	x21, [sp, #0x458]
    21ec:      	ldr	x22, [sp, #0x460]
    21f0:      	ldr	x23, [sp, #0x468]
    21f4:      	ldr	x24, [sp, #0x470]
    21f8:      	ldr	x25, [sp, #0x478]
    21fc:      	ldr	x26, [sp, #0x480]
    2200:      	ldr	x27, [sp, #0x488]
    2204:      	ldr	x28, [sp, #0x490]
    2208:      	ldr	x29, [sp, #0x10]
    220c:      	ldr	x30, [sp, #0x18]
    2210:      	add	sp, sp, #0x4a0
    2214:      	ret
    2218:      	ldr	x1, [sp, #0x248]
    221c:      	mov	x2, x0
    2220:      	mov	x0, #0x1                ; =1
    2224:      	b	0x21d0 <_stogir.verify.integer-operations-target-structured+0x13fc>
    2228:      	str	x8, [sp, #0x2c0]
    222c:      	str	x20, [sp, #0x2c8]
    2230:      	b	0x21b4 <_stogir.verify.integer-operations-target-structured+0x13e0>
    2234:      	str	x8, [sp, #0x2c0]
    2238:      	str	x20, [sp, #0x2c8]
    223c:      	b	0x21b4 <_stogir.verify.integer-operations-target-structured+0x13e0>
    2240:      	str	x1, [sp, #0x358]
    2244:      	str	x2, [sp, #0x360]
    2248:      	b	0x1900 <_stogir.verify.integer-operations-target-structured+0xb2c>
    224c:      	str	x1, [sp, #0x368]
    2250:      	str	x2, [sp, #0x370]
    2254:      	b	0x19f8 <_stogir.verify.integer-operations-target-structured+0xc24>
    2258:      	str	x0, [sp, #0x378]
    225c:      	str	x1, [sp, #0x380]
    2260:      	b	0x1a14 <_stogir.verify.integer-operations-target-structured+0xc40>
    2264:      	str	x0, [sp, #0x388]
    2268:      	str	x1, [sp, #0x390]
    226c:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xca4>
    2270:      	str	x0, [sp, #0x388]
    2274:      	str	x1, [sp, #0x390]
    2278:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xca4>
    227c:      	str	x0, [sp, #0x3a8]
    2280:      	str	x1, [sp, #0x3b0]
    2284:      	b	0x13c8 <_stogir.verify.integer-operations-target-structured+0x5f4>
    2288:      	str	x0, [sp, #0x3c8]
    228c:      	str	x1, [sp, #0x3d0]
    2290:      	ldr	x1, [sp, #0x350]
    2294:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x650>
    2298:      	str	x1, [sp, #0x350]
    229c:      	ldr	x1, [sp, #0x320]
    22a0:      	str	x0, [sp, #0x3d8]
    22a4:      	str	x2, [sp, #0x3e0]
    22a8:      	b	0x1cf0 <_stogir.verify.integer-operations-target-structured+0xf1c>
    22ac:      	str	x1, [sp, #0x350]
    22b0:      	ldr	x1, [sp, #0x320]
    22b4:      	str	x0, [sp, #0x3d8]
    22b8:      	str	x2, [sp, #0x3e0]
    22bc:      	b	0x1cf0 <_stogir.verify.integer-operations-target-structured+0xf1c>
    22c0:      	str	x1, [sp, #0x320]
    22c4:      	ldr	x1, [sp, #0x238]
    22c8:      	str	x0, [sp, #0x3e8]
    22cc:      	str	x2, [sp, #0x3f0]
    22d0:      	b	0x1d1c <_stogir.verify.integer-operations-target-structured+0xf48>
    22d4:      	str	x1, [sp, #0x238]
    22d8:      	str	x0, [sp, #0x3f8]
    22dc:      	str	x2, [sp, #0x400]
    22e0:      	b	0x1dd4 <_stogir.verify.integer-operations-target-structured+0x1000>
    22e4:      	str	x0, [sp, #0x408]
    22e8:      	str	x1, [sp, #0x410]
    22ec:      	ldr	x1, [sp, #0x258]
    22f0:      	str	x20, [sp, #0x260]
    22f4:      	mov	x20, x2
    22f8:      	b	0x1e00 <_stogir.verify.integer-operations-target-structured+0x102c>
    22fc:      	ldr	x20, [sp, #0x338]
    2300:      	ldr	x21, [sp, #0x2b0]
    2304:      	b	0x1e48 <_stogir.verify.integer-operations-target-structured+0x1074>
    2308:      	ldr	x20, [sp, #0x338]
    230c:      	ldr	x21, [sp, #0x2b0]
    2310:      	b	0x1e40 <_stogir.verify.integer-operations-target-structured+0x106c>
    2314:      	str	x26, [sp, #0x440]
    2318:      	str	x25, [sp, #0x438]
    231c:      	str	x24, [sp, #0x430]
    2320:      	str	x23, [sp, #0x428]
    2324:      	str	x1, [sp, #0x258]
    2328:      	str	x2, [sp, #0x418]
    232c:      	str	x3, [sp, #0x420]
    2330:      	b	0x2184 <_stogir.verify.integer-operations-target-structured+0x13b0>
    2334:      	str	x26, [sp, #0x440]
    2338:      	str	x25, [sp, #0x438]
    233c:      	str	x24, [sp, #0x430]
    2340:      	mov	x24, x1
    2344:      	str	x23, [sp, #0x428]
    2348:      	mov	x23, x2
    234c:      	b	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    2350:      	str	x26, [sp, #0x440]
    2354:      	str	x25, [sp, #0x438]
    2358:      	str	x24, [sp, #0x430]
    235c:      	mov	x24, x1
    2360:      	str	x23, [sp, #0x428]
    2364:      	mov	x23, x2
    2368:      	b	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1158>
    236c:      	str	x26, [sp, #0x440]
    2370:      	str	x25, [sp, #0x438]
    2374:      	str	x24, [sp, #0x430]
    2378:      	mov	x24, x1
    237c:      	str	x23, [sp, #0x428]
    2380:      	mov	x23, x2
    2384:      	mov	w25, w3
    2388:      	mov	w26, w4
    238c:      	b	0x2010 <_stogir.verify.integer-operations-target-structured+0x123c>

0000000000002390 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2390:      	ldr	x0, [x0, #0x8]
    2394:      	ret

0000000000002398 <_coil.core.Eq$slice<u8>$=>:
    2398:      	sub	sp, sp, #0x10
    239c:      	str	x29, [sp]
    23a0:      	str	x30, [sp, #0x8]
    23a4:      	mov	x29, sp
    23a8:      	cmp	x1, x3
    23ac:      	b.ne	0x23ec <_coil.core.Eq$slice<u8>$=+0x54>
    23b0:      	cmp	x1, #0x0
    23b4:      	b.ne	0x23c0 <_coil.core.Eq$slice<u8>$=+0x28>
    23b8:      	mov	x0, #0x1                ; =1
    23bc:      	b	0x23e8 <_coil.core.Eq$slice<u8>$=+0x50>
    23c0:      	lsr	x1, x1, #0
    23c4:      	fmov	d31, x1
    23c8:      	mov	x1, x2
    23cc:      	fmov	x2, d31
    23d0:      	bl	0x23d0 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000023d0:  ARM64_RELOC_BRANCH26	_memcmp
    23d4:      	lsr	w0, w0, #0
    23d8:      	sxtw	x0, w0
    23dc:      	cmp	x0, #0x0
    23e0:      	cset	w0, eq
    23e4:      	ubfx	x0, x0, #0, #8
    23e8:      	b	0x23f0 <_coil.core.Eq$slice<u8>$=+0x58>
    23ec:      	movz	x0, #0x0, lsl #48
    23f0:      	ldr	x29, [sp]
    23f4:      	ldr	x30, [sp, #0x8]
    23f8:      	add	sp, sp, #0x10
    23fc:      	ret

0000000000002400 <_stogir.node.opcode>:
    2400:      	ldr	w0, [x0]
    2404:      	uxtb	w0, w0
    2408:      	ret

000000000000240c <_stogir.opcode.valid?>:
    240c:      	sxtw	x0, w0
    2410:      	cmp	x0, #0x0
    2414:      	b.lt	0x2428 <_stogir.opcode.valid?+0x1c>
    2418:      	cmp	x0, #0x83
    241c:      	cset	w0, lt
    2420:      	ubfx	x0, x0, #0, #8
    2424:      	b	0x242c <_stogir.opcode.valid?+0x20>
    2428:      	movz	x0, #0x0, lsl #48
    242c:      	ret

0000000000002430 <_stogir.node.type-id>:
    2430:      	ldr	w0, [x0]
    2434:      	ubfx	x0, x0, #8, #8
    2438:      	ret

000000000000243c <_stogir.types.valid?>:
    243c:      	sxtw	x0, w0
    2440:      	cmp	x0, #0x0
    2444:      	b.lt	0x2458 <_stogir.types.valid?+0x1c>
    2448:      	cmp	x0, #0xd
    244c:      	b.gt	0x2458 <_stogir.types.valid?+0x1c>
    2450:      	mov	x0, #0x1                ; =1
    2454:      	b	0x2498 <_stogir.types.valid?+0x5c>
    2458:      	cmp	x0, #0xf
    245c:      	b.le	0x2494 <_stogir.types.valid?+0x58>
    2460:      	cmp	x0, #0x80
    2464:      	b.ge	0x248c <_stogir.types.valid?+0x50>
    2468:      	and	x0, x0, #0xf
    246c:      	lsr	w0, w0, #0
    2470:      	sxtw	x0, w0
    2474:      	cmp	x0, #0x1
    2478:      	b.lt	0x249c <_stogir.types.valid?+0x60>
    247c:      	cmp	x0, #0xd
    2480:      	cset	w0, le
    2484:      	ubfx	x0, x0, #0, #8
    2488:      	b	0x24a0 <_stogir.types.valid?+0x64>
    248c:      	movz	x0, #0x0, lsl #48
    2490:      	b	0x2498 <_stogir.types.valid?+0x5c>
    2494:      	movz	x0, #0x0, lsl #48
    2498:      	ret
    249c:      	movz	x0, #0x0, lsl #48
    24a0:      	b	0x2490 <_stogir.types.valid?+0x54>

00000000000024a4 <_stogir.opcode.operand-slots>:
    24a4:      	sxtw	x0, w0
    24a8:      	cmp	x0, #0x0
    24ac:      	b.lt	0x24d4 <_stogir.opcode.operand-slots+0x30>
    24b0:      	cmp	x0, #0x83
    24b4:      	b.ge	0x24d4 <_stogir.opcode.operand-slots+0x30>
    24b8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		00000000000024b8:  ARM64_RELOC_PAGE21	l_stogir.336
    24bc:      	ldr	x16, [x16]
		00000000000024bc:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    24c0:      	orr	x1, x16, xzr
    24c4:      	add	x0, x1, x0
    24c8:      	ldrsb	w0, [x0]
    24cc:      	sxtb	x0, w0
    24d0:      	b	0x24d8 <_stogir.opcode.operand-slots+0x34>
    24d4:      	mov	x0, #-0x2               ; =-2
    24d8:      	ret

00000000000024dc <_stogir.opcode.input-count>:
    24dc:      	sxtw	x0, w0
    24e0:      	cmp	x0, #0x0
    24e4:      	b.lt	0x250c <_stogir.opcode.input-count+0x30>
    24e8:      	cmp	x0, #0x83
    24ec:      	b.ge	0x250c <_stogir.opcode.input-count+0x30>
    24f0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		00000000000024f0:  ARM64_RELOC_PAGE21	l_stogir.337
    24f4:      	ldr	x16, [x16]
		00000000000024f4:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    24f8:      	orr	x1, x16, xzr
    24fc:      	add	x0, x1, x0
    2500:      	ldrsb	w0, [x0]
    2504:      	sxtb	x0, w0
    2508:      	b	0x2510 <_stogir.opcode.input-count+0x34>
    250c:      	mov	x0, #-0x2               ; =-2
    2510:      	ret

0000000000002514 <_stogir.node.auxiliary>:
    2514:      	ldr	w0, [x0]
    2518:      	ubfx	x0, x0, #16, #16
    251c:      	ret

0000000000002520 <_stogir.opcode.operand-code>:
    2520:      	sxtw	x0, w0
    2524:      	cmp	x0, #0x0
    2528:      	b.lt	0x2564 <_stogir.opcode.operand-code+0x44>
    252c:      	cmp	x0, #0x83
    2530:      	b.ge	0x2564 <_stogir.opcode.operand-code+0x44>
    2534:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		0000000000002534:  ARM64_RELOC_PAGE21	l_stogir.338
    2538:      	ldr	x16, [x16]
		0000000000002538:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    253c:      	orr	x2, x16, xzr
    2540:      	sxtw	x1, w1
    2544:      	add	x0, x2, x0, lsl #2
    2548:      	ldr	w0, [x0]
    254c:      	cmp	x1, #0x0
    2550:      	b.le	0x256c <_stogir.opcode.operand-code+0x4c>
    2554:      	cmp	x1, #0x4
    2558:      	b.le	0x2574 <_stogir.opcode.operand-code+0x54>
    255c:      	mov	x1, #0x4                ; =4
    2560:      	b	0x2580 <_stogir.opcode.operand-code+0x60>
    2564:      	movz	x0, #0x0, lsl #48
    2568:      	ret
    256c:      	movz	x0, #0x0, lsl #48
    2570:      	b	0x2568 <_stogir.opcode.operand-code+0x48>
    2574:      	sub	x1, x1, #0x1
    2578:      	lsr	w1, w1, #0
    257c:      	sxtw	x1, w1
    2580:      	lsl	x1, x1, #2
    2584:      	lsr	w1, w1, #0
    2588:      	ubfx	x1, x1, #0, #32
    258c:      	lsr	x0, x0, x1
    2590:      	lsr	w0, w0, #0
    2594:      	and	x0, x0, #0xf
    2598:      	lsr	w0, w0, #0
    259c:      	b	0x2570 <_stogir.opcode.operand-code+0x50>

00000000000025a0 <_stogir.graph.operand>:
    25a0:      	sub	sp, sp, #0x10
    25a4:      	mov	x3, sp
    25a8:      	sxtw	x1, w1
    25ac:      	cmp	x1, #0x0
    25b0:      	b.le	0x25f4 <_stogir.graph.operand+0x54>
    25b4:      	lsl	x4, x1, #2
    25b8:      	ldr	x5, [x0, #0x8]
    25bc:      	cmp	x1, x5
    25c0:      	b.ge	0x2628 <_stogir.graph.operand+0x88>
    25c4:      	add	x5, x0, #0x78
    25c8:      	ldr	x5, [x5, #0x8]
    25cc:      	cmp	x1, x5
    25d0:      	b.ge	0x2620 <_stogir.graph.operand+0x80>
    25d4:      	ldr	x5, [x0, #0x78]
    25d8:      	add	x5, x4, x5
    25dc:      	ldr	w5, [x5]
    25e0:      	sxtw	x5, w5
    25e4:      	cmp	x5, #0x0
    25e8:      	cset	w5, ge
    25ec:      	ubfx	x5, x5, #0, #8
    25f0:      	b	0x2624 <_stogir.graph.operand+0x84>
    25f4:      	movz	x0, #0x0, lsl #48
    25f8:      	movz	x1, #0x0, lsl #48
    25fc:      	str	x0, [x3]
    2600:      	str	x1, [x3, #0x8]
    2604:      	ldr	x0, [sp]
    2608:      	ldr	x1, [sp, #0x8]
    260c:      	add	sp, sp, #0x10
    2610:      	ret
    2614:      	movz	x0, #0x0, lsl #48
    2618:      	movz	x1, #0x0, lsl #48
    261c:      	b	0x25fc <_stogir.graph.operand+0x5c>
    2620:      	movz	x5, #0x0, lsl #48
    2624:      	b	0x262c <_stogir.graph.operand+0x8c>
    2628:      	movz	x5, #0x0, lsl #48
    262c:      	cmp	x5, #0x0
    2630:      	b.eq	0x25f4 <_stogir.graph.operand+0x54>
    2634:      	sxtw	x2, w2
    2638:      	cmp	x2, #0x1
    263c:      	b.lt	0x2614 <_stogir.graph.operand+0x74>
    2640:      	ldr	x5, [x0, #0x78]
    2644:      	add	x4, x4, x5
    2648:      	ldr	w4, [x4]
    264c:      	sxtw	x4, w4
    2650:      	cmp	x2, x4
    2654:      	b.gt	0x2614 <_stogir.graph.operand+0x74>
    2658:      	asr	x16, x2, #63
    265c:      	lsr	x16, x16, #62
    2660:      	add	x4, x2, x16
    2664:      	asr	x4, x4, #2
    2668:      	asr	x16, x2, #63
    266c:      	lsr	x16, x16, #62
    2670:      	add	x2, x2, x16
    2674:      	and	x2, x2, #0x3
    2678:      	sub	x2, x2, x16
    267c:      	ldr	x0, [x0]
    2680:      	add	x1, x4, x1
    2684:      	add	x0, x0, x1, lsl #4
    2688:      	add	x0, x0, x2, lsl #2
    268c:      	ldr	w0, [x0]
    2690:      	sxtw	x0, w0
    2694:      	and	x0, x0, #0xffffffff
    2698:      	mov	x1, x0
    269c:      	mov	x0, #0x1                ; =1
    26a0:      	b	0x261c <_stogir.graph.operand+0x7c>

00000000000026a4 <_stogir.graph.borrow-node>:
    26a4:      	sxtw	x1, w1
    26a8:      	cmp	x1, #0x0
    26ac:      	cset	w2, gt
    26b0:      	movz	x16, #0x0, lsl #48
    26b4:      	sub	x3, x16, x1
    26b8:      	sub	x4, x3, #0x1
    26bc:      	uxtb	w16, w2
    26c0:      	cmp	w16, wzr
    26c4:      	b.eq	0x2704 <_stogir.graph.borrow-node+0x60>
    26c8:      	ldr	x3, [x0, #0x8]
    26cc:      	cmp	x1, x3
    26d0:      	b.ge	0x2754 <_stogir.graph.borrow-node+0xb0>
    26d4:      	add	x3, x0, #0x78
    26d8:      	ldr	x3, [x3, #0x8]
    26dc:      	cmp	x1, x3
    26e0:      	b.ge	0x2794 <_stogir.graph.borrow-node+0xf0>
    26e4:      	ldr	x3, [x0, #0x78]
    26e8:      	add	x3, x3, x1, lsl #2
    26ec:      	ldr	w3, [x3]
    26f0:      	sxtw	x3, w3
    26f4:      	cmp	x3, #0x0
    26f8:      	cset	w3, ge
    26fc:      	ubfx	x3, x3, #0, #8
    2700:      	b	0x2798 <_stogir.graph.borrow-node+0xf4>
    2704:      	cmp	x1, #0x0
    2708:      	b.ge	0x275c <_stogir.graph.borrow-node+0xb8>
    270c:      	add	x5, x0, #0x28
    2710:      	add	x6, x0, #0x50
    2714:      	ldr	x5, [x5, #0x8]
    2718:      	ldr	x6, [x6, #0x8]
    271c:      	cmp	x5, x6
    2720:      	b.ne	0x274c <_stogir.graph.borrow-node+0xa8>
    2724:      	cmp	x3, x5
    2728:      	b.gt	0x279c <_stogir.graph.borrow-node+0xf8>
    272c:      	ldr	x3, [x0, #0x50]
    2730:      	add	x3, x3, x4, lsl #2
    2734:      	ldr	w3, [x3]
    2738:      	sxtw	x3, w3
    273c:      	cmp	x3, #0x0
    2740:      	cset	w3, gt
    2744:      	ubfx	x3, x3, #0, #8
    2748:      	b	0x27a0 <_stogir.graph.borrow-node+0xfc>
    274c:      	movz	x3, #0x0, lsl #48
    2750:      	b	0x2760 <_stogir.graph.borrow-node+0xbc>
    2754:      	movz	x3, #0x0, lsl #48
    2758:      	b	0x2760 <_stogir.graph.borrow-node+0xbc>
    275c:      	movz	x3, #0x0, lsl #48
    2760:      	cmp	x3, #0x0
    2764:      	b.eq	0x278c <_stogir.graph.borrow-node+0xe8>
    2768:      	uxtb	w16, w2
    276c:      	cmp	w16, wzr
    2770:      	b.eq	0x2780 <_stogir.graph.borrow-node+0xdc>
    2774:      	ldr	x0, [x0]
    2778:      	add	x0, x0, x1, lsl #4
    277c:      	b	0x2788 <_stogir.graph.borrow-node+0xe4>
    2780:      	ldr	x0, [x0, #0x28]
    2784:      	add	x0, x0, x4, lsl #4
    2788:      	b	0x2790 <_stogir.graph.borrow-node+0xec>
    278c:      	movz	x0, #0x0, lsl #48
    2790:      	ret
    2794:      	movz	x3, #0x0, lsl #48
    2798:      	b	0x2758 <_stogir.graph.borrow-node+0xb4>
    279c:      	movz	x3, #0x0, lsl #48
    27a0:      	b	0x2750 <_stogir.graph.borrow-node+0xac>

00000000000027a4 <_stogir.strings.lookup>:
    27a4:      	sxtw	x1, w1
    27a8:      	cmp	x1, #0x0
    27ac:      	b.le	0x2824 <_stogir.strings.lookup+0x80>
    27b0:      	add	x2, x0, #0x28
    27b4:      	ldr	x2, [x2, #0x8]
    27b8:      	cmp	x1, x2
    27bc:      	b.gt	0x2824 <_stogir.strings.lookup+0x80>
    27c0:      	sub	x1, x1, #0x1
    27c4:      	mov	x17, #0x18              ; =24
    27c8:      	mul	x1, x1, x17
    27cc:      	ldr	x2, [x0, #0x28]
    27d0:      	add	x1, x1, x2
    27d4:      	ldr	x2, [x1]
    27d8:      	ldr	x1, [x1, #0x8]
    27dc:      	ldr	x3, [x0, #0x8]
    27e0:      	cmp	x2, #0x0
    27e4:      	b.lt	0x2840 <_stogir.strings.lookup+0x9c>
    27e8:      	cmp	x2, x3
    27ec:      	b.gt	0x2840 <_stogir.strings.lookup+0x9c>
    27f0:      	cmp	x1, #0x0
    27f4:      	b.lt	0x2840 <_stogir.strings.lookup+0x9c>
    27f8:      	sub	x3, x3, x2
    27fc:      	cmp	x1, x3
    2800:      	b.gt	0x2840 <_stogir.strings.lookup+0x9c>
    2804:      	add	x1, x1, x2
    2808:      	sub	x1, x1, x2
    280c:      	ldr	x0, [x0]
    2810:      	add	x0, x0, x2
    2814:      	mov	x2, x1
    2818:      	mov	x1, x0
    281c:      	mov	x0, #0x1                ; =1
    2820:      	b	0x284c <_stogir.strings.lookup+0xa8>
    2824:      	movz	x0, #0x0, lsl #48
    2828:      	movz	x1, #0x0, lsl #48
    282c:      	movz	x2, #0x0, lsl #48
    2830:      	str	x0, [x8]
    2834:      	str	x1, [x8, #0x8]
    2838:      	str	x2, [x8, #0x10]
    283c:      	ret
    2840:      	movz	x0, #0x0, lsl #48
    2844:      	movz	x1, #0x0, lsl #48
    2848:      	movz	x2, #0x0, lsl #48
    284c:      	b	0x2830 <_stogir.strings.lookup+0x8c>

0000000000002850 <_stogir.uses.edge-code?>:
    2850:      	ubfx	x0, x0, #0, #32
    2854:      	cmp	x0, #0xf
    2858:      	b.hs	0x288c <_stogir.uses.edge-code?+0x3c>
    285c:      	mov	x16, #0x1               ; =1
    2860:      	lsl	x0, x16, x0
    2864:      	lsr	w0, w0, #0
    2868:      	mov	x17, #0x5e1c            ; =24092
    286c:      	and	x0, x0, x17
    2870:      	lsr	w0, w0, #0
    2874:      	cmp	x0, #0x0
    2878:      	cset	w0, eq
    287c:      	uxtb	w16, w0
    2880:      	cmp	w16, wzr
    2884:      	cset	x0, eq
    2888:      	b	0x2890 <_stogir.uses.edge-code?+0x40>
    288c:      	movz	x0, #0x0, lsl #48
    2890:      	ret

0000000000002894 <_stogir.graph.contains?>:
    2894:      	sxtw	x1, w1
    2898:      	cmp	x1, #0x0
    289c:      	b.le	0x28dc <_stogir.graph.contains?+0x48>
    28a0:      	ldr	x2, [x0, #0x8]
    28a4:      	cmp	x1, x2
    28a8:      	b.ge	0x2938 <_stogir.graph.contains?+0xa4>
    28ac:      	add	x2, x0, #0x78
    28b0:      	ldr	x2, [x2, #0x8]
    28b4:      	cmp	x1, x2
    28b8:      	b.ge	0x2948 <_stogir.graph.contains?+0xb4>
    28bc:      	ldr	x0, [x0, #0x78]
    28c0:      	add	x0, x0, x1, lsl #2
    28c4:      	ldr	w0, [x0]
    28c8:      	sxtw	x0, w0
    28cc:      	cmp	x0, #0x0
    28d0:      	cset	w0, ge
    28d4:      	ubfx	x0, x0, #0, #8
    28d8:      	b	0x294c <_stogir.graph.contains?+0xb8>
    28dc:      	cmp	x1, #0x0
    28e0:      	b.ge	0x2940 <_stogir.graph.contains?+0xac>
    28e4:      	add	x2, x0, #0x28
    28e8:      	add	x3, x0, #0x50
    28ec:      	ldr	x2, [x2, #0x8]
    28f0:      	ldr	x3, [x3, #0x8]
    28f4:      	cmp	x2, x3
    28f8:      	b.ne	0x2958 <_stogir.graph.contains?+0xc4>
    28fc:      	movz	x16, #0x0, lsl #48
    2900:      	sub	x3, x16, x1
    2904:      	cmp	x3, x2
    2908:      	b.gt	0x2950 <_stogir.graph.contains?+0xbc>
    290c:      	movz	x16, #0x0, lsl #48
    2910:      	sub	x1, x16, x1
    2914:      	sub	x1, x1, #0x1
    2918:      	ldr	x0, [x0, #0x50]
    291c:      	add	x0, x0, x1, lsl #2
    2920:      	ldr	w0, [x0]
    2924:      	sxtw	x0, w0
    2928:      	cmp	x0, #0x0
    292c:      	cset	w0, gt
    2930:      	ubfx	x0, x0, #0, #8
    2934:      	b	0x2954 <_stogir.graph.contains?+0xc0>
    2938:      	movz	x0, #0x0, lsl #48
    293c:      	b	0x294c <_stogir.graph.contains?+0xb8>
    2940:      	movz	x0, #0x0, lsl #48
    2944:      	b	0x2954 <_stogir.graph.contains?+0xc0>
    2948:      	movz	x0, #0x0, lsl #48
    294c:      	b	0x2954 <_stogir.graph.contains?+0xc0>
    2950:      	movz	x0, #0x0, lsl #48
    2954:      	ret
    2958:      	movz	x0, #0x0, lsl #48
    295c:      	b	0x2954 <_stogir.graph.contains?+0xc0>

0000000000002960 <_stogir.opcode.optional-reference?>:
    2960:      	sxtw	x0, w0
    2964:      	sxtw	x2, w2
    2968:      	cmp	x0, #0x0
    296c:      	b.lt	0x29a4 <_stogir.opcode.optional-reference?+0x44>
    2970:      	cmp	x0, #0x83
    2974:      	b.ge	0x29a4 <_stogir.opcode.optional-reference?+0x44>
    2978:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		0000000000002978:  ARM64_RELOC_PAGE21	l_stogir.339
    297c:      	ldr	x16, [x16]
		000000000000297c:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2980:      	orr	x3, x16, xzr
    2984:      	add	x3, x3, x0, lsl #2
    2988:      	ldr	w3, [x3]
    298c:      	cmp	x2, #0x0
    2990:      	b.le	0x29ec <_stogir.opcode.optional-reference?+0x8c>
    2994:      	cmp	x2, #0x4
    2998:      	b.le	0x2a10 <_stogir.opcode.optional-reference?+0xb0>
    299c:      	mov	x4, #0x4                ; =4
    29a0:      	b	0x2a1c <_stogir.opcode.optional-reference?+0xbc>
    29a4:      	movz	x3, #0x0, lsl #48
    29a8:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		00000000000029a8:  ARM64_RELOC_PAGE21	l_stogir.340
    29ac:      	ldr	x16, [x16]
		00000000000029ac:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    29b0:      	ldr	w4, [x16]
    29b4:      	lsr	w3, w3, #0
    29b8:      	cmp	x3, x4
    29bc:      	b.ne	0x29d0 <_stogir.opcode.optional-reference?+0x70>
    29c0:      	mov	x0, #0x1                ; =1
    29c4:      	b	0x29cc <_stogir.opcode.optional-reference?+0x6c>
    29c8:      	movz	x0, #0x0, lsl #48
    29cc:      	ret
    29d0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		00000000000029d0:  ARM64_RELOC_PAGE21	l_stogir.341
    29d4:      	ldr	x16, [x16]
		00000000000029d4:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    29d8:      	ldr	w4, [x16]
    29dc:      	cmp	x3, x4
    29e0:      	b.ne	0x29f4 <_stogir.opcode.optional-reference?+0x94>
    29e4:      	mov	x0, #0x1                ; =1
    29e8:      	b	0x29cc <_stogir.opcode.optional-reference?+0x6c>
    29ec:      	movz	x3, #0x0, lsl #48
    29f0:      	b	0x29a8 <_stogir.opcode.optional-reference?+0x48>
    29f4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		00000000000029f4:  ARM64_RELOC_PAGE21	l_stogir.342
    29f8:      	ldr	x16, [x16]
		00000000000029f8:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    29fc:      	ldr	w4, [x16]
    2a00:      	cmp	x3, x4
    2a04:      	b.ne	0x2a3c <_stogir.opcode.optional-reference?+0xdc>
    2a08:      	mov	x0, #0x1                ; =1
    2a0c:      	b	0x29cc <_stogir.opcode.optional-reference?+0x6c>
    2a10:      	sub	x4, x2, #0x1
    2a14:      	lsr	w4, w4, #0
    2a18:      	sxtw	x4, w4
    2a1c:      	lsl	x4, x4, #2
    2a20:      	lsr	w4, w4, #0
    2a24:      	ubfx	x4, x4, #0, #32
    2a28:      	lsr	x3, x3, x4
    2a2c:      	lsr	w3, w3, #0
    2a30:      	and	x3, x3, #0xf
    2a34:      	lsr	w3, w3, #0
    2a38:      	b	0x29f0 <_stogir.opcode.optional-reference?+0x90>
    2a3c:      	cmp	x0, #0x78
    2a40:      	b.ne	0x29c8 <_stogir.opcode.optional-reference?+0x68>
    2a44:      	sxtw	x1, w1
    2a48:      	cmp	x1, #0x0
    2a4c:      	b.ne	0x2a60 <_stogir.opcode.optional-reference?+0x100>
    2a50:      	cmp	x2, #0x2
    2a54:      	cset	w0, eq
    2a58:      	ubfx	x0, x0, #0, #8
    2a5c:      	b	0x2a64 <_stogir.opcode.optional-reference?+0x104>
    2a60:      	movz	x0, #0x0, lsl #48
    2a64:      	b	0x29cc <_stogir.opcode.optional-reference?+0x6c>

0000000000002a68 <_stogir.integer-binary.operation?>:
    2a68:      	sxtw	x0, w0
    2a6c:      	cmp	x0, #0x1a
    2a70:      	b.lt	0x2a84 <_stogir.integer-binary.operation?+0x1c>
    2a74:      	cmp	x0, #0x1e
    2a78:      	b.gt	0x2a84 <_stogir.integer-binary.operation?+0x1c>
    2a7c:      	mov	x0, #0x1                ; =1
    2a80:      	b	0x2ab8 <_stogir.integer-binary.operation?+0x50>
    2a84:      	cmp	x0, #0x2e
    2a88:      	b.lt	0x2a9c <_stogir.integer-binary.operation?+0x34>
    2a8c:      	cmp	x0, #0x35
    2a90:      	b.gt	0x2a9c <_stogir.integer-binary.operation?+0x34>
    2a94:      	mov	x0, #0x1                ; =1
    2a98:      	b	0x2ab8 <_stogir.integer-binary.operation?+0x50>
    2a9c:      	cmp	x0, #0x3a
    2aa0:      	b.ne	0x2aac <_stogir.integer-binary.operation?+0x44>
    2aa4:      	mov	x0, #0x1                ; =1
    2aa8:      	b	0x2ab8 <_stogir.integer-binary.operation?+0x50>
    2aac:      	cmp	x0, #0x3b
    2ab0:      	cset	w0, eq
    2ab4:      	ubfx	x0, x0, #0, #8
    2ab8:      	ret

0000000000002abc <_stogir.integer-unary.operation?>:
    2abc:      	sxtw	x0, w0
    2ac0:      	cmp	x0, #0x1f
    2ac4:      	b.ne	0x2ae0 <_stogir.integer-unary.operation?+0x24>
    2ac8:      	mov	x0, #0x1                ; =1
    2acc:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>
    2ad0:      	cmp	x0, #0x39
    2ad4:      	cset	w0, eq
    2ad8:      	ubfx	x0, x0, #0, #8
    2adc:      	ret
    2ae0:      	cmp	x0, #0x20
    2ae4:      	b.ne	0x2af0 <_stogir.integer-unary.operation?+0x34>
    2ae8:      	mov	x0, #0x1                ; =1
    2aec:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>
    2af0:      	cmp	x0, #0x2d
    2af4:      	b.ne	0x2b00 <_stogir.integer-unary.operation?+0x44>
    2af8:      	mov	x0, #0x1                ; =1
    2afc:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>
    2b00:      	cmp	x0, #0x36
    2b04:      	b.ne	0x2b10 <_stogir.integer-unary.operation?+0x54>
    2b08:      	mov	x0, #0x1                ; =1
    2b0c:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>
    2b10:      	cmp	x0, #0x37
    2b14:      	b.ne	0x2b20 <_stogir.integer-unary.operation?+0x64>
    2b18:      	mov	x0, #0x1                ; =1
    2b1c:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>
    2b20:      	cmp	x0, #0x38
    2b24:      	b.ne	0x2ad0 <_stogir.integer-unary.operation?+0x14>
    2b28:      	mov	x0, #0x1                ; =1
    2b2c:      	b	0x2adc <_stogir.integer-unary.operation?+0x20>

0000000000002b30 <_stogir.verify.classifications>:
    2b30:      	sub	sp, sp, #0x70
    2b34:      	str	x29, [sp]
    2b38:      	str	x30, [sp, #0x8]
    2b3c:      	mov	x29, sp
    2b40:      	str	x19, [sp, #0x20]
    2b44:      	str	x20, [sp, #0x28]
    2b48:      	str	x21, [sp, #0x30]
    2b4c:      	str	x22, [sp, #0x38]
    2b50:      	str	x23, [sp, #0x40]
    2b54:      	str	x24, [sp, #0x48]
    2b58:      	str	x25, [sp, #0x50]
    2b5c:      	str	x26, [sp, #0x58]
    2b60:      	str	x27, [sp, #0x60]
    2b64:      	str	x28, [sp, #0x68]
    2b68:      	ldr	w4, [x2]
    2b6c:      	uxtb	w19, w4
    2b70:      	orr	x5, x19, xzr
    2b74:      	lsr	w20, w5, #0
    2b78:      	ubfx	x21, x4, #8, #8
    2b7c:      	orr	x4, x21, xzr
    2b80:      	lsr	w4, w4, #0
    2b84:      	mov	x22, x0
    2b88:      	mov	w0, w4
    2b8c:      	mov	w23, w1
    2b90:      	mov	x24, x2
    2b94:      	mov	w25, w3
    2b98:      	bl	0x2b98 <_stogir.verify.classifications+0x68>
		0000000000002b98:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2b9c:      	fmov	d31, x0
    2ba0:      	mov	w0, w20
    2ba4:      	fmov	x20, d31
    2ba8:      	bl	0x2ba8 <_stogir.verify.classifications+0x78>
		0000000000002ba8:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2bac:      	cmp	x0, #0x0
    2bb0:      	b.eq	0x2bd0 <_stogir.verify.classifications+0xa0>
    2bb4:      	cmp	x20, #0x0
    2bb8:      	cset	w0, ne
    2bbc:      	uxtb	w16, w0
    2bc0:      	cmp	w16, wzr
    2bc4:      	cset	x0, eq
    2bc8:      	mov	x26, x0
    2bcc:      	b	0x2bd4 <_stogir.verify.classifications+0xa4>
    2bd0:      	movz	x26, #0x0, lsl #48
    2bd4:      	cmp	x26, #0x0
    2bd8:      	cset	w27, ne
    2bdc:      	uxtb	w16, w27
    2be0:      	cmp	w16, wzr
    2be4:      	b.eq	0x2c18 <_stogir.verify.classifications+0xe8>
    2be8:      	ldr	w0, [x24, #0x4]
    2bec:      	lsr	w0, w0, #0
    2bf0:      	mov	w1, w0
    2bf4:      	mov	x0, x22
    2bf8:      	bl	0x2bf8 <_stogir.verify.classifications+0xc8>
		0000000000002bf8:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2bfc:      	cmp	x0, #0x0
    2c00:      	b.ne	0x2c0c <_stogir.verify.classifications+0xdc>
    2c04:      	movn	x0, #0x0, lsl #48
    2c08:      	b	0x2c14 <_stogir.verify.classifications+0xe4>
    2c0c:      	ldr	w0, [x0]
    2c10:      	ubfx	x0, x0, #8, #8
    2c14:      	b	0x2c1c <_stogir.verify.classifications+0xec>
    2c18:      	movn	x0, #0x0, lsl #48
    2c1c:      	lsr	w0, w0, #0
    2c20:      	sxtw	x28, w0
    2c24:      	cmp	x26, #0x0
    2c28:      	b.eq	0x2c58 <_stogir.verify.classifications+0x128>
    2c2c:      	bl	0x2c2c <_stogir.verify.classifications+0xfc>
		0000000000002c2c:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    2c30:      	cmp	x0, #0x0
    2c34:      	b.eq	0x3094 <_stogir.verify.classifications+0x564>
    2c38:      	movz	x0, #0x0, lsl #48
    2c3c:      	b	0x2c44 <_stogir.verify.classifications+0x114>
    2c40:      	mov	x0, #0x1                ; =1
    2c44:      	b	0x2c5c <_stogir.verify.classifications+0x12c>
    2c48:      	movz	x20, #0x0, lsl #48
    2c4c:      	b	0x2ce0 <_stogir.verify.classifications+0x1b0>
    2c50:      	movz	x13, #0x0, lsl #48
    2c54:      	b	0x2ce8 <_stogir.verify.classifications+0x1b8>
    2c58:      	movz	x0, #0x0, lsl #48
    2c5c:      	sxtw	x25, w25
    2c60:      	cmp	x28, #0xf
    2c64:      	cset	w1, gt
    2c68:      	cmp	x28, #0x80
    2c6c:      	cset	w2, lt
    2c70:      	and	x3, x28, #0xf
    2c74:      	cmp	x19, #0x83
    2c78:      	cset	w4, lt
    2c7c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		0000000000002c7c:  ARM64_RELOC_PAGE21	l_stogir.343
    2c80:      	ldr	x16, [x16]
		0000000000002c80:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    2c84:      	orr	x5, x16, xzr
    2c88:      	add	x6, x22, #0x78
    2c8c:      	add	x7, x22, #0x28
    2c90:      	add	x8, x22, #0x50
    2c94:      	sxtw	x23, w23
    2c98:      	add	x9, x22, #0x78
    2c9c:      	lsr	w3, w3, #0
    2ca0:      	add	x5, x5, x19, lsl #2
    2ca4:      	cmp	x23, #0x0
    2ca8:      	cset	w10, le
    2cac:      	lsl	x11, x23, #2
    2cb0:      	sxtw	x3, w3
    2cb4:      	cmp	x3, #0x1
    2cb8:      	cset	w12, ge
    2cbc:      	cmp	x3, #0xd
    2cc0:      	cset	w3, le
    2cc4:      	ubfx	x3, x3, #0, #8
    2cc8:      	mov	x13, x20
    2ccc:      	mov	x14, #0x1               ; =1
    2cd0:      	b	0x2da0 <_stogir.verify.classifications+0x270>
    2cd4:      	movz	x20, #0x0, lsl #48
    2cd8:      	b	0x2d1c <_stogir.verify.classifications+0x1ec>
    2cdc:      	movz	x20, #0x0, lsl #48
    2ce0:      	b	0x2d24 <_stogir.verify.classifications+0x1f4>
    2ce4:      	movz	x13, #0x0, lsl #48
    2ce8:      	b	0x2d94 <_stogir.verify.classifications+0x264>
    2cec:      	sub	x20, x15, #0x1
    2cf0:      	lsr	w20, w20, #0
    2cf4:      	sxtw	x20, w20
    2cf8:      	lsl	x20, x20, #2
    2cfc:      	lsr	w20, w20, #0
    2d00:      	ubfx	x20, x20, #0, #32
    2d04:      	lsr	x19, x19, x20
    2d08:      	lsr	w19, w19, #0
    2d0c:      	and	x19, x19, #0xf
    2d10:      	lsr	w19, w19, #0
    2d14:      	b	0x2de4 <_stogir.verify.classifications+0x2b4>
    2d18:      	movz	x20, #0x0, lsl #48
    2d1c:      	b	0x2d24 <_stogir.verify.classifications+0x1f4>
    2d20:      	movz	x20, #0x0, lsl #48
    2d24:      	cmp	x20, #0x0
    2d28:      	b.eq	0x2d50 <_stogir.verify.classifications+0x220>
    2d2c:      	uxtb	w16, w19
    2d30:      	cmp	w16, wzr
    2d34:      	b.eq	0x2d44 <_stogir.verify.classifications+0x214>
    2d38:      	ldr	x19, [x22]
    2d3c:      	add	x15, x19, x15, lsl #4
    2d40:      	b	0x2d4c <_stogir.verify.classifications+0x21c>
    2d44:      	ldr	x15, [x22, #0x28]
    2d48:      	add	x15, x15, x21, lsl #4
    2d4c:      	b	0x2d54 <_stogir.verify.classifications+0x224>
    2d50:      	movz	x15, #0x0, lsl #48
    2d54:      	cmp	x15, #0x0
    2d58:      	b.eq	0x2d94 <_stogir.verify.classifications+0x264>
    2d5c:      	ldr	w15, [x15]
    2d60:      	ubfx	x15, x15, #8, #8
    2d64:      	cmp	x15, #0xf
    2d68:      	b.le	0x2d94 <_stogir.verify.classifications+0x264>
    2d6c:      	cmp	x15, #0x80
    2d70:      	b.ge	0x2d94 <_stogir.verify.classifications+0x264>
    2d74:      	and	x15, x15, #0xf
    2d78:      	lsr	w15, w15, #0
    2d7c:      	sxtw	x15, w15
    2d80:      	cmp	x15, #0x1
    2d84:      	b.lt	0x2d94 <_stogir.verify.classifications+0x264>
    2d88:      	cmp	x15, #0xd
    2d8c:      	b.gt	0x2d94 <_stogir.verify.classifications+0x264>
    2d90:      	mov	x13, #0x1               ; =1
    2d94:      	add	x14, x14, #0x1
    2d98:      	lsr	w14, w14, #0
    2d9c:      	sxtw	x14, w14
    2da0:      	cmp	x13, #0x0
    2da4:      	b.ne	0x2f30 <_stogir.verify.classifications+0x400>
    2da8:      	cmp	x14, x25
    2dac:      	b.gt	0x2f30 <_stogir.verify.classifications+0x400>
    2db0:      	lsr	w15, w14, #0
    2db4:      	sxtw	x15, w15
    2db8:      	uxtb	w16, w4
    2dbc:      	cmp	w16, wzr
    2dc0:      	b.eq	0x2de8 <_stogir.verify.classifications+0x2b8>
    2dc4:      	ldr	w19, [x5]
    2dc8:      	cmp	x15, #0x0
    2dcc:      	b.le	0x2de0 <_stogir.verify.classifications+0x2b0>
    2dd0:      	cmp	x15, #0x4
    2dd4:      	b.le	0x2cec <_stogir.verify.classifications+0x1bc>
    2dd8:      	mov	x20, #0x4               ; =4
    2ddc:      	b	0x2cf8 <_stogir.verify.classifications+0x1c8>
    2de0:      	movz	x19, #0x0, lsl #48
    2de4:      	b	0x2dec <_stogir.verify.classifications+0x2bc>
    2de8:      	movz	x19, #0x0, lsl #48
    2dec:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		0000000000002dec:  ARM64_RELOC_PAGE21	l_stogir.344
    2df0:      	ldr	x16, [x16]
		0000000000002df0:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    2df4:      	ldr	w20, [x16]
    2df8:      	lsr	w19, w19, #0
    2dfc:      	cmp	x19, x20
    2e00:      	b.eq	0x2e18 <_stogir.verify.classifications+0x2e8>
    2e04:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x122c>
		0000000000002e04:  ARM64_RELOC_PAGE21	l_stogir.345
    2e08:      	ldr	x16, [x16]
		0000000000002e08:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    2e0c:      	ldr	w20, [x16]
    2e10:      	cmp	x19, x20
    2e14:      	b.ne	0x2d94 <_stogir.verify.classifications+0x264>
    2e18:      	cmp	x14, #0x1
    2e1c:      	b.ne	0x2e58 <_stogir.verify.classifications+0x328>
    2e20:      	uxtb	w16, w27
    2e24:      	cmp	w16, wzr
    2e28:      	b.eq	0x2e58 <_stogir.verify.classifications+0x328>
    2e2c:      	uxtb	w16, w1
    2e30:      	cmp	w16, wzr
    2e34:      	b.eq	0x2ce4 <_stogir.verify.classifications+0x1b4>
    2e38:      	uxtb	w16, w2
    2e3c:      	cmp	w16, wzr
    2e40:      	b.eq	0x2c50 <_stogir.verify.classifications+0x120>
    2e44:      	uxtb	w16, w12
    2e48:      	cmp	w16, wzr
    2e4c:      	b.eq	0x303c <_stogir.verify.classifications+0x50c>
    2e50:      	mov	x13, x3
    2e54:      	b	0x3040 <_stogir.verify.classifications+0x510>
    2e58:      	cmp	x14, #0x1
    2e5c:      	b.ne	0x2ec8 <_stogir.verify.classifications+0x398>
    2e60:      	ldr	w15, [x24, #0x4]
    2e64:      	sxtw	x15, w15
    2e68:      	lsr	w15, w15, #0
    2e6c:      	sxtw	x15, w15
    2e70:      	cmp	x15, #0x0
    2e74:      	cset	w19, gt
    2e78:      	movz	x16, #0x0, lsl #48
    2e7c:      	sub	x20, x16, x15
    2e80:      	sub	x21, x20, #0x1
    2e84:      	uxtb	w16, w19
    2e88:      	cmp	w16, wzr
    2e8c:      	b.eq	0x2edc <_stogir.verify.classifications+0x3ac>
    2e90:      	ldr	x20, [x22, #0x8]
    2e94:      	cmp	x15, x20
    2e98:      	b.ge	0x2d18 <_stogir.verify.classifications+0x1e8>
    2e9c:      	ldr	x20, [x6, #0x8]
    2ea0:      	cmp	x15, x20
    2ea4:      	b.ge	0x2cd4 <_stogir.verify.classifications+0x1a4>
    2ea8:      	ldr	x20, [x22, #0x78]
    2eac:      	add	x20, x20, x15, lsl #2
    2eb0:      	ldr	w20, [x20]
    2eb4:      	sxtw	x20, w20
    2eb8:      	cmp	x20, #0x0
    2ebc:      	cset	w20, ge
    2ec0:      	ubfx	x20, x20, #0, #8
    2ec4:      	b	0x2cd8 <_stogir.verify.classifications+0x1a8>
    2ec8:      	cmp	x14, #0x2
    2ecc:      	b.ne	0x2f1c <_stogir.verify.classifications+0x3ec>
    2ed0:      	ldr	w15, [x24, #0x8]
    2ed4:      	sxtw	x15, w15
    2ed8:      	b	0x2e68 <_stogir.verify.classifications+0x338>
    2edc:      	cmp	x15, #0x0
    2ee0:      	b.ge	0x2d20 <_stogir.verify.classifications+0x1f0>
    2ee4:      	ldr	x26, [x7, #0x8]
    2ee8:      	ldr	x28, [x8, #0x8]
    2eec:      	cmp	x26, x28
    2ef0:      	b.ne	0x2cdc <_stogir.verify.classifications+0x1ac>
    2ef4:      	cmp	x20, x26
    2ef8:      	b.gt	0x2c48 <_stogir.verify.classifications+0x118>
    2efc:      	ldr	x20, [x22, #0x50]
    2f00:      	add	x20, x20, x21, lsl #2
    2f04:      	ldr	w20, [x20]
    2f08:      	sxtw	x20, w20
    2f0c:      	cmp	x20, #0x0
    2f10:      	cset	w20, gt
    2f14:      	ubfx	x20, x20, #0, #8
    2f18:      	b	0x2c4c <_stogir.verify.classifications+0x11c>
    2f1c:      	cmp	x14, #0x3
    2f20:      	b.ne	0x2f94 <_stogir.verify.classifications+0x464>
    2f24:      	ldr	w15, [x24, #0xc]
    2f28:      	sxtw	x15, w15
    2f2c:      	b	0x2ed8 <_stogir.verify.classifications+0x3a8>
    2f30:      	uxtb	w13, w13
    2f34:      	uxtb	w0, w0
    2f38:      	add	x16, sp, #0x10
    2f3c:      	movz	w17, #0x0, lsl #16
    2f40:      	strh	w17, [x16]
    2f44:      	add	x16, sp, #0x10
    2f48:      	strb	w13, [x16]
    2f4c:      	add	x16, sp, #0x10
    2f50:      	strb	w0, [x16, #0x1]
    2f54:      	add	x16, sp, #0x10
    2f58:      	ldrh	w0, [x16]
    2f5c:      	ldr	x19, [sp, #0x20]
    2f60:      	ldr	x20, [sp, #0x28]
    2f64:      	ldr	x21, [sp, #0x30]
    2f68:      	ldr	x22, [sp, #0x38]
    2f6c:      	ldr	x23, [sp, #0x40]
    2f70:      	ldr	x24, [sp, #0x48]
    2f74:      	ldr	x25, [sp, #0x50]
    2f78:      	ldr	x26, [sp, #0x58]
    2f7c:      	ldr	x27, [sp, #0x60]
    2f80:      	ldr	x28, [sp, #0x68]
    2f84:      	ldr	x29, [sp]
    2f88:      	ldr	x30, [sp, #0x8]
    2f8c:      	add	sp, sp, #0x70
    2f90:      	ret
    2f94:      	uxtb	w16, w10
    2f98:      	cmp	w16, wzr
    2f9c:      	b.ne	0x3054 <_stogir.verify.classifications+0x524>
    2fa0:      	ldr	x19, [x22, #0x8]
    2fa4:      	cmp	x23, x19
    2fa8:      	b.ge	0x3054 <_stogir.verify.classifications+0x524>
    2fac:      	ldr	x19, [x9, #0x8]
    2fb0:      	cmp	x23, x19
    2fb4:      	b.ge	0x3054 <_stogir.verify.classifications+0x524>
    2fb8:      	ldr	x19, [x22, #0x78]
    2fbc:      	add	x19, x11, x19
    2fc0:      	ldr	w19, [x19]
    2fc4:      	sxtw	x19, w19
    2fc8:      	cmp	x19, #0x0
    2fcc:      	b.lt	0x3054 <_stogir.verify.classifications+0x524>
    2fd0:      	cmp	x15, #0x1
    2fd4:      	b.lt	0x30d4 <_stogir.verify.classifications+0x5a4>
    2fd8:      	ldr	x19, [x22, #0x78]
    2fdc:      	add	x19, x11, x19
    2fe0:      	ldr	w19, [x19]
    2fe4:      	sxtw	x19, w19
    2fe8:      	cmp	x15, x19
    2fec:      	b.gt	0x30d4 <_stogir.verify.classifications+0x5a4>
    2ff0:      	ldr	x19, [x22]
    2ff4:      	asr	x16, x15, #63
    2ff8:      	lsr	x16, x16, #62
    2ffc:      	add	x20, x15, x16
    3000:      	asr	x20, x20, #2
    3004:      	asr	x16, x15, #63
    3008:      	lsr	x16, x16, #62
    300c:      	add	x15, x15, x16
    3010:      	and	x15, x15, #0x3
    3014:      	sub	x15, x15, x16
    3018:      	add	x20, x20, x23
    301c:      	add	x19, x19, x20, lsl #4
    3020:      	add	x15, x19, x15, lsl #2
    3024:      	ldr	w15, [x15]
    3028:      	sxtw	x15, w15
    302c:      	and	x15, x15, #0xffffffff
    3030:      	mov	x19, x15
    3034:      	mov	x15, #0x1               ; =1
    3038:      	b	0x30dc <_stogir.verify.classifications+0x5ac>
    303c:      	movz	x13, #0x0, lsl #48
    3040:      	b	0x2c54 <_stogir.verify.classifications+0x124>
    3044:      	lsr	w19, w19, #0
    3048:      	sxtw	x19, w19
    304c:      	mov	x15, x19
    3050:      	b	0x2f2c <_stogir.verify.classifications+0x3fc>
    3054:      	movz	x15, #0x0, lsl #48
    3058:      	movz	x19, #0x0, lsl #48
    305c:      	lsr	w15, w15, #0
    3060:      	lsr	x16, x15, #0
    3064:      	cmp	x16, #0x1
    3068:      	b.eq	0x3084 <_stogir.verify.classifications+0x554>
    306c:      	b.lo	0x3074 <_stogir.verify.classifications+0x544>
    3070:      	b	0x3088 <_stogir.verify.classifications+0x558>
    3074:      	cmp	x16, #0x0
    3078:      	b.eq	0x3080 <_stogir.verify.classifications+0x550>
    307c:      	b	0x3088 <_stogir.verify.classifications+0x558>
    3080:      	b	0x308c <_stogir.verify.classifications+0x55c>
    3084:      	b	0x3044 <_stogir.verify.classifications+0x514>
    3088:      	b	0x30f0 <_stogir.verify.classifications+0x5c0>
    308c:      	movz	x15, #0x0, lsl #48
    3090:      	b	0x3050 <_stogir.verify.classifications+0x520>
    3094:      	cmp	x19, #0x18
    3098:      	b.ne	0x30a4 <_stogir.verify.classifications+0x574>
    309c:      	mov	x0, #0x1                ; =1
    30a0:      	b	0x2c44 <_stogir.verify.classifications+0x114>
    30a4:      	cmp	x19, #0x19
    30a8:      	b.ne	0x30b4 <_stogir.verify.classifications+0x584>
    30ac:      	mov	x0, #0x1                ; =1
    30b0:      	b	0x2c44 <_stogir.verify.classifications+0x114>
    30b4:      	cmp	x21, #0xc
    30b8:      	b.eq	0x2c40 <_stogir.verify.classifications+0x110>
    30bc:      	cmp	x21, #0xd
    30c0:      	b.eq	0x2c40 <_stogir.verify.classifications+0x110>
    30c4:      	cmp	x28, #0xc
    30c8:      	b.ne	0x30e0 <_stogir.verify.classifications+0x5b0>
    30cc:      	mov	x0, #0x1                ; =1
    30d0:      	b	0x30ec <_stogir.verify.classifications+0x5bc>
    30d4:      	movz	x15, #0x0, lsl #48
    30d8:      	movz	x19, #0x0, lsl #48
    30dc:      	b	0x305c <_stogir.verify.classifications+0x52c>
    30e0:      	cmp	x28, #0xd
    30e4:      	cset	w0, eq
    30e8:      	ubfx	x0, x0, #0, #8
    30ec:      	b	0x2c44 <_stogir.verify.classifications+0x114>
    30f0:      	brk	#0
    30f4:      	b	0x30f0 <_stogir.verify.classifications+0x5c0>

00000000000030f8 <_stogir.vector-lanes.operation?>:
    30f8:      	sxtw	x0, w0
    30fc:      	cmp	x0, #0x3d
    3100:      	b.lt	0x3114 <_stogir.vector-lanes.operation?+0x1c>
    3104:      	cmp	x0, #0x3f
    3108:      	cset	w0, le
    310c:      	ubfx	x0, x0, #0, #8
    3110:      	b	0x3118 <_stogir.vector-lanes.operation?+0x20>
    3114:      	movz	x0, #0x0, lsl #48
    3118:      	ret
    311c:      	udf	#0x0

0000000000003120 <_stogir.vector.validate>:
    3120:      	sub	sp, sp, #0x210
    3124:      	str	x29, [sp]
    3128:      	str	x30, [sp, #0x8]
    312c:      	mov	x29, sp
    3130:      	str	x19, [sp, #0x1c0]
    3134:      	str	x20, [sp, #0x1c8]
    3138:      	str	x21, [sp, #0x1d0]
    313c:      	str	x22, [sp, #0x1d8]
    3140:      	str	x23, [sp, #0x1e0]
    3144:      	str	x24, [sp, #0x1e8]
    3148:      	str	x25, [sp, #0x1f0]
    314c:      	str	x26, [sp, #0x1f8]
    3150:      	str	x27, [sp, #0x200]
    3154:      	str	x28, [sp, #0x208]
    3158:      	lsr	w19, w1, #0
    315c:      	mov	x20, x8
    3160:      	add	x8, sp, #0x10
    3164:      	mov	x21, x0
    3168:      	mov	w22, w1
    316c:      	mov	w1, w19
    3170:      	mov	w23, w2
    3174:      	bl	0x3174 <_stogir.vector.validate+0x54>
		0000000000003174:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3178:      	add	x16, sp, #0x10
    317c:      	ldr	w0, [x16]
    3180:      	lsr	x16, x0, #0
    3184:      	cmp	x16, #0x1
    3188:      	b.eq	0x31a4 <_stogir.vector.validate+0x84>
    318c:      	b.lo	0x3194 <_stogir.vector.validate+0x74>
    3190:      	b	0x31a8 <_stogir.vector.validate+0x88>
    3194:      	cmp	x16, #0x0
    3198:      	b.eq	0x31a0 <_stogir.vector.validate+0x80>
    319c:      	b	0x31a8 <_stogir.vector.validate+0x88>
    31a0:      	b	0x31ac <_stogir.vector.validate+0x8c>
    31a4:      	b	0x3244 <_stogir.vector.validate+0x124>
    31a8:      	b	0x3464 <_stogir.vector.validate+0x344>
    31ac:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		00000000000031ac:  ARM64_RELOC_PAGE21	l_stogir.346
    31b0:      	ldr	x16, [x16]
		00000000000031b0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    31b4:      	orr	x0, x16, xzr
    31b8:      	str	x20, [sp, #0x1a8]
    31bc:      	mov	x1, x0
    31c0:      	mov	x0, #0x1                ; =1
    31c4:      	mov	x2, #0x1a               ; =26
    31c8:      	b	0x31fc <_stogir.vector.validate+0xdc>
    31cc:      	lsr	w23, w23, #0
    31d0:      	add	x8, sp, #0x70
    31d4:      	mov	x0, x21
    31d8:      	ldr	w1, [sp, #0x1a0]
    31dc:      	mov	w2, w23
    31e0:      	bl	0x31e0 <_stogir.vector.validate+0xc0>
		00000000000031e0:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    31e4:      	add	x16, sp, #0x70
    31e8:      	ldr	x0, [x16]
    31ec:      	add	x16, sp, #0x70
    31f0:      	ldr	x1, [x16, #0x8]
    31f4:      	add	x16, sp, #0x70
    31f8:      	ldr	x2, [x16, #0x10]
    31fc:      	ldr	x3, [sp, #0x1a8]
    3200:      	str	x0, [x3]
    3204:      	str	x1, [x3, #0x8]
    3208:      	str	x2, [x3, #0x10]
    320c:      	ldr	x19, [sp, #0x1c0]
    3210:      	ldr	x20, [sp, #0x1c8]
    3214:      	ldr	x21, [sp, #0x1d0]
    3218:      	ldr	x22, [sp, #0x1d8]
    321c:      	ldr	x23, [sp, #0x1e0]
    3220:      	ldr	x24, [sp, #0x1e8]
    3224:      	ldr	x25, [sp, #0x1f0]
    3228:      	ldr	x26, [sp, #0x1f8]
    322c:      	ldr	x27, [sp, #0x200]
    3230:      	ldr	x28, [sp, #0x208]
    3234:      	ldr	x29, [sp]
    3238:      	ldr	x30, [sp, #0x8]
    323c:      	add	sp, sp, #0x210
    3240:      	ret
    3244:      	sxtw	x22, w22
    3248:      	add	x16, sp, #0x10
    324c:      	orr	x0, x16, xzr
    3250:      	cmp	x22, #0x0
    3254:      	cset	w24, le
    3258:      	add	x0, x0, #0x8
    325c:      	add	x16, sp, #0x10
    3260:      	ldr	x25, [x16, #0x8]
    3264:      	add	x16, sp, #0x40
    3268:      	str	x25, [x16]
    326c:      	ldr	x0, [x0, #0x8]
    3270:      	add	x16, sp, #0x40
    3274:      	str	x0, [x16, #0x8]
    3278:      	uxtb	w16, w24
    327c:      	cmp	w16, wzr
    3280:      	b.eq	0x32a4 <_stogir.vector.validate+0x184>
    3284:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003284:  ARM64_RELOC_PAGE21	l_stogir.347
    3288:      	ldr	x16, [x16]
		0000000000003288:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    328c:      	orr	x0, x16, xzr
    3290:      	str	x20, [sp, #0x1a8]
    3294:      	mov	x1, x0
    3298:      	mov	x0, #0x1                ; =1
    329c:      	mov	x2, #0x3b               ; =59
    32a0:      	b	0x31fc <_stogir.vector.validate+0xdc>
    32a4:      	lsl	x26, x22, #2
    32a8:      	uxtb	w0, w25
    32ac:      	orr	x27, x0, xzr
    32b0:      	ldr	x0, [x21, #0x78]
    32b4:      	cmp	x27, #0x44
    32b8:      	cset	w1, eq
    32bc:      	add	x0, x0, x22, lsl #2
    32c0:      	ldr	w28, [x0]
    32c4:      	cmp	x27, #0x24
    32c8:      	b.ne	0x330c <_stogir.vector.validate+0x1ec>
    32cc:      	str	x20, [sp, #0x1a8]
    32d0:      	str	w19, [sp, #0x1a0]
    32d4:      	uxtb	w16, w1
    32d8:      	cmp	w16, wzr
    32dc:      	b.eq	0x31cc <_stogir.vector.validate+0xac>
    32e0:      	add	x8, sp, #0x50
    32e4:      	mov	x0, x21
    32e8:      	ldr	w1, [sp, #0x1a0]
    32ec:      	bl	0x32ec <_stogir.vector.validate+0x1cc>
		00000000000032ec:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    32f0:      	add	x16, sp, #0x50
    32f4:      	ldr	x0, [x16]
    32f8:      	add	x16, sp, #0x50
    32fc:      	ldr	x1, [x16, #0x8]
    3300:      	add	x16, sp, #0x50
    3304:      	ldr	x2, [x16, #0x10]
    3308:      	b	0x31fc <_stogir.vector.validate+0xdc>
    330c:      	uxtb	w16, w1
    3310:      	cmp	w16, wzr
    3314:      	b.ne	0x3bc0 <_stogir.vector.validate+0xaa0>
    3318:      	cmp	x27, #0x3c
    331c:      	b.ne	0x33d0 <_stogir.vector.validate+0x2b0>
    3320:      	add	x8, sp, #0x90
    3324:      	mov	x0, x21
    3328:      	mov	w1, w19
    332c:      	bl	0x332c <_stogir.vector.validate+0x20c>
		000000000000332c:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3330:      	add	x16, sp, #0x90
    3334:      	ldr	x0, [x16]
    3338:      	add	x16, sp, #0x90
    333c:      	ldr	x1, [x16, #0x8]
    3340:      	add	x16, sp, #0x90
    3344:      	ldr	x2, [x16, #0x10]
    3348:      	str	x20, [sp, #0x1a8]
    334c:      	b	0x33cc <_stogir.vector.validate+0x2ac>
    3350:      	cmp	x27, #0x41
    3354:      	cset	w0, eq
    3358:      	cmp	x27, #0x48
    335c:      	cset	w1, eq
    3360:      	cmp	x27, #0x55
    3364:      	cset	w2, ge
    3368:      	cmp	x27, #0x58
    336c:      	cset	w3, le
    3370:      	cmp	x27, #0x47
    3374:      	b.ne	0x346c <_stogir.vector.validate+0x34c>
    3378:      	str	x20, [sp, #0x1a8]
    337c:      	str	w19, [sp, #0x1a0]
    3380:      	mov	w19, w0
    3384:      	mov	w20, w1
    3388:      	str	w2, [sp, #0x1b0]
    338c:      	str	w3, [sp, #0x1b8]
    3390:      	mov	x0, x21
    3394:      	ldr	w1, [sp, #0x1a0]
    3398:      	bl	0x3398 <_stogir.vector.validate+0x278>
		0000000000003398:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    339c:      	cmp	x0, #0x0
    33a0:      	b.eq	0x3490 <_stogir.vector.validate+0x370>
    33a4:      	add	x8, sp, #0xf0
    33a8:      	mov	x0, x21
    33ac:      	ldr	w1, [sp, #0x1a0]
    33b0:      	bl	0x33b0 <_stogir.vector.validate+0x290>
		00000000000033b0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    33b4:      	add	x16, sp, #0xf0
    33b8:      	ldr	x0, [x16]
    33bc:      	add	x16, sp, #0xf0
    33c0:      	ldr	x1, [x16, #0x8]
    33c4:      	add	x16, sp, #0xf0
    33c8:      	ldr	x2, [x16, #0x10]
    33cc:      	b	0x31fc <_stogir.vector.validate+0xdc>
    33d0:      	cmp	x27, #0x3d
    33d4:      	b.lt	0x3418 <_stogir.vector.validate+0x2f8>
    33d8:      	cmp	x27, #0x3f
    33dc:      	b.gt	0x3418 <_stogir.vector.validate+0x2f8>
    33e0:      	lsr	w23, w23, #0
    33e4:      	add	x8, sp, #0xb0
    33e8:      	mov	x0, x21
    33ec:      	mov	w1, w19
    33f0:      	mov	w2, w23
    33f4:      	bl	0x33f4 <_stogir.vector.validate+0x2d4>
		00000000000033f4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    33f8:      	add	x16, sp, #0xb0
    33fc:      	ldr	x0, [x16]
    3400:      	add	x16, sp, #0xb0
    3404:      	ldr	x1, [x16, #0x8]
    3408:      	add	x16, sp, #0xb0
    340c:      	ldr	x2, [x16, #0x10]
    3410:      	str	x20, [sp, #0x1a8]
    3414:      	b	0x33cc <_stogir.vector.validate+0x2ac>
    3418:      	mov	x0, x21
    341c:      	mov	w1, w19
    3420:      	bl	0x3420 <_stogir.vector.validate+0x300>
		0000000000003420:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    3424:      	cmp	x0, #0x0
    3428:      	b.eq	0x3350 <_stogir.vector.validate+0x230>
    342c:      	lsr	w23, w23, #0
    3430:      	add	x8, sp, #0xd0
    3434:      	mov	x0, x21
    3438:      	mov	w1, w19
    343c:      	mov	w2, w23
    3440:      	bl	0x3440 <_stogir.vector.validate+0x320>
		0000000000003440:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    3444:      	add	x16, sp, #0xd0
    3448:      	ldr	x0, [x16]
    344c:      	add	x16, sp, #0xd0
    3450:      	ldr	x1, [x16, #0x8]
    3454:      	add	x16, sp, #0xd0
    3458:      	ldr	x2, [x16, #0x10]
    345c:      	str	x20, [sp, #0x1a8]
    3460:      	b	0x33cc <_stogir.vector.validate+0x2ac>
    3464:      	brk	#0
    3468:      	b	0x3464 <_stogir.vector.validate+0x344>
    346c:      	cmp	x27, #0x4f
    3470:      	b.ne	0x350c <_stogir.vector.validate+0x3ec>
    3474:      	str	x20, [sp, #0x1a8]
    3478:      	str	w19, [sp, #0x1a0]
    347c:      	mov	w19, w0
    3480:      	mov	w20, w1
    3484:      	str	w2, [sp, #0x1b0]
    3488:      	str	w3, [sp, #0x1b8]
    348c:      	b	0x3390 <_stogir.vector.validate+0x270>
    3490:      	uxtb	w16, w19
    3494:      	cmp	w16, wzr
    3498:      	b.ne	0x34d8 <_stogir.vector.validate+0x3b8>
    349c:      	uxtb	w16, w20
    34a0:      	cmp	w16, wzr
    34a4:      	b.ne	0x34d8 <_stogir.vector.validate+0x3b8>
    34a8:      	ldr	w0, [sp, #0x1b0]
    34ac:      	uxtb	w16, w0
    34b0:      	cmp	w16, wzr
    34b4:      	b.eq	0x34c8 <_stogir.vector.validate+0x3a8>
    34b8:      	ldr	w0, [sp, #0x1b8]
    34bc:      	uxtb	w16, w0
    34c0:      	cmp	w16, wzr
    34c4:      	b.ne	0x34d8 <_stogir.vector.validate+0x3b8>
    34c8:      	movz	x0, #0x0, lsl #48
    34cc:      	movz	x1, #0x0, lsl #48
    34d0:      	movz	x2, #0x0, lsl #48
    34d4:      	b	0x3508 <_stogir.vector.validate+0x3e8>
    34d8:      	lsr	w23, w23, #0
    34dc:      	add	x8, sp, #0x110
    34e0:      	mov	x0, x21
    34e4:      	ldr	w1, [sp, #0x1a0]
    34e8:      	mov	w2, w23
    34ec:      	bl	0x34ec <_stogir.vector.validate+0x3cc>
		00000000000034ec:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    34f0:      	add	x16, sp, #0x110
    34f4:      	ldr	x0, [x16]
    34f8:      	add	x16, sp, #0x110
    34fc:      	ldr	x1, [x16, #0x8]
    3500:      	add	x16, sp, #0x110
    3504:      	ldr	x2, [x16, #0x10]
    3508:      	b	0x33cc <_stogir.vector.validate+0x2ac>
    350c:      	cmp	x27, #0x50
    3510:      	b.eq	0x3bcc <_stogir.vector.validate+0xaac>
    3514:      	cmp	x27, #0x78
    3518:      	b.ne	0x3538 <_stogir.vector.validate+0x418>
    351c:      	str	x20, [sp, #0x1a8]
    3520:      	str	w19, [sp, #0x1a0]
    3524:      	mov	w19, w0
    3528:      	mov	w20, w1
    352c:      	str	w2, [sp, #0x1b0]
    3530:      	str	w3, [sp, #0x1b8]
    3534:      	b	0x3390 <_stogir.vector.validate+0x270>
    3538:      	uxtb	w16, w0
    353c:      	cmp	w16, wzr
    3540:      	b.ne	0x3640 <_stogir.vector.validate+0x520>
    3544:      	uxtb	w16, w1
    3548:      	cmp	w16, wzr
    354c:      	b.ne	0x3640 <_stogir.vector.validate+0x520>
    3550:      	uxtb	w16, w2
    3554:      	cmp	w16, wzr
    3558:      	b.eq	0x3568 <_stogir.vector.validate+0x448>
    355c:      	uxtb	w16, w3
    3560:      	cmp	w16, wzr
    3564:      	b.ne	0x3640 <_stogir.vector.validate+0x520>
    3568:      	str	w2, [sp, #0x1b0]
    356c:      	str	w3, [sp, #0x1b8]
    3570:      	str	w19, [sp, #0x1a0]
    3574:      	str	x20, [sp, #0x1a8]
    3578:      	mov	w20, w1
    357c:      	mov	w1, w19
    3580:      	mov	w19, w0
    3584:      	mov	x0, x21
    3588:      	bl	0x3588 <_stogir.vector.validate+0x468>
		0000000000003588:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    358c:      	cmp	x0, #0x0
    3590:      	b.ne	0x3390 <_stogir.vector.validate+0x270>
    3594:      	sxtw	x28, w28
    3598:      	lsr	w25, w25, #0
    359c:      	ubfx	x0, x25, #8, #8
    35a0:      	orr	x1, x0, xzr
    35a4:      	lsr	w19, w1, #0
    35a8:      	cmp	x27, #0x5b
    35ac:      	b.eq	0x3678 <_stogir.vector.validate+0x558>
    35b0:      	cmp	x27, #0x5c
    35b4:      	b.eq	0x3678 <_stogir.vector.validate+0x558>
    35b8:      	orr	x20, x0, xzr
    35bc:      	cmp	x27, #0x5d
    35c0:      	b.eq	0x36f0 <_stogir.vector.validate+0x5d0>
    35c4:      	cmp	x27, #0x5e
    35c8:      	b.eq	0x36f0 <_stogir.vector.validate+0x5d0>
    35cc:      	cmp	x27, #0x43
    35d0:      	b.ne	0x376c <_stogir.vector.validate+0x64c>
    35d4:      	cmp	x20, #0xf
    35d8:      	b.le	0x3a78 <_stogir.vector.validate+0x958>
    35dc:      	cmp	x20, #0x80
    35e0:      	b.ge	0x3a78 <_stogir.vector.validate+0x958>
    35e4:      	and	x0, x20, #0xf
    35e8:      	lsr	w0, w0, #0
    35ec:      	sxtw	x0, w0
    35f0:      	cmp	x0, #0x1
    35f4:      	b.lt	0x3a78 <_stogir.vector.validate+0x958>
    35f8:      	cmp	x0, #0xd
    35fc:      	b.gt	0x3a78 <_stogir.vector.validate+0x958>
    3600:      	lsr	w23, w23, #0
    3604:      	mov	w0, w19
    3608:      	mov	w1, w23
    360c:      	bl	0x360c <_stogir.vector.validate+0x4ec>
		000000000000360c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3610:      	lsr	w0, w0, #0
    3614:      	sxtw	x0, w0
    3618:      	cmp	x0, #0x0
    361c:      	b.le	0x3a78 <_stogir.vector.validate+0x958>
    3620:      	cmp	x28, #0x3
    3624:      	b.lt	0x3a78 <_stogir.vector.validate+0x958>
    3628:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003628:  ARM64_RELOC_PAGE21	l_stogir.348
    362c:      	ldr	x16, [x16]
		000000000000362c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    3630:      	orr	x0, x16, xzr
    3634:      	mov	x25, x0
    3638:      	movz	x27, #0x0, lsl #48
    363c:      	b	0x3a8c <_stogir.vector.validate+0x96c>
    3640:      	str	x20, [sp, #0x1a8]
    3644:      	str	w19, [sp, #0x1a0]
    3648:      	mov	w19, w0
    364c:      	mov	w20, w1
    3650:      	str	w2, [sp, #0x1b0]
    3654:      	str	w3, [sp, #0x1b8]
    3658:      	b	0x3390 <_stogir.vector.validate+0x270>
    365c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		000000000000365c:  ARM64_RELOC_PAGE21	l_stogir.349
    3660:      	ldr	x16, [x16]
		0000000000003660:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    3664:      	orr	x0, x16, xzr
    3668:      	mov	x1, x0
    366c:      	mov	x0, #0x1                ; =1
    3670:      	mov	x2, #0x19               ; =25
    3674:      	b	0x33cc <_stogir.vector.validate+0x2ac>
    3678:      	cmp	x28, #0x2
    367c:      	b.ne	0x365c <_stogir.vector.validate+0x53c>
    3680:      	lsr	w23, w23, #0
    3684:      	add	x16, sp, #0x40
    3688:      	ldr	w0, [x16, #0x4]
    368c:      	add	x16, sp, #0x40
    3690:      	ldr	w1, [x16, #0x8]
    3694:      	lsr	w0, w0, #0
    3698:      	lsr	w1, w1, #0
    369c:      	add	x8, sp, #0x130
    36a0:      	mov	w2, w23
    36a4:      	mov	w3, w0
    36a8:      	mov	x0, x21
    36ac:      	mov	w4, w1
    36b0:      	mov	w1, w19
    36b4:      	bl	0x36b4 <_stogir.vector.validate+0x594>
		00000000000036b4:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    36b8:      	add	x16, sp, #0x130
    36bc:      	ldr	x0, [x16]
    36c0:      	add	x16, sp, #0x130
    36c4:      	ldr	x1, [x16, #0x8]
    36c8:      	add	x16, sp, #0x130
    36cc:      	ldr	x2, [x16, #0x10]
    36d0:      	b	0x3674 <_stogir.vector.validate+0x554>
    36d4:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		00000000000036d4:  ARM64_RELOC_PAGE21	l_stogir.350
    36d8:      	ldr	x16, [x16]
		00000000000036d8:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    36dc:      	orr	x0, x16, xzr
    36e0:      	mov	x1, x0
    36e4:      	mov	x0, #0x1                ; =1
    36e8:      	mov	x2, #0x1a               ; =26
    36ec:      	b	0x3674 <_stogir.vector.validate+0x554>
    36f0:      	cmp	x28, #0x3
    36f4:      	b.ne	0x36d4 <_stogir.vector.validate+0x5b4>
    36f8:      	cmp	x20, #0x0
    36fc:      	b.ne	0x36d4 <_stogir.vector.validate+0x5b4>
    3700:      	lsr	w23, w23, #0
    3704:      	add	x16, sp, #0x40
    3708:      	ldr	w0, [x16, #0x4]
    370c:      	add	x16, sp, #0x40
    3710:      	ldr	w1, [x16, #0x8]
    3714:      	lsr	w0, w0, #0
    3718:      	add	x16, sp, #0x40
    371c:      	ldr	w2, [x16, #0xc]
    3720:      	lsr	w1, w1, #0
    3724:      	lsr	w2, w2, #0
    3728:      	add	x8, sp, #0x150
    372c:      	mov	w3, w1
    3730:      	mov	w1, w23
    3734:      	mov	w4, w2
    3738:      	mov	w2, w0
    373c:      	mov	x0, x21
    3740:      	bl	0x3740 <_stogir.vector.validate+0x620>
		0000000000003740:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    3744:      	add	x16, sp, #0x150
    3748:      	ldr	x0, [x16]
    374c:      	add	x16, sp, #0x150
    3750:      	ldr	x1, [x16, #0x8]
    3754:      	add	x16, sp, #0x150
    3758:      	ldr	x2, [x16, #0x10]
    375c:      	b	0x36ec <_stogir.vector.validate+0x5cc>
    3760:      	mov	x2, x8
    3764:      	mov	x0, #0x1                ; =1
    3768:      	b	0x36ec <_stogir.vector.validate+0x5cc>
    376c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		000000000000376c:  ARM64_RELOC_PAGE21	l_stogir.351
    3770:      	ldr	x16, [x16]
		0000000000003770:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3774:      	orr	x0, x16, xzr
    3778:      	mov	x1, x0
    377c:      	mov	x0, #0x1                ; =1
    3780:      	mov	x2, #0x28               ; =40
    3784:      	b	0x3768 <_stogir.vector.validate+0x648>
    3788:      	mov	x0, x1
    378c:      	mov	x1, x27
    3790:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003790:  ARM64_RELOC_PAGE21	l_stogir.352
    3794:      	ldr	x16, [x16]
		0000000000003794:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3798:      	orr	x2, x16, xzr
    379c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		000000000000379c:  ARM64_RELOC_PAGE21	l_stogir.353
    37a0:      	ldr	x16, [x16]
		00000000000037a0:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    37a4:      	orr	x3, x16, xzr
    37a8:      	add	x4, x21, #0x78
    37ac:      	add	x5, x21, #0x28
    37b0:      	add	x6, x21, #0x50
    37b4:      	add	x7, x21, #0x78
    37b8:      	mov	x8, x1
    37bc:      	mov	x1, x0
    37c0:      	mov	x0, #0x2                ; =2
    37c4:      	b	0x383c <_stogir.vector.validate+0x71c>
    37c8:      	lsr	w10, w10, #0
    37cc:      	ubfx	x9, x10, #8, #8
    37d0:      	cmp	x9, x20
    37d4:      	b.eq	0x37e0 <_stogir.vector.validate+0x6c0>
    37d8:      	mov	x1, x3
    37dc:      	mov	x8, #0x1e               ; =30
    37e0:      	b	0x3830 <_stogir.vector.validate+0x710>
    37e4:      	movz	x9, #0x0, lsl #48
    37e8:      	movz	x10, #0x0, lsl #48
    37ec:      	b	0x37f8 <_stogir.vector.validate+0x6d8>
    37f0:      	movz	x9, #0x0, lsl #48
    37f4:      	movz	x10, #0x0, lsl #48
    37f8:      	lsr	w9, w9, #0
    37fc:      	lsr	x16, x9, #0
    3800:      	cmp	x16, #0x1
    3804:      	b.eq	0x3820 <_stogir.vector.validate+0x700>
    3808:      	b.lo	0x3810 <_stogir.vector.validate+0x6f0>
    380c:      	b	0x3824 <_stogir.vector.validate+0x704>
    3810:      	cmp	x16, #0x0
    3814:      	b.eq	0x381c <_stogir.vector.validate+0x6fc>
    3818:      	b	0x3824 <_stogir.vector.validate+0x704>
    381c:      	b	0x3828 <_stogir.vector.validate+0x708>
    3820:      	b	0x3890 <_stogir.vector.validate+0x770>
    3824:      	b	0x3ba8 <_stogir.vector.validate+0xa88>
    3828:      	mov	x1, x2
    382c:      	mov	x8, #0x18               ; =24
    3830:      	add	x0, x0, #0x1
    3834:      	lsr	w0, w0, #0
    3838:      	sxtw	x0, w0
    383c:      	cmp	x8, #0x0
    3840:      	b.ne	0x39b8 <_stogir.vector.validate+0x898>
    3844:      	cmp	x0, x28
    3848:      	b.gt	0x39b8 <_stogir.vector.validate+0x898>
    384c:      	uxtb	w16, w24
    3850:      	cmp	w16, wzr
    3854:      	b.ne	0x37f0 <_stogir.vector.validate+0x6d0>
    3858:      	ldr	x9, [x21, #0x8]
    385c:      	cmp	x22, x9
    3860:      	b.ge	0x38f8 <_stogir.vector.validate+0x7d8>
    3864:      	ldr	x9, [x7, #0x8]
    3868:      	cmp	x22, x9
    386c:      	b.ge	0x38f0 <_stogir.vector.validate+0x7d0>
    3870:      	ldr	x9, [x21, #0x78]
    3874:      	add	x9, x26, x9
    3878:      	ldr	w9, [x9]
    387c:      	sxtw	x9, w9
    3880:      	cmp	x9, #0x0
    3884:      	cset	w9, ge
    3888:      	ubfx	x9, x9, #0, #8
    388c:      	b	0x38f4 <_stogir.vector.validate+0x7d4>
    3890:      	lsr	w10, w10, #0
    3894:      	sxtw	x10, w10
    3898:      	cmp	x10, #0x0
    389c:      	cset	w9, gt
    38a0:      	movz	x16, #0x0, lsl #48
    38a4:      	sub	x11, x16, x10
    38a8:      	sub	x12, x11, #0x1
    38ac:      	uxtb	w16, w9
    38b0:      	cmp	w16, wzr
    38b4:      	b.eq	0x3978 <_stogir.vector.validate+0x858>
    38b8:      	ldr	x11, [x21, #0x8]
    38bc:      	cmp	x10, x11
    38c0:      	b.ge	0x39ec <_stogir.vector.validate+0x8cc>
    38c4:      	ldr	x11, [x4, #0x8]
    38c8:      	cmp	x10, x11
    38cc:      	b.ge	0x3af8 <_stogir.vector.validate+0x9d8>
    38d0:      	ldr	x11, [x21, #0x78]
    38d4:      	add	x11, x11, x10, lsl #2
    38d8:      	ldr	w11, [x11]
    38dc:      	sxtw	x11, w11
    38e0:      	cmp	x11, #0x0
    38e4:      	cset	w11, ge
    38e8:      	ubfx	x11, x11, #0, #8
    38ec:      	b	0x3afc <_stogir.vector.validate+0x9dc>
    38f0:      	movz	x9, #0x0, lsl #48
    38f4:      	b	0x38fc <_stogir.vector.validate+0x7dc>
    38f8:      	movz	x9, #0x0, lsl #48
    38fc:      	cmp	x9, #0x0
    3900:      	b.eq	0x37f0 <_stogir.vector.validate+0x6d0>
    3904:      	lsr	w9, w0, #0
    3908:      	sxtw	x9, w9
    390c:      	cmp	x9, #0x1
    3910:      	b.lt	0x37e4 <_stogir.vector.validate+0x6c4>
    3914:      	ldr	x10, [x21, #0x78]
    3918:      	add	x10, x26, x10
    391c:      	ldr	w10, [x10]
    3920:      	sxtw	x10, w10
    3924:      	cmp	x9, x10
    3928:      	b.gt	0x37e4 <_stogir.vector.validate+0x6c4>
    392c:      	ldr	x10, [x21]
    3930:      	asr	x16, x9, #63
    3934:      	lsr	x16, x16, #62
    3938:      	add	x11, x9, x16
    393c:      	asr	x11, x11, #2
    3940:      	asr	x16, x9, #63
    3944:      	lsr	x16, x16, #62
    3948:      	add	x9, x9, x16
    394c:      	and	x9, x9, #0x3
    3950:      	sub	x9, x9, x16
    3954:      	add	x11, x11, x22
    3958:      	add	x10, x10, x11, lsl #4
    395c:      	add	x9, x10, x9, lsl #2
    3960:      	ldr	w9, [x9]
    3964:      	sxtw	x9, w9
    3968:      	and	x9, x9, #0xffffffff
    396c:      	mov	x10, x9
    3970:      	mov	x9, #0x1                ; =1
    3974:      	b	0x37ec <_stogir.vector.validate+0x6cc>
    3978:      	cmp	x10, #0x0
    397c:      	b.ge	0x39f4 <_stogir.vector.validate+0x8d4>
    3980:      	ldr	x13, [x5, #0x8]
    3984:      	ldr	x14, [x6, #0x8]
    3988:      	cmp	x13, x14
    398c:      	b.ne	0x3af0 <_stogir.vector.validate+0x9d0>
    3990:      	cmp	x11, x13
    3994:      	b.gt	0x3b28 <_stogir.vector.validate+0xa08>
    3998:      	ldr	x11, [x21, #0x50]
    399c:      	add	x11, x11, x12, lsl #2
    39a0:      	ldr	w11, [x11]
    39a4:      	sxtw	x11, w11
    39a8:      	cmp	x11, #0x0
    39ac:      	cset	w11, gt
    39b0:      	ubfx	x11, x11, #0, #8
    39b4:      	b	0x3b2c <_stogir.vector.validate+0xa0c>
    39b8:      	cmp	x8, #0x0
    39bc:      	b.ne	0x3760 <_stogir.vector.validate+0x640>
    39c0:      	lsr	w23, w23, #0
    39c4:      	mov	w0, w19
    39c8:      	mov	w1, w23
    39cc:      	bl	0x39cc <_stogir.vector.validate+0x8ac>
		00000000000039cc:  ARM64_RELOC_BRANCH26	_stogir.types.size
    39d0:      	lsr	w0, w0, #0
    39d4:      	sxtw	x0, w0
    39d8:      	and	x0, x0, #0xffffffff
    39dc:      	mov	x1, x0
    39e0:      	movz	x0, #0x0, lsl #48
    39e4:      	movz	x2, #0x0, lsl #48
    39e8:      	b	0x3768 <_stogir.vector.validate+0x648>
    39ec:      	movz	x11, #0x0, lsl #48
    39f0:      	b	0x39f8 <_stogir.vector.validate+0x8d8>
    39f4:      	movz	x11, #0x0, lsl #48
    39f8:      	cmp	x11, #0x0
    39fc:      	b.eq	0x3a34 <_stogir.vector.validate+0x914>
    3a00:      	uxtb	w16, w9
    3a04:      	cmp	w16, wzr
    3a08:      	b.eq	0x3a1c <_stogir.vector.validate+0x8fc>
    3a0c:      	ldr	x9, [x21]
    3a10:      	add	x9, x9, x10, lsl #4
    3a14:      	ldr	x9, [x9]
    3a18:      	b	0x3a28 <_stogir.vector.validate+0x908>
    3a1c:      	ldr	x9, [x21, #0x28]
    3a20:      	add	x9, x9, x12, lsl #4
    3a24:      	ldr	x9, [x9]
    3a28:      	mov	x10, x9
    3a2c:      	mov	x9, #0x1                ; =1
    3a30:      	b	0x3a3c <_stogir.vector.validate+0x91c>
    3a34:      	movz	x9, #0x0, lsl #48
    3a38:      	movz	x10, #0x0, lsl #48
    3a3c:      	lsr	w9, w9, #0
    3a40:      	lsr	x16, x9, #0
    3a44:      	cmp	x16, #0x1
    3a48:      	b.eq	0x3a64 <_stogir.vector.validate+0x944>
    3a4c:      	b.lo	0x3a54 <_stogir.vector.validate+0x934>
    3a50:      	b	0x3a68 <_stogir.vector.validate+0x948>
    3a54:      	cmp	x16, #0x0
    3a58:      	b.eq	0x3a60 <_stogir.vector.validate+0x940>
    3a5c:      	b	0x3a68 <_stogir.vector.validate+0x948>
    3a60:      	b	0x3a6c <_stogir.vector.validate+0x94c>
    3a64:      	b	0x37c8 <_stogir.vector.validate+0x6a8>
    3a68:      	b	0x3bb0 <_stogir.vector.validate+0xa90>
    3a6c:      	mov	x1, x2
    3a70:      	mov	x8, #0x18               ; =24
    3a74:      	b	0x37e0 <_stogir.vector.validate+0x6c0>
    3a78:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003a78:  ARM64_RELOC_PAGE21	l_stogir.354
    3a7c:      	ldr	x16, [x16]
		0000000000003a7c:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3a80:      	orr	x0, x16, xzr
    3a84:      	mov	x25, x0
    3a88:      	mov	x27, #0x20              ; =32
    3a8c:      	add	x16, sp, #0x40
    3a90:      	ldr	w0, [x16, #0x4]
    3a94:      	lsr	w0, w0, #0
    3a98:      	add	x8, sp, #0x170
    3a9c:      	mov	w1, w0
    3aa0:      	mov	x0, x21
    3aa4:      	bl	0x3aa4 <_stogir.vector.validate+0x984>
		0000000000003aa4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3aa8:      	add	x16, sp, #0x170
    3aac:      	ldr	w0, [x16]
    3ab0:      	lsr	x16, x0, #0
    3ab4:      	cmp	x16, #0x1
    3ab8:      	b.eq	0x3ad4 <_stogir.vector.validate+0x9b4>
    3abc:      	b.lo	0x3ac4 <_stogir.vector.validate+0x9a4>
    3ac0:      	b	0x3ad8 <_stogir.vector.validate+0x9b8>
    3ac4:      	cmp	x16, #0x0
    3ac8:      	b.eq	0x3ad0 <_stogir.vector.validate+0x9b0>
    3acc:      	b	0x3ad8 <_stogir.vector.validate+0x9b8>
    3ad0:      	b	0x3adc <_stogir.vector.validate+0x9bc>
    3ad4:      	b	0x3b00 <_stogir.vector.validate+0x9e0>
    3ad8:      	b	0x3bb8 <_stogir.vector.validate+0xa98>
    3adc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003adc:  ARM64_RELOC_PAGE21	l_stogir.355
    3ae0:      	ldr	x16, [x16]
		0000000000003ae0:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    3ae4:      	orr	x0, x16, xzr
    3ae8:      	mov	x1, #0x19               ; =25
    3aec:      	b	0x3790 <_stogir.vector.validate+0x670>
    3af0:      	movz	x11, #0x0, lsl #48
    3af4:      	b	0x39f8 <_stogir.vector.validate+0x8d8>
    3af8:      	movz	x11, #0x0, lsl #48
    3afc:      	b	0x39f0 <_stogir.vector.validate+0x8d0>
    3b00:      	add	x16, sp, #0x170
    3b04:      	ldr	x0, [x16, #0x8]
    3b08:      	add	x16, sp, #0x40
    3b0c:      	ldr	w1, [x16, #0x4]
    3b10:      	sxtw	x1, w1
    3b14:      	cmp	x1, #0x0
    3b18:      	b.gt	0x3b8c <_stogir.vector.validate+0xa6c>
    3b1c:      	mov	x1, x25
    3b20:      	mov	x0, #0x1                ; =1
    3b24:      	b	0x3b70 <_stogir.vector.validate+0xa50>
    3b28:      	movz	x11, #0x0, lsl #48
    3b2c:      	b	0x3af4 <_stogir.vector.validate+0x9d4>
    3b30:      	add	x16, sp, #0x40
    3b34:      	ldr	w0, [x16, #0x4]
    3b38:      	sxtw	x0, w0
    3b3c:      	ldr	x1, [x21, #0x78]
    3b40:      	add	x0, x1, x0, lsl #2
    3b44:      	ldr	w0, [x0]
    3b48:      	sxtw	x0, w0
    3b4c:      	add	x0, x0, #0x1
    3b50:      	lsr	w0, w0, #0
    3b54:      	sxtw	x0, w0
    3b58:      	cmp	x28, x0
    3b5c:      	cset	w0, eq
    3b60:      	uxtb	w16, w0
    3b64:      	cmp	w16, wzr
    3b68:      	cset	x0, eq
    3b6c:      	mov	x1, x25
    3b70:      	cmp	x0, #0x0
    3b74:      	b.eq	0x3788 <_stogir.vector.validate+0x668>
    3b78:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003b78:  ARM64_RELOC_PAGE21	l_stogir.356
    3b7c:      	ldr	x16, [x16]
		0000000000003b7c:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    3b80:      	orr	x0, x16, xzr
    3b84:      	mov	x1, #0x19               ; =25
    3b88:      	b	0x3790 <_stogir.vector.validate+0x670>
    3b8c:      	uxtb	w0, w0
    3b90:      	cmp	x0, #0x70
    3b94:      	b.eq	0x3b30 <_stogir.vector.validate+0xa10>
    3b98:      	cmp	x0, #0x71
    3b9c:      	b.eq	0x3b30 <_stogir.vector.validate+0xa10>
    3ba0:      	mov	x0, #0x1                ; =1
    3ba4:      	b	0x3b6c <_stogir.vector.validate+0xa4c>
    3ba8:      	brk	#0
    3bac:      	b	0x3ba8 <_stogir.vector.validate+0xa88>
    3bb0:      	brk	#0
    3bb4:      	b	0x3bb0 <_stogir.vector.validate+0xa90>
    3bb8:      	brk	#0
    3bbc:      	b	0x3bb8 <_stogir.vector.validate+0xa98>
    3bc0:      	str	x20, [sp, #0x1a8]
    3bc4:      	str	w19, [sp, #0x1a0]
    3bc8:      	b	0x32d4 <_stogir.vector.validate+0x1b4>
    3bcc:      	str	x20, [sp, #0x1a8]
    3bd0:      	str	w19, [sp, #0x1a0]
    3bd4:      	mov	w19, w0
    3bd8:      	mov	w20, w1
    3bdc:      	str	w2, [sp, #0x1b0]
    3be0:      	str	w3, [sp, #0x1b8]
    3be4:      	b	0x3390 <_stogir.vector.validate+0x270>

0000000000003be8 <_stogir.copy.validate>:
    3be8:      	sub	sp, sp, #0x10
    3bec:      	sxtw	x1, w1
    3bf0:      	lsl	x2, x1, #2
    3bf4:      	cmp	x1, #0x0
    3bf8:      	cset	w3, gt
    3bfc:      	movz	x16, #0x0, lsl #48
    3c00:      	sub	x4, x16, x1
    3c04:      	sub	x5, x4, #0x1
    3c08:      	uxtb	w16, w3
    3c0c:      	cmp	w16, wzr
    3c10:      	b.eq	0x3c50 <_stogir.copy.validate+0x68>
    3c14:      	ldr	x4, [x0, #0x8]
    3c18:      	cmp	x1, x4
    3c1c:      	b.ge	0x3cbc <_stogir.copy.validate+0xd4>
    3c20:      	add	x4, x0, #0x78
    3c24:      	ldr	x4, [x4, #0x8]
    3c28:      	cmp	x1, x4
    3c2c:      	b.ge	0x3e78 <_stogir.copy.validate+0x290>
    3c30:      	ldr	x4, [x0, #0x78]
    3c34:      	add	x4, x2, x4
    3c38:      	ldr	w4, [x4]
    3c3c:      	sxtw	x4, w4
    3c40:      	cmp	x4, #0x0
    3c44:      	cset	w4, ge
    3c48:      	ubfx	x4, x4, #0, #8
    3c4c:      	b	0x3e7c <_stogir.copy.validate+0x294>
    3c50:      	cmp	x1, #0x0
    3c54:      	b.ge	0x3cc4 <_stogir.copy.validate+0xdc>
    3c58:      	add	x6, x0, #0x28
    3c5c:      	add	x7, x0, #0x50
    3c60:      	ldr	x6, [x6, #0x8]
    3c64:      	ldr	x7, [x7, #0x8]
    3c68:      	cmp	x6, x7
    3c6c:      	b.ne	0x3c98 <_stogir.copy.validate+0xb0>
    3c70:      	cmp	x4, x6
    3c74:      	b.gt	0x3e80 <_stogir.copy.validate+0x298>
    3c78:      	ldr	x4, [x0, #0x50]
    3c7c:      	add	x4, x4, x5, lsl #2
    3c80:      	ldr	w4, [x4]
    3c84:      	sxtw	x4, w4
    3c88:      	cmp	x4, #0x0
    3c8c:      	cset	w4, gt
    3c90:      	ubfx	x4, x4, #0, #8
    3c94:      	b	0x3e84 <_stogir.copy.validate+0x29c>
    3c98:      	movz	x4, #0x0, lsl #48
    3c9c:      	b	0x3cc8 <_stogir.copy.validate+0xe0>
    3ca0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003ca0:  ARM64_RELOC_PAGE21	l_stogir.357
    3ca4:      	ldr	x16, [x16]
		0000000000003ca4:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    3ca8:      	orr	x0, x16, xzr
    3cac:      	mov	x1, x0
    3cb0:      	mov	x0, #0x1                ; =1
    3cb4:      	mov	x2, #0x21               ; =33
    3cb8:      	b	0x3d7c <_stogir.copy.validate+0x194>
    3cbc:      	movz	x4, #0x0, lsl #48
    3cc0:      	b	0x3cc8 <_stogir.copy.validate+0xe0>
    3cc4:      	movz	x4, #0x0, lsl #48
    3cc8:      	cmp	x4, #0x0
    3ccc:      	b.eq	0x3d28 <_stogir.copy.validate+0x140>
    3cd0:      	uxtb	w16, w3
    3cd4:      	cmp	w16, wzr
    3cd8:      	b.eq	0x3cfc <_stogir.copy.validate+0x114>
    3cdc:      	ldr	x3, [x0]
    3ce0:      	add	x3, x3, x1, lsl #4
    3ce4:      	ldr	x4, [x3]
    3ce8:      	ldr	x3, [x3, #0x8]
    3cec:      	fmov	d31, x3
    3cf0:      	mov	x3, x4
    3cf4:      	fmov	x4, d31
    3cf8:      	b	0x3d18 <_stogir.copy.validate+0x130>
    3cfc:      	ldr	x3, [x0, #0x28]
    3d00:      	add	x3, x3, x5, lsl #4
    3d04:      	ldr	x4, [x3]
    3d08:      	ldr	x3, [x3, #0x8]
    3d0c:      	fmov	d31, x3
    3d10:      	mov	x3, x4
    3d14:      	fmov	x4, d31
    3d18:      	mov	x5, x4
    3d1c:      	mov	x4, x3
    3d20:      	mov	x3, #0x1                ; =1
    3d24:      	b	0x3d34 <_stogir.copy.validate+0x14c>
    3d28:      	movz	x3, #0x0, lsl #48
    3d2c:      	movz	x4, #0x0, lsl #48
    3d30:      	movz	x5, #0x0, lsl #48
    3d34:      	lsr	w3, w3, #0
    3d38:      	lsr	x16, x3, #0
    3d3c:      	cmp	x16, #0x1
    3d40:      	b.eq	0x3d5c <_stogir.copy.validate+0x174>
    3d44:      	b.lo	0x3d4c <_stogir.copy.validate+0x164>
    3d48:      	b	0x3d60 <_stogir.copy.validate+0x178>
    3d4c:      	cmp	x16, #0x0
    3d50:      	b.eq	0x3d58 <_stogir.copy.validate+0x170>
    3d54:      	b	0x3d60 <_stogir.copy.validate+0x178>
    3d58:      	b	0x3d64 <_stogir.copy.validate+0x17c>
    3d5c:      	b	0x3d90 <_stogir.copy.validate+0x1a8>
    3d60:      	b	0x3e88 <_stogir.copy.validate+0x2a0>
    3d64:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003d64:  ARM64_RELOC_PAGE21	l_stogir.358
    3d68:      	ldr	x16, [x16]
		0000000000003d68:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    3d6c:      	orr	x0, x16, xzr
    3d70:      	mov	x1, x0
    3d74:      	mov	x0, #0x1                ; =1
    3d78:      	mov	x2, #0x18               ; =24
    3d7c:      	str	x0, [x8]
    3d80:      	str	x1, [x8, #0x8]
    3d84:      	str	x2, [x8, #0x10]
    3d88:      	add	sp, sp, #0x10
    3d8c:      	ret
    3d90:      	mov	x16, sp
    3d94:      	str	x4, [x16]
    3d98:      	mov	x16, sp
    3d9c:      	str	x5, [x16, #0x8]
    3da0:      	cmp	x1, #0x0
    3da4:      	b.le	0x3ca0 <_stogir.copy.validate+0xb8>
    3da8:      	uxtb	w1, w4
    3dac:      	cmp	x1, #0x44
    3db0:      	b.ne	0x3ca0 <_stogir.copy.validate+0xb8>
    3db4:      	ldr	x1, [x0, #0x78]
    3db8:      	add	x1, x2, x1
    3dbc:      	ldr	w1, [x1]
    3dc0:      	sxtw	x1, w1
    3dc4:      	cmp	x1, #0x2
    3dc8:      	b.ne	0x3ca0 <_stogir.copy.validate+0xb8>
    3dcc:      	lsr	w4, w4, #0
    3dd0:      	ubfx	x1, x4, #8, #8
    3dd4:      	cmp	x1, #0x0
    3dd8:      	b.eq	0x3ca0 <_stogir.copy.validate+0xb8>
    3ddc:      	cmp	x1, #0xd
    3de0:      	b.le	0x3e10 <_stogir.copy.validate+0x228>
    3de4:      	cmp	x1, #0xf
    3de8:      	b.le	0x3ca0 <_stogir.copy.validate+0xb8>
    3dec:      	cmp	x1, #0x80
    3df0:      	b.ge	0x3ca0 <_stogir.copy.validate+0xb8>
    3df4:      	and	x2, x1, #0xf
    3df8:      	lsr	w2, w2, #0
    3dfc:      	sxtw	x2, w2
    3e00:      	cmp	x2, #0x1
    3e04:      	b.lt	0x3ca0 <_stogir.copy.validate+0xb8>
    3e08:      	cmp	x2, #0xd
    3e0c:      	b.gt	0x3ca0 <_stogir.copy.validate+0xb8>
    3e10:      	mov	x16, sp
    3e14:      	ldr	w2, [x16, #0x4]
    3e18:      	sxtw	x2, w2
    3e1c:      	cmp	x2, #0x0
    3e20:      	cset	w3, gt
    3e24:      	movz	x16, #0x0, lsl #48
    3e28:      	sub	x4, x16, x2
    3e2c:      	sub	x5, x4, #0x1
    3e30:      	uxtb	w16, w3
    3e34:      	cmp	w16, wzr
    3e38:      	b.eq	0x3eac <_stogir.copy.validate+0x2c4>
    3e3c:      	ldr	x4, [x0, #0x8]
    3e40:      	cmp	x2, x4
    3e44:      	b.ge	0x3ef4 <_stogir.copy.validate+0x30c>
    3e48:      	add	x4, x0, #0x78
    3e4c:      	ldr	x4, [x4, #0x8]
    3e50:      	cmp	x2, x4
    3e54:      	b.ge	0x3fc8 <_stogir.copy.validate+0x3e0>
    3e58:      	ldr	x4, [x0, #0x78]
    3e5c:      	add	x4, x4, x2, lsl #2
    3e60:      	ldr	w4, [x4]
    3e64:      	sxtw	x4, w4
    3e68:      	cmp	x4, #0x0
    3e6c:      	cset	w4, ge
    3e70:      	ubfx	x4, x4, #0, #8
    3e74:      	b	0x3fcc <_stogir.copy.validate+0x3e4>
    3e78:      	movz	x4, #0x0, lsl #48
    3e7c:      	b	0x3cc0 <_stogir.copy.validate+0xd8>
    3e80:      	movz	x4, #0x0, lsl #48
    3e84:      	b	0x3c9c <_stogir.copy.validate+0xb4>
    3e88:      	brk	#0
    3e8c:      	b	0x3e88 <_stogir.copy.validate+0x2a0>
    3e90:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003e90:  ARM64_RELOC_PAGE21	l_stogir.359
    3e94:      	ldr	x16, [x16]
		0000000000003e94:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    3e98:      	orr	x0, x16, xzr
    3e9c:      	mov	x1, x0
    3ea0:      	mov	x0, #0x1                ; =1
    3ea4:      	mov	x2, #0x20               ; =32
    3ea8:      	b	0x3cb8 <_stogir.copy.validate+0xd0>
    3eac:      	cmp	x2, #0x0
    3eb0:      	b.ge	0x3efc <_stogir.copy.validate+0x314>
    3eb4:      	add	x6, x0, #0x28
    3eb8:      	add	x7, x0, #0x50
    3ebc:      	ldr	x6, [x6, #0x8]
    3ec0:      	ldr	x7, [x7, #0x8]
    3ec4:      	cmp	x6, x7
    3ec8:      	b.ne	0x3fc0 <_stogir.copy.validate+0x3d8>
    3ecc:      	cmp	x4, x6
    3ed0:      	b.gt	0x3fd0 <_stogir.copy.validate+0x3e8>
    3ed4:      	ldr	x4, [x0, #0x50]
    3ed8:      	add	x4, x4, x5, lsl #2
    3edc:      	ldr	w4, [x4]
    3ee0:      	sxtw	x4, w4
    3ee4:      	cmp	x4, #0x0
    3ee8:      	cset	w4, gt
    3eec:      	ubfx	x4, x4, #0, #8
    3ef0:      	b	0x3fd4 <_stogir.copy.validate+0x3ec>
    3ef4:      	movz	x4, #0x0, lsl #48
    3ef8:      	b	0x3f00 <_stogir.copy.validate+0x318>
    3efc:      	movz	x4, #0x0, lsl #48
    3f00:      	cmp	x4, #0x0
    3f04:      	b.eq	0x3f3c <_stogir.copy.validate+0x354>
    3f08:      	uxtb	w16, w3
    3f0c:      	cmp	w16, wzr
    3f10:      	b.eq	0x3f24 <_stogir.copy.validate+0x33c>
    3f14:      	ldr	x0, [x0]
    3f18:      	add	x0, x0, x2, lsl #4
    3f1c:      	ldr	x0, [x0]
    3f20:      	b	0x3f30 <_stogir.copy.validate+0x348>
    3f24:      	ldr	x0, [x0, #0x28]
    3f28:      	add	x0, x0, x5, lsl #4
    3f2c:      	ldr	x0, [x0]
    3f30:      	mov	x2, x0
    3f34:      	mov	x0, #0x1                ; =1
    3f38:      	b	0x3f44 <_stogir.copy.validate+0x35c>
    3f3c:      	movz	x0, #0x0, lsl #48
    3f40:      	movz	x2, #0x0, lsl #48
    3f44:      	lsr	w0, w0, #0
    3f48:      	lsr	x16, x0, #0
    3f4c:      	cmp	x16, #0x1
    3f50:      	b.eq	0x3f6c <_stogir.copy.validate+0x384>
    3f54:      	b.lo	0x3f5c <_stogir.copy.validate+0x374>
    3f58:      	b	0x3f70 <_stogir.copy.validate+0x388>
    3f5c:      	cmp	x16, #0x0
    3f60:      	b.eq	0x3f68 <_stogir.copy.validate+0x380>
    3f64:      	b	0x3f70 <_stogir.copy.validate+0x388>
    3f68:      	b	0x3f74 <_stogir.copy.validate+0x38c>
    3f6c:      	b	0x3f90 <_stogir.copy.validate+0x3a8>
    3f70:      	b	0x3fd8 <_stogir.copy.validate+0x3f0>
    3f74:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x4d0>
		0000000000003f74:  ARM64_RELOC_PAGE21	l_stogir.360
    3f78:      	ldr	x16, [x16]
		0000000000003f78:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    3f7c:      	orr	x0, x16, xzr
    3f80:      	mov	x1, x0
    3f84:      	mov	x0, #0x1                ; =1
    3f88:      	mov	x2, #0x13               ; =19
    3f8c:      	b	0x3ea8 <_stogir.copy.validate+0x2c0>
    3f90:      	lsr	w2, w2, #0
    3f94:      	mov	x16, sp
    3f98:      	ldr	w0, [x16]
    3f9c:      	ubfx	x2, x2, #8, #8
    3fa0:      	ubfx	x0, x0, #8, #8
    3fa4:      	cmp	x2, x0
    3fa8:      	b.ne	0x3e90 <_stogir.copy.validate+0x2a8>
    3fac:      	and	x0, x1, #0xffffffff
    3fb0:      	mov	x1, x0
    3fb4:      	movz	x0, #0x0, lsl #48
    3fb8:      	movz	x2, #0x0, lsl #48
    3fbc:      	b	0x3ea8 <_stogir.copy.validate+0x2c0>
    3fc0:      	movz	x4, #0x0, lsl #48
    3fc4:      	b	0x3f00 <_stogir.copy.validate+0x318>
    3fc8:      	movz	x4, #0x0, lsl #48
    3fcc:      	b	0x3ef8 <_stogir.copy.validate+0x310>
    3fd0:      	movz	x4, #0x0, lsl #48
    3fd4:      	b	0x3fc4 <_stogir.copy.validate+0x3dc>
    3fd8:      	brk	#0
    3fdc:      	b	0x3fd8 <_stogir.copy.validate+0x3f0>

0000000000003fe0 <_stogir.graph.lookup>:
    3fe0:      	sxtw	x1, w1
    3fe4:      	cmp	x1, #0x0
    3fe8:      	cset	w2, gt
    3fec:      	movz	x16, #0x0, lsl #48
    3ff0:      	sub	x3, x16, x1
    3ff4:      	sub	x4, x3, #0x1
    3ff8:      	uxtb	w16, w2
    3ffc:      	cmp	w16, wzr
    4000:      	b.eq	0x4040 <_stogir.graph.lookup+0x60>
    4004:      	ldr	x3, [x0, #0x8]
    4008:      	cmp	x1, x3
    400c:      	b.ge	0x4090 <_stogir.graph.lookup+0xb0>
    4010:      	add	x3, x0, #0x78
    4014:      	ldr	x3, [x3, #0x8]
    4018:      	cmp	x1, x3
    401c:      	b.ge	0x4128 <_stogir.graph.lookup+0x148>
    4020:      	ldr	x3, [x0, #0x78]
    4024:      	add	x3, x3, x1, lsl #2
    4028:      	ldr	w3, [x3]
    402c:      	sxtw	x3, w3
    4030:      	cmp	x3, #0x0
    4034:      	cset	w3, ge
    4038:      	ubfx	x3, x3, #0, #8
    403c:      	b	0x412c <_stogir.graph.lookup+0x14c>
    4040:      	cmp	x1, #0x0
    4044:      	b.ge	0x4098 <_stogir.graph.lookup+0xb8>
    4048:      	add	x5, x0, #0x28
    404c:      	add	x6, x0, #0x50
    4050:      	ldr	x5, [x5, #0x8]
    4054:      	ldr	x6, [x6, #0x8]
    4058:      	cmp	x5, x6
    405c:      	b.ne	0x4088 <_stogir.graph.lookup+0xa8>
    4060:      	cmp	x3, x5
    4064:      	b.gt	0x4130 <_stogir.graph.lookup+0x150>
    4068:      	ldr	x3, [x0, #0x50]
    406c:      	add	x3, x3, x4, lsl #2
    4070:      	ldr	w3, [x3]
    4074:      	sxtw	x3, w3
    4078:      	cmp	x3, #0x0
    407c:      	cset	w3, gt
    4080:      	ubfx	x3, x3, #0, #8
    4084:      	b	0x4134 <_stogir.graph.lookup+0x154>
    4088:      	movz	x3, #0x0, lsl #48
    408c:      	b	0x409c <_stogir.graph.lookup+0xbc>
    4090:      	movz	x3, #0x0, lsl #48
    4094:      	b	0x409c <_stogir.graph.lookup+0xbc>
    4098:      	movz	x3, #0x0, lsl #48
    409c:      	cmp	x3, #0x0
    40a0:      	b.eq	0x40fc <_stogir.graph.lookup+0x11c>
    40a4:      	uxtb	w16, w2
    40a8:      	cmp	w16, wzr
    40ac:      	b.eq	0x40d0 <_stogir.graph.lookup+0xf0>
    40b0:      	ldr	x0, [x0]
    40b4:      	add	x0, x0, x1, lsl #4
    40b8:      	ldr	x1, [x0]
    40bc:      	ldr	x0, [x0, #0x8]
    40c0:      	fmov	d31, x0
    40c4:      	mov	x0, x1
    40c8:      	fmov	x1, d31
    40cc:      	b	0x40ec <_stogir.graph.lookup+0x10c>
    40d0:      	ldr	x0, [x0, #0x28]
    40d4:      	add	x0, x0, x4, lsl #4
    40d8:      	ldr	x1, [x0]
    40dc:      	ldr	x0, [x0, #0x8]
    40e0:      	fmov	d31, x0
    40e4:      	mov	x0, x1
    40e8:      	fmov	x1, d31
    40ec:      	mov	x2, x1
    40f0:      	mov	x1, x0
    40f4:      	mov	x0, #0x1                ; =1
    40f8:      	b	0x4108 <_stogir.graph.lookup+0x128>
    40fc:      	movz	x0, #0x0, lsl #48
    4100:      	movz	x1, #0x0, lsl #48
    4104:      	movz	x2, #0x0, lsl #48
    4108:      	str	x0, [x8]
    410c:      	str	x1, [x8, #0x8]
    4110:      	str	x2, [x8, #0x10]
    4114:      	movz	x17, #0x0, lsl #48
    4118:      	str	x17, [x8, #0x18]
    411c:      	movz	x17, #0x0, lsl #48
    4120:      	str	x17, [x8, #0x20]
    4124:      	ret
    4128:      	movz	x3, #0x0, lsl #48
    412c:      	b	0x4094 <_stogir.graph.lookup+0xb4>
    4130:      	movz	x3, #0x0, lsl #48
    4134:      	b	0x408c <_stogir.graph.lookup+0xac>

0000000000004138 <_stogir.opcode.block-start?>:
    4138:      	sxtw	x0, w0
    413c:      	cmp	x0, #0x0
    4140:      	b.lt	0x4164 <_stogir.opcode.block-start?+0x2c>
    4144:      	cmp	x0, #0x83
    4148:      	b.ge	0x4164 <_stogir.opcode.block-start?+0x2c>
    414c:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		000000000000414c:  ARM64_RELOC_PAGE21	l_stogir.361
    4150:      	ldr	x16, [x16]
		0000000000004150:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4154:      	orr	x1, x16, xzr
    4158:      	add	x0, x1, x0
    415c:      	ldrb	w0, [x0]
    4160:      	b	0x4168 <_stogir.opcode.block-start?+0x30>
    4164:      	movz	x0, #0x0, lsl #48
    4168:      	uxtb	w0, w0
    416c:      	and	x0, x0, #0x2
    4170:      	uxtb	w0, w0
    4174:      	cmp	x0, #0x0
    4178:      	cset	w0, eq
    417c:      	uxtb	w16, w0
    4180:      	cmp	w16, wzr
    4184:      	cset	x0, eq
    4188:      	ret

000000000000418c <_stogir.checked.operation?>:
    418c:      	sxtw	x0, w0
    4190:      	cmp	x0, #0x29
    4194:      	b.lt	0x41a8 <_stogir.checked.operation?+0x1c>
    4198:      	cmp	x0, #0x2b
    419c:      	cset	w0, le
    41a0:      	ubfx	x0, x0, #0, #8
    41a4:      	b	0x41ac <_stogir.checked.operation?+0x20>
    41a8:      	movz	x0, #0x0, lsl #48
    41ac:      	ret

00000000000041b0 <_stogir.checked.validate-projection>:
    41b0:      	sub	sp, sp, #0x40
    41b4:      	str	x29, [sp]
    41b8:      	str	x30, [sp, #0x8]
    41bc:      	mov	x29, sp
    41c0:      	str	x19, [sp, #0x30]
    41c4:      	sxtw	x1, w1
    41c8:      	lsl	x2, x1, #2
    41cc:      	cmp	x1, #0x0
    41d0:      	cset	w3, gt
    41d4:      	movz	x16, #0x0, lsl #48
    41d8:      	sub	x4, x16, x1
    41dc:      	sub	x5, x4, #0x1
    41e0:      	uxtb	w16, w3
    41e4:      	cmp	w16, wzr
    41e8:      	b.eq	0x4228 <_stogir.checked.validate-projection+0x78>
    41ec:      	ldr	x4, [x0, #0x8]
    41f0:      	cmp	x1, x4
    41f4:      	b.ge	0x4278 <_stogir.checked.validate-projection+0xc8>
    41f8:      	add	x4, x0, #0x78
    41fc:      	ldr	x4, [x4, #0x8]
    4200:      	cmp	x1, x4
    4204:      	b.ge	0x435c <_stogir.checked.validate-projection+0x1ac>
    4208:      	ldr	x4, [x0, #0x78]
    420c:      	add	x4, x2, x4
    4210:      	ldr	w4, [x4]
    4214:      	sxtw	x4, w4
    4218:      	cmp	x4, #0x0
    421c:      	cset	w4, ge
    4220:      	ubfx	x4, x4, #0, #8
    4224:      	b	0x4360 <_stogir.checked.validate-projection+0x1b0>
    4228:      	cmp	x1, #0x0
    422c:      	b.ge	0x4280 <_stogir.checked.validate-projection+0xd0>
    4230:      	add	x6, x0, #0x28
    4234:      	add	x7, x0, #0x50
    4238:      	ldr	x6, [x6, #0x8]
    423c:      	ldr	x7, [x7, #0x8]
    4240:      	cmp	x6, x7
    4244:      	b.ne	0x4270 <_stogir.checked.validate-projection+0xc0>
    4248:      	cmp	x4, x6
    424c:      	b.gt	0x43c8 <_stogir.checked.validate-projection+0x218>
    4250:      	ldr	x4, [x0, #0x50]
    4254:      	add	x4, x4, x5, lsl #2
    4258:      	ldr	w4, [x4]
    425c:      	sxtw	x4, w4
    4260:      	cmp	x4, #0x0
    4264:      	cset	w4, gt
    4268:      	ubfx	x4, x4, #0, #8
    426c:      	b	0x43cc <_stogir.checked.validate-projection+0x21c>
    4270:      	movz	x4, #0x0, lsl #48
    4274:      	b	0x4284 <_stogir.checked.validate-projection+0xd4>
    4278:      	movz	x4, #0x0, lsl #48
    427c:      	b	0x4284 <_stogir.checked.validate-projection+0xd4>
    4280:      	movz	x4, #0x0, lsl #48
    4284:      	cmp	x4, #0x0
    4288:      	b.eq	0x42c0 <_stogir.checked.validate-projection+0x110>
    428c:      	uxtb	w16, w3
    4290:      	cmp	w16, wzr
    4294:      	b.eq	0x42a8 <_stogir.checked.validate-projection+0xf8>
    4298:      	ldr	x3, [x0]
    429c:      	add	x3, x3, x1, lsl #4
    42a0:      	ldr	x3, [x3]
    42a4:      	b	0x42b4 <_stogir.checked.validate-projection+0x104>
    42a8:      	ldr	x3, [x0, #0x28]
    42ac:      	add	x3, x3, x5, lsl #4
    42b0:      	ldr	x3, [x3]
    42b4:      	mov	x4, x3
    42b8:      	mov	x3, #0x1                ; =1
    42bc:      	b	0x42c8 <_stogir.checked.validate-projection+0x118>
    42c0:      	movz	x3, #0x0, lsl #48
    42c4:      	movz	x4, #0x0, lsl #48
    42c8:      	lsr	w3, w3, #0
    42cc:      	lsr	x16, x3, #0
    42d0:      	cmp	x16, #0x1
    42d4:      	b.eq	0x42f0 <_stogir.checked.validate-projection+0x140>
    42d8:      	b.lo	0x42e0 <_stogir.checked.validate-projection+0x130>
    42dc:      	b	0x42f4 <_stogir.checked.validate-projection+0x144>
    42e0:      	cmp	x16, #0x0
    42e4:      	b.eq	0x42ec <_stogir.checked.validate-projection+0x13c>
    42e8:      	b	0x42f4 <_stogir.checked.validate-projection+0x144>
    42ec:      	b	0x42f8 <_stogir.checked.validate-projection+0x148>
    42f0:      	b	0x4318 <_stogir.checked.validate-projection+0x168>
    42f4:      	b	0x43d0 <_stogir.checked.validate-projection+0x220>
    42f8:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		00000000000042f8:  ARM64_RELOC_PAGE21	l_stogir.362
    42fc:      	ldr	x16, [x16]
		00000000000042fc:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    4300:      	orr	x0, x16, xzr
    4304:      	mov	x19, x8
    4308:      	mov	x1, x0
    430c:      	mov	x0, #0x1                ; =1
    4310:      	mov	x2, #0x10               ; =16
    4314:      	b	0x433c <_stogir.checked.validate-projection+0x18c>
    4318:      	cmp	x1, #0x0
    431c:      	b.gt	0x4364 <_stogir.checked.validate-projection+0x1b4>
    4320:      	mov	x19, x8
    4324:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004324:  ARM64_RELOC_PAGE21	l_stogir.363
    4328:      	ldr	x16, [x16]
		0000000000004328:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    432c:      	orr	x0, x16, xzr
    4330:      	mov	x1, x0
    4334:      	mov	x0, #0x1                ; =1
    4338:      	mov	x2, #0x1c               ; =28
    433c:      	str	x0, [x19]
    4340:      	str	x1, [x19, #0x8]
    4344:      	str	x2, [x19, #0x10]
    4348:      	ldr	x19, [sp, #0x30]
    434c:      	ldr	x29, [sp]
    4350:      	ldr	x30, [sp, #0x8]
    4354:      	add	sp, sp, #0x40
    4358:      	ret
    435c:      	movz	x4, #0x0, lsl #48
    4360:      	b	0x427c <_stogir.checked.validate-projection+0xcc>
    4364:      	uxtb	w1, w4
    4368:      	cmp	x1, #0x2c
    436c:      	b.ne	0x43d8 <_stogir.checked.validate-projection+0x228>
    4370:      	lsr	w1, w4, #0
    4374:      	ubfx	x1, x1, #8, #8
    4378:      	cmp	x1, #0x1
    437c:      	b.ne	0x43e0 <_stogir.checked.validate-projection+0x230>
    4380:      	ldr	x1, [x0, #0x78]
    4384:      	add	x1, x2, x1
    4388:      	ldr	w1, [x1]
    438c:      	sxtw	x1, w1
    4390:      	cmp	x1, #0x1
    4394:      	b.ne	0x43e8 <_stogir.checked.validate-projection+0x238>
    4398:      	lsr	x1, x4, #32
    439c:      	lsr	w1, w1, #0
    43a0:      	mov	x19, x8
    43a4:      	add	x8, sp, #0x10
    43a8:      	bl	0x43a8 <_stogir.checked.validate-projection+0x1f8>
		00000000000043a8:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    43ac:      	add	x16, sp, #0x10
    43b0:      	ldr	x0, [x16]
    43b4:      	add	x16, sp, #0x10
    43b8:      	ldr	x1, [x16, #0x8]
    43bc:      	add	x16, sp, #0x10
    43c0:      	ldr	x2, [x16, #0x10]
    43c4:      	b	0x433c <_stogir.checked.validate-projection+0x18c>
    43c8:      	movz	x4, #0x0, lsl #48
    43cc:      	b	0x4274 <_stogir.checked.validate-projection+0xc4>
    43d0:      	brk	#0
    43d4:      	b	0x43d0 <_stogir.checked.validate-projection+0x220>
    43d8:      	mov	x19, x8
    43dc:      	b	0x4324 <_stogir.checked.validate-projection+0x174>
    43e0:      	mov	x19, x8
    43e4:      	b	0x4324 <_stogir.checked.validate-projection+0x174>
    43e8:      	mov	x19, x8
    43ec:      	b	0x4324 <_stogir.checked.validate-projection+0x174>

00000000000043f0 <_stogir.checked.validate>:
    43f0:      	sub	sp, sp, #0x30
    43f4:      	str	x29, [sp]
    43f8:      	str	x30, [sp, #0x8]
    43fc:      	mov	x29, sp
    4400:      	str	x19, [sp, #0x10]
    4404:      	str	x20, [sp, #0x18]
    4408:      	str	x21, [sp, #0x20]
    440c:      	sxtw	x1, w1
    4410:      	lsl	x2, x1, #2
    4414:      	cmp	x1, #0x0
    4418:      	cset	w3, gt
    441c:      	movz	x16, #0x0, lsl #48
    4420:      	sub	x4, x16, x1
    4424:      	sub	x5, x4, #0x1
    4428:      	uxtb	w16, w3
    442c:      	cmp	w16, wzr
    4430:      	b.eq	0x4470 <_stogir.checked.validate+0x80>
    4434:      	ldr	x4, [x0, #0x8]
    4438:      	cmp	x1, x4
    443c:      	b.ge	0x44c0 <_stogir.checked.validate+0xd0>
    4440:      	add	x4, x0, #0x78
    4444:      	ldr	x4, [x4, #0x8]
    4448:      	cmp	x1, x4
    444c:      	b.ge	0x4644 <_stogir.checked.validate+0x254>
    4450:      	ldr	x4, [x0, #0x78]
    4454:      	add	x4, x2, x4
    4458:      	ldr	w4, [x4]
    445c:      	sxtw	x4, w4
    4460:      	cmp	x4, #0x0
    4464:      	cset	w4, ge
    4468:      	ubfx	x4, x4, #0, #8
    446c:      	b	0x4648 <_stogir.checked.validate+0x258>
    4470:      	cmp	x1, #0x0
    4474:      	b.ge	0x44c8 <_stogir.checked.validate+0xd8>
    4478:      	add	x6, x0, #0x28
    447c:      	add	x7, x0, #0x50
    4480:      	ldr	x6, [x6, #0x8]
    4484:      	ldr	x7, [x7, #0x8]
    4488:      	cmp	x6, x7
    448c:      	b.ne	0x44b8 <_stogir.checked.validate+0xc8>
    4490:      	cmp	x4, x6
    4494:      	b.gt	0x464c <_stogir.checked.validate+0x25c>
    4498:      	ldr	x4, [x0, #0x50]
    449c:      	add	x4, x4, x5, lsl #2
    44a0:      	ldr	w4, [x4]
    44a4:      	sxtw	x4, w4
    44a8:      	cmp	x4, #0x0
    44ac:      	cset	w4, gt
    44b0:      	ubfx	x4, x4, #0, #8
    44b4:      	b	0x4650 <_stogir.checked.validate+0x260>
    44b8:      	movz	x4, #0x0, lsl #48
    44bc:      	b	0x44cc <_stogir.checked.validate+0xdc>
    44c0:      	movz	x4, #0x0, lsl #48
    44c4:      	b	0x44cc <_stogir.checked.validate+0xdc>
    44c8:      	movz	x4, #0x0, lsl #48
    44cc:      	cmp	x4, #0x0
    44d0:      	b.eq	0x452c <_stogir.checked.validate+0x13c>
    44d4:      	uxtb	w16, w3
    44d8:      	cmp	w16, wzr
    44dc:      	b.eq	0x4500 <_stogir.checked.validate+0x110>
    44e0:      	ldr	x3, [x0]
    44e4:      	add	x3, x3, x1, lsl #4
    44e8:      	ldr	x4, [x3]
    44ec:      	ldr	x3, [x3, #0x8]
    44f0:      	fmov	d31, x3
    44f4:      	mov	x3, x4
    44f8:      	fmov	x4, d31
    44fc:      	b	0x451c <_stogir.checked.validate+0x12c>
    4500:      	ldr	x3, [x0, #0x28]
    4504:      	add	x3, x3, x5, lsl #4
    4508:      	ldr	x4, [x3]
    450c:      	ldr	x3, [x3, #0x8]
    4510:      	fmov	d31, x3
    4514:      	mov	x3, x4
    4518:      	fmov	x4, d31
    451c:      	mov	x5, x4
    4520:      	mov	x4, x3
    4524:      	mov	x3, #0x1                ; =1
    4528:      	b	0x4538 <_stogir.checked.validate+0x148>
    452c:      	movz	x3, #0x0, lsl #48
    4530:      	movz	x4, #0x0, lsl #48
    4534:      	movz	x5, #0x0, lsl #48
    4538:      	lsr	w3, w3, #0
    453c:      	lsr	x16, x3, #0
    4540:      	cmp	x16, #0x1
    4544:      	b.eq	0x4560 <_stogir.checked.validate+0x170>
    4548:      	b.lo	0x4550 <_stogir.checked.validate+0x160>
    454c:      	b	0x4564 <_stogir.checked.validate+0x174>
    4550:      	cmp	x16, #0x0
    4554:      	b.eq	0x455c <_stogir.checked.validate+0x16c>
    4558:      	b	0x4564 <_stogir.checked.validate+0x174>
    455c:      	b	0x4568 <_stogir.checked.validate+0x178>
    4560:      	b	0x45c8 <_stogir.checked.validate+0x1d8>
    4564:      	b	0x48b0 <_stogir.checked.validate+0x4c0>
    4568:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004568:  ARM64_RELOC_PAGE21	l_stogir.364
    456c:      	ldr	x16, [x16]
		000000000000456c:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4570:      	orr	x0, x16, xzr
    4574:      	mov	x1, x0
    4578:      	mov	x0, #0x1                ; =1
    457c:      	mov	x2, #0x1a               ; =26
    4580:      	b	0x459c <_stogir.checked.validate+0x1ac>
    4584:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004584:  ARM64_RELOC_PAGE21	l_stogir.365
    4588:      	ldr	x16, [x16]
		0000000000004588:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    458c:      	orr	x0, x16, xzr
    4590:      	mov	x1, x0
    4594:      	mov	x0, #0x1                ; =1
    4598:      	mov	x2, #0x26               ; =38
    459c:      	str	x0, [x8]
    45a0:      	str	x1, [x8, #0x8]
    45a4:      	str	x2, [x8, #0x10]
    45a8:      	sub	sp, x29, #0x0
    45ac:      	ldr	x19, [sp, #0x10]
    45b0:      	ldr	x20, [sp, #0x18]
    45b4:      	ldr	x21, [sp, #0x20]
    45b8:      	ldr	x29, [sp]
    45bc:      	ldr	x30, [sp, #0x8]
    45c0:      	add	sp, sp, #0x30
    45c4:      	ret
    45c8:      	cmp	x1, #0x0
    45cc:      	b.le	0x4584 <_stogir.checked.validate+0x194>
    45d0:      	uxtb	w1, w4
    45d4:      	cmp	x1, #0x29
    45d8:      	b.lt	0x4584 <_stogir.checked.validate+0x194>
    45dc:      	cmp	x1, #0x2b
    45e0:      	b.gt	0x4584 <_stogir.checked.validate+0x194>
    45e4:      	ldr	x1, [x0, #0x78]
    45e8:      	add	x1, x2, x1
    45ec:      	ldr	w1, [x1]
    45f0:      	sxtw	x1, w1
    45f4:      	cmp	x1, #0x2
    45f8:      	b.ne	0x4584 <_stogir.checked.validate+0x194>
    45fc:      	lsr	w1, w4, #0
    4600:      	mov	x2, sp
    4604:      	sub	sp, sp, #0x10
    4608:      	mov	x3, sp
    460c:      	sub	sp, sp, #0x10
    4610:      	mov	x6, sp
    4614:      	ubfx	x1, x1, #8, #8
    4618:      	cmp	x1, #0x1
    461c:      	b.lt	0x4838 <_stogir.checked.validate+0x448>
    4620:      	cmp	x1, #0xb
    4624:      	b.gt	0x4838 <_stogir.checked.validate+0x448>
    4628:      	cmp	x1, #0x1
    462c:      	b.eq	0x4838 <_stogir.checked.validate+0x448>
    4630:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004630:  ARM64_RELOC_PAGE21	l_stogir.366
    4634:      	ldr	x16, [x16]
		0000000000004634:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4638:      	orr	x7, x16, xzr
    463c:      	movz	x9, #0x0, lsl #48
    4640:      	b	0x4848 <_stogir.checked.validate+0x458>
    4644:      	movz	x4, #0x0, lsl #48
    4648:      	b	0x44c4 <_stogir.checked.validate+0xd4>
    464c:      	movz	x4, #0x0, lsl #48
    4650:      	b	0x44bc <_stogir.checked.validate+0xcc>
    4654:      	mov	x1, x3
    4658:      	mov	x3, x4
    465c:      	mov	x0, #0x1                ; =1
    4660:      	mov	sp, x2
    4664:      	mov	x2, x3
    4668:      	b	0x459c <_stogir.checked.validate+0x1ac>
    466c:      	movz	x5, #0x0, lsl #48
    4670:      	movz	x6, #0x0, lsl #48
    4674:      	lsr	w5, w5, #0
    4678:      	lsr	x16, x5, #0
    467c:      	cmp	x16, #0x1
    4680:      	b.eq	0x469c <_stogir.checked.validate+0x2ac>
    4684:      	b.lo	0x468c <_stogir.checked.validate+0x29c>
    4688:      	b	0x46a0 <_stogir.checked.validate+0x2b0>
    468c:      	cmp	x16, #0x0
    4690:      	b.eq	0x4698 <_stogir.checked.validate+0x2a8>
    4694:      	b	0x46a0 <_stogir.checked.validate+0x2b0>
    4698:      	b	0x46a4 <_stogir.checked.validate+0x2b4>
    469c:      	b	0x481c <_stogir.checked.validate+0x42c>
    46a0:      	b	0x48c8 <_stogir.checked.validate+0x4d8>
    46a4:      	mov	x3, x11
    46a8:      	mov	x4, #0x22               ; =34
    46ac:      	mov	x5, x7
    46b0:      	cmp	x5, #0x2
    46b4:      	b.ge	0x46dc <_stogir.checked.validate+0x2ec>
    46b8:      	add	x6, x5, #0x1
    46bc:      	add	x5, x10, x5, lsl #2
    46c0:      	ldr	w5, [x5]
    46c4:      	sxtw	x5, w5
    46c8:      	and	x5, x5, #0xffffffff
    46cc:      	mov	x7, x6
    46d0:      	mov	x6, x5
    46d4:      	mov	x5, #0x1                ; =1
    46d8:      	b	0x46e8 <_stogir.checked.validate+0x2f8>
    46dc:      	mov	x7, x5
    46e0:      	movz	x5, #0x0, lsl #48
    46e4:      	movz	x6, #0x0, lsl #48
    46e8:      	lsr	w5, w5, #0
    46ec:      	lsr	x16, x5, #0
    46f0:      	cmp	x16, #0x1
    46f4:      	b.eq	0x4710 <_stogir.checked.validate+0x320>
    46f8:      	b.lo	0x4700 <_stogir.checked.validate+0x310>
    46fc:      	b	0x4714 <_stogir.checked.validate+0x324>
    4700:      	cmp	x16, #0x0
    4704:      	b.eq	0x470c <_stogir.checked.validate+0x31c>
    4708:      	b	0x4714 <_stogir.checked.validate+0x324>
    470c:      	b	0x4778 <_stogir.checked.validate+0x388>
    4710:      	b	0x4718 <_stogir.checked.validate+0x328>
    4714:      	b	0x48c0 <_stogir.checked.validate+0x4d0>
    4718:      	lsr	w6, w6, #0
    471c:      	sxtw	x6, w6
    4720:      	cmp	x6, #0x0
    4724:      	cset	w5, gt
    4728:      	movz	x16, #0x0, lsl #48
    472c:      	sub	x9, x16, x6
    4730:      	sub	x19, x9, #0x1
    4734:      	uxtb	w16, w5
    4738:      	cmp	w16, wzr
    473c:      	b.eq	0x47dc <_stogir.checked.validate+0x3ec>
    4740:      	ldr	x9, [x0, #0x8]
    4744:      	cmp	x6, x9
    4748:      	b.ge	0x47d4 <_stogir.checked.validate+0x3e4>
    474c:      	ldr	x9, [x13, #0x8]
    4750:      	cmp	x6, x9
    4754:      	b.ge	0x48a8 <_stogir.checked.validate+0x4b8>
    4758:      	ldr	x9, [x0, #0x78]
    475c:      	add	x9, x9, x6, lsl #2
    4760:      	ldr	w9, [x9]
    4764:      	sxtw	x9, w9
    4768:      	cmp	x9, #0x0
    476c:      	cset	w9, ge
    4770:      	ubfx	x9, x9, #0, #8
    4774:      	b	0x48ac <_stogir.checked.validate+0x4bc>
    4778:      	cmp	x4, #0x0
    477c:      	b.ne	0x4654 <_stogir.checked.validate+0x264>
    4780:      	and	x0, x1, #0xffffffff
    4784:      	mov	x1, x0
    4788:      	movz	x0, #0x0, lsl #48
    478c:      	movz	x3, #0x0, lsl #48
    4790:      	b	0x4660 <_stogir.checked.validate+0x270>
    4794:      	ldr	x5, [x0, #0x28]
    4798:      	add	x5, x5, x19, lsl #4
    479c:      	ldr	x5, [x5]
    47a0:      	mov	x6, x5
    47a4:      	mov	x5, #0x1                ; =1
    47a8:      	b	0x4674 <_stogir.checked.validate+0x284>
    47ac:      	movz	x9, #0x0, lsl #48
    47b0:      	cmp	x9, #0x0
    47b4:      	b.eq	0x466c <_stogir.checked.validate+0x27c>
    47b8:      	uxtb	w16, w5
    47bc:      	cmp	w16, wzr
    47c0:      	b.eq	0x4794 <_stogir.checked.validate+0x3a4>
    47c4:      	ldr	x5, [x0]
    47c8:      	add	x5, x5, x6, lsl #4
    47cc:      	ldr	x5, [x5]
    47d0:      	b	0x47a0 <_stogir.checked.validate+0x3b0>
    47d4:      	movz	x9, #0x0, lsl #48
    47d8:      	b	0x47b0 <_stogir.checked.validate+0x3c0>
    47dc:      	cmp	x6, #0x0
    47e0:      	b.ge	0x47ac <_stogir.checked.validate+0x3bc>
    47e4:      	ldr	x20, [x14, #0x8]
    47e8:      	ldr	x21, [x15, #0x8]
    47ec:      	cmp	x20, x21
    47f0:      	b.ne	0x48a0 <_stogir.checked.validate+0x4b0>
    47f4:      	cmp	x9, x20
    47f8:      	b.gt	0x48b8 <_stogir.checked.validate+0x4c8>
    47fc:      	ldr	x9, [x0, #0x50]
    4800:      	add	x9, x9, x19, lsl #2
    4804:      	ldr	w9, [x9]
    4808:      	sxtw	x9, w9
    480c:      	cmp	x9, #0x0
    4810:      	cset	w9, gt
    4814:      	ubfx	x9, x9, #0, #8
    4818:      	b	0x48bc <_stogir.checked.validate+0x4cc>
    481c:      	lsr	w6, w6, #0
    4820:      	ubfx	x5, x6, #8, #8
    4824:      	cmp	x5, x1
    4828:      	b.eq	0x4834 <_stogir.checked.validate+0x444>
    482c:      	mov	x3, x12
    4830:      	mov	x4, #0x28               ; =40
    4834:      	b	0x46ac <_stogir.checked.validate+0x2bc>
    4838:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004838:  ARM64_RELOC_PAGE21	l_stogir.367
    483c:      	ldr	x16, [x16]
		000000000000483c:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4840:      	orr	x7, x16, xzr
    4844:      	mov	x9, #0x36               ; =54
    4848:      	orr	x10, x6, xzr
    484c:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		000000000000484c:  ARM64_RELOC_PAGE21	l_stogir.368
    4850:      	ldr	x16, [x16]
		0000000000004850:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4854:      	orr	x11, x16, xzr
    4858:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004858:  ARM64_RELOC_PAGE21	l_stogir.369
    485c:      	ldr	x16, [x16]
		000000000000485c:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4860:      	orr	x12, x16, xzr
    4864:      	add	x13, x0, #0x78
    4868:      	add	x14, x0, #0x28
    486c:      	add	x15, x0, #0x50
    4870:      	lsr	w5, w5, #0
    4874:      	lsr	x4, x4, #32
    4878:      	lsr	w5, w5, #0
    487c:      	lsr	w4, w4, #0
    4880:      	str	w4, [x3]
    4884:      	str	w5, [x3, #0x4]
    4888:      	ldr	x3, [x3]
    488c:      	str	x3, [x6]
    4890:      	mov	x3, x7
    4894:      	mov	x4, x9
    4898:      	movz	x5, #0x0, lsl #48
    489c:      	b	0x46b0 <_stogir.checked.validate+0x2c0>
    48a0:      	movz	x9, #0x0, lsl #48
    48a4:      	b	0x47b0 <_stogir.checked.validate+0x3c0>
    48a8:      	movz	x9, #0x0, lsl #48
    48ac:      	b	0x47d8 <_stogir.checked.validate+0x3e8>
    48b0:      	brk	#0
    48b4:      	b	0x48b0 <_stogir.checked.validate+0x4c0>
    48b8:      	movz	x9, #0x0, lsl #48
    48bc:      	b	0x48a4 <_stogir.checked.validate+0x4b4>
    48c0:      	brk	#0
    48c4:      	b	0x48c0 <_stogir.checked.validate+0x4d0>
    48c8:      	brk	#0
    48cc:      	b	0x48c8 <_stogir.checked.validate+0x4d8>

00000000000048d0 <_stogir.atomic.operation?>:
    48d0:      	sxtw	x0, w0
    48d4:      	cmp	x0, #0x7e
    48d8:      	b.lt	0x48ec <_stogir.atomic.operation?+0x1c>
    48dc:      	cmp	x0, #0x82
    48e0:      	cset	w0, le
    48e4:      	ubfx	x0, x0, #0, #8
    48e8:      	b	0x48f0 <_stogir.atomic.operation?+0x20>
    48ec:      	movz	x0, #0x0, lsl #48
    48f0:      	ret

00000000000048f4 <_stogir.atomic.validate>:
    48f4:      	sub	sp, sp, #0xf0
    48f8:      	str	x29, [sp, #0x10]
    48fc:      	str	x30, [sp, #0x18]
    4900:      	add	x29, sp, #0x10
    4904:      	str	x19, [sp, #0xa0]
    4908:      	str	x20, [sp, #0xa8]
    490c:      	str	x21, [sp, #0xb0]
    4910:      	str	x22, [sp, #0xb8]
    4914:      	str	x23, [sp, #0xc0]
    4918:      	str	x24, [sp, #0xc8]
    491c:      	str	x25, [sp, #0xd0]
    4920:      	str	x26, [sp, #0xd8]
    4924:      	str	x27, [sp, #0xe0]
    4928:      	sxtw	x2, w1
    492c:      	lsl	x3, x2, #2
    4930:      	cmp	x2, #0x0
    4934:      	cset	w4, gt
    4938:      	movz	x16, #0x0, lsl #48
    493c:      	sub	x5, x16, x2
    4940:      	sub	x6, x5, #0x1
    4944:      	uxtb	w16, w4
    4948:      	cmp	w16, wzr
    494c:      	b.eq	0x498c <_stogir.atomic.validate+0x98>
    4950:      	ldr	x5, [x0, #0x8]
    4954:      	cmp	x2, x5
    4958:      	b.ge	0x49dc <_stogir.atomic.validate+0xe8>
    495c:      	add	x5, x0, #0x78
    4960:      	ldr	x5, [x5, #0x8]
    4964:      	cmp	x2, x5
    4968:      	b.ge	0x4b3c <_stogir.atomic.validate+0x248>
    496c:      	ldr	x5, [x0, #0x78]
    4970:      	add	x5, x3, x5
    4974:      	ldr	w5, [x5]
    4978:      	sxtw	x5, w5
    497c:      	cmp	x5, #0x0
    4980:      	cset	w5, ge
    4984:      	ubfx	x5, x5, #0, #8
    4988:      	b	0x4b40 <_stogir.atomic.validate+0x24c>
    498c:      	cmp	x2, #0x0
    4990:      	b.ge	0x49e4 <_stogir.atomic.validate+0xf0>
    4994:      	add	x7, x0, #0x28
    4998:      	add	x9, x0, #0x50
    499c:      	ldr	x7, [x7, #0x8]
    49a0:      	ldr	x9, [x9, #0x8]
    49a4:      	cmp	x7, x9
    49a8:      	b.ne	0x49d4 <_stogir.atomic.validate+0xe0>
    49ac:      	cmp	x5, x7
    49b0:      	b.gt	0x4bd4 <_stogir.atomic.validate+0x2e0>
    49b4:      	ldr	x5, [x0, #0x50]
    49b8:      	add	x5, x5, x6, lsl #2
    49bc:      	ldr	w5, [x5]
    49c0:      	sxtw	x5, w5
    49c4:      	cmp	x5, #0x0
    49c8:      	cset	w5, gt
    49cc:      	ubfx	x5, x5, #0, #8
    49d0:      	b	0x4bd8 <_stogir.atomic.validate+0x2e4>
    49d4:      	movz	x5, #0x0, lsl #48
    49d8:      	b	0x49e8 <_stogir.atomic.validate+0xf4>
    49dc:      	movz	x5, #0x0, lsl #48
    49e0:      	b	0x49e8 <_stogir.atomic.validate+0xf4>
    49e4:      	movz	x5, #0x0, lsl #48
    49e8:      	cmp	x5, #0x0
    49ec:      	b.eq	0x4a44 <_stogir.atomic.validate+0x150>
    49f0:      	uxtb	w16, w4
    49f4:      	cmp	w16, wzr
    49f8:      	b.eq	0x4a1c <_stogir.atomic.validate+0x128>
    49fc:      	ldr	x4, [x0]
    4a00:      	add	x4, x4, x2, lsl #4
    4a04:      	ldr	x5, [x4]
    4a08:      	ldr	x4, [x4, #0x8]
    4a0c:      	fmov	d31, x4
    4a10:      	mov	x4, x5
    4a14:      	fmov	x5, d31
    4a18:      	b	0x4a38 <_stogir.atomic.validate+0x144>
    4a1c:      	ldr	x4, [x0, #0x28]
    4a20:      	add	x4, x4, x6, lsl #4
    4a24:      	ldr	x5, [x4]
    4a28:      	ldr	x4, [x4, #0x8]
    4a2c:      	fmov	d31, x4
    4a30:      	mov	x4, x5
    4a34:      	fmov	x5, d31
    4a38:      	mov	x19, x4
    4a3c:      	mov	x4, #0x1                ; =1
    4a40:      	b	0x4a50 <_stogir.atomic.validate+0x15c>
    4a44:      	movz	x4, #0x0, lsl #48
    4a48:      	movz	x19, #0x0, lsl #48
    4a4c:      	movz	x5, #0x0, lsl #48
    4a50:      	lsr	w4, w4, #0
    4a54:      	lsr	x16, x4, #0
    4a58:      	cmp	x16, #0x1
    4a5c:      	b.eq	0x4a78 <_stogir.atomic.validate+0x184>
    4a60:      	b.lo	0x4a68 <_stogir.atomic.validate+0x174>
    4a64:      	b	0x4a7c <_stogir.atomic.validate+0x188>
    4a68:      	cmp	x16, #0x0
    4a6c:      	b.eq	0x4a74 <_stogir.atomic.validate+0x180>
    4a70:      	b	0x4a7c <_stogir.atomic.validate+0x188>
    4a74:      	b	0x4a80 <_stogir.atomic.validate+0x18c>
    4a78:      	b	0x4adc <_stogir.atomic.validate+0x1e8>
    4a7c:      	b	0x5184 <_stogir.atomic.validate+0x890>
    4a80:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004a80:  ARM64_RELOC_PAGE21	l_stogir.370
    4a84:      	ldr	x16, [x16]
		0000000000004a84:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4a88:      	orr	x0, x16, xzr
    4a8c:      	mov	x23, x8
    4a90:      	mov	x1, x0
    4a94:      	mov	x0, #0x1                ; =1
    4a98:      	mov	x2, #0x1a               ; =26
    4a9c:      	str	x0, [x23]
    4aa0:      	str	x1, [x23, #0x8]
    4aa4:      	str	x2, [x23, #0x10]
    4aa8:      	ldr	x19, [sp, #0xa0]
    4aac:      	ldr	x20, [sp, #0xa8]
    4ab0:      	ldr	x21, [sp, #0xb0]
    4ab4:      	ldr	x22, [sp, #0xb8]
    4ab8:      	ldr	x23, [sp, #0xc0]
    4abc:      	ldr	x24, [sp, #0xc8]
    4ac0:      	ldr	x25, [sp, #0xd0]
    4ac4:      	ldr	x26, [sp, #0xd8]
    4ac8:      	ldr	x27, [sp, #0xe0]
    4acc:      	ldr	x29, [sp, #0x10]
    4ad0:      	ldr	x30, [sp, #0x18]
    4ad4:      	add	sp, sp, #0xf0
    4ad8:      	ret
    4adc:      	uxtb	w4, w19
    4ae0:      	add	x16, sp, #0x20
    4ae4:      	str	x19, [x16]
    4ae8:      	orr	x20, x4, xzr
    4aec:      	add	x16, sp, #0x20
    4af0:      	str	x5, [x16, #0x8]
    4af4:      	cmp	x2, #0x0
    4af8:      	b.le	0x4b54 <_stogir.atomic.validate+0x260>
    4afc:      	cmp	x20, #0x7e
    4b00:      	b.lt	0x4b54 <_stogir.atomic.validate+0x260>
    4b04:      	cmp	x20, #0x82
    4b08:      	b.gt	0x4b54 <_stogir.atomic.validate+0x260>
    4b0c:      	ldr	x2, [x0, #0x78]
    4b10:      	add	x2, x3, x2
    4b14:      	ldr	w2, [x2]
    4b18:      	cmp	x20, #0x83
    4b1c:      	b.ge	0x50a4 <_stogir.atomic.validate+0x7b0>
    4b20:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004b20:  ARM64_RELOC_PAGE21	l_stogir.371
    4b24:      	ldr	x16, [x16]
		0000000000004b24:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    4b28:      	orr	x3, x16, xzr
    4b2c:      	add	x3, x20, x3
    4b30:      	ldrsb	w3, [x3]
    4b34:      	sxtb	x3, w3
    4b38:      	b	0x50a8 <_stogir.atomic.validate+0x7b4>
    4b3c:      	movz	x5, #0x0, lsl #48
    4b40:      	b	0x49e0 <_stogir.atomic.validate+0xec>
    4b44:      	mov	x2, x1
    4b48:      	mov	x1, x0
    4b4c:      	mov	x0, #0x1                ; =1
    4b50:      	b	0x4a9c <_stogir.atomic.validate+0x1a8>
    4b54:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004b54:  ARM64_RELOC_PAGE21	l_stogir.372
    4b58:      	ldr	x16, [x16]
		0000000000004b58:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    4b5c:      	orr	x2, x16, xzr
    4b60:      	mov	x21, x2
    4b64:      	mov	x22, #0x20              ; =32
    4b68:      	add	x16, sp, #0x20
    4b6c:      	ldr	w2, [x16, #0x4]
    4b70:      	lsr	w2, w2, #0
    4b74:      	mov	x23, x8
    4b78:      	add	x8, sp, #0x30
    4b7c:      	mov	x24, x0
    4b80:      	mov	w25, w1
    4b84:      	mov	w1, w2
    4b88:      	bl	0x4b88 <_stogir.atomic.validate+0x294>
		0000000000004b88:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4b8c:      	add	x16, sp, #0x30
    4b90:      	ldr	w0, [x16]
    4b94:      	lsr	x16, x0, #0
    4b98:      	cmp	x16, #0x1
    4b9c:      	b.eq	0x4bb8 <_stogir.atomic.validate+0x2c4>
    4ba0:      	b.lo	0x4ba8 <_stogir.atomic.validate+0x2b4>
    4ba4:      	b	0x4bbc <_stogir.atomic.validate+0x2c8>
    4ba8:      	cmp	x16, #0x0
    4bac:      	b.eq	0x4bb4 <_stogir.atomic.validate+0x2c0>
    4bb0:      	b	0x4bbc <_stogir.atomic.validate+0x2c8>
    4bb4:      	b	0x4bc0 <_stogir.atomic.validate+0x2cc>
    4bb8:      	b	0x4cb8 <_stogir.atomic.validate+0x3c4>
    4bbc:      	b	0x51b8 <_stogir.atomic.validate+0x8c4>
    4bc0:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004bc0:  ARM64_RELOC_PAGE21	l_stogir.373
    4bc4:      	ldr	x16, [x16]
		0000000000004bc4:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    4bc8:      	orr	x0, x16, xzr
    4bcc:      	mov	x1, #0x16               ; =22
    4bd0:      	b	0x4be4 <_stogir.atomic.validate+0x2f0>
    4bd4:      	movz	x5, #0x0, lsl #48
    4bd8:      	b	0x49d8 <_stogir.atomic.validate+0xe4>
    4bdc:      	mov	x0, x1
    4be0:      	mov	x1, x22
    4be4:      	cmp	x20, #0x82
    4be8:      	cset	w21, eq
    4bec:      	lsr	w19, w19, #0
    4bf0:      	ubfx	x2, x19, #8, #8
    4bf4:      	orr	x19, x2, xzr
    4bf8:      	cmp	x19, #0x0
    4bfc:      	cset	w22, eq
    4c00:      	uxtb	w16, w21
    4c04:      	cmp	w16, wzr
    4c08:      	b.eq	0x4c30 <_stogir.atomic.validate+0x33c>
    4c0c:      	uxtb	w16, w22
    4c10:      	cmp	w16, wzr
    4c14:      	b.ne	0x4c28 <_stogir.atomic.validate+0x334>
    4c18:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004c18:  ARM64_RELOC_PAGE21	l_stogir.374
    4c1c:      	ldr	x16, [x16]
		0000000000004c1c:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    4c20:      	orr	x0, x16, xzr
    4c24:      	mov	x1, #0x19               ; =25
    4c28:      	mov	x26, x1
    4c2c:      	b	0x4c34 <_stogir.atomic.validate+0x340>
    4c30:      	mov	x26, x1
    4c34:      	uxtb	w16, w21
    4c38:      	cmp	w16, wzr
    4c3c:      	b.eq	0x4c4c <_stogir.atomic.validate+0x358>
    4c40:      	mov	x27, x0
    4c44:      	movz	x0, #0x0, lsl #48
    4c48:      	b	0x4c54 <_stogir.atomic.validate+0x360>
    4c4c:      	mov	x27, x0
    4c50:      	mov	x0, #0x1                ; =1
    4c54:      	cmp	x0, #0x0
    4c58:      	b.eq	0x4c8c <_stogir.atomic.validate+0x398>
    4c5c:      	add	x16, sp, #0x20
    4c60:      	ldr	w0, [x16, #0x8]
    4c64:      	lsr	w0, w0, #0
    4c68:      	mov	w1, w0
    4c6c:      	mov	x0, x24
    4c70:      	mov	x2, #0x6                ; =6
    4c74:      	bl	0x4c74 <_stogir.atomic.validate+0x380>
		0000000000004c74:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4c78:      	cmp	x0, #0x0
    4c7c:      	b.eq	0x4df0 <_stogir.atomic.validate+0x4fc>
    4c80:      	mov	x1, x27
    4c84:      	movz	x0, #0x0, lsl #48
    4c88:      	b	0x4df8 <_stogir.atomic.validate+0x504>
    4c8c:      	mov	x0, x19
    4c90:      	mov	x1, x27
    4c94:      	mov	x19, x26
    4c98:      	cmp	x20, #0x80
    4c9c:      	cset	w22, eq
    4ca0:      	uxtb	w16, w22
    4ca4:      	cmp	w16, wzr
    4ca8:      	b.eq	0x4ce0 <_stogir.atomic.validate+0x3ec>
    4cac:      	mov	x20, x1
    4cb0:      	mov	x1, #0x1                ; =1
    4cb4:      	b	0x4cf4 <_stogir.atomic.validate+0x400>
    4cb8:      	add	x16, sp, #0x30
    4cbc:      	ldr	x0, [x16, #0x8]
    4cc0:      	add	x16, sp, #0x20
    4cc4:      	ldr	w1, [x16, #0x4]
    4cc8:      	sxtw	x1, w1
    4ccc:      	cmp	x1, #0x0
    4cd0:      	b.gt	0x4e60 <_stogir.atomic.validate+0x56c>
    4cd4:      	mov	x1, x21
    4cd8:      	mov	x0, #0x1                ; =1
    4cdc:      	b	0x4e44 <_stogir.atomic.validate+0x550>
    4ce0:      	cmp	x20, #0x81
    4ce4:      	cset	w2, eq
    4ce8:      	ubfx	x2, x2, #0, #8
    4cec:      	mov	x20, x1
    4cf0:      	mov	x1, x2
    4cf4:      	lsr	w26, w0, #0
    4cf8:      	cmp	x1, #0x0
    4cfc:      	b.eq	0x4d7c <_stogir.atomic.validate+0x488>
    4d00:      	lsr	w25, w25, #0
    4d04:      	add	x16, sp, #0x90
    4d08:      	str	x16, [sp]
    4d0c:      	mov	x0, x24
    4d10:      	mov	w1, w25
    4d14:      	mov	x2, #0x4                ; =4
    4d18:      	bl	0x4d18 <_stogir.atomic.validate+0x424>
		0000000000004d18:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    4d1c:      	ldr	x16, [sp]
    4d20:      	str	x0, [x16]
    4d24:      	str	x1, [x16, #0x8]
    4d28:      	add	x16, sp, #0x90
    4d2c:      	ldr	x0, [x16]
    4d30:      	add	x16, sp, #0x90
    4d34:      	ldr	x1, [x16, #0x8]
    4d38:      	lsr	w0, w0, #0
    4d3c:      	lsr	x16, x0, #0
    4d40:      	cmp	x16, #0x1
    4d44:      	b.eq	0x4d60 <_stogir.atomic.validate+0x46c>
    4d48:      	b.lo	0x4d50 <_stogir.atomic.validate+0x45c>
    4d4c:      	b	0x4d64 <_stogir.atomic.validate+0x470>
    4d50:      	cmp	x16, #0x0
    4d54:      	b.eq	0x4d5c <_stogir.atomic.validate+0x468>
    4d58:      	b	0x4d64 <_stogir.atomic.validate+0x470>
    4d5c:      	b	0x4d68 <_stogir.atomic.validate+0x474>
    4d60:      	b	0x4f98 <_stogir.atomic.validate+0x6a4>
    4d64:      	b	0x51c8 <_stogir.atomic.validate+0x8d4>
    4d68:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004d68:  ARM64_RELOC_PAGE21	l_stogir.375
    4d6c:      	ldr	x16, [x16]
		0000000000004d6c:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    4d70:      	orr	x0, x16, xzr
    4d74:      	mov	x1, #0x1d               ; =29
    4d78:      	b	0x4dec <_stogir.atomic.validate+0x4f8>
    4d7c:      	mov	x0, x20
    4d80:      	mov	x1, x19
    4d84:      	cmp	x1, #0x0
    4d88:      	b.ne	0x4b44 <_stogir.atomic.validate+0x250>
    4d8c:      	uxtb	w16, w21
    4d90:      	cmp	w16, wzr
    4d94:      	b.eq	0x4f84 <_stogir.atomic.validate+0x690>
    4d98:      	movz	x0, #0x0, lsl #48
    4d9c:      	b	0x4dc8 <_stogir.atomic.validate+0x4d4>
    4da0:      	mov	x0, x1
    4da4:      	mov	x1, x22
    4da8:      	fmov	d31, x0
    4dac:      	mov	x0, x19
    4db0:      	mov	x19, x1
    4db4:      	fmov	x1, d31
    4db8:      	b	0x4c98 <_stogir.atomic.validate+0x3a4>
    4dbc:      	mov	x0, #0x1                ; =1
    4dc0:      	lsr	w0, w0, #0
    4dc4:      	sxtw	x0, w0
    4dc8:      	and	x0, x0, #0xffffffff
    4dcc:      	mov	x1, x0
    4dd0:      	movz	x0, #0x0, lsl #48
    4dd4:      	movz	x2, #0x0, lsl #48
    4dd8:      	b	0x4b50 <_stogir.atomic.validate+0x25c>
    4ddc:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004ddc:  ARM64_RELOC_PAGE21	l_stogir.376
    4de0:      	ldr	x16, [x16]
		0000000000004de0:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    4de4:      	orr	x0, x16, xzr
    4de8:      	mov	x1, #0x24               ; =36
    4dec:      	b	0x4d84 <_stogir.atomic.validate+0x490>
    4df0:      	mov	x1, x27
    4df4:      	mov	x0, #0x1                ; =1
    4df8:      	cmp	x0, #0x0
    4dfc:      	b.eq	0x4e14 <_stogir.atomic.validate+0x520>
    4e00:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004e00:  ARM64_RELOC_PAGE21	l_stogir.377
    4e04:      	ldr	x16, [x16]
		0000000000004e04:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    4e08:      	orr	x0, x16, xzr
    4e0c:      	mov	x1, #0x1b               ; =27
    4e10:      	b	0x4e1c <_stogir.atomic.validate+0x528>
    4e14:      	mov	x0, x1
    4e18:      	mov	x1, x26
    4e1c:      	cmp	x20, #0x7f
    4e20:      	b.ne	0x4eb4 <_stogir.atomic.validate+0x5c0>
    4e24:      	uxtb	w16, w22
    4e28:      	cmp	w16, wzr
    4e2c:      	b.eq	0x4fc0 <_stogir.atomic.validate+0x6cc>
    4e30:      	mov	x22, x0
    4e34:      	mov	x26, x1
    4e38:      	b	0x4fd4 <_stogir.atomic.validate+0x6e0>
    4e3c:      	mov	x0, #0x1                ; =1
    4e40:      	mov	x1, x21
    4e44:      	cmp	x0, #0x0
    4e48:      	b.eq	0x4bdc <_stogir.atomic.validate+0x2e8>
    4e4c:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004e4c:  ARM64_RELOC_PAGE21	l_stogir.378
    4e50:      	ldr	x16, [x16]
		0000000000004e50:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    4e54:      	orr	x0, x16, xzr
    4e58:      	mov	x1, #0x16               ; =22
    4e5c:      	b	0x4be4 <_stogir.atomic.validate+0x2f0>
    4e60:      	uxtb	w0, w0
    4e64:      	cmp	x0, #0x83
    4e68:      	cset	w1, lt
    4e6c:      	uxtb	w16, w1
    4e70:      	cmp	w16, wzr
    4e74:      	b.eq	0x5068 <_stogir.atomic.validate+0x774>
    4e78:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004e78:  ARM64_RELOC_PAGE21	l_stogir.379
    4e7c:      	ldr	x16, [x16]
		0000000000004e7c:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    4e80:      	orr	x2, x16, xzr
    4e84:      	add	x2, x0, x2
    4e88:      	ldrb	w2, [x2]
    4e8c:      	b	0x506c <_stogir.atomic.validate+0x778>
    4e90:      	add	x16, sp, #0x60
    4e94:      	ldr	x0, [x16, #0x8]
    4e98:      	lsr	w0, w0, #0
    4e9c:      	ubfx	x0, x0, #8, #8
    4ea0:      	mov	x1, x22
    4ea4:      	mov	x2, x26
    4ea8:      	mov	x19, x0
    4eac:      	mov	x0, x1
    4eb0:      	mov	x1, x2
    4eb4:      	cmp	x19, #0x2
    4eb8:      	b.ge	0x4f50 <_stogir.atomic.validate+0x65c>
    4ebc:      	mov	x2, x1
    4ec0:      	mov	x1, #0x1                ; =1
    4ec4:      	b	0x4f68 <_stogir.atomic.validate+0x674>
    4ec8:      	mov	x1, x26
    4ecc:      	movz	x0, #0x0, lsl #48
    4ed0:      	cmp	x0, #0x0
    4ed4:      	b.eq	0x4da0 <_stogir.atomic.validate+0x4ac>
    4ed8:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004ed8:  ARM64_RELOC_PAGE21	l_stogir.380
    4edc:      	ldr	x16, [x16]
		0000000000004edc:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    4ee0:      	orr	x0, x16, xzr
    4ee4:      	mov	x1, #0x22               ; =34
    4ee8:      	b	0x4da8 <_stogir.atomic.validate+0x4b4>
    4eec:      	mov	x1, x26
    4ef0:      	mov	x0, #0x1                ; =1
    4ef4:      	b	0x4ed0 <_stogir.atomic.validate+0x5dc>
    4ef8:      	mov	x26, x0
    4efc:      	mov	x0, #0x1                ; =1
    4f00:      	cmp	x0, #0x0
    4f04:      	b.eq	0x4ec8 <_stogir.atomic.validate+0x5d4>
    4f08:      	lsr	w0, w19, #0
    4f0c:      	add	x16, sp, #0x20
    4f10:      	ldr	w1, [x16, #0xc]
    4f14:      	lsr	w1, w1, #0
    4f18:      	mov	w2, w0
    4f1c:      	mov	x0, x24
    4f20:      	bl	0x4f20 <_stogir.atomic.validate+0x62c>
		0000000000004f20:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4f24:      	cmp	x0, #0x0
    4f28:      	b.eq	0x4eec <_stogir.atomic.validate+0x5f8>
    4f2c:      	mov	x1, x26
    4f30:      	movz	x0, #0x0, lsl #48
    4f34:      	b	0x4ef4 <_stogir.atomic.validate+0x600>
    4f38:      	mov	x22, x2
    4f3c:      	cmp	x20, #0x7e
    4f40:      	b.ne	0x4ef8 <_stogir.atomic.validate+0x604>
    4f44:      	mov	x26, x0
    4f48:      	movz	x0, #0x0, lsl #48
    4f4c:      	b	0x4f00 <_stogir.atomic.validate+0x60c>
    4f50:      	cmp	x19, #0x5
    4f54:      	cset	w2, gt
    4f58:      	ubfx	x2, x2, #0, #8
    4f5c:      	fmov	d31, x1
    4f60:      	mov	x1, x2
    4f64:      	fmov	x2, d31
    4f68:      	cmp	x1, #0x0
    4f6c:      	b.eq	0x4f38 <_stogir.atomic.validate+0x644>
    4f70:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004f70:  ARM64_RELOC_PAGE21	l_stogir.381
    4f74:      	ldr	x16, [x16]
		0000000000004f74:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    4f78:      	orr	x0, x16, xzr
    4f7c:      	mov	x22, #0x25              ; =37
    4f80:      	b	0x4f3c <_stogir.atomic.validate+0x648>
    4f84:      	sxtw	x26, w26
    4f88:      	cmp	x26, #0x0
    4f8c:      	b.ne	0x50d4 <_stogir.atomic.validate+0x7e0>
    4f90:      	movz	x0, #0x0, lsl #48
    4f94:      	b	0x4dc0 <_stogir.atomic.validate+0x4cc>
    4f98:      	lsr	w1, w1, #0
    4f9c:      	uxtb	w16, w22
    4fa0:      	cmp	w16, wzr
    4fa4:      	b.eq	0x5160 <_stogir.atomic.validate+0x86c>
    4fa8:      	sxtw	x1, w1
    4fac:      	cmp	x1, #0x0
    4fb0:      	b.ge	0x518c <_stogir.atomic.validate+0x898>
    4fb4:      	mov	x1, x20
    4fb8:      	mov	x0, #0x1                ; =1
    4fbc:      	b	0x519c <_stogir.atomic.validate+0x8a8>
    4fc0:      	adrp	x16, 0x4000 <_stogir.graph.lookup+0x20>
		0000000000004fc0:  ARM64_RELOC_PAGE21	l_stogir.382
    4fc4:      	ldr	x16, [x16]
		0000000000004fc4:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    4fc8:      	orr	x0, x16, xzr
    4fcc:      	mov	x22, x0
    4fd0:      	mov	x26, #0x19              ; =25
    4fd4:      	add	x16, sp, #0x20
    4fd8:      	ldr	w0, [x16, #0xc]
    4fdc:      	lsr	w0, w0, #0
    4fe0:      	add	x8, sp, #0x60
    4fe4:      	mov	w1, w0
    4fe8:      	mov	x0, x24
    4fec:      	bl	0x4fec <_stogir.atomic.validate+0x6f8>
		0000000000004fec:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4ff0:      	add	x16, sp, #0x60
    4ff4:      	ldr	w0, [x16]
    4ff8:      	lsr	x16, x0, #0
    4ffc:      	cmp	x16, #0x1
    5000:      	b.eq	0x501c <_stogir.atomic.validate+0x728>
    5004:      	b.lo	0x500c <_stogir.atomic.validate+0x718>
    5008:      	b	0x5020 <_stogir.atomic.validate+0x72c>
    500c:      	cmp	x16, #0x0
    5010:      	b.eq	0x5018 <_stogir.atomic.validate+0x724>
    5014:      	b	0x5020 <_stogir.atomic.validate+0x72c>
    5018:      	b	0x5024 <_stogir.atomic.validate+0x730>
    501c:      	b	0x4e90 <_stogir.atomic.validate+0x59c>
    5020:      	b	0x51d0 <_stogir.atomic.validate+0x8dc>
    5024:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005024:  ARM64_RELOC_PAGE21	l_stogir.383
    5028:      	ldr	x16, [x16]
		0000000000005028:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    502c:      	orr	x0, x16, xzr
    5030:      	mov	x1, x0
    5034:      	mov	x0, x19
    5038:      	mov	x2, #0x1a               ; =26
    503c:      	b	0x4ea8 <_stogir.atomic.validate+0x5b4>
    5040:      	movz	x0, #0x0, lsl #48
    5044:      	uxtb	w0, w0
    5048:      	and	x0, x0, #0x4
    504c:      	uxtb	w0, w0
    5050:      	cmp	x0, #0x0
    5054:      	cset	w0, eq
    5058:      	uxtb	w16, w0
    505c:      	cmp	w16, wzr
    5060:      	cset	x0, eq
    5064:      	b	0x4e40 <_stogir.atomic.validate+0x54c>
    5068:      	movz	x2, #0x0, lsl #48
    506c:      	uxtb	w2, w2
    5070:      	and	x2, x2, #0x1
    5074:      	uxtb	w2, w2
    5078:      	cmp	x2, #0x0
    507c:      	b.eq	0x4e3c <_stogir.atomic.validate+0x548>
    5080:      	uxtb	w16, w1
    5084:      	cmp	w16, wzr
    5088:      	b.eq	0x5040 <_stogir.atomic.validate+0x74c>
    508c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		000000000000508c:  ARM64_RELOC_PAGE21	l_stogir.379
    5090:      	ldr	x16, [x16]
		0000000000005090:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    5094:      	orr	x1, x16, xzr
    5098:      	add	x0, x0, x1
    509c:      	ldrb	w0, [x0]
    50a0:      	b	0x5044 <_stogir.atomic.validate+0x750>
    50a4:      	mov	x3, #-0x2               ; =-2
    50a8:      	sxtw	x2, w2
    50ac:      	lsr	w3, w3, #0
    50b0:      	sxtw	x3, w3
    50b4:      	cmp	x2, x3
    50b8:      	b.ne	0x4b54 <_stogir.atomic.validate+0x260>
    50bc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		00000000000050bc:  ARM64_RELOC_PAGE21	l_stogir.384
    50c0:      	ldr	x16, [x16]
		00000000000050c0:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    50c4:      	orr	x2, x16, xzr
    50c8:      	mov	x21, x2
    50cc:      	movz	x22, #0x0, lsl #48
    50d0:      	b	0x4b68 <_stogir.atomic.validate+0x274>
    50d4:      	cmp	x26, #0x1
    50d8:      	b.eq	0x4dbc <_stogir.atomic.validate+0x4c8>
    50dc:      	cmp	x26, #0x2
    50e0:      	b.eq	0x4dbc <_stogir.atomic.validate+0x4c8>
    50e4:      	cmp	x26, #0x7
    50e8:      	b.eq	0x4dbc <_stogir.atomic.validate+0x4c8>
    50ec:      	cmp	x26, #0x8
    50f0:      	b.eq	0x4dbc <_stogir.atomic.validate+0x4c8>
    50f4:      	cmp	x26, #0x3
    50f8:      	b.eq	0x51c0 <_stogir.atomic.validate+0x8cc>
    50fc:      	cmp	x26, #0x9
    5100:      	b.eq	0x51c0 <_stogir.atomic.validate+0x8cc>
    5104:      	cmp	x26, #0x4
    5108:      	b.eq	0x51d8 <_stogir.atomic.validate+0x8e4>
    510c:      	cmp	x26, #0xa
    5110:      	b.eq	0x51d8 <_stogir.atomic.validate+0x8e4>
    5114:      	cmp	x26, #0xd
    5118:      	b.eq	0x51d8 <_stogir.atomic.validate+0x8e4>
    511c:      	cmp	x26, #0x5
    5120:      	b.eq	0x51e0 <_stogir.atomic.validate+0x8ec>
    5124:      	cmp	x26, #0xb
    5128:      	b.eq	0x51e0 <_stogir.atomic.validate+0x8ec>
    512c:      	cmp	x26, #0xc
    5130:      	b.eq	0x51e0 <_stogir.atomic.validate+0x8ec>
    5134:      	cmp	x26, #0x6
    5138:      	cset	w0, eq
    513c:      	uxtb	w16, w0
    5140:      	cmp	w16, wzr
    5144:      	mov	x16, #0x8               ; =8
    5148:      	movn	x17, #0x0, lsl #48
    514c:      	csel	x0, x16, x17, ne
    5150:      	b	0x51e4 <_stogir.atomic.validate+0x8f0>
    5154:      	mov	x0, x1
    5158:      	mov	x1, x19
    515c:      	b	0x4dec <_stogir.atomic.validate+0x4f8>
    5160:      	lsr	w1, w1, #0
    5164:      	mov	x0, x24
    5168:      	mov	w2, w26
    516c:      	bl	0x516c <_stogir.atomic.validate+0x878>
		000000000000516c:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5170:      	cmp	x0, #0x0
    5174:      	b.eq	0x4ddc <_stogir.atomic.validate+0x4e8>
    5178:      	mov	x0, x20
    517c:      	mov	x1, x19
    5180:      	b	0x4dec <_stogir.atomic.validate+0x4f8>
    5184:      	brk	#0
    5188:      	b	0x5184 <_stogir.atomic.validate+0x890>
    518c:      	cmp	x1, #0x9
    5190:      	cset	w0, gt
    5194:      	ubfx	x0, x0, #0, #8
    5198:      	mov	x1, x20
    519c:      	cmp	x0, #0x0
    51a0:      	b.eq	0x5154 <_stogir.atomic.validate+0x860>
    51a4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		00000000000051a4:  ARM64_RELOC_PAGE21	l_stogir.385
    51a8:      	ldr	x16, [x16]
		00000000000051a8:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    51ac:      	orr	x0, x16, xzr
    51b0:      	mov	x1, #0x1c               ; =28
    51b4:      	b	0x515c <_stogir.atomic.validate+0x868>
    51b8:      	brk	#0
    51bc:      	b	0x51b8 <_stogir.atomic.validate+0x8c4>
    51c0:      	mov	x0, #0x2                ; =2
    51c4:      	b	0x4dc0 <_stogir.atomic.validate+0x4cc>
    51c8:      	brk	#0
    51cc:      	b	0x51c8 <_stogir.atomic.validate+0x8d4>
    51d0:      	brk	#0
    51d4:      	b	0x51d0 <_stogir.atomic.validate+0x8dc>
    51d8:      	mov	x0, #0x4                ; =4
    51dc:      	b	0x51c4 <_stogir.atomic.validate+0x8d0>
    51e0:      	mov	x0, #0x8                ; =8
    51e4:      	b	0x51dc <_stogir.atomic.validate+0x8e8>

00000000000051e8 <_stogir.terminal.operation?>:
    51e8:      	sxtw	x0, w0
    51ec:      	cmp	x0, #0x60
    51f0:      	b.ne	0x51fc <_stogir.terminal.operation?+0x14>
    51f4:      	mov	x0, #0x1                ; =1
    51f8:      	b	0x5208 <_stogir.terminal.operation?+0x20>
    51fc:      	cmp	x0, #0x79
    5200:      	cset	w0, eq
    5204:      	ubfx	x0, x0, #0, #8
    5208:      	ret

000000000000520c <_stogir.terminal.validate>:
    520c:      	sub	sp, sp, #0x50
    5210:      	str	x29, [sp]
    5214:      	str	x30, [sp, #0x8]
    5218:      	mov	x29, sp
    521c:      	str	x19, [sp, #0x40]
    5220:      	sxtw	x1, w1
    5224:      	lsl	x2, x1, #2
    5228:      	cmp	x1, #0x0
    522c:      	cset	w3, gt
    5230:      	movz	x16, #0x0, lsl #48
    5234:      	sub	x4, x16, x1
    5238:      	sub	x5, x4, #0x1
    523c:      	uxtb	w16, w3
    5240:      	cmp	w16, wzr
    5244:      	b.eq	0x5284 <_stogir.terminal.validate+0x78>
    5248:      	ldr	x4, [x0, #0x8]
    524c:      	cmp	x1, x4
    5250:      	b.ge	0x52d4 <_stogir.terminal.validate+0xc8>
    5254:      	add	x4, x0, #0x78
    5258:      	ldr	x4, [x4, #0x8]
    525c:      	cmp	x1, x4
    5260:      	b.ge	0x53f0 <_stogir.terminal.validate+0x1e4>
    5264:      	ldr	x4, [x0, #0x78]
    5268:      	add	x4, x2, x4
    526c:      	ldr	w4, [x4]
    5270:      	sxtw	x4, w4
    5274:      	cmp	x4, #0x0
    5278:      	cset	w4, ge
    527c:      	ubfx	x4, x4, #0, #8
    5280:      	b	0x53f4 <_stogir.terminal.validate+0x1e8>
    5284:      	cmp	x1, #0x0
    5288:      	b.ge	0x52dc <_stogir.terminal.validate+0xd0>
    528c:      	add	x6, x0, #0x28
    5290:      	add	x7, x0, #0x50
    5294:      	ldr	x6, [x6, #0x8]
    5298:      	ldr	x7, [x7, #0x8]
    529c:      	cmp	x6, x7
    52a0:      	b.ne	0x52cc <_stogir.terminal.validate+0xc0>
    52a4:      	cmp	x4, x6
    52a8:      	b.gt	0x5430 <_stogir.terminal.validate+0x224>
    52ac:      	ldr	x4, [x0, #0x50]
    52b0:      	add	x4, x4, x5, lsl #2
    52b4:      	ldr	w4, [x4]
    52b8:      	sxtw	x4, w4
    52bc:      	cmp	x4, #0x0
    52c0:      	cset	w4, gt
    52c4:      	ubfx	x4, x4, #0, #8
    52c8:      	b	0x5434 <_stogir.terminal.validate+0x228>
    52cc:      	movz	x4, #0x0, lsl #48
    52d0:      	b	0x52e0 <_stogir.terminal.validate+0xd4>
    52d4:      	movz	x4, #0x0, lsl #48
    52d8:      	b	0x52e0 <_stogir.terminal.validate+0xd4>
    52dc:      	movz	x4, #0x0, lsl #48
    52e0:      	cmp	x4, #0x0
    52e4:      	b.eq	0x5340 <_stogir.terminal.validate+0x134>
    52e8:      	uxtb	w16, w3
    52ec:      	cmp	w16, wzr
    52f0:      	b.eq	0x5314 <_stogir.terminal.validate+0x108>
    52f4:      	ldr	x3, [x0]
    52f8:      	add	x3, x3, x1, lsl #4
    52fc:      	ldr	x4, [x3]
    5300:      	ldr	x3, [x3, #0x8]
    5304:      	fmov	d31, x3
    5308:      	mov	x3, x4
    530c:      	fmov	x4, d31
    5310:      	b	0x5330 <_stogir.terminal.validate+0x124>
    5314:      	ldr	x3, [x0, #0x28]
    5318:      	add	x3, x3, x5, lsl #4
    531c:      	ldr	x4, [x3]
    5320:      	ldr	x3, [x3, #0x8]
    5324:      	fmov	d31, x3
    5328:      	mov	x3, x4
    532c:      	fmov	x4, d31
    5330:      	mov	x5, x4
    5334:      	mov	x4, x3
    5338:      	mov	x3, #0x1                ; =1
    533c:      	b	0x534c <_stogir.terminal.validate+0x140>
    5340:      	movz	x3, #0x0, lsl #48
    5344:      	movz	x4, #0x0, lsl #48
    5348:      	movz	x5, #0x0, lsl #48
    534c:      	lsr	w3, w3, #0
    5350:      	lsr	x16, x3, #0
    5354:      	cmp	x16, #0x1
    5358:      	b.eq	0x5374 <_stogir.terminal.validate+0x168>
    535c:      	b.lo	0x5364 <_stogir.terminal.validate+0x158>
    5360:      	b	0x5378 <_stogir.terminal.validate+0x16c>
    5364:      	cmp	x16, #0x0
    5368:      	b.eq	0x5370 <_stogir.terminal.validate+0x164>
    536c:      	b	0x5378 <_stogir.terminal.validate+0x16c>
    5370:      	b	0x537c <_stogir.terminal.validate+0x170>
    5374:      	b	0x539c <_stogir.terminal.validate+0x190>
    5378:      	b	0x550c <_stogir.terminal.validate+0x300>
    537c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		000000000000537c:  ARM64_RELOC_PAGE21	l_stogir.386
    5380:      	ldr	x16, [x16]
		0000000000005380:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5384:      	orr	x0, x16, xzr
    5388:      	mov	x19, x8
    538c:      	mov	x1, x0
    5390:      	mov	x0, #0x1                ; =1
    5394:      	mov	x2, #0x21               ; =33
    5398:      	b	0x53d0 <_stogir.terminal.validate+0x1c4>
    539c:      	add	x16, sp, #0x10
    53a0:      	str	x4, [x16]
    53a4:      	add	x16, sp, #0x10
    53a8:      	str	x5, [x16, #0x8]
    53ac:      	cmp	x1, #0x0
    53b0:      	b.gt	0x53f8 <_stogir.terminal.validate+0x1ec>
    53b4:      	mov	x19, x8
    53b8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		00000000000053b8:  ARM64_RELOC_PAGE21	l_stogir.387
    53bc:      	ldr	x16, [x16]
		00000000000053bc:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    53c0:      	orr	x0, x16, xzr
    53c4:      	mov	x1, x0
    53c8:      	mov	x0, #0x1                ; =1
    53cc:      	mov	x2, #0x1b               ; =27
    53d0:      	str	x0, [x19]
    53d4:      	str	x1, [x19, #0x8]
    53d8:      	str	x2, [x19, #0x10]
    53dc:      	ldr	x19, [sp, #0x40]
    53e0:      	ldr	x29, [sp]
    53e4:      	ldr	x30, [sp, #0x8]
    53e8:      	add	sp, sp, #0x50
    53ec:      	ret
    53f0:      	movz	x4, #0x0, lsl #48
    53f4:      	b	0x52d8 <_stogir.terminal.validate+0xcc>
    53f8:      	uxtb	w4, w4
    53fc:      	orr	x1, x4, xzr
    5400:      	cmp	x1, #0x60
    5404:      	cset	w3, eq
    5408:      	cmp	x1, #0x79
    540c:      	cset	w1, eq
    5410:      	uxtb	w16, w3
    5414:      	cmp	w16, wzr
    5418:      	b.ne	0x5438 <_stogir.terminal.validate+0x22c>
    541c:      	uxtb	w16, w1
    5420:      	cmp	w16, wzr
    5424:      	b.ne	0x5438 <_stogir.terminal.validate+0x22c>
    5428:      	mov	x19, x8
    542c:      	b	0x53b8 <_stogir.terminal.validate+0x1ac>
    5430:      	movz	x4, #0x0, lsl #48
    5434:      	b	0x52d0 <_stogir.terminal.validate+0xc4>
    5438:      	add	x16, sp, #0x10
    543c:      	ldr	w5, [x16]
    5440:      	ubfx	x5, x5, #8, #8
    5444:      	cmp	x5, #0x0
    5448:      	b.ne	0x5514 <_stogir.terminal.validate+0x308>
    544c:      	uxtb	w16, w3
    5450:      	cmp	w16, wzr
    5454:      	mov	x16, #0x1               ; =1
    5458:      	mov	x17, #0x3               ; =3
    545c:      	csel	x3, x16, x17, ne
    5460:      	lsr	w3, w3, #0
    5464:      	sxtw	x3, w3
    5468:      	ldr	x5, [x0, #0x78]
    546c:      	add	x2, x2, x5
    5470:      	ldr	w2, [x2]
    5474:      	sxtw	x2, w2
    5478:      	cmp	x2, x3
    547c:      	b.ne	0x551c <_stogir.terminal.validate+0x310>
    5480:      	uxtb	w16, w1
    5484:      	cmp	w16, wzr
    5488:      	b.eq	0x54e8 <_stogir.terminal.validate+0x2dc>
    548c:      	add	x16, sp, #0x10
    5490:      	ldr	w2, [x16, #0x8]
    5494:      	sxtw	x2, w2
    5498:      	cmp	x2, #0x0
    549c:      	b.eq	0x54e8 <_stogir.terminal.validate+0x2dc>
    54a0:      	mov	x19, x8
    54a4:      	b	0x53b8 <_stogir.terminal.validate+0x1ac>
    54a8:      	movz	x1, #0x0, lsl #48
    54ac:      	lsr	w2, w2, #0
    54b0:      	lsr	w4, w4, #0
    54b4:      	lsr	w1, w1, #0
    54b8:      	mov	w3, w1
    54bc:      	mov	w1, w4
    54c0:      	mov	x19, x8
    54c4:      	add	x8, sp, #0x20
    54c8:      	bl	0x54c8 <_stogir.terminal.validate+0x2bc>
		00000000000054c8:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    54cc:      	add	x16, sp, #0x20
    54d0:      	ldr	x0, [x16]
    54d4:      	add	x16, sp, #0x20
    54d8:      	ldr	x1, [x16, #0x8]
    54dc:      	add	x16, sp, #0x20
    54e0:      	ldr	x2, [x16, #0x10]
    54e4:      	b	0x53d0 <_stogir.terminal.validate+0x1c4>
    54e8:      	add	x16, sp, #0x10
    54ec:      	ldr	w2, [x16, #0x4]
    54f0:      	uxtb	w16, w1
    54f4:      	cmp	w16, wzr
    54f8:      	b.eq	0x54a8 <_stogir.terminal.validate+0x29c>
    54fc:      	add	x16, sp, #0x10
    5500:      	ldr	w1, [x16, #0xc]
    5504:      	sxtw	x1, w1
    5508:      	b	0x54ac <_stogir.terminal.validate+0x2a0>
    550c:      	brk	#0
    5510:      	b	0x550c <_stogir.terminal.validate+0x300>
    5514:      	mov	x19, x8
    5518:      	b	0x53b8 <_stogir.terminal.validate+0x1ac>
    551c:      	mov	x19, x8
    5520:      	b	0x53b8 <_stogir.terminal.validate+0x1ac>

0000000000005524 <_stogir.switch.operation?>:
    5524:      	sxtw	x0, w0
    5528:      	cmp	x0, #0x75
    552c:      	b.ne	0x5540 <_stogir.switch.operation?+0x1c>
    5530:      	mov	x0, #0x1                ; =1
    5534:      	b	0x553c <_stogir.switch.operation?+0x18>
    5538:      	movz	x0, #0x0, lsl #48
    553c:      	ret
    5540:      	cmp	x0, #0x6d
    5544:      	b.lt	0x5538 <_stogir.switch.operation?+0x14>
    5548:      	cmp	x0, #0x6f
    554c:      	cset	w0, le
    5550:      	ubfx	x0, x0, #0, #8
    5554:      	b	0x553c <_stogir.switch.operation?+0x18>

0000000000005558 <_stogir.switch.validate>:
    5558:      	sub	sp, sp, #0x70
    555c:      	str	x29, [sp]
    5560:      	str	x30, [sp, #0x8]
    5564:      	mov	x29, sp
    5568:      	str	x19, [sp, #0x60]
    556c:      	sxtw	x1, w1
    5570:      	lsl	x2, x1, #2
    5574:      	cmp	x1, #0x0
    5578:      	cset	w3, gt
    557c:      	movz	x16, #0x0, lsl #48
    5580:      	sub	x4, x16, x1
    5584:      	sub	x5, x4, #0x1
    5588:      	uxtb	w16, w3
    558c:      	cmp	w16, wzr
    5590:      	b.eq	0x55d0 <_stogir.switch.validate+0x78>
    5594:      	ldr	x4, [x0, #0x8]
    5598:      	cmp	x1, x4
    559c:      	b.ge	0x5620 <_stogir.switch.validate+0xc8>
    55a0:      	add	x4, x0, #0x78
    55a4:      	ldr	x4, [x4, #0x8]
    55a8:      	cmp	x1, x4
    55ac:      	b.ge	0x573c <_stogir.switch.validate+0x1e4>
    55b0:      	ldr	x4, [x0, #0x78]
    55b4:      	add	x4, x2, x4
    55b8:      	ldr	w4, [x4]
    55bc:      	sxtw	x4, w4
    55c0:      	cmp	x4, #0x0
    55c4:      	cset	w4, ge
    55c8:      	ubfx	x4, x4, #0, #8
    55cc:      	b	0x5740 <_stogir.switch.validate+0x1e8>
    55d0:      	cmp	x1, #0x0
    55d4:      	b.ge	0x5628 <_stogir.switch.validate+0xd0>
    55d8:      	add	x6, x0, #0x28
    55dc:      	add	x7, x0, #0x50
    55e0:      	ldr	x6, [x6, #0x8]
    55e4:      	ldr	x7, [x7, #0x8]
    55e8:      	cmp	x6, x7
    55ec:      	b.ne	0x5618 <_stogir.switch.validate+0xc0>
    55f0:      	cmp	x4, x6
    55f4:      	b.gt	0x5778 <_stogir.switch.validate+0x220>
    55f8:      	ldr	x4, [x0, #0x50]
    55fc:      	add	x4, x4, x5, lsl #2
    5600:      	ldr	w4, [x4]
    5604:      	sxtw	x4, w4
    5608:      	cmp	x4, #0x0
    560c:      	cset	w4, gt
    5610:      	ubfx	x4, x4, #0, #8
    5614:      	b	0x577c <_stogir.switch.validate+0x224>
    5618:      	movz	x4, #0x0, lsl #48
    561c:      	b	0x562c <_stogir.switch.validate+0xd4>
    5620:      	movz	x4, #0x0, lsl #48
    5624:      	b	0x562c <_stogir.switch.validate+0xd4>
    5628:      	movz	x4, #0x0, lsl #48
    562c:      	cmp	x4, #0x0
    5630:      	b.eq	0x568c <_stogir.switch.validate+0x134>
    5634:      	uxtb	w16, w3
    5638:      	cmp	w16, wzr
    563c:      	b.eq	0x5660 <_stogir.switch.validate+0x108>
    5640:      	ldr	x3, [x0]
    5644:      	add	x3, x3, x1, lsl #4
    5648:      	ldr	x4, [x3]
    564c:      	ldr	x3, [x3, #0x8]
    5650:      	fmov	d31, x3
    5654:      	mov	x3, x4
    5658:      	fmov	x4, d31
    565c:      	b	0x567c <_stogir.switch.validate+0x124>
    5660:      	ldr	x3, [x0, #0x28]
    5664:      	add	x3, x3, x5, lsl #4
    5668:      	ldr	x4, [x3]
    566c:      	ldr	x3, [x3, #0x8]
    5670:      	fmov	d31, x3
    5674:      	mov	x3, x4
    5678:      	fmov	x4, d31
    567c:      	mov	x5, x4
    5680:      	mov	x4, x3
    5684:      	mov	x3, #0x1                ; =1
    5688:      	b	0x5698 <_stogir.switch.validate+0x140>
    568c:      	movz	x3, #0x0, lsl #48
    5690:      	movz	x4, #0x0, lsl #48
    5694:      	movz	x5, #0x0, lsl #48
    5698:      	lsr	w3, w3, #0
    569c:      	lsr	x16, x3, #0
    56a0:      	cmp	x16, #0x1
    56a4:      	b.eq	0x56c0 <_stogir.switch.validate+0x168>
    56a8:      	b.lo	0x56b0 <_stogir.switch.validate+0x158>
    56ac:      	b	0x56c4 <_stogir.switch.validate+0x16c>
    56b0:      	cmp	x16, #0x0
    56b4:      	b.eq	0x56bc <_stogir.switch.validate+0x164>
    56b8:      	b	0x56c4 <_stogir.switch.validate+0x16c>
    56bc:      	b	0x56c8 <_stogir.switch.validate+0x170>
    56c0:      	b	0x56e8 <_stogir.switch.validate+0x190>
    56c4:      	b	0x587c <_stogir.switch.validate+0x324>
    56c8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		00000000000056c8:  ARM64_RELOC_PAGE21	l_stogir.388
    56cc:      	ldr	x16, [x16]
		00000000000056cc:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    56d0:      	orr	x0, x16, xzr
    56d4:      	mov	x19, x8
    56d8:      	mov	x1, x0
    56dc:      	mov	x0, #0x1                ; =1
    56e0:      	mov	x2, #0x1a               ; =26
    56e4:      	b	0x571c <_stogir.switch.validate+0x1c4>
    56e8:      	add	x16, sp, #0x10
    56ec:      	str	x4, [x16]
    56f0:      	add	x16, sp, #0x10
    56f4:      	str	x5, [x16, #0x8]
    56f8:      	cmp	x1, #0x0
    56fc:      	b.gt	0x5744 <_stogir.switch.validate+0x1ec>
    5700:      	mov	x19, x8
    5704:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005704:  ARM64_RELOC_PAGE21	l_stogir.389
    5708:      	ldr	x16, [x16]
		0000000000005708:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    570c:      	orr	x0, x16, xzr
    5710:      	mov	x1, x0
    5714:      	mov	x0, #0x1                ; =1
    5718:      	mov	x2, #0x20               ; =32
    571c:      	str	x0, [x19]
    5720:      	str	x1, [x19, #0x8]
    5724:      	str	x2, [x19, #0x10]
    5728:      	ldr	x19, [sp, #0x60]
    572c:      	ldr	x29, [sp]
    5730:      	ldr	x30, [sp, #0x8]
    5734:      	add	sp, sp, #0x70
    5738:      	ret
    573c:      	movz	x4, #0x0, lsl #48
    5740:      	b	0x5624 <_stogir.switch.validate+0xcc>
    5744:      	uxtb	w4, w4
    5748:      	orr	x1, x4, xzr
    574c:      	cmp	x1, #0x75
    5750:      	cset	w3, eq
    5754:      	uxtb	w16, w3
    5758:      	cmp	w16, wzr
    575c:      	b.ne	0x5780 <_stogir.switch.validate+0x228>
    5760:      	cmp	x1, #0x6d
    5764:      	b.lt	0x5884 <_stogir.switch.validate+0x32c>
    5768:      	cmp	x1, #0x6f
    576c:      	b.le	0x5780 <_stogir.switch.validate+0x228>
    5770:      	mov	x19, x8
    5774:      	b	0x5704 <_stogir.switch.validate+0x1ac>
    5778:      	movz	x4, #0x0, lsl #48
    577c:      	b	0x561c <_stogir.switch.validate+0xc4>
    5780:      	add	x16, sp, #0x10
    5784:      	ldr	w5, [x16]
    5788:      	ubfx	x5, x5, #8, #8
    578c:      	cmp	x5, #0x0
    5790:      	b.ne	0x588c <_stogir.switch.validate+0x334>
    5794:      	ldr	x5, [x0, #0x78]
    5798:      	add	x2, x2, x5
    579c:      	ldr	w2, [x2]
    57a0:      	cmp	x1, #0x6d
    57a4:      	b.eq	0x5818 <_stogir.switch.validate+0x2c0>
    57a8:      	cmp	x1, #0x6e
    57ac:      	b.eq	0x5818 <_stogir.switch.validate+0x2c0>
    57b0:      	mov	x1, #0x2                ; =2
    57b4:      	b	0x581c <_stogir.switch.validate+0x2c4>
    57b8:      	lsr	w4, w4, #0
    57bc:      	add	x16, sp, #0x10
    57c0:      	ldr	w1, [x16, #0x4]
    57c4:      	add	x16, sp, #0x10
    57c8:      	ldr	w2, [x16, #0x8]
    57cc:      	lsr	w1, w1, #0
    57d0:      	add	x16, sp, #0x10
    57d4:      	ldr	w3, [x16, #0xc]
    57d8:      	lsr	w2, w2, #0
    57dc:      	lsr	w3, w3, #0
    57e0:      	add	x8, sp, #0x40
    57e4:      	fmov	s31, w1
    57e8:      	mov	w1, w4
    57ec:      	mov	w4, w3
    57f0:      	mov	w3, w2
    57f4:      	fmov	w2, s31
    57f8:      	bl	0x57f8 <_stogir.switch.validate+0x2a0>
		00000000000057f8:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    57fc:      	add	x16, sp, #0x40
    5800:      	ldr	x0, [x16]
    5804:      	add	x16, sp, #0x40
    5808:      	ldr	x1, [x16, #0x8]
    580c:      	add	x16, sp, #0x40
    5810:      	ldr	x2, [x16, #0x10]
    5814:      	b	0x571c <_stogir.switch.validate+0x1c4>
    5818:      	mov	x1, #0x3                ; =3
    581c:      	sxtw	x2, w2
    5820:      	lsr	w1, w1, #0
    5824:      	sxtw	x1, w1
    5828:      	cmp	x2, x1
    582c:      	b.ne	0x5894 <_stogir.switch.validate+0x33c>
    5830:      	uxtb	w16, w3
    5834:      	cmp	w16, wzr
    5838:      	b.eq	0x589c <_stogir.switch.validate+0x344>
    583c:      	add	x16, sp, #0x10
    5840:      	ldr	w1, [x16, #0x4]
    5844:      	add	x16, sp, #0x10
    5848:      	ldr	w2, [x16, #0x8]
    584c:      	lsr	w1, w1, #0
    5850:      	lsr	w2, w2, #0
    5854:      	mov	x19, x8
    5858:      	add	x8, sp, #0x20
    585c:      	bl	0x585c <_stogir.switch.validate+0x304>
		000000000000585c:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5860:      	add	x16, sp, #0x20
    5864:      	ldr	x0, [x16]
    5868:      	add	x16, sp, #0x20
    586c:      	ldr	x1, [x16, #0x8]
    5870:      	add	x16, sp, #0x20
    5874:      	ldr	x2, [x16, #0x10]
    5878:      	b	0x5814 <_stogir.switch.validate+0x2bc>
    587c:      	brk	#0
    5880:      	b	0x587c <_stogir.switch.validate+0x324>
    5884:      	mov	x19, x8
    5888:      	b	0x5704 <_stogir.switch.validate+0x1ac>
    588c:      	mov	x19, x8
    5890:      	b	0x5704 <_stogir.switch.validate+0x1ac>
    5894:      	mov	x19, x8
    5898:      	b	0x5704 <_stogir.switch.validate+0x1ac>
    589c:      	mov	x19, x8
    58a0:      	b	0x57b8 <_stogir.switch.validate+0x260>

00000000000058a4 <_stogir.stack.operation?>:
    58a4:      	sxtw	x0, w0
    58a8:      	cmp	x0, #0x42
    58ac:      	b.ne	0x58c8 <_stogir.stack.operation?+0x24>
    58b0:      	mov	x0, #0x1                ; =1
    58b4:      	b	0x58c4 <_stogir.stack.operation?+0x20>
    58b8:      	cmp	x0, #0x54
    58bc:      	cset	w0, eq
    58c0:      	ubfx	x0, x0, #0, #8
    58c4:      	ret
    58c8:      	cmp	x0, #0x51
    58cc:      	b.ne	0x58d8 <_stogir.stack.operation?+0x34>
    58d0:      	mov	x0, #0x1                ; =1
    58d4:      	b	0x58c4 <_stogir.stack.operation?+0x20>
    58d8:      	cmp	x0, #0x52
    58dc:      	b.ne	0x58e8 <_stogir.stack.operation?+0x44>
    58e0:      	mov	x0, #0x1                ; =1
    58e4:      	b	0x58c4 <_stogir.stack.operation?+0x20>
    58e8:      	cmp	x0, #0x53
    58ec:      	b.ne	0x58b8 <_stogir.stack.operation?+0x14>
    58f0:      	mov	x0, #0x1                ; =1
    58f4:      	b	0x58c4 <_stogir.stack.operation?+0x20>

00000000000058f8 <_stogir.stack.validate>:
    58f8:      	sub	sp, sp, #0x90
    58fc:      	str	x29, [sp]
    5900:      	str	x30, [sp, #0x8]
    5904:      	mov	x29, sp
    5908:      	str	x19, [sp, #0x60]
    590c:      	str	x20, [sp, #0x68]
    5910:      	str	x21, [sp, #0x70]
    5914:      	str	x22, [sp, #0x78]
    5918:      	str	x23, [sp, #0x80]
    591c:      	sxtw	x1, w1
    5920:      	lsl	x2, x1, #2
    5924:      	cmp	x1, #0x0
    5928:      	cset	w3, gt
    592c:      	movz	x16, #0x0, lsl #48
    5930:      	sub	x4, x16, x1
    5934:      	cmp	x1, #0x0
    5938:      	cset	w5, lt
    593c:      	sub	x6, x4, #0x1
    5940:      	lsl	x7, x6, #2
    5944:      	uxtb	w16, w3
    5948:      	cmp	w16, wzr
    594c:      	b.eq	0x598c <_stogir.stack.validate+0x94>
    5950:      	ldr	x9, [x0, #0x8]
    5954:      	cmp	x1, x9
    5958:      	b.ge	0x5a0c <_stogir.stack.validate+0x114>
    595c:      	add	x9, x0, #0x78
    5960:      	ldr	x9, [x9, #0x8]
    5964:      	cmp	x1, x9
    5968:      	b.ge	0x5b78 <_stogir.stack.validate+0x280>
    596c:      	ldr	x9, [x0, #0x78]
    5970:      	add	x9, x2, x9
    5974:      	ldr	w9, [x9]
    5978:      	sxtw	x9, w9
    597c:      	cmp	x9, #0x0
    5980:      	cset	w9, ge
    5984:      	ubfx	x9, x9, #0, #8
    5988:      	b	0x5b7c <_stogir.stack.validate+0x284>
    598c:      	uxtb	w16, w5
    5990:      	cmp	w16, wzr
    5994:      	b.eq	0x5a14 <_stogir.stack.validate+0x11c>
    5998:      	add	x9, x0, #0x28
    599c:      	add	x10, x0, #0x50
    59a0:      	ldr	x9, [x9, #0x8]
    59a4:      	ldr	x10, [x10, #0x8]
    59a8:      	cmp	x9, x10
    59ac:      	b.ne	0x59d8 <_stogir.stack.validate+0xe0>
    59b0:      	cmp	x4, x9
    59b4:      	b.gt	0x5b80 <_stogir.stack.validate+0x288>
    59b8:      	ldr	x9, [x0, #0x50]
    59bc:      	add	x9, x7, x9
    59c0:      	ldr	w9, [x9]
    59c4:      	sxtw	x9, w9
    59c8:      	cmp	x9, #0x0
    59cc:      	cset	w9, gt
    59d0:      	ubfx	x9, x9, #0, #8
    59d4:      	b	0x5b84 <_stogir.stack.validate+0x28c>
    59d8:      	movz	x9, #0x0, lsl #48
    59dc:      	b	0x5a18 <_stogir.stack.validate+0x120>
    59e0:      	uxtb	w16, w9
    59e4:      	cmp	w16, wzr
    59e8:      	b.eq	0x5ba8 <_stogir.stack.validate+0x2b0>
    59ec:      	mov	x22, x8
    59f0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		00000000000059f0:  ARM64_RELOC_PAGE21	l_stogir.390
    59f4:      	ldr	x16, [x16]
		00000000000059f4:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    59f8:      	orr	x0, x16, xzr
    59fc:      	mov	x1, x0
    5a00:      	mov	x0, #0x1                ; =1
    5a04:      	mov	x2, #0x19               ; =25
    5a08:      	b	0x5ad8 <_stogir.stack.validate+0x1e0>
    5a0c:      	movz	x9, #0x0, lsl #48
    5a10:      	b	0x5a18 <_stogir.stack.validate+0x120>
    5a14:      	movz	x9, #0x0, lsl #48
    5a18:      	lsl	x10, x1, #4
    5a1c:      	lsl	x6, x6, #4
    5a20:      	cmp	x9, #0x0
    5a24:      	b.eq	0x5a80 <_stogir.stack.validate+0x188>
    5a28:      	uxtb	w16, w3
    5a2c:      	cmp	w16, wzr
    5a30:      	b.eq	0x5a54 <_stogir.stack.validate+0x15c>
    5a34:      	ldr	x9, [x0]
    5a38:      	add	x9, x10, x9
    5a3c:      	ldr	x11, [x9]
    5a40:      	ldr	x9, [x9, #0x8]
    5a44:      	fmov	d31, x9
    5a48:      	mov	x9, x11
    5a4c:      	fmov	x11, d31
    5a50:      	b	0x5a70 <_stogir.stack.validate+0x178>
    5a54:      	ldr	x9, [x0, #0x28]
    5a58:      	add	x9, x6, x9
    5a5c:      	ldr	x11, [x9]
    5a60:      	ldr	x9, [x9, #0x8]
    5a64:      	fmov	d31, x9
    5a68:      	mov	x9, x11
    5a6c:      	fmov	x11, d31
    5a70:      	mov	x12, x11
    5a74:      	mov	x11, x9
    5a78:      	mov	x9, #0x1                ; =1
    5a7c:      	b	0x5a8c <_stogir.stack.validate+0x194>
    5a80:      	movz	x9, #0x0, lsl #48
    5a84:      	movz	x11, #0x0, lsl #48
    5a88:      	movz	x12, #0x0, lsl #48
    5a8c:      	lsr	w9, w9, #0
    5a90:      	lsr	x16, x9, #0
    5a94:      	cmp	x16, #0x1
    5a98:      	b.eq	0x5ab4 <_stogir.stack.validate+0x1bc>
    5a9c:      	b.lo	0x5aa4 <_stogir.stack.validate+0x1ac>
    5aa0:      	b	0x5ab8 <_stogir.stack.validate+0x1c0>
    5aa4:      	cmp	x16, #0x0
    5aa8:      	b.eq	0x5ab0 <_stogir.stack.validate+0x1b8>
    5aac:      	b	0x5ab8 <_stogir.stack.validate+0x1c0>
    5ab0:      	b	0x5abc <_stogir.stack.validate+0x1c4>
    5ab4:      	b	0x5b08 <_stogir.stack.validate+0x210>
    5ab8:      	b	0x5f00 <_stogir.stack.validate+0x608>
    5abc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005abc:  ARM64_RELOC_PAGE21	l_stogir.391
    5ac0:      	ldr	x16, [x16]
		0000000000005ac0:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    5ac4:      	orr	x0, x16, xzr
    5ac8:      	mov	x22, x8
    5acc:      	mov	x1, x0
    5ad0:      	mov	x0, #0x1                ; =1
    5ad4:      	mov	x2, #0x19               ; =25
    5ad8:      	str	x0, [x22]
    5adc:      	str	x1, [x22, #0x8]
    5ae0:      	str	x2, [x22, #0x10]
    5ae4:      	ldr	x19, [sp, #0x60]
    5ae8:      	ldr	x20, [sp, #0x68]
    5aec:      	ldr	x21, [sp, #0x70]
    5af0:      	ldr	x22, [sp, #0x78]
    5af4:      	ldr	x23, [sp, #0x80]
    5af8:      	ldr	x29, [sp]
    5afc:      	ldr	x30, [sp, #0x8]
    5b00:      	add	sp, sp, #0x90
    5b04:      	ret
    5b08:      	cmp	x1, #0x0
    5b0c:      	cset	w9, le
    5b10:      	uxtb	w19, w11
    5b14:      	add	x16, sp, #0x10
    5b18:      	str	x11, [x16]
    5b1c:      	orr	x11, x19, xzr
    5b20:      	add	x16, sp, #0x10
    5b24:      	str	x12, [x16, #0x8]
    5b28:      	cmp	x11, #0x42
    5b2c:      	b.ne	0x59e0 <_stogir.stack.validate+0xe8>
    5b30:      	uxtb	w16, w3
    5b34:      	cmp	w16, wzr
    5b38:      	b.eq	0x5bf4 <_stogir.stack.validate+0x2fc>
    5b3c:      	ldr	x4, [x0, #0x8]
    5b40:      	cmp	x1, x4
    5b44:      	b.ge	0x5c40 <_stogir.stack.validate+0x348>
    5b48:      	add	x4, x0, #0x78
    5b4c:      	ldr	x4, [x4, #0x8]
    5b50:      	cmp	x1, x4
    5b54:      	b.ge	0x5d34 <_stogir.stack.validate+0x43c>
    5b58:      	ldr	x1, [x0, #0x78]
    5b5c:      	add	x1, x2, x1
    5b60:      	ldr	w1, [x1]
    5b64:      	sxtw	x1, w1
    5b68:      	cmp	x1, #0x0
    5b6c:      	cset	w1, ge
    5b70:      	ubfx	x1, x1, #0, #8
    5b74:      	b	0x5d38 <_stogir.stack.validate+0x440>
    5b78:      	movz	x9, #0x0, lsl #48
    5b7c:      	b	0x5a10 <_stogir.stack.validate+0x118>
    5b80:      	movz	x9, #0x0, lsl #48
    5b84:      	b	0x59dc <_stogir.stack.validate+0xe4>
    5b88:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005b88:  ARM64_RELOC_PAGE21	l_stogir.392
    5b8c:      	ldr	x16, [x16]
		0000000000005b8c:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    5b90:      	orr	x0, x16, xzr
    5b94:      	mov	x1, x0
    5b98:      	mov	x0, #0x1                ; =1
    5b9c:      	mov	x2, #0x1e               ; =30
    5ba0:      	mov	x22, x8
    5ba4:      	b	0x5a08 <_stogir.stack.validate+0x110>
    5ba8:      	cmp	x11, #0x51
    5bac:      	cset	w1, eq
    5bb0:      	cmp	x11, #0x53
    5bb4:      	cset	w20, eq
    5bb8:      	cmp	x11, #0x54
    5bbc:      	cset	w21, eq
    5bc0:      	uxtb	w16, w1
    5bc4:      	cmp	w16, wzr
    5bc8:      	b.ne	0x5d3c <_stogir.stack.validate+0x444>
    5bcc:      	cmp	x11, #0x52
    5bd0:      	b.eq	0x5d3c <_stogir.stack.validate+0x444>
    5bd4:      	uxtb	w16, w20
    5bd8:      	cmp	w16, wzr
    5bdc:      	b.ne	0x5d3c <_stogir.stack.validate+0x444>
    5be0:      	uxtb	w16, w21
    5be4:      	cmp	w16, wzr
    5be8:      	b.ne	0x5d3c <_stogir.stack.validate+0x444>
    5bec:      	mov	x22, x8
    5bf0:      	b	0x59f0 <_stogir.stack.validate+0xf8>
    5bf4:      	uxtb	w16, w5
    5bf8:      	cmp	w16, wzr
    5bfc:      	b.eq	0x5c48 <_stogir.stack.validate+0x350>
    5c00:      	add	x1, x0, #0x28
    5c04:      	add	x5, x0, #0x50
    5c08:      	ldr	x1, [x1, #0x8]
    5c0c:      	ldr	x5, [x5, #0x8]
    5c10:      	cmp	x1, x5
    5c14:      	b.ne	0x5d2c <_stogir.stack.validate+0x434>
    5c18:      	cmp	x4, x1
    5c1c:      	b.gt	0x5e98 <_stogir.stack.validate+0x5a0>
    5c20:      	ldr	x1, [x0, #0x50]
    5c24:      	add	x1, x7, x1
    5c28:      	ldr	w1, [x1]
    5c2c:      	sxtw	x1, w1
    5c30:      	cmp	x1, #0x0
    5c34:      	cset	w1, gt
    5c38:      	ubfx	x1, x1, #0, #8
    5c3c:      	b	0x5e9c <_stogir.stack.validate+0x5a4>
    5c40:      	movz	x1, #0x0, lsl #48
    5c44:      	b	0x5c4c <_stogir.stack.validate+0x354>
    5c48:      	movz	x1, #0x0, lsl #48
    5c4c:      	cmp	x1, #0x0
    5c50:      	b.eq	0x5c88 <_stogir.stack.validate+0x390>
    5c54:      	uxtb	w16, w3
    5c58:      	cmp	w16, wzr
    5c5c:      	b.eq	0x5c70 <_stogir.stack.validate+0x378>
    5c60:      	ldr	x1, [x0]
    5c64:      	add	x1, x10, x1
    5c68:      	ldr	x1, [x1]
    5c6c:      	b	0x5c7c <_stogir.stack.validate+0x384>
    5c70:      	ldr	x1, [x0, #0x28]
    5c74:      	add	x1, x6, x1
    5c78:      	ldr	x1, [x1]
    5c7c:      	mov	x3, x1
    5c80:      	mov	x1, #0x1                ; =1
    5c84:      	b	0x5c90 <_stogir.stack.validate+0x398>
    5c88:      	movz	x1, #0x0, lsl #48
    5c8c:      	movz	x3, #0x0, lsl #48
    5c90:      	lsr	w1, w1, #0
    5c94:      	lsr	x16, x1, #0
    5c98:      	cmp	x16, #0x1
    5c9c:      	b.eq	0x5cb8 <_stogir.stack.validate+0x3c0>
    5ca0:      	b.lo	0x5ca8 <_stogir.stack.validate+0x3b0>
    5ca4:      	b	0x5cbc <_stogir.stack.validate+0x3c4>
    5ca8:      	cmp	x16, #0x0
    5cac:      	b.eq	0x5cb4 <_stogir.stack.validate+0x3bc>
    5cb0:      	b	0x5cbc <_stogir.stack.validate+0x3c4>
    5cb4:      	b	0x5cc0 <_stogir.stack.validate+0x3c8>
    5cb8:      	b	0x5cdc <_stogir.stack.validate+0x3e4>
    5cbc:      	b	0x5f08 <_stogir.stack.validate+0x610>
    5cc0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005cc0:  ARM64_RELOC_PAGE21	l_stogir.393
    5cc4:      	ldr	x16, [x16]
		0000000000005cc4:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    5cc8:      	orr	x0, x16, xzr
    5ccc:      	mov	x1, x0
    5cd0:      	mov	x0, #0x1                ; =1
    5cd4:      	mov	x2, #0x21               ; =33
    5cd8:      	b	0x5ba0 <_stogir.stack.validate+0x2a8>
    5cdc:      	uxtb	w16, w9
    5ce0:      	cmp	w16, wzr
    5ce4:      	b.ne	0x5b88 <_stogir.stack.validate+0x290>
    5ce8:      	uxtb	w1, w3
    5cec:      	cmp	x1, #0x42
    5cf0:      	b.ne	0x5b88 <_stogir.stack.validate+0x290>
    5cf4:      	lsr	w3, w3, #0
    5cf8:      	ubfx	x1, x3, #8, #8
    5cfc:      	cmp	x1, #0x6
    5d00:      	b.ne	0x5b88 <_stogir.stack.validate+0x290>
    5d04:      	ldr	x0, [x0, #0x78]
    5d08:      	add	x0, x2, x0
    5d0c:      	ldr	w0, [x0]
    5d10:      	sxtw	x0, w0
    5d14:      	cmp	x0, #0x0
    5d18:      	b.ne	0x5b88 <_stogir.stack.validate+0x290>
    5d1c:      	movz	x0, #0x0, lsl #48
    5d20:      	mov	x1, #0x8                ; =8
    5d24:      	movz	x2, #0x0, lsl #48
    5d28:      	b	0x5ba0 <_stogir.stack.validate+0x2a8>
    5d2c:      	movz	x1, #0x0, lsl #48
    5d30:      	b	0x5c4c <_stogir.stack.validate+0x354>
    5d34:      	movz	x1, #0x0, lsl #48
    5d38:      	b	0x5c44 <_stogir.stack.validate+0x34c>
    5d3c:      	ldr	x3, [x0, #0x78]
    5d40:      	add	x2, x2, x3
    5d44:      	ldr	w2, [x2]
    5d48:      	uxtb	w16, w1
    5d4c:      	cmp	w16, wzr
    5d50:      	b.eq	0x5dbc <_stogir.stack.validate+0x4c4>
    5d54:      	mov	x1, #0x3                ; =3
    5d58:      	b	0x5dd0 <_stogir.stack.validate+0x4d8>
    5d5c:      	add	x16, sp, #0x10
    5d60:      	ldr	w0, [x16]
    5d64:      	add	x16, sp, #0x10
    5d68:      	ldr	w1, [x16, #0x4]
    5d6c:      	add	x16, sp, #0x10
    5d70:      	ldr	w2, [x16, #0x8]
    5d74:      	lsr	w1, w1, #0
    5d78:      	ubfx	x0, x0, #8, #8
    5d7c:      	lsr	w2, w2, #0
    5d80:      	lsr	w0, w0, #0
    5d84:      	add	x8, sp, #0x20
    5d88:      	mov	w3, w1
    5d8c:      	mov	w1, w19
    5d90:      	mov	w4, w2
    5d94:      	mov	w2, w0
    5d98:      	mov	x0, x23
    5d9c:      	bl	0x5d9c <_stogir.stack.validate+0x4a4>
		0000000000005d9c:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    5da0:      	add	x16, sp, #0x20
    5da4:      	ldr	x0, [x16]
    5da8:      	add	x16, sp, #0x20
    5dac:      	ldr	x1, [x16, #0x8]
    5db0:      	add	x16, sp, #0x20
    5db4:      	ldr	x2, [x16, #0x10]
    5db8:      	b	0x5a08 <_stogir.stack.validate+0x110>
    5dbc:      	uxtb	w16, w20
    5dc0:      	cmp	w16, wzr
    5dc4:      	mov	x16, #0x1               ; =1
    5dc8:      	mov	x17, #0x2               ; =2
    5dcc:      	csel	x1, x16, x17, ne
    5dd0:      	sxtw	x2, w2
    5dd4:      	lsr	w1, w1, #0
    5dd8:      	sxtw	x1, w1
    5ddc:      	cmp	x2, x1
    5de0:      	b.ne	0x5f10 <_stogir.stack.validate+0x618>
    5de4:      	add	x16, sp, #0x10
    5de8:      	ldr	w1, [x16]
    5dec:      	orr	x2, x1, xzr
    5df0:      	ubfx	x2, x2, #16, #16
    5df4:      	and	x2, x2, #0x8000
    5df8:      	uxth	w2, w2
    5dfc:      	cmp	x2, #0x0
    5e00:      	b.ne	0x5ea0 <_stogir.stack.validate+0x5a8>
    5e04:      	mov	x22, x8
    5e08:      	mov	x23, x0
    5e0c:      	lsr	w19, w19, #0
    5e10:      	uxtb	w16, w20
    5e14:      	cmp	w16, wzr
    5e18:      	b.ne	0x5d5c <_stogir.stack.validate+0x464>
    5e1c:      	uxtb	w16, w21
    5e20:      	cmp	w16, wzr
    5e24:      	b.ne	0x5d5c <_stogir.stack.validate+0x464>
    5e28:      	add	x16, sp, #0x10
    5e2c:      	ldr	w0, [x16]
    5e30:      	add	x16, sp, #0x10
    5e34:      	ldr	w1, [x16, #0x4]
    5e38:      	add	x16, sp, #0x10
    5e3c:      	ldr	w2, [x16, #0x8]
    5e40:      	lsr	w1, w1, #0
    5e44:      	ubfx	x0, x0, #8, #8
    5e48:      	add	x16, sp, #0x10
    5e4c:      	ldr	w3, [x16, #0xc]
    5e50:      	lsr	w2, w2, #0
    5e54:      	lsr	w3, w3, #0
    5e58:      	lsr	w0, w0, #0
    5e5c:      	add	x8, sp, #0x40
    5e60:      	mov	w4, w2
    5e64:      	mov	w2, w0
    5e68:      	mov	x0, x23
    5e6c:      	mov	w5, w3
    5e70:      	mov	w3, w1
    5e74:      	mov	w1, w19
    5e78:      	bl	0x5e78 <_stogir.stack.validate+0x580>
		0000000000005e78:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    5e7c:      	add	x16, sp, #0x40
    5e80:      	ldr	x0, [x16]
    5e84:      	add	x16, sp, #0x40
    5e88:      	ldr	x1, [x16, #0x8]
    5e8c:      	add	x16, sp, #0x40
    5e90:      	ldr	x2, [x16, #0x10]
    5e94:      	b	0x5db8 <_stogir.stack.validate+0x4c0>
    5e98:      	movz	x1, #0x0, lsl #48
    5e9c:      	b	0x5d30 <_stogir.stack.validate+0x438>
    5ea0:      	uxtb	w2, w1
    5ea4:      	cmp	x2, #0x51
    5ea8:      	b.ne	0x5f18 <_stogir.stack.validate+0x620>
    5eac:      	ubfx	x1, x1, #16, #16
    5eb0:      	cmp	x1, #0x8, lsl #12       ; =0x8000
    5eb4:      	b.ne	0x5f20 <_stogir.stack.validate+0x628>
    5eb8:      	add	x16, sp, #0x10
    5ebc:      	ldr	w1, [x16, #0x4]
    5ec0:      	add	x16, sp, #0x10
    5ec4:      	ldr	w2, [x16, #0x8]
    5ec8:      	lsr	w1, w1, #0
    5ecc:      	lsr	w2, w2, #0
    5ed0:      	mov	x22, x8
    5ed4:      	mov	x23, x0
    5ed8:      	bl	0x5ed8 <_stogir.stack.validate+0x5e0>
		0000000000005ed8:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    5edc:      	cmp	x0, #0x0
    5ee0:      	b.ne	0x5e0c <_stogir.stack.validate+0x514>
    5ee4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x70c>
		0000000000005ee4:  ARM64_RELOC_PAGE21	l_stogir.394
    5ee8:      	ldr	x16, [x16]
		0000000000005ee8:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    5eec:      	orr	x0, x16, xzr
    5ef0:      	mov	x1, x0
    5ef4:      	mov	x0, #0x1                ; =1
    5ef8:      	mov	x2, #0x26               ; =38
    5efc:      	b	0x5db8 <_stogir.stack.validate+0x4c0>
    5f00:      	brk	#0
    5f04:      	b	0x5f00 <_stogir.stack.validate+0x608>
    5f08:      	brk	#0
    5f0c:      	b	0x5f08 <_stogir.stack.validate+0x610>
    5f10:      	mov	x22, x8
    5f14:      	b	0x59f0 <_stogir.stack.validate+0xf8>
    5f18:      	mov	x22, x8
    5f1c:      	b	0x5ee4 <_stogir.stack.validate+0x5ec>
    5f20:      	mov	x22, x8
    5f24:      	b	0x5ee4 <_stogir.stack.validate+0x5ec>

0000000000005f28 <_stogir.locals.operation?>:
    5f28:      	sxtw	x0, w0
    5f2c:      	cmp	x0, #0x41
    5f30:      	b.ne	0x5f44 <_stogir.locals.operation?+0x1c>
    5f34:      	mov	x0, #0x1                ; =1
    5f38:      	b	0x5f40 <_stogir.locals.operation?+0x18>
    5f3c:      	movz	x0, #0x0, lsl #48
    5f40:      	ret
    5f44:      	cmp	x0, #0x48
    5f48:      	b.ne	0x5f54 <_stogir.locals.operation?+0x2c>
    5f4c:      	mov	x0, #0x1                ; =1
    5f50:      	b	0x5f40 <_stogir.locals.operation?+0x18>
    5f54:      	cmp	x0, #0x55
    5f58:      	b.lt	0x5f3c <_stogir.locals.operation?+0x14>
    5f5c:      	cmp	x0, #0x58
    5f60:      	cset	w0, le
    5f64:      	ubfx	x0, x0, #0, #8
    5f68:      	b	0x5f40 <_stogir.locals.operation?+0x18>

0000000000005f6c <_stogir.locals.validate>:
    5f6c:      	sub	sp, sp, #0xb0
    5f70:      	str	x29, [sp]
    5f74:      	str	x30, [sp, #0x8]
    5f78:      	mov	x29, sp
    5f7c:      	str	x19, [sp, #0x70]
    5f80:      	str	x20, [sp, #0x78]
    5f84:      	str	x21, [sp, #0x80]
    5f88:      	str	x22, [sp, #0x88]
    5f8c:      	str	x23, [sp, #0x90]
    5f90:      	str	x24, [sp, #0x98]
    5f94:      	str	x25, [sp, #0xa0]
    5f98:      	sxtw	x1, w1
    5f9c:      	lsl	x3, x1, #2
    5fa0:      	cmp	x1, #0x0
    5fa4:      	cset	w4, gt
    5fa8:      	movz	x16, #0x0, lsl #48
    5fac:      	sub	x5, x16, x1
    5fb0:      	sub	x6, x5, #0x1
    5fb4:      	uxtb	w16, w4
    5fb8:      	cmp	w16, wzr
    5fbc:      	b.eq	0x5ffc <_stogir.locals.validate+0x90>
    5fc0:      	ldr	x5, [x0, #0x8]
    5fc4:      	cmp	x1, x5
    5fc8:      	b.ge	0x6098 <_stogir.locals.validate+0x12c>
    5fcc:      	add	x5, x0, #0x78
    5fd0:      	ldr	x5, [x5, #0x8]
    5fd4:      	cmp	x1, x5
    5fd8:      	b.ge	0x61b8 <_stogir.locals.validate+0x24c>
    5fdc:      	ldr	x5, [x0, #0x78]
    5fe0:      	add	x5, x3, x5
    5fe4:      	ldr	w5, [x5]
    5fe8:      	sxtw	x5, w5
    5fec:      	cmp	x5, #0x0
    5ff0:      	cset	w5, ge
    5ff4:      	ubfx	x5, x5, #0, #8
    5ff8:      	b	0x61bc <_stogir.locals.validate+0x250>
    5ffc:      	cmp	x1, #0x0
    6000:      	b.ge	0x60a0 <_stogir.locals.validate+0x134>
    6004:      	add	x7, x0, #0x28
    6008:      	add	x9, x0, #0x50
    600c:      	ldr	x7, [x7, #0x8]
    6010:      	ldr	x9, [x9, #0x8]
    6014:      	cmp	x7, x9
    6018:      	b.ne	0x6044 <_stogir.locals.validate+0xd8>
    601c:      	cmp	x5, x7
    6020:      	b.gt	0x6240 <_stogir.locals.validate+0x2d4>
    6024:      	ldr	x5, [x0, #0x50]
    6028:      	add	x5, x5, x6, lsl #2
    602c:      	ldr	w5, [x5]
    6030:      	sxtw	x5, w5
    6034:      	cmp	x5, #0x0
    6038:      	cset	w5, gt
    603c:      	ubfx	x5, x5, #0, #8
    6040:      	b	0x6244 <_stogir.locals.validate+0x2d8>
    6044:      	movz	x5, #0x0, lsl #48
    6048:      	b	0x60a4 <_stogir.locals.validate+0x138>
    604c:      	cmp	x5, #0x0
    6050:      	cset	w5, ne
    6054:      	uxtb	w16, w5
    6058:      	cmp	w16, wzr
    605c:      	mov	x16, #0x2               ; =2
    6060:      	mov	x17, #0x3               ; =3
    6064:      	csel	x5, x16, x17, ne
    6068:      	lsr	w5, w5, #0
    606c:      	sxtw	x5, w5
    6070:      	cmp	x1, #0x0
    6074:      	b.gt	0x61c0 <_stogir.locals.validate+0x254>
    6078:      	mov	x23, x8
    607c:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		000000000000607c:  ARM64_RELOC_PAGE21	l_stogir.395
    6080:      	ldr	x16, [x16]
		0000000000006080:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6084:      	orr	x0, x16, xzr
    6088:      	mov	x1, x0
    608c:      	mov	x0, #0x1                ; =1
    6090:      	mov	x2, #0x17               ; =23
    6094:      	b	0x615c <_stogir.locals.validate+0x1f0>
    6098:      	movz	x5, #0x0, lsl #48
    609c:      	b	0x60a4 <_stogir.locals.validate+0x138>
    60a0:      	movz	x5, #0x0, lsl #48
    60a4:      	cmp	x5, #0x0
    60a8:      	b.eq	0x6104 <_stogir.locals.validate+0x198>
    60ac:      	uxtb	w16, w4
    60b0:      	cmp	w16, wzr
    60b4:      	b.eq	0x60d8 <_stogir.locals.validate+0x16c>
    60b8:      	ldr	x4, [x0]
    60bc:      	add	x4, x4, x1, lsl #4
    60c0:      	ldr	x5, [x4]
    60c4:      	ldr	x4, [x4, #0x8]
    60c8:      	fmov	d31, x4
    60cc:      	mov	x4, x5
    60d0:      	fmov	x5, d31
    60d4:      	b	0x60f4 <_stogir.locals.validate+0x188>
    60d8:      	ldr	x4, [x0, #0x28]
    60dc:      	add	x4, x4, x6, lsl #4
    60e0:      	ldr	x5, [x4]
    60e4:      	ldr	x4, [x4, #0x8]
    60e8:      	fmov	d31, x4
    60ec:      	mov	x4, x5
    60f0:      	fmov	x5, d31
    60f4:      	mov	x6, x5
    60f8:      	mov	x5, x4
    60fc:      	mov	x4, #0x1                ; =1
    6100:      	b	0x6110 <_stogir.locals.validate+0x1a4>
    6104:      	movz	x4, #0x0, lsl #48
    6108:      	movz	x5, #0x0, lsl #48
    610c:      	movz	x6, #0x0, lsl #48
    6110:      	lsr	w4, w4, #0
    6114:      	lsr	x16, x4, #0
    6118:      	cmp	x16, #0x1
    611c:      	b.eq	0x6138 <_stogir.locals.validate+0x1cc>
    6120:      	b.lo	0x6128 <_stogir.locals.validate+0x1bc>
    6124:      	b	0x613c <_stogir.locals.validate+0x1d0>
    6128:      	cmp	x16, #0x0
    612c:      	b.eq	0x6134 <_stogir.locals.validate+0x1c8>
    6130:      	b	0x613c <_stogir.locals.validate+0x1d0>
    6134:      	b	0x6140 <_stogir.locals.validate+0x1d4>
    6138:      	b	0x6194 <_stogir.locals.validate+0x228>
    613c:      	b	0x6384 <_stogir.locals.validate+0x418>
    6140:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006140:  ARM64_RELOC_PAGE21	l_stogir.396
    6144:      	ldr	x16, [x16]
		0000000000006144:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6148:      	orr	x0, x16, xzr
    614c:      	mov	x23, x8
    6150:      	mov	x1, x0
    6154:      	mov	x0, #0x1                ; =1
    6158:      	mov	x2, #0x17               ; =23
    615c:      	str	x0, [x23]
    6160:      	str	x1, [x23, #0x8]
    6164:      	str	x2, [x23, #0x10]
    6168:      	ldr	x19, [sp, #0x70]
    616c:      	ldr	x20, [sp, #0x78]
    6170:      	ldr	x21, [sp, #0x80]
    6174:      	ldr	x22, [sp, #0x88]
    6178:      	ldr	x23, [sp, #0x90]
    617c:      	ldr	x24, [sp, #0x98]
    6180:      	ldr	x25, [sp, #0xa0]
    6184:      	ldr	x29, [sp]
    6188:      	ldr	x30, [sp, #0x8]
    618c:      	add	sp, sp, #0xb0
    6190:      	ret
    6194:      	uxtb	w4, w5
    6198:      	add	x16, sp, #0x10
    619c:      	str	x5, [x16]
    61a0:      	add	x16, sp, #0x10
    61a4:      	str	x6, [x16, #0x8]
    61a8:      	cmp	x4, #0x55
    61ac:      	b.ne	0x6224 <_stogir.locals.validate+0x2b8>
    61b0:      	mov	x5, #0x1                ; =1
    61b4:      	b	0x6230 <_stogir.locals.validate+0x2c4>
    61b8:      	movz	x5, #0x0, lsl #48
    61bc:      	b	0x609c <_stogir.locals.validate+0x130>
    61c0:      	cmp	x4, #0x48
    61c4:      	cset	w21, eq
    61c8:      	uxtb	w16, w20
    61cc:      	cmp	w16, wzr
    61d0:      	b.ne	0x6248 <_stogir.locals.validate+0x2dc>
    61d4:      	uxtb	w16, w21
    61d8:      	cmp	w16, wzr
    61dc:      	b.ne	0x6248 <_stogir.locals.validate+0x2dc>
    61e0:      	cmp	x4, #0x55
    61e4:      	b.lt	0x670c <_stogir.locals.validate+0x7a0>
    61e8:      	cmp	x4, #0x58
    61ec:      	b.le	0x6248 <_stogir.locals.validate+0x2dc>
    61f0:      	mov	x23, x8
    61f4:      	b	0x607c <_stogir.locals.validate+0x110>
    61f8:      	cmp	x4, #0x58
    61fc:      	cset	w6, eq
    6200:      	ubfx	x6, x6, #0, #8
    6204:      	mov	x19, x6
    6208:      	cmp	x4, #0x41
    620c:      	cset	w20, eq
    6210:      	uxtb	w16, w20
    6214:      	cmp	w16, wzr
    6218:      	b.eq	0x604c <_stogir.locals.validate+0xe0>
    621c:      	mov	x5, #0x1                ; =1
    6220:      	b	0x6070 <_stogir.locals.validate+0x104>
    6224:      	cmp	x4, #0x56
    6228:      	cset	w5, eq
    622c:      	ubfx	x5, x5, #0, #8
    6230:      	cmp	x4, #0x57
    6234:      	b.ne	0x61f8 <_stogir.locals.validate+0x28c>
    6238:      	mov	x19, #0x1               ; =1
    623c:      	b	0x6208 <_stogir.locals.validate+0x29c>
    6240:      	movz	x5, #0x0, lsl #48
    6244:      	b	0x6048 <_stogir.locals.validate+0xdc>
    6248:      	lsr	w5, w5, #0
    624c:      	sxtw	x5, w5
    6250:      	ldr	x4, [x0, #0x78]
    6254:      	add	x3, x3, x4
    6258:      	ldr	w3, [x3]
    625c:      	sxtw	x3, w3
    6260:      	cmp	x3, x5
    6264:      	b.ne	0x6714 <_stogir.locals.validate+0x7a8>
    6268:      	uxtb	w16, w20
    626c:      	cmp	w16, wzr
    6270:      	b.ne	0x6290 <_stogir.locals.validate+0x324>
    6274:      	uxtb	w16, w21
    6278:      	cmp	w16, wzr
    627c:      	b.ne	0x6290 <_stogir.locals.validate+0x324>
    6280:      	add	x16, sp, #0x10
    6284:      	ldr	w1, [x16, #0x8]
    6288:      	sxtw	x1, w1
    628c:      	b	0x62a8 <_stogir.locals.validate+0x33c>
    6290:      	uxtb	w16, w21
    6294:      	cmp	w16, wzr
    6298:      	b.ne	0x62a8 <_stogir.locals.validate+0x33c>
    629c:      	add	x16, sp, #0x10
    62a0:      	ldr	w1, [x16, #0x4]
    62a4:      	sxtw	x1, w1
    62a8:      	add	x16, sp, #0x20
    62ac:      	orr	x22, x16, xzr
    62b0:      	lsr	w2, w2, #0
    62b4:      	lsr	w1, w1, #0
    62b8:      	mov	x23, x8
    62bc:      	add	x8, sp, #0x20
    62c0:      	mov	x24, x0
    62c4:      	mov	w25, w2
    62c8:      	bl	0x62c8 <_stogir.locals.validate+0x35c>
		00000000000062c8:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    62cc:      	add	x16, sp, #0x20
    62d0:      	ldr	w0, [x16]
    62d4:      	lsr	x16, x0, #0
    62d8:      	cmp	x16, #0x1
    62dc:      	b.eq	0x62f8 <_stogir.locals.validate+0x38c>
    62e0:      	b.lo	0x62e8 <_stogir.locals.validate+0x37c>
    62e4:      	b	0x62fc <_stogir.locals.validate+0x390>
    62e8:      	cmp	x16, #0x0
    62ec:      	b.eq	0x62f4 <_stogir.locals.validate+0x388>
    62f0:      	b	0x62fc <_stogir.locals.validate+0x390>
    62f4:      	b	0x631c <_stogir.locals.validate+0x3b0>
    62f8:      	b	0x6300 <_stogir.locals.validate+0x394>
    62fc:      	b	0x656c <_stogir.locals.validate+0x600>
    6300:      	add	x0, x22, #0x8
    6304:      	add	x16, sp, #0x20
    6308:      	ldr	x1, [x16, #0x8]
    630c:      	ldr	x0, [x0, #0x8]
    6310:      	mov	x2, x0
    6314:      	mov	x0, #0x1                ; =1
    6318:      	b	0x6094 <_stogir.locals.validate+0x128>
    631c:      	add	x16, sp, #0x20
    6320:      	ldr	x22, [x16, #0x8]
    6324:      	uxtb	w16, w21
    6328:      	cmp	w16, wzr
    632c:      	b.eq	0x634c <_stogir.locals.validate+0x3e0>
    6330:      	lsr	w22, w22, #0
    6334:      	sxtw	x22, w22
    6338:      	and	x0, x22, #0xffffffff
    633c:      	mov	x1, x0
    6340:      	movz	x0, #0x0, lsl #48
    6344:      	movz	x2, #0x0, lsl #48
    6348:      	b	0x6318 <_stogir.locals.validate+0x3ac>
    634c:      	uxtb	w16, w20
    6350:      	cmp	w16, wzr
    6354:      	b.eq	0x63a8 <_stogir.locals.validate+0x43c>
    6358:      	add	x16, sp, #0x10
    635c:      	ldr	w0, [x16]
    6360:      	ubfx	x0, x0, #8, #8
    6364:      	cmp	x0, #0x6
    6368:      	b.ne	0x638c <_stogir.locals.validate+0x420>
    636c:      	sxtw	x25, w25
    6370:      	and	x0, x25, #0xffffffff
    6374:      	mov	x1, x0
    6378:      	movz	x0, #0x0, lsl #48
    637c:      	movz	x2, #0x0, lsl #48
    6380:      	b	0x63a4 <_stogir.locals.validate+0x438>
    6384:      	brk	#0
    6388:      	b	0x6384 <_stogir.locals.validate+0x418>
    638c:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		000000000000638c:  ARM64_RELOC_PAGE21	l_stogir.397
    6390:      	ldr	x16, [x16]
		0000000000006390:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    6394:      	orr	x0, x16, xzr
    6398:      	mov	x1, x0
    639c:      	mov	x0, #0x1                ; =1
    63a0:      	mov	x2, #0x21               ; =33
    63a4:      	b	0x6348 <_stogir.locals.validate+0x3dc>
    63a8:      	add	x16, sp, #0x10
    63ac:      	ldr	w0, [x16, #0x4]
    63b0:      	sxtw	x0, w0
    63b4:      	cmp	x0, #0x0
    63b8:      	cset	w1, gt
    63bc:      	movz	x16, #0x0, lsl #48
    63c0:      	sub	x2, x16, x0
    63c4:      	sub	x3, x2, #0x1
    63c8:      	uxtb	w16, w1
    63cc:      	cmp	w16, wzr
    63d0:      	b.eq	0x64ac <_stogir.locals.validate+0x540>
    63d4:      	ldr	x2, [x24, #0x8]
    63d8:      	cmp	x0, x2
    63dc:      	b.ge	0x64a4 <_stogir.locals.validate+0x538>
    63e0:      	add	x2, x24, #0x78
    63e4:      	ldr	x2, [x2, #0x8]
    63e8:      	cmp	x0, x2
    63ec:      	b.ge	0x655c <_stogir.locals.validate+0x5f0>
    63f0:      	ldr	x2, [x24, #0x78]
    63f4:      	add	x2, x2, x0, lsl #2
    63f8:      	ldr	w2, [x2]
    63fc:      	sxtw	x2, w2
    6400:      	cmp	x2, #0x0
    6404:      	cset	w2, ge
    6408:      	ubfx	x2, x2, #0, #8
    640c:      	b	0x6560 <_stogir.locals.validate+0x5f4>
    6410:      	movz	x0, #0x0, lsl #48
    6414:      	movz	x1, #0x0, lsl #48
    6418:      	lsr	w0, w0, #0
    641c:      	lsr	x16, x0, #0
    6420:      	cmp	x16, #0x1
    6424:      	b.eq	0x6440 <_stogir.locals.validate+0x4d4>
    6428:      	b.lo	0x6430 <_stogir.locals.validate+0x4c4>
    642c:      	b	0x6444 <_stogir.locals.validate+0x4d8>
    6430:      	cmp	x16, #0x0
    6434:      	b.eq	0x643c <_stogir.locals.validate+0x4d0>
    6438:      	b	0x6444 <_stogir.locals.validate+0x4d8>
    643c:      	b	0x6448 <_stogir.locals.validate+0x4dc>
    6440:      	b	0x64f4 <_stogir.locals.validate+0x588>
    6444:      	b	0x66dc <_stogir.locals.validate+0x770>
    6448:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006448:  ARM64_RELOC_PAGE21	l_stogir.398
    644c:      	ldr	x16, [x16]
		000000000000644c:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    6450:      	orr	x0, x16, xzr
    6454:      	mov	x1, x0
    6458:      	mov	x0, #0x1                ; =1
    645c:      	mov	x2, #0x1c               ; =28
    6460:      	b	0x63a4 <_stogir.locals.validate+0x438>
    6464:      	ldr	x0, [x24, #0x28]
    6468:      	add	x0, x0, x3, lsl #4
    646c:      	ldr	x0, [x0]
    6470:      	mov	x1, x0
    6474:      	mov	x0, #0x1                ; =1
    6478:      	b	0x6418 <_stogir.locals.validate+0x4ac>
    647c:      	movz	x2, #0x0, lsl #48
    6480:      	cmp	x2, #0x0
    6484:      	b.eq	0x6410 <_stogir.locals.validate+0x4a4>
    6488:      	uxtb	w16, w1
    648c:      	cmp	w16, wzr
    6490:      	b.eq	0x6464 <_stogir.locals.validate+0x4f8>
    6494:      	ldr	x1, [x24]
    6498:      	add	x0, x1, x0, lsl #4
    649c:      	ldr	x0, [x0]
    64a0:      	b	0x6470 <_stogir.locals.validate+0x504>
    64a4:      	movz	x2, #0x0, lsl #48
    64a8:      	b	0x6480 <_stogir.locals.validate+0x514>
    64ac:      	cmp	x0, #0x0
    64b0:      	b.ge	0x647c <_stogir.locals.validate+0x510>
    64b4:      	add	x4, x24, #0x28
    64b8:      	add	x5, x24, #0x50
    64bc:      	ldr	x4, [x4, #0x8]
    64c0:      	ldr	x5, [x5, #0x8]
    64c4:      	cmp	x4, x5
    64c8:      	b.ne	0x6554 <_stogir.locals.validate+0x5e8>
    64cc:      	cmp	x2, x4
    64d0:      	b.gt	0x6564 <_stogir.locals.validate+0x5f8>
    64d4:      	ldr	x2, [x24, #0x50]
    64d8:      	add	x2, x2, x3, lsl #2
    64dc:      	ldr	w2, [x2]
    64e0:      	sxtw	x2, w2
    64e4:      	cmp	x2, #0x0
    64e8:      	cset	w2, gt
    64ec:      	ubfx	x2, x2, #0, #8
    64f0:      	b	0x6568 <_stogir.locals.validate+0x5fc>
    64f4:      	add	x16, sp, #0x10
    64f8:      	ldr	w0, [x16, #0x4]
    64fc:      	sxtw	x0, w0
    6500:      	cmp	x0, #0x0
    6504:      	b.le	0x6538 <_stogir.locals.validate+0x5cc>
    6508:      	uxtb	w1, w1
    650c:      	cmp	x1, #0x83
    6510:      	cset	w0, lt
    6514:      	uxtb	w16, w0
    6518:      	cmp	w16, wzr
    651c:      	b.eq	0x6574 <_stogir.locals.validate+0x608>
    6520:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006520:  ARM64_RELOC_PAGE21	l_stogir.399
    6524:      	ldr	x16, [x16]
		0000000000006524:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6528:      	orr	x2, x16, xzr
    652c:      	add	x2, x1, x2
    6530:      	ldrb	w2, [x2]
    6534:      	b	0x6578 <_stogir.locals.validate+0x60c>
    6538:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006538:  ARM64_RELOC_PAGE21	l_stogir.400
    653c:      	ldr	x16, [x16]
		000000000000653c:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6540:      	orr	x0, x16, xzr
    6544:      	mov	x1, x0
    6548:      	mov	x0, #0x1                ; =1
    654c:      	mov	x2, #0x1c               ; =28
    6550:      	b	0x6460 <_stogir.locals.validate+0x4f4>
    6554:      	movz	x2, #0x0, lsl #48
    6558:      	b	0x6480 <_stogir.locals.validate+0x514>
    655c:      	movz	x2, #0x0, lsl #48
    6560:      	b	0x64a8 <_stogir.locals.validate+0x53c>
    6564:      	movz	x2, #0x0, lsl #48
    6568:      	b	0x6558 <_stogir.locals.validate+0x5ec>
    656c:      	brk	#0
    6570:      	b	0x656c <_stogir.locals.validate+0x600>
    6574:      	movz	x2, #0x0, lsl #48
    6578:      	uxtb	w2, w2
    657c:      	and	x2, x2, #0x1
    6580:      	uxtb	w2, w2
    6584:      	cmp	x2, #0x0
    6588:      	b.eq	0x6538 <_stogir.locals.validate+0x5cc>
    658c:      	uxtb	w16, w0
    6590:      	cmp	w16, wzr
    6594:      	b.eq	0x65b0 <_stogir.locals.validate+0x644>
    6598:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006598:  ARM64_RELOC_PAGE21	l_stogir.399
    659c:      	ldr	x16, [x16]
		000000000000659c:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    65a0:      	orr	x0, x16, xzr
    65a4:      	add	x0, x1, x0
    65a8:      	ldrb	w0, [x0]
    65ac:      	b	0x65b4 <_stogir.locals.validate+0x648>
    65b0:      	movz	x0, #0x0, lsl #48
    65b4:      	uxtb	w0, w0
    65b8:      	and	x0, x0, #0x4
    65bc:      	uxtb	w0, w0
    65c0:      	cmp	x0, #0x0
    65c4:      	cset	w0, eq
    65c8:      	uxtb	w16, w0
    65cc:      	cmp	w16, wzr
    65d0:      	cset	x0, eq
    65d4:      	cmp	x0, #0x0
    65d8:      	b.ne	0x6538 <_stogir.locals.validate+0x5cc>
    65dc:      	cmp	x19, #0x0
    65e0:      	b.eq	0x6680 <_stogir.locals.validate+0x714>
    65e4:      	add	x16, sp, #0x10
    65e8:      	ldr	w0, [x16, #0xc]
    65ec:      	lsr	w0, w0, #0
    65f0:      	add	x8, sp, #0x40
    65f4:      	mov	w1, w0
    65f8:      	mov	x0, x24
    65fc:      	bl	0x65fc <_stogir.locals.validate+0x690>
		00000000000065fc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6600:      	add	x16, sp, #0x40
    6604:      	ldr	x0, [x16]
    6608:      	add	x16, sp, #0x40
    660c:      	ldr	x1, [x16, #0x8]
    6610:      	mov	x20, x1
    6614:      	b	0x6690 <_stogir.locals.validate+0x724>
    6618:      	lsr	w25, w25, #0
    661c:      	lsr	w0, w20, #0
    6620:      	ubfx	x0, x0, #8, #8
    6624:      	lsr	w0, w0, #0
    6628:      	mov	w1, w25
    662c:      	bl	0x662c <_stogir.locals.validate+0x6c0>
		000000000000662c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6630:      	lsr	w0, w0, #0
    6634:      	sxtw	x0, w0
    6638:      	cmp	x0, #0x0
    663c:      	b.le	0x6664 <_stogir.locals.validate+0x6f8>
    6640:      	cmp	x0, x22
    6644:      	b.gt	0x6664 <_stogir.locals.validate+0x6f8>
    6648:      	cmp	x19, #0x0
    664c:      	b.eq	0x66e4 <_stogir.locals.validate+0x778>
    6650:      	add	x16, sp, #0x10
    6654:      	ldr	w1, [x16]
    6658:      	ubfx	x1, x1, #8, #8
    665c:      	cmp	x1, #0x0
    6660:      	b.eq	0x66e4 <_stogir.locals.validate+0x778>
    6664:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006664:  ARM64_RELOC_PAGE21	l_stogir.401
    6668:      	ldr	x16, [x16]
		0000000000006668:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    666c:      	orr	x0, x16, xzr
    6670:      	mov	x1, x0
    6674:      	mov	x0, #0x1                ; =1
    6678:      	mov	x2, #0x23               ; =35
    667c:      	b	0x6550 <_stogir.locals.validate+0x5e4>
    6680:      	add	x16, sp, #0x10
    6684:      	ldr	x0, [x16]
    6688:      	mov	x20, x0
    668c:      	mov	x0, #0x1                ; =1
    6690:      	lsr	w0, w0, #0
    6694:      	lsr	x16, x0, #0
    6698:      	cmp	x16, #0x1
    669c:      	b.eq	0x66b8 <_stogir.locals.validate+0x74c>
    66a0:      	b.lo	0x66a8 <_stogir.locals.validate+0x73c>
    66a4:      	b	0x66bc <_stogir.locals.validate+0x750>
    66a8:      	cmp	x16, #0x0
    66ac:      	b.eq	0x66b4 <_stogir.locals.validate+0x748>
    66b0:      	b	0x66bc <_stogir.locals.validate+0x750>
    66b4:      	b	0x66c0 <_stogir.locals.validate+0x754>
    66b8:      	b	0x6618 <_stogir.locals.validate+0x6ac>
    66bc:      	b	0x6704 <_stogir.locals.validate+0x798>
    66c0:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		00000000000066c0:  ARM64_RELOC_PAGE21	l_stogir.402
    66c4:      	ldr	x16, [x16]
		00000000000066c4:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    66c8:      	orr	x0, x16, xzr
    66cc:      	mov	x1, x0
    66d0:      	mov	x0, #0x1                ; =1
    66d4:      	mov	x2, #0x19               ; =25
    66d8:      	b	0x667c <_stogir.locals.validate+0x710>
    66dc:      	brk	#0
    66e0:      	b	0x66dc <_stogir.locals.validate+0x770>
    66e4:      	uxtb	w20, w20
    66e8:      	cmp	x20, #0x48
    66ec:      	b.eq	0x6664 <_stogir.locals.validate+0x6f8>
    66f0:      	and	x0, x0, #0xffffffff
    66f4:      	mov	x1, x0
    66f8:      	movz	x0, #0x0, lsl #48
    66fc:      	movz	x2, #0x0, lsl #48
    6700:      	b	0x667c <_stogir.locals.validate+0x710>
    6704:      	brk	#0
    6708:      	b	0x6704 <_stogir.locals.validate+0x798>
    670c:      	mov	x23, x8
    6710:      	b	0x607c <_stogir.locals.validate+0x110>
    6714:      	mov	x23, x8
    6718:      	b	0x607c <_stogir.locals.validate+0x110>

000000000000671c <_stogir.conversion.operation?>:
    671c:      	sxtw	x0, w0
    6720:      	cmp	x0, #0x21
    6724:      	b.lt	0x6738 <_stogir.conversion.operation?+0x1c>
    6728:      	cmp	x0, #0x27
    672c:      	cset	w0, le
    6730:      	ubfx	x0, x0, #0, #8
    6734:      	b	0x673c <_stogir.conversion.operation?+0x20>
    6738:      	movz	x0, #0x0, lsl #48
    673c:      	ret

0000000000006740 <_stogir.conversion.validate>:
    6740:      	sub	sp, sp, #0x40
    6744:      	str	x29, [sp]
    6748:      	str	x30, [sp, #0x8]
    674c:      	mov	x29, sp
    6750:      	str	x19, [sp, #0x30]
    6754:      	sxtw	x1, w1
    6758:      	lsl	x3, x1, #2
    675c:      	cmp	x1, #0x0
    6760:      	cset	w4, gt
    6764:      	movz	x16, #0x0, lsl #48
    6768:      	sub	x5, x16, x1
    676c:      	sub	x6, x5, #0x1
    6770:      	uxtb	w16, w4
    6774:      	cmp	w16, wzr
    6778:      	b.eq	0x67b8 <_stogir.conversion.validate+0x78>
    677c:      	ldr	x5, [x0, #0x8]
    6780:      	cmp	x1, x5
    6784:      	b.ge	0x6808 <_stogir.conversion.validate+0xc8>
    6788:      	add	x5, x0, #0x78
    678c:      	ldr	x5, [x5, #0x8]
    6790:      	cmp	x1, x5
    6794:      	b.ge	0x68ec <_stogir.conversion.validate+0x1ac>
    6798:      	ldr	x5, [x0, #0x78]
    679c:      	add	x5, x3, x5
    67a0:      	ldr	w5, [x5]
    67a4:      	sxtw	x5, w5
    67a8:      	cmp	x5, #0x0
    67ac:      	cset	w5, ge
    67b0:      	ubfx	x5, x5, #0, #8
    67b4:      	b	0x68f0 <_stogir.conversion.validate+0x1b0>
    67b8:      	cmp	x1, #0x0
    67bc:      	b.ge	0x6810 <_stogir.conversion.validate+0xd0>
    67c0:      	add	x7, x0, #0x28
    67c4:      	add	x9, x0, #0x50
    67c8:      	ldr	x7, [x7, #0x8]
    67cc:      	ldr	x9, [x9, #0x8]
    67d0:      	cmp	x7, x9
    67d4:      	b.ne	0x6800 <_stogir.conversion.validate+0xc0>
    67d8:      	cmp	x5, x7
    67dc:      	b.gt	0x6980 <_stogir.conversion.validate+0x240>
    67e0:      	ldr	x5, [x0, #0x50]
    67e4:      	add	x5, x5, x6, lsl #2
    67e8:      	ldr	w5, [x5]
    67ec:      	sxtw	x5, w5
    67f0:      	cmp	x5, #0x0
    67f4:      	cset	w5, gt
    67f8:      	ubfx	x5, x5, #0, #8
    67fc:      	b	0x6984 <_stogir.conversion.validate+0x244>
    6800:      	movz	x5, #0x0, lsl #48
    6804:      	b	0x6814 <_stogir.conversion.validate+0xd4>
    6808:      	movz	x5, #0x0, lsl #48
    680c:      	b	0x6814 <_stogir.conversion.validate+0xd4>
    6810:      	movz	x5, #0x0, lsl #48
    6814:      	cmp	x5, #0x0
    6818:      	b.eq	0x6850 <_stogir.conversion.validate+0x110>
    681c:      	uxtb	w16, w4
    6820:      	cmp	w16, wzr
    6824:      	b.eq	0x6838 <_stogir.conversion.validate+0xf8>
    6828:      	ldr	x4, [x0]
    682c:      	add	x4, x4, x1, lsl #4
    6830:      	ldr	x4, [x4]
    6834:      	b	0x6844 <_stogir.conversion.validate+0x104>
    6838:      	ldr	x4, [x0, #0x28]
    683c:      	add	x4, x4, x6, lsl #4
    6840:      	ldr	x4, [x4]
    6844:      	mov	x5, x4
    6848:      	mov	x4, #0x1                ; =1
    684c:      	b	0x6858 <_stogir.conversion.validate+0x118>
    6850:      	movz	x4, #0x0, lsl #48
    6854:      	movz	x5, #0x0, lsl #48
    6858:      	lsr	w4, w4, #0
    685c:      	lsr	x16, x4, #0
    6860:      	cmp	x16, #0x1
    6864:      	b.eq	0x6880 <_stogir.conversion.validate+0x140>
    6868:      	b.lo	0x6870 <_stogir.conversion.validate+0x130>
    686c:      	b	0x6884 <_stogir.conversion.validate+0x144>
    6870:      	cmp	x16, #0x0
    6874:      	b.eq	0x687c <_stogir.conversion.validate+0x13c>
    6878:      	b	0x6884 <_stogir.conversion.validate+0x144>
    687c:      	b	0x6888 <_stogir.conversion.validate+0x148>
    6880:      	b	0x68c4 <_stogir.conversion.validate+0x184>
    6884:      	b	0x69fc <_stogir.conversion.validate+0x2bc>
    6888:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006888:  ARM64_RELOC_PAGE21	l_stogir.403
    688c:      	ldr	x16, [x16]
		000000000000688c:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    6890:      	orr	x0, x16, xzr
    6894:      	mov	x19, x8
    6898:      	mov	x1, x0
    689c:      	mov	x0, #0x1                ; =1
    68a0:      	mov	x2, #0x12               ; =18
    68a4:      	str	x0, [x19]
    68a8:      	str	x1, [x19, #0x8]
    68ac:      	str	x2, [x19, #0x10]
    68b0:      	ldr	x19, [sp, #0x30]
    68b4:      	ldr	x29, [sp]
    68b8:      	ldr	x30, [sp, #0x8]
    68bc:      	add	sp, sp, #0x40
    68c0:      	ret
    68c4:      	cmp	x1, #0x0
    68c8:      	b.gt	0x68f4 <_stogir.conversion.validate+0x1b4>
    68cc:      	mov	x19, x8
    68d0:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		00000000000068d0:  ARM64_RELOC_PAGE21	l_stogir.404
    68d4:      	ldr	x16, [x16]
		00000000000068d4:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    68d8:      	orr	x0, x16, xzr
    68dc:      	mov	x1, x0
    68e0:      	mov	x0, #0x1                ; =1
    68e4:      	mov	x2, #0x1e               ; =30
    68e8:      	b	0x68a4 <_stogir.conversion.validate+0x164>
    68ec:      	movz	x5, #0x0, lsl #48
    68f0:      	b	0x680c <_stogir.conversion.validate+0xcc>
    68f4:      	uxtb	w1, w5
    68f8:      	orr	x4, x1, xzr
    68fc:      	cmp	x4, #0x21
    6900:      	b.lt	0x6b28 <_stogir.conversion.validate+0x3e8>
    6904:      	cmp	x4, #0x27
    6908:      	b.gt	0x6b30 <_stogir.conversion.validate+0x3f0>
    690c:      	ldr	x4, [x0, #0x78]
    6910:      	add	x3, x3, x4
    6914:      	ldr	w3, [x3]
    6918:      	sxtw	x3, w3
    691c:      	cmp	x3, #0x1
    6920:      	b.ne	0x6b38 <_stogir.conversion.validate+0x3f8>
    6924:      	asr	x3, x5, #32
    6928:      	cmp	x3, #0x0
    692c:      	cset	w6, gt
    6930:      	movz	x16, #0x0, lsl #48
    6934:      	sub	x7, x16, x3
    6938:      	sub	x9, x7, #0x1
    693c:      	uxtb	w16, w6
    6940:      	cmp	w16, wzr
    6944:      	b.eq	0x69b4 <_stogir.conversion.validate+0x274>
    6948:      	ldr	x7, [x0, #0x8]
    694c:      	cmp	x3, x7
    6950:      	b.ge	0x6a04 <_stogir.conversion.validate+0x2c4>
    6954:      	add	x7, x0, #0x78
    6958:      	ldr	x7, [x7, #0x8]
    695c:      	cmp	x3, x7
    6960:      	b.ge	0x6aac <_stogir.conversion.validate+0x36c>
    6964:      	add	x4, x4, x3, lsl #2
    6968:      	ldr	w4, [x4]
    696c:      	sxtw	x4, w4
    6970:      	cmp	x4, #0x0
    6974:      	cset	w4, ge
    6978:      	ubfx	x4, x4, #0, #8
    697c:      	b	0x6ab0 <_stogir.conversion.validate+0x370>
    6980:      	movz	x5, #0x0, lsl #48
    6984:      	b	0x6804 <_stogir.conversion.validate+0xc4>
    6988:      	uxtb	w0, w3
    698c:      	cmp	x0, #0x48
    6990:      	b.ne	0x6ab4 <_stogir.conversion.validate+0x374>
    6994:      	mov	x19, x8
    6998:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006998:  ARM64_RELOC_PAGE21	l_stogir.405
    699c:      	ldr	x16, [x16]
		000000000000699c:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    69a0:      	orr	x0, x16, xzr
    69a4:      	mov	x1, x0
    69a8:      	mov	x0, #0x1                ; =1
    69ac:      	mov	x2, #0x25               ; =37
    69b0:      	b	0x68e8 <_stogir.conversion.validate+0x1a8>
    69b4:      	cmp	x3, #0x0
    69b8:      	b.ge	0x6a0c <_stogir.conversion.validate+0x2cc>
    69bc:      	add	x4, x0, #0x28
    69c0:      	add	x10, x0, #0x50
    69c4:      	ldr	x4, [x4, #0x8]
    69c8:      	ldr	x10, [x10, #0x8]
    69cc:      	cmp	x4, x10
    69d0:      	b.ne	0x6aa4 <_stogir.conversion.validate+0x364>
    69d4:      	cmp	x7, x4
    69d8:      	b.gt	0x6b18 <_stogir.conversion.validate+0x3d8>
    69dc:      	ldr	x4, [x0, #0x50]
    69e0:      	add	x4, x4, x9, lsl #2
    69e4:      	ldr	w4, [x4]
    69e8:      	sxtw	x4, w4
    69ec:      	cmp	x4, #0x0
    69f0:      	cset	w4, gt
    69f4:      	ubfx	x4, x4, #0, #8
    69f8:      	b	0x6b1c <_stogir.conversion.validate+0x3dc>
    69fc:      	brk	#0
    6a00:      	b	0x69fc <_stogir.conversion.validate+0x2bc>
    6a04:      	movz	x4, #0x0, lsl #48
    6a08:      	b	0x6a10 <_stogir.conversion.validate+0x2d0>
    6a0c:      	movz	x4, #0x0, lsl #48
    6a10:      	cmp	x4, #0x0
    6a14:      	b.eq	0x6a4c <_stogir.conversion.validate+0x30c>
    6a18:      	uxtb	w16, w6
    6a1c:      	cmp	w16, wzr
    6a20:      	b.eq	0x6a34 <_stogir.conversion.validate+0x2f4>
    6a24:      	ldr	x0, [x0]
    6a28:      	add	x0, x0, x3, lsl #4
    6a2c:      	ldr	x0, [x0]
    6a30:      	b	0x6a40 <_stogir.conversion.validate+0x300>
    6a34:      	ldr	x0, [x0, #0x28]
    6a38:      	add	x0, x0, x9, lsl #4
    6a3c:      	ldr	x0, [x0]
    6a40:      	mov	x3, x0
    6a44:      	mov	x0, #0x1                ; =1
    6a48:      	b	0x6a54 <_stogir.conversion.validate+0x314>
    6a4c:      	movz	x0, #0x0, lsl #48
    6a50:      	movz	x3, #0x0, lsl #48
    6a54:      	lsr	w0, w0, #0
    6a58:      	lsr	x16, x0, #0
    6a5c:      	cmp	x16, #0x1
    6a60:      	b.eq	0x6a7c <_stogir.conversion.validate+0x33c>
    6a64:      	b.lo	0x6a6c <_stogir.conversion.validate+0x32c>
    6a68:      	b	0x6a80 <_stogir.conversion.validate+0x340>
    6a6c:      	cmp	x16, #0x0
    6a70:      	b.eq	0x6a78 <_stogir.conversion.validate+0x338>
    6a74:      	b	0x6a80 <_stogir.conversion.validate+0x340>
    6a78:      	b	0x6a84 <_stogir.conversion.validate+0x344>
    6a7c:      	b	0x6988 <_stogir.conversion.validate+0x248>
    6a80:      	b	0x6b20 <_stogir.conversion.validate+0x3e0>
    6a84:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006a84:  ARM64_RELOC_PAGE21	l_stogir.406
    6a88:      	ldr	x16, [x16]
		0000000000006a88:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    6a8c:      	orr	x0, x16, xzr
    6a90:      	mov	x19, x8
    6a94:      	mov	x1, x0
    6a98:      	mov	x0, #0x1                ; =1
    6a9c:      	mov	x2, #0x19               ; =25
    6aa0:      	b	0x69b0 <_stogir.conversion.validate+0x270>
    6aa4:      	movz	x4, #0x0, lsl #48
    6aa8:      	b	0x6a10 <_stogir.conversion.validate+0x2d0>
    6aac:      	movz	x4, #0x0, lsl #48
    6ab0:      	b	0x6a08 <_stogir.conversion.validate+0x2c8>
    6ab4:      	cmp	x0, #0x46
    6ab8:      	b.eq	0x6b40 <_stogir.conversion.validate+0x400>
    6abc:      	lsr	w2, w2, #0
    6ac0:      	lsr	w5, w5, #0
    6ac4:      	lsr	w3, w3, #0
    6ac8:      	lsr	w1, w1, #0
    6acc:      	ubfx	x0, x5, #8, #8
    6ad0:      	ubfx	x3, x3, #8, #8
    6ad4:      	lsr	w0, w0, #0
    6ad8:      	lsr	w3, w3, #0
    6adc:      	mov	x19, x8
    6ae0:      	add	x8, sp, #0x10
    6ae4:      	fmov	s31, w0
    6ae8:      	mov	w0, w1
    6aec:      	mov	w1, w3
    6af0:      	mov	w3, w2
    6af4:      	fmov	w2, s31
    6af8:      	bl	0x6af8 <_stogir.conversion.validate+0x3b8>
		0000000000006af8:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6afc:      	add	x16, sp, #0x10
    6b00:      	ldr	x0, [x16]
    6b04:      	add	x16, sp, #0x10
    6b08:      	ldr	x1, [x16, #0x8]
    6b0c:      	add	x16, sp, #0x10
    6b10:      	ldr	x2, [x16, #0x10]
    6b14:      	b	0x69b0 <_stogir.conversion.validate+0x270>
    6b18:      	movz	x4, #0x0, lsl #48
    6b1c:      	b	0x6aa8 <_stogir.conversion.validate+0x368>
    6b20:      	brk	#0
    6b24:      	b	0x6b20 <_stogir.conversion.validate+0x3e0>
    6b28:      	mov	x19, x8
    6b2c:      	b	0x68d0 <_stogir.conversion.validate+0x190>
    6b30:      	mov	x19, x8
    6b34:      	b	0x68d0 <_stogir.conversion.validate+0x190>
    6b38:      	mov	x19, x8
    6b3c:      	b	0x68d0 <_stogir.conversion.validate+0x190>
    6b40:      	mov	x19, x8
    6b44:      	b	0x6998 <_stogir.conversion.validate+0x258>

0000000000006b48 <_stogir.conditional.validate>:
    6b48:      	sub	sp, sp, #0x40
    6b4c:      	str	x29, [sp]
    6b50:      	str	x30, [sp, #0x8]
    6b54:      	mov	x29, sp
    6b58:      	str	x19, [sp, #0x30]
    6b5c:      	sxtw	x1, w1
    6b60:      	lsl	x2, x1, #2
    6b64:      	cmp	x1, #0x0
    6b68:      	cset	w3, gt
    6b6c:      	movz	x16, #0x0, lsl #48
    6b70:      	sub	x4, x16, x1
    6b74:      	sub	x5, x4, #0x1
    6b78:      	uxtb	w16, w3
    6b7c:      	cmp	w16, wzr
    6b80:      	b.eq	0x6bc0 <_stogir.conditional.validate+0x78>
    6b84:      	ldr	x4, [x0, #0x8]
    6b88:      	cmp	x1, x4
    6b8c:      	b.ge	0x6c10 <_stogir.conditional.validate+0xc8>
    6b90:      	add	x4, x0, #0x78
    6b94:      	ldr	x4, [x4, #0x8]
    6b98:      	cmp	x1, x4
    6b9c:      	b.ge	0x6d1c <_stogir.conditional.validate+0x1d4>
    6ba0:      	ldr	x4, [x0, #0x78]
    6ba4:      	add	x4, x2, x4
    6ba8:      	ldr	w4, [x4]
    6bac:      	sxtw	x4, w4
    6bb0:      	cmp	x4, #0x0
    6bb4:      	cset	w4, ge
    6bb8:      	ubfx	x4, x4, #0, #8
    6bbc:      	b	0x6d20 <_stogir.conditional.validate+0x1d8>
    6bc0:      	cmp	x1, #0x0
    6bc4:      	b.ge	0x6c18 <_stogir.conditional.validate+0xd0>
    6bc8:      	add	x6, x0, #0x28
    6bcc:      	add	x7, x0, #0x50
    6bd0:      	ldr	x6, [x6, #0x8]
    6bd4:      	ldr	x7, [x7, #0x8]
    6bd8:      	cmp	x6, x7
    6bdc:      	b.ne	0x6c08 <_stogir.conditional.validate+0xc0>
    6be0:      	cmp	x4, x6
    6be4:      	b.gt	0x6da4 <_stogir.conditional.validate+0x25c>
    6be8:      	ldr	x4, [x0, #0x50]
    6bec:      	add	x4, x4, x5, lsl #2
    6bf0:      	ldr	w4, [x4]
    6bf4:      	sxtw	x4, w4
    6bf8:      	cmp	x4, #0x0
    6bfc:      	cset	w4, gt
    6c00:      	ubfx	x4, x4, #0, #8
    6c04:      	b	0x6da8 <_stogir.conditional.validate+0x260>
    6c08:      	movz	x4, #0x0, lsl #48
    6c0c:      	b	0x6c1c <_stogir.conditional.validate+0xd4>
    6c10:      	movz	x4, #0x0, lsl #48
    6c14:      	b	0x6c1c <_stogir.conditional.validate+0xd4>
    6c18:      	movz	x4, #0x0, lsl #48
    6c1c:      	cmp	x4, #0x0
    6c20:      	b.eq	0x6c7c <_stogir.conditional.validate+0x134>
    6c24:      	uxtb	w16, w3
    6c28:      	cmp	w16, wzr
    6c2c:      	b.eq	0x6c50 <_stogir.conditional.validate+0x108>
    6c30:      	ldr	x3, [x0]
    6c34:      	add	x3, x3, x1, lsl #4
    6c38:      	ldr	x4, [x3]
    6c3c:      	ldr	x3, [x3, #0x8]
    6c40:      	fmov	d31, x3
    6c44:      	mov	x3, x4
    6c48:      	fmov	x4, d31
    6c4c:      	b	0x6c6c <_stogir.conditional.validate+0x124>
    6c50:      	ldr	x3, [x0, #0x28]
    6c54:      	add	x3, x3, x5, lsl #4
    6c58:      	ldr	x4, [x3]
    6c5c:      	ldr	x3, [x3, #0x8]
    6c60:      	fmov	d31, x3
    6c64:      	mov	x3, x4
    6c68:      	fmov	x4, d31
    6c6c:      	mov	x5, x4
    6c70:      	mov	x4, x3
    6c74:      	mov	x3, #0x1                ; =1
    6c78:      	b	0x6c88 <_stogir.conditional.validate+0x140>
    6c7c:      	movz	x3, #0x0, lsl #48
    6c80:      	movz	x4, #0x0, lsl #48
    6c84:      	movz	x5, #0x0, lsl #48
    6c88:      	lsr	w3, w3, #0
    6c8c:      	lsr	x16, x3, #0
    6c90:      	cmp	x16, #0x1
    6c94:      	b.eq	0x6cb0 <_stogir.conditional.validate+0x168>
    6c98:      	b.lo	0x6ca0 <_stogir.conditional.validate+0x158>
    6c9c:      	b	0x6cb4 <_stogir.conditional.validate+0x16c>
    6ca0:      	cmp	x16, #0x0
    6ca4:      	b.eq	0x6cac <_stogir.conditional.validate+0x164>
    6ca8:      	b	0x6cb4 <_stogir.conditional.validate+0x16c>
    6cac:      	b	0x6cb8 <_stogir.conditional.validate+0x170>
    6cb0:      	b	0x6cd8 <_stogir.conditional.validate+0x190>
    6cb4:      	b	0x6dac <_stogir.conditional.validate+0x264>
    6cb8:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006cb8:  ARM64_RELOC_PAGE21	l_stogir.407
    6cbc:      	ldr	x16, [x16]
		0000000000006cbc:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    6cc0:      	orr	x0, x16, xzr
    6cc4:      	mov	x19, x8
    6cc8:      	mov	x1, x0
    6ccc:      	mov	x0, #0x1                ; =1
    6cd0:      	mov	x2, #0x18               ; =24
    6cd4:      	b	0x6cfc <_stogir.conditional.validate+0x1b4>
    6cd8:      	cmp	x1, #0x0
    6cdc:      	b.gt	0x6d24 <_stogir.conditional.validate+0x1dc>
    6ce0:      	mov	x19, x8
    6ce4:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006ce4:  ARM64_RELOC_PAGE21	l_stogir.408
    6ce8:      	ldr	x16, [x16]
		0000000000006ce8:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    6cec:      	orr	x0, x16, xzr
    6cf0:      	mov	x1, x0
    6cf4:      	mov	x0, #0x1                ; =1
    6cf8:      	mov	x2, #0x18               ; =24
    6cfc:      	str	x0, [x19]
    6d00:      	str	x1, [x19, #0x8]
    6d04:      	str	x2, [x19, #0x10]
    6d08:      	ldr	x19, [sp, #0x30]
    6d0c:      	ldr	x29, [sp]
    6d10:      	ldr	x30, [sp, #0x8]
    6d14:      	add	sp, sp, #0x40
    6d18:      	ret
    6d1c:      	movz	x4, #0x0, lsl #48
    6d20:      	b	0x6c14 <_stogir.conditional.validate+0xcc>
    6d24:      	uxtb	w1, w4
    6d28:      	cmp	x1, #0x3c
    6d2c:      	b.ne	0x6db4 <_stogir.conditional.validate+0x26c>
    6d30:      	ldr	x1, [x0, #0x78]
    6d34:      	add	x1, x2, x1
    6d38:      	ldr	w1, [x1]
    6d3c:      	sxtw	x1, w1
    6d40:      	cmp	x1, #0x3
    6d44:      	b.ne	0x6dbc <_stogir.conditional.validate+0x274>
    6d48:      	lsr	w1, w5, #0
    6d4c:      	lsr	w2, w4, #0
    6d50:      	lsr	x3, x4, #32
    6d54:      	lsr	w1, w1, #0
    6d58:      	lsr	x4, x5, #32
    6d5c:      	lsr	w3, w3, #0
    6d60:      	lsr	w4, w4, #0
    6d64:      	ubfx	x2, x2, #8, #8
    6d68:      	lsr	w2, w2, #0
    6d6c:      	mov	x19, x8
    6d70:      	add	x8, sp, #0x10
    6d74:      	fmov	s31, w1
    6d78:      	mov	w1, w2
    6d7c:      	mov	w2, w3
    6d80:      	fmov	w3, s31
    6d84:      	bl	0x6d84 <_stogir.conditional.validate+0x23c>
		0000000000006d84:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    6d88:      	add	x16, sp, #0x10
    6d8c:      	ldr	x0, [x16]
    6d90:      	add	x16, sp, #0x10
    6d94:      	ldr	x1, [x16, #0x8]
    6d98:      	add	x16, sp, #0x10
    6d9c:      	ldr	x2, [x16, #0x10]
    6da0:      	b	0x6cfc <_stogir.conditional.validate+0x1b4>
    6da4:      	movz	x4, #0x0, lsl #48
    6da8:      	b	0x6c0c <_stogir.conditional.validate+0xc4>
    6dac:      	brk	#0
    6db0:      	b	0x6dac <_stogir.conditional.validate+0x264>
    6db4:      	mov	x19, x8
    6db8:      	b	0x6ce4 <_stogir.conditional.validate+0x19c>
    6dbc:      	mov	x19, x8
    6dc0:      	b	0x6ce4 <_stogir.conditional.validate+0x19c>

0000000000006dc4 <_stogir.floating.validate>:
    6dc4:      	sub	sp, sp, #0x50
    6dc8:      	str	x29, [sp]
    6dcc:      	str	x30, [sp, #0x8]
    6dd0:      	mov	x29, sp
    6dd4:      	str	x19, [sp, #0x40]
    6dd8:      	sxtw	x1, w1
    6ddc:      	lsl	x2, x1, #2
    6de0:      	cmp	x1, #0x0
    6de4:      	cset	w3, gt
    6de8:      	movz	x16, #0x0, lsl #48
    6dec:      	sub	x4, x16, x1
    6df0:      	sub	x5, x4, #0x1
    6df4:      	uxtb	w16, w3
    6df8:      	cmp	w16, wzr
    6dfc:      	b.eq	0x6e3c <_stogir.floating.validate+0x78>
    6e00:      	ldr	x4, [x0, #0x8]
    6e04:      	cmp	x1, x4
    6e08:      	b.ge	0x6e8c <_stogir.floating.validate+0xc8>
    6e0c:      	add	x4, x0, #0x78
    6e10:      	ldr	x4, [x4, #0x8]
    6e14:      	cmp	x1, x4
    6e18:      	b.ge	0x6fa8 <_stogir.floating.validate+0x1e4>
    6e1c:      	ldr	x4, [x0, #0x78]
    6e20:      	add	x4, x2, x4
    6e24:      	ldr	w4, [x4]
    6e28:      	sxtw	x4, w4
    6e2c:      	cmp	x4, #0x0
    6e30:      	cset	w4, ge
    6e34:      	ubfx	x4, x4, #0, #8
    6e38:      	b	0x6fac <_stogir.floating.validate+0x1e8>
    6e3c:      	cmp	x1, #0x0
    6e40:      	b.ge	0x6e94 <_stogir.floating.validate+0xd0>
    6e44:      	add	x6, x0, #0x28
    6e48:      	add	x7, x0, #0x50
    6e4c:      	ldr	x6, [x6, #0x8]
    6e50:      	ldr	x7, [x7, #0x8]
    6e54:      	cmp	x6, x7
    6e58:      	b.ne	0x6e84 <_stogir.floating.validate+0xc0>
    6e5c:      	cmp	x4, x6
    6e60:      	b.gt	0x7034 <_stogir.floating.validate+0x270>
    6e64:      	ldr	x4, [x0, #0x50]
    6e68:      	add	x4, x4, x5, lsl #2
    6e6c:      	ldr	w4, [x4]
    6e70:      	sxtw	x4, w4
    6e74:      	cmp	x4, #0x0
    6e78:      	cset	w4, gt
    6e7c:      	ubfx	x4, x4, #0, #8
    6e80:      	b	0x7038 <_stogir.floating.validate+0x274>
    6e84:      	movz	x4, #0x0, lsl #48
    6e88:      	b	0x6e98 <_stogir.floating.validate+0xd4>
    6e8c:      	movz	x4, #0x0, lsl #48
    6e90:      	b	0x6e98 <_stogir.floating.validate+0xd4>
    6e94:      	movz	x4, #0x0, lsl #48
    6e98:      	cmp	x4, #0x0
    6e9c:      	b.eq	0x6ef8 <_stogir.floating.validate+0x134>
    6ea0:      	uxtb	w16, w3
    6ea4:      	cmp	w16, wzr
    6ea8:      	b.eq	0x6ecc <_stogir.floating.validate+0x108>
    6eac:      	ldr	x3, [x0]
    6eb0:      	add	x3, x3, x1, lsl #4
    6eb4:      	ldr	x4, [x3]
    6eb8:      	ldr	x3, [x3, #0x8]
    6ebc:      	fmov	d31, x3
    6ec0:      	mov	x3, x4
    6ec4:      	fmov	x4, d31
    6ec8:      	b	0x6ee8 <_stogir.floating.validate+0x124>
    6ecc:      	ldr	x3, [x0, #0x28]
    6ed0:      	add	x3, x3, x5, lsl #4
    6ed4:      	ldr	x4, [x3]
    6ed8:      	ldr	x3, [x3, #0x8]
    6edc:      	fmov	d31, x3
    6ee0:      	mov	x3, x4
    6ee4:      	fmov	x4, d31
    6ee8:      	mov	x5, x4
    6eec:      	mov	x4, x3
    6ef0:      	mov	x3, #0x1                ; =1
    6ef4:      	b	0x6f04 <_stogir.floating.validate+0x140>
    6ef8:      	movz	x3, #0x0, lsl #48
    6efc:      	movz	x4, #0x0, lsl #48
    6f00:      	movz	x5, #0x0, lsl #48
    6f04:      	lsr	w3, w3, #0
    6f08:      	lsr	x16, x3, #0
    6f0c:      	cmp	x16, #0x1
    6f10:      	b.eq	0x6f2c <_stogir.floating.validate+0x168>
    6f14:      	b.lo	0x6f1c <_stogir.floating.validate+0x158>
    6f18:      	b	0x6f30 <_stogir.floating.validate+0x16c>
    6f1c:      	cmp	x16, #0x0
    6f20:      	b.eq	0x6f28 <_stogir.floating.validate+0x164>
    6f24:      	b	0x6f30 <_stogir.floating.validate+0x16c>
    6f28:      	b	0x6f34 <_stogir.floating.validate+0x170>
    6f2c:      	b	0x6f70 <_stogir.floating.validate+0x1ac>
    6f30:      	b	0x72e0 <_stogir.floating.validate+0x51c>
    6f34:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006f34:  ARM64_RELOC_PAGE21	l_stogir.409
    6f38:      	ldr	x16, [x16]
		0000000000006f38:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    6f3c:      	orr	x0, x16, xzr
    6f40:      	mov	x19, x8
    6f44:      	mov	x1, x0
    6f48:      	mov	x0, #0x1                ; =1
    6f4c:      	mov	x2, #0x1c               ; =28
    6f50:      	str	x0, [x19]
    6f54:      	str	x1, [x19, #0x8]
    6f58:      	str	x2, [x19, #0x10]
    6f5c:      	ldr	x19, [sp, #0x40]
    6f60:      	ldr	x29, [sp]
    6f64:      	ldr	x30, [sp, #0x8]
    6f68:      	add	sp, sp, #0x50
    6f6c:      	ret
    6f70:      	add	x16, sp, #0x10
    6f74:      	str	x4, [x16]
    6f78:      	add	x16, sp, #0x10
    6f7c:      	str	x5, [x16, #0x8]
    6f80:      	cmp	x1, #0x0
    6f84:      	b.gt	0x6fb0 <_stogir.floating.validate+0x1ec>
    6f88:      	mov	x19, x8
    6f8c:      	adrp	x16, 0x6000 <_stogir.locals.validate+0x94>
		0000000000006f8c:  ARM64_RELOC_PAGE21	l_stogir.410
    6f90:      	ldr	x16, [x16]
		0000000000006f90:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    6f94:      	orr	x0, x16, xzr
    6f98:      	mov	x1, x0
    6f9c:      	mov	x0, #0x1                ; =1
    6fa0:      	mov	x2, #0x1c               ; =28
    6fa4:      	b	0x6f50 <_stogir.floating.validate+0x18c>
    6fa8:      	movz	x4, #0x0, lsl #48
    6fac:      	b	0x6e90 <_stogir.floating.validate+0xcc>
    6fb0:      	uxtb	w4, w4
    6fb4:      	orr	x1, x4, xzr
    6fb8:      	cmp	x1, #0xe
    6fbc:      	cset	w3, ge
    6fc0:      	cmp	x1, #0x19
    6fc4:      	cset	w5, le
    6fc8:      	cmp	x1, #0x1f
    6fcc:      	cset	w6, eq
    6fd0:      	cmp	x1, #0x20
    6fd4:      	cset	w7, eq
    6fd8:      	uxtb	w16, w3
    6fdc:      	cmp	w16, wzr
    6fe0:      	b.eq	0x703c <_stogir.floating.validate+0x278>
    6fe4:      	uxtb	w16, w5
    6fe8:      	cmp	w16, wzr
    6fec:      	b.eq	0x703c <_stogir.floating.validate+0x278>
    6ff0:      	cmp	x1, #0x1d
    6ff4:      	cset	w1, eq
    6ff8:      	ldr	x9, [x0, #0x78]
    6ffc:      	add	x2, x2, x9
    7000:      	ldr	w2, [x2]
    7004:      	uxtb	w16, w6
    7008:      	cmp	w16, wzr
    700c:      	b.ne	0x707c <_stogir.floating.validate+0x2b8>
    7010:      	uxtb	w16, w7
    7014:      	cmp	w16, wzr
    7018:      	b.ne	0x707c <_stogir.floating.validate+0x2b8>
    701c:      	uxtb	w16, w1
    7020:      	cmp	w16, wzr
    7024:      	mov	x16, #0x3               ; =3
    7028:      	mov	x17, #0x2               ; =2
    702c:      	csel	x6, x16, x17, ne
    7030:      	b	0x7080 <_stogir.floating.validate+0x2bc>
    7034:      	movz	x4, #0x0, lsl #48
    7038:      	b	0x6e88 <_stogir.floating.validate+0xc4>
    703c:      	uxtb	w16, w6
    7040:      	cmp	w16, wzr
    7044:      	b.ne	0x6ff0 <_stogir.floating.validate+0x22c>
    7048:      	uxtb	w16, w7
    704c:      	cmp	w16, wzr
    7050:      	b.ne	0x6ff0 <_stogir.floating.validate+0x22c>
    7054:      	cmp	x1, #0x1a
    7058:      	b.lt	0x7064 <_stogir.floating.validate+0x2a0>
    705c:      	cmp	x1, #0x1d
    7060:      	b.le	0x6ff0 <_stogir.floating.validate+0x22c>
    7064:      	cmp	x1, #0x3a
    7068:      	b.eq	0x6ff0 <_stogir.floating.validate+0x22c>
    706c:      	cmp	x1, #0x3b
    7070:      	b.eq	0x6ff0 <_stogir.floating.validate+0x22c>
    7074:      	mov	x19, x8
    7078:      	b	0x6f8c <_stogir.floating.validate+0x1c8>
    707c:      	mov	x6, #0x1                ; =1
    7080:      	sxtw	x2, w2
    7084:      	lsr	w6, w6, #0
    7088:      	sxtw	x6, w6
    708c:      	cmp	x2, x6
    7090:      	b.ne	0x72f0 <_stogir.floating.validate+0x52c>
    7094:      	add	x16, sp, #0x10
    7098:      	ldr	w2, [x16, #0x4]
    709c:      	sxtw	x2, w2
    70a0:      	cmp	x2, #0x0
    70a4:      	cset	w6, gt
    70a8:      	movz	x16, #0x0, lsl #48
    70ac:      	sub	x7, x16, x2
    70b0:      	sub	x9, x7, #0x1
    70b4:      	uxtb	w16, w6
    70b8:      	cmp	w16, wzr
    70bc:      	b.eq	0x7118 <_stogir.floating.validate+0x354>
    70c0:      	ldr	x7, [x0, #0x8]
    70c4:      	cmp	x2, x7
    70c8:      	b.ge	0x7160 <_stogir.floating.validate+0x39c>
    70cc:      	add	x7, x0, #0x78
    70d0:      	ldr	x7, [x7, #0x8]
    70d4:      	cmp	x2, x7
    70d8:      	b.ge	0x7238 <_stogir.floating.validate+0x474>
    70dc:      	ldr	x7, [x0, #0x78]
    70e0:      	add	x7, x7, x2, lsl #2
    70e4:      	ldr	w7, [x7]
    70e8:      	sxtw	x7, w7
    70ec:      	cmp	x7, #0x0
    70f0:      	cset	w7, ge
    70f4:      	ubfx	x7, x7, #0, #8
    70f8:      	b	0x723c <_stogir.floating.validate+0x478>
    70fc:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		00000000000070fc:  ARM64_RELOC_PAGE21	l_stogir.411
    7100:      	ldr	x16, [x16]
		0000000000007100:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7104:      	orr	x0, x16, xzr
    7108:      	mov	x1, x0
    710c:      	mov	x0, #0x1                ; =1
    7110:      	mov	x2, #0x1d               ; =29
    7114:      	b	0x6fa4 <_stogir.floating.validate+0x1e0>
    7118:      	cmp	x2, #0x0
    711c:      	b.ge	0x7168 <_stogir.floating.validate+0x3a4>
    7120:      	add	x10, x0, #0x28
    7124:      	add	x11, x0, #0x50
    7128:      	ldr	x10, [x10, #0x8]
    712c:      	ldr	x11, [x11, #0x8]
    7130:      	cmp	x10, x11
    7134:      	b.ne	0x7230 <_stogir.floating.validate+0x46c>
    7138:      	cmp	x7, x10
    713c:      	b.gt	0x72d8 <_stogir.floating.validate+0x514>
    7140:      	ldr	x7, [x0, #0x50]
    7144:      	add	x7, x7, x9, lsl #2
    7148:      	ldr	w7, [x7]
    714c:      	sxtw	x7, w7
    7150:      	cmp	x7, #0x0
    7154:      	cset	w7, gt
    7158:      	ubfx	x7, x7, #0, #8
    715c:      	b	0x72dc <_stogir.floating.validate+0x518>
    7160:      	movz	x7, #0x0, lsl #48
    7164:      	b	0x716c <_stogir.floating.validate+0x3a8>
    7168:      	movz	x7, #0x0, lsl #48
    716c:      	cmp	x7, #0x0
    7170:      	b.eq	0x71a8 <_stogir.floating.validate+0x3e4>
    7174:      	uxtb	w16, w6
    7178:      	cmp	w16, wzr
    717c:      	b.eq	0x7190 <_stogir.floating.validate+0x3cc>
    7180:      	ldr	x6, [x0]
    7184:      	add	x2, x6, x2, lsl #4
    7188:      	ldr	x2, [x2]
    718c:      	b	0x719c <_stogir.floating.validate+0x3d8>
    7190:      	ldr	x2, [x0, #0x28]
    7194:      	add	x2, x2, x9, lsl #4
    7198:      	ldr	x2, [x2]
    719c:      	mov	x6, x2
    71a0:      	mov	x2, #0x1                ; =1
    71a4:      	b	0x71b0 <_stogir.floating.validate+0x3ec>
    71a8:      	movz	x2, #0x0, lsl #48
    71ac:      	movz	x6, #0x0, lsl #48
    71b0:      	lsr	w2, w2, #0
    71b4:      	lsr	x16, x2, #0
    71b8:      	cmp	x16, #0x1
    71bc:      	b.eq	0x71d8 <_stogir.floating.validate+0x414>
    71c0:      	b.lo	0x71c8 <_stogir.floating.validate+0x404>
    71c4:      	b	0x71dc <_stogir.floating.validate+0x418>
    71c8:      	cmp	x16, #0x0
    71cc:      	b.eq	0x71d4 <_stogir.floating.validate+0x410>
    71d0:      	b	0x71dc <_stogir.floating.validate+0x418>
    71d4:      	b	0x71e0 <_stogir.floating.validate+0x41c>
    71d8:      	b	0x7200 <_stogir.floating.validate+0x43c>
    71dc:      	b	0x72e8 <_stogir.floating.validate+0x524>
    71e0:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		00000000000071e0:  ARM64_RELOC_PAGE21	l_stogir.412
    71e4:      	ldr	x16, [x16]
		00000000000071e4:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    71e8:      	orr	x0, x16, xzr
    71ec:      	mov	x19, x8
    71f0:      	mov	x1, x0
    71f4:      	mov	x0, #0x1                ; =1
    71f8:      	mov	x2, #0x18               ; =24
    71fc:      	b	0x7114 <_stogir.floating.validate+0x350>
    7200:      	lsr	w6, w6, #0
    7204:      	add	x16, sp, #0x10
    7208:      	ldr	w2, [x16]
    720c:      	ubfx	x6, x6, #8, #8
    7210:      	uxtb	w16, w3
    7214:      	cmp	w16, wzr
    7218:      	b.eq	0x7294 <_stogir.floating.validate+0x4d0>
    721c:      	uxtb	w16, w5
    7220:      	cmp	w16, wzr
    7224:      	b.eq	0x7294 <_stogir.floating.validate+0x4d0>
    7228:      	mov	x3, #0x1                ; =1
    722c:      	b	0x7298 <_stogir.floating.validate+0x4d4>
    7230:      	movz	x7, #0x0, lsl #48
    7234:      	b	0x716c <_stogir.floating.validate+0x3a8>
    7238:      	movz	x7, #0x0, lsl #48
    723c:      	b	0x7164 <_stogir.floating.validate+0x3a0>
    7240:      	movz	x1, #0x0, lsl #48
    7244:      	lsr	w2, w2, #0
    7248:      	lsr	w3, w3, #0
    724c:      	lsr	w4, w4, #0
    7250:      	lsr	w6, w6, #0
    7254:      	lsr	w1, w1, #0
    7258:      	mov	w5, w1
    725c:      	mov	w1, w4
    7260:      	mov	w4, w3
    7264:      	mov	w3, w2
    7268:      	mov	w2, w6
    726c:      	mov	x19, x8
    7270:      	add	x8, sp, #0x20
    7274:      	bl	0x7274 <_stogir.floating.validate+0x4b0>
		0000000000007274:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    7278:      	add	x16, sp, #0x20
    727c:      	ldr	x0, [x16]
    7280:      	add	x16, sp, #0x20
    7284:      	ldr	x1, [x16, #0x8]
    7288:      	add	x16, sp, #0x20
    728c:      	ldr	x2, [x16, #0x10]
    7290:      	b	0x7114 <_stogir.floating.validate+0x350>
    7294:      	orr	x3, x6, xzr
    7298:      	lsr	w3, w3, #0
    729c:      	ubfx	x2, x2, #8, #8
    72a0:      	sxtw	x3, w3
    72a4:      	cmp	x2, x3
    72a8:      	b.ne	0x72f8 <_stogir.floating.validate+0x534>
    72ac:      	add	x16, sp, #0x10
    72b0:      	ldr	w2, [x16, #0x4]
    72b4:      	add	x16, sp, #0x10
    72b8:      	ldr	w3, [x16, #0x8]
    72bc:      	uxtb	w16, w1
    72c0:      	cmp	w16, wzr
    72c4:      	b.eq	0x7240 <_stogir.floating.validate+0x47c>
    72c8:      	add	x16, sp, #0x10
    72cc:      	ldr	w1, [x16, #0xc]
    72d0:      	sxtw	x1, w1
    72d4:      	b	0x7244 <_stogir.floating.validate+0x480>
    72d8:      	movz	x7, #0x0, lsl #48
    72dc:      	b	0x7234 <_stogir.floating.validate+0x470>
    72e0:      	brk	#0
    72e4:      	b	0x72e0 <_stogir.floating.validate+0x51c>
    72e8:      	brk	#0
    72ec:      	b	0x72e8 <_stogir.floating.validate+0x524>
    72f0:      	mov	x19, x8
    72f4:      	b	0x6f8c <_stogir.floating.validate+0x1c8>
    72f8:      	mov	x19, x8
    72fc:      	b	0x70fc <_stogir.floating.validate+0x338>

0000000000007300 <_stogir.types.integer?>:
    7300:      	sxtw	x0, w0
    7304:      	cmp	x0, #0x1
    7308:      	b.lt	0x731c <_stogir.types.integer?+0x1c>
    730c:      	cmp	x0, #0xb
    7310:      	cset	w0, le
    7314:      	ubfx	x0, x0, #0, #8
    7318:      	b	0x7320 <_stogir.types.integer?+0x20>
    731c:      	movz	x0, #0x0, lsl #48
    7320:      	ret

0000000000007324 <_stogir.integer-unary.valid-type?>:
    7324:      	sxtw	x0, w0
    7328:      	cmp	x0, #0x2d
    732c:      	cset	w2, eq
    7330:      	cmp	x0, #0x1f
    7334:      	cset	w3, eq
    7338:      	cmp	x0, #0x20
    733c:      	cset	w4, eq
    7340:      	cmp	x0, #0x36
    7344:      	cset	w5, eq
    7348:      	uxtb	w16, w3
    734c:      	cmp	w16, wzr
    7350:      	b.ne	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7354:      	uxtb	w16, w4
    7358:      	cmp	w16, wzr
    735c:      	b.ne	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7360:      	uxtb	w16, w2
    7364:      	cmp	w16, wzr
    7368:      	b.ne	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    736c:      	uxtb	w16, w5
    7370:      	cmp	w16, wzr
    7374:      	b.ne	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7378:      	cmp	x0, #0x37
    737c:      	b.eq	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7380:      	cmp	x0, #0x38
    7384:      	b.eq	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7388:      	cmp	x0, #0x39
    738c:      	b.eq	0x7398 <_stogir.integer-unary.valid-type?+0x74>
    7390:      	movz	x0, #0x0, lsl #48
    7394:      	b	0x73d0 <_stogir.integer-unary.valid-type?+0xac>
    7398:      	sxtw	x1, w1
    739c:      	cmp	x1, #0x1
    73a0:      	b.lt	0x73cc <_stogir.integer-unary.valid-type?+0xa8>
    73a4:      	cmp	x1, #0xb
    73a8:      	cset	w0, le
    73ac:      	uxtb	w16, w0
    73b0:      	cmp	w16, wzr
    73b4:      	b.eq	0x73cc <_stogir.integer-unary.valid-type?+0xa8>
    73b8:      	uxtb	w16, w2
    73bc:      	cmp	w16, wzr
    73c0:      	b.eq	0x73dc <_stogir.integer-unary.valid-type?+0xb8>
    73c4:      	mov	x0, #0x1                ; =1
    73c8:      	b	0x73d8 <_stogir.integer-unary.valid-type?+0xb4>
    73cc:      	movz	x0, #0x0, lsl #48
    73d0:      	ret
    73d4:      	mov	x0, #0x1                ; =1
    73d8:      	b	0x73d0 <_stogir.integer-unary.valid-type?+0xac>
    73dc:      	cmp	x1, #0x1
    73e0:      	b.ne	0x73ec <_stogir.integer-unary.valid-type?+0xc8>
    73e4:      	movz	x0, #0x0, lsl #48
    73e8:      	b	0x73d8 <_stogir.integer-unary.valid-type?+0xb4>
    73ec:      	cmp	x1, #0x6
    73f0:      	cset	w2, eq
    73f4:      	uxtb	w16, w3
    73f8:      	cmp	w16, wzr
    73fc:      	b.eq	0x7410 <_stogir.integer-unary.valid-type?+0xec>
    7400:      	uxtb	w16, w2
    7404:      	cmp	w16, wzr
    7408:      	cset	x0, eq
    740c:      	b	0x73d8 <_stogir.integer-unary.valid-type?+0xb4>
    7410:      	uxtb	w16, w4
    7414:      	cmp	w16, wzr
    7418:      	b.eq	0x7434 <_stogir.integer-unary.valid-type?+0x110>
    741c:      	cmp	x1, #0x7
    7420:      	b.lt	0x742c <_stogir.integer-unary.valid-type?+0x108>
    7424:      	ubfx	x0, x0, #0, #8
    7428:      	b	0x7430 <_stogir.integer-unary.valid-type?+0x10c>
    742c:      	movz	x0, #0x0, lsl #48
    7430:      	b	0x73d8 <_stogir.integer-unary.valid-type?+0xb4>
    7434:      	uxtb	w16, w5
    7438:      	cmp	w16, wzr
    743c:      	b.eq	0x73d4 <_stogir.integer-unary.valid-type?+0xb0>
    7440:      	cmp	x1, #0x3
    7444:      	b.ne	0x7460 <_stogir.integer-unary.valid-type?+0x13c>
    7448:      	mov	x0, #0x1                ; =1
    744c:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>
    7450:      	cmp	x1, #0xb
    7454:      	cset	w0, eq
    7458:      	ubfx	x0, x0, #0, #8
    745c:      	b	0x73d8 <_stogir.integer-unary.valid-type?+0xb4>
    7460:      	cmp	x1, #0x4
    7464:      	b.ne	0x7470 <_stogir.integer-unary.valid-type?+0x14c>
    7468:      	mov	x0, #0x1                ; =1
    746c:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>
    7470:      	cmp	x1, #0x5
    7474:      	b.ne	0x7480 <_stogir.integer-unary.valid-type?+0x15c>
    7478:      	mov	x0, #0x1                ; =1
    747c:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>
    7480:      	uxtb	w16, w2
    7484:      	cmp	w16, wzr
    7488:      	b.eq	0x7494 <_stogir.integer-unary.valid-type?+0x170>
    748c:      	mov	x0, #0x1                ; =1
    7490:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>
    7494:      	cmp	x1, #0x9
    7498:      	b.ne	0x74a4 <_stogir.integer-unary.valid-type?+0x180>
    749c:      	mov	x0, #0x1                ; =1
    74a0:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>
    74a4:      	cmp	x1, #0xa
    74a8:      	b.ne	0x7450 <_stogir.integer-unary.valid-type?+0x12c>
    74ac:      	mov	x0, #0x1                ; =1
    74b0:      	b	0x745c <_stogir.integer-unary.valid-type?+0x138>

00000000000074b4 <_stogir.integer-binary.valid-type?>:
    74b4:      	sxtw	x0, w0
    74b8:      	cmp	x0, #0x3a
    74bc:      	cset	w2, eq
    74c0:      	cmp	x0, #0x3b
    74c4:      	cset	w3, eq
    74c8:      	cmp	x0, #0x1a
    74cc:      	b.lt	0x7520 <_stogir.integer-binary.valid-type?+0x6c>
    74d0:      	cmp	x0, #0x1e
    74d4:      	b.gt	0x7520 <_stogir.integer-binary.valid-type?+0x6c>
    74d8:      	sxtw	x1, w1
    74dc:      	cmp	x1, #0x1
    74e0:      	b.lt	0x7550 <_stogir.integer-binary.valid-type?+0x9c>
    74e4:      	cmp	x1, #0xb
    74e8:      	b.gt	0x7550 <_stogir.integer-binary.valid-type?+0x9c>
    74ec:      	cmp	x1, #0x1
    74f0:      	b.ne	0x7558 <_stogir.integer-binary.valid-type?+0xa4>
    74f4:      	cmp	x0, #0x2e
    74f8:      	b.eq	0x7560 <_stogir.integer-binary.valid-type?+0xac>
    74fc:      	cmp	x0, #0x2f
    7500:      	b.eq	0x7560 <_stogir.integer-binary.valid-type?+0xac>
    7504:      	cmp	x0, #0x30
    7508:      	b.eq	0x7560 <_stogir.integer-binary.valid-type?+0xac>
    750c:      	uxtb	w16, w2
    7510:      	cmp	w16, wzr
    7514:      	b.eq	0x7568 <_stogir.integer-binary.valid-type?+0xb4>
    7518:      	mov	x0, #0x1                ; =1
    751c:      	b	0x7570 <_stogir.integer-binary.valid-type?+0xbc>
    7520:      	cmp	x0, #0x2e
    7524:      	b.lt	0x7530 <_stogir.integer-binary.valid-type?+0x7c>
    7528:      	cmp	x0, #0x35
    752c:      	b.le	0x74d8 <_stogir.integer-binary.valid-type?+0x24>
    7530:      	uxtb	w16, w2
    7534:      	cmp	w16, wzr
    7538:      	b.ne	0x74d8 <_stogir.integer-binary.valid-type?+0x24>
    753c:      	uxtb	w16, w3
    7540:      	cmp	w16, wzr
    7544:      	b.ne	0x74d8 <_stogir.integer-binary.valid-type?+0x24>
    7548:      	movz	x0, #0x0, lsl #48
    754c:      	b	0x7554 <_stogir.integer-binary.valid-type?+0xa0>
    7550:      	movz	x0, #0x0, lsl #48
    7554:      	ret
    7558:      	mov	x0, #0x1                ; =1
    755c:      	b	0x7554 <_stogir.integer-binary.valid-type?+0xa0>
    7560:      	mov	x0, #0x1                ; =1
    7564:      	b	0x755c <_stogir.integer-binary.valid-type?+0xa8>
    7568:      	ubfx	x3, x3, #0, #8
    756c:      	mov	x0, x3
    7570:      	b	0x7564 <_stogir.integer-binary.valid-type?+0xb0>

0000000000007574 <_coil.core.Len$slice$len__u8>:
    7574:      	mov	x0, x1
    7578:      	ret

000000000000757c <_inherent$slice$data__u8>:
    757c:      	ret

0000000000007580 <_coil.mem.eql__u8>:
    7580:      	sub	sp, sp, #0x10
    7584:      	str	x29, [sp]
    7588:      	str	x30, [sp, #0x8]
    758c:      	mov	x29, sp
    7590:      	cmp	x2, #0x0
    7594:      	b.ne	0x75a0 <_coil.mem.eql__u8+0x20>
    7598:      	mov	x0, #0x1                ; =1
    759c:      	b	0x75bc <_coil.mem.eql__u8+0x3c>
    75a0:      	lsr	x2, x2, #0
    75a4:      	bl	0x75a4 <_coil.mem.eql__u8+0x24>
		00000000000075a4:  ARM64_RELOC_BRANCH26	_memcmp
    75a8:      	lsr	w0, w0, #0
    75ac:      	sxtw	x0, w0
    75b0:      	cmp	x0, #0x0
    75b4:      	cset	w0, eq
    75b8:      	ubfx	x0, x0, #0, #8
    75bc:      	ldr	x29, [sp]
    75c0:      	ldr	x30, [sp, #0x8]
    75c4:      	add	sp, sp, #0x10
    75c8:      	ret

00000000000075cc <_stogir.opcode.count>:
    75cc:      	mov	x0, #0x83               ; =131
    75d0:      	ret

00000000000075d4 <_stogir.types.valid-scalar?>:
    75d4:      	sxtw	x0, w0
    75d8:      	cmp	x0, #0x0
    75dc:      	b.lt	0x75f0 <_stogir.types.valid-scalar?+0x1c>
    75e0:      	cmp	x0, #0xd
    75e4:      	cset	w0, le
    75e8:      	ubfx	x0, x0, #0, #8
    75ec:      	b	0x75f4 <_stogir.types.valid-scalar?+0x20>
    75f0:      	movz	x0, #0x0, lsl #48
    75f4:      	ret

00000000000075f8 <_stogir.types.vector?>:
    75f8:      	sxtw	x0, w0
    75fc:      	cmp	x0, #0xf
    7600:      	b.le	0x763c <_stogir.types.vector?+0x44>
    7604:      	cmp	x0, #0x80
    7608:      	b.ge	0x764c <_stogir.types.vector?+0x54>
    760c:      	and	x1, x0, #0xf
    7610:      	lsr	w1, w1, #0
    7614:      	sxtw	x1, w1
    7618:      	cmp	x1, #0x1
    761c:      	b.lt	0x7644 <_stogir.types.vector?+0x4c>
    7620:      	and	x0, x0, #0xf
    7624:      	lsr	w0, w0, #0
    7628:      	sxtw	x0, w0
    762c:      	cmp	x0, #0xd
    7630:      	cset	w0, le
    7634:      	ubfx	x0, x0, #0, #8
    7638:      	b	0x7648 <_stogir.types.vector?+0x50>
    763c:      	movz	x0, #0x0, lsl #48
    7640:      	b	0x7648 <_stogir.types.vector?+0x50>
    7644:      	movz	x0, #0x0, lsl #48
    7648:      	ret
    764c:      	movz	x0, #0x0, lsl #48
    7650:      	b	0x7648 <_stogir.types.vector?+0x50>

0000000000007654 <_coil.core.Get$slice$get__i8>:
    7654:      	add	x0, x0, x2
    7658:      	ldrsb	w0, [x0]
    765c:      	sxtb	x0, w0
    7660:      	ret

0000000000007664 <_stogir.opcode.metadata>:
    7664:      	sub	sp, sp, #0x10
    7668:      	mov	x0, sp
    766c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		000000000000766c:  ARM64_RELOC_PAGE21	l_stogir.413
    7670:      	ldr	x16, [x16]
		0000000000007670:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    7674:      	orr	x1, x16, xzr
    7678:      	str	x1, [x0]
    767c:      	mov	x17, #0x83              ; =131
    7680:      	str	x17, [x0, #0x8]
    7684:      	ldr	x0, [sp]
    7688:      	ldr	x1, [sp, #0x8]
    768c:      	add	sp, sp, #0x10
    7690:      	ret

0000000000007694 <_coil.core.Get$slice$get__u32>:
    7694:      	add	x0, x0, x2, lsl #2
    7698:      	ldr	w0, [x0]
    769c:      	ret

00000000000076a0 <_stogir.opcode.operand-code-word>:
    76a0:      	sxtw	x1, w1
    76a4:      	cmp	x1, #0x0
    76a8:      	b.le	0x76bc <_stogir.opcode.operand-code-word+0x1c>
    76ac:      	cmp	x1, #0x4
    76b0:      	b.le	0x76c4 <_stogir.opcode.operand-code-word+0x24>
    76b4:      	mov	x1, #0x4                ; =4
    76b8:      	b	0x76d0 <_stogir.opcode.operand-code-word+0x30>
    76bc:      	movz	x0, #0x0, lsl #48
    76c0:      	b	0x76f0 <_stogir.opcode.operand-code-word+0x50>
    76c4:      	sub	x1, x1, #0x1
    76c8:      	lsr	w1, w1, #0
    76cc:      	sxtw	x1, w1
    76d0:      	ubfx	x0, x0, #0, #32
    76d4:      	lsl	x1, x1, #2
    76d8:      	lsr	w1, w1, #0
    76dc:      	ubfx	x1, x1, #0, #32
    76e0:      	lsr	x0, x0, x1
    76e4:      	lsr	w0, w0, #0
    76e8:      	and	x0, x0, #0xf
    76ec:      	lsr	w0, w0, #0
    76f0:      	ret

00000000000076f4 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    76f4:      	ldr	x0, [x0]
    76f8:      	add	x0, x0, x1, lsl #4
    76fc:      	ret

0000000000007700 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7700:      	ldr	x0, [x0, #0x8]
    7704:      	ret

0000000000007708 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7708:      	ldr	x0, [x0, #0x8]
    770c:      	ret

0000000000007710 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7710:      	sub	sp, sp, #0x10
    7714:      	mov	x1, sp
    7718:      	ldr	x2, [x0]
    771c:      	ldr	x0, [x0, #0x8]
    7720:      	str	x2, [x1]
    7724:      	str	x0, [x1, #0x8]
    7728:      	ldr	x0, [sp]
    772c:      	ldr	x1, [sp, #0x8]
    7730:      	add	sp, sp, #0x10
    7734:      	ret

0000000000007738 <_coil.slice.subslice__u8>:
    7738:      	sub	sp, sp, #0x10
    773c:      	mov	x1, sp
    7740:      	sub	x3, x3, x2
    7744:      	add	x0, x0, x2
    7748:      	str	x0, [x1]
    774c:      	str	x3, [x1, #0x8]
    7750:      	ldr	x0, [sp]
    7754:      	ldr	x1, [sp, #0x8]
    7758:      	add	sp, sp, #0x10
    775c:      	ret

0000000000007760 <_stogir.floating.operation?>:
    7760:      	sxtw	x0, w0
    7764:      	cmp	x0, #0xe
    7768:      	b.lt	0x777c <_stogir.floating.operation?+0x1c>
    776c:      	cmp	x0, #0x19
    7770:      	b.gt	0x777c <_stogir.floating.operation?+0x1c>
    7774:      	mov	x0, #0x1                ; =1
    7778:      	b	0x77a8 <_stogir.floating.operation?+0x48>
    777c:      	cmp	x0, #0x1f
    7780:      	b.eq	0x77a4 <_stogir.floating.operation?+0x44>
    7784:      	cmp	x0, #0x20
    7788:      	b.eq	0x77a4 <_stogir.floating.operation?+0x44>
    778c:      	cmp	x0, #0x1a
    7790:      	b.lt	0x77bc <_stogir.floating.operation?+0x5c>
    7794:      	cmp	x0, #0x1d
    7798:      	b.gt	0x77bc <_stogir.floating.operation?+0x5c>
    779c:      	mov	x0, #0x1                ; =1
    77a0:      	b	0x77b8 <_stogir.floating.operation?+0x58>
    77a4:      	mov	x0, #0x1                ; =1
    77a8:      	ret
    77ac:      	cmp	x0, #0x3b
    77b0:      	cset	w0, eq
    77b4:      	ubfx	x0, x0, #0, #8
    77b8:      	b	0x77a8 <_stogir.floating.operation?+0x48>
    77bc:      	cmp	x0, #0x3a
    77c0:      	b.ne	0x77ac <_stogir.floating.operation?+0x4c>
    77c4:      	mov	x0, #0x1                ; =1
    77c8:      	b	0x77b8 <_stogir.floating.operation?+0x58>

00000000000077cc <_stogir.types.floating?>:
    77cc:      	sxtw	x0, w0
    77d0:      	cmp	x0, #0xc
    77d4:      	b.ne	0x77e0 <_stogir.types.floating?+0x14>
    77d8:      	mov	x0, #0x1                ; =1
    77dc:      	b	0x77ec <_stogir.types.floating?+0x20>
    77e0:      	cmp	x0, #0xd
    77e4:      	cset	w0, eq
    77e8:      	ubfx	x0, x0, #0, #8
    77ec:      	ret

00000000000077f0 <_stogir.vector-lanes.validate>:
    77f0:      	sub	sp, sp, #0x50
    77f4:      	str	x29, [sp]
    77f8:      	str	x30, [sp, #0x8]
    77fc:      	mov	x29, sp
    7800:      	str	x19, [sp, #0x40]
    7804:      	sxtw	x1, w1
    7808:      	lsl	x3, x1, #2
    780c:      	cmp	x1, #0x0
    7810:      	cset	w4, gt
    7814:      	movz	x16, #0x0, lsl #48
    7818:      	sub	x5, x16, x1
    781c:      	sub	x6, x5, #0x1
    7820:      	uxtb	w16, w4
    7824:      	cmp	w16, wzr
    7828:      	b.eq	0x7868 <_stogir.vector-lanes.validate+0x78>
    782c:      	ldr	x5, [x0, #0x8]
    7830:      	cmp	x1, x5
    7834:      	b.ge	0x78b8 <_stogir.vector-lanes.validate+0xc8>
    7838:      	add	x5, x0, #0x78
    783c:      	ldr	x5, [x5, #0x8]
    7840:      	cmp	x1, x5
    7844:      	b.ge	0x79d4 <_stogir.vector-lanes.validate+0x1e4>
    7848:      	ldr	x5, [x0, #0x78]
    784c:      	add	x5, x3, x5
    7850:      	ldr	w5, [x5]
    7854:      	sxtw	x5, w5
    7858:      	cmp	x5, #0x0
    785c:      	cset	w5, ge
    7860:      	ubfx	x5, x5, #0, #8
    7864:      	b	0x79d8 <_stogir.vector-lanes.validate+0x1e8>
    7868:      	cmp	x1, #0x0
    786c:      	b.ge	0x78c0 <_stogir.vector-lanes.validate+0xd0>
    7870:      	add	x7, x0, #0x28
    7874:      	add	x9, x0, #0x50
    7878:      	ldr	x7, [x7, #0x8]
    787c:      	ldr	x9, [x9, #0x8]
    7880:      	cmp	x7, x9
    7884:      	b.ne	0x78b0 <_stogir.vector-lanes.validate+0xc0>
    7888:      	cmp	x5, x7
    788c:      	b.gt	0x7a18 <_stogir.vector-lanes.validate+0x228>
    7890:      	ldr	x5, [x0, #0x50]
    7894:      	add	x5, x5, x6, lsl #2
    7898:      	ldr	w5, [x5]
    789c:      	sxtw	x5, w5
    78a0:      	cmp	x5, #0x0
    78a4:      	cset	w5, gt
    78a8:      	ubfx	x5, x5, #0, #8
    78ac:      	b	0x7a1c <_stogir.vector-lanes.validate+0x22c>
    78b0:      	movz	x5, #0x0, lsl #48
    78b4:      	b	0x78c4 <_stogir.vector-lanes.validate+0xd4>
    78b8:      	movz	x5, #0x0, lsl #48
    78bc:      	b	0x78c4 <_stogir.vector-lanes.validate+0xd4>
    78c0:      	movz	x5, #0x0, lsl #48
    78c4:      	cmp	x5, #0x0
    78c8:      	b.eq	0x7924 <_stogir.vector-lanes.validate+0x134>
    78cc:      	uxtb	w16, w4
    78d0:      	cmp	w16, wzr
    78d4:      	b.eq	0x78f8 <_stogir.vector-lanes.validate+0x108>
    78d8:      	ldr	x4, [x0]
    78dc:      	add	x4, x4, x1, lsl #4
    78e0:      	ldr	x5, [x4]
    78e4:      	ldr	x4, [x4, #0x8]
    78e8:      	fmov	d31, x4
    78ec:      	mov	x4, x5
    78f0:      	fmov	x5, d31
    78f4:      	b	0x7914 <_stogir.vector-lanes.validate+0x124>
    78f8:      	ldr	x4, [x0, #0x28]
    78fc:      	add	x4, x4, x6, lsl #4
    7900:      	ldr	x5, [x4]
    7904:      	ldr	x4, [x4, #0x8]
    7908:      	fmov	d31, x4
    790c:      	mov	x4, x5
    7910:      	fmov	x5, d31
    7914:      	mov	x6, x5
    7918:      	mov	x5, x4
    791c:      	mov	x4, #0x1                ; =1
    7920:      	b	0x7930 <_stogir.vector-lanes.validate+0x140>
    7924:      	movz	x4, #0x0, lsl #48
    7928:      	movz	x5, #0x0, lsl #48
    792c:      	movz	x6, #0x0, lsl #48
    7930:      	lsr	w4, w4, #0
    7934:      	lsr	x16, x4, #0
    7938:      	cmp	x16, #0x1
    793c:      	b.eq	0x7958 <_stogir.vector-lanes.validate+0x168>
    7940:      	b.lo	0x7948 <_stogir.vector-lanes.validate+0x158>
    7944:      	b	0x795c <_stogir.vector-lanes.validate+0x16c>
    7948:      	cmp	x16, #0x0
    794c:      	b.eq	0x7954 <_stogir.vector-lanes.validate+0x164>
    7950:      	b	0x795c <_stogir.vector-lanes.validate+0x16c>
    7954:      	b	0x7960 <_stogir.vector-lanes.validate+0x170>
    7958:      	b	0x7980 <_stogir.vector-lanes.validate+0x190>
    795c:      	b	0x7afc <_stogir.vector-lanes.validate+0x30c>
    7960:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		0000000000007960:  ARM64_RELOC_PAGE21	l_stogir.414
    7964:      	ldr	x16, [x16]
		0000000000007964:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    7968:      	orr	x0, x16, xzr
    796c:      	mov	x19, x8
    7970:      	mov	x1, x0
    7974:      	mov	x0, #0x1                ; =1
    7978:      	mov	x2, #0x1f               ; =31
    797c:      	b	0x79b4 <_stogir.vector-lanes.validate+0x1c4>
    7980:      	add	x16, sp, #0x10
    7984:      	str	x5, [x16]
    7988:      	add	x16, sp, #0x10
    798c:      	str	x6, [x16, #0x8]
    7990:      	cmp	x1, #0x0
    7994:      	b.gt	0x79dc <_stogir.vector-lanes.validate+0x1ec>
    7998:      	mov	x19, x8
    799c:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		000000000000799c:  ARM64_RELOC_PAGE21	l_stogir.415
    79a0:      	ldr	x16, [x16]
		00000000000079a0:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    79a4:      	orr	x0, x16, xzr
    79a8:      	mov	x1, x0
    79ac:      	mov	x0, #0x1                ; =1
    79b0:      	mov	x2, #0x25               ; =37
    79b4:      	str	x0, [x19]
    79b8:      	str	x1, [x19, #0x8]
    79bc:      	str	x2, [x19, #0x10]
    79c0:      	ldr	x19, [sp, #0x40]
    79c4:      	ldr	x29, [sp]
    79c8:      	ldr	x30, [sp, #0x8]
    79cc:      	add	sp, sp, #0x50
    79d0:      	ret
    79d4:      	movz	x5, #0x0, lsl #48
    79d8:      	b	0x78bc <_stogir.vector-lanes.validate+0xcc>
    79dc:      	uxtb	w5, w5
    79e0:      	orr	x1, x5, xzr
    79e4:      	cmp	x1, #0x3d
    79e8:      	b.lt	0x7b04 <_stogir.vector-lanes.validate+0x314>
    79ec:      	cmp	x1, #0x3f
    79f0:      	b.gt	0x7b0c <_stogir.vector-lanes.validate+0x31c>
    79f4:      	cmp	x1, #0x3e
    79f8:      	cset	w4, eq
    79fc:      	ldr	x6, [x0, #0x78]
    7a00:      	add	x3, x3, x6
    7a04:      	ldr	w3, [x3]
    7a08:      	cmp	x1, #0x3d
    7a0c:      	b.ne	0x7a8c <_stogir.vector-lanes.validate+0x29c>
    7a10:      	mov	x6, #0x2                ; =2
    7a14:      	b	0x7aa0 <_stogir.vector-lanes.validate+0x2b0>
    7a18:      	movz	x5, #0x0, lsl #48
    7a1c:      	b	0x78b4 <_stogir.vector-lanes.validate+0xc4>
    7a20:      	movz	x4, #0x0, lsl #48
    7a24:      	lsr	w2, w2, #0
    7a28:      	lsr	w6, w6, #0
    7a2c:      	lsr	w1, w1, #0
    7a30:      	lsr	w5, w5, #0
    7a34:      	lsr	w4, w4, #0
    7a38:      	ubfx	x3, x3, #8, #8
    7a3c:      	lsr	w3, w3, #0
    7a40:      	mov	x19, x8
    7a44:      	add	x8, sp, #0x20
    7a48:      	fmov	s31, w1
    7a4c:      	mov	w1, w5
    7a50:      	fmov	w5, s31
    7a54:      	fmov	s31, w2
    7a58:      	mov	w2, w3
    7a5c:      	fmov	w3, s31
    7a60:      	fmov	s31, w4
    7a64:      	mov	w4, w6
    7a68:      	fmov	w6, s31
    7a6c:      	bl	0x7a6c <_stogir.vector-lanes.validate+0x27c>
		0000000000007a6c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7a70:      	add	x16, sp, #0x20
    7a74:      	ldr	x0, [x16]
    7a78:      	add	x16, sp, #0x20
    7a7c:      	ldr	x1, [x16, #0x8]
    7a80:      	add	x16, sp, #0x20
    7a84:      	ldr	x2, [x16, #0x10]
    7a88:      	b	0x79b4 <_stogir.vector-lanes.validate+0x1c4>
    7a8c:      	uxtb	w16, w4
    7a90:      	cmp	w16, wzr
    7a94:      	mov	x16, #0x3               ; =3
    7a98:      	mov	x17, #0x1               ; =1
    7a9c:      	csel	x6, x16, x17, ne
    7aa0:      	sxtw	x3, w3
    7aa4:      	lsr	w6, w6, #0
    7aa8:      	sxtw	x6, w6
    7aac:      	cmp	x3, x6
    7ab0:      	b.ne	0x7b14 <_stogir.vector-lanes.validate+0x324>
    7ab4:      	add	x16, sp, #0x10
    7ab8:      	ldr	w3, [x16]
    7abc:      	add	x16, sp, #0x10
    7ac0:      	ldr	w6, [x16, #0x4]
    7ac4:      	cmp	x1, #0x3f
    7ac8:      	b.ne	0x7ad4 <_stogir.vector-lanes.validate+0x2e4>
    7acc:      	movz	x1, #0x0, lsl #48
    7ad0:      	b	0x7ae0 <_stogir.vector-lanes.validate+0x2f0>
    7ad4:      	add	x16, sp, #0x10
    7ad8:      	ldr	w1, [x16, #0x8]
    7adc:      	sxtw	x1, w1
    7ae0:      	uxtb	w16, w4
    7ae4:      	cmp	w16, wzr
    7ae8:      	b.eq	0x7a20 <_stogir.vector-lanes.validate+0x230>
    7aec:      	add	x16, sp, #0x10
    7af0:      	ldr	w4, [x16, #0xc]
    7af4:      	sxtw	x4, w4
    7af8:      	b	0x7a24 <_stogir.vector-lanes.validate+0x234>
    7afc:      	brk	#0
    7b00:      	b	0x7afc <_stogir.vector-lanes.validate+0x30c>
    7b04:      	mov	x19, x8
    7b08:      	b	0x799c <_stogir.vector-lanes.validate+0x1ac>
    7b0c:      	mov	x19, x8
    7b10:      	b	0x799c <_stogir.vector-lanes.validate+0x1ac>
    7b14:      	mov	x19, x8
    7b18:      	b	0x799c <_stogir.vector-lanes.validate+0x1ac>

0000000000007b1c <_stogir.vector-comparison.node?>:
    7b1c:      	sxtw	x1, w1
    7b20:      	cmp	x1, #0x0
    7b24:      	cset	w2, gt
    7b28:      	movz	x16, #0x0, lsl #48
    7b2c:      	sub	x3, x16, x1
    7b30:      	sub	x4, x3, #0x1
    7b34:      	uxtb	w16, w2
    7b38:      	cmp	w16, wzr
    7b3c:      	b.eq	0x7b7c <_stogir.vector-comparison.node?+0x60>
    7b40:      	ldr	x3, [x0, #0x8]
    7b44:      	cmp	x1, x3
    7b48:      	b.ge	0x7bcc <_stogir.vector-comparison.node?+0xb0>
    7b4c:      	add	x3, x0, #0x78
    7b50:      	ldr	x3, [x3, #0x8]
    7b54:      	cmp	x1, x3
    7b58:      	b.ge	0x7cac <_stogir.vector-comparison.node?+0x190>
    7b5c:      	ldr	x3, [x0, #0x78]
    7b60:      	add	x3, x3, x1, lsl #2
    7b64:      	ldr	w3, [x3]
    7b68:      	sxtw	x3, w3
    7b6c:      	cmp	x3, #0x0
    7b70:      	cset	w3, ge
    7b74:      	ubfx	x3, x3, #0, #8
    7b78:      	b	0x7cb0 <_stogir.vector-comparison.node?+0x194>
    7b7c:      	cmp	x1, #0x0
    7b80:      	b.ge	0x7bd4 <_stogir.vector-comparison.node?+0xb8>
    7b84:      	add	x5, x0, #0x28
    7b88:      	add	x6, x0, #0x50
    7b8c:      	ldr	x5, [x5, #0x8]
    7b90:      	ldr	x6, [x6, #0x8]
    7b94:      	cmp	x5, x6
    7b98:      	b.ne	0x7bc4 <_stogir.vector-comparison.node?+0xa8>
    7b9c:      	cmp	x3, x5
    7ba0:      	b.gt	0x7cb4 <_stogir.vector-comparison.node?+0x198>
    7ba4:      	ldr	x3, [x0, #0x50]
    7ba8:      	add	x3, x3, x4, lsl #2
    7bac:      	ldr	w3, [x3]
    7bb0:      	sxtw	x3, w3
    7bb4:      	cmp	x3, #0x0
    7bb8:      	cset	w3, gt
    7bbc:      	ubfx	x3, x3, #0, #8
    7bc0:      	b	0x7cb8 <_stogir.vector-comparison.node?+0x19c>
    7bc4:      	movz	x3, #0x0, lsl #48
    7bc8:      	b	0x7bd8 <_stogir.vector-comparison.node?+0xbc>
    7bcc:      	movz	x3, #0x0, lsl #48
    7bd0:      	b	0x7bd8 <_stogir.vector-comparison.node?+0xbc>
    7bd4:      	movz	x3, #0x0, lsl #48
    7bd8:      	cmp	x3, #0x0
    7bdc:      	b.eq	0x7c14 <_stogir.vector-comparison.node?+0xf8>
    7be0:      	uxtb	w16, w2
    7be4:      	cmp	w16, wzr
    7be8:      	b.eq	0x7bfc <_stogir.vector-comparison.node?+0xe0>
    7bec:      	ldr	x0, [x0]
    7bf0:      	add	x0, x0, x1, lsl #4
    7bf4:      	ldr	x0, [x0]
    7bf8:      	b	0x7c08 <_stogir.vector-comparison.node?+0xec>
    7bfc:      	ldr	x0, [x0, #0x28]
    7c00:      	add	x0, x0, x4, lsl #4
    7c04:      	ldr	x0, [x0]
    7c08:      	mov	x1, x0
    7c0c:      	mov	x0, #0x1                ; =1
    7c10:      	b	0x7c1c <_stogir.vector-comparison.node?+0x100>
    7c14:      	movz	x0, #0x0, lsl #48
    7c18:      	movz	x1, #0x0, lsl #48
    7c1c:      	lsr	w0, w0, #0
    7c20:      	lsr	x16, x0, #0
    7c24:      	cmp	x16, #0x1
    7c28:      	b.eq	0x7c44 <_stogir.vector-comparison.node?+0x128>
    7c2c:      	b.lo	0x7c34 <_stogir.vector-comparison.node?+0x118>
    7c30:      	b	0x7c48 <_stogir.vector-comparison.node?+0x12c>
    7c34:      	cmp	x16, #0x0
    7c38:      	b.eq	0x7c40 <_stogir.vector-comparison.node?+0x124>
    7c3c:      	b	0x7c48 <_stogir.vector-comparison.node?+0x12c>
    7c40:      	b	0x7c4c <_stogir.vector-comparison.node?+0x130>
    7c44:      	b	0x7c5c <_stogir.vector-comparison.node?+0x140>
    7c48:      	b	0x7cd4 <_stogir.vector-comparison.node?+0x1b8>
    7c4c:      	movz	x0, #0x0, lsl #48
    7c50:      	b	0x7c58 <_stogir.vector-comparison.node?+0x13c>
    7c54:      	movz	x0, #0x0, lsl #48
    7c58:      	ret
    7c5c:      	uxtb	w0, w1
    7c60:      	cmp	x0, #0xe
    7c64:      	b.lt	0x7c54 <_stogir.vector-comparison.node?+0x138>
    7c68:      	cmp	x0, #0x19
    7c6c:      	b.gt	0x7c54 <_stogir.vector-comparison.node?+0x138>
    7c70:      	lsr	w1, w1, #0
    7c74:      	ubfx	x0, x1, #8, #8
    7c78:      	cmp	x0, #0xf
    7c7c:      	b.le	0x7cbc <_stogir.vector-comparison.node?+0x1a0>
    7c80:      	cmp	x0, #0x80
    7c84:      	b.ge	0x7cc4 <_stogir.vector-comparison.node?+0x1a8>
    7c88:      	and	x0, x0, #0xf
    7c8c:      	lsr	w0, w0, #0
    7c90:      	sxtw	x0, w0
    7c94:      	cmp	x0, #0x1
    7c98:      	b.lt	0x7ccc <_stogir.vector-comparison.node?+0x1b0>
    7c9c:      	cmp	x0, #0xd
    7ca0:      	cset	w0, le
    7ca4:      	ubfx	x0, x0, #0, #8
    7ca8:      	b	0x7cd0 <_stogir.vector-comparison.node?+0x1b4>
    7cac:      	movz	x3, #0x0, lsl #48
    7cb0:      	b	0x7bd0 <_stogir.vector-comparison.node?+0xb4>
    7cb4:      	movz	x3, #0x0, lsl #48
    7cb8:      	b	0x7bc8 <_stogir.vector-comparison.node?+0xac>
    7cbc:      	movz	x0, #0x0, lsl #48
    7cc0:      	b	0x7c58 <_stogir.vector-comparison.node?+0x13c>
    7cc4:      	movz	x0, #0x0, lsl #48
    7cc8:      	b	0x7cc0 <_stogir.vector-comparison.node?+0x1a4>
    7ccc:      	movz	x0, #0x0, lsl #48
    7cd0:      	b	0x7cc8 <_stogir.vector-comparison.node?+0x1ac>
    7cd4:      	brk	#0
    7cd8:      	b	0x7cd4 <_stogir.vector-comparison.node?+0x1b8>

0000000000007cdc <_stogir.vector-comparison.validate>:
    7cdc:      	sub	sp, sp, #0x50
    7ce0:      	str	x29, [sp]
    7ce4:      	str	x30, [sp, #0x8]
    7ce8:      	mov	x29, sp
    7cec:      	str	x19, [sp, #0x40]
    7cf0:      	sxtw	x1, w1
    7cf4:      	lsl	x3, x1, #2
    7cf8:      	cmp	x1, #0x0
    7cfc:      	cset	w4, gt
    7d00:      	movz	x16, #0x0, lsl #48
    7d04:      	sub	x5, x16, x1
    7d08:      	sub	x6, x5, #0x1
    7d0c:      	uxtb	w16, w4
    7d10:      	cmp	w16, wzr
    7d14:      	b.eq	0x7d54 <_stogir.vector-comparison.validate+0x78>
    7d18:      	ldr	x5, [x0, #0x8]
    7d1c:      	cmp	x1, x5
    7d20:      	b.ge	0x7da4 <_stogir.vector-comparison.validate+0xc8>
    7d24:      	add	x5, x0, #0x78
    7d28:      	ldr	x5, [x5, #0x8]
    7d2c:      	cmp	x1, x5
    7d30:      	b.ge	0x7ec4 <_stogir.vector-comparison.validate+0x1e8>
    7d34:      	ldr	x5, [x0, #0x78]
    7d38:      	add	x5, x3, x5
    7d3c:      	ldr	w5, [x5]
    7d40:      	sxtw	x5, w5
    7d44:      	cmp	x5, #0x0
    7d48:      	cset	w5, ge
    7d4c:      	ubfx	x5, x5, #0, #8
    7d50:      	b	0x7ec8 <_stogir.vector-comparison.validate+0x1ec>
    7d54:      	cmp	x1, #0x0
    7d58:      	b.ge	0x7dac <_stogir.vector-comparison.validate+0xd0>
    7d5c:      	add	x7, x0, #0x28
    7d60:      	add	x9, x0, #0x50
    7d64:      	ldr	x7, [x7, #0x8]
    7d68:      	ldr	x9, [x9, #0x8]
    7d6c:      	cmp	x7, x9
    7d70:      	b.ne	0x7d9c <_stogir.vector-comparison.validate+0xc0>
    7d74:      	cmp	x5, x7
    7d78:      	b.gt	0x7f18 <_stogir.vector-comparison.validate+0x23c>
    7d7c:      	ldr	x5, [x0, #0x50]
    7d80:      	add	x5, x5, x6, lsl #2
    7d84:      	ldr	w5, [x5]
    7d88:      	sxtw	x5, w5
    7d8c:      	cmp	x5, #0x0
    7d90:      	cset	w5, gt
    7d94:      	ubfx	x5, x5, #0, #8
    7d98:      	b	0x7f1c <_stogir.vector-comparison.validate+0x240>
    7d9c:      	movz	x5, #0x0, lsl #48
    7da0:      	b	0x7db0 <_stogir.vector-comparison.validate+0xd4>
    7da4:      	movz	x5, #0x0, lsl #48
    7da8:      	b	0x7db0 <_stogir.vector-comparison.validate+0xd4>
    7dac:      	movz	x5, #0x0, lsl #48
    7db0:      	lsl	x7, x1, #4
    7db4:      	cmp	x5, #0x0
    7db8:      	b.eq	0x7e14 <_stogir.vector-comparison.validate+0x138>
    7dbc:      	uxtb	w16, w4
    7dc0:      	cmp	w16, wzr
    7dc4:      	b.eq	0x7de8 <_stogir.vector-comparison.validate+0x10c>
    7dc8:      	ldr	x4, [x0]
    7dcc:      	add	x4, x7, x4
    7dd0:      	ldr	x5, [x4]
    7dd4:      	ldr	x4, [x4, #0x8]
    7dd8:      	fmov	d31, x4
    7ddc:      	mov	x4, x5
    7de0:      	fmov	x5, d31
    7de4:      	b	0x7e04 <_stogir.vector-comparison.validate+0x128>
    7de8:      	ldr	x4, [x0, #0x28]
    7dec:      	add	x4, x4, x6, lsl #4
    7df0:      	ldr	x5, [x4]
    7df4:      	ldr	x4, [x4, #0x8]
    7df8:      	fmov	d31, x4
    7dfc:      	mov	x4, x5
    7e00:      	fmov	x5, d31
    7e04:      	mov	x6, x5
    7e08:      	mov	x5, x4
    7e0c:      	mov	x4, #0x1                ; =1
    7e10:      	b	0x7e20 <_stogir.vector-comparison.validate+0x144>
    7e14:      	movz	x4, #0x0, lsl #48
    7e18:      	movz	x5, #0x0, lsl #48
    7e1c:      	movz	x6, #0x0, lsl #48
    7e20:      	lsr	w4, w4, #0
    7e24:      	lsr	x16, x4, #0
    7e28:      	cmp	x16, #0x1
    7e2c:      	b.eq	0x7e48 <_stogir.vector-comparison.validate+0x16c>
    7e30:      	b.lo	0x7e38 <_stogir.vector-comparison.validate+0x15c>
    7e34:      	b	0x7e4c <_stogir.vector-comparison.validate+0x170>
    7e38:      	cmp	x16, #0x0
    7e3c:      	b.eq	0x7e44 <_stogir.vector-comparison.validate+0x168>
    7e40:      	b	0x7e4c <_stogir.vector-comparison.validate+0x170>
    7e44:      	b	0x7e50 <_stogir.vector-comparison.validate+0x174>
    7e48:      	b	0x7e8c <_stogir.vector-comparison.validate+0x1b0>
    7e4c:      	b	0x802c <_stogir.vector-comparison.validate+0x350>
    7e50:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		0000000000007e50:  ARM64_RELOC_PAGE21	l_stogir.416
    7e54:      	ldr	x16, [x16]
		0000000000007e54:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    7e58:      	orr	x0, x16, xzr
    7e5c:      	mov	x19, x8
    7e60:      	mov	x1, x0
    7e64:      	mov	x0, #0x1                ; =1
    7e68:      	mov	x2, #0x25               ; =37
    7e6c:      	str	x0, [x19]
    7e70:      	str	x1, [x19, #0x8]
    7e74:      	str	x2, [x19, #0x10]
    7e78:      	ldr	x19, [sp, #0x40]
    7e7c:      	ldr	x29, [sp]
    7e80:      	ldr	x30, [sp, #0x8]
    7e84:      	add	sp, sp, #0x50
    7e88:      	ret
    7e8c:      	add	x16, sp, #0x10
    7e90:      	str	x5, [x16]
    7e94:      	add	x16, sp, #0x10
    7e98:      	str	x6, [x16, #0x8]
    7e9c:      	cmp	x1, #0x0
    7ea0:      	b.gt	0x7ecc <_stogir.vector-comparison.validate+0x1f0>
    7ea4:      	mov	x19, x8
    7ea8:      	adrp	x16, 0x7000 <_stogir.floating.validate+0x23c>
		0000000000007ea8:  ARM64_RELOC_PAGE21	l_stogir.417
    7eac:      	ldr	x16, [x16]
		0000000000007eac:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    7eb0:      	orr	x0, x16, xzr
    7eb4:      	mov	x1, x0
    7eb8:      	mov	x0, #0x1                ; =1
    7ebc:      	mov	x2, #0x2b               ; =43
    7ec0:      	b	0x7e6c <_stogir.vector-comparison.validate+0x190>
    7ec4:      	movz	x5, #0x0, lsl #48
    7ec8:      	b	0x7da8 <_stogir.vector-comparison.validate+0xcc>
    7ecc:      	ldr	x4, [x0, #0x8]
    7ed0:      	cmp	x1, x4
    7ed4:      	b.ge	0x7f20 <_stogir.vector-comparison.validate+0x244>
    7ed8:      	add	x4, x0, #0x78
    7edc:      	ldr	x4, [x4, #0x8]
    7ee0:      	cmp	x1, x4
    7ee4:      	b.ge	0x7f20 <_stogir.vector-comparison.validate+0x244>
    7ee8:      	ldr	x1, [x0, #0x78]
    7eec:      	add	x1, x3, x1
    7ef0:      	ldr	w1, [x1]
    7ef4:      	sxtw	x1, w1
    7ef8:      	cmp	x1, #0x0
    7efc:      	b.lt	0x7f20 <_stogir.vector-comparison.validate+0x244>
    7f00:      	ldr	x1, [x0]
    7f04:      	add	x1, x7, x1
    7f08:      	ldr	x1, [x1]
    7f0c:      	mov	x4, x1
    7f10:      	mov	x1, #0x1                ; =1
    7f14:      	b	0x7f28 <_stogir.vector-comparison.validate+0x24c>
    7f18:      	movz	x5, #0x0, lsl #48
    7f1c:      	b	0x7da0 <_stogir.vector-comparison.validate+0xc4>
    7f20:      	movz	x1, #0x0, lsl #48
    7f24:      	movz	x4, #0x0, lsl #48
    7f28:      	lsr	w1, w1, #0
    7f2c:      	lsr	x16, x1, #0
    7f30:      	cmp	x16, #0x1
    7f34:      	b.eq	0x7f50 <_stogir.vector-comparison.validate+0x274>
    7f38:      	b.lo	0x7f40 <_stogir.vector-comparison.validate+0x264>
    7f3c:      	b	0x7f54 <_stogir.vector-comparison.validate+0x278>
    7f40:      	cmp	x16, #0x0
    7f44:      	b.eq	0x7f4c <_stogir.vector-comparison.validate+0x270>
    7f48:      	b	0x7f54 <_stogir.vector-comparison.validate+0x278>
    7f4c:      	b	0x7f58 <_stogir.vector-comparison.validate+0x27c>
    7f50:      	b	0x7f60 <_stogir.vector-comparison.validate+0x284>
    7f54:      	b	0x8034 <_stogir.vector-comparison.validate+0x358>
    7f58:      	mov	x19, x8
    7f5c:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    7f60:      	uxtb	w1, w4
    7f64:      	cmp	x1, #0xe
    7f68:      	b.lt	0x803c <_stogir.vector-comparison.validate+0x360>
    7f6c:      	cmp	x1, #0x19
    7f70:      	b.gt	0x8044 <_stogir.vector-comparison.validate+0x368>
    7f74:      	lsr	w4, w4, #0
    7f78:      	ubfx	x1, x4, #8, #8
    7f7c:      	cmp	x1, #0xf
    7f80:      	b.le	0x804c <_stogir.vector-comparison.validate+0x370>
    7f84:      	cmp	x1, #0x80
    7f88:      	b.ge	0x8054 <_stogir.vector-comparison.validate+0x378>
    7f8c:      	and	x1, x1, #0xf
    7f90:      	lsr	w1, w1, #0
    7f94:      	sxtw	x1, w1
    7f98:      	cmp	x1, #0x1
    7f9c:      	b.lt	0x805c <_stogir.vector-comparison.validate+0x380>
    7fa0:      	cmp	x1, #0xd
    7fa4:      	b.gt	0x8064 <_stogir.vector-comparison.validate+0x388>
    7fa8:      	ldr	x1, [x0, #0x78]
    7fac:      	add	x1, x3, x1
    7fb0:      	ldr	w1, [x1]
    7fb4:      	sxtw	x1, w1
    7fb8:      	cmp	x1, #0x2
    7fbc:      	b.ne	0x806c <_stogir.vector-comparison.validate+0x390>
    7fc0:      	lsr	w2, w2, #0
    7fc4:      	add	x16, sp, #0x10
    7fc8:      	ldr	w1, [x16]
    7fcc:      	uxtb	w3, w1
    7fd0:      	add	x16, sp, #0x10
    7fd4:      	ldr	w4, [x16, #0x4]
    7fd8:      	lsr	w3, w3, #0
    7fdc:      	ubfx	x1, x1, #8, #8
    7fe0:      	add	x16, sp, #0x10
    7fe4:      	ldr	w5, [x16, #0x8]
    7fe8:      	lsr	w4, w4, #0
    7fec:      	lsr	w5, w5, #0
    7ff0:      	lsr	w1, w1, #0
    7ff4:      	mov	x19, x8
    7ff8:      	add	x8, sp, #0x20
    7ffc:      	fmov	s31, w1
    8000:      	mov	w1, w3
    8004:      	mov	w3, w2
    8008:      	fmov	w2, s31
    800c:      	bl	0x800c <_stogir.vector-comparison.validate+0x330>
		000000000000800c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    8010:      	add	x16, sp, #0x20
    8014:      	ldr	x0, [x16]
    8018:      	add	x16, sp, #0x20
    801c:      	ldr	x1, [x16, #0x8]
    8020:      	add	x16, sp, #0x20
    8024:      	ldr	x2, [x16, #0x10]
    8028:      	b	0x7ec0 <_stogir.vector-comparison.validate+0x1e4>
    802c:      	brk	#0
    8030:      	b	0x802c <_stogir.vector-comparison.validate+0x350>
    8034:      	brk	#0
    8038:      	b	0x8034 <_stogir.vector-comparison.validate+0x358>
    803c:      	mov	x19, x8
    8040:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    8044:      	mov	x19, x8
    8048:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    804c:      	mov	x19, x8
    8050:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    8054:      	mov	x19, x8
    8058:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    805c:      	mov	x19, x8
    8060:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    8064:      	mov	x19, x8
    8068:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>
    806c:      	mov	x19, x8
    8070:      	b	0x7ea8 <_stogir.vector-comparison.validate+0x1cc>

0000000000008074 <_stogir.vector-arithmetic.node?>:
    8074:      	sxtw	x1, w1
    8078:      	cmp	x1, #0x0
    807c:      	cset	w2, gt
    8080:      	movz	x16, #0x0, lsl #48
    8084:      	sub	x3, x16, x1
    8088:      	sub	x4, x3, #0x1
    808c:      	uxtb	w16, w2
    8090:      	cmp	w16, wzr
    8094:      	b.eq	0x80d4 <_stogir.vector-arithmetic.node?+0x60>
    8098:      	ldr	x3, [x0, #0x8]
    809c:      	cmp	x1, x3
    80a0:      	b.ge	0x8124 <_stogir.vector-arithmetic.node?+0xb0>
    80a4:      	add	x3, x0, #0x78
    80a8:      	ldr	x3, [x3, #0x8]
    80ac:      	cmp	x1, x3
    80b0:      	b.ge	0x824c <_stogir.vector-arithmetic.node?+0x1d8>
    80b4:      	ldr	x3, [x0, #0x78]
    80b8:      	add	x3, x3, x1, lsl #2
    80bc:      	ldr	w3, [x3]
    80c0:      	sxtw	x3, w3
    80c4:      	cmp	x3, #0x0
    80c8:      	cset	w3, ge
    80cc:      	ubfx	x3, x3, #0, #8
    80d0:      	b	0x8250 <_stogir.vector-arithmetic.node?+0x1dc>
    80d4:      	cmp	x1, #0x0
    80d8:      	b.ge	0x812c <_stogir.vector-arithmetic.node?+0xb8>
    80dc:      	add	x5, x0, #0x28
    80e0:      	add	x6, x0, #0x50
    80e4:      	ldr	x5, [x5, #0x8]
    80e8:      	ldr	x6, [x6, #0x8]
    80ec:      	cmp	x5, x6
    80f0:      	b.ne	0x811c <_stogir.vector-arithmetic.node?+0xa8>
    80f4:      	cmp	x3, x5
    80f8:      	b.gt	0x825c <_stogir.vector-arithmetic.node?+0x1e8>
    80fc:      	ldr	x3, [x0, #0x50]
    8100:      	add	x3, x3, x4, lsl #2
    8104:      	ldr	w3, [x3]
    8108:      	sxtw	x3, w3
    810c:      	cmp	x3, #0x0
    8110:      	cset	w3, gt
    8114:      	ubfx	x3, x3, #0, #8
    8118:      	b	0x8260 <_stogir.vector-arithmetic.node?+0x1ec>
    811c:      	movz	x3, #0x0, lsl #48
    8120:      	b	0x8130 <_stogir.vector-arithmetic.node?+0xbc>
    8124:      	movz	x3, #0x0, lsl #48
    8128:      	b	0x8130 <_stogir.vector-arithmetic.node?+0xbc>
    812c:      	movz	x3, #0x0, lsl #48
    8130:      	cmp	x3, #0x0
    8134:      	b.eq	0x816c <_stogir.vector-arithmetic.node?+0xf8>
    8138:      	uxtb	w16, w2
    813c:      	cmp	w16, wzr
    8140:      	b.eq	0x8154 <_stogir.vector-arithmetic.node?+0xe0>
    8144:      	ldr	x0, [x0]
    8148:      	add	x0, x0, x1, lsl #4
    814c:      	ldr	x0, [x0]
    8150:      	b	0x8160 <_stogir.vector-arithmetic.node?+0xec>
    8154:      	ldr	x0, [x0, #0x28]
    8158:      	add	x0, x0, x4, lsl #4
    815c:      	ldr	x0, [x0]
    8160:      	mov	x1, x0
    8164:      	mov	x0, #0x1                ; =1
    8168:      	b	0x8174 <_stogir.vector-arithmetic.node?+0x100>
    816c:      	movz	x0, #0x0, lsl #48
    8170:      	movz	x1, #0x0, lsl #48
    8174:      	lsr	w0, w0, #0
    8178:      	lsr	x16, x0, #0
    817c:      	cmp	x16, #0x1
    8180:      	b.eq	0x819c <_stogir.vector-arithmetic.node?+0x128>
    8184:      	b.lo	0x818c <_stogir.vector-arithmetic.node?+0x118>
    8188:      	b	0x81a0 <_stogir.vector-arithmetic.node?+0x12c>
    818c:      	cmp	x16, #0x0
    8190:      	b.eq	0x8198 <_stogir.vector-arithmetic.node?+0x124>
    8194:      	b	0x81a0 <_stogir.vector-arithmetic.node?+0x12c>
    8198:      	b	0x81a4 <_stogir.vector-arithmetic.node?+0x130>
    819c:      	b	0x81b4 <_stogir.vector-arithmetic.node?+0x140>
    81a0:      	b	0x826c <_stogir.vector-arithmetic.node?+0x1f8>
    81a4:      	movz	x0, #0x0, lsl #48
    81a8:      	b	0x81b0 <_stogir.vector-arithmetic.node?+0x13c>
    81ac:      	movz	x0, #0x0, lsl #48
    81b0:      	ret
    81b4:      	uxtb	w0, w1
    81b8:      	cmp	x0, #0x1f
    81bc:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81c0:      	cmp	x0, #0x20
    81c4:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81c8:      	cmp	x0, #0x2d
    81cc:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81d0:      	cmp	x0, #0x36
    81d4:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81d8:      	cmp	x0, #0x37
    81dc:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81e0:      	cmp	x0, #0x38
    81e4:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81e8:      	cmp	x0, #0x39
    81ec:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81f0:      	cmp	x0, #0x3a
    81f4:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    81f8:      	cmp	x0, #0x3b
    81fc:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    8200:      	cmp	x0, #0x31
    8204:      	b.lt	0x8274 <_stogir.vector-arithmetic.node?+0x200>
    8208:      	cmp	x0, #0x35
    820c:      	b.gt	0x8274 <_stogir.vector-arithmetic.node?+0x200>
    8210:      	lsr	w1, w1, #0
    8214:      	ubfx	x0, x1, #8, #8
    8218:      	cmp	x0, #0xf
    821c:      	b.le	0x81ac <_stogir.vector-arithmetic.node?+0x138>
    8220:      	cmp	x0, #0x80
    8224:      	b.ge	0x8254 <_stogir.vector-arithmetic.node?+0x1e0>
    8228:      	and	x0, x0, #0xf
    822c:      	lsr	w0, w0, #0
    8230:      	sxtw	x0, w0
    8234:      	cmp	x0, #0x1
    8238:      	b.lt	0x8264 <_stogir.vector-arithmetic.node?+0x1f0>
    823c:      	cmp	x0, #0xd
    8240:      	cset	w0, le
    8244:      	ubfx	x0, x0, #0, #8
    8248:      	b	0x8268 <_stogir.vector-arithmetic.node?+0x1f4>
    824c:      	movz	x3, #0x0, lsl #48
    8250:      	b	0x8128 <_stogir.vector-arithmetic.node?+0xb4>
    8254:      	movz	x0, #0x0, lsl #48
    8258:      	b	0x81b0 <_stogir.vector-arithmetic.node?+0x13c>
    825c:      	movz	x3, #0x0, lsl #48
    8260:      	b	0x8120 <_stogir.vector-arithmetic.node?+0xac>
    8264:      	movz	x0, #0x0, lsl #48
    8268:      	b	0x8258 <_stogir.vector-arithmetic.node?+0x1e4>
    826c:      	brk	#0
    8270:      	b	0x826c <_stogir.vector-arithmetic.node?+0x1f8>
    8274:      	cmp	x0, #0x1a
    8278:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    827c:      	cmp	x0, #0x1b
    8280:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    8284:      	cmp	x0, #0x1c
    8288:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    828c:      	cmp	x0, #0x1d
    8290:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    8294:      	cmp	x0, #0x1e
    8298:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    829c:      	cmp	x0, #0x2e
    82a0:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    82a4:      	cmp	x0, #0x2f
    82a8:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    82ac:      	cmp	x0, #0x30
    82b0:      	b.eq	0x8210 <_stogir.vector-arithmetic.node?+0x19c>
    82b4:      	movz	x0, #0x0, lsl #48
    82b8:      	b	0x81b0 <_stogir.vector-arithmetic.node?+0x13c>

00000000000082bc <_stogir.vector-arithmetic.validate>:
    82bc:      	sub	sp, sp, #0x60
    82c0:      	str	x29, [sp]
    82c4:      	str	x30, [sp, #0x8]
    82c8:      	mov	x29, sp
    82cc:      	str	x19, [sp, #0x40]
    82d0:      	str	x20, [sp, #0x48]
    82d4:      	str	x21, [sp, #0x50]
    82d8:      	str	x22, [sp, #0x58]
    82dc:      	sxtw	x2, w1
    82e0:      	lsl	x19, x2, #2
    82e4:      	cmp	x2, #0x0
    82e8:      	cset	w3, gt
    82ec:      	movz	x16, #0x0, lsl #48
    82f0:      	sub	x4, x16, x2
    82f4:      	sub	x5, x4, #0x1
    82f8:      	uxtb	w16, w3
    82fc:      	cmp	w16, wzr
    8300:      	b.eq	0x8340 <_stogir.vector-arithmetic.validate+0x84>
    8304:      	ldr	x4, [x0, #0x8]
    8308:      	cmp	x2, x4
    830c:      	b.ge	0x8390 <_stogir.vector-arithmetic.validate+0xd4>
    8310:      	add	x4, x0, #0x78
    8314:      	ldr	x4, [x4, #0x8]
    8318:      	cmp	x2, x4
    831c:      	b.ge	0x84b4 <_stogir.vector-arithmetic.validate+0x1f8>
    8320:      	ldr	x4, [x0, #0x78]
    8324:      	add	x4, x19, x4
    8328:      	ldr	w4, [x4]
    832c:      	sxtw	x4, w4
    8330:      	cmp	x4, #0x0
    8334:      	cset	w4, ge
    8338:      	ubfx	x4, x4, #0, #8
    833c:      	b	0x84b8 <_stogir.vector-arithmetic.validate+0x1fc>
    8340:      	cmp	x2, #0x0
    8344:      	b.ge	0x8398 <_stogir.vector-arithmetic.validate+0xdc>
    8348:      	add	x6, x0, #0x28
    834c:      	add	x7, x0, #0x50
    8350:      	ldr	x6, [x6, #0x8]
    8354:      	ldr	x7, [x7, #0x8]
    8358:      	cmp	x6, x7
    835c:      	b.ne	0x8388 <_stogir.vector-arithmetic.validate+0xcc>
    8360:      	cmp	x4, x6
    8364:      	b.gt	0x8550 <_stogir.vector-arithmetic.validate+0x294>
    8368:      	ldr	x4, [x0, #0x50]
    836c:      	add	x4, x4, x5, lsl #2
    8370:      	ldr	w4, [x4]
    8374:      	sxtw	x4, w4
    8378:      	cmp	x4, #0x0
    837c:      	cset	w4, gt
    8380:      	ubfx	x4, x4, #0, #8
    8384:      	b	0x8554 <_stogir.vector-arithmetic.validate+0x298>
    8388:      	movz	x4, #0x0, lsl #48
    838c:      	b	0x839c <_stogir.vector-arithmetic.validate+0xe0>
    8390:      	movz	x4, #0x0, lsl #48
    8394:      	b	0x839c <_stogir.vector-arithmetic.validate+0xe0>
    8398:      	movz	x4, #0x0, lsl #48
    839c:      	cmp	x4, #0x0
    83a0:      	b.eq	0x83f8 <_stogir.vector-arithmetic.validate+0x13c>
    83a4:      	uxtb	w16, w3
    83a8:      	cmp	w16, wzr
    83ac:      	b.eq	0x83d0 <_stogir.vector-arithmetic.validate+0x114>
    83b0:      	ldr	x3, [x0]
    83b4:      	add	x3, x3, x2, lsl #4
    83b8:      	ldr	x4, [x3]
    83bc:      	ldr	x3, [x3, #0x8]
    83c0:      	fmov	d31, x3
    83c4:      	mov	x3, x4
    83c8:      	fmov	x4, d31
    83cc:      	b	0x83ec <_stogir.vector-arithmetic.validate+0x130>
    83d0:      	ldr	x3, [x0, #0x28]
    83d4:      	add	x3, x3, x5, lsl #4
    83d8:      	ldr	x4, [x3]
    83dc:      	ldr	x3, [x3, #0x8]
    83e0:      	fmov	d31, x3
    83e4:      	mov	x3, x4
    83e8:      	fmov	x4, d31
    83ec:      	mov	x20, x3
    83f0:      	mov	x3, #0x1                ; =1
    83f4:      	b	0x8404 <_stogir.vector-arithmetic.validate+0x148>
    83f8:      	movz	x3, #0x0, lsl #48
    83fc:      	movz	x20, #0x0, lsl #48
    8400:      	movz	x4, #0x0, lsl #48
    8404:      	lsr	w3, w3, #0
    8408:      	lsr	x16, x3, #0
    840c:      	cmp	x16, #0x1
    8410:      	b.eq	0x842c <_stogir.vector-arithmetic.validate+0x170>
    8414:      	b.lo	0x841c <_stogir.vector-arithmetic.validate+0x160>
    8418:      	b	0x8430 <_stogir.vector-arithmetic.validate+0x174>
    841c:      	cmp	x16, #0x0
    8420:      	b.eq	0x8428 <_stogir.vector-arithmetic.validate+0x16c>
    8424:      	b	0x8430 <_stogir.vector-arithmetic.validate+0x174>
    8428:      	b	0x8434 <_stogir.vector-arithmetic.validate+0x178>
    842c:      	b	0x8454 <_stogir.vector-arithmetic.validate+0x198>
    8430:      	b	0x8604 <_stogir.vector-arithmetic.validate+0x348>
    8434:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008434:  ARM64_RELOC_PAGE21	l_stogir.418
    8438:      	ldr	x16, [x16]
		0000000000008438:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    843c:      	orr	x0, x16, xzr
    8440:      	mov	x21, x8
    8444:      	mov	x1, x0
    8448:      	mov	x0, #0x1                ; =1
    844c:      	mov	x2, #0x25               ; =37
    8450:      	b	0x8488 <_stogir.vector-arithmetic.validate+0x1cc>
    8454:      	add	x16, sp, #0x10
    8458:      	str	x20, [x16]
    845c:      	add	x16, sp, #0x10
    8460:      	str	x4, [x16, #0x8]
    8464:      	cmp	x2, #0x0
    8468:      	b.gt	0x84bc <_stogir.vector-arithmetic.validate+0x200>
    846c:      	mov	x21, x8
    8470:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008470:  ARM64_RELOC_PAGE21	l_stogir.419
    8474:      	ldr	x16, [x16]
		0000000000008474:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8478:      	orr	x0, x16, xzr
    847c:      	mov	x1, x0
    8480:      	mov	x0, #0x1                ; =1
    8484:      	mov	x2, #0x2b               ; =43
    8488:      	str	x0, [x21]
    848c:      	str	x1, [x21, #0x8]
    8490:      	str	x2, [x21, #0x10]
    8494:      	ldr	x19, [sp, #0x40]
    8498:      	ldr	x20, [sp, #0x48]
    849c:      	ldr	x21, [sp, #0x50]
    84a0:      	ldr	x22, [sp, #0x58]
    84a4:      	ldr	x29, [sp]
    84a8:      	ldr	x30, [sp, #0x8]
    84ac:      	add	sp, sp, #0x60
    84b0:      	ret
    84b4:      	movz	x4, #0x0, lsl #48
    84b8:      	b	0x8394 <_stogir.vector-arithmetic.validate+0xd8>
    84bc:      	lsr	w1, w1, #0
    84c0:      	mov	x21, x8
    84c4:      	mov	x22, x0
    84c8:      	bl	0x84c8 <_stogir.vector-arithmetic.validate+0x20c>
		00000000000084c8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    84cc:      	cmp	x0, #0x0
    84d0:      	b.eq	0x8470 <_stogir.vector-arithmetic.validate+0x1b4>
    84d4:      	uxtb	w20, w20
    84d8:      	orr	x0, x20, xzr
    84dc:      	ldr	x1, [x22, #0x78]
    84e0:      	cmp	x0, #0x1d
    84e4:      	cset	w2, eq
    84e8:      	cmp	x0, #0x1e
    84ec:      	cset	w3, eq
    84f0:      	add	x1, x19, x1
    84f4:      	ldr	w1, [x1]
    84f8:      	cmp	x0, #0x1f
    84fc:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8500:      	cmp	x0, #0x20
    8504:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8508:      	cmp	x0, #0x2d
    850c:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8510:      	cmp	x0, #0x36
    8514:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8518:      	cmp	x0, #0x37
    851c:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8520:      	cmp	x0, #0x38
    8524:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8528:      	cmp	x0, #0x39
    852c:      	b.eq	0x85b4 <_stogir.vector-arithmetic.validate+0x2f8>
    8530:      	uxtb	w16, w2
    8534:      	cmp	w16, wzr
    8538:      	b.ne	0x860c <_stogir.vector-arithmetic.validate+0x350>
    853c:      	uxtb	w16, w3
    8540:      	cmp	w16, wzr
    8544:      	b.ne	0x860c <_stogir.vector-arithmetic.validate+0x350>
    8548:      	mov	x0, #0x2                ; =2
    854c:      	b	0x8610 <_stogir.vector-arithmetic.validate+0x354>
    8550:      	movz	x4, #0x0, lsl #48
    8554:      	b	0x838c <_stogir.vector-arithmetic.validate+0xd0>
    8558:      	add	x16, sp, #0x10
    855c:      	ldr	w2, [x16, #0xc]
    8560:      	sxtw	x2, w2
    8564:      	lsr	w1, w1, #0
    8568:      	lsr	w4, w4, #0
    856c:      	lsr	w20, w20, #0
    8570:      	lsr	w2, w2, #0
    8574:      	ubfx	x0, x0, #8, #8
    8578:      	lsr	w0, w0, #0
    857c:      	add	x8, sp, #0x20
    8580:      	mov	w3, w1
    8584:      	mov	w1, w20
    8588:      	mov	w5, w2
    858c:      	mov	w2, w0
    8590:      	mov	x0, x22
    8594:      	bl	0x8594 <_stogir.vector-arithmetic.validate+0x2d8>
		0000000000008594:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8598:      	add	x16, sp, #0x20
    859c:      	ldr	x0, [x16]
    85a0:      	add	x16, sp, #0x20
    85a4:      	ldr	x1, [x16, #0x8]
    85a8:      	add	x16, sp, #0x20
    85ac:      	ldr	x2, [x16, #0x10]
    85b0:      	b	0x8488 <_stogir.vector-arithmetic.validate+0x1cc>
    85b4:      	mov	x0, #0x1                ; =1
    85b8:      	sxtw	x1, w1
    85bc:      	lsr	w0, w0, #0
    85c0:      	sxtw	x0, w0
    85c4:      	cmp	x1, x0
    85c8:      	b.ne	0x8470 <_stogir.vector-arithmetic.validate+0x1b4>
    85cc:      	add	x16, sp, #0x10
    85d0:      	ldr	w0, [x16]
    85d4:      	add	x16, sp, #0x10
    85d8:      	ldr	w1, [x16, #0x4]
    85dc:      	add	x16, sp, #0x10
    85e0:      	ldr	w4, [x16, #0x8]
    85e4:      	uxtb	w16, w2
    85e8:      	cmp	w16, wzr
    85ec:      	b.ne	0x8558 <_stogir.vector-arithmetic.validate+0x29c>
    85f0:      	uxtb	w16, w3
    85f4:      	cmp	w16, wzr
    85f8:      	b.ne	0x8558 <_stogir.vector-arithmetic.validate+0x29c>
    85fc:      	movz	x2, #0x0, lsl #48
    8600:      	b	0x8564 <_stogir.vector-arithmetic.validate+0x2a8>
    8604:      	brk	#0
    8608:      	b	0x8604 <_stogir.vector-arithmetic.validate+0x348>
    860c:      	mov	x0, #0x3                ; =3
    8610:      	b	0x85b8 <_stogir.vector-arithmetic.validate+0x2fc>

0000000000008614 <_stogir.vector.memory-inputs>:
    8614:      	sub	sp, sp, #0x40
    8618:      	str	x29, [sp]
    861c:      	str	x30, [sp, #0x8]
    8620:      	mov	x29, sp
    8624:      	str	x19, [sp, #0x10]
    8628:      	str	x20, [sp, #0x18]
    862c:      	str	x21, [sp, #0x20]
    8630:      	str	x22, [sp, #0x28]
    8634:      	str	x23, [sp, #0x30]
    8638:      	str	x24, [sp, #0x38]
    863c:      	sxtw	x5, w1
    8640:      	cmp	x5, #0xf
    8644:      	b.le	0x8af4 <_stogir.vector.memory-inputs+0x4e0>
    8648:      	cmp	x5, #0x80
    864c:      	b.ge	0x8afc <_stogir.vector.memory-inputs+0x4e8>
    8650:      	and	x6, x5, #0xf
    8654:      	lsr	w6, w6, #0
    8658:      	sxtw	x6, w6
    865c:      	cmp	x6, #0x1
    8660:      	b.lt	0x8b04 <_stogir.vector.memory-inputs+0x4f0>
    8664:      	and	x5, x5, #0xf
    8668:      	lsr	w5, w5, #0
    866c:      	sxtw	x5, w5
    8670:      	cmp	x5, #0xd
    8674:      	b.gt	0x8b0c <_stogir.vector.memory-inputs+0x4f8>
    8678:      	lsr	w1, w1, #0
    867c:      	lsr	w2, w2, #0
    8680:      	mov	x19, x8
    8684:      	mov	x20, x0
    8688:      	mov	w0, w1
    868c:      	mov	w21, w1
    8690:      	mov	w1, w2
    8694:      	mov	w22, w2
    8698:      	mov	w23, w3
    869c:      	mov	w24, w4
    86a0:      	bl	0x86a0 <_stogir.vector.memory-inputs+0x8c>
		00000000000086a0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    86a4:      	lsr	w0, w0, #0
    86a8:      	sxtw	x0, w0
    86ac:      	cmp	x0, #0x0
    86b0:      	b.le	0x8714 <_stogir.vector.memory-inputs+0x100>
    86b4:      	sxtw	x23, w23
    86b8:      	cmp	x23, #0x0
    86bc:      	cset	w0, gt
    86c0:      	movz	x16, #0x0, lsl #48
    86c4:      	sub	x1, x16, x23
    86c8:      	sub	x2, x1, #0x1
    86cc:      	uxtb	w16, w0
    86d0:      	cmp	w16, wzr
    86d4:      	b.eq	0x87fc <_stogir.vector.memory-inputs+0x1e8>
    86d8:      	ldr	x1, [x20, #0x8]
    86dc:      	cmp	x23, x1
    86e0:      	b.ge	0x87f4 <_stogir.vector.memory-inputs+0x1e0>
    86e4:      	add	x1, x20, #0x78
    86e8:      	ldr	x1, [x1, #0x8]
    86ec:      	cmp	x23, x1
    86f0:      	b.ge	0x88a0 <_stogir.vector.memory-inputs+0x28c>
    86f4:      	ldr	x1, [x20, #0x78]
    86f8:      	add	x1, x1, x23, lsl #2
    86fc:      	ldr	w1, [x1]
    8700:      	sxtw	x1, w1
    8704:      	cmp	x1, #0x0
    8708:      	cset	w1, ge
    870c:      	ubfx	x1, x1, #0, #8
    8710:      	b	0x88a4 <_stogir.vector.memory-inputs+0x290>
    8714:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008714:  ARM64_RELOC_PAGE21	l_stogir.420
    8718:      	ldr	x16, [x16]
		0000000000008718:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    871c:      	orr	x0, x16, xzr
    8720:      	mov	x1, x0
    8724:      	mov	x0, #0x1                ; =1
    8728:      	mov	x2, #0x32               ; =50
    872c:      	str	x0, [x19]
    8730:      	str	x1, [x19, #0x8]
    8734:      	str	x2, [x19, #0x10]
    8738:      	ldr	x19, [sp, #0x10]
    873c:      	ldr	x20, [sp, #0x18]
    8740:      	ldr	x21, [sp, #0x20]
    8744:      	ldr	x22, [sp, #0x28]
    8748:      	ldr	x23, [sp, #0x30]
    874c:      	ldr	x24, [sp, #0x38]
    8750:      	ldr	x29, [sp]
    8754:      	ldr	x30, [sp, #0x8]
    8758:      	add	sp, sp, #0x40
    875c:      	ret
    8760:      	movz	x0, #0x0, lsl #48
    8764:      	movz	x1, #0x0, lsl #48
    8768:      	lsr	w0, w0, #0
    876c:      	lsr	x16, x0, #0
    8770:      	cmp	x16, #0x1
    8774:      	b.eq	0x8790 <_stogir.vector.memory-inputs+0x17c>
    8778:      	b.lo	0x8780 <_stogir.vector.memory-inputs+0x16c>
    877c:      	b	0x8794 <_stogir.vector.memory-inputs+0x180>
    8780:      	cmp	x16, #0x0
    8784:      	b.eq	0x878c <_stogir.vector.memory-inputs+0x178>
    8788:      	b	0x8794 <_stogir.vector.memory-inputs+0x180>
    878c:      	b	0x8798 <_stogir.vector.memory-inputs+0x184>
    8790:      	b	0x8844 <_stogir.vector.memory-inputs+0x230>
    8794:      	b	0x8adc <_stogir.vector.memory-inputs+0x4c8>
    8798:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008798:  ARM64_RELOC_PAGE21	l_stogir.421
    879c:      	ldr	x16, [x16]
		000000000000879c:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    87a0:      	orr	x0, x16, xzr
    87a4:      	mov	x1, x0
    87a8:      	mov	x0, #0x1                ; =1
    87ac:      	mov	x2, #0x1d               ; =29
    87b0:      	b	0x872c <_stogir.vector.memory-inputs+0x118>
    87b4:      	ldr	x0, [x20, #0x28]
    87b8:      	add	x0, x0, x2, lsl #4
    87bc:      	ldr	x0, [x0]
    87c0:      	mov	x1, x0
    87c4:      	mov	x0, #0x1                ; =1
    87c8:      	b	0x8768 <_stogir.vector.memory-inputs+0x154>
    87cc:      	movz	x1, #0x0, lsl #48
    87d0:      	cmp	x1, #0x0
    87d4:      	b.eq	0x8760 <_stogir.vector.memory-inputs+0x14c>
    87d8:      	uxtb	w16, w0
    87dc:      	cmp	w16, wzr
    87e0:      	b.eq	0x87b4 <_stogir.vector.memory-inputs+0x1a0>
    87e4:      	ldr	x0, [x20]
    87e8:      	add	x0, x0, x23, lsl #4
    87ec:      	ldr	x0, [x0]
    87f0:      	b	0x87c0 <_stogir.vector.memory-inputs+0x1ac>
    87f4:      	movz	x1, #0x0, lsl #48
    87f8:      	b	0x87d0 <_stogir.vector.memory-inputs+0x1bc>
    87fc:      	cmp	x23, #0x0
    8800:      	b.ge	0x87cc <_stogir.vector.memory-inputs+0x1b8>
    8804:      	add	x3, x20, #0x28
    8808:      	add	x4, x20, #0x50
    880c:      	ldr	x3, [x3, #0x8]
    8810:      	ldr	x4, [x4, #0x8]
    8814:      	cmp	x3, x4
    8818:      	b.ne	0x8898 <_stogir.vector.memory-inputs+0x284>
    881c:      	cmp	x1, x3
    8820:      	b.gt	0x88a8 <_stogir.vector.memory-inputs+0x294>
    8824:      	ldr	x1, [x20, #0x50]
    8828:      	add	x1, x1, x2, lsl #2
    882c:      	ldr	w1, [x1]
    8830:      	sxtw	x1, w1
    8834:      	cmp	x1, #0x0
    8838:      	cset	w1, gt
    883c:      	ubfx	x1, x1, #0, #8
    8840:      	b	0x88ac <_stogir.vector.memory-inputs+0x298>
    8844:      	cmp	x23, #0x0
    8848:      	b.le	0x887c <_stogir.vector.memory-inputs+0x268>
    884c:      	uxtb	w1, w1
    8850:      	cmp	x1, #0x83
    8854:      	cset	w0, lt
    8858:      	uxtb	w16, w0
    885c:      	cmp	w16, wzr
    8860:      	b.eq	0x88b0 <_stogir.vector.memory-inputs+0x29c>
    8864:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008864:  ARM64_RELOC_PAGE21	l_stogir.422
    8868:      	ldr	x16, [x16]
		0000000000008868:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    886c:      	orr	x2, x16, xzr
    8870:      	add	x2, x1, x2
    8874:      	ldrb	w2, [x2]
    8878:      	b	0x88b4 <_stogir.vector.memory-inputs+0x2a0>
    887c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		000000000000887c:  ARM64_RELOC_PAGE21	l_stogir.423
    8880:      	ldr	x16, [x16]
		0000000000008880:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    8884:      	orr	x0, x16, xzr
    8888:      	mov	x1, x0
    888c:      	mov	x0, #0x1                ; =1
    8890:      	mov	x2, #0x2c               ; =44
    8894:      	b	0x87b0 <_stogir.vector.memory-inputs+0x19c>
    8898:      	movz	x1, #0x0, lsl #48
    889c:      	b	0x87d0 <_stogir.vector.memory-inputs+0x1bc>
    88a0:      	movz	x1, #0x0, lsl #48
    88a4:      	b	0x87f8 <_stogir.vector.memory-inputs+0x1e4>
    88a8:      	movz	x1, #0x0, lsl #48
    88ac:      	b	0x889c <_stogir.vector.memory-inputs+0x288>
    88b0:      	movz	x2, #0x0, lsl #48
    88b4:      	uxtb	w2, w2
    88b8:      	and	x2, x2, #0x1
    88bc:      	uxtb	w2, w2
    88c0:      	cmp	x2, #0x0
    88c4:      	b.eq	0x887c <_stogir.vector.memory-inputs+0x268>
    88c8:      	uxtb	w16, w0
    88cc:      	cmp	w16, wzr
    88d0:      	b.eq	0x88ec <_stogir.vector.memory-inputs+0x2d8>
    88d4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		00000000000088d4:  ARM64_RELOC_PAGE21	l_stogir.422
    88d8:      	ldr	x16, [x16]
		00000000000088d8:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    88dc:      	orr	x0, x16, xzr
    88e0:      	add	x0, x1, x0
    88e4:      	ldrb	w0, [x0]
    88e8:      	b	0x88f0 <_stogir.vector.memory-inputs+0x2dc>
    88ec:      	movz	x0, #0x0, lsl #48
    88f0:      	uxtb	w0, w0
    88f4:      	and	x0, x0, #0x4
    88f8:      	uxtb	w0, w0
    88fc:      	cmp	x0, #0x0
    8900:      	cset	w0, eq
    8904:      	uxtb	w16, w0
    8908:      	cmp	w16, wzr
    890c:      	cset	x0, eq
    8910:      	cmp	x0, #0x0
    8914:      	b.ne	0x887c <_stogir.vector.memory-inputs+0x268>
    8918:      	sxtw	x24, w24
    891c:      	cmp	x24, #0x0
    8920:      	cset	w0, gt
    8924:      	movz	x16, #0x0, lsl #48
    8928:      	sub	x1, x16, x24
    892c:      	sub	x2, x1, #0x1
    8930:      	uxtb	w16, w0
    8934:      	cmp	w16, wzr
    8938:      	b.eq	0x8994 <_stogir.vector.memory-inputs+0x380>
    893c:      	ldr	x1, [x20, #0x8]
    8940:      	cmp	x24, x1
    8944:      	b.ge	0x89dc <_stogir.vector.memory-inputs+0x3c8>
    8948:      	add	x1, x20, #0x78
    894c:      	ldr	x1, [x1, #0x8]
    8950:      	cmp	x24, x1
    8954:      	b.ge	0x8ad4 <_stogir.vector.memory-inputs+0x4c0>
    8958:      	ldr	x1, [x20, #0x78]
    895c:      	add	x1, x1, x24, lsl #2
    8960:      	ldr	w1, [x1]
    8964:      	sxtw	x1, w1
    8968:      	cmp	x1, #0x0
    896c:      	cset	w1, ge
    8970:      	ubfx	x1, x1, #0, #8
    8974:      	b	0x8ad8 <_stogir.vector.memory-inputs+0x4c4>
    8978:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008978:  ARM64_RELOC_PAGE21	l_stogir.424
    897c:      	ldr	x16, [x16]
		000000000000897c:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    8980:      	orr	x0, x16, xzr
    8984:      	mov	x1, x0
    8988:      	mov	x0, #0x1                ; =1
    898c:      	mov	x2, #0x2b               ; =43
    8990:      	b	0x8894 <_stogir.vector.memory-inputs+0x280>
    8994:      	cmp	x24, #0x0
    8998:      	b.ge	0x89e4 <_stogir.vector.memory-inputs+0x3d0>
    899c:      	add	x3, x20, #0x28
    89a0:      	add	x4, x20, #0x50
    89a4:      	ldr	x3, [x3, #0x8]
    89a8:      	ldr	x4, [x4, #0x8]
    89ac:      	cmp	x3, x4
    89b0:      	b.ne	0x8acc <_stogir.vector.memory-inputs+0x4b8>
    89b4:      	cmp	x1, x3
    89b8:      	b.gt	0x8ae4 <_stogir.vector.memory-inputs+0x4d0>
    89bc:      	ldr	x1, [x20, #0x50]
    89c0:      	add	x1, x1, x2, lsl #2
    89c4:      	ldr	w1, [x1]
    89c8:      	sxtw	x1, w1
    89cc:      	cmp	x1, #0x0
    89d0:      	cset	w1, gt
    89d4:      	ubfx	x1, x1, #0, #8
    89d8:      	b	0x8ae8 <_stogir.vector.memory-inputs+0x4d4>
    89dc:      	movz	x1, #0x0, lsl #48
    89e0:      	b	0x89e8 <_stogir.vector.memory-inputs+0x3d4>
    89e4:      	movz	x1, #0x0, lsl #48
    89e8:      	cmp	x1, #0x0
    89ec:      	b.eq	0x8a24 <_stogir.vector.memory-inputs+0x410>
    89f0:      	uxtb	w16, w0
    89f4:      	cmp	w16, wzr
    89f8:      	b.eq	0x8a0c <_stogir.vector.memory-inputs+0x3f8>
    89fc:      	ldr	x0, [x20]
    8a00:      	add	x0, x0, x24, lsl #4
    8a04:      	ldr	x0, [x0]
    8a08:      	b	0x8a18 <_stogir.vector.memory-inputs+0x404>
    8a0c:      	ldr	x0, [x20, #0x28]
    8a10:      	add	x0, x0, x2, lsl #4
    8a14:      	ldr	x0, [x0]
    8a18:      	mov	x1, x0
    8a1c:      	mov	x0, #0x1                ; =1
    8a20:      	b	0x8a2c <_stogir.vector.memory-inputs+0x418>
    8a24:      	movz	x0, #0x0, lsl #48
    8a28:      	movz	x1, #0x0, lsl #48
    8a2c:      	lsr	w0, w0, #0
    8a30:      	lsr	x16, x0, #0
    8a34:      	cmp	x16, #0x1
    8a38:      	b.eq	0x8a54 <_stogir.vector.memory-inputs+0x440>
    8a3c:      	b.lo	0x8a44 <_stogir.vector.memory-inputs+0x430>
    8a40:      	b	0x8a58 <_stogir.vector.memory-inputs+0x444>
    8a44:      	cmp	x16, #0x0
    8a48:      	b.eq	0x8a50 <_stogir.vector.memory-inputs+0x43c>
    8a4c:      	b	0x8a58 <_stogir.vector.memory-inputs+0x444>
    8a50:      	b	0x8a5c <_stogir.vector.memory-inputs+0x448>
    8a54:      	b	0x8a78 <_stogir.vector.memory-inputs+0x464>
    8a58:      	b	0x8aec <_stogir.vector.memory-inputs+0x4d8>
    8a5c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008a5c:  ARM64_RELOC_PAGE21	l_stogir.425
    8a60:      	ldr	x16, [x16]
		0000000000008a60:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    8a64:      	orr	x0, x16, xzr
    8a68:      	mov	x1, x0
    8a6c:      	mov	x0, #0x1                ; =1
    8a70:      	mov	x2, #0x1d               ; =29
    8a74:      	b	0x8990 <_stogir.vector.memory-inputs+0x37c>
    8a78:      	lsr	w0, w1, #0
    8a7c:      	ubfx	x0, x0, #8, #8
    8a80:      	cmp	x0, #0x6
    8a84:      	b.ne	0x8978 <_stogir.vector.memory-inputs+0x364>
    8a88:      	uxtb	w1, w1
    8a8c:      	cmp	x1, #0x48
    8a90:      	b.eq	0x8978 <_stogir.vector.memory-inputs+0x364>
    8a94:      	cmp	x1, #0x46
    8a98:      	b.eq	0x8978 <_stogir.vector.memory-inputs+0x364>
    8a9c:      	lsr	w21, w21, #0
    8aa0:      	lsr	w22, w22, #0
    8aa4:      	mov	w0, w21
    8aa8:      	mov	w1, w22
    8aac:      	bl	0x8aac <_stogir.vector.memory-inputs+0x498>
		0000000000008aac:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8ab0:      	lsr	w0, w0, #0
    8ab4:      	sxtw	x0, w0
    8ab8:      	and	x0, x0, #0xffffffff
    8abc:      	mov	x1, x0
    8ac0:      	movz	x0, #0x0, lsl #48
    8ac4:      	movz	x2, #0x0, lsl #48
    8ac8:      	b	0x8990 <_stogir.vector.memory-inputs+0x37c>
    8acc:      	movz	x1, #0x0, lsl #48
    8ad0:      	b	0x89e8 <_stogir.vector.memory-inputs+0x3d4>
    8ad4:      	movz	x1, #0x0, lsl #48
    8ad8:      	b	0x89e0 <_stogir.vector.memory-inputs+0x3cc>
    8adc:      	brk	#0
    8ae0:      	b	0x8adc <_stogir.vector.memory-inputs+0x4c8>
    8ae4:      	movz	x1, #0x0, lsl #48
    8ae8:      	b	0x8ad0 <_stogir.vector.memory-inputs+0x4bc>
    8aec:      	brk	#0
    8af0:      	b	0x8aec <_stogir.vector.memory-inputs+0x4d8>
    8af4:      	mov	x19, x8
    8af8:      	b	0x8714 <_stogir.vector.memory-inputs+0x100>
    8afc:      	mov	x19, x8
    8b00:      	b	0x8714 <_stogir.vector.memory-inputs+0x100>
    8b04:      	mov	x19, x8
    8b08:      	b	0x8714 <_stogir.vector.memory-inputs+0x100>
    8b0c:      	mov	x19, x8
    8b10:      	b	0x8714 <_stogir.vector.memory-inputs+0x100>

0000000000008b14 <_stogir.vector.store-inputs>:
    8b14:      	sub	sp, sp, #0x40
    8b18:      	str	x29, [sp]
    8b1c:      	str	x30, [sp, #0x8]
    8b20:      	mov	x29, sp
    8b24:      	str	x19, [sp, #0x30]
    8b28:      	sxtw	x4, w4
    8b2c:      	cmp	x4, #0x0
    8b30:      	cset	w5, gt
    8b34:      	movz	x16, #0x0, lsl #48
    8b38:      	sub	x6, x16, x4
    8b3c:      	sub	x7, x6, #0x1
    8b40:      	uxtb	w16, w5
    8b44:      	cmp	w16, wzr
    8b48:      	b.eq	0x8b88 <_stogir.vector.store-inputs+0x74>
    8b4c:      	ldr	x6, [x0, #0x8]
    8b50:      	cmp	x4, x6
    8b54:      	b.ge	0x8bd8 <_stogir.vector.store-inputs+0xc4>
    8b58:      	add	x6, x0, #0x78
    8b5c:      	ldr	x6, [x6, #0x8]
    8b60:      	cmp	x4, x6
    8b64:      	b.ge	0x8ce8 <_stogir.vector.store-inputs+0x1d4>
    8b68:      	ldr	x6, [x0, #0x78]
    8b6c:      	add	x6, x6, x4, lsl #2
    8b70:      	ldr	w6, [x6]
    8b74:      	sxtw	x6, w6
    8b78:      	cmp	x6, #0x0
    8b7c:      	cset	w6, ge
    8b80:      	ubfx	x6, x6, #0, #8
    8b84:      	b	0x8cec <_stogir.vector.store-inputs+0x1d8>
    8b88:      	cmp	x4, #0x0
    8b8c:      	b.ge	0x8be0 <_stogir.vector.store-inputs+0xcc>
    8b90:      	add	x9, x0, #0x28
    8b94:      	add	x10, x0, #0x50
    8b98:      	ldr	x9, [x9, #0x8]
    8b9c:      	ldr	x10, [x10, #0x8]
    8ba0:      	cmp	x9, x10
    8ba4:      	b.ne	0x8bd0 <_stogir.vector.store-inputs+0xbc>
    8ba8:      	cmp	x6, x9
    8bac:      	b.gt	0x8cf0 <_stogir.vector.store-inputs+0x1dc>
    8bb0:      	ldr	x6, [x0, #0x50]
    8bb4:      	add	x6, x6, x7, lsl #2
    8bb8:      	ldr	w6, [x6]
    8bbc:      	sxtw	x6, w6
    8bc0:      	cmp	x6, #0x0
    8bc4:      	cset	w6, gt
    8bc8:      	ubfx	x6, x6, #0, #8
    8bcc:      	b	0x8cf4 <_stogir.vector.store-inputs+0x1e0>
    8bd0:      	movz	x6, #0x0, lsl #48
    8bd4:      	b	0x8be4 <_stogir.vector.store-inputs+0xd0>
    8bd8:      	movz	x6, #0x0, lsl #48
    8bdc:      	b	0x8be4 <_stogir.vector.store-inputs+0xd0>
    8be0:      	movz	x6, #0x0, lsl #48
    8be4:      	cmp	x6, #0x0
    8be8:      	b.eq	0x8c20 <_stogir.vector.store-inputs+0x10c>
    8bec:      	uxtb	w16, w5
    8bf0:      	cmp	w16, wzr
    8bf4:      	b.eq	0x8c08 <_stogir.vector.store-inputs+0xf4>
    8bf8:      	ldr	x5, [x0]
    8bfc:      	add	x4, x5, x4, lsl #4
    8c00:      	ldr	x4, [x4]
    8c04:      	b	0x8c14 <_stogir.vector.store-inputs+0x100>
    8c08:      	ldr	x4, [x0, #0x28]
    8c0c:      	add	x4, x4, x7, lsl #4
    8c10:      	ldr	x4, [x4]
    8c14:      	mov	x5, x4
    8c18:      	mov	x4, #0x1                ; =1
    8c1c:      	b	0x8c28 <_stogir.vector.store-inputs+0x114>
    8c20:      	movz	x4, #0x0, lsl #48
    8c24:      	movz	x5, #0x0, lsl #48
    8c28:      	lsr	w4, w4, #0
    8c2c:      	lsr	x16, x4, #0
    8c30:      	cmp	x16, #0x1
    8c34:      	b.eq	0x8c50 <_stogir.vector.store-inputs+0x13c>
    8c38:      	b.lo	0x8c40 <_stogir.vector.store-inputs+0x12c>
    8c3c:      	b	0x8c54 <_stogir.vector.store-inputs+0x140>
    8c40:      	cmp	x16, #0x0
    8c44:      	b.eq	0x8c4c <_stogir.vector.store-inputs+0x138>
    8c48:      	b	0x8c54 <_stogir.vector.store-inputs+0x140>
    8c4c:      	b	0x8c58 <_stogir.vector.store-inputs+0x144>
    8c50:      	b	0x8c78 <_stogir.vector.store-inputs+0x164>
    8c54:      	b	0x8cf8 <_stogir.vector.store-inputs+0x1e4>
    8c58:      	adrp	x16, 0x8000 <_stogir.vector-comparison.validate+0x324>
		0000000000008c58:  ARM64_RELOC_PAGE21	l_stogir.426
    8c5c:      	ldr	x16, [x16]
		0000000000008c5c:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    8c60:      	orr	x0, x16, xzr
    8c64:      	mov	x19, x8
    8c68:      	mov	x1, x0
    8c6c:      	mov	x0, #0x1                ; =1
    8c70:      	mov	x2, #0x1a               ; =26
    8c74:      	b	0x8cc8 <_stogir.vector.store-inputs+0x1b4>
    8c78:      	lsr	w1, w1, #0
    8c7c:      	lsr	w2, w2, #0
    8c80:      	lsr	w3, w3, #0
    8c84:      	lsr	w5, w5, #0
    8c88:      	ubfx	x4, x5, #8, #8
    8c8c:      	lsr	w4, w4, #0
    8c90:      	mov	x19, x8
    8c94:      	add	x8, sp, #0x10
    8c98:      	fmov	s31, w1
    8c9c:      	mov	w1, w4
    8ca0:      	mov	w4, w3
    8ca4:      	mov	w3, w2
    8ca8:      	fmov	w2, s31
    8cac:      	bl	0x8cac <_stogir.vector.store-inputs+0x198>
		0000000000008cac:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    8cb0:      	add	x16, sp, #0x10
    8cb4:      	ldr	x0, [x16]
    8cb8:      	add	x16, sp, #0x10
    8cbc:      	ldr	x1, [x16, #0x8]
    8cc0:      	add	x16, sp, #0x10
    8cc4:      	ldr	x2, [x16, #0x10]
    8cc8:      	str	x0, [x19]
    8ccc:      	str	x1, [x19, #0x8]
    8cd0:      	str	x2, [x19, #0x10]
    8cd4:      	ldr	x19, [sp, #0x30]
    8cd8:      	ldr	x29, [sp]
    8cdc:      	ldr	x30, [sp, #0x8]
    8ce0:      	add	sp, sp, #0x40
    8ce4:      	ret
    8ce8:      	movz	x6, #0x0, lsl #48
    8cec:      	b	0x8bdc <_stogir.vector.store-inputs+0xc8>
    8cf0:      	movz	x6, #0x0, lsl #48
    8cf4:      	b	0x8bd4 <_stogir.vector.store-inputs+0xc0>
    8cf8:      	brk	#0
    8cfc:      	b	0x8cf8 <_stogir.vector.store-inputs+0x1e4>

0000000000008d00 <_stogir.types.size>:
    8d00:      	sxtw	x0, w0
    8d04:      	sxtw	x1, w1
    8d08:      	cmp	x0, #0xf
    8d0c:      	cset	w2, gt
    8d10:      	cmp	x0, #0x0
    8d14:      	cset	w3, eq
    8d18:      	cmp	x1, #0x4
    8d1c:      	cset	w4, eq
    8d20:      	cmp	x1, #0x8
    8d24:      	cset	w5, eq
    8d28:      	uxtb	w16, w2
    8d2c:      	cmp	w16, wzr
    8d30:      	b.eq	0x8df8 <_stogir.types.size+0xf8>
    8d34:      	cmp	x0, #0x80
    8d38:      	cset	w6, lt
    8d3c:      	uxtb	w16, w6
    8d40:      	cmp	w16, wzr
    8d44:      	b.eq	0x8df8 <_stogir.types.size+0xf8>
    8d48:      	and	x7, x0, #0xf
    8d4c:      	lsr	w7, w7, #0
    8d50:      	sxtw	x7, w7
    8d54:      	cmp	x7, #0x1
    8d58:      	cset	w8, ge
    8d5c:      	uxtb	w16, w8
    8d60:      	cmp	w16, wzr
    8d64:      	b.eq	0x8df8 <_stogir.types.size+0xf8>
    8d68:      	cmp	x7, #0xd
    8d6c:      	cset	w9, le
    8d70:      	uxtb	w16, w9
    8d74:      	cmp	w16, wzr
    8d78:      	b.eq	0x8df8 <_stogir.types.size+0xf8>
    8d7c:      	cmp	x0, #0x0
    8d80:      	cset	w10, ge
    8d84:      	cmp	x0, #0xd
    8d88:      	cset	w11, le
    8d8c:      	uxtb	w16, w10
    8d90:      	cmp	w16, wzr
    8d94:      	b.eq	0x8da4 <_stogir.types.size+0xa4>
    8d98:      	uxtb	w16, w11
    8d9c:      	cmp	w16, wzr
    8da0:      	b.ne	0x8dd8 <_stogir.types.size+0xd8>
    8da4:      	uxtb	w16, w2
    8da8:      	cmp	w16, wzr
    8dac:      	b.eq	0x8dd4 <_stogir.types.size+0xd4>
    8db0:      	uxtb	w16, w6
    8db4:      	cmp	w16, wzr
    8db8:      	b.eq	0x8dd4 <_stogir.types.size+0xd4>
    8dbc:      	uxtb	w16, w8
    8dc0:      	cmp	w16, wzr
    8dc4:      	b.eq	0x8dd4 <_stogir.types.size+0xd4>
    8dc8:      	uxtb	w16, w9
    8dcc:      	cmp	w16, wzr
    8dd0:      	b.ne	0x8dd8 <_stogir.types.size+0xd8>
    8dd4:      	movn	x7, #0x0, lsl #48
    8dd8:      	uxtb	w16, w4
    8ddc:      	cmp	w16, wzr
    8de0:      	b.ne	0x8f34 <_stogir.types.size+0x234>
    8de4:      	uxtb	w16, w5
    8de8:      	cmp	w16, wzr
    8dec:      	b.ne	0x8f34 <_stogir.types.size+0x234>
    8df0:      	movn	x1, #0x0, lsl #48
    8df4:      	b	0x8ea8 <_stogir.types.size+0x1a8>
    8df8:      	uxtb	w16, w4
    8dfc:      	cmp	w16, wzr
    8e00:      	b.ne	0x8e18 <_stogir.types.size+0x118>
    8e04:      	uxtb	w16, w5
    8e08:      	cmp	w16, wzr
    8e0c:      	b.ne	0x8e18 <_stogir.types.size+0x118>
    8e10:      	movn	x0, #0x0, lsl #48
    8e14:      	b	0x8e30 <_stogir.types.size+0x130>
    8e18:      	uxtb	w16, w3
    8e1c:      	cmp	w16, wzr
    8e20:      	b.eq	0x8e34 <_stogir.types.size+0x134>
    8e24:      	movz	x0, #0x0, lsl #48
    8e28:      	b	0x8e30 <_stogir.types.size+0x130>
    8e2c:      	mov	x0, #0x1                ; =1
    8e30:      	ret
    8e34:      	cmp	x0, #0x1
    8e38:      	b.eq	0x8e2c <_stogir.types.size+0x12c>
    8e3c:      	cmp	x0, #0x2
    8e40:      	b.eq	0x8e2c <_stogir.types.size+0x12c>
    8e44:      	cmp	x0, #0x7
    8e48:      	b.eq	0x8e2c <_stogir.types.size+0x12c>
    8e4c:      	cmp	x0, #0x8
    8e50:      	b.eq	0x8e2c <_stogir.types.size+0x12c>
    8e54:      	cmp	x0, #0x3
    8e58:      	b.eq	0x8fbc <_stogir.types.size+0x2bc>
    8e5c:      	cmp	x0, #0x9
    8e60:      	b.eq	0x8fbc <_stogir.types.size+0x2bc>
    8e64:      	cmp	x0, #0x4
    8e68:      	b.eq	0x8fec <_stogir.types.size+0x2ec>
    8e6c:      	cmp	x0, #0xa
    8e70:      	b.eq	0x8fec <_stogir.types.size+0x2ec>
    8e74:      	cmp	x0, #0xd
    8e78:      	b.eq	0x8fec <_stogir.types.size+0x2ec>
    8e7c:      	cmp	x0, #0x5
    8e80:      	b.eq	0x8ffc <_stogir.types.size+0x2fc>
    8e84:      	cmp	x0, #0xb
    8e88:      	b.eq	0x8ffc <_stogir.types.size+0x2fc>
    8e8c:      	cmp	x0, #0xc
    8e90:      	b.eq	0x8ffc <_stogir.types.size+0x2fc>
    8e94:      	cmp	x0, #0x6
    8e98:      	b.ne	0x900c <_stogir.types.size+0x30c>
    8e9c:      	mov	x0, x1
    8ea0:      	b	0x9010 <_stogir.types.size+0x310>
    8ea4:      	mov	x1, #0x1                ; =1
    8ea8:      	lsr	w1, w1, #0
    8eac:      	sxtw	x1, w1
    8eb0:      	cmp	x1, #0x0
    8eb4:      	b.ge	0x8ec0 <_stogir.types.size+0x1c0>
    8eb8:      	movn	x0, #0x0, lsl #48
    8ebc:      	b	0x8e30 <_stogir.types.size+0x130>
    8ec0:      	uxtb	w16, w2
    8ec4:      	cmp	w16, wzr
    8ec8:      	b.eq	0x8fc4 <_stogir.types.size+0x2c4>
    8ecc:      	uxtb	w16, w6
    8ed0:      	cmp	w16, wzr
    8ed4:      	b.eq	0x8fc4 <_stogir.types.size+0x2c4>
    8ed8:      	uxtb	w16, w8
    8edc:      	cmp	w16, wzr
    8ee0:      	b.eq	0x8fc4 <_stogir.types.size+0x2c4>
    8ee4:      	uxtb	w16, w9
    8ee8:      	cmp	w16, wzr
    8eec:      	b.eq	0x8fc4 <_stogir.types.size+0x2c4>
    8ef0:      	ubfx	x0, x0, #4, #32
    8ef4:      	sxtw	x0, w0
    8ef8:      	sub	x0, x0, #0x1
    8efc:      	lsr	w0, w0, #0
    8f00:      	sxtw	x0, w0
    8f04:      	mov	x16, #0x1               ; =1
    8f08:      	lsl	x0, x16, x0
    8f0c:      	lsr	w0, w0, #0
    8f10:      	sxtw	x0, w0
    8f14:      	b	0x8f1c <_stogir.types.size+0x21c>
    8f18:      	movn	x0, #0x0, lsl #48
    8f1c:      	lsr	w0, w0, #0
    8f20:      	sxtw	x0, w0
    8f24:      	mul	x0, x0, x1
    8f28:      	lsr	w0, w0, #0
    8f2c:      	sxtw	x0, w0
    8f30:      	b	0x8ebc <_stogir.types.size+0x1bc>
    8f34:      	lsr	w7, w7, #0
    8f38:      	sxtw	x7, w7
    8f3c:      	cmp	x7, #0x0
    8f40:      	b.ne	0x8f4c <_stogir.types.size+0x24c>
    8f44:      	movz	x1, #0x0, lsl #48
    8f48:      	b	0x8ea8 <_stogir.types.size+0x1a8>
    8f4c:      	cmp	x7, #0x1
    8f50:      	b.eq	0x8ea4 <_stogir.types.size+0x1a4>
    8f54:      	cmp	x7, #0x2
    8f58:      	b.eq	0x8ea4 <_stogir.types.size+0x1a4>
    8f5c:      	cmp	x7, #0x7
    8f60:      	b.eq	0x8ea4 <_stogir.types.size+0x1a4>
    8f64:      	cmp	x7, #0x8
    8f68:      	b.eq	0x8ea4 <_stogir.types.size+0x1a4>
    8f6c:      	cmp	x7, #0x3
    8f70:      	b.eq	0x8ff4 <_stogir.types.size+0x2f4>
    8f74:      	cmp	x7, #0x9
    8f78:      	b.eq	0x8ff4 <_stogir.types.size+0x2f4>
    8f7c:      	cmp	x7, #0x4
    8f80:      	b.eq	0x9004 <_stogir.types.size+0x304>
    8f84:      	cmp	x7, #0xa
    8f88:      	b.eq	0x9004 <_stogir.types.size+0x304>
    8f8c:      	cmp	x7, #0xd
    8f90:      	b.eq	0x9004 <_stogir.types.size+0x304>
    8f94:      	cmp	x7, #0x5
    8f98:      	b.eq	0x9014 <_stogir.types.size+0x314>
    8f9c:      	cmp	x7, #0xb
    8fa0:      	b.eq	0x9014 <_stogir.types.size+0x314>
    8fa4:      	cmp	x7, #0xc
    8fa8:      	b.eq	0x9014 <_stogir.types.size+0x314>
    8fac:      	cmp	x7, #0x6
    8fb0:      	b.eq	0x8fb8 <_stogir.types.size+0x2b8>
    8fb4:      	movn	x1, #0x0, lsl #48
    8fb8:      	b	0x9018 <_stogir.types.size+0x318>
    8fbc:      	mov	x0, #0x2                ; =2
    8fc0:      	b	0x8e30 <_stogir.types.size+0x130>
    8fc4:      	uxtb	w16, w10
    8fc8:      	cmp	w16, wzr
    8fcc:      	b.eq	0x8f18 <_stogir.types.size+0x218>
    8fd0:      	uxtb	w16, w11
    8fd4:      	cmp	w16, wzr
    8fd8:      	b.eq	0x8f18 <_stogir.types.size+0x218>
    8fdc:      	uxtb	w16, w3
    8fe0:      	cmp	w16, wzr
    8fe4:      	cset	x0, eq
    8fe8:      	b	0x8f1c <_stogir.types.size+0x21c>
    8fec:      	mov	x0, #0x4                ; =4
    8ff0:      	b	0x8fc0 <_stogir.types.size+0x2c0>
    8ff4:      	mov	x1, #0x2                ; =2
    8ff8:      	b	0x8ea8 <_stogir.types.size+0x1a8>
    8ffc:      	mov	x0, #0x8                ; =8
    9000:      	b	0x8ff0 <_stogir.types.size+0x2f0>
    9004:      	mov	x1, #0x4                ; =4
    9008:      	b	0x8ff8 <_stogir.types.size+0x2f8>
    900c:      	movn	x0, #0x0, lsl #48
    9010:      	b	0x9000 <_stogir.types.size+0x300>
    9014:      	mov	x1, #0x8                ; =8
    9018:      	b	0x9008 <_stogir.types.size+0x308>

000000000000901c <_stogir.opcode.properties>:
    901c:      	sxtw	x0, w0
    9020:      	cmp	x0, #0x0
    9024:      	b.lt	0x9048 <_stogir.opcode.properties+0x2c>
    9028:      	cmp	x0, #0x83
    902c:      	b.ge	0x9048 <_stogir.opcode.properties+0x2c>
    9030:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009030:  ARM64_RELOC_PAGE21	l_stogir.427
    9034:      	ldr	x16, [x16]
		0000000000009034:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    9038:      	orr	x1, x16, xzr
    903c:      	add	x0, x1, x0
    9040:      	ldrb	w0, [x0]
    9044:      	b	0x904c <_stogir.opcode.properties+0x30>
    9048:      	movz	x0, #0x0, lsl #48
    904c:      	ret

0000000000009050 <_stogir.checked.projection>:
    9050:      	sub	sp, sp, #0x40
    9054:      	str	x29, [sp]
    9058:      	str	x30, [sp, #0x8]
    905c:      	mov	x29, sp
    9060:      	str	x19, [sp, #0x30]
    9064:      	sxtw	x2, w1
    9068:      	cmp	x2, #0x0
    906c:      	cset	w3, gt
    9070:      	movz	x16, #0x0, lsl #48
    9074:      	sub	x4, x16, x2
    9078:      	sub	x5, x4, #0x1
    907c:      	uxtb	w16, w3
    9080:      	cmp	w16, wzr
    9084:      	b.eq	0x90c4 <_stogir.checked.projection+0x74>
    9088:      	ldr	x4, [x0, #0x8]
    908c:      	cmp	x2, x4
    9090:      	b.ge	0x9114 <_stogir.checked.projection+0xc4>
    9094:      	add	x4, x0, #0x78
    9098:      	ldr	x4, [x4, #0x8]
    909c:      	cmp	x2, x4
    90a0:      	b.ge	0x922c <_stogir.checked.projection+0x1dc>
    90a4:      	ldr	x4, [x0, #0x78]
    90a8:      	add	x4, x4, x2, lsl #2
    90ac:      	ldr	w4, [x4]
    90b0:      	sxtw	x4, w4
    90b4:      	cmp	x4, #0x0
    90b8:      	cset	w4, ge
    90bc:      	ubfx	x4, x4, #0, #8
    90c0:      	b	0x9230 <_stogir.checked.projection+0x1e0>
    90c4:      	cmp	x2, #0x0
    90c8:      	b.ge	0x911c <_stogir.checked.projection+0xcc>
    90cc:      	add	x6, x0, #0x28
    90d0:      	add	x7, x0, #0x50
    90d4:      	ldr	x6, [x6, #0x8]
    90d8:      	ldr	x7, [x7, #0x8]
    90dc:      	cmp	x6, x7
    90e0:      	b.ne	0x910c <_stogir.checked.projection+0xbc>
    90e4:      	cmp	x4, x6
    90e8:      	b.gt	0x925c <_stogir.checked.projection+0x20c>
    90ec:      	ldr	x4, [x0, #0x50]
    90f0:      	add	x4, x4, x5, lsl #2
    90f4:      	ldr	w4, [x4]
    90f8:      	sxtw	x4, w4
    90fc:      	cmp	x4, #0x0
    9100:      	cset	w4, gt
    9104:      	ubfx	x4, x4, #0, #8
    9108:      	b	0x9260 <_stogir.checked.projection+0x210>
    910c:      	movz	x4, #0x0, lsl #48
    9110:      	b	0x9120 <_stogir.checked.projection+0xd0>
    9114:      	movz	x4, #0x0, lsl #48
    9118:      	b	0x9120 <_stogir.checked.projection+0xd0>
    911c:      	movz	x4, #0x0, lsl #48
    9120:      	cmp	x4, #0x0
    9124:      	b.eq	0x915c <_stogir.checked.projection+0x10c>
    9128:      	uxtb	w16, w3
    912c:      	cmp	w16, wzr
    9130:      	b.eq	0x9144 <_stogir.checked.projection+0xf4>
    9134:      	ldr	x3, [x0]
    9138:      	add	x2, x3, x2, lsl #4
    913c:      	ldr	x2, [x2]
    9140:      	b	0x9150 <_stogir.checked.projection+0x100>
    9144:      	ldr	x2, [x0, #0x28]
    9148:      	add	x2, x2, x5, lsl #4
    914c:      	ldr	x2, [x2]
    9150:      	mov	x3, x2
    9154:      	mov	x2, #0x1                ; =1
    9158:      	b	0x9164 <_stogir.checked.projection+0x114>
    915c:      	movz	x2, #0x0, lsl #48
    9160:      	movz	x3, #0x0, lsl #48
    9164:      	lsr	w2, w2, #0
    9168:      	lsr	x16, x2, #0
    916c:      	cmp	x16, #0x1
    9170:      	b.eq	0x918c <_stogir.checked.projection+0x13c>
    9174:      	b.lo	0x917c <_stogir.checked.projection+0x12c>
    9178:      	b	0x9190 <_stogir.checked.projection+0x140>
    917c:      	cmp	x16, #0x0
    9180:      	b.eq	0x9188 <_stogir.checked.projection+0x138>
    9184:      	b	0x9190 <_stogir.checked.projection+0x140>
    9188:      	b	0x9194 <_stogir.checked.projection+0x144>
    918c:      	b	0x91ec <_stogir.checked.projection+0x19c>
    9190:      	b	0x9264 <_stogir.checked.projection+0x214>
    9194:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009194:  ARM64_RELOC_PAGE21	l_stogir.428
    9198:      	ldr	x16, [x16]
		0000000000009198:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    919c:      	orr	x0, x16, xzr
    91a0:      	mov	x19, x8
    91a4:      	mov	x1, x0
    91a8:      	mov	x0, #0x1                ; =1
    91ac:      	mov	x2, #0x17               ; =23
    91b0:      	b	0x91cc <_stogir.checked.projection+0x17c>
    91b4:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		00000000000091b4:  ARM64_RELOC_PAGE21	l_stogir.429
    91b8:      	ldr	x16, [x16]
		00000000000091b8:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    91bc:      	orr	x0, x16, xzr
    91c0:      	mov	x1, x0
    91c4:      	mov	x0, #0x1                ; =1
    91c8:      	mov	x2, #0x20               ; =32
    91cc:      	str	x0, [x19]
    91d0:      	str	x1, [x19, #0x8]
    91d4:      	str	x2, [x19, #0x10]
    91d8:      	ldr	x19, [sp, #0x30]
    91dc:      	ldr	x29, [sp]
    91e0:      	ldr	x30, [sp, #0x8]
    91e4:      	add	sp, sp, #0x40
    91e8:      	ret
    91ec:      	uxtb	w2, w3
    91f0:      	cmp	x2, #0x29
    91f4:      	b.lt	0x926c <_stogir.checked.projection+0x21c>
    91f8:      	cmp	x2, #0x2b
    91fc:      	b.gt	0x9274 <_stogir.checked.projection+0x224>
    9200:      	lsr	w1, w1, #0
    9204:      	mov	x19, x8
    9208:      	add	x8, sp, #0x10
    920c:      	bl	0x920c <_stogir.checked.projection+0x1bc>
		000000000000920c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    9210:      	add	x16, sp, #0x10
    9214:      	ldr	x0, [x16]
    9218:      	add	x16, sp, #0x10
    921c:      	ldr	x1, [x16, #0x8]
    9220:      	add	x16, sp, #0x10
    9224:      	ldr	x2, [x16, #0x10]
    9228:      	b	0x91cc <_stogir.checked.projection+0x17c>
    922c:      	movz	x4, #0x0, lsl #48
    9230:      	b	0x9118 <_stogir.checked.projection+0xc8>
    9234:      	lsr	w3, w3, #0
    9238:      	ubfx	x0, x3, #8, #8
    923c:      	cmp	x0, #0x0
    9240:      	b.eq	0x91b4 <_stogir.checked.projection+0x164>
    9244:      	cmp	x0, #0xd
    9248:      	b.gt	0x91b4 <_stogir.checked.projection+0x164>
    924c:      	movz	x0, #0x0, lsl #48
    9250:      	movz	x1, #0x0, lsl #48
    9254:      	movz	x2, #0x0, lsl #48
    9258:      	b	0x91cc <_stogir.checked.projection+0x17c>
    925c:      	movz	x4, #0x0, lsl #48
    9260:      	b	0x9110 <_stogir.checked.projection+0xc0>
    9264:      	brk	#0
    9268:      	b	0x9264 <_stogir.checked.projection+0x214>
    926c:      	mov	x19, x8
    9270:      	b	0x9234 <_stogir.checked.projection+0x1e4>
    9274:      	mov	x19, x8
    9278:      	b	0x9234 <_stogir.checked.projection+0x1e4>

000000000000927c <_stogir.checked.operands>:
    927c:      	sub	sp, sp, #0x30
    9280:      	str	x19, [sp, #0x20]
    9284:      	str	x20, [sp, #0x28]
    9288:      	sxtw	x1, w1
    928c:      	sxtw	x2, w2
    9290:      	cmp	x1, #0x29
    9294:      	b.lt	0x92dc <_stogir.checked.operands+0x60>
    9298:      	cmp	x1, #0x2b
    929c:      	b.gt	0x92dc <_stogir.checked.operands+0x60>
    92a0:      	cmp	x2, #0x1
    92a4:      	b.lt	0x92dc <_stogir.checked.operands+0x60>
    92a8:      	cmp	x2, #0xb
    92ac:      	b.gt	0x92dc <_stogir.checked.operands+0x60>
    92b0:      	cmp	x2, #0x1
    92b4:      	b.eq	0x92dc <_stogir.checked.operands+0x60>
    92b8:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		00000000000092b8:  ARM64_RELOC_PAGE21	l_stogir.430
    92bc:      	ldr	x16, [x16]
		00000000000092bc:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    92c0:      	orr	x1, x16, xzr
    92c4:      	movz	x5, #0x0, lsl #48
    92c8:      	b	0x92ec <_stogir.checked.operands+0x70>
    92cc:      	movz	x14, #0x0, lsl #48
    92d0:      	b	0x9350 <_stogir.checked.operands+0xd4>
    92d4:      	movz	x14, #0x0, lsl #48
    92d8:      	b	0x9364 <_stogir.checked.operands+0xe8>
    92dc:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		00000000000092dc:  ARM64_RELOC_PAGE21	l_stogir.431
    92e0:      	ldr	x16, [x16]
		00000000000092e0:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    92e4:      	orr	x1, x16, xzr
    92e8:      	mov	x5, #0x36               ; =54
    92ec:      	add	x16, sp, #0x10
    92f0:      	orr	x6, x16, xzr
    92f4:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		00000000000092f4:  ARM64_RELOC_PAGE21	l_stogir.432
    92f8:      	ldr	x16, [x16]
		00000000000092f8:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    92fc:      	orr	x7, x16, xzr
    9300:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009300:  ARM64_RELOC_PAGE21	l_stogir.433
    9304:      	ldr	x16, [x16]
		0000000000009304:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9308:      	orr	x9, x16, xzr
    930c:      	lsr	w3, w3, #0
    9310:      	lsr	w4, w4, #0
    9314:      	add	x10, x0, #0x78
    9318:      	add	x11, x0, #0x28
    931c:      	add	x12, x0, #0x50
    9320:      	mov	x16, sp
    9324:      	str	w3, [x16]
    9328:      	mov	x16, sp
    932c:      	str	w4, [x16, #0x4]
    9330:      	mov	x16, sp
    9334:      	ldr	x3, [x16]
    9338:      	add	x16, sp, #0x10
    933c:      	str	x3, [x16]
    9340:      	mov	x3, x5
    9344:      	movz	x4, #0x0, lsl #48
    9348:      	b	0x940c <_stogir.checked.operands+0x190>
    934c:      	movz	x14, #0x0, lsl #48
    9350:      	fmov	d31, x13
    9354:      	mov	x13, x14
    9358:      	fmov	x14, d31
    935c:      	b	0x9370 <_stogir.checked.operands+0xf4>
    9360:      	movz	x14, #0x0, lsl #48
    9364:      	fmov	d31, x13
    9368:      	mov	x13, x14
    936c:      	fmov	x14, d31
    9370:      	cmp	x13, #0x0
    9374:      	b.eq	0x93ac <_stogir.checked.operands+0x130>
    9378:      	uxtb	w16, w4
    937c:      	cmp	w16, wzr
    9380:      	b.eq	0x9394 <_stogir.checked.operands+0x118>
    9384:      	ldr	x4, [x0]
    9388:      	add	x4, x4, x5, lsl #4
    938c:      	ldr	x4, [x4]
    9390:      	b	0x93a0 <_stogir.checked.operands+0x124>
    9394:      	ldr	x4, [x0, #0x28]
    9398:      	add	x4, x4, x15, lsl #4
    939c:      	ldr	x4, [x4]
    93a0:      	mov	x5, x4
    93a4:      	mov	x4, #0x1                ; =1
    93a8:      	b	0x93b4 <_stogir.checked.operands+0x138>
    93ac:      	movz	x4, #0x0, lsl #48
    93b0:      	movz	x5, #0x0, lsl #48
    93b4:      	lsr	w4, w4, #0
    93b8:      	lsr	x16, x4, #0
    93bc:      	cmp	x16, #0x1
    93c0:      	b.eq	0x93dc <_stogir.checked.operands+0x160>
    93c4:      	b.lo	0x93cc <_stogir.checked.operands+0x150>
    93c8:      	b	0x93e0 <_stogir.checked.operands+0x164>
    93cc:      	cmp	x16, #0x0
    93d0:      	b.eq	0x93d8 <_stogir.checked.operands+0x15c>
    93d4:      	b	0x93e0 <_stogir.checked.operands+0x164>
    93d8:      	b	0x93e4 <_stogir.checked.operands+0x168>
    93dc:      	b	0x93f0 <_stogir.checked.operands+0x174>
    93e0:      	b	0x9564 <_stogir.checked.operands+0x2e8>
    93e4:      	mov	x1, x7
    93e8:      	mov	x3, #0x22               ; =34
    93ec:      	b	0x9408 <_stogir.checked.operands+0x18c>
    93f0:      	lsr	w5, w5, #0
    93f4:      	ubfx	x4, x5, #8, #8
    93f8:      	cmp	x4, x2
    93fc:      	b.eq	0x9408 <_stogir.checked.operands+0x18c>
    9400:      	mov	x1, x9
    9404:      	mov	x3, #0x28               ; =40
    9408:      	mov	x4, x14
    940c:      	cmp	x4, #0x2
    9410:      	b.ge	0x9438 <_stogir.checked.operands+0x1bc>
    9414:      	add	x5, x4, #0x1
    9418:      	add	x4, x6, x4, lsl #2
    941c:      	ldr	w4, [x4]
    9420:      	sxtw	x4, w4
    9424:      	and	x4, x4, #0xffffffff
    9428:      	mov	x13, x5
    942c:      	mov	x5, x4
    9430:      	mov	x4, #0x1                ; =1
    9434:      	b	0x9444 <_stogir.checked.operands+0x1c8>
    9438:      	mov	x13, x4
    943c:      	movz	x4, #0x0, lsl #48
    9440:      	movz	x5, #0x0, lsl #48
    9444:      	lsr	w4, w4, #0
    9448:      	lsr	x16, x4, #0
    944c:      	cmp	x16, #0x1
    9450:      	b.eq	0x946c <_stogir.checked.operands+0x1f0>
    9454:      	b.lo	0x945c <_stogir.checked.operands+0x1e0>
    9458:      	b	0x9470 <_stogir.checked.operands+0x1f4>
    945c:      	cmp	x16, #0x0
    9460:      	b.eq	0x9468 <_stogir.checked.operands+0x1ec>
    9464:      	b	0x9470 <_stogir.checked.operands+0x1f4>
    9468:      	b	0x94d4 <_stogir.checked.operands+0x258>
    946c:      	b	0x9474 <_stogir.checked.operands+0x1f8>
    9470:      	b	0x955c <_stogir.checked.operands+0x2e0>
    9474:      	lsr	w5, w5, #0
    9478:      	sxtw	x5, w5
    947c:      	cmp	x5, #0x0
    9480:      	cset	w4, gt
    9484:      	movz	x16, #0x0, lsl #48
    9488:      	sub	x14, x16, x5
    948c:      	sub	x15, x14, #0x1
    9490:      	uxtb	w16, w4
    9494:      	cmp	w16, wzr
    9498:      	b.eq	0x9514 <_stogir.checked.operands+0x298>
    949c:      	ldr	x14, [x0, #0x8]
    94a0:      	cmp	x5, x14
    94a4:      	b.ge	0x934c <_stogir.checked.operands+0xd0>
    94a8:      	ldr	x14, [x10, #0x8]
    94ac:      	cmp	x5, x14
    94b0:      	b.ge	0x92cc <_stogir.checked.operands+0x50>
    94b4:      	ldr	x14, [x0, #0x78]
    94b8:      	add	x14, x14, x5, lsl #2
    94bc:      	ldr	w14, [x14]
    94c0:      	sxtw	x14, w14
    94c4:      	cmp	x14, #0x0
    94c8:      	cset	w14, ge
    94cc:      	ubfx	x14, x14, #0, #8
    94d0:      	b	0x92d0 <_stogir.checked.operands+0x54>
    94d4:      	cmp	x3, #0x0
    94d8:      	b.ne	0x94f0 <_stogir.checked.operands+0x274>
    94dc:      	and	x0, x2, #0xffffffff
    94e0:      	mov	x1, x0
    94e4:      	movz	x0, #0x0, lsl #48
    94e8:      	movz	x2, #0x0, lsl #48
    94ec:      	b	0x94f8 <_stogir.checked.operands+0x27c>
    94f0:      	mov	x2, x3
    94f4:      	mov	x0, #0x1                ; =1
    94f8:      	str	x0, [x8]
    94fc:      	str	x1, [x8, #0x8]
    9500:      	str	x2, [x8, #0x10]
    9504:      	ldr	x19, [sp, #0x20]
    9508:      	ldr	x20, [sp, #0x28]
    950c:      	add	sp, sp, #0x30
    9510:      	ret
    9514:      	cmp	x5, #0x0
    9518:      	b.ge	0x9360 <_stogir.checked.operands+0xe4>
    951c:      	ldr	x19, [x11, #0x8]
    9520:      	ldr	x20, [x12, #0x8]
    9524:      	cmp	x19, x20
    9528:      	b.ne	0x92d4 <_stogir.checked.operands+0x58>
    952c:      	cmp	x14, x19
    9530:      	b.gt	0x9554 <_stogir.checked.operands+0x2d8>
    9534:      	ldr	x14, [x0, #0x50]
    9538:      	add	x14, x14, x15, lsl #2
    953c:      	ldr	w14, [x14]
    9540:      	sxtw	x14, w14
    9544:      	cmp	x14, #0x0
    9548:      	cset	w14, gt
    954c:      	ubfx	x14, x14, #0, #8
    9550:      	b	0x9558 <_stogir.checked.operands+0x2dc>
    9554:      	movz	x14, #0x0, lsl #48
    9558:      	b	0x92d8 <_stogir.checked.operands+0x5c>
    955c:      	brk	#0
    9560:      	b	0x955c <_stogir.checked.operands+0x2e0>
    9564:      	brk	#0
    9568:      	b	0x9564 <_stogir.checked.operands+0x2e8>

000000000000956c <_stogir.opcode.control?>:
    956c:      	sxtw	x0, w0
    9570:      	cmp	x0, #0x0
    9574:      	b.lt	0x9598 <_stogir.opcode.control?+0x2c>
    9578:      	cmp	x0, #0x83
    957c:      	b.ge	0x9598 <_stogir.opcode.control?+0x2c>
    9580:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009580:  ARM64_RELOC_PAGE21	l_stogir.434
    9584:      	ldr	x16, [x16]
		0000000000009584:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9588:      	orr	x1, x16, xzr
    958c:      	add	x0, x1, x0
    9590:      	ldrb	w0, [x0]
    9594:      	b	0x959c <_stogir.opcode.control?+0x30>
    9598:      	movz	x0, #0x0, lsl #48
    959c:      	uxtb	w0, w0
    95a0:      	and	x0, x0, #0x1
    95a4:      	uxtb	w0, w0
    95a8:      	ret

00000000000095ac <_stogir.opcode.block-end?>:
    95ac:      	sxtw	x0, w0
    95b0:      	cmp	x0, #0x0
    95b4:      	b.lt	0x95d8 <_stogir.opcode.block-end?+0x2c>
    95b8:      	cmp	x0, #0x83
    95bc:      	b.ge	0x95d8 <_stogir.opcode.block-end?+0x2c>
    95c0:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		00000000000095c0:  ARM64_RELOC_PAGE21	l_stogir.435
    95c4:      	ldr	x16, [x16]
		00000000000095c4:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    95c8:      	orr	x1, x16, xzr
    95cc:      	add	x0, x1, x0
    95d0:      	ldrb	w0, [x0]
    95d4:      	b	0x95dc <_stogir.opcode.block-end?+0x30>
    95d8:      	movz	x0, #0x0, lsl #48
    95dc:      	uxtb	w0, w0
    95e0:      	and	x0, x0, #0x4
    95e4:      	uxtb	w0, w0
    95e8:      	cmp	x0, #0x0
    95ec:      	cset	w0, eq
    95f0:      	uxtb	w16, w0
    95f4:      	cmp	w16, wzr
    95f8:      	cset	x0, eq
    95fc:      	ret

0000000000009600 <_stogir.atomic.ordinary?>:
    9600:      	sxtw	x1, w1
    9604:      	cmp	x1, #0x0
    9608:      	cset	w3, gt
    960c:      	movz	x16, #0x0, lsl #48
    9610:      	sub	x4, x16, x1
    9614:      	sub	x5, x4, #0x1
    9618:      	uxtb	w16, w3
    961c:      	cmp	w16, wzr
    9620:      	b.eq	0x9660 <_stogir.atomic.ordinary?+0x60>
    9624:      	ldr	x4, [x0, #0x8]
    9628:      	cmp	x1, x4
    962c:      	b.ge	0x96b0 <_stogir.atomic.ordinary?+0xb0>
    9630:      	add	x4, x0, #0x78
    9634:      	ldr	x4, [x4, #0x8]
    9638:      	cmp	x1, x4
    963c:      	b.ge	0x9768 <_stogir.atomic.ordinary?+0x168>
    9640:      	ldr	x4, [x0, #0x78]
    9644:      	add	x4, x4, x1, lsl #2
    9648:      	ldr	w4, [x4]
    964c:      	sxtw	x4, w4
    9650:      	cmp	x4, #0x0
    9654:      	cset	w4, ge
    9658:      	ubfx	x4, x4, #0, #8
    965c:      	b	0x976c <_stogir.atomic.ordinary?+0x16c>
    9660:      	cmp	x1, #0x0
    9664:      	b.ge	0x96b8 <_stogir.atomic.ordinary?+0xb8>
    9668:      	add	x6, x0, #0x28
    966c:      	add	x7, x0, #0x50
    9670:      	ldr	x6, [x6, #0x8]
    9674:      	ldr	x7, [x7, #0x8]
    9678:      	cmp	x6, x7
    967c:      	b.ne	0x96a8 <_stogir.atomic.ordinary?+0xa8>
    9680:      	cmp	x4, x6
    9684:      	b.gt	0x9788 <_stogir.atomic.ordinary?+0x188>
    9688:      	ldr	x4, [x0, #0x50]
    968c:      	add	x4, x4, x5, lsl #2
    9690:      	ldr	w4, [x4]
    9694:      	sxtw	x4, w4
    9698:      	cmp	x4, #0x0
    969c:      	cset	w4, gt
    96a0:      	ubfx	x4, x4, #0, #8
    96a4:      	b	0x978c <_stogir.atomic.ordinary?+0x18c>
    96a8:      	movz	x4, #0x0, lsl #48
    96ac:      	b	0x96bc <_stogir.atomic.ordinary?+0xbc>
    96b0:      	movz	x4, #0x0, lsl #48
    96b4:      	b	0x96bc <_stogir.atomic.ordinary?+0xbc>
    96b8:      	movz	x4, #0x0, lsl #48
    96bc:      	cmp	x4, #0x0
    96c0:      	b.eq	0x96f8 <_stogir.atomic.ordinary?+0xf8>
    96c4:      	uxtb	w16, w3
    96c8:      	cmp	w16, wzr
    96cc:      	b.eq	0x96e0 <_stogir.atomic.ordinary?+0xe0>
    96d0:      	ldr	x0, [x0]
    96d4:      	add	x0, x0, x1, lsl #4
    96d8:      	ldr	x0, [x0]
    96dc:      	b	0x96ec <_stogir.atomic.ordinary?+0xec>
    96e0:      	ldr	x0, [x0, #0x28]
    96e4:      	add	x0, x0, x5, lsl #4
    96e8:      	ldr	x0, [x0]
    96ec:      	mov	x1, x0
    96f0:      	mov	x0, #0x1                ; =1
    96f4:      	b	0x9700 <_stogir.atomic.ordinary?+0x100>
    96f8:      	movz	x0, #0x0, lsl #48
    96fc:      	movz	x1, #0x0, lsl #48
    9700:      	lsr	w0, w0, #0
    9704:      	lsr	x16, x0, #0
    9708:      	cmp	x16, #0x1
    970c:      	b.eq	0x9728 <_stogir.atomic.ordinary?+0x128>
    9710:      	b.lo	0x9718 <_stogir.atomic.ordinary?+0x118>
    9714:      	b	0x972c <_stogir.atomic.ordinary?+0x12c>
    9718:      	cmp	x16, #0x0
    971c:      	b.eq	0x9724 <_stogir.atomic.ordinary?+0x124>
    9720:      	b	0x972c <_stogir.atomic.ordinary?+0x12c>
    9724:      	b	0x9730 <_stogir.atomic.ordinary?+0x130>
    9728:      	b	0x9740 <_stogir.atomic.ordinary?+0x140>
    972c:      	b	0x9790 <_stogir.atomic.ordinary?+0x190>
    9730:      	movz	x0, #0x0, lsl #48
    9734:      	b	0x973c <_stogir.atomic.ordinary?+0x13c>
    9738:      	movz	x0, #0x0, lsl #48
    973c:      	ret
    9740:      	sxtw	x2, w2
    9744:      	lsr	w0, w1, #0
    9748:      	ubfx	x0, x0, #8, #8
    974c:      	cmp	x0, x2
    9750:      	b.ne	0x9738 <_stogir.atomic.ordinary?+0x138>
    9754:      	uxtb	w1, w1
    9758:      	cmp	x1, #0x46
    975c:      	b.ne	0x9770 <_stogir.atomic.ordinary?+0x170>
    9760:      	movz	x0, #0x0, lsl #48
    9764:      	b	0x9784 <_stogir.atomic.ordinary?+0x184>
    9768:      	movz	x4, #0x0, lsl #48
    976c:      	b	0x96b4 <_stogir.atomic.ordinary?+0xb4>
    9770:      	cmp	x1, #0x48
    9774:      	cset	w0, eq
    9778:      	uxtb	w16, w0
    977c:      	cmp	w16, wzr
    9780:      	cset	x0, eq
    9784:      	b	0x973c <_stogir.atomic.ordinary?+0x13c>
    9788:      	movz	x4, #0x0, lsl #48
    978c:      	b	0x96ac <_stogir.atomic.ordinary?+0xac>
    9790:      	brk	#0
    9794:      	b	0x9790 <_stogir.atomic.ordinary?+0x190>

0000000000009798 <_stogir.types.scalar-size>:
    9798:      	sxtw	x1, w1
    979c:      	cmp	x1, #0x4
    97a0:      	b.eq	0x97b4 <_stogir.types.scalar-size+0x1c>
    97a4:      	cmp	x1, #0x8
    97a8:      	b.eq	0x97b4 <_stogir.types.scalar-size+0x1c>
    97ac:      	movn	x0, #0x0, lsl #48
    97b0:      	b	0x97cc <_stogir.types.scalar-size+0x34>
    97b4:      	sxtw	x0, w0
    97b8:      	cmp	x0, #0x0
    97bc:      	b.ne	0x97d0 <_stogir.types.scalar-size+0x38>
    97c0:      	movz	x0, #0x0, lsl #48
    97c4:      	b	0x97cc <_stogir.types.scalar-size+0x34>
    97c8:      	mov	x0, #0x1                ; =1
    97cc:      	ret
    97d0:      	cmp	x0, #0x1
    97d4:      	b.eq	0x97c8 <_stogir.types.scalar-size+0x30>
    97d8:      	cmp	x0, #0x2
    97dc:      	b.eq	0x97c8 <_stogir.types.scalar-size+0x30>
    97e0:      	cmp	x0, #0x7
    97e4:      	b.eq	0x97c8 <_stogir.types.scalar-size+0x30>
    97e8:      	cmp	x0, #0x8
    97ec:      	b.eq	0x97c8 <_stogir.types.scalar-size+0x30>
    97f0:      	cmp	x0, #0x3
    97f4:      	b.eq	0x9840 <_stogir.types.scalar-size+0xa8>
    97f8:      	cmp	x0, #0x9
    97fc:      	b.eq	0x9840 <_stogir.types.scalar-size+0xa8>
    9800:      	cmp	x0, #0x4
    9804:      	b.eq	0x9848 <_stogir.types.scalar-size+0xb0>
    9808:      	cmp	x0, #0xa
    980c:      	b.eq	0x9848 <_stogir.types.scalar-size+0xb0>
    9810:      	cmp	x0, #0xd
    9814:      	b.eq	0x9848 <_stogir.types.scalar-size+0xb0>
    9818:      	cmp	x0, #0x5
    981c:      	b.eq	0x9850 <_stogir.types.scalar-size+0xb8>
    9820:      	cmp	x0, #0xb
    9824:      	b.eq	0x9850 <_stogir.types.scalar-size+0xb8>
    9828:      	cmp	x0, #0xc
    982c:      	b.eq	0x9850 <_stogir.types.scalar-size+0xb8>
    9830:      	cmp	x0, #0x6
    9834:      	b.ne	0x9858 <_stogir.types.scalar-size+0xc0>
    9838:      	mov	x0, x1
    983c:      	b	0x985c <_stogir.types.scalar-size+0xc4>
    9840:      	mov	x0, #0x2                ; =2
    9844:      	b	0x97cc <_stogir.types.scalar-size+0x34>
    9848:      	mov	x0, #0x4                ; =4
    984c:      	b	0x9844 <_stogir.types.scalar-size+0xac>
    9850:      	mov	x0, #0x8                ; =8
    9854:      	b	0x984c <_stogir.types.scalar-size+0xb4>
    9858:      	movn	x0, #0x0, lsl #48
    985c:      	b	0x9854 <_stogir.types.scalar-size+0xbc>

0000000000009860 <_stogir.terminal.inputs>:
    9860:      	sxtw	x1, w1
    9864:      	cmp	x1, #0x60
    9868:      	cset	w4, eq
    986c:      	uxtb	w16, w4
    9870:      	cmp	w16, wzr
    9874:      	b.ne	0x98a8 <_stogir.terminal.inputs+0x48>
    9878:      	cmp	x1, #0x79
    987c:      	b.eq	0x98a8 <_stogir.terminal.inputs+0x48>
    9880:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009880:  ARM64_RELOC_PAGE21	l_stogir.436
    9884:      	ldr	x16, [x16]
		0000000000009884:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    9888:      	orr	x0, x16, xzr
    988c:      	mov	x1, x0
    9890:      	mov	x0, #0x1                ; =1
    9894:      	mov	x2, #0x25               ; =37
    9898:      	str	x0, [x8]
    989c:      	str	x1, [x8, #0x8]
    98a0:      	str	x2, [x8, #0x10]
    98a4:      	ret
    98a8:      	sxtw	x3, w3
    98ac:      	uxtb	w16, w4
    98b0:      	cmp	w16, wzr
    98b4:      	b.eq	0x98c0 <_stogir.terminal.inputs+0x60>
    98b8:      	cmp	x3, #0x0
    98bc:      	b.ne	0x9880 <_stogir.terminal.inputs+0x20>
    98c0:      	sxtw	x2, w2
    98c4:      	cmp	x2, #0x0
    98c8:      	cset	w1, gt
    98cc:      	movz	x16, #0x0, lsl #48
    98d0:      	sub	x4, x16, x2
    98d4:      	sub	x5, x4, #0x1
    98d8:      	uxtb	w16, w1
    98dc:      	cmp	w16, wzr
    98e0:      	b.eq	0x99bc <_stogir.terminal.inputs+0x15c>
    98e4:      	ldr	x4, [x0, #0x8]
    98e8:      	cmp	x2, x4
    98ec:      	b.ge	0x99b4 <_stogir.terminal.inputs+0x154>
    98f0:      	add	x4, x0, #0x78
    98f4:      	ldr	x4, [x4, #0x8]
    98f8:      	cmp	x2, x4
    98fc:      	b.ge	0x9a60 <_stogir.terminal.inputs+0x200>
    9900:      	ldr	x4, [x0, #0x78]
    9904:      	add	x4, x4, x2, lsl #2
    9908:      	ldr	w4, [x4]
    990c:      	sxtw	x4, w4
    9910:      	cmp	x4, #0x0
    9914:      	cset	w4, ge
    9918:      	ubfx	x4, x4, #0, #8
    991c:      	b	0x9a64 <_stogir.terminal.inputs+0x204>
    9920:      	movz	x1, #0x0, lsl #48
    9924:      	movz	x4, #0x0, lsl #48
    9928:      	lsr	w1, w1, #0
    992c:      	lsr	x16, x1, #0
    9930:      	cmp	x16, #0x1
    9934:      	b.eq	0x9950 <_stogir.terminal.inputs+0xf0>
    9938:      	b.lo	0x9940 <_stogir.terminal.inputs+0xe0>
    993c:      	b	0x9954 <_stogir.terminal.inputs+0xf4>
    9940:      	cmp	x16, #0x0
    9944:      	b.eq	0x994c <_stogir.terminal.inputs+0xec>
    9948:      	b	0x9954 <_stogir.terminal.inputs+0xf4>
    994c:      	b	0x9958 <_stogir.terminal.inputs+0xf8>
    9950:      	b	0x9a04 <_stogir.terminal.inputs+0x1a4>
    9954:      	b	0x9bb0 <_stogir.terminal.inputs+0x350>
    9958:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009958:  ARM64_RELOC_PAGE21	l_stogir.437
    995c:      	ldr	x16, [x16]
		000000000000995c:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    9960:      	orr	x0, x16, xzr
    9964:      	mov	x1, x0
    9968:      	mov	x0, #0x1                ; =1
    996c:      	mov	x2, #0x1d               ; =29
    9970:      	b	0x9898 <_stogir.terminal.inputs+0x38>
    9974:      	ldr	x1, [x0, #0x28]
    9978:      	add	x1, x1, x5, lsl #4
    997c:      	ldr	x1, [x1]
    9980:      	mov	x4, x1
    9984:      	mov	x1, #0x1                ; =1
    9988:      	b	0x9928 <_stogir.terminal.inputs+0xc8>
    998c:      	movz	x4, #0x0, lsl #48
    9990:      	cmp	x4, #0x0
    9994:      	b.eq	0x9920 <_stogir.terminal.inputs+0xc0>
    9998:      	uxtb	w16, w1
    999c:      	cmp	w16, wzr
    99a0:      	b.eq	0x9974 <_stogir.terminal.inputs+0x114>
    99a4:      	ldr	x1, [x0]
    99a8:      	add	x1, x1, x2, lsl #4
    99ac:      	ldr	x1, [x1]
    99b0:      	b	0x9980 <_stogir.terminal.inputs+0x120>
    99b4:      	movz	x4, #0x0, lsl #48
    99b8:      	b	0x9990 <_stogir.terminal.inputs+0x130>
    99bc:      	cmp	x2, #0x0
    99c0:      	b.ge	0x998c <_stogir.terminal.inputs+0x12c>
    99c4:      	add	x6, x0, #0x28
    99c8:      	add	x7, x0, #0x50
    99cc:      	ldr	x6, [x6, #0x8]
    99d0:      	ldr	x7, [x7, #0x8]
    99d4:      	cmp	x6, x7
    99d8:      	b.ne	0x9a58 <_stogir.terminal.inputs+0x1f8>
    99dc:      	cmp	x4, x6
    99e0:      	b.gt	0x9a68 <_stogir.terminal.inputs+0x208>
    99e4:      	ldr	x4, [x0, #0x50]
    99e8:      	add	x4, x4, x5, lsl #2
    99ec:      	ldr	w4, [x4]
    99f0:      	sxtw	x4, w4
    99f4:      	cmp	x4, #0x0
    99f8:      	cset	w4, gt
    99fc:      	ubfx	x4, x4, #0, #8
    9a00:      	b	0x9a6c <_stogir.terminal.inputs+0x20c>
    9a04:      	cmp	x2, #0x0
    9a08:      	b.le	0x9a3c <_stogir.terminal.inputs+0x1dc>
    9a0c:      	uxtb	w4, w4
    9a10:      	cmp	x4, #0x83
    9a14:      	cset	w1, lt
    9a18:      	uxtb	w16, w1
    9a1c:      	cmp	w16, wzr
    9a20:      	b.eq	0x9a70 <_stogir.terminal.inputs+0x210>
    9a24:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009a24:  ARM64_RELOC_PAGE21	l_stogir.438
    9a28:      	ldr	x16, [x16]
		0000000000009a28:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9a2c:      	orr	x2, x16, xzr
    9a30:      	add	x2, x4, x2
    9a34:      	ldrb	w2, [x2]
    9a38:      	b	0x9a74 <_stogir.terminal.inputs+0x214>
    9a3c:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009a3c:  ARM64_RELOC_PAGE21	l_stogir.439
    9a40:      	ldr	x16, [x16]
		0000000000009a40:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    9a44:      	orr	x0, x16, xzr
    9a48:      	mov	x1, x0
    9a4c:      	mov	x0, #0x1                ; =1
    9a50:      	mov	x2, #0x2c               ; =44
    9a54:      	b	0x9970 <_stogir.terminal.inputs+0x110>
    9a58:      	movz	x4, #0x0, lsl #48
    9a5c:      	b	0x9990 <_stogir.terminal.inputs+0x130>
    9a60:      	movz	x4, #0x0, lsl #48
    9a64:      	b	0x99b8 <_stogir.terminal.inputs+0x158>
    9a68:      	movz	x4, #0x0, lsl #48
    9a6c:      	b	0x9a5c <_stogir.terminal.inputs+0x1fc>
    9a70:      	movz	x2, #0x0, lsl #48
    9a74:      	uxtb	w2, w2
    9a78:      	and	x2, x2, #0x1
    9a7c:      	uxtb	w2, w2
    9a80:      	cmp	x2, #0x0
    9a84:      	b.eq	0x9a3c <_stogir.terminal.inputs+0x1dc>
    9a88:      	uxtb	w16, w1
    9a8c:      	cmp	w16, wzr
    9a90:      	b.eq	0x9aac <_stogir.terminal.inputs+0x24c>
    9a94:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009a94:  ARM64_RELOC_PAGE21	l_stogir.438
    9a98:      	ldr	x16, [x16]
		0000000000009a98:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9a9c:      	orr	x1, x16, xzr
    9aa0:      	add	x1, x4, x1
    9aa4:      	ldrb	w1, [x1]
    9aa8:      	b	0x9ab0 <_stogir.terminal.inputs+0x250>
    9aac:      	movz	x1, #0x0, lsl #48
    9ab0:      	uxtb	w1, w1
    9ab4:      	and	x1, x1, #0x4
    9ab8:      	uxtb	w1, w1
    9abc:      	cmp	x1, #0x0
    9ac0:      	cset	w1, eq
    9ac4:      	uxtb	w16, w1
    9ac8:      	cmp	w16, wzr
    9acc:      	cset	x1, eq
    9ad0:      	cmp	x1, #0x0
    9ad4:      	b.ne	0x9a3c <_stogir.terminal.inputs+0x1dc>
    9ad8:      	cmp	x3, #0x0
    9adc:      	b.ne	0x9af0 <_stogir.terminal.inputs+0x290>
    9ae0:      	movz	x0, #0x0, lsl #48
    9ae4:      	movz	x1, #0x0, lsl #48
    9ae8:      	movz	x2, #0x0, lsl #48
    9aec:      	b	0x9a54 <_stogir.terminal.inputs+0x1f4>
    9af0:      	cmp	x3, #0x0
    9af4:      	cset	w1, gt
    9af8:      	movz	x16, #0x0, lsl #48
    9afc:      	sub	x2, x16, x3
    9b00:      	sub	x4, x2, #0x1
    9b04:      	uxtb	w16, w1
    9b08:      	cmp	w16, wzr
    9b0c:      	b.eq	0x9b68 <_stogir.terminal.inputs+0x308>
    9b10:      	ldr	x2, [x0, #0x8]
    9b14:      	cmp	x3, x2
    9b18:      	b.ge	0x9bb8 <_stogir.terminal.inputs+0x358>
    9b1c:      	add	x2, x0, #0x78
    9b20:      	ldr	x2, [x2, #0x8]
    9b24:      	cmp	x3, x2
    9b28:      	b.ge	0x9c88 <_stogir.terminal.inputs+0x428>
    9b2c:      	ldr	x2, [x0, #0x78]
    9b30:      	add	x2, x2, x3, lsl #2
    9b34:      	ldr	w2, [x2]
    9b38:      	sxtw	x2, w2
    9b3c:      	cmp	x2, #0x0
    9b40:      	cset	w2, ge
    9b44:      	ubfx	x2, x2, #0, #8
    9b48:      	b	0x9c8c <_stogir.terminal.inputs+0x42c>
    9b4c:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009b4c:  ARM64_RELOC_PAGE21	l_stogir.440
    9b50:      	ldr	x16, [x16]
		0000000000009b50:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    9b54:      	orr	x0, x16, xzr
    9b58:      	mov	x1, x0
    9b5c:      	mov	x0, #0x1                ; =1
    9b60:      	mov	x2, #0x2e               ; =46
    9b64:      	b	0x9aec <_stogir.terminal.inputs+0x28c>
    9b68:      	cmp	x3, #0x0
    9b6c:      	b.ge	0x9bc0 <_stogir.terminal.inputs+0x360>
    9b70:      	add	x5, x0, #0x28
    9b74:      	add	x6, x0, #0x50
    9b78:      	ldr	x5, [x5, #0x8]
    9b7c:      	ldr	x6, [x6, #0x8]
    9b80:      	cmp	x5, x6
    9b84:      	b.ne	0x9c80 <_stogir.terminal.inputs+0x420>
    9b88:      	cmp	x2, x5
    9b8c:      	b.gt	0x9c90 <_stogir.terminal.inputs+0x430>
    9b90:      	ldr	x2, [x0, #0x50]
    9b94:      	add	x2, x2, x4, lsl #2
    9b98:      	ldr	w2, [x2]
    9b9c:      	sxtw	x2, w2
    9ba0:      	cmp	x2, #0x0
    9ba4:      	cset	w2, gt
    9ba8:      	ubfx	x2, x2, #0, #8
    9bac:      	b	0x9c94 <_stogir.terminal.inputs+0x434>
    9bb0:      	brk	#0
    9bb4:      	b	0x9bb0 <_stogir.terminal.inputs+0x350>
    9bb8:      	movz	x2, #0x0, lsl #48
    9bbc:      	b	0x9bc4 <_stogir.terminal.inputs+0x364>
    9bc0:      	movz	x2, #0x0, lsl #48
    9bc4:      	cmp	x2, #0x0
    9bc8:      	b.eq	0x9c00 <_stogir.terminal.inputs+0x3a0>
    9bcc:      	uxtb	w16, w1
    9bd0:      	cmp	w16, wzr
    9bd4:      	b.eq	0x9be8 <_stogir.terminal.inputs+0x388>
    9bd8:      	ldr	x0, [x0]
    9bdc:      	add	x0, x0, x3, lsl #4
    9be0:      	ldr	x0, [x0]
    9be4:      	b	0x9bf4 <_stogir.terminal.inputs+0x394>
    9be8:      	ldr	x0, [x0, #0x28]
    9bec:      	add	x0, x0, x4, lsl #4
    9bf0:      	ldr	x0, [x0]
    9bf4:      	mov	x1, x0
    9bf8:      	mov	x0, #0x1                ; =1
    9bfc:      	b	0x9c08 <_stogir.terminal.inputs+0x3a8>
    9c00:      	movz	x0, #0x0, lsl #48
    9c04:      	movz	x1, #0x0, lsl #48
    9c08:      	lsr	w0, w0, #0
    9c0c:      	lsr	x16, x0, #0
    9c10:      	cmp	x16, #0x1
    9c14:      	b.eq	0x9c30 <_stogir.terminal.inputs+0x3d0>
    9c18:      	b.lo	0x9c20 <_stogir.terminal.inputs+0x3c0>
    9c1c:      	b	0x9c34 <_stogir.terminal.inputs+0x3d4>
    9c20:      	cmp	x16, #0x0
    9c24:      	b.eq	0x9c2c <_stogir.terminal.inputs+0x3cc>
    9c28:      	b	0x9c34 <_stogir.terminal.inputs+0x3d4>
    9c2c:      	b	0x9c38 <_stogir.terminal.inputs+0x3d8>
    9c30:      	b	0x9c54 <_stogir.terminal.inputs+0x3f4>
    9c34:      	b	0x9cd8 <_stogir.terminal.inputs+0x478>
    9c38:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009c38:  ARM64_RELOC_PAGE21	l_stogir.441
    9c3c:      	ldr	x16, [x16]
		0000000000009c3c:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    9c40:      	orr	x0, x16, xzr
    9c44:      	mov	x1, x0
    9c48:      	mov	x0, #0x1                ; =1
    9c4c:      	mov	x2, #0x1d               ; =29
    9c50:      	b	0x9b64 <_stogir.terminal.inputs+0x304>
    9c54:      	cmp	x3, #0x0
    9c58:      	b.le	0x9b4c <_stogir.terminal.inputs+0x2ec>
    9c5c:      	uxtb	w1, w1
    9c60:      	cmp	x1, #0x83
    9c64:      	b.ge	0x9c98 <_stogir.terminal.inputs+0x438>
    9c68:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009c68:  ARM64_RELOC_PAGE21	l_stogir.438
    9c6c:      	ldr	x16, [x16]
		0000000000009c6c:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    9c70:      	orr	x0, x16, xzr
    9c74:      	add	x0, x1, x0
    9c78:      	ldrb	w0, [x0]
    9c7c:      	b	0x9c9c <_stogir.terminal.inputs+0x43c>
    9c80:      	movz	x2, #0x0, lsl #48
    9c84:      	b	0x9bc4 <_stogir.terminal.inputs+0x364>
    9c88:      	movz	x2, #0x0, lsl #48
    9c8c:      	b	0x9bbc <_stogir.terminal.inputs+0x35c>
    9c90:      	movz	x2, #0x0, lsl #48
    9c94:      	b	0x9c84 <_stogir.terminal.inputs+0x424>
    9c98:      	movz	x0, #0x0, lsl #48
    9c9c:      	uxtb	w0, w0
    9ca0:      	and	x0, x0, #0x8
    9ca4:      	uxtb	w0, w0
    9ca8:      	cmp	x0, #0x0
    9cac:      	cset	w0, eq
    9cb0:      	uxtb	w16, w0
    9cb4:      	cmp	w16, wzr
    9cb8:      	cset	x0, eq
    9cbc:      	cmp	x0, #0x0
    9cc0:      	b.eq	0x9b4c <_stogir.terminal.inputs+0x2ec>
    9cc4:      	and	x0, x3, #0xffffffff
    9cc8:      	mov	x1, x0
    9ccc:      	movz	x0, #0x0, lsl #48
    9cd0:      	movz	x2, #0x0, lsl #48
    9cd4:      	b	0x9b64 <_stogir.terminal.inputs+0x304>
    9cd8:      	brk	#0
    9cdc:      	b	0x9cd8 <_stogir.terminal.inputs+0x478>

0000000000009ce0 <_stogir.switch.switch-inputs>:
    9ce0:      	sxtw	x1, w1
    9ce4:      	cmp	x1, #0x0
    9ce8:      	cset	w3, gt
    9cec:      	movz	x16, #0x0, lsl #48
    9cf0:      	sub	x4, x16, x1
    9cf4:      	sub	x5, x4, #0x1
    9cf8:      	uxtb	w16, w3
    9cfc:      	cmp	w16, wzr
    9d00:      	b.eq	0x9d40 <_stogir.switch.switch-inputs+0x60>
    9d04:      	ldr	x4, [x0, #0x8]
    9d08:      	cmp	x1, x4
    9d0c:      	b.ge	0x9dac <_stogir.switch.switch-inputs+0xcc>
    9d10:      	add	x4, x0, #0x78
    9d14:      	ldr	x4, [x4, #0x8]
    9d18:      	cmp	x1, x4
    9d1c:      	b.ge	0x9e8c <_stogir.switch.switch-inputs+0x1ac>
    9d20:      	ldr	x4, [x0, #0x78]
    9d24:      	add	x4, x4, x1, lsl #2
    9d28:      	ldr	w4, [x4]
    9d2c:      	sxtw	x4, w4
    9d30:      	cmp	x4, #0x0
    9d34:      	cset	w4, ge
    9d38:      	ubfx	x4, x4, #0, #8
    9d3c:      	b	0x9e90 <_stogir.switch.switch-inputs+0x1b0>
    9d40:      	cmp	x1, #0x0
    9d44:      	b.ge	0x9db4 <_stogir.switch.switch-inputs+0xd4>
    9d48:      	add	x6, x0, #0x28
    9d4c:      	add	x7, x0, #0x50
    9d50:      	ldr	x6, [x6, #0x8]
    9d54:      	ldr	x7, [x7, #0x8]
    9d58:      	cmp	x6, x7
    9d5c:      	b.ne	0x9d88 <_stogir.switch.switch-inputs+0xa8>
    9d60:      	cmp	x4, x6
    9d64:      	b.gt	0x9e94 <_stogir.switch.switch-inputs+0x1b4>
    9d68:      	ldr	x4, [x0, #0x50]
    9d6c:      	add	x4, x4, x5, lsl #2
    9d70:      	ldr	w4, [x4]
    9d74:      	sxtw	x4, w4
    9d78:      	cmp	x4, #0x0
    9d7c:      	cset	w4, gt
    9d80:      	ubfx	x4, x4, #0, #8
    9d84:      	b	0x9e98 <_stogir.switch.switch-inputs+0x1b8>
    9d88:      	movz	x4, #0x0, lsl #48
    9d8c:      	b	0x9db8 <_stogir.switch.switch-inputs+0xd8>
    9d90:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009d90:  ARM64_RELOC_PAGE21	l_stogir.442
    9d94:      	ldr	x16, [x16]
		0000000000009d94:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    9d98:      	orr	x0, x16, xzr
    9d9c:      	mov	x1, x0
    9da0:      	mov	x0, #0x1                ; =1
    9da4:      	mov	x2, #0x16               ; =22
    9da8:      	b	0x9e44 <_stogir.switch.switch-inputs+0x164>
    9dac:      	movz	x4, #0x0, lsl #48
    9db0:      	b	0x9db8 <_stogir.switch.switch-inputs+0xd8>
    9db4:      	movz	x4, #0x0, lsl #48
    9db8:      	cmp	x4, #0x0
    9dbc:      	b.eq	0x9df4 <_stogir.switch.switch-inputs+0x114>
    9dc0:      	uxtb	w16, w3
    9dc4:      	cmp	w16, wzr
    9dc8:      	b.eq	0x9ddc <_stogir.switch.switch-inputs+0xfc>
    9dcc:      	ldr	x3, [x0]
    9dd0:      	add	x3, x3, x1, lsl #4
    9dd4:      	ldr	x3, [x3]
    9dd8:      	b	0x9de8 <_stogir.switch.switch-inputs+0x108>
    9ddc:      	ldr	x3, [x0, #0x28]
    9de0:      	add	x3, x3, x5, lsl #4
    9de4:      	ldr	x3, [x3]
    9de8:      	mov	x4, x3
    9dec:      	mov	x3, #0x1                ; =1
    9df0:      	b	0x9dfc <_stogir.switch.switch-inputs+0x11c>
    9df4:      	movz	x3, #0x0, lsl #48
    9df8:      	movz	x4, #0x0, lsl #48
    9dfc:      	lsr	w3, w3, #0
    9e00:      	lsr	x16, x3, #0
    9e04:      	cmp	x16, #0x1
    9e08:      	b.eq	0x9e24 <_stogir.switch.switch-inputs+0x144>
    9e0c:      	b.lo	0x9e14 <_stogir.switch.switch-inputs+0x134>
    9e10:      	b	0x9e28 <_stogir.switch.switch-inputs+0x148>
    9e14:      	cmp	x16, #0x0
    9e18:      	b.eq	0x9e20 <_stogir.switch.switch-inputs+0x140>
    9e1c:      	b	0x9e28 <_stogir.switch.switch-inputs+0x148>
    9e20:      	b	0x9e2c <_stogir.switch.switch-inputs+0x14c>
    9e24:      	b	0x9e54 <_stogir.switch.switch-inputs+0x174>
    9e28:      	b	0xa0ac <_stogir.switch.switch-inputs+0x3cc>
    9e2c:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009e2c:  ARM64_RELOC_PAGE21	l_stogir.443
    9e30:      	ldr	x16, [x16]
		0000000000009e30:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    9e34:      	orr	x0, x16, xzr
    9e38:      	mov	x1, x0
    9e3c:      	mov	x0, #0x1                ; =1
    9e40:      	mov	x2, #0x16               ; =22
    9e44:      	str	x0, [x8]
    9e48:      	str	x1, [x8, #0x8]
    9e4c:      	str	x2, [x8, #0x10]
    9e50:      	ret
    9e54:      	cmp	x1, #0x0
    9e58:      	b.le	0x9d90 <_stogir.switch.switch-inputs+0xb0>
    9e5c:      	uxtb	w4, w4
    9e60:      	cmp	x4, #0x83
    9e64:      	cset	w1, lt
    9e68:      	uxtb	w16, w1
    9e6c:      	cmp	w16, wzr
    9e70:      	b.eq	0x9e9c <_stogir.switch.switch-inputs+0x1bc>
    9e74:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009e74:  ARM64_RELOC_PAGE21	l_stogir.444
    9e78:      	ldr	x16, [x16]
		0000000000009e78:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9e7c:      	orr	x3, x16, xzr
    9e80:      	add	x3, x4, x3
    9e84:      	ldrb	w3, [x3]
    9e88:      	b	0x9ea0 <_stogir.switch.switch-inputs+0x1c0>
    9e8c:      	movz	x4, #0x0, lsl #48
    9e90:      	b	0x9db0 <_stogir.switch.switch-inputs+0xd0>
    9e94:      	movz	x4, #0x0, lsl #48
    9e98:      	b	0x9d8c <_stogir.switch.switch-inputs+0xac>
    9e9c:      	movz	x3, #0x0, lsl #48
    9ea0:      	uxtb	w3, w3
    9ea4:      	and	x3, x3, #0x1
    9ea8:      	uxtb	w3, w3
    9eac:      	cmp	x3, #0x0
    9eb0:      	b.eq	0x9d90 <_stogir.switch.switch-inputs+0xb0>
    9eb4:      	uxtb	w16, w1
    9eb8:      	cmp	w16, wzr
    9ebc:      	b.eq	0x9ed8 <_stogir.switch.switch-inputs+0x1f8>
    9ec0:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009ec0:  ARM64_RELOC_PAGE21	l_stogir.444
    9ec4:      	ldr	x16, [x16]
		0000000000009ec4:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    9ec8:      	orr	x1, x16, xzr
    9ecc:      	add	x1, x4, x1
    9ed0:      	ldrb	w1, [x1]
    9ed4:      	b	0x9edc <_stogir.switch.switch-inputs+0x1fc>
    9ed8:      	movz	x1, #0x0, lsl #48
    9edc:      	uxtb	w1, w1
    9ee0:      	and	x1, x1, #0x4
    9ee4:      	uxtb	w1, w1
    9ee8:      	cmp	x1, #0x0
    9eec:      	cset	w1, eq
    9ef0:      	uxtb	w16, w1
    9ef4:      	cmp	w16, wzr
    9ef8:      	cset	x1, eq
    9efc:      	cmp	x1, #0x0
    9f00:      	b.ne	0x9d90 <_stogir.switch.switch-inputs+0xb0>
    9f04:      	sxtw	x2, w2
    9f08:      	cmp	x2, #0x0
    9f0c:      	cset	w1, gt
    9f10:      	movz	x16, #0x0, lsl #48
    9f14:      	sub	x3, x16, x2
    9f18:      	sub	x4, x3, #0x1
    9f1c:      	uxtb	w16, w1
    9f20:      	cmp	w16, wzr
    9f24:      	b.eq	0x9f80 <_stogir.switch.switch-inputs+0x2a0>
    9f28:      	ldr	x3, [x0, #0x8]
    9f2c:      	cmp	x2, x3
    9f30:      	b.ge	0x9fc8 <_stogir.switch.switch-inputs+0x2e8>
    9f34:      	add	x3, x0, #0x78
    9f38:      	ldr	x3, [x3, #0x8]
    9f3c:      	cmp	x2, x3
    9f40:      	b.ge	0xa0a4 <_stogir.switch.switch-inputs+0x3c4>
    9f44:      	ldr	x3, [x0, #0x78]
    9f48:      	add	x3, x3, x2, lsl #2
    9f4c:      	ldr	w3, [x3]
    9f50:      	sxtw	x3, w3
    9f54:      	cmp	x3, #0x0
    9f58:      	cset	w3, ge
    9f5c:      	ubfx	x3, x3, #0, #8
    9f60:      	b	0xa0a8 <_stogir.switch.switch-inputs+0x3c8>
    9f64:      	adrp	x16, 0x9000 <_stogir.types.size+0x300>
		0000000000009f64:  ARM64_RELOC_PAGE21	l_stogir.445
    9f68:      	ldr	x16, [x16]
		0000000000009f68:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    9f6c:      	orr	x0, x16, xzr
    9f70:      	mov	x1, x0
    9f74:      	mov	x0, #0x1                ; =1
    9f78:      	mov	x2, #0x20               ; =32
    9f7c:      	b	0x9da8 <_stogir.switch.switch-inputs+0xc8>
    9f80:      	cmp	x2, #0x0
    9f84:      	b.ge	0x9fd0 <_stogir.switch.switch-inputs+0x2f0>
    9f88:      	add	x5, x0, #0x28
    9f8c:      	add	x6, x0, #0x50
    9f90:      	ldr	x5, [x5, #0x8]
    9f94:      	ldr	x6, [x6, #0x8]
    9f98:      	cmp	x5, x6
    9f9c:      	b.ne	0xa09c <_stogir.switch.switch-inputs+0x3bc>
    9fa0:      	cmp	x3, x5
    9fa4:      	b.gt	0xa0b4 <_stogir.switch.switch-inputs+0x3d4>
    9fa8:      	ldr	x3, [x0, #0x50]
    9fac:      	add	x3, x3, x4, lsl #2
    9fb0:      	ldr	w3, [x3]
    9fb4:      	sxtw	x3, w3
    9fb8:      	cmp	x3, #0x0
    9fbc:      	cset	w3, gt
    9fc0:      	ubfx	x3, x3, #0, #8
    9fc4:      	b	0xa0b8 <_stogir.switch.switch-inputs+0x3d8>
    9fc8:      	movz	x3, #0x0, lsl #48
    9fcc:      	b	0x9fd4 <_stogir.switch.switch-inputs+0x2f4>
    9fd0:      	movz	x3, #0x0, lsl #48
    9fd4:      	cmp	x3, #0x0
    9fd8:      	b.eq	0xa010 <_stogir.switch.switch-inputs+0x330>
    9fdc:      	uxtb	w16, w1
    9fe0:      	cmp	w16, wzr
    9fe4:      	b.eq	0x9ff8 <_stogir.switch.switch-inputs+0x318>
    9fe8:      	ldr	x0, [x0]
    9fec:      	add	x0, x0, x2, lsl #4
    9ff0:      	ldr	x0, [x0]
    9ff4:      	b	0xa004 <_stogir.switch.switch-inputs+0x324>
    9ff8:      	ldr	x0, [x0, #0x28]
    9ffc:      	add	x0, x0, x4, lsl #4
    a000:      	ldr	x0, [x0]
    a004:      	mov	x1, x0
    a008:      	mov	x0, #0x1                ; =1
    a00c:      	b	0xa018 <_stogir.switch.switch-inputs+0x338>
    a010:      	movz	x0, #0x0, lsl #48
    a014:      	movz	x1, #0x0, lsl #48
    a018:      	lsr	w0, w0, #0
    a01c:      	lsr	x16, x0, #0
    a020:      	cmp	x16, #0x1
    a024:      	b.eq	0xa040 <_stogir.switch.switch-inputs+0x360>
    a028:      	b.lo	0xa030 <_stogir.switch.switch-inputs+0x350>
    a02c:      	b	0xa044 <_stogir.switch.switch-inputs+0x364>
    a030:      	cmp	x16, #0x0
    a034:      	b.eq	0xa03c <_stogir.switch.switch-inputs+0x35c>
    a038:      	b	0xa044 <_stogir.switch.switch-inputs+0x364>
    a03c:      	b	0xa048 <_stogir.switch.switch-inputs+0x368>
    a040:      	b	0xa064 <_stogir.switch.switch-inputs+0x384>
    a044:      	b	0xa0bc <_stogir.switch.switch-inputs+0x3dc>
    a048:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a048:  ARM64_RELOC_PAGE21	l_stogir.446
    a04c:      	ldr	x16, [x16]
		000000000000a04c:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    a050:      	orr	x0, x16, xzr
    a054:      	mov	x1, x0
    a058:      	mov	x0, #0x1                ; =1
    a05c:      	mov	x2, #0x17               ; =23
    a060:      	b	0x9f7c <_stogir.switch.switch-inputs+0x29c>
    a064:      	lsr	w0, w1, #0
    a068:      	ubfx	x0, x0, #8, #8
    a06c:      	cmp	x0, #0x1
    a070:      	b.lt	0x9f64 <_stogir.switch.switch-inputs+0x284>
    a074:      	cmp	x0, #0xb
    a078:      	b.gt	0x9f64 <_stogir.switch.switch-inputs+0x284>
    a07c:      	uxtb	w1, w1
    a080:      	cmp	x1, #0x48
    a084:      	b.eq	0x9f64 <_stogir.switch.switch-inputs+0x284>
    a088:      	and	x0, x0, #0xffffffff
    a08c:      	mov	x1, x0
    a090:      	movz	x0, #0x0, lsl #48
    a094:      	movz	x2, #0x0, lsl #48
    a098:      	b	0x9f7c <_stogir.switch.switch-inputs+0x29c>
    a09c:      	movz	x3, #0x0, lsl #48
    a0a0:      	b	0x9fd4 <_stogir.switch.switch-inputs+0x2f4>
    a0a4:      	movz	x3, #0x0, lsl #48
    a0a8:      	b	0x9fcc <_stogir.switch.switch-inputs+0x2ec>
    a0ac:      	brk	#0
    a0b0:      	b	0xa0ac <_stogir.switch.switch-inputs+0x3cc>
    a0b4:      	movz	x3, #0x0, lsl #48
    a0b8:      	b	0xa0a0 <_stogir.switch.switch-inputs+0x3c0>
    a0bc:      	brk	#0
    a0c0:      	b	0xa0bc <_stogir.switch.switch-inputs+0x3dc>

000000000000a0c4 <_stogir.switch.case-inputs>:
    a0c4:      	sub	sp, sp, #0xb0
    a0c8:      	str	x29, [sp]
    a0cc:      	str	x30, [sp, #0x8]
    a0d0:      	mov	x29, sp
    a0d4:      	str	x19, [sp, #0x70]
    a0d8:      	str	x20, [sp, #0x78]
    a0dc:      	str	x21, [sp, #0x80]
    a0e0:      	str	x22, [sp, #0x88]
    a0e4:      	str	x23, [sp, #0x90]
    a0e8:      	str	x24, [sp, #0x98]
    a0ec:      	str	x25, [sp, #0xa0]
    a0f0:      	str	x26, [sp, #0xa8]
    a0f4:      	sxtw	x2, w2
    a0f8:      	lsl	x5, x2, #2
    a0fc:      	cmp	x2, #0x0
    a100:      	cset	w6, gt
    a104:      	movz	x16, #0x0, lsl #48
    a108:      	sub	x7, x16, x2
    a10c:      	sub	x9, x7, #0x1
    a110:      	uxtb	w16, w6
    a114:      	cmp	w16, wzr
    a118:      	b.eq	0xa158 <_stogir.switch.case-inputs+0x94>
    a11c:      	ldr	x7, [x0, #0x8]
    a120:      	cmp	x2, x7
    a124:      	b.ge	0xa1a8 <_stogir.switch.case-inputs+0xe4>
    a128:      	add	x7, x0, #0x78
    a12c:      	ldr	x7, [x7, #0x8]
    a130:      	cmp	x2, x7
    a134:      	b.ge	0xa2d0 <_stogir.switch.case-inputs+0x20c>
    a138:      	ldr	x7, [x0, #0x78]
    a13c:      	add	x7, x5, x7
    a140:      	ldr	w7, [x7]
    a144:      	sxtw	x7, w7
    a148:      	cmp	x7, #0x0
    a14c:      	cset	w7, ge
    a150:      	ubfx	x7, x7, #0, #8
    a154:      	b	0xa2d4 <_stogir.switch.case-inputs+0x210>
    a158:      	cmp	x2, #0x0
    a15c:      	b.ge	0xa1b0 <_stogir.switch.case-inputs+0xec>
    a160:      	add	x10, x0, #0x28
    a164:      	add	x11, x0, #0x50
    a168:      	ldr	x10, [x10, #0x8]
    a16c:      	ldr	x11, [x11, #0x8]
    a170:      	cmp	x10, x11
    a174:      	b.ne	0xa1a0 <_stogir.switch.case-inputs+0xdc>
    a178:      	cmp	x7, x10
    a17c:      	b.gt	0xa3a4 <_stogir.switch.case-inputs+0x2e0>
    a180:      	ldr	x7, [x0, #0x50]
    a184:      	add	x7, x7, x9, lsl #2
    a188:      	ldr	w7, [x7]
    a18c:      	sxtw	x7, w7
    a190:      	cmp	x7, #0x0
    a194:      	cset	w7, gt
    a198:      	ubfx	x7, x7, #0, #8
    a19c:      	b	0xa3a8 <_stogir.switch.case-inputs+0x2e4>
    a1a0:      	movz	x7, #0x0, lsl #48
    a1a4:      	b	0xa1b4 <_stogir.switch.case-inputs+0xf0>
    a1a8:      	movz	x7, #0x0, lsl #48
    a1ac:      	b	0xa1b4 <_stogir.switch.case-inputs+0xf0>
    a1b0:      	movz	x7, #0x0, lsl #48
    a1b4:      	cmp	x7, #0x0
    a1b8:      	b.eq	0xa214 <_stogir.switch.case-inputs+0x150>
    a1bc:      	uxtb	w16, w6
    a1c0:      	cmp	w16, wzr
    a1c4:      	b.eq	0xa1e8 <_stogir.switch.case-inputs+0x124>
    a1c8:      	ldr	x6, [x0]
    a1cc:      	add	x6, x6, x2, lsl #4
    a1d0:      	ldr	x7, [x6]
    a1d4:      	ldr	x6, [x6, #0x8]
    a1d8:      	fmov	d31, x6
    a1dc:      	mov	x6, x7
    a1e0:      	fmov	x7, d31
    a1e4:      	b	0xa204 <_stogir.switch.case-inputs+0x140>
    a1e8:      	ldr	x6, [x0, #0x28]
    a1ec:      	add	x6, x6, x9, lsl #4
    a1f0:      	ldr	x7, [x6]
    a1f4:      	ldr	x6, [x6, #0x8]
    a1f8:      	fmov	d31, x6
    a1fc:      	mov	x6, x7
    a200:      	fmov	x7, d31
    a204:      	mov	x9, x7
    a208:      	mov	x7, x6
    a20c:      	mov	x6, #0x1                ; =1
    a210:      	b	0xa220 <_stogir.switch.case-inputs+0x15c>
    a214:      	movz	x6, #0x0, lsl #48
    a218:      	movz	x7, #0x0, lsl #48
    a21c:      	movz	x9, #0x0, lsl #48
    a220:      	lsr	w6, w6, #0
    a224:      	lsr	x16, x6, #0
    a228:      	cmp	x16, #0x1
    a22c:      	b.eq	0xa248 <_stogir.switch.case-inputs+0x184>
    a230:      	b.lo	0xa238 <_stogir.switch.case-inputs+0x174>
    a234:      	b	0xa24c <_stogir.switch.case-inputs+0x188>
    a238:      	cmp	x16, #0x0
    a23c:      	b.eq	0xa244 <_stogir.switch.case-inputs+0x180>
    a240:      	b	0xa24c <_stogir.switch.case-inputs+0x188>
    a244:      	b	0xa250 <_stogir.switch.case-inputs+0x18c>
    a248:      	b	0xa2a8 <_stogir.switch.case-inputs+0x1e4>
    a24c:      	b	0xa3ac <_stogir.switch.case-inputs+0x2e8>
    a250:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a250:  ARM64_RELOC_PAGE21	l_stogir.447
    a254:      	ldr	x16, [x16]
		000000000000a254:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    a258:      	orr	x0, x16, xzr
    a25c:      	mov	x21, x8
    a260:      	mov	x1, x0
    a264:      	mov	x0, #0x1                ; =1
    a268:      	mov	x2, #0x1a               ; =26
    a26c:      	str	x0, [x21]
    a270:      	str	x1, [x21, #0x8]
    a274:      	str	x2, [x21, #0x10]
    a278:      	ldr	x19, [sp, #0x70]
    a27c:      	ldr	x20, [sp, #0x78]
    a280:      	ldr	x21, [sp, #0x80]
    a284:      	ldr	x22, [sp, #0x88]
    a288:      	ldr	x23, [sp, #0x90]
    a28c:      	ldr	x24, [sp, #0x98]
    a290:      	ldr	x25, [sp, #0xa0]
    a294:      	ldr	x26, [sp, #0xa8]
    a298:      	ldr	x29, [sp]
    a29c:      	ldr	x30, [sp, #0x8]
    a2a0:      	add	sp, sp, #0xb0
    a2a4:      	ret
    a2a8:      	cmp	x2, #0x0
    a2ac:      	b.gt	0xa2d8 <_stogir.switch.case-inputs+0x214>
    a2b0:      	mov	x21, x8
    a2b4:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a2b4:  ARM64_RELOC_PAGE21	l_stogir.448
    a2b8:      	ldr	x16, [x16]
		000000000000a2b8:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    a2bc:      	orr	x0, x16, xzr
    a2c0:      	mov	x1, x0
    a2c4:      	mov	x0, #0x1                ; =1
    a2c8:      	mov	x2, #0x1f               ; =31
    a2cc:      	b	0xa26c <_stogir.switch.case-inputs+0x1a8>
    a2d0:      	movz	x7, #0x0, lsl #48
    a2d4:      	b	0xa1ac <_stogir.switch.case-inputs+0xe8>
    a2d8:      	uxtb	w2, w7
    a2dc:      	cmp	x2, #0x75
    a2e0:      	b.ne	0xa53c <_stogir.switch.case-inputs+0x478>
    a2e4:      	lsr	w2, w7, #0
    a2e8:      	ubfx	x2, x2, #8, #8
    a2ec:      	cmp	x2, #0x0
    a2f0:      	b.ne	0xa544 <_stogir.switch.case-inputs+0x480>
    a2f4:      	ldr	x2, [x0, #0x78]
    a2f8:      	add	x2, x5, x2
    a2fc:      	ldr	w2, [x2]
    a300:      	sxtw	x2, w2
    a304:      	cmp	x2, #0x2
    a308:      	b.ne	0xa54c <_stogir.switch.case-inputs+0x488>
    a30c:      	sxtw	x19, w1
    a310:      	cmp	x19, #0x6d
    a314:      	b.lt	0xa554 <_stogir.switch.case-inputs+0x490>
    a318:      	cmp	x19, #0x6f
    a31c:      	b.gt	0xa55c <_stogir.switch.case-inputs+0x498>
    a320:      	add	x16, sp, #0x10
    a324:      	orr	x20, x16, xzr
    a328:      	lsr	w9, w9, #0
    a32c:      	lsr	x1, x7, #32
    a330:      	lsr	w9, w9, #0
    a334:      	lsr	w1, w1, #0
    a338:      	mov	w2, w9
    a33c:      	mov	x21, x8
    a340:      	add	x8, sp, #0x10
    a344:      	mov	x22, x0
    a348:      	mov	w23, w3
    a34c:      	mov	w24, w4
    a350:      	bl	0xa350 <_stogir.switch.case-inputs+0x28c>
		000000000000a350:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a354:      	add	x16, sp, #0x10
    a358:      	ldr	w0, [x16]
    a35c:      	lsr	x16, x0, #0
    a360:      	cmp	x16, #0x1
    a364:      	b.eq	0xa380 <_stogir.switch.case-inputs+0x2bc>
    a368:      	b.lo	0xa370 <_stogir.switch.case-inputs+0x2ac>
    a36c:      	b	0xa384 <_stogir.switch.case-inputs+0x2c0>
    a370:      	cmp	x16, #0x0
    a374:      	b.eq	0xa37c <_stogir.switch.case-inputs+0x2b8>
    a378:      	b	0xa384 <_stogir.switch.case-inputs+0x2c0>
    a37c:      	b	0xa3b4 <_stogir.switch.case-inputs+0x2f0>
    a380:      	b	0xa388 <_stogir.switch.case-inputs+0x2c4>
    a384:      	b	0xa524 <_stogir.switch.case-inputs+0x460>
    a388:      	add	x0, x20, #0x8
    a38c:      	add	x16, sp, #0x10
    a390:      	ldr	x1, [x16, #0x8]
    a394:      	ldr	x0, [x0, #0x8]
    a398:      	mov	x2, x0
    a39c:      	mov	x0, #0x1                ; =1
    a3a0:      	b	0xa2cc <_stogir.switch.case-inputs+0x208>
    a3a4:      	movz	x7, #0x0, lsl #48
    a3a8:      	b	0xa1a4 <_stogir.switch.case-inputs+0xe0>
    a3ac:      	brk	#0
    a3b0:      	b	0xa3ac <_stogir.switch.case-inputs+0x2e8>
    a3b4:      	add	x16, sp, #0x10
    a3b8:      	ldr	w20, [x16, #0x8]
    a3bc:      	sxtw	x0, w20
    a3c0:      	and	x25, x0, #0xffffffff
    a3c4:      	cmp	x19, #0x6f
    a3c8:      	b.ne	0xa3dc <_stogir.switch.case-inputs+0x318>
    a3cc:      	mov	x1, x25
    a3d0:      	movz	x0, #0x0, lsl #48
    a3d4:      	movz	x2, #0x0, lsl #48
    a3d8:      	b	0xa3a0 <_stogir.switch.case-inputs+0x2dc>
    a3dc:      	add	x16, sp, #0x30
    a3e0:      	orr	x26, x16, xzr
    a3e4:      	lsr	w23, w23, #0
    a3e8:      	lsr	w20, w20, #0
    a3ec:      	add	x8, sp, #0x30
    a3f0:      	mov	x0, x22
    a3f4:      	mov	w1, w23
    a3f8:      	mov	w2, w20
    a3fc:      	bl	0xa3fc <_stogir.switch.case-inputs+0x338>
		000000000000a3fc:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a400:      	add	x16, sp, #0x30
    a404:      	ldr	w0, [x16]
    a408:      	lsr	x16, x0, #0
    a40c:      	cmp	x16, #0x1
    a410:      	b.eq	0xa42c <_stogir.switch.case-inputs+0x368>
    a414:      	b.lo	0xa41c <_stogir.switch.case-inputs+0x358>
    a418:      	b	0xa430 <_stogir.switch.case-inputs+0x36c>
    a41c:      	cmp	x16, #0x0
    a420:      	b.eq	0xa428 <_stogir.switch.case-inputs+0x364>
    a424:      	b	0xa430 <_stogir.switch.case-inputs+0x36c>
    a428:      	b	0xa450 <_stogir.switch.case-inputs+0x38c>
    a42c:      	b	0xa434 <_stogir.switch.case-inputs+0x370>
    a430:      	b	0xa52c <_stogir.switch.case-inputs+0x468>
    a434:      	add	x0, x26, #0x8
    a438:      	add	x16, sp, #0x30
    a43c:      	ldr	x1, [x16, #0x8]
    a440:      	ldr	x0, [x0, #0x8]
    a444:      	mov	x2, x0
    a448:      	mov	x0, #0x1                ; =1
    a44c:      	b	0xa3d8 <_stogir.switch.case-inputs+0x314>
    a450:      	add	x16, sp, #0x30
    a454:      	ldr	x26, [x16, #0x8]
    a458:      	cmp	x19, #0x6d
    a45c:      	b.ne	0xa47c <_stogir.switch.case-inputs+0x3b8>
    a460:      	sxtw	x23, w23
    a464:      	mov	x0, x23
    a468:      	b	0xa484 <_stogir.switch.case-inputs+0x3c0>
    a46c:      	mov	x1, x25
    a470:      	movz	x0, #0x0, lsl #48
    a474:      	movz	x2, #0x0, lsl #48
    a478:      	b	0xa44c <_stogir.switch.case-inputs+0x388>
    a47c:      	sxtw	x24, w24
    a480:      	mov	x0, x24
    a484:      	add	x16, sp, #0x50
    a488:      	orr	x19, x16, xzr
    a48c:      	lsr	w20, w20, #0
    a490:      	lsr	w0, w0, #0
    a494:      	add	x8, sp, #0x50
    a498:      	mov	w1, w0
    a49c:      	mov	x0, x22
    a4a0:      	mov	w2, w20
    a4a4:      	bl	0xa4a4 <_stogir.switch.case-inputs+0x3e0>
		000000000000a4a4:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    a4a8:      	add	x16, sp, #0x50
    a4ac:      	ldr	w0, [x16]
    a4b0:      	lsr	x16, x0, #0
    a4b4:      	cmp	x16, #0x1
    a4b8:      	b.eq	0xa4d4 <_stogir.switch.case-inputs+0x410>
    a4bc:      	b.lo	0xa4c4 <_stogir.switch.case-inputs+0x400>
    a4c0:      	b	0xa4d8 <_stogir.switch.case-inputs+0x414>
    a4c4:      	cmp	x16, #0x0
    a4c8:      	b.eq	0xa4d0 <_stogir.switch.case-inputs+0x40c>
    a4cc:      	b	0xa4d8 <_stogir.switch.case-inputs+0x414>
    a4d0:      	b	0xa4f8 <_stogir.switch.case-inputs+0x434>
    a4d4:      	b	0xa4dc <_stogir.switch.case-inputs+0x418>
    a4d8:      	b	0xa534 <_stogir.switch.case-inputs+0x470>
    a4dc:      	add	x0, x19, #0x8
    a4e0:      	add	x16, sp, #0x50
    a4e4:      	ldr	x1, [x16, #0x8]
    a4e8:      	ldr	x0, [x0, #0x8]
    a4ec:      	mov	x2, x0
    a4f0:      	mov	x0, #0x1                ; =1
    a4f4:      	b	0xa478 <_stogir.switch.case-inputs+0x3b4>
    a4f8:      	add	x16, sp, #0x50
    a4fc:      	ldr	x0, [x16, #0x8]
    a500:      	cmp	x26, x0
    a504:      	b.ls	0xa46c <_stogir.switch.case-inputs+0x3a8>
    a508:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a508:  ARM64_RELOC_PAGE21	l_stogir.449
    a50c:      	ldr	x16, [x16]
		000000000000a50c:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    a510:      	orr	x0, x16, xzr
    a514:      	mov	x1, x0
    a518:      	mov	x0, #0x1                ; =1
    a51c:      	mov	x2, #0x1a               ; =26
    a520:      	b	0xa478 <_stogir.switch.case-inputs+0x3b4>
    a524:      	brk	#0
    a528:      	b	0xa524 <_stogir.switch.case-inputs+0x460>
    a52c:      	brk	#0
    a530:      	b	0xa52c <_stogir.switch.case-inputs+0x468>
    a534:      	brk	#0
    a538:      	b	0xa534 <_stogir.switch.case-inputs+0x470>
    a53c:      	mov	x21, x8
    a540:      	b	0xa2b4 <_stogir.switch.case-inputs+0x1f0>
    a544:      	mov	x21, x8
    a548:      	b	0xa2b4 <_stogir.switch.case-inputs+0x1f0>
    a54c:      	mov	x21, x8
    a550:      	b	0xa2b4 <_stogir.switch.case-inputs+0x1f0>
    a554:      	mov	x21, x8
    a558:      	b	0xa2b4 <_stogir.switch.case-inputs+0x1f0>
    a55c:      	mov	x21, x8
    a560:      	b	0xa2b4 <_stogir.switch.case-inputs+0x1f0>

000000000000a564 <_stogir.stack.validate-frame-address>:
    a564:      	sxtw	x1, w1
    a568:      	lsl	x2, x1, #2
    a56c:      	cmp	x1, #0x0
    a570:      	cset	w3, gt
    a574:      	movz	x16, #0x0, lsl #48
    a578:      	sub	x4, x16, x1
    a57c:      	sub	x5, x4, #0x1
    a580:      	uxtb	w16, w3
    a584:      	cmp	w16, wzr
    a588:      	b.eq	0xa5c8 <_stogir.stack.validate-frame-address+0x64>
    a58c:      	ldr	x4, [x0, #0x8]
    a590:      	cmp	x1, x4
    a594:      	b.ge	0xa618 <_stogir.stack.validate-frame-address+0xb4>
    a598:      	add	x4, x0, #0x78
    a59c:      	ldr	x4, [x4, #0x8]
    a5a0:      	cmp	x1, x4
    a5a4:      	b.ge	0xa728 <_stogir.stack.validate-frame-address+0x1c4>
    a5a8:      	ldr	x4, [x0, #0x78]
    a5ac:      	add	x4, x2, x4
    a5b0:      	ldr	w4, [x4]
    a5b4:      	sxtw	x4, w4
    a5b8:      	cmp	x4, #0x0
    a5bc:      	cset	w4, ge
    a5c0:      	ubfx	x4, x4, #0, #8
    a5c4:      	b	0xa72c <_stogir.stack.validate-frame-address+0x1c8>
    a5c8:      	cmp	x1, #0x0
    a5cc:      	b.ge	0xa620 <_stogir.stack.validate-frame-address+0xbc>
    a5d0:      	add	x6, x0, #0x28
    a5d4:      	add	x7, x0, #0x50
    a5d8:      	ldr	x6, [x6, #0x8]
    a5dc:      	ldr	x7, [x7, #0x8]
    a5e0:      	cmp	x6, x7
    a5e4:      	b.ne	0xa610 <_stogir.stack.validate-frame-address+0xac>
    a5e8:      	cmp	x4, x6
    a5ec:      	b.gt	0xa730 <_stogir.stack.validate-frame-address+0x1cc>
    a5f0:      	ldr	x4, [x0, #0x50]
    a5f4:      	add	x4, x4, x5, lsl #2
    a5f8:      	ldr	w4, [x4]
    a5fc:      	sxtw	x4, w4
    a600:      	cmp	x4, #0x0
    a604:      	cset	w4, gt
    a608:      	ubfx	x4, x4, #0, #8
    a60c:      	b	0xa734 <_stogir.stack.validate-frame-address+0x1d0>
    a610:      	movz	x4, #0x0, lsl #48
    a614:      	b	0xa624 <_stogir.stack.validate-frame-address+0xc0>
    a618:      	movz	x4, #0x0, lsl #48
    a61c:      	b	0xa624 <_stogir.stack.validate-frame-address+0xc0>
    a620:      	movz	x4, #0x0, lsl #48
    a624:      	cmp	x4, #0x0
    a628:      	b.eq	0xa660 <_stogir.stack.validate-frame-address+0xfc>
    a62c:      	uxtb	w16, w3
    a630:      	cmp	w16, wzr
    a634:      	b.eq	0xa648 <_stogir.stack.validate-frame-address+0xe4>
    a638:      	ldr	x3, [x0]
    a63c:      	add	x3, x3, x1, lsl #4
    a640:      	ldr	x3, [x3]
    a644:      	b	0xa654 <_stogir.stack.validate-frame-address+0xf0>
    a648:      	ldr	x3, [x0, #0x28]
    a64c:      	add	x3, x3, x5, lsl #4
    a650:      	ldr	x3, [x3]
    a654:      	mov	x4, x3
    a658:      	mov	x3, #0x1                ; =1
    a65c:      	b	0xa668 <_stogir.stack.validate-frame-address+0x104>
    a660:      	movz	x3, #0x0, lsl #48
    a664:      	movz	x4, #0x0, lsl #48
    a668:      	lsr	w3, w3, #0
    a66c:      	lsr	x16, x3, #0
    a670:      	cmp	x16, #0x1
    a674:      	b.eq	0xa690 <_stogir.stack.validate-frame-address+0x12c>
    a678:      	b.lo	0xa680 <_stogir.stack.validate-frame-address+0x11c>
    a67c:      	b	0xa694 <_stogir.stack.validate-frame-address+0x130>
    a680:      	cmp	x16, #0x0
    a684:      	b.eq	0xa68c <_stogir.stack.validate-frame-address+0x128>
    a688:      	b	0xa694 <_stogir.stack.validate-frame-address+0x130>
    a68c:      	b	0xa698 <_stogir.stack.validate-frame-address+0x134>
    a690:      	b	0xa6dc <_stogir.stack.validate-frame-address+0x178>
    a694:      	b	0xa738 <_stogir.stack.validate-frame-address+0x1d4>
    a698:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a698:  ARM64_RELOC_PAGE21	l_stogir.450
    a69c:      	ldr	x16, [x16]
		000000000000a69c:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    a6a0:      	orr	x0, x16, xzr
    a6a4:      	mov	x1, x0
    a6a8:      	mov	x0, #0x1                ; =1
    a6ac:      	mov	x2, #0x21               ; =33
    a6b0:      	b	0xa6cc <_stogir.stack.validate-frame-address+0x168>
    a6b4:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000a6b4:  ARM64_RELOC_PAGE21	l_stogir.451
    a6b8:      	ldr	x16, [x16]
		000000000000a6b8:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    a6bc:      	orr	x0, x16, xzr
    a6c0:      	mov	x1, x0
    a6c4:      	mov	x0, #0x1                ; =1
    a6c8:      	mov	x2, #0x1e               ; =30
    a6cc:      	str	x0, [x8]
    a6d0:      	str	x1, [x8, #0x8]
    a6d4:      	str	x2, [x8, #0x10]
    a6d8:      	ret
    a6dc:      	cmp	x1, #0x0
    a6e0:      	b.le	0xa6b4 <_stogir.stack.validate-frame-address+0x150>
    a6e4:      	uxtb	w1, w4
    a6e8:      	cmp	x1, #0x42
    a6ec:      	b.ne	0xa6b4 <_stogir.stack.validate-frame-address+0x150>
    a6f0:      	lsr	w4, w4, #0
    a6f4:      	ubfx	x1, x4, #8, #8
    a6f8:      	cmp	x1, #0x6
    a6fc:      	b.ne	0xa6b4 <_stogir.stack.validate-frame-address+0x150>
    a700:      	ldr	x0, [x0, #0x78]
    a704:      	add	x0, x2, x0
    a708:      	ldr	w0, [x0]
    a70c:      	sxtw	x0, w0
    a710:      	cmp	x0, #0x0
    a714:      	b.ne	0xa6b4 <_stogir.stack.validate-frame-address+0x150>
    a718:      	movz	x0, #0x0, lsl #48
    a71c:      	mov	x1, #0x8                ; =8
    a720:      	movz	x2, #0x0, lsl #48
    a724:      	b	0xa6cc <_stogir.stack.validate-frame-address+0x168>
    a728:      	movz	x4, #0x0, lsl #48
    a72c:      	b	0xa61c <_stogir.stack.validate-frame-address+0xb8>
    a730:      	movz	x4, #0x0, lsl #48
    a734:      	b	0xa614 <_stogir.stack.validate-frame-address+0xb0>
    a738:      	brk	#0
    a73c:      	b	0xa738 <_stogir.stack.validate-frame-address+0x1d4>

000000000000a740 <_stogir.stack.frame-object?>:
    a740:      	ldr	w0, [x0]
    a744:      	uxtb	w1, w0
    a748:      	cmp	x1, #0x51
    a74c:      	b.ne	0xa764 <_stogir.stack.frame-object?+0x24>
    a750:      	ubfx	x0, x0, #16, #16
    a754:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    a758:      	cset	w0, eq
    a75c:      	ubfx	x0, x0, #0, #8
    a760:      	b	0xa768 <_stogir.stack.frame-object?+0x28>
    a764:      	movz	x0, #0x0, lsl #48
    a768:      	ret

000000000000a76c <_stogir.stack.valid-frame-object-inputs?>:
    a76c:      	sub	sp, sp, #0x50
    a770:      	str	x29, [sp]
    a774:      	str	x30, [sp, #0x8]
    a778:      	mov	x29, sp
    a77c:      	str	x19, [sp, #0x30]
    a780:      	str	x20, [sp, #0x38]
    a784:      	str	x21, [sp, #0x40]
    a788:      	add	x3, x0, #0x78
    a78c:      	add	x4, x0, #0x28
    a790:      	add	x5, x0, #0x50
    a794:      	add	x6, x0, #0x78
    a798:      	add	x7, x0, #0x28
    a79c:      	add	x8, x0, #0x50
    a7a0:      	sxtw	x1, w1
    a7a4:      	mov	x9, sp
    a7a8:      	sub	sp, sp, #0x10
    a7ac:      	mov	x10, sp
    a7b0:      	mov	x12, x1
    a7b4:      	mov	x1, #0x1                ; =1
    a7b8:      	movz	x11, #0x0, lsl #48
    a7bc:      	b	0xa904 <_stogir.stack.valid-frame-object-inputs?+0x198>
    a7c0:      	movz	x15, #0x0, lsl #48
    a7c4:      	b	0xa83c <_stogir.stack.valid-frame-object-inputs?+0xd0>
    a7c8:      	movz	x13, #0x0, lsl #48
    a7cc:      	movz	x14, #0x0, lsl #48
    a7d0:      	lsr	w13, w13, #0
    a7d4:      	lsr	x16, x13, #0
    a7d8:      	cmp	x16, #0x1
    a7dc:      	b.eq	0xa7f8 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    a7e0:      	b.lo	0xa7e8 <_stogir.stack.valid-frame-object-inputs?+0x7c>
    a7e4:      	b	0xa7fc <_stogir.stack.valid-frame-object-inputs?+0x90>
    a7e8:      	cmp	x16, #0x0
    a7ec:      	b.eq	0xa7f4 <_stogir.stack.valid-frame-object-inputs?+0x88>
    a7f0:      	b	0xa7fc <_stogir.stack.valid-frame-object-inputs?+0x90>
    a7f4:      	b	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    a7f8:      	b	0xa800 <_stogir.stack.valid-frame-object-inputs?+0x94>
    a7fc:      	b	0xabd4 <_stogir.stack.valid-frame-object-inputs?+0x468>
    a800:      	uxtb	w13, w14
    a804:      	lsr	w14, w14, #0
    a808:      	ubfx	x14, x14, #8, #8
    a80c:      	cmp	x13, x14
    a810:      	b.eq	0xabc0 <_stogir.stack.valid-frame-object-inputs?+0x454>
    a814:      	cmp	x13, #0x49
    a818:      	b.eq	0xabc0 <_stogir.stack.valid-frame-object-inputs?+0x454>
    a81c:      	movz	x1, #0x0, lsl #48
    a820:      	fmov	d31, x11
    a824:      	mov	x11, x12
    a828:      	fmov	x12, d31
    a82c:      	b	0xa9e0 <_stogir.stack.valid-frame-object-inputs?+0x274>
    a830:      	movz	x15, #0x0, lsl #48
    a834:      	b	0xa844 <_stogir.stack.valid-frame-object-inputs?+0xd8>
    a838:      	movz	x15, #0x0, lsl #48
    a83c:      	b	0xa84c <_stogir.stack.valid-frame-object-inputs?+0xe0>
    a840:      	movz	x15, #0x0, lsl #48
    a844:      	b	0xa84c <_stogir.stack.valid-frame-object-inputs?+0xe0>
    a848:      	movz	x15, #0x0, lsl #48
    a84c:      	cmp	x15, #0x0
    a850:      	b.eq	0xa8ac <_stogir.stack.valid-frame-object-inputs?+0x140>
    a854:      	uxtb	w16, w14
    a858:      	cmp	w16, wzr
    a85c:      	b.eq	0xa880 <_stogir.stack.valid-frame-object-inputs?+0x114>
    a860:      	ldr	x14, [x0]
    a864:      	add	x13, x14, x13, lsl #4
    a868:      	ldr	x14, [x13]
    a86c:      	ldr	x13, [x13, #0x8]
    a870:      	fmov	d31, x13
    a874:      	mov	x13, x14
    a878:      	fmov	x14, d31
    a87c:      	b	0xa89c <_stogir.stack.valid-frame-object-inputs?+0x130>
    a880:      	ldr	x13, [x0, #0x28]
    a884:      	add	x13, x13, x19, lsl #4
    a888:      	ldr	x14, [x13]
    a88c:      	ldr	x13, [x13, #0x8]
    a890:      	fmov	d31, x13
    a894:      	mov	x13, x14
    a898:      	fmov	x14, d31
    a89c:      	mov	x15, x14
    a8a0:      	mov	x14, x13
    a8a4:      	mov	x13, #0x1               ; =1
    a8a8:      	b	0xa8b8 <_stogir.stack.valid-frame-object-inputs?+0x14c>
    a8ac:      	movz	x13, #0x0, lsl #48
    a8b0:      	movz	x14, #0x0, lsl #48
    a8b4:      	movz	x15, #0x0, lsl #48
    a8b8:      	lsr	w13, w13, #0
    a8bc:      	lsr	x16, x13, #0
    a8c0:      	cmp	x16, #0x1
    a8c4:      	b.eq	0xa8e0 <_stogir.stack.valid-frame-object-inputs?+0x174>
    a8c8:      	b.lo	0xa8d0 <_stogir.stack.valid-frame-object-inputs?+0x164>
    a8cc:      	b	0xa8e4 <_stogir.stack.valid-frame-object-inputs?+0x178>
    a8d0:      	cmp	x16, #0x0
    a8d4:      	b.eq	0xa8dc <_stogir.stack.valid-frame-object-inputs?+0x170>
    a8d8:      	b	0xa8e4 <_stogir.stack.valid-frame-object-inputs?+0x178>
    a8dc:      	b	0xa8e8 <_stogir.stack.valid-frame-object-inputs?+0x17c>
    a8e0:      	b	0xa9b4 <_stogir.stack.valid-frame-object-inputs?+0x248>
    a8e4:      	b	0xab28 <_stogir.stack.valid-frame-object-inputs?+0x3bc>
    a8e8:      	fmov	d31, x11
    a8ec:      	mov	x11, x12
    a8f0:      	fmov	x12, d31
    a8f4:      	movz	x1, #0x0, lsl #48
    a8f8:      	fmov	d31, x11
    a8fc:      	mov	x11, x12
    a900:      	fmov	x12, d31
    a904:      	cmp	x1, #0x0
    a908:      	b.eq	0xaa6c <_stogir.stack.valid-frame-object-inputs?+0x300>
    a90c:      	cmp	x11, #0x0
    a910:      	b.ne	0xaa6c <_stogir.stack.valid-frame-object-inputs?+0x300>
    a914:      	lsr	w13, w12, #0
    a918:      	sxtw	x13, w13
    a91c:      	cmp	x13, #0x0
    a920:      	cset	w14, gt
    a924:      	movz	x16, #0x0, lsl #48
    a928:      	sub	x15, x16, x13
    a92c:      	sub	x19, x15, #0x1
    a930:      	uxtb	w16, w14
    a934:      	cmp	w16, wzr
    a938:      	b.eq	0xa974 <_stogir.stack.valid-frame-object-inputs?+0x208>
    a93c:      	ldr	x15, [x0, #0x8]
    a940:      	cmp	x13, x15
    a944:      	b.ge	0xa840 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    a948:      	ldr	x15, [x3, #0x8]
    a94c:      	cmp	x13, x15
    a950:      	b.ge	0xa830 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    a954:      	ldr	x15, [x0, #0x78]
    a958:      	add	x15, x15, x13, lsl #2
    a95c:      	ldr	w15, [x15]
    a960:      	sxtw	x15, w15
    a964:      	cmp	x15, #0x0
    a968:      	cset	w15, ge
    a96c:      	ubfx	x15, x15, #0, #8
    a970:      	b	0xa834 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    a974:      	cmp	x13, #0x0
    a978:      	b.ge	0xa848 <_stogir.stack.valid-frame-object-inputs?+0xdc>
    a97c:      	ldr	x20, [x4, #0x8]
    a980:      	ldr	x21, [x5, #0x8]
    a984:      	cmp	x20, x21
    a988:      	b.ne	0xa838 <_stogir.stack.valid-frame-object-inputs?+0xcc>
    a98c:      	cmp	x15, x20
    a990:      	b.gt	0xa7c0 <_stogir.stack.valid-frame-object-inputs?+0x54>
    a994:      	ldr	x15, [x0, #0x50]
    a998:      	add	x15, x15, x19, lsl #2
    a99c:      	ldr	w15, [x15]
    a9a0:      	sxtw	x15, w15
    a9a4:      	cmp	x15, #0x0
    a9a8:      	cset	w15, gt
    a9ac:      	ubfx	x15, x15, #0, #8
    a9b0:      	b	0xa7c4 <_stogir.stack.valid-frame-object-inputs?+0x58>
    a9b4:      	uxtb	w13, w14
    a9b8:      	asr	x19, x14, #32
    a9bc:      	str	x14, [x10]
    a9c0:      	str	x15, [x10, #0x8]
    a9c4:      	cmp	x13, #0x68
    a9c8:      	b.ne	0xa9e4 <_stogir.stack.valid-frame-object-inputs?+0x278>
    a9cc:      	cmp	x19, #0x0
    a9d0:      	cset	w1, eq
    a9d4:      	ubfx	x1, x1, #0, #8
    a9d8:      	mov	x11, x12
    a9dc:      	mov	x12, #0x1               ; =1
    a9e0:      	b	0xa8f8 <_stogir.stack.valid-frame-object-inputs?+0x18c>
    a9e4:      	cmp	x12, #0x0
    a9e8:      	b.le	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    a9ec:      	cmp	x13, #0x51
    a9f0:      	b.ne	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    a9f4:      	cmp	x19, #0x0
    a9f8:      	b.le	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    a9fc:      	cmp	x19, x12
    aa00:      	b.ge	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    aa04:      	lsr	w15, w15, #0
    aa08:      	sxtw	x15, w15
    aa0c:      	cmp	x15, #0x0
    aa10:      	b.ge	0xa81c <_stogir.stack.valid-frame-object-inputs?+0xb0>
    aa14:      	cmp	x15, #0x0
    aa18:      	cset	w13, gt
    aa1c:      	movz	x16, #0x0, lsl #48
    aa20:      	sub	x14, x16, x15
    aa24:      	sub	x19, x14, #0x1
    aa28:      	uxtb	w16, w13
    aa2c:      	cmp	w16, wzr
    aa30:      	b.eq	0xab78 <_stogir.stack.valid-frame-object-inputs?+0x40c>
    aa34:      	ldr	x14, [x0, #0x8]
    aa38:      	cmp	x15, x14
    aa3c:      	b.ge	0xab70 <_stogir.stack.valid-frame-object-inputs?+0x404>
    aa40:      	ldr	x14, [x6, #0x8]
    aa44:      	cmp	x15, x14
    aa48:      	b.ge	0xabb8 <_stogir.stack.valid-frame-object-inputs?+0x44c>
    aa4c:      	ldr	x14, [x0, #0x78]
    aa50:      	add	x14, x14, x15, lsl #2
    aa54:      	ldr	w14, [x14]
    aa58:      	sxtw	x14, w14
    aa5c:      	cmp	x14, #0x0
    aa60:      	cset	w14, ge
    aa64:      	ubfx	x14, x14, #0, #8
    aa68:      	b	0xabbc <_stogir.stack.valid-frame-object-inputs?+0x450>
    aa6c:      	cmp	x1, #0x0
    aa70:      	b.eq	0xaa7c <_stogir.stack.valid-frame-object-inputs?+0x310>
    aa74:      	mov	x1, x11
    aa78:      	b	0xaa80 <_stogir.stack.valid-frame-object-inputs?+0x314>
    aa7c:      	movz	x1, #0x0, lsl #48
    aa80:      	mov	sp, x9
    aa84:      	cmp	x1, #0x0
    aa88:      	b.eq	0xaae4 <_stogir.stack.valid-frame-object-inputs?+0x378>
    aa8c:      	sxtw	x1, w2
    aa90:      	cmp	x1, #0x0
    aa94:      	b.ge	0xab08 <_stogir.stack.valid-frame-object-inputs?+0x39c>
    aa98:      	lsr	w2, w2, #0
    aa9c:      	add	x8, x29, #0x10
    aaa0:      	mov	w1, w2
    aaa4:      	bl	0xaaa4 <_stogir.stack.valid-frame-object-inputs?+0x338>
		000000000000aaa4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    aaa8:      	add	x16, x29, #0x10
    aaac:      	ldr	w0, [x16]
    aab0:      	lsr	x16, x0, #0
    aab4:      	cmp	x16, #0x1
    aab8:      	b.eq	0xaad4 <_stogir.stack.valid-frame-object-inputs?+0x368>
    aabc:      	b.lo	0xaac4 <_stogir.stack.valid-frame-object-inputs?+0x358>
    aac0:      	b	0xaad8 <_stogir.stack.valid-frame-object-inputs?+0x36c>
    aac4:      	cmp	x16, #0x0
    aac8:      	b.eq	0xaad0 <_stogir.stack.valid-frame-object-inputs?+0x364>
    aacc:      	b	0xaad8 <_stogir.stack.valid-frame-object-inputs?+0x36c>
    aad0:      	b	0xab10 <_stogir.stack.valid-frame-object-inputs?+0x3a4>
    aad4:      	b	0xaadc <_stogir.stack.valid-frame-object-inputs?+0x370>
    aad8:      	b	0xabcc <_stogir.stack.valid-frame-object-inputs?+0x460>
    aadc:      	movz	x0, #0x0, lsl #48
    aae0:      	b	0xab24 <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    aae4:      	movz	x0, #0x0, lsl #48
    aae8:      	sub	sp, x29, #0x0
    aaec:      	ldr	x19, [sp, #0x30]
    aaf0:      	ldr	x20, [sp, #0x38]
    aaf4:      	ldr	x21, [sp, #0x40]
    aaf8:      	ldr	x29, [sp]
    aafc:      	ldr	x30, [sp, #0x8]
    ab00:      	add	sp, sp, #0x50
    ab04:      	ret
    ab08:      	movz	x0, #0x0, lsl #48
    ab0c:      	b	0xaae8 <_stogir.stack.valid-frame-object-inputs?+0x37c>
    ab10:      	add	x16, x29, #0x10
    ab14:      	ldr	x0, [x16, #0x8]
    ab18:      	cmp	x0, #0x0
    ab1c:      	cset	w0, gt
    ab20:      	ubfx	x0, x0, #0, #8
    ab24:      	b	0xab0c <_stogir.stack.valid-frame-object-inputs?+0x3a0>
    ab28:      	brk	#0
    ab2c:      	b	0xab28 <_stogir.stack.valid-frame-object-inputs?+0x3bc>
    ab30:      	ldr	x13, [x0, #0x28]
    ab34:      	add	x13, x13, x19, lsl #4
    ab38:      	ldr	x13, [x13]
    ab3c:      	mov	x14, x13
    ab40:      	mov	x13, #0x1               ; =1
    ab44:      	b	0xa7d0 <_stogir.stack.valid-frame-object-inputs?+0x64>
    ab48:      	movz	x14, #0x0, lsl #48
    ab4c:      	cmp	x14, #0x0
    ab50:      	b.eq	0xa7c8 <_stogir.stack.valid-frame-object-inputs?+0x5c>
    ab54:      	uxtb	w16, w13
    ab58:      	cmp	w16, wzr
    ab5c:      	b.eq	0xab30 <_stogir.stack.valid-frame-object-inputs?+0x3c4>
    ab60:      	ldr	x13, [x0]
    ab64:      	add	x13, x13, x15, lsl #4
    ab68:      	ldr	x13, [x13]
    ab6c:      	b	0xab3c <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    ab70:      	movz	x14, #0x0, lsl #48
    ab74:      	b	0xab4c <_stogir.stack.valid-frame-object-inputs?+0x3e0>
    ab78:      	ldr	x20, [x7, #0x8]
    ab7c:      	ldr	x21, [x8, #0x8]
    ab80:      	cmp	x20, x21
    ab84:      	b.ne	0xab48 <_stogir.stack.valid-frame-object-inputs?+0x3dc>
    ab88:      	cmp	x14, x20
    ab8c:      	b.gt	0xabb0 <_stogir.stack.valid-frame-object-inputs?+0x444>
    ab90:      	ldr	x14, [x0, #0x50]
    ab94:      	add	x14, x14, x19, lsl #2
    ab98:      	ldr	w14, [x14]
    ab9c:      	sxtw	x14, w14
    aba0:      	cmp	x14, #0x0
    aba4:      	cset	w14, gt
    aba8:      	ubfx	x14, x14, #0, #8
    abac:      	b	0xabb4 <_stogir.stack.valid-frame-object-inputs?+0x448>
    abb0:      	movz	x14, #0x0, lsl #48
    abb4:      	b	0xab4c <_stogir.stack.valid-frame-object-inputs?+0x3e0>
    abb8:      	movz	x14, #0x0, lsl #48
    abbc:      	b	0xab74 <_stogir.stack.valid-frame-object-inputs?+0x408>
    abc0:      	ldr	w12, [x10, #0x4]
    abc4:      	sxtw	x12, w12
    abc8:      	b	0xa820 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    abcc:      	brk	#0
    abd0:      	b	0xabcc <_stogir.stack.valid-frame-object-inputs?+0x460>
    abd4:      	brk	#0
    abd8:      	b	0xabd4 <_stogir.stack.valid-frame-object-inputs?+0x468>

000000000000abdc <_stogir.stack.validate-scope-inputs>:
    abdc:      	sxtw	x1, w1
    abe0:      	cmp	x1, #0x53
    abe4:      	cset	w5, eq
    abe8:      	uxtb	w16, w5
    abec:      	cmp	w16, wzr
    abf0:      	b.ne	0xac24 <_stogir.stack.validate-scope-inputs+0x48>
    abf4:      	cmp	x1, #0x54
    abf8:      	b.eq	0xac24 <_stogir.stack.validate-scope-inputs+0x48>
    abfc:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000abfc:  ARM64_RELOC_PAGE21	l_stogir.452
    ac00:      	ldr	x16, [x16]
		000000000000ac00:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    ac04:      	orr	x0, x16, xzr
    ac08:      	mov	x1, x0
    ac0c:      	mov	x0, #0x1                ; =1
    ac10:      	mov	x2, #0x22               ; =34
    ac14:      	str	x0, [x8]
    ac18:      	str	x1, [x8, #0x8]
    ac1c:      	str	x2, [x8, #0x10]
    ac20:      	ret
    ac24:      	uxtb	w16, w5
    ac28:      	cmp	w16, wzr
    ac2c:      	mov	x16, #0x6               ; =6
    ac30:      	movz	x17, #0x0, lsl #48
    ac34:      	csel	x1, x16, x17, ne
    ac38:      	sxtw	x2, w2
    ac3c:      	lsr	w1, w1, #0
    ac40:      	sxtw	x1, w1
    ac44:      	cmp	x2, x1
    ac48:      	b.ne	0xabfc <_stogir.stack.validate-scope-inputs+0x20>
    ac4c:      	sxtw	x3, w3
    ac50:      	cmp	x3, #0x0
    ac54:      	cset	w1, gt
    ac58:      	movz	x16, #0x0, lsl #48
    ac5c:      	sub	x2, x16, x3
    ac60:      	sub	x6, x2, #0x1
    ac64:      	uxtb	w16, w1
    ac68:      	cmp	w16, wzr
    ac6c:      	b.eq	0xad48 <_stogir.stack.validate-scope-inputs+0x16c>
    ac70:      	ldr	x2, [x0, #0x8]
    ac74:      	cmp	x3, x2
    ac78:      	b.ge	0xad40 <_stogir.stack.validate-scope-inputs+0x164>
    ac7c:      	add	x2, x0, #0x78
    ac80:      	ldr	x2, [x2, #0x8]
    ac84:      	cmp	x3, x2
    ac88:      	b.ge	0xadec <_stogir.stack.validate-scope-inputs+0x210>
    ac8c:      	ldr	x2, [x0, #0x78]
    ac90:      	add	x2, x2, x3, lsl #2
    ac94:      	ldr	w2, [x2]
    ac98:      	sxtw	x2, w2
    ac9c:      	cmp	x2, #0x0
    aca0:      	cset	w2, ge
    aca4:      	ubfx	x2, x2, #0, #8
    aca8:      	b	0xadf0 <_stogir.stack.validate-scope-inputs+0x214>
    acac:      	movz	x1, #0x0, lsl #48
    acb0:      	movz	x2, #0x0, lsl #48
    acb4:      	lsr	w1, w1, #0
    acb8:      	lsr	x16, x1, #0
    acbc:      	cmp	x16, #0x1
    acc0:      	b.eq	0xacdc <_stogir.stack.validate-scope-inputs+0x100>
    acc4:      	b.lo	0xaccc <_stogir.stack.validate-scope-inputs+0xf0>
    acc8:      	b	0xace0 <_stogir.stack.validate-scope-inputs+0x104>
    accc:      	cmp	x16, #0x0
    acd0:      	b.eq	0xacd8 <_stogir.stack.validate-scope-inputs+0xfc>
    acd4:      	b	0xace0 <_stogir.stack.validate-scope-inputs+0x104>
    acd8:      	b	0xace4 <_stogir.stack.validate-scope-inputs+0x108>
    acdc:      	b	0xad90 <_stogir.stack.validate-scope-inputs+0x1b4>
    ace0:      	b	0xafc4 <_stogir.stack.validate-scope-inputs+0x3e8>
    ace4:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000ace4:  ARM64_RELOC_PAGE21	l_stogir.453
    ace8:      	ldr	x16, [x16]
		000000000000ace8:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    acec:      	orr	x0, x16, xzr
    acf0:      	mov	x1, x0
    acf4:      	mov	x0, #0x1                ; =1
    acf8:      	mov	x2, #0x1b               ; =27
    acfc:      	b	0xac14 <_stogir.stack.validate-scope-inputs+0x38>
    ad00:      	ldr	x1, [x0, #0x28]
    ad04:      	add	x1, x1, x6, lsl #4
    ad08:      	ldr	x1, [x1]
    ad0c:      	mov	x2, x1
    ad10:      	mov	x1, #0x1                ; =1
    ad14:      	b	0xacb4 <_stogir.stack.validate-scope-inputs+0xd8>
    ad18:      	movz	x2, #0x0, lsl #48
    ad1c:      	cmp	x2, #0x0
    ad20:      	b.eq	0xacac <_stogir.stack.validate-scope-inputs+0xd0>
    ad24:      	uxtb	w16, w1
    ad28:      	cmp	w16, wzr
    ad2c:      	b.eq	0xad00 <_stogir.stack.validate-scope-inputs+0x124>
    ad30:      	ldr	x1, [x0]
    ad34:      	add	x1, x1, x3, lsl #4
    ad38:      	ldr	x1, [x1]
    ad3c:      	b	0xad0c <_stogir.stack.validate-scope-inputs+0x130>
    ad40:      	movz	x2, #0x0, lsl #48
    ad44:      	b	0xad1c <_stogir.stack.validate-scope-inputs+0x140>
    ad48:      	cmp	x3, #0x0
    ad4c:      	b.ge	0xad18 <_stogir.stack.validate-scope-inputs+0x13c>
    ad50:      	add	x7, x0, #0x28
    ad54:      	add	x9, x0, #0x50
    ad58:      	ldr	x7, [x7, #0x8]
    ad5c:      	ldr	x9, [x9, #0x8]
    ad60:      	cmp	x7, x9
    ad64:      	b.ne	0xade4 <_stogir.stack.validate-scope-inputs+0x208>
    ad68:      	cmp	x2, x7
    ad6c:      	b.gt	0xadf4 <_stogir.stack.validate-scope-inputs+0x218>
    ad70:      	ldr	x2, [x0, #0x50]
    ad74:      	add	x2, x2, x6, lsl #2
    ad78:      	ldr	w2, [x2]
    ad7c:      	sxtw	x2, w2
    ad80:      	cmp	x2, #0x0
    ad84:      	cset	w2, gt
    ad88:      	ubfx	x2, x2, #0, #8
    ad8c:      	b	0xadf8 <_stogir.stack.validate-scope-inputs+0x21c>
    ad90:      	cmp	x3, #0x0
    ad94:      	b.le	0xadc8 <_stogir.stack.validate-scope-inputs+0x1ec>
    ad98:      	uxtb	w2, w2
    ad9c:      	cmp	x2, #0x83
    ada0:      	cset	w1, lt
    ada4:      	uxtb	w16, w1
    ada8:      	cmp	w16, wzr
    adac:      	b.eq	0xadfc <_stogir.stack.validate-scope-inputs+0x220>
    adb0:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000adb0:  ARM64_RELOC_PAGE21	l_stogir.454
    adb4:      	ldr	x16, [x16]
		000000000000adb4:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    adb8:      	orr	x3, x16, xzr
    adbc:      	add	x3, x2, x3
    adc0:      	ldrb	w3, [x3]
    adc4:      	b	0xae00 <_stogir.stack.validate-scope-inputs+0x224>
    adc8:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000adc8:  ARM64_RELOC_PAGE21	l_stogir.455
    adcc:      	ldr	x16, [x16]
		000000000000adcc:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    add0:      	orr	x0, x16, xzr
    add4:      	mov	x1, x0
    add8:      	mov	x0, #0x1                ; =1
    addc:      	mov	x2, #0x1b               ; =27
    ade0:      	b	0xacfc <_stogir.stack.validate-scope-inputs+0x120>
    ade4:      	movz	x2, #0x0, lsl #48
    ade8:      	b	0xad1c <_stogir.stack.validate-scope-inputs+0x140>
    adec:      	movz	x2, #0x0, lsl #48
    adf0:      	b	0xad44 <_stogir.stack.validate-scope-inputs+0x168>
    adf4:      	movz	x2, #0x0, lsl #48
    adf8:      	b	0xade8 <_stogir.stack.validate-scope-inputs+0x20c>
    adfc:      	movz	x3, #0x0, lsl #48
    ae00:      	uxtb	w3, w3
    ae04:      	and	x3, x3, #0x1
    ae08:      	uxtb	w3, w3
    ae0c:      	cmp	x3, #0x0
    ae10:      	b.eq	0xadc8 <_stogir.stack.validate-scope-inputs+0x1ec>
    ae14:      	uxtb	w16, w1
    ae18:      	cmp	w16, wzr
    ae1c:      	b.eq	0xae38 <_stogir.stack.validate-scope-inputs+0x25c>
    ae20:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000ae20:  ARM64_RELOC_PAGE21	l_stogir.454
    ae24:      	ldr	x16, [x16]
		000000000000ae24:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    ae28:      	orr	x1, x16, xzr
    ae2c:      	add	x1, x2, x1
    ae30:      	ldrb	w1, [x1]
    ae34:      	b	0xae3c <_stogir.stack.validate-scope-inputs+0x260>
    ae38:      	movz	x1, #0x0, lsl #48
    ae3c:      	uxtb	w1, w1
    ae40:      	and	x1, x1, #0x4
    ae44:      	uxtb	w1, w1
    ae48:      	cmp	x1, #0x0
    ae4c:      	cset	w1, eq
    ae50:      	uxtb	w16, w1
    ae54:      	cmp	w16, wzr
    ae58:      	cset	x1, eq
    ae5c:      	cmp	x1, #0x0
    ae60:      	b.ne	0xadc8 <_stogir.stack.validate-scope-inputs+0x1ec>
    ae64:      	uxtb	w16, w5
    ae68:      	cmp	w16, wzr
    ae6c:      	b.eq	0xae80 <_stogir.stack.validate-scope-inputs+0x2a4>
    ae70:      	movz	x0, #0x0, lsl #48
    ae74:      	mov	x1, #0x8                ; =8
    ae78:      	movz	x2, #0x0, lsl #48
    ae7c:      	b	0xade0 <_stogir.stack.validate-scope-inputs+0x204>
    ae80:      	sxtw	x4, w4
    ae84:      	cmp	x4, #0x0
    ae88:      	cset	w1, gt
    ae8c:      	movz	x16, #0x0, lsl #48
    ae90:      	sub	x2, x16, x4
    ae94:      	sub	x3, x2, #0x1
    ae98:      	uxtb	w16, w1
    ae9c:      	cmp	w16, wzr
    aea0:      	b.eq	0xaf7c <_stogir.stack.validate-scope-inputs+0x3a0>
    aea4:      	ldr	x2, [x0, #0x8]
    aea8:      	cmp	x4, x2
    aeac:      	b.ge	0xaf74 <_stogir.stack.validate-scope-inputs+0x398>
    aeb0:      	add	x2, x0, #0x78
    aeb4:      	ldr	x2, [x2, #0x8]
    aeb8:      	cmp	x4, x2
    aebc:      	b.ge	0xb01c <_stogir.stack.validate-scope-inputs+0x440>
    aec0:      	ldr	x2, [x0, #0x78]
    aec4:      	add	x2, x2, x4, lsl #2
    aec8:      	ldr	w2, [x2]
    aecc:      	sxtw	x2, w2
    aed0:      	cmp	x2, #0x0
    aed4:      	cset	w2, ge
    aed8:      	ubfx	x2, x2, #0, #8
    aedc:      	b	0xb020 <_stogir.stack.validate-scope-inputs+0x444>
    aee0:      	movz	x0, #0x0, lsl #48
    aee4:      	movz	x1, #0x0, lsl #48
    aee8:      	lsr	w0, w0, #0
    aeec:      	lsr	x16, x0, #0
    aef0:      	cmp	x16, #0x1
    aef4:      	b.eq	0xaf10 <_stogir.stack.validate-scope-inputs+0x334>
    aef8:      	b.lo	0xaf00 <_stogir.stack.validate-scope-inputs+0x324>
    aefc:      	b	0xaf14 <_stogir.stack.validate-scope-inputs+0x338>
    af00:      	cmp	x16, #0x0
    af04:      	b.eq	0xaf0c <_stogir.stack.validate-scope-inputs+0x330>
    af08:      	b	0xaf14 <_stogir.stack.validate-scope-inputs+0x338>
    af0c:      	b	0xaf18 <_stogir.stack.validate-scope-inputs+0x33c>
    af10:      	b	0xafcc <_stogir.stack.validate-scope-inputs+0x3f0>
    af14:      	b	0xb02c <_stogir.stack.validate-scope-inputs+0x450>
    af18:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000af18:  ARM64_RELOC_PAGE21	l_stogir.456
    af1c:      	ldr	x16, [x16]
		000000000000af1c:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    af20:      	orr	x0, x16, xzr
    af24:      	mov	x1, x0
    af28:      	mov	x0, #0x1                ; =1
    af2c:      	mov	x2, #0x1b               ; =27
    af30:      	b	0xae7c <_stogir.stack.validate-scope-inputs+0x2a0>
    af34:      	ldr	x0, [x0, #0x28]
    af38:      	add	x0, x0, x3, lsl #4
    af3c:      	ldr	x0, [x0]
    af40:      	mov	x1, x0
    af44:      	mov	x0, #0x1                ; =1
    af48:      	b	0xaee8 <_stogir.stack.validate-scope-inputs+0x30c>
    af4c:      	movz	x2, #0x0, lsl #48
    af50:      	cmp	x2, #0x0
    af54:      	b.eq	0xaee0 <_stogir.stack.validate-scope-inputs+0x304>
    af58:      	uxtb	w16, w1
    af5c:      	cmp	w16, wzr
    af60:      	b.eq	0xaf34 <_stogir.stack.validate-scope-inputs+0x358>
    af64:      	ldr	x0, [x0]
    af68:      	add	x0, x0, x4, lsl #4
    af6c:      	ldr	x0, [x0]
    af70:      	b	0xaf40 <_stogir.stack.validate-scope-inputs+0x364>
    af74:      	movz	x2, #0x0, lsl #48
    af78:      	b	0xaf50 <_stogir.stack.validate-scope-inputs+0x374>
    af7c:      	cmp	x4, #0x0
    af80:      	b.ge	0xaf4c <_stogir.stack.validate-scope-inputs+0x370>
    af84:      	add	x5, x0, #0x28
    af88:      	add	x6, x0, #0x50
    af8c:      	ldr	x5, [x5, #0x8]
    af90:      	ldr	x6, [x6, #0x8]
    af94:      	cmp	x5, x6
    af98:      	b.ne	0xb014 <_stogir.stack.validate-scope-inputs+0x438>
    af9c:      	cmp	x2, x5
    afa0:      	b.gt	0xb024 <_stogir.stack.validate-scope-inputs+0x448>
    afa4:      	ldr	x2, [x0, #0x50]
    afa8:      	add	x2, x2, x3, lsl #2
    afac:      	ldr	w2, [x2]
    afb0:      	sxtw	x2, w2
    afb4:      	cmp	x2, #0x0
    afb8:      	cset	w2, gt
    afbc:      	ubfx	x2, x2, #0, #8
    afc0:      	b	0xb028 <_stogir.stack.validate-scope-inputs+0x44c>
    afc4:      	brk	#0
    afc8:      	b	0xafc4 <_stogir.stack.validate-scope-inputs+0x3e8>
    afcc:      	lsr	w0, w1, #0
    afd0:      	ubfx	x0, x0, #8, #8
    afd4:      	cmp	x0, #0x6
    afd8:      	b.ne	0xaff8 <_stogir.stack.validate-scope-inputs+0x41c>
    afdc:      	uxtb	w1, w1
    afe0:      	cmp	x1, #0x48
    afe4:      	b.eq	0xaff8 <_stogir.stack.validate-scope-inputs+0x41c>
    afe8:      	movz	x0, #0x0, lsl #48
    afec:      	mov	x1, #0x8                ; =8
    aff0:      	movz	x2, #0x0, lsl #48
    aff4:      	b	0xb010 <_stogir.stack.validate-scope-inputs+0x434>
    aff8:      	adrp	x16, 0xa000 <_stogir.switch.switch-inputs+0x320>
		000000000000aff8:  ARM64_RELOC_PAGE21	l_stogir.457
    affc:      	ldr	x16, [x16]
		000000000000affc:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b000:      	orr	x0, x16, xzr
    b004:      	mov	x1, x0
    b008:      	mov	x0, #0x1                ; =1
    b00c:      	mov	x2, #0x29               ; =41
    b010:      	b	0xaf30 <_stogir.stack.validate-scope-inputs+0x354>
    b014:      	movz	x2, #0x0, lsl #48
    b018:      	b	0xaf50 <_stogir.stack.validate-scope-inputs+0x374>
    b01c:      	movz	x2, #0x0, lsl #48
    b020:      	b	0xaf78 <_stogir.stack.validate-scope-inputs+0x39c>
    b024:      	movz	x2, #0x0, lsl #48
    b028:      	b	0xb018 <_stogir.stack.validate-scope-inputs+0x43c>
    b02c:      	brk	#0
    b030:      	b	0xb02c <_stogir.stack.validate-scope-inputs+0x450>

000000000000b034 <_stogir.stack.validate-inputs>:
    b034:      	sub	sp, sp, #0x110
    b038:      	str	x29, [sp]
    b03c:      	str	x30, [sp, #0x8]
    b040:      	mov	x29, sp
    b044:      	str	x19, [sp, #0xb8]
    b048:      	str	x20, [sp, #0xc0]
    b04c:      	str	x21, [sp, #0xc8]
    b050:      	str	x22, [sp, #0xd0]
    b054:      	str	x23, [sp, #0xd8]
    b058:      	str	x24, [sp, #0xe0]
    b05c:      	str	x25, [sp, #0xe8]
    b060:      	str	x26, [sp, #0xf0]
    b064:      	str	x27, [sp, #0xf8]
    b068:      	str	x28, [sp, #0x100]
    b06c:      	sxtw	x1, w1
    b070:      	cmp	x1, #0x51
    b074:      	cset	w19, eq
    b078:      	uxtb	w16, w19
    b07c:      	cmp	w16, wzr
    b080:      	b.ne	0xb0f0 <_stogir.stack.validate-inputs+0xbc>
    b084:      	cmp	x1, #0x52
    b088:      	b.eq	0xb0f0 <_stogir.stack.validate-inputs+0xbc>
    b08c:      	str	x8, [sp, #0x90]
    b090:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b090:  ARM64_RELOC_PAGE21	l_stogir.458
    b094:      	ldr	x16, [x16]
		000000000000b094:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b098:      	orr	x0, x16, xzr
    b09c:      	mov	x1, x0
    b0a0:      	mov	x0, #0x1                ; =1
    b0a4:      	mov	x2, #0x29               ; =41
    b0a8:      	ldr	x3, [sp, #0x90]
    b0ac:      	str	x0, [x3]
    b0b0:      	str	x1, [x3, #0x8]
    b0b4:      	str	x2, [x3, #0x10]
    b0b8:      	ldr	x19, [sp, #0xb8]
    b0bc:      	ldr	x20, [sp, #0xc0]
    b0c0:      	ldr	x21, [sp, #0xc8]
    b0c4:      	ldr	x22, [sp, #0xd0]
    b0c8:      	ldr	x23, [sp, #0xd8]
    b0cc:      	ldr	x24, [sp, #0xe0]
    b0d0:      	ldr	x25, [sp, #0xe8]
    b0d4:      	ldr	x26, [sp, #0xf0]
    b0d8:      	ldr	x27, [sp, #0xf8]
    b0dc:      	ldr	x28, [sp, #0x100]
    b0e0:      	ldr	x29, [sp]
    b0e4:      	ldr	x30, [sp, #0x8]
    b0e8:      	add	sp, sp, #0x110
    b0ec:      	ret
    b0f0:      	uxtb	w16, w19
    b0f4:      	cmp	w16, wzr
    b0f8:      	mov	x16, #0x6               ; =6
    b0fc:      	movz	x17, #0x0, lsl #48
    b100:      	csel	x1, x16, x17, ne
    b104:      	sxtw	x2, w2
    b108:      	lsr	w1, w1, #0
    b10c:      	sxtw	x1, w1
    b110:      	cmp	x2, x1
    b114:      	b.ne	0xb674 <_stogir.stack.validate-inputs+0x640>
    b118:      	sxtw	x20, w5
    b11c:      	uxtb	w16, w19
    b120:      	cmp	w16, wzr
    b124:      	b.eq	0xb148 <_stogir.stack.validate-inputs+0x114>
    b128:      	cmp	x20, #0x0
    b12c:      	b.eq	0xb148 <_stogir.stack.validate-inputs+0x114>
    b130:      	cmp	x20, #0x0
    b134:      	b.le	0xb1f0 <_stogir.stack.validate-inputs+0x1bc>
    b138:      	sub	x1, x20, #0x1
    b13c:      	and	x1, x1, x20
    b140:      	cmp	x1, #0x0
    b144:      	b.ne	0xb1f0 <_stogir.stack.validate-inputs+0x1bc>
    b148:      	lsr	w3, w3, #0
    b14c:      	mov	w1, w3
    b150:      	mov	x21, x8
    b154:      	add	x8, sp, #0x10
    b158:      	mov	x22, x0
    b15c:      	mov	w23, w3
    b160:      	mov	w24, w4
    b164:      	bl	0xb164 <_stogir.stack.validate-inputs+0x130>
		000000000000b164:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b168:      	add	x16, sp, #0x10
    b16c:      	ldr	w0, [x16]
    b170:      	lsr	x16, x0, #0
    b174:      	cmp	x16, #0x1
    b178:      	b.eq	0xb194 <_stogir.stack.validate-inputs+0x160>
    b17c:      	b.lo	0xb184 <_stogir.stack.validate-inputs+0x150>
    b180:      	b	0xb198 <_stogir.stack.validate-inputs+0x164>
    b184:      	cmp	x16, #0x0
    b188:      	b.eq	0xb190 <_stogir.stack.validate-inputs+0x15c>
    b18c:      	b	0xb198 <_stogir.stack.validate-inputs+0x164>
    b190:      	b	0xb19c <_stogir.stack.validate-inputs+0x168>
    b194:      	b	0xb1bc <_stogir.stack.validate-inputs+0x188>
    b198:      	b	0xb3ec <_stogir.stack.validate-inputs+0x3b8>
    b19c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b19c:  ARM64_RELOC_PAGE21	l_stogir.459
    b1a0:      	ldr	x16, [x16]
		000000000000b1a0:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    b1a4:      	orr	x0, x16, xzr
    b1a8:      	str	x21, [sp, #0x90]
    b1ac:      	mov	x1, x0
    b1b0:      	mov	x0, #0x1                ; =1
    b1b4:      	mov	x2, #0x1f               ; =31
    b1b8:      	b	0xb0a8 <_stogir.stack.validate-inputs+0x74>
    b1bc:      	sxtw	x23, w23
    b1c0:      	add	x16, sp, #0x10
    b1c4:      	ldr	x0, [x16, #0x8]
    b1c8:      	cmp	x23, #0x0
    b1cc:      	b.gt	0xb1f8 <_stogir.stack.validate-inputs+0x1c4>
    b1d0:      	str	x21, [sp, #0x90]
    b1d4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b1d4:  ARM64_RELOC_PAGE21	l_stogir.460
    b1d8:      	ldr	x16, [x16]
		000000000000b1d8:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    b1dc:      	orr	x0, x16, xzr
    b1e0:      	mov	x1, x0
    b1e4:      	mov	x0, #0x1                ; =1
    b1e8:      	mov	x2, #0x1f               ; =31
    b1ec:      	b	0xb1b8 <_stogir.stack.validate-inputs+0x184>
    b1f0:      	str	x8, [sp, #0x90]
    b1f4:      	b	0xb090 <_stogir.stack.validate-inputs+0x5c>
    b1f8:      	uxtb	w0, w0
    b1fc:      	cmp	x0, #0x83
    b200:      	cset	w1, lt
    b204:      	uxtb	w16, w1
    b208:      	cmp	w16, wzr
    b20c:      	b.eq	0xb228 <_stogir.stack.validate-inputs+0x1f4>
    b210:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b210:  ARM64_RELOC_PAGE21	l_stogir.461
    b214:      	ldr	x16, [x16]
		000000000000b214:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    b218:      	orr	x2, x16, xzr
    b21c:      	add	x2, x0, x2
    b220:      	ldrb	w2, [x2]
    b224:      	b	0xb22c <_stogir.stack.validate-inputs+0x1f8>
    b228:      	movz	x2, #0x0, lsl #48
    b22c:      	uxtb	w2, w2
    b230:      	and	x2, x2, #0x1
    b234:      	uxtb	w2, w2
    b238:      	cmp	x2, #0x0
    b23c:      	b.eq	0xb67c <_stogir.stack.validate-inputs+0x648>
    b240:      	uxtb	w16, w1
    b244:      	cmp	w16, wzr
    b248:      	b.eq	0xb264 <_stogir.stack.validate-inputs+0x230>
    b24c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b24c:  ARM64_RELOC_PAGE21	l_stogir.461
    b250:      	ldr	x16, [x16]
		000000000000b250:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    b254:      	orr	x1, x16, xzr
    b258:      	add	x0, x0, x1
    b25c:      	ldrb	w0, [x0]
    b260:      	b	0xb268 <_stogir.stack.validate-inputs+0x234>
    b264:      	movz	x0, #0x0, lsl #48
    b268:      	uxtb	w0, w0
    b26c:      	and	x0, x0, #0x4
    b270:      	uxtb	w0, w0
    b274:      	cmp	x0, #0x0
    b278:      	cset	w0, eq
    b27c:      	uxtb	w16, w0
    b280:      	cmp	w16, wzr
    b284:      	cset	x0, eq
    b288:      	cmp	x0, #0x0
    b28c:      	b.ne	0xb684 <_stogir.stack.validate-inputs+0x650>
    b290:      	lsr	w24, w24, #0
    b294:      	add	x8, sp, #0x40
    b298:      	mov	x0, x22
    b29c:      	mov	w1, w24
    b2a0:      	bl	0xb2a0 <_stogir.stack.validate-inputs+0x26c>
		000000000000b2a0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b2a4:      	add	x16, sp, #0x40
    b2a8:      	ldr	w0, [x16]
    b2ac:      	lsr	x16, x0, #0
    b2b0:      	cmp	x16, #0x1
    b2b4:      	b.eq	0xb2d0 <_stogir.stack.validate-inputs+0x29c>
    b2b8:      	b.lo	0xb2c0 <_stogir.stack.validate-inputs+0x28c>
    b2bc:      	b	0xb2d4 <_stogir.stack.validate-inputs+0x2a0>
    b2c0:      	cmp	x16, #0x0
    b2c4:      	b.eq	0xb2cc <_stogir.stack.validate-inputs+0x298>
    b2c8:      	b	0xb2d4 <_stogir.stack.validate-inputs+0x2a0>
    b2cc:      	b	0xb2d8 <_stogir.stack.validate-inputs+0x2a4>
    b2d0:      	b	0xb2f8 <_stogir.stack.validate-inputs+0x2c4>
    b2d4:      	b	0xb57c <_stogir.stack.validate-inputs+0x548>
    b2d8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b2d8:  ARM64_RELOC_PAGE21	l_stogir.462
    b2dc:      	ldr	x16, [x16]
		000000000000b2dc:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    b2e0:      	orr	x0, x16, xzr
    b2e4:      	str	x21, [sp, #0x90]
    b2e8:      	mov	x1, x0
    b2ec:      	mov	x0, #0x1                ; =1
    b2f0:      	mov	x2, #0x18               ; =24
    b2f4:      	b	0xb1ec <_stogir.stack.validate-inputs+0x1b8>
    b2f8:      	add	x16, sp, #0x40
    b2fc:      	ldr	x0, [x16, #0x8]
    b300:      	lsr	w1, w0, #0
    b304:      	ubfx	x1, x1, #8, #8
    b308:      	cmp	x1, #0x1
    b30c:      	b.lt	0xb68c <_stogir.stack.validate-inputs+0x658>
    b310:      	cmp	x1, #0xb
    b314:      	b.gt	0xb694 <_stogir.stack.validate-inputs+0x660>
    b318:      	uxtb	w0, w0
    b31c:      	cmp	x0, #0x48
    b320:      	b.eq	0xb69c <_stogir.stack.validate-inputs+0x668>
    b324:      	sxtw	x0, w24
    b328:      	cmp	x1, #0x0
    b32c:      	cset	w23, eq
    b330:      	cmp	x1, #0x1
    b334:      	cset	w25, eq
    b338:      	cmp	x1, #0x2
    b33c:      	cset	w26, eq
    b340:      	cmp	x1, #0x7
    b344:      	cset	w27, eq
    b348:      	cmp	x1, #0x8
    b34c:      	cset	w28, eq
    b350:      	cmp	x1, #0x3
    b354:      	cset	w2, eq
    b358:      	cmp	x1, #0x9
    b35c:      	cset	w3, eq
    b360:      	cmp	x1, #0x4
    b364:      	cset	w4, eq
    b368:      	cmp	x1, #0xa
    b36c:      	cset	w5, eq
    b370:      	cmp	x1, #0xd
    b374:      	cset	w6, eq
    b378:      	cmp	x1, #0x5
    b37c:      	cset	w7, eq
    b380:      	cmp	x1, #0xb
    b384:      	cset	w8, eq
    b388:      	cmp	x1, #0xc
    b38c:      	cset	w9, eq
    b390:      	cmp	x1, #0x6
    b394:      	cset	w1, eq
    b398:      	uxtb	w16, w1
    b39c:      	cmp	w16, wzr
    b3a0:      	mov	x16, #0x8               ; =8
    b3a4:      	movn	x17, #0x0, lsl #48
    b3a8:      	csel	x1, x16, x17, ne
    b3ac:      	cmp	x0, #0x0
    b3b0:      	b.ge	0xb6a4 <_stogir.stack.validate-inputs+0x670>
    b3b4:      	uxtb	w16, w19
    b3b8:      	cmp	w16, wzr
    b3bc:      	b.eq	0xb4e0 <_stogir.stack.validate-inputs+0x4ac>
    b3c0:      	cmp	x20, #0x10
    b3c4:      	b.le	0xb4e0 <_stogir.stack.validate-inputs+0x4ac>
    b3c8:      	mov	x0, x20
    b3cc:      	b	0xb4e4 <_stogir.stack.validate-inputs+0x4b0>
    b3d0:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b3d0:  ARM64_RELOC_PAGE21	l_stogir.463
    b3d4:      	ldr	x16, [x16]
		000000000000b3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    b3d8:      	orr	x0, x16, xzr
    b3dc:      	mov	x1, x0
    b3e0:      	mov	x0, #0x1                ; =1
    b3e4:      	mov	x2, #0x29               ; =41
    b3e8:      	b	0xb2f4 <_stogir.stack.validate-inputs+0x2c0>
    b3ec:      	brk	#0
    b3f0:      	b	0xb3ec <_stogir.stack.validate-inputs+0x3b8>
    b3f4:      	mov	x0, #0x1                ; =1
    b3f8:      	lsr	w0, w0, #0
    b3fc:      	sxtw	x0, w0
    b400:      	and	x0, x0, #0xffffffff
    b404:      	mov	x1, x0
    b408:      	movz	x0, #0x0, lsl #48
    b40c:      	movz	x2, #0x0, lsl #48
    b410:      	b	0xb3e8 <_stogir.stack.validate-inputs+0x3b4>
    b414:      	uxtb	w16, w23
    b418:      	cmp	w16, wzr
    b41c:      	b.eq	0xb448 <_stogir.stack.validate-inputs+0x414>
    b420:      	movz	x0, #0x0, lsl #48
    b424:      	b	0xb3f8 <_stogir.stack.validate-inputs+0x3c4>
    b428:      	mov	x0, #0x1                ; =1
    b42c:      	lsr	w0, w0, #0
    b430:      	sxtw	x0, w0
    b434:      	and	x0, x0, #0xffffffff
    b438:      	mov	x1, x0
    b43c:      	movz	x0, #0x0, lsl #48
    b440:      	movz	x2, #0x0, lsl #48
    b444:      	b	0xb410 <_stogir.stack.validate-inputs+0x3dc>
    b448:      	uxtb	w16, w25
    b44c:      	cmp	w16, wzr
    b450:      	b.ne	0xb3f4 <_stogir.stack.validate-inputs+0x3c0>
    b454:      	uxtb	w16, w26
    b458:      	cmp	w16, wzr
    b45c:      	b.ne	0xb3f4 <_stogir.stack.validate-inputs+0x3c0>
    b460:      	uxtb	w16, w27
    b464:      	cmp	w16, wzr
    b468:      	b.ne	0xb3f4 <_stogir.stack.validate-inputs+0x3c0>
    b46c:      	uxtb	w16, w28
    b470:      	cmp	w16, wzr
    b474:      	b.ne	0xb3f4 <_stogir.stack.validate-inputs+0x3c0>
    b478:      	uxtb	w16, w19
    b47c:      	cmp	w16, wzr
    b480:      	b.ne	0xb63c <_stogir.stack.validate-inputs+0x608>
    b484:      	uxtb	w16, w20
    b488:      	cmp	w16, wzr
    b48c:      	b.ne	0xb63c <_stogir.stack.validate-inputs+0x608>
    b490:      	uxtb	w16, w22
    b494:      	cmp	w16, wzr
    b498:      	b.ne	0xb654 <_stogir.stack.validate-inputs+0x620>
    b49c:      	uxtb	w16, w24
    b4a0:      	cmp	w16, wzr
    b4a4:      	b.ne	0xb654 <_stogir.stack.validate-inputs+0x620>
    b4a8:      	uxtb	w16, w21
    b4ac:      	cmp	w16, wzr
    b4b0:      	b.ne	0xb654 <_stogir.stack.validate-inputs+0x620>
    b4b4:      	uxtb	w16, w0
    b4b8:      	cmp	w16, wzr
    b4bc:      	b.ne	0xb664 <_stogir.stack.validate-inputs+0x630>
    b4c0:      	uxtb	w16, w1
    b4c4:      	cmp	w16, wzr
    b4c8:      	b.ne	0xb664 <_stogir.stack.validate-inputs+0x630>
    b4cc:      	uxtb	w16, w2
    b4d0:      	cmp	w16, wzr
    b4d4:      	b.ne	0xb664 <_stogir.stack.validate-inputs+0x630>
    b4d8:      	ldr	x0, [sp, #0xb0]
    b4dc:      	b	0xb668 <_stogir.stack.validate-inputs+0x634>
    b4e0:      	mov	x0, #0x10               ; =16
    b4e4:      	lsr	w24, w24, #0
    b4e8:      	mov	w19, w2
    b4ec:      	mov	x2, x0
    b4f0:      	mov	x0, x22
    b4f4:      	mov	w20, w3
    b4f8:      	mov	w22, w4
    b4fc:      	str	w7, [sp, #0x98]
    b500:      	str	w8, [sp, #0xa0]
    b504:      	add	x8, sp, #0x70
    b508:      	str	w9, [sp, #0xa8]
    b50c:      	str	x1, [sp, #0xb0]
    b510:      	mov	w1, w24
    b514:      	mov	w24, w5
    b518:      	str	x21, [sp, #0x90]
    b51c:      	mov	w21, w6
    b520:      	bl	0xb520 <_stogir.stack.validate-inputs+0x4ec>
		000000000000b520:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    b524:      	add	x16, sp, #0x70
    b528:      	ldr	w0, [x16]
    b52c:      	lsr	x16, x0, #0
    b530:      	cmp	x16, #0x1
    b534:      	b.eq	0xb550 <_stogir.stack.validate-inputs+0x51c>
    b538:      	b.lo	0xb540 <_stogir.stack.validate-inputs+0x50c>
    b53c:      	b	0xb554 <_stogir.stack.validate-inputs+0x520>
    b540:      	cmp	x16, #0x0
    b544:      	b.eq	0xb54c <_stogir.stack.validate-inputs+0x518>
    b548:      	b	0xb554 <_stogir.stack.validate-inputs+0x520>
    b54c:      	b	0xb584 <_stogir.stack.validate-inputs+0x550>
    b550:      	b	0xb558 <_stogir.stack.validate-inputs+0x524>
    b554:      	b	0xb64c <_stogir.stack.validate-inputs+0x618>
    b558:      	add	x16, sp, #0x70
    b55c:      	orr	x0, x16, xzr
    b560:      	add	x0, x0, #0x8
    b564:      	add	x16, sp, #0x70
    b568:      	ldr	x1, [x16, #0x8]
    b56c:      	ldr	x0, [x0, #0x8]
    b570:      	mov	x2, x0
    b574:      	mov	x0, #0x1                ; =1
    b578:      	b	0xb444 <_stogir.stack.validate-inputs+0x410>
    b57c:      	brk	#0
    b580:      	b	0xb57c <_stogir.stack.validate-inputs+0x548>
    b584:      	uxtb	w16, w23
    b588:      	cmp	w16, wzr
    b58c:      	b.eq	0xb598 <_stogir.stack.validate-inputs+0x564>
    b590:      	movz	x0, #0x0, lsl #48
    b594:      	b	0xb42c <_stogir.stack.validate-inputs+0x3f8>
    b598:      	uxtb	w16, w25
    b59c:      	cmp	w16, wzr
    b5a0:      	b.ne	0xb428 <_stogir.stack.validate-inputs+0x3f4>
    b5a4:      	uxtb	w16, w26
    b5a8:      	cmp	w16, wzr
    b5ac:      	b.ne	0xb428 <_stogir.stack.validate-inputs+0x3f4>
    b5b0:      	uxtb	w16, w27
    b5b4:      	cmp	w16, wzr
    b5b8:      	b.ne	0xb428 <_stogir.stack.validate-inputs+0x3f4>
    b5bc:      	uxtb	w16, w28
    b5c0:      	cmp	w16, wzr
    b5c4:      	b.ne	0xb428 <_stogir.stack.validate-inputs+0x3f4>
    b5c8:      	uxtb	w16, w19
    b5cc:      	cmp	w16, wzr
    b5d0:      	b.ne	0xb644 <_stogir.stack.validate-inputs+0x610>
    b5d4:      	uxtb	w16, w20
    b5d8:      	cmp	w16, wzr
    b5dc:      	b.ne	0xb644 <_stogir.stack.validate-inputs+0x610>
    b5e0:      	uxtb	w16, w22
    b5e4:      	cmp	w16, wzr
    b5e8:      	b.ne	0xb65c <_stogir.stack.validate-inputs+0x628>
    b5ec:      	uxtb	w16, w24
    b5f0:      	cmp	w16, wzr
    b5f4:      	b.ne	0xb65c <_stogir.stack.validate-inputs+0x628>
    b5f8:      	uxtb	w16, w21
    b5fc:      	cmp	w16, wzr
    b600:      	b.ne	0xb65c <_stogir.stack.validate-inputs+0x628>
    b604:      	ldr	w0, [sp, #0x98]
    b608:      	uxtb	w16, w0
    b60c:      	cmp	w16, wzr
    b610:      	b.ne	0xb66c <_stogir.stack.validate-inputs+0x638>
    b614:      	ldr	w1, [sp, #0xa0]
    b618:      	uxtb	w16, w1
    b61c:      	cmp	w16, wzr
    b620:      	b.ne	0xb66c <_stogir.stack.validate-inputs+0x638>
    b624:      	ldr	w2, [sp, #0xa8]
    b628:      	uxtb	w16, w2
    b62c:      	cmp	w16, wzr
    b630:      	b.ne	0xb66c <_stogir.stack.validate-inputs+0x638>
    b634:      	ldr	x0, [sp, #0xb0]
    b638:      	b	0xb670 <_stogir.stack.validate-inputs+0x63c>
    b63c:      	mov	x0, #0x2                ; =2
    b640:      	b	0xb3f8 <_stogir.stack.validate-inputs+0x3c4>
    b644:      	mov	x0, #0x2                ; =2
    b648:      	b	0xb42c <_stogir.stack.validate-inputs+0x3f8>
    b64c:      	brk	#0
    b650:      	b	0xb64c <_stogir.stack.validate-inputs+0x618>
    b654:      	mov	x0, #0x4                ; =4
    b658:      	b	0xb640 <_stogir.stack.validate-inputs+0x60c>
    b65c:      	mov	x0, #0x4                ; =4
    b660:      	b	0xb648 <_stogir.stack.validate-inputs+0x614>
    b664:      	mov	x0, #0x8                ; =8
    b668:      	b	0xb658 <_stogir.stack.validate-inputs+0x624>
    b66c:      	mov	x0, #0x8                ; =8
    b670:      	b	0xb660 <_stogir.stack.validate-inputs+0x62c>
    b674:      	str	x8, [sp, #0x90]
    b678:      	b	0xb090 <_stogir.stack.validate-inputs+0x5c>
    b67c:      	str	x21, [sp, #0x90]
    b680:      	b	0xb1d4 <_stogir.stack.validate-inputs+0x1a0>
    b684:      	str	x21, [sp, #0x90]
    b688:      	b	0xb1d4 <_stogir.stack.validate-inputs+0x1a0>
    b68c:      	str	x21, [sp, #0x90]
    b690:      	b	0xb3d0 <_stogir.stack.validate-inputs+0x39c>
    b694:      	str	x21, [sp, #0x90]
    b698:      	b	0xb3d0 <_stogir.stack.validate-inputs+0x39c>
    b69c:      	str	x21, [sp, #0x90]
    b6a0:      	b	0xb3d0 <_stogir.stack.validate-inputs+0x39c>
    b6a4:      	str	x21, [sp, #0x90]
    b6a8:      	str	x1, [sp, #0xb0]
    b6ac:      	mov	w19, w2
    b6b0:      	mov	w20, w3
    b6b4:      	mov	w22, w4
    b6b8:      	mov	w24, w5
    b6bc:      	mov	w21, w6
    b6c0:      	mov	w0, w7
    b6c4:      	mov	w1, w8
    b6c8:      	mov	w2, w9
    b6cc:      	b	0xb414 <_stogir.stack.validate-inputs+0x3e0>

000000000000b6d0 <_stogir.locals.shape>:
    b6d0:      	sub	sp, sp, #0x40
    b6d4:      	str	x29, [sp]
    b6d8:      	str	x30, [sp, #0x8]
    b6dc:      	mov	x29, sp
    b6e0:      	str	x19, [sp, #0x20]
    b6e4:      	str	x20, [sp, #0x28]
    b6e8:      	str	x21, [sp, #0x30]
    b6ec:      	str	x22, [sp, #0x38]
    b6f0:      	sxtw	x19, w1
    b6f4:      	lsl	x20, x19, #2
    b6f8:      	cmp	x19, #0x0
    b6fc:      	cset	w1, gt
    b700:      	movz	x16, #0x0, lsl #48
    b704:      	sub	x3, x16, x19
    b708:      	sub	x4, x3, #0x1
    b70c:      	uxtb	w16, w1
    b710:      	cmp	w16, wzr
    b714:      	b.eq	0xb754 <_stogir.locals.shape+0x84>
    b718:      	ldr	x3, [x0, #0x8]
    b71c:      	cmp	x19, x3
    b720:      	b.ge	0xb7c0 <_stogir.locals.shape+0xf0>
    b724:      	add	x3, x0, #0x78
    b728:      	ldr	x3, [x3, #0x8]
    b72c:      	cmp	x19, x3
    b730:      	b.ge	0xb984 <_stogir.locals.shape+0x2b4>
    b734:      	ldr	x3, [x0, #0x78]
    b738:      	add	x3, x20, x3
    b73c:      	ldr	w3, [x3]
    b740:      	sxtw	x3, w3
    b744:      	cmp	x3, #0x0
    b748:      	cset	w3, ge
    b74c:      	ubfx	x3, x3, #0, #8
    b750:      	b	0xb988 <_stogir.locals.shape+0x2b8>
    b754:      	cmp	x19, #0x0
    b758:      	b.ge	0xb7c8 <_stogir.locals.shape+0xf8>
    b75c:      	add	x5, x0, #0x28
    b760:      	add	x6, x0, #0x50
    b764:      	ldr	x5, [x5, #0x8]
    b768:      	ldr	x6, [x6, #0x8]
    b76c:      	cmp	x5, x6
    b770:      	b.ne	0xb79c <_stogir.locals.shape+0xcc>
    b774:      	cmp	x3, x5
    b778:      	b.gt	0xba54 <_stogir.locals.shape+0x384>
    b77c:      	ldr	x3, [x0, #0x50]
    b780:      	add	x3, x3, x4, lsl #2
    b784:      	ldr	w3, [x3]
    b788:      	sxtw	x3, w3
    b78c:      	cmp	x3, #0x0
    b790:      	cset	w3, gt
    b794:      	ubfx	x3, x3, #0, #8
    b798:      	b	0xba58 <_stogir.locals.shape+0x388>
    b79c:      	movz	x3, #0x0, lsl #48
    b7a0:      	b	0xb7cc <_stogir.locals.shape+0xfc>
    b7a4:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b7a4:  ARM64_RELOC_PAGE21	l_stogir.464
    b7a8:      	ldr	x16, [x16]
		000000000000b7a8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    b7ac:      	orr	x0, x16, xzr
    b7b0:      	mov	x1, x0
    b7b4:      	mov	x0, #0x1                ; =1
    b7b8:      	mov	x2, #0x1c               ; =28
    b7bc:      	b	0xb884 <_stogir.locals.shape+0x1b4>
    b7c0:      	movz	x3, #0x0, lsl #48
    b7c4:      	b	0xb7cc <_stogir.locals.shape+0xfc>
    b7c8:      	movz	x3, #0x0, lsl #48
    b7cc:      	cmp	x3, #0x0
    b7d0:      	b.eq	0xb82c <_stogir.locals.shape+0x15c>
    b7d4:      	uxtb	w16, w1
    b7d8:      	cmp	w16, wzr
    b7dc:      	b.eq	0xb800 <_stogir.locals.shape+0x130>
    b7e0:      	ldr	x1, [x0]
    b7e4:      	add	x1, x1, x19, lsl #4
    b7e8:      	ldr	x3, [x1]
    b7ec:      	ldr	x1, [x1, #0x8]
    b7f0:      	fmov	d31, x1
    b7f4:      	mov	x1, x3
    b7f8:      	fmov	x3, d31
    b7fc:      	b	0xb81c <_stogir.locals.shape+0x14c>
    b800:      	ldr	x1, [x0, #0x28]
    b804:      	add	x1, x1, x4, lsl #4
    b808:      	ldr	x3, [x1]
    b80c:      	ldr	x1, [x1, #0x8]
    b810:      	fmov	d31, x1
    b814:      	mov	x1, x3
    b818:      	fmov	x3, d31
    b81c:      	mov	x4, x3
    b820:      	mov	x3, x1
    b824:      	mov	x1, #0x1                ; =1
    b828:      	b	0xb838 <_stogir.locals.shape+0x168>
    b82c:      	movz	x1, #0x0, lsl #48
    b830:      	movz	x3, #0x0, lsl #48
    b834:      	movz	x4, #0x0, lsl #48
    b838:      	lsr	w1, w1, #0
    b83c:      	lsr	x16, x1, #0
    b840:      	cmp	x16, #0x1
    b844:      	b.eq	0xb860 <_stogir.locals.shape+0x190>
    b848:      	b.lo	0xb850 <_stogir.locals.shape+0x180>
    b84c:      	b	0xb864 <_stogir.locals.shape+0x194>
    b850:      	cmp	x16, #0x0
    b854:      	b.eq	0xb85c <_stogir.locals.shape+0x18c>
    b858:      	b	0xb864 <_stogir.locals.shape+0x194>
    b85c:      	b	0xb868 <_stogir.locals.shape+0x198>
    b860:      	b	0xb8b0 <_stogir.locals.shape+0x1e0>
    b864:      	b	0xbaa8 <_stogir.locals.shape+0x3d8>
    b868:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000b868:  ARM64_RELOC_PAGE21	l_stogir.465
    b86c:      	ldr	x16, [x16]
		000000000000b86c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    b870:      	orr	x0, x16, xzr
    b874:      	mov	x21, x8
    b878:      	mov	x1, x0
    b87c:      	mov	x0, #0x1                ; =1
    b880:      	mov	x2, #0x16               ; =22
    b884:      	str	x0, [x21]
    b888:      	str	x1, [x21, #0x8]
    b88c:      	str	x2, [x21, #0x10]
    b890:      	ldr	x19, [sp, #0x20]
    b894:      	ldr	x20, [sp, #0x28]
    b898:      	ldr	x21, [sp, #0x30]
    b89c:      	ldr	x22, [sp, #0x38]
    b8a0:      	ldr	x29, [sp]
    b8a4:      	ldr	x30, [sp, #0x8]
    b8a8:      	add	sp, sp, #0x40
    b8ac:      	ret
    b8b0:      	lsr	w2, w2, #0
    b8b4:      	lsr	w1, w3, #0
    b8b8:      	add	x16, sp, #0x10
    b8bc:      	str	x3, [x16]
    b8c0:      	add	x16, sp, #0x10
    b8c4:      	str	x4, [x16, #0x8]
    b8c8:      	ubfx	x1, x1, #8, #8
    b8cc:      	lsr	w1, w1, #0
    b8d0:      	mov	x21, x8
    b8d4:      	mov	x22, x0
    b8d8:      	mov	w0, w1
    b8dc:      	mov	w1, w2
    b8e0:      	bl	0xb8e0 <_stogir.locals.shape+0x210>
		000000000000b8e0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    b8e4:      	lsr	w0, w0, #0
    b8e8:      	add	x16, sp, #0x10
    b8ec:      	ldr	w1, [x16, #0xc]
    b8f0:      	sxtw	x0, w0
    b8f4:      	sxtw	x1, w1
    b8f8:      	cmp	x1, #0x0
    b8fc:      	b.ne	0xb904 <_stogir.locals.shape+0x234>
    b900:      	mov	x1, x0
    b904:      	add	x16, sp, #0x10
    b908:      	ldr	w2, [x16, #0x8]
    b90c:      	sxtw	x2, w2
    b910:      	cmp	x2, #0x0
    b914:      	cset	w3, eq
    b918:      	ubfx	x3, x3, #0, #8
    b91c:      	cmp	x2, #0x0
    b920:      	b.le	0xb98c <_stogir.locals.shape+0x2bc>
    b924:      	add	x4, x22, #0x110
    b928:      	add	x5, x4, #0x28
    b92c:      	ldr	x5, [x5, #0x8]
    b930:      	cmp	x2, x5
    b934:      	b.gt	0xba6c <_stogir.locals.shape+0x39c>
    b938:      	sub	x2, x2, #0x1
    b93c:      	mov	x17, #0x18              ; =24
    b940:      	mul	x2, x2, x17
    b944:      	ldr	x5, [x4, #0x28]
    b948:      	add	x2, x2, x5
    b94c:      	ldr	x5, [x2]
    b950:      	ldr	x2, [x2, #0x8]
    b954:      	ldr	x4, [x4, #0x8]
    b958:      	cmp	x5, #0x0
    b95c:      	b.lt	0xba64 <_stogir.locals.shape+0x394>
    b960:      	cmp	x5, x4
    b964:      	b.gt	0xba64 <_stogir.locals.shape+0x394>
    b968:      	cmp	x2, #0x0
    b96c:      	b.lt	0xba64 <_stogir.locals.shape+0x394>
    b970:      	sub	x4, x4, x5
    b974:      	cmp	x2, x4
    b978:      	b.gt	0xba64 <_stogir.locals.shape+0x394>
    b97c:      	mov	x2, #0x1                ; =1
    b980:      	b	0xba68 <_stogir.locals.shape+0x398>
    b984:      	movz	x3, #0x0, lsl #48
    b988:      	b	0xb7c4 <_stogir.locals.shape+0xf4>
    b98c:      	mov	x2, x3
    b990:      	cmp	x19, #0x0
    b994:      	b.le	0xb7a4 <_stogir.locals.shape+0xd4>
    b998:      	add	x16, sp, #0x10
    b99c:      	ldr	w3, [x16]
    b9a0:      	uxtb	w3, w3
    b9a4:      	cmp	x3, #0x48
    b9a8:      	b.ne	0xb7a4 <_stogir.locals.shape+0xd4>
    b9ac:      	ldr	x3, [x22, #0x78]
    b9b0:      	add	x3, x20, x3
    b9b4:      	ldr	w3, [x3]
    b9b8:      	sxtw	x3, w3
    b9bc:      	cmp	x3, #0x3
    b9c0:      	b.ne	0xb7a4 <_stogir.locals.shape+0xd4>
    b9c4:      	cmp	x0, #0x0
    b9c8:      	b.le	0xb7a4 <_stogir.locals.shape+0xd4>
    b9cc:      	cmp	x2, #0x0
    b9d0:      	b.eq	0xb7a4 <_stogir.locals.shape+0xd4>
    b9d4:      	cmp	x1, #0x0
    b9d8:      	b.le	0xb7a4 <_stogir.locals.shape+0xd4>
    b9dc:      	sub	x2, x1, #0x1
    b9e0:      	and	x2, x2, x1
    b9e4:      	cmp	x2, #0x0
    b9e8:      	b.ne	0xb7a4 <_stogir.locals.shape+0xd4>
    b9ec:      	add	x16, sp, #0x10
    b9f0:      	ldr	w2, [x16, #0x4]
    b9f4:      	sxtw	x2, w2
    b9f8:      	cmp	x2, #0x0
    b9fc:      	cset	w3, gt
    ba00:      	movz	x16, #0x0, lsl #48
    ba04:      	sub	x4, x16, x2
    ba08:      	sub	x5, x4, #0x1
    ba0c:      	uxtb	w16, w3
    ba10:      	cmp	w16, wzr
    ba14:      	b.eq	0xbad4 <_stogir.locals.shape+0x404>
    ba18:      	ldr	x4, [x22, #0x8]
    ba1c:      	cmp	x2, x4
    ba20:      	b.ge	0xbb1c <_stogir.locals.shape+0x44c>
    ba24:      	add	x4, x22, #0x78
    ba28:      	ldr	x4, [x4, #0x8]
    ba2c:      	cmp	x2, x4
    ba30:      	b.ge	0xbbf8 <_stogir.locals.shape+0x528>
    ba34:      	ldr	x4, [x22, #0x78]
    ba38:      	add	x4, x4, x2, lsl #2
    ba3c:      	ldr	w4, [x4]
    ba40:      	sxtw	x4, w4
    ba44:      	cmp	x4, #0x0
    ba48:      	cset	w4, ge
    ba4c:      	ubfx	x4, x4, #0, #8
    ba50:      	b	0xbbfc <_stogir.locals.shape+0x52c>
    ba54:      	movz	x3, #0x0, lsl #48
    ba58:      	b	0xb7a0 <_stogir.locals.shape+0xd0>
    ba5c:      	mov	x2, #0x1                ; =1
    ba60:      	b	0xb990 <_stogir.locals.shape+0x2c0>
    ba64:      	movz	x2, #0x0, lsl #48
    ba68:      	b	0xba70 <_stogir.locals.shape+0x3a0>
    ba6c:      	movz	x2, #0x0, lsl #48
    ba70:      	lsr	w2, w2, #0
    ba74:      	lsr	x16, x2, #0
    ba78:      	cmp	x16, #0x1
    ba7c:      	b.eq	0xba98 <_stogir.locals.shape+0x3c8>
    ba80:      	b.lo	0xba88 <_stogir.locals.shape+0x3b8>
    ba84:      	b	0xba9c <_stogir.locals.shape+0x3cc>
    ba88:      	cmp	x16, #0x0
    ba8c:      	b.eq	0xba94 <_stogir.locals.shape+0x3c4>
    ba90:      	b	0xba9c <_stogir.locals.shape+0x3cc>
    ba94:      	b	0xbaa0 <_stogir.locals.shape+0x3d0>
    ba98:      	b	0xba5c <_stogir.locals.shape+0x38c>
    ba9c:      	b	0xbab0 <_stogir.locals.shape+0x3e0>
    baa0:      	mov	x2, x3
    baa4:      	b	0xba60 <_stogir.locals.shape+0x390>
    baa8:      	brk	#0
    baac:      	b	0xbaa8 <_stogir.locals.shape+0x3d8>
    bab0:      	brk	#0
    bab4:      	b	0xbab0 <_stogir.locals.shape+0x3e0>
    bab8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000bab8:  ARM64_RELOC_PAGE21	l_stogir.466
    babc:      	ldr	x16, [x16]
		000000000000babc:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    bac0:      	orr	x0, x16, xzr
    bac4:      	mov	x1, x0
    bac8:      	mov	x0, #0x1                ; =1
    bacc:      	mov	x2, #0x2c               ; =44
    bad0:      	b	0xb7bc <_stogir.locals.shape+0xec>
    bad4:      	cmp	x2, #0x0
    bad8:      	b.ge	0xbb24 <_stogir.locals.shape+0x454>
    badc:      	add	x6, x22, #0x28
    bae0:      	add	x7, x22, #0x50
    bae4:      	ldr	x6, [x6, #0x8]
    bae8:      	ldr	x7, [x7, #0x8]
    baec:      	cmp	x6, x7
    baf0:      	b.ne	0xbbf0 <_stogir.locals.shape+0x520>
    baf4:      	cmp	x4, x6
    baf8:      	b.gt	0xbc00 <_stogir.locals.shape+0x530>
    bafc:      	ldr	x4, [x22, #0x50]
    bb00:      	add	x4, x4, x5, lsl #2
    bb04:      	ldr	w4, [x4]
    bb08:      	sxtw	x4, w4
    bb0c:      	cmp	x4, #0x0
    bb10:      	cset	w4, gt
    bb14:      	ubfx	x4, x4, #0, #8
    bb18:      	b	0xbc04 <_stogir.locals.shape+0x534>
    bb1c:      	movz	x4, #0x0, lsl #48
    bb20:      	b	0xbb28 <_stogir.locals.shape+0x458>
    bb24:      	movz	x4, #0x0, lsl #48
    bb28:      	cmp	x4, #0x0
    bb2c:      	b.eq	0xbb64 <_stogir.locals.shape+0x494>
    bb30:      	uxtb	w16, w3
    bb34:      	cmp	w16, wzr
    bb38:      	b.eq	0xbb4c <_stogir.locals.shape+0x47c>
    bb3c:      	ldr	x3, [x22]
    bb40:      	add	x2, x3, x2, lsl #4
    bb44:      	ldr	x2, [x2]
    bb48:      	b	0xbb58 <_stogir.locals.shape+0x488>
    bb4c:      	ldr	x2, [x22, #0x28]
    bb50:      	add	x2, x2, x5, lsl #4
    bb54:      	ldr	x2, [x2]
    bb58:      	mov	x3, x2
    bb5c:      	mov	x2, #0x1                ; =1
    bb60:      	b	0xbb6c <_stogir.locals.shape+0x49c>
    bb64:      	movz	x2, #0x0, lsl #48
    bb68:      	movz	x3, #0x0, lsl #48
    bb6c:      	lsr	w2, w2, #0
    bb70:      	lsr	x16, x2, #0
    bb74:      	cmp	x16, #0x1
    bb78:      	b.eq	0xbb94 <_stogir.locals.shape+0x4c4>
    bb7c:      	b.lo	0xbb84 <_stogir.locals.shape+0x4b4>
    bb80:      	b	0xbb98 <_stogir.locals.shape+0x4c8>
    bb84:      	cmp	x16, #0x0
    bb88:      	b.eq	0xbb90 <_stogir.locals.shape+0x4c0>
    bb8c:      	b	0xbb98 <_stogir.locals.shape+0x4c8>
    bb90:      	b	0xbb9c <_stogir.locals.shape+0x4cc>
    bb94:      	b	0xbbb8 <_stogir.locals.shape+0x4e8>
    bb98:      	b	0xbc44 <_stogir.locals.shape+0x574>
    bb9c:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000bb9c:  ARM64_RELOC_PAGE21	l_stogir.467
    bba0:      	ldr	x16, [x16]
		000000000000bba0:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    bba4:      	orr	x0, x16, xzr
    bba8:      	mov	x1, x0
    bbac:      	mov	x0, #0x1                ; =1
    bbb0:      	mov	x2, #0x1d               ; =29
    bbb4:      	b	0xbad0 <_stogir.locals.shape+0x400>
    bbb8:      	add	x16, sp, #0x10
    bbbc:      	ldr	w2, [x16, #0x4]
    bbc0:      	sxtw	x2, w2
    bbc4:      	cmp	x2, #0x0
    bbc8:      	b.le	0xbab8 <_stogir.locals.shape+0x3e8>
    bbcc:      	uxtb	w3, w3
    bbd0:      	cmp	x3, #0x83
    bbd4:      	b.ge	0xbc08 <_stogir.locals.shape+0x538>
    bbd8:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000bbd8:  ARM64_RELOC_PAGE21	l_stogir.468
    bbdc:      	ldr	x16, [x16]
		000000000000bbdc:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    bbe0:      	orr	x2, x16, xzr
    bbe4:      	add	x2, x3, x2
    bbe8:      	ldrb	w2, [x2]
    bbec:      	b	0xbc0c <_stogir.locals.shape+0x53c>
    bbf0:      	movz	x4, #0x0, lsl #48
    bbf4:      	b	0xbb28 <_stogir.locals.shape+0x458>
    bbf8:      	movz	x4, #0x0, lsl #48
    bbfc:      	b	0xbb20 <_stogir.locals.shape+0x450>
    bc00:      	movz	x4, #0x0, lsl #48
    bc04:      	b	0xbbf4 <_stogir.locals.shape+0x524>
    bc08:      	movz	x2, #0x0, lsl #48
    bc0c:      	uxtb	w2, w2
    bc10:      	and	x2, x2, #0x2
    bc14:      	uxtb	w2, w2
    bc18:      	cmp	x2, #0x0
    bc1c:      	cset	w2, eq
    bc20:      	uxtb	w16, w2
    bc24:      	cmp	w16, wzr
    bc28:      	cset	x2, eq
    bc2c:      	cmp	x2, #0x0
    bc30:      	b.eq	0xbab8 <_stogir.locals.shape+0x3e8>
    bc34:      	mov	x2, x1
    bc38:      	mov	x1, x0
    bc3c:      	movz	x0, #0x0, lsl #48
    bc40:      	b	0xbad0 <_stogir.locals.shape+0x400>
    bc44:      	brk	#0
    bc48:      	b	0xbc44 <_stogir.locals.shape+0x574>

000000000000bc4c <_stogir.conversion.policy>:
    bc4c:      	sub	sp, sp, #0x70
    bc50:      	str	x29, [sp]
    bc54:      	str	x30, [sp, #0x8]
    bc58:      	mov	x29, sp
    bc5c:      	str	x19, [sp, #0x20]
    bc60:      	str	x20, [sp, #0x28]
    bc64:      	str	x21, [sp, #0x30]
    bc68:      	str	x22, [sp, #0x38]
    bc6c:      	str	x23, [sp, #0x40]
    bc70:      	str	x24, [sp, #0x48]
    bc74:      	str	x25, [sp, #0x50]
    bc78:      	str	x26, [sp, #0x58]
    bc7c:      	str	x27, [sp, #0x60]
    bc80:      	str	x28, [sp, #0x68]
    bc84:      	sxtw	x19, w0
    bc88:      	sxtw	x20, w1
    bc8c:      	sxtw	x21, w2
    bc90:      	cmp	x19, #0x24
    bc94:      	b.ne	0xbcd8 <_stogir.conversion.policy+0x8c>
    bc98:      	cmp	x20, #0xf
    bc9c:      	b.le	0xbef4 <_stogir.conversion.policy+0x2a8>
    bca0:      	cmp	x20, #0x80
    bca4:      	b.ge	0xbef4 <_stogir.conversion.policy+0x2a8>
    bca8:      	and	x0, x20, #0xf
    bcac:      	lsr	w0, w0, #0
    bcb0:      	sxtw	x0, w0
    bcb4:      	cmp	x0, #0x1
    bcb8:      	b.lt	0xbef4 <_stogir.conversion.policy+0x2a8>
    bcbc:      	cmp	x0, #0xd
    bcc0:      	b.gt	0xbef4 <_stogir.conversion.policy+0x2a8>
    bcc4:      	mov	x0, #0x1                ; =1
    bcc8:      	b	0xbcd0 <_stogir.conversion.policy+0x84>
    bccc:      	movz	x0, #0x0, lsl #48
    bcd0:      	mov	x22, x0
    bcd4:      	b	0xbcdc <_stogir.conversion.policy+0x90>
    bcd8:      	movz	x22, #0x0, lsl #48
    bcdc:      	sxtw	x23, w3
    bce0:      	cmp	x20, #0xd
    bce4:      	cset	w24, eq
    bce8:      	cmp	x20, #0xc
    bcec:      	cset	w25, eq
    bcf0:      	cmp	x23, #0x4
    bcf4:      	cset	w26, eq
    bcf8:      	cmp	x23, #0x8
    bcfc:      	cset	w27, eq
    bd00:      	cmp	x22, #0x0
    bd04:      	b.eq	0xc1dc <_stogir.conversion.policy+0x590>
    bd08:      	lsr	w1, w1, #0
    bd0c:      	lsr	w3, w3, #0
    bd10:      	mov	w0, w1
    bd14:      	mov	w1, w3
    bd18:      	str	x8, [sp, #0x18]
    bd1c:      	mov	w28, w3
    bd20:      	str	x23, [sp, #0x10]
    bd24:      	mov	w23, w2
    bd28:      	bl	0xbd28 <_stogir.conversion.policy+0xdc>
		000000000000bd28:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bd2c:      	lsr	w0, w0, #0
    bd30:      	sxtw	x0, w0
    bd34:      	b	0xbd44 <_stogir.conversion.policy+0xf8>
    bd38:      	mov	x0, #0x1                ; =1
    bd3c:      	lsr	w0, w0, #0
    bd40:      	sxtw	x0, w0
    bd44:      	cmp	x21, #0xd
    bd48:      	cset	w1, eq
    bd4c:      	cmp	x21, #0xc
    bd50:      	cset	w2, eq
    bd54:      	cmp	x22, #0x0
    bd58:      	b.eq	0xc1f0 <_stogir.conversion.policy+0x5a4>
    bd5c:      	lsr	w23, w23, #0
    bd60:      	lsr	w28, w28, #0
    bd64:      	mov	x22, x0
    bd68:      	mov	w0, w23
    bd6c:      	mov	w23, w1
    bd70:      	mov	w1, w28
    bd74:      	mov	w28, w2
    bd78:      	bl	0xbd78 <_stogir.conversion.policy+0x12c>
		000000000000bd78:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bd7c:      	lsr	w0, w0, #0
    bd80:      	sxtw	x0, w0
    bd84:      	b	0xbd94 <_stogir.conversion.policy+0x148>
    bd88:      	mov	x0, #0x1                ; =1
    bd8c:      	lsr	w0, w0, #0
    bd90:      	sxtw	x0, w0
    bd94:      	cmp	x19, #0x21
    bd98:      	b.lt	0xbe74 <_stogir.conversion.policy+0x228>
    bd9c:      	cmp	x19, #0x27
    bda0:      	b.gt	0xbe74 <_stogir.conversion.policy+0x228>
    bda4:      	lsl	x1, x22, #3
    bda8:      	lsr	w1, w1, #0
    bdac:      	sxtw	x1, w1
    bdb0:      	cmp	x1, #0x0
    bdb4:      	b.le	0xbe74 <_stogir.conversion.policy+0x228>
    bdb8:      	lsl	x0, x0, #3
    bdbc:      	lsr	w0, w0, #0
    bdc0:      	sxtw	x0, w0
    bdc4:      	cmp	x0, #0x0
    bdc8:      	b.le	0xbe74 <_stogir.conversion.policy+0x228>
    bdcc:      	cmp	x19, #0x26
    bdd0:      	cset	w2, eq
    bdd4:      	cmp	x20, #0x1
    bdd8:      	cset	w3, ge
    bddc:      	cmp	x20, #0xb
    bde0:      	cset	w4, le
    bde4:      	cmp	x21, #0x1
    bde8:      	cset	w5, ge
    bdec:      	cmp	x21, #0xb
    bdf0:      	cset	w6, le
    bdf4:      	cmp	x19, #0x25
    bdf8:      	b.lt	0xc07c <_stogir.conversion.policy+0x430>
    bdfc:      	ubfx	x23, x23, #0, #8
    be00:      	cmp	x19, #0x25
    be04:      	b.ne	0xc0ec <_stogir.conversion.policy+0x4a0>
    be08:      	uxtb	w16, w3
    be0c:      	cmp	w16, wzr
    be10:      	b.eq	0xc0e4 <_stogir.conversion.policy+0x498>
    be14:      	uxtb	w16, w4
    be18:      	cmp	w16, wzr
    be1c:      	b.eq	0xc0e4 <_stogir.conversion.policy+0x498>
    be20:      	uxtb	w16, w28
    be24:      	cmp	w16, wzr
    be28:      	b.eq	0xc160 <_stogir.conversion.policy+0x514>
    be2c:      	mov	x3, #0x1                ; =1
    be30:      	b	0xc164 <_stogir.conversion.policy+0x518>
    be34:      	uxtb	w16, w26
    be38:      	cmp	w16, wzr
    be3c:      	b.ne	0xbed4 <_stogir.conversion.policy+0x288>
    be40:      	uxtb	w16, w27
    be44:      	cmp	w16, wzr
    be48:      	b.ne	0xbed4 <_stogir.conversion.policy+0x288>
    be4c:      	movn	x0, #0x0, lsl #48
    be50:      	b	0xbd8c <_stogir.conversion.policy+0x140>
    be54:      	uxtb	w16, w26
    be58:      	cmp	w16, wzr
    be5c:      	b.ne	0xbee4 <_stogir.conversion.policy+0x298>
    be60:      	uxtb	w16, w27
    be64:      	cmp	w16, wzr
    be68:      	b.ne	0xbee4 <_stogir.conversion.policy+0x298>
    be6c:      	movn	x0, #0x0, lsl #48
    be70:      	b	0xbd3c <_stogir.conversion.policy+0xf0>
    be74:      	adrp	x16, 0xb000 <_stogir.stack.validate-scope-inputs+0x424>
		000000000000be74:  ARM64_RELOC_PAGE21	l_stogir.469
    be78:      	ldr	x16, [x16]
		000000000000be78:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    be7c:      	orr	x0, x16, xzr
    be80:      	mov	x1, x0
    be84:      	mov	x0, #0x1                ; =1
    be88:      	mov	x2, #0x22               ; =34
    be8c:      	ldr	x3, [sp, #0x18]
    be90:      	str	x0, [x3]
    be94:      	str	x1, [x3, #0x8]
    be98:      	str	x2, [x3, #0x10]
    be9c:      	ldr	x19, [sp, #0x20]
    bea0:      	ldr	x20, [sp, #0x28]
    bea4:      	ldr	x21, [sp, #0x30]
    bea8:      	ldr	x22, [sp, #0x38]
    beac:      	ldr	x23, [sp, #0x40]
    beb0:      	ldr	x24, [sp, #0x48]
    beb4:      	ldr	x25, [sp, #0x50]
    beb8:      	ldr	x26, [sp, #0x58]
    bebc:      	ldr	x27, [sp, #0x60]
    bec0:      	ldr	x28, [sp, #0x68]
    bec4:      	ldr	x29, [sp]
    bec8:      	ldr	x30, [sp, #0x8]
    becc:      	add	sp, sp, #0x70
    bed0:      	ret
    bed4:      	cmp	x21, #0x0
    bed8:      	b.ne	0xbf30 <_stogir.conversion.policy+0x2e4>
    bedc:      	movz	x0, #0x0, lsl #48
    bee0:      	b	0xbd8c <_stogir.conversion.policy+0x140>
    bee4:      	cmp	x20, #0x0
    bee8:      	b.ne	0xbfa8 <_stogir.conversion.policy+0x35c>
    beec:      	movz	x0, #0x0, lsl #48
    bef0:      	b	0xbd3c <_stogir.conversion.policy+0xf0>
    bef4:      	cmp	x21, #0xf
    bef8:      	b.le	0xbccc <_stogir.conversion.policy+0x80>
    befc:      	cmp	x21, #0x80
    bf00:      	b.ge	0xbf28 <_stogir.conversion.policy+0x2dc>
    bf04:      	and	x0, x21, #0xf
    bf08:      	lsr	w0, w0, #0
    bf0c:      	sxtw	x0, w0
    bf10:      	cmp	x0, #0x1
    bf14:      	b.lt	0xc020 <_stogir.conversion.policy+0x3d4>
    bf18:      	cmp	x0, #0xd
    bf1c:      	cset	w0, le
    bf20:      	ubfx	x0, x0, #0, #8
    bf24:      	b	0xc024 <_stogir.conversion.policy+0x3d8>
    bf28:      	movz	x0, #0x0, lsl #48
    bf2c:      	b	0xbcd0 <_stogir.conversion.policy+0x84>
    bf30:      	cmp	x21, #0x1
    bf34:      	b.eq	0xbd88 <_stogir.conversion.policy+0x13c>
    bf38:      	cmp	x21, #0x2
    bf3c:      	b.eq	0xbd88 <_stogir.conversion.policy+0x13c>
    bf40:      	cmp	x21, #0x7
    bf44:      	b.eq	0xbd88 <_stogir.conversion.policy+0x13c>
    bf48:      	cmp	x21, #0x8
    bf4c:      	b.eq	0xbd88 <_stogir.conversion.policy+0x13c>
    bf50:      	cmp	x21, #0x3
    bf54:      	b.eq	0xc118 <_stogir.conversion.policy+0x4cc>
    bf58:      	cmp	x21, #0x9
    bf5c:      	b.eq	0xc118 <_stogir.conversion.policy+0x4cc>
    bf60:      	cmp	x21, #0x4
    bf64:      	b.eq	0xc188 <_stogir.conversion.policy+0x53c>
    bf68:      	cmp	x21, #0xa
    bf6c:      	b.eq	0xc188 <_stogir.conversion.policy+0x53c>
    bf70:      	uxtb	w16, w23
    bf74:      	cmp	w16, wzr
    bf78:      	b.ne	0xc188 <_stogir.conversion.policy+0x53c>
    bf7c:      	cmp	x21, #0x5
    bf80:      	b.eq	0xc1bc <_stogir.conversion.policy+0x570>
    bf84:      	cmp	x21, #0xb
    bf88:      	b.eq	0xc1bc <_stogir.conversion.policy+0x570>
    bf8c:      	uxtb	w16, w28
    bf90:      	cmp	w16, wzr
    bf94:      	b.ne	0xc1bc <_stogir.conversion.policy+0x570>
    bf98:      	cmp	x21, #0x6
    bf9c:      	b.ne	0xc1cc <_stogir.conversion.policy+0x580>
    bfa0:      	ldr	x0, [sp, #0x10]
    bfa4:      	b	0xc1d0 <_stogir.conversion.policy+0x584>
    bfa8:      	cmp	x20, #0x1
    bfac:      	b.eq	0xbd38 <_stogir.conversion.policy+0xec>
    bfb0:      	cmp	x20, #0x2
    bfb4:      	b.eq	0xbd38 <_stogir.conversion.policy+0xec>
    bfb8:      	cmp	x20, #0x7
    bfbc:      	b.eq	0xbd38 <_stogir.conversion.policy+0xec>
    bfc0:      	cmp	x20, #0x8
    bfc4:      	b.eq	0xbd38 <_stogir.conversion.policy+0xec>
    bfc8:      	cmp	x20, #0x3
    bfcc:      	b.eq	0xc120 <_stogir.conversion.policy+0x4d4>
    bfd0:      	cmp	x20, #0x9
    bfd4:      	b.eq	0xc120 <_stogir.conversion.policy+0x4d4>
    bfd8:      	cmp	x20, #0x4
    bfdc:      	b.eq	0xc190 <_stogir.conversion.policy+0x544>
    bfe0:      	cmp	x20, #0xa
    bfe4:      	b.eq	0xc190 <_stogir.conversion.policy+0x544>
    bfe8:      	uxtb	w16, w24
    bfec:      	cmp	w16, wzr
    bff0:      	b.ne	0xc190 <_stogir.conversion.policy+0x544>
    bff4:      	cmp	x20, #0x5
    bff8:      	b.eq	0xc1c4 <_stogir.conversion.policy+0x578>
    bffc:      	cmp	x20, #0xb
    c000:      	b.eq	0xc1c4 <_stogir.conversion.policy+0x578>
    c004:      	uxtb	w16, w25
    c008:      	cmp	w16, wzr
    c00c:      	b.ne	0xc1c4 <_stogir.conversion.policy+0x578>
    c010:      	cmp	x20, #0x6
    c014:      	b.ne	0xc1d4 <_stogir.conversion.policy+0x588>
    c018:      	ldr	x0, [sp, #0x10]
    c01c:      	b	0xc1d8 <_stogir.conversion.policy+0x58c>
    c020:      	movz	x0, #0x0, lsl #48
    c024:      	b	0xbf2c <_stogir.conversion.policy+0x2e0>
    c028:      	mov	x3, #0x1                ; =1
    c02c:      	cmp	x3, #0x0
    c030:      	b.ne	0xbe74 <_stogir.conversion.policy+0x228>
    c034:      	cmp	x19, #0x23
    c038:      	b.eq	0xc04c <_stogir.conversion.policy+0x400>
    c03c:      	uxtb	w16, w2
    c040:      	cmp	w16, wzr
    c044:      	b.ne	0xc04c <_stogir.conversion.policy+0x400>
    c048:      	mov	x0, x1
    c04c:      	and	x0, x0, #0xffffffff
    c050:      	mov	x1, x0
    c054:      	movz	x0, #0x0, lsl #48
    c058:      	movz	x2, #0x0, lsl #48
    c05c:      	b	0xbe8c <_stogir.conversion.policy+0x240>
    c060:      	movz	x3, #0x0, lsl #48
    c064:      	cmp	x3, #0x0
    c068:      	cset	w3, ne
    c06c:      	uxtb	w16, w3
    c070:      	cmp	w16, wzr
    c074:      	cset	x3, eq
    c078:      	b	0xc02c <_stogir.conversion.policy+0x3e0>
    c07c:      	cmp	x19, #0x24
    c080:      	b.ne	0xc09c <_stogir.conversion.policy+0x450>
    c084:      	cmp	x1, x0
    c088:      	cset	w3, eq
    c08c:      	uxtb	w16, w3
    c090:      	cmp	w16, wzr
    c094:      	cset	x3, eq
    c098:      	b	0xc02c <_stogir.conversion.policy+0x3e0>
    c09c:      	uxtb	w16, w3
    c0a0:      	cmp	w16, wzr
    c0a4:      	b.eq	0xc028 <_stogir.conversion.policy+0x3dc>
    c0a8:      	uxtb	w16, w4
    c0ac:      	cmp	w16, wzr
    c0b0:      	b.eq	0xc028 <_stogir.conversion.policy+0x3dc>
    c0b4:      	uxtb	w16, w5
    c0b8:      	cmp	w16, wzr
    c0bc:      	b.eq	0xc158 <_stogir.conversion.policy+0x50c>
    c0c0:      	uxtb	w16, w6
    c0c4:      	cmp	w16, wzr
    c0c8:      	b.eq	0xc158 <_stogir.conversion.policy+0x50c>
    c0cc:      	cmp	x19, #0x23
    c0d0:      	b.ne	0xc1ac <_stogir.conversion.policy+0x560>
    c0d4:      	cmp	x0, x1
    c0d8:      	cset	w3, ge
    c0dc:      	ubfx	x3, x3, #0, #8
    c0e0:      	b	0xc1b8 <_stogir.conversion.policy+0x56c>
    c0e4:      	movz	x3, #0x0, lsl #48
    c0e8:      	b	0xc064 <_stogir.conversion.policy+0x418>
    c0ec:      	uxtb	w16, w2
    c0f0:      	cmp	w16, wzr
    c0f4:      	b.eq	0xc130 <_stogir.conversion.policy+0x4e4>
    c0f8:      	uxtb	w16, w25
    c0fc:      	cmp	w16, wzr
    c100:      	b.ne	0xc170 <_stogir.conversion.policy+0x524>
    c104:      	uxtb	w16, w24
    c108:      	cmp	w16, wzr
    c10c:      	b.ne	0xc170 <_stogir.conversion.policy+0x524>
    c110:      	movz	x3, #0x0, lsl #48
    c114:      	b	0xc12c <_stogir.conversion.policy+0x4e0>
    c118:      	mov	x0, #0x2                ; =2
    c11c:      	b	0xbd8c <_stogir.conversion.policy+0x140>
    c120:      	mov	x0, #0x2                ; =2
    c124:      	b	0xbd3c <_stogir.conversion.policy+0xf0>
    c128:      	movz	x3, #0x0, lsl #48
    c12c:      	b	0xc064 <_stogir.conversion.policy+0x418>
    c130:      	cmp	x19, #0x27
    c134:      	b.ne	0xc060 <_stogir.conversion.policy+0x414>
    c138:      	uxtb	w16, w25
    c13c:      	cmp	w16, wzr
    c140:      	b.ne	0xc198 <_stogir.conversion.policy+0x54c>
    c144:      	uxtb	w16, w24
    c148:      	cmp	w16, wzr
    c14c:      	b.ne	0xc198 <_stogir.conversion.policy+0x54c>
    c150:      	movz	x3, #0x0, lsl #48
    c154:      	b	0xc16c <_stogir.conversion.policy+0x520>
    c158:      	mov	x3, #0x1                ; =1
    c15c:      	b	0xc02c <_stogir.conversion.policy+0x3e0>
    c160:      	mov	x3, x23
    c164:      	b	0xc0e8 <_stogir.conversion.policy+0x49c>
    c168:      	mov	x3, x23
    c16c:      	b	0xc064 <_stogir.conversion.policy+0x418>
    c170:      	uxtb	w16, w5
    c174:      	cmp	w16, wzr
    c178:      	b.eq	0xc128 <_stogir.conversion.policy+0x4dc>
    c17c:      	ubfx	x6, x6, #0, #8
    c180:      	mov	x3, x6
    c184:      	b	0xc12c <_stogir.conversion.policy+0x4e0>
    c188:      	mov	x0, #0x4                ; =4
    c18c:      	b	0xc11c <_stogir.conversion.policy+0x4d0>
    c190:      	mov	x0, #0x4                ; =4
    c194:      	b	0xc124 <_stogir.conversion.policy+0x4d8>
    c198:      	uxtb	w16, w28
    c19c:      	cmp	w16, wzr
    c1a0:      	b.eq	0xc168 <_stogir.conversion.policy+0x51c>
    c1a4:      	mov	x3, #0x1                ; =1
    c1a8:      	b	0xc16c <_stogir.conversion.policy+0x520>
    c1ac:      	cmp	x0, x1
    c1b0:      	cset	w3, le
    c1b4:      	ubfx	x3, x3, #0, #8
    c1b8:      	b	0xc15c <_stogir.conversion.policy+0x510>
    c1bc:      	mov	x0, #0x8                ; =8
    c1c0:      	b	0xc18c <_stogir.conversion.policy+0x540>
    c1c4:      	mov	x0, #0x8                ; =8
    c1c8:      	b	0xc194 <_stogir.conversion.policy+0x548>
    c1cc:      	movn	x0, #0x0, lsl #48
    c1d0:      	b	0xc1c0 <_stogir.conversion.policy+0x574>
    c1d4:      	movn	x0, #0x0, lsl #48
    c1d8:      	b	0xc1c8 <_stogir.conversion.policy+0x57c>
    c1dc:      	str	x8, [sp, #0x18]
    c1e0:      	mov	w28, w3
    c1e4:      	str	x23, [sp, #0x10]
    c1e8:      	mov	w23, w2
    c1ec:      	b	0xbe54 <_stogir.conversion.policy+0x208>
    c1f0:      	mov	x22, x0
    c1f4:      	mov	w23, w1
    c1f8:      	mov	w28, w2
    c1fc:      	b	0xbe34 <_stogir.conversion.policy+0x1e8>

000000000000c200 <_stogir.conditional.operands>:
    c200:      	sub	sp, sp, #0x30
    c204:      	str	x19, [sp, #0x20]
    c208:      	str	x20, [sp, #0x28]
    c20c:      	sxtw	x1, w1
    c210:      	cmp	x1, #0x0
    c214:      	b.eq	0xc268 <_stogir.conditional.operands+0x68>
    c218:      	cmp	x1, #0x0
    c21c:      	b.lt	0xc23c <_stogir.conditional.operands+0x3c>
    c220:      	cmp	x1, #0xd
    c224:      	b.gt	0xc23c <_stogir.conditional.operands+0x3c>
    c228:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c228:  ARM64_RELOC_PAGE21	l_stogir.470
    c22c:      	ldr	x16, [x16]
		000000000000c22c:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    c230:      	orr	x5, x16, xzr
    c234:      	movz	x6, #0x0, lsl #48
    c238:      	b	0xc278 <_stogir.conditional.operands+0x78>
    c23c:      	cmp	x1, #0xf
    c240:      	b.le	0xc268 <_stogir.conditional.operands+0x68>
    c244:      	cmp	x1, #0x80
    c248:      	b.ge	0xc268 <_stogir.conditional.operands+0x68>
    c24c:      	and	x5, x1, #0xf
    c250:      	lsr	w5, w5, #0
    c254:      	sxtw	x5, w5
    c258:      	cmp	x5, #0x1
    c25c:      	b.lt	0xc268 <_stogir.conditional.operands+0x68>
    c260:      	cmp	x5, #0xd
    c264:      	b.le	0xc228 <_stogir.conditional.operands+0x28>
    c268:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c268:  ARM64_RELOC_PAGE21	l_stogir.471
    c26c:      	ldr	x16, [x16]
		000000000000c26c:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    c270:      	orr	x5, x16, xzr
    c274:      	mov	x6, #0x2b               ; =43
    c278:      	sxtw	x2, w2
    c27c:      	cmp	x2, #0x0
    c280:      	cset	w7, gt
    c284:      	movz	x16, #0x0, lsl #48
    c288:      	sub	x9, x16, x2
    c28c:      	sub	x10, x9, #0x1
    c290:      	uxtb	w16, w7
    c294:      	cmp	w16, wzr
    c298:      	b.eq	0xc2d8 <_stogir.conditional.operands+0xd8>
    c29c:      	ldr	x9, [x0, #0x8]
    c2a0:      	cmp	x2, x9
    c2a4:      	b.ge	0xc330 <_stogir.conditional.operands+0x130>
    c2a8:      	add	x9, x0, #0x78
    c2ac:      	ldr	x9, [x9, #0x8]
    c2b0:      	cmp	x2, x9
    c2b4:      	b.ge	0xc6b4 <_stogir.conditional.operands+0x4b4>
    c2b8:      	ldr	x9, [x0, #0x78]
    c2bc:      	add	x9, x9, x2, lsl #2
    c2c0:      	ldr	w9, [x9]
    c2c4:      	sxtw	x9, w9
    c2c8:      	cmp	x9, #0x0
    c2cc:      	cset	w9, ge
    c2d0:      	ubfx	x9, x9, #0, #8
    c2d4:      	b	0xc6b8 <_stogir.conditional.operands+0x4b8>
    c2d8:      	cmp	x2, #0x0
    c2dc:      	b.ge	0xc338 <_stogir.conditional.operands+0x138>
    c2e0:      	add	x11, x0, #0x28
    c2e4:      	add	x12, x0, #0x50
    c2e8:      	ldr	x11, [x11, #0x8]
    c2ec:      	ldr	x12, [x12, #0x8]
    c2f0:      	cmp	x11, x12
    c2f4:      	b.ne	0xc320 <_stogir.conditional.operands+0x120>
    c2f8:      	cmp	x9, x11
    c2fc:      	b.gt	0xc6bc <_stogir.conditional.operands+0x4bc>
    c300:      	ldr	x9, [x0, #0x50]
    c304:      	add	x9, x9, x10, lsl #2
    c308:      	ldr	w9, [x9]
    c30c:      	sxtw	x9, w9
    c310:      	cmp	x9, #0x0
    c314:      	cset	w9, gt
    c318:      	ubfx	x9, x9, #0, #8
    c31c:      	b	0xc6c0 <_stogir.conditional.operands+0x4c0>
    c320:      	movz	x9, #0x0, lsl #48
    c324:      	b	0xc33c <_stogir.conditional.operands+0x13c>
    c328:      	movz	x14, #0x0, lsl #48
    c32c:      	b	0xc3dc <_stogir.conditional.operands+0x1dc>
    c330:      	movz	x9, #0x0, lsl #48
    c334:      	b	0xc33c <_stogir.conditional.operands+0x13c>
    c338:      	movz	x9, #0x0, lsl #48
    c33c:      	cmp	x9, #0x0
    c340:      	b.eq	0xc378 <_stogir.conditional.operands+0x178>
    c344:      	uxtb	w16, w7
    c348:      	cmp	w16, wzr
    c34c:      	b.eq	0xc360 <_stogir.conditional.operands+0x160>
    c350:      	ldr	x7, [x0]
    c354:      	add	x2, x7, x2, lsl #4
    c358:      	ldr	x2, [x2]
    c35c:      	b	0xc36c <_stogir.conditional.operands+0x16c>
    c360:      	ldr	x2, [x0, #0x28]
    c364:      	add	x2, x2, x10, lsl #4
    c368:      	ldr	x2, [x2]
    c36c:      	mov	x7, x2
    c370:      	mov	x2, #0x1                ; =1
    c374:      	b	0xc380 <_stogir.conditional.operands+0x180>
    c378:      	movz	x2, #0x0, lsl #48
    c37c:      	movz	x7, #0x0, lsl #48
    c380:      	lsr	w2, w2, #0
    c384:      	lsr	x16, x2, #0
    c388:      	cmp	x16, #0x1
    c38c:      	b.eq	0xc3a8 <_stogir.conditional.operands+0x1a8>
    c390:      	b.lo	0xc398 <_stogir.conditional.operands+0x198>
    c394:      	b	0xc3ac <_stogir.conditional.operands+0x1ac>
    c398:      	cmp	x16, #0x0
    c39c:      	b.eq	0xc3a4 <_stogir.conditional.operands+0x1a4>
    c3a0:      	b	0xc3ac <_stogir.conditional.operands+0x1ac>
    c3a4:      	b	0xc3b0 <_stogir.conditional.operands+0x1b0>
    c3a8:      	b	0xc674 <_stogir.conditional.operands+0x474>
    c3ac:      	b	0xc6d4 <_stogir.conditional.operands+0x4d4>
    c3b0:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c3b0:  ARM64_RELOC_PAGE21	l_stogir.472
    c3b4:      	ldr	x16, [x16]
		000000000000c3b4:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    c3b8:      	orr	x2, x16, xzr
    c3bc:      	mov	x5, #0x16               ; =22
    c3c0:      	b	0xc3f0 <_stogir.conditional.operands+0x1f0>
    c3c4:      	movz	x14, #0x0, lsl #48
    c3c8:      	fmov	d31, x13
    c3cc:      	mov	x13, x14
    c3d0:      	fmov	x14, d31
    c3d4:      	b	0xc458 <_stogir.conditional.operands+0x258>
    c3d8:      	movz	x14, #0x0, lsl #48
    c3dc:      	b	0xc460 <_stogir.conditional.operands+0x260>
    c3e0:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c3e0:  ARM64_RELOC_PAGE21	l_stogir.473
    c3e4:      	ldr	x16, [x16]
		000000000000c3e4:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    c3e8:      	orr	x2, x16, xzr
    c3ec:      	mov	x5, #0x2a               ; =42
    c3f0:      	add	x16, sp, #0x10
    c3f4:      	orr	x6, x16, xzr
    c3f8:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c3f8:  ARM64_RELOC_PAGE21	l_stogir.474
    c3fc:      	ldr	x16, [x16]
		000000000000c3fc:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    c400:      	orr	x7, x16, xzr
    c404:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c404:  ARM64_RELOC_PAGE21	l_stogir.475
    c408:      	ldr	x16, [x16]
		000000000000c408:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    c40c:      	orr	x9, x16, xzr
    c410:      	lsr	w3, w3, #0
    c414:      	lsr	w4, w4, #0
    c418:      	add	x10, x0, #0x78
    c41c:      	add	x11, x0, #0x28
    c420:      	add	x12, x0, #0x50
    c424:      	mov	x16, sp
    c428:      	str	w3, [x16]
    c42c:      	mov	x16, sp
    c430:      	str	w4, [x16, #0x4]
    c434:      	mov	x16, sp
    c438:      	ldr	x3, [x16]
    c43c:      	add	x16, sp, #0x10
    c440:      	str	x3, [x16]
    c444:      	mov	x3, x5
    c448:      	movz	x4, #0x0, lsl #48
    c44c:      	b	0xc528 <_stogir.conditional.operands+0x328>
    c450:      	mov	x14, x13
    c454:      	movz	x13, #0x0, lsl #48
    c458:      	b	0xc46c <_stogir.conditional.operands+0x26c>
    c45c:      	movz	x14, #0x0, lsl #48
    c460:      	fmov	d31, x13
    c464:      	mov	x13, x14
    c468:      	fmov	x14, d31
    c46c:      	cmp	x13, #0x0
    c470:      	b.eq	0xc4ac <_stogir.conditional.operands+0x2ac>
    c474:      	uxtb	w16, w4
    c478:      	cmp	w16, wzr
    c47c:      	b.eq	0xc490 <_stogir.conditional.operands+0x290>
    c480:      	ldr	x4, [x0]
    c484:      	add	x4, x4, x5, lsl #4
    c488:      	ldr	x4, [x4]
    c48c:      	b	0xc49c <_stogir.conditional.operands+0x29c>
    c490:      	ldr	x4, [x0, #0x28]
    c494:      	add	x4, x4, x15, lsl #4
    c498:      	ldr	x4, [x4]
    c49c:      	mov	x5, x4
    c4a0:      	mov	x13, x14
    c4a4:      	mov	x4, #0x1                ; =1
    c4a8:      	b	0xc4b8 <_stogir.conditional.operands+0x2b8>
    c4ac:      	mov	x13, x14
    c4b0:      	movz	x4, #0x0, lsl #48
    c4b4:      	movz	x5, #0x0, lsl #48
    c4b8:      	lsr	w4, w4, #0
    c4bc:      	lsr	x16, x4, #0
    c4c0:      	cmp	x16, #0x1
    c4c4:      	b.eq	0xc4e0 <_stogir.conditional.operands+0x2e0>
    c4c8:      	b.lo	0xc4d0 <_stogir.conditional.operands+0x2d0>
    c4cc:      	b	0xc4e4 <_stogir.conditional.operands+0x2e4>
    c4d0:      	cmp	x16, #0x0
    c4d4:      	b.eq	0xc4dc <_stogir.conditional.operands+0x2dc>
    c4d8:      	b	0xc4e4 <_stogir.conditional.operands+0x2e4>
    c4dc:      	b	0xc4e8 <_stogir.conditional.operands+0x2e8>
    c4e0:      	b	0xc4f8 <_stogir.conditional.operands+0x2f8>
    c4e4:      	b	0xc6cc <_stogir.conditional.operands+0x4cc>
    c4e8:      	mov	x2, x7
    c4ec:      	mov	x4, x13
    c4f0:      	mov	x3, #0x10               ; =16
    c4f4:      	b	0xc528 <_stogir.conditional.operands+0x328>
    c4f8:      	uxtb	w4, w5
    c4fc:      	cmp	x4, #0x48
    c500:      	b.eq	0xc51c <_stogir.conditional.operands+0x31c>
    c504:      	cmp	x4, #0x46
    c508:      	b.eq	0xc51c <_stogir.conditional.operands+0x31c>
    c50c:      	lsr	w5, w5, #0
    c510:      	ubfx	x4, x5, #8, #8
    c514:      	cmp	x4, x1
    c518:      	b.eq	0xc524 <_stogir.conditional.operands+0x324>
    c51c:      	mov	x2, x9
    c520:      	mov	x3, #0x21               ; =33
    c524:      	mov	x4, x13
    c528:      	cmp	x4, #0x2
    c52c:      	b.ge	0xc554 <_stogir.conditional.operands+0x354>
    c530:      	add	x5, x4, #0x1
    c534:      	add	x4, x6, x4, lsl #2
    c538:      	ldr	w4, [x4]
    c53c:      	sxtw	x4, w4
    c540:      	and	x4, x4, #0xffffffff
    c544:      	mov	x13, x5
    c548:      	mov	x5, x4
    c54c:      	mov	x4, #0x1                ; =1
    c550:      	b	0xc560 <_stogir.conditional.operands+0x360>
    c554:      	mov	x13, x4
    c558:      	movz	x4, #0x0, lsl #48
    c55c:      	movz	x5, #0x0, lsl #48
    c560:      	lsr	w4, w4, #0
    c564:      	lsr	x16, x4, #0
    c568:      	cmp	x16, #0x1
    c56c:      	b.eq	0xc588 <_stogir.conditional.operands+0x388>
    c570:      	b.lo	0xc578 <_stogir.conditional.operands+0x378>
    c574:      	b	0xc58c <_stogir.conditional.operands+0x38c>
    c578:      	cmp	x16, #0x0
    c57c:      	b.eq	0xc584 <_stogir.conditional.operands+0x384>
    c580:      	b	0xc58c <_stogir.conditional.operands+0x38c>
    c584:      	b	0xc5f0 <_stogir.conditional.operands+0x3f0>
    c588:      	b	0xc590 <_stogir.conditional.operands+0x390>
    c58c:      	b	0xc6c4 <_stogir.conditional.operands+0x4c4>
    c590:      	lsr	w5, w5, #0
    c594:      	sxtw	x5, w5
    c598:      	cmp	x5, #0x0
    c59c:      	cset	w4, gt
    c5a0:      	movz	x16, #0x0, lsl #48
    c5a4:      	sub	x14, x16, x5
    c5a8:      	sub	x15, x14, #0x1
    c5ac:      	uxtb	w16, w4
    c5b0:      	cmp	w16, wzr
    c5b4:      	b.eq	0xc634 <_stogir.conditional.operands+0x434>
    c5b8:      	ldr	x14, [x0, #0x8]
    c5bc:      	cmp	x5, x14
    c5c0:      	b.ge	0xc450 <_stogir.conditional.operands+0x250>
    c5c4:      	ldr	x14, [x10, #0x8]
    c5c8:      	cmp	x5, x14
    c5cc:      	b.ge	0xc3c4 <_stogir.conditional.operands+0x1c4>
    c5d0:      	ldr	x14, [x0, #0x78]
    c5d4:      	add	x14, x14, x5, lsl #2
    c5d8:      	ldr	w14, [x14]
    c5dc:      	sxtw	x14, w14
    c5e0:      	cmp	x14, #0x0
    c5e4:      	cset	w14, ge
    c5e8:      	ubfx	x14, x14, #0, #8
    c5ec:      	b	0xc3c8 <_stogir.conditional.operands+0x1c8>
    c5f0:      	cmp	x3, #0x0
    c5f4:      	b.ne	0xc60c <_stogir.conditional.operands+0x40c>
    c5f8:      	and	x0, x1, #0xffffffff
    c5fc:      	mov	x1, x0
    c600:      	movz	x0, #0x0, lsl #48
    c604:      	movz	x2, #0x0, lsl #48
    c608:      	b	0xc618 <_stogir.conditional.operands+0x418>
    c60c:      	mov	x1, x2
    c610:      	mov	x2, x3
    c614:      	mov	x0, #0x1                ; =1
    c618:      	str	x0, [x8]
    c61c:      	str	x1, [x8, #0x8]
    c620:      	str	x2, [x8, #0x10]
    c624:      	ldr	x19, [sp, #0x20]
    c628:      	ldr	x20, [sp, #0x28]
    c62c:      	add	sp, sp, #0x30
    c630:      	ret
    c634:      	cmp	x5, #0x0
    c638:      	b.ge	0xc45c <_stogir.conditional.operands+0x25c>
    c63c:      	ldr	x19, [x11, #0x8]
    c640:      	ldr	x20, [x12, #0x8]
    c644:      	cmp	x19, x20
    c648:      	b.ne	0xc3d8 <_stogir.conditional.operands+0x1d8>
    c64c:      	cmp	x14, x19
    c650:      	b.gt	0xc328 <_stogir.conditional.operands+0x128>
    c654:      	ldr	x14, [x0, #0x50]
    c658:      	add	x14, x14, x15, lsl #2
    c65c:      	ldr	w14, [x14]
    c660:      	sxtw	x14, w14
    c664:      	cmp	x14, #0x0
    c668:      	cset	w14, gt
    c66c:      	ubfx	x14, x14, #0, #8
    c670:      	b	0xc32c <_stogir.conditional.operands+0x12c>
    c674:      	uxtb	w2, w7
    c678:      	cmp	x2, #0x48
    c67c:      	b.eq	0xc3e0 <_stogir.conditional.operands+0x1e0>
    c680:      	cmp	x2, #0x46
    c684:      	b.eq	0xc3e0 <_stogir.conditional.operands+0x1e0>
    c688:      	lsr	w7, w7, #0
    c68c:      	orr	x2, x7, xzr
    c690:      	ubfx	x2, x2, #8, #8
    c694:      	cmp	x2, #0x0
    c698:      	b.eq	0xc3e0 <_stogir.conditional.operands+0x1e0>
    c69c:      	ubfx	x2, x7, #8, #8
    c6a0:      	cmp	x2, #0xd
    c6a4:      	b.gt	0xc3e0 <_stogir.conditional.operands+0x1e0>
    c6a8:      	mov	x2, x5
    c6ac:      	mov	x5, x6
    c6b0:      	b	0xc3f0 <_stogir.conditional.operands+0x1f0>
    c6b4:      	movz	x9, #0x0, lsl #48
    c6b8:      	b	0xc334 <_stogir.conditional.operands+0x134>
    c6bc:      	movz	x9, #0x0, lsl #48
    c6c0:      	b	0xc324 <_stogir.conditional.operands+0x124>
    c6c4:      	brk	#0
    c6c8:      	b	0xc6c4 <_stogir.conditional.operands+0x4c4>
    c6cc:      	brk	#0
    c6d0:      	b	0xc6cc <_stogir.conditional.operands+0x4cc>
    c6d4:      	brk	#0
    c6d8:      	b	0xc6d4 <_stogir.conditional.operands+0x4d4>

000000000000c6dc <_stogir.floating.unary?>:
    c6dc:      	sxtw	x0, w0
    c6e0:      	cmp	x0, #0x1f
    c6e4:      	b.ne	0xc6f0 <_stogir.floating.unary?+0x14>
    c6e8:      	mov	x0, #0x1                ; =1
    c6ec:      	b	0xc6fc <_stogir.floating.unary?+0x20>
    c6f0:      	cmp	x0, #0x20
    c6f4:      	cset	w0, eq
    c6f8:      	ubfx	x0, x0, #0, #8
    c6fc:      	ret

000000000000c700 <_stogir.floating.comparison?>:
    c700:      	sxtw	x0, w0
    c704:      	cmp	x0, #0xe
    c708:      	b.lt	0xc71c <_stogir.floating.comparison?+0x1c>
    c70c:      	cmp	x0, #0x19
    c710:      	cset	w0, le
    c714:      	ubfx	x0, x0, #0, #8
    c718:      	b	0xc720 <_stogir.floating.comparison?+0x20>
    c71c:      	movz	x0, #0x0, lsl #48
    c720:      	ret

000000000000c724 <_stogir.floating.operands>:
    c724:      	sub	sp, sp, #0x90
    c728:      	str	x29, [sp]
    c72c:      	str	x30, [sp, #0x8]
    c730:      	mov	x29, sp
    c734:      	str	x19, [sp, #0x60]
    c738:      	str	x20, [sp, #0x68]
    c73c:      	str	x21, [sp, #0x70]
    c740:      	str	x22, [sp, #0x78]
    c744:      	str	x23, [sp, #0x80]
    c748:      	sxtw	x1, w1
    c74c:      	sxtw	x19, w2
    c750:      	cmp	x1, #0x1f
    c754:      	cset	w2, eq
    c758:      	cmp	x1, #0x20
    c75c:      	cset	w6, eq
    c760:      	cmp	x1, #0xe
    c764:      	b.lt	0xc794 <_stogir.floating.operands+0x70>
    c768:      	cmp	x1, #0x19
    c76c:      	b.gt	0xc794 <_stogir.floating.operands+0x70>
    c770:      	cmp	x19, #0xc
    c774:      	b.eq	0xc7d0 <_stogir.floating.operands+0xac>
    c778:      	cmp	x19, #0xd
    c77c:      	b.eq	0xc7d0 <_stogir.floating.operands+0xac>
    c780:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c780:  ARM64_RELOC_PAGE21	l_stogir.476
    c784:      	ldr	x16, [x16]
		000000000000c784:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    c788:      	orr	x7, x16, xzr
    c78c:      	mov	x9, #0x22               ; =34
    c790:      	b	0xc7e0 <_stogir.floating.operands+0xbc>
    c794:      	uxtb	w16, w2
    c798:      	cmp	w16, wzr
    c79c:      	b.ne	0xc770 <_stogir.floating.operands+0x4c>
    c7a0:      	uxtb	w16, w6
    c7a4:      	cmp	w16, wzr
    c7a8:      	b.ne	0xc770 <_stogir.floating.operands+0x4c>
    c7ac:      	cmp	x1, #0x1a
    c7b0:      	b.lt	0xc7bc <_stogir.floating.operands+0x98>
    c7b4:      	cmp	x1, #0x1d
    c7b8:      	b.le	0xc770 <_stogir.floating.operands+0x4c>
    c7bc:      	cmp	x1, #0x3a
    c7c0:      	b.eq	0xc770 <_stogir.floating.operands+0x4c>
    c7c4:      	cmp	x1, #0x3b
    c7c8:      	b.eq	0xc770 <_stogir.floating.operands+0x4c>
    c7cc:      	b	0xc780 <_stogir.floating.operands+0x5c>
    c7d0:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c7d0:  ARM64_RELOC_PAGE21	l_stogir.477
    c7d4:      	ldr	x16, [x16]
		000000000000c7d4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    c7d8:      	orr	x7, x16, xzr
    c7dc:      	movz	x9, #0x0, lsl #48
    c7e0:      	lsr	w3, w3, #0
    c7e4:      	add	x16, sp, #0x10
    c7e8:      	str	w3, [x16]
    c7ec:      	uxtb	w16, w2
    c7f0:      	cmp	w16, wzr
    c7f4:      	b.ne	0xc87c <_stogir.floating.operands+0x158>
    c7f8:      	uxtb	w16, w6
    c7fc:      	cmp	w16, wzr
    c800:      	b.ne	0xc87c <_stogir.floating.operands+0x158>
    c804:      	sxtw	x4, w4
    c808:      	mov	x2, x4
    c80c:      	b	0xc884 <_stogir.floating.operands+0x160>
    c810:      	movz	x1, #0x0, lsl #48
    c814:      	uxtb	w1, w1
    c818:      	and	x1, x1, #0x2
    c81c:      	uxtb	w1, w1
    c820:      	cmp	x1, #0x0
    c824:      	cset	w1, eq
    c828:      	uxtb	w16, w1
    c82c:      	cmp	w16, wzr
    c830:      	cset	x1, eq
    c834:      	cmp	x1, #0x0
    c838:      	b.ne	0xcbdc <_stogir.floating.operands+0x4b8>
    c83c:      	cmp	x0, #0x65
    c840:      	b.eq	0xcbdc <_stogir.floating.operands+0x4b8>
    c844:      	cmp	x0, #0x66
    c848:      	b.eq	0xcbdc <_stogir.floating.operands+0x4b8>
    c84c:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c84c:  ARM64_RELOC_PAGE21	l_stogir.478
    c850:      	ldr	x16, [x16]
		000000000000c850:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    c854:      	orr	x0, x16, xzr
    c858:      	mov	x1, #0x2d               ; =45
    c85c:      	b	0xc990 <_stogir.floating.operands+0x26c>
    c860:      	movz	x13, #0x0, lsl #48
    c864:      	fmov	d31, x9
    c868:      	mov	x9, x13
    c86c:      	fmov	x13, d31
    c870:      	b	0xc8e4 <_stogir.floating.operands+0x1c0>
    c874:      	movz	x13, #0x0, lsl #48
    c878:      	b	0xc8ec <_stogir.floating.operands+0x1c8>
    c87c:      	sxtw	x3, w3
    c880:      	mov	x2, x3
    c884:      	add	x16, sp, #0x20
    c888:      	orr	x3, x16, xzr
    c88c:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c88c:  ARM64_RELOC_PAGE21	l_stogir.479
    c890:      	ldr	x16, [x16]
		000000000000c890:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    c894:      	orr	x4, x16, xzr
    c898:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c898:  ARM64_RELOC_PAGE21	l_stogir.480
    c89c:      	ldr	x16, [x16]
		000000000000c89c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    c8a0:      	orr	x6, x16, xzr
    c8a4:      	add	x10, x0, #0x78
    c8a8:      	add	x11, x0, #0x28
    c8ac:      	add	x12, x0, #0x50
    c8b0:      	lsr	w2, w2, #0
    c8b4:      	add	x16, sp, #0x10
    c8b8:      	str	w2, [x16, #0x4]
    c8bc:      	add	x16, sp, #0x10
    c8c0:      	ldr	x2, [x16]
    c8c4:      	add	x16, sp, #0x20
    c8c8:      	str	x2, [x16]
    c8cc:      	mov	x20, x7
    c8d0:      	mov	x21, x9
    c8d4:      	movz	x2, #0x0, lsl #48
    c8d8:      	b	0xc9a8 <_stogir.floating.operands+0x284>
    c8dc:      	mov	x13, x9
    c8e0:      	movz	x9, #0x0, lsl #48
    c8e4:      	b	0xc8f8 <_stogir.floating.operands+0x1d4>
    c8e8:      	movz	x13, #0x0, lsl #48
    c8ec:      	fmov	d31, x9
    c8f0:      	mov	x9, x13
    c8f4:      	fmov	x13, d31
    c8f8:      	cmp	x9, #0x0
    c8fc:      	b.eq	0xc938 <_stogir.floating.operands+0x214>
    c900:      	uxtb	w16, w2
    c904:      	cmp	w16, wzr
    c908:      	b.eq	0xc91c <_stogir.floating.operands+0x1f8>
    c90c:      	ldr	x2, [x0]
    c910:      	add	x2, x2, x7, lsl #4
    c914:      	ldr	x2, [x2]
    c918:      	b	0xc928 <_stogir.floating.operands+0x204>
    c91c:      	ldr	x2, [x0, #0x28]
    c920:      	add	x2, x2, x14, lsl #4
    c924:      	ldr	x2, [x2]
    c928:      	mov	x7, x2
    c92c:      	mov	x9, x13
    c930:      	mov	x2, #0x1                ; =1
    c934:      	b	0xc944 <_stogir.floating.operands+0x220>
    c938:      	mov	x9, x13
    c93c:      	movz	x2, #0x0, lsl #48
    c940:      	movz	x7, #0x0, lsl #48
    c944:      	lsr	w2, w2, #0
    c948:      	lsr	x16, x2, #0
    c94c:      	cmp	x16, #0x1
    c950:      	b.eq	0xc96c <_stogir.floating.operands+0x248>
    c954:      	b.lo	0xc95c <_stogir.floating.operands+0x238>
    c958:      	b	0xc970 <_stogir.floating.operands+0x24c>
    c95c:      	cmp	x16, #0x0
    c960:      	b.eq	0xc968 <_stogir.floating.operands+0x244>
    c964:      	b	0xc970 <_stogir.floating.operands+0x24c>
    c968:      	b	0xc974 <_stogir.floating.operands+0x250>
    c96c:      	b	0xcb84 <_stogir.floating.operands+0x460>
    c970:      	b	0xcbf0 <_stogir.floating.operands+0x4cc>
    c974:      	mov	x2, x4
    c978:      	mov	x7, #0x18               ; =24
    c97c:      	b	0xc99c <_stogir.floating.operands+0x278>
    c980:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000c980:  ARM64_RELOC_PAGE21	l_stogir.481
    c984:      	ldr	x16, [x16]
		000000000000c984:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    c988:      	orr	x0, x16, xzr
    c98c:      	mov	x1, #0x21               ; =33
    c990:      	b	0xca88 <_stogir.floating.operands+0x364>
    c994:      	mov	x2, x6
    c998:      	mov	x7, #0x1e               ; =30
    c99c:      	mov	x20, x2
    c9a0:      	mov	x21, x7
    c9a4:      	mov	x2, x9
    c9a8:      	cmp	x2, #0x2
    c9ac:      	b.ge	0xc9d4 <_stogir.floating.operands+0x2b0>
    c9b0:      	add	x7, x2, #0x1
    c9b4:      	add	x2, x3, x2, lsl #2
    c9b8:      	ldr	w2, [x2]
    c9bc:      	sxtw	x2, w2
    c9c0:      	and	x2, x2, #0xffffffff
    c9c4:      	mov	x9, x7
    c9c8:      	mov	x7, x2
    c9cc:      	mov	x2, #0x1                ; =1
    c9d0:      	b	0xc9e0 <_stogir.floating.operands+0x2bc>
    c9d4:      	mov	x9, x2
    c9d8:      	movz	x2, #0x0, lsl #48
    c9dc:      	movz	x7, #0x0, lsl #48
    c9e0:      	lsr	w2, w2, #0
    c9e4:      	lsr	x16, x2, #0
    c9e8:      	cmp	x16, #0x1
    c9ec:      	b.eq	0xca08 <_stogir.floating.operands+0x2e4>
    c9f0:      	b.lo	0xc9f8 <_stogir.floating.operands+0x2d4>
    c9f4:      	b	0xca0c <_stogir.floating.operands+0x2e8>
    c9f8:      	cmp	x16, #0x0
    c9fc:      	b.eq	0xca04 <_stogir.floating.operands+0x2e0>
    ca00:      	b	0xca0c <_stogir.floating.operands+0x2e8>
    ca04:      	b	0xca70 <_stogir.floating.operands+0x34c>
    ca08:      	b	0xca10 <_stogir.floating.operands+0x2ec>
    ca0c:      	b	0xcbe8 <_stogir.floating.operands+0x4c4>
    ca10:      	lsr	w7, w7, #0
    ca14:      	sxtw	x7, w7
    ca18:      	cmp	x7, #0x0
    ca1c:      	cset	w2, gt
    ca20:      	movz	x16, #0x0, lsl #48
    ca24:      	sub	x13, x16, x7
    ca28:      	sub	x14, x13, #0x1
    ca2c:      	uxtb	w16, w2
    ca30:      	cmp	w16, wzr
    ca34:      	b.eq	0xcb08 <_stogir.floating.operands+0x3e4>
    ca38:      	ldr	x13, [x0, #0x8]
    ca3c:      	cmp	x7, x13
    ca40:      	b.ge	0xc8dc <_stogir.floating.operands+0x1b8>
    ca44:      	ldr	x13, [x10, #0x8]
    ca48:      	cmp	x7, x13
    ca4c:      	b.ge	0xc860 <_stogir.floating.operands+0x13c>
    ca50:      	ldr	x13, [x0, #0x78]
    ca54:      	add	x13, x13, x7, lsl #2
    ca58:      	ldr	w13, [x13]
    ca5c:      	sxtw	x13, w13
    ca60:      	cmp	x13, #0x0
    ca64:      	cset	w13, ge
    ca68:      	ubfx	x13, x13, #0, #8
    ca6c:      	b	0xc864 <_stogir.floating.operands+0x140>
    ca70:      	sxtw	x22, w5
    ca74:      	cmp	x22, #0x0
    ca78:      	b.ne	0xcaa4 <_stogir.floating.operands+0x380>
    ca7c:      	mov	x23, x8
    ca80:      	mov	x0, x20
    ca84:      	mov	x1, x21
    ca88:      	cmp	x1, #0x0
    ca8c:      	b.ne	0xcb48 <_stogir.floating.operands+0x424>
    ca90:      	and	x0, x19, #0xffffffff
    ca94:      	mov	x1, x0
    ca98:      	movz	x0, #0x0, lsl #48
    ca9c:      	movz	x2, #0x0, lsl #48
    caa0:      	b	0xcb54 <_stogir.floating.operands+0x430>
    caa4:      	cmp	x1, #0x1d
    caa8:      	b.ne	0xcc00 <_stogir.floating.operands+0x4dc>
    caac:      	lsr	w5, w5, #0
    cab0:      	mov	w1, w5
    cab4:      	mov	x23, x8
    cab8:      	add	x8, sp, #0x30
    cabc:      	bl	0xcabc <_stogir.floating.operands+0x398>
		000000000000cabc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    cac0:      	add	x16, sp, #0x30
    cac4:      	ldr	w0, [x16]
    cac8:      	lsr	x16, x0, #0
    cacc:      	cmp	x16, #0x1
    cad0:      	b.eq	0xcaec <_stogir.floating.operands+0x3c8>
    cad4:      	b.lo	0xcadc <_stogir.floating.operands+0x3b8>
    cad8:      	b	0xcaf0 <_stogir.floating.operands+0x3cc>
    cadc:      	cmp	x16, #0x0
    cae0:      	b.eq	0xcae8 <_stogir.floating.operands+0x3c4>
    cae4:      	b	0xcaf0 <_stogir.floating.operands+0x3cc>
    cae8:      	b	0xcaf4 <_stogir.floating.operands+0x3d0>
    caec:      	b	0xcba8 <_stogir.floating.operands+0x484>
    caf0:      	b	0xcbf8 <_stogir.floating.operands+0x4d4>
    caf4:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000caf4:  ARM64_RELOC_PAGE21	l_stogir.482
    caf8:      	ldr	x16, [x16]
		000000000000caf8:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    cafc:      	orr	x0, x16, xzr
    cb00:      	mov	x1, #0x16               ; =22
    cb04:      	b	0xc85c <_stogir.floating.operands+0x138>
    cb08:      	cmp	x7, #0x0
    cb0c:      	b.ge	0xc8e8 <_stogir.floating.operands+0x1c4>
    cb10:      	ldr	x15, [x11, #0x8]
    cb14:      	ldr	x22, [x12, #0x8]
    cb18:      	cmp	x15, x22
    cb1c:      	b.ne	0xc874 <_stogir.floating.operands+0x150>
    cb20:      	cmp	x13, x15
    cb24:      	b.gt	0xcba0 <_stogir.floating.operands+0x47c>
    cb28:      	ldr	x13, [x0, #0x50]
    cb2c:      	add	x13, x13, x14, lsl #2
    cb30:      	ldr	w13, [x13]
    cb34:      	sxtw	x13, w13
    cb38:      	cmp	x13, #0x0
    cb3c:      	cset	w13, gt
    cb40:      	ubfx	x13, x13, #0, #8
    cb44:      	b	0xcba4 <_stogir.floating.operands+0x480>
    cb48:      	mov	x2, x1
    cb4c:      	mov	x1, x0
    cb50:      	mov	x0, #0x1                ; =1
    cb54:      	str	x0, [x23]
    cb58:      	str	x1, [x23, #0x8]
    cb5c:      	str	x2, [x23, #0x10]
    cb60:      	ldr	x19, [sp, #0x60]
    cb64:      	ldr	x20, [sp, #0x68]
    cb68:      	ldr	x21, [sp, #0x70]
    cb6c:      	ldr	x22, [sp, #0x78]
    cb70:      	ldr	x23, [sp, #0x80]
    cb74:      	ldr	x29, [sp]
    cb78:      	ldr	x30, [sp, #0x8]
    cb7c:      	add	sp, sp, #0x90
    cb80:      	ret
    cb84:      	lsr	w7, w7, #0
    cb88:      	ubfx	x2, x7, #8, #8
    cb8c:      	cmp	x2, x19
    cb90:      	b.ne	0xc994 <_stogir.floating.operands+0x270>
    cb94:      	mov	x2, x20
    cb98:      	mov	x7, x21
    cb9c:      	b	0xc99c <_stogir.floating.operands+0x278>
    cba0:      	movz	x13, #0x0, lsl #48
    cba4:      	b	0xc878 <_stogir.floating.operands+0x154>
    cba8:      	add	x16, sp, #0x30
    cbac:      	ldr	x0, [x16, #0x8]
    cbb0:      	cmp	x22, #0x0
    cbb4:      	b.lt	0xc84c <_stogir.floating.operands+0x128>
    cbb8:      	uxtb	w0, w0
    cbbc:      	cmp	x0, #0x83
    cbc0:      	b.ge	0xc810 <_stogir.floating.operands+0xec>
    cbc4:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000cbc4:  ARM64_RELOC_PAGE21	l_stogir.483
    cbc8:      	ldr	x16, [x16]
		000000000000cbc8:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    cbcc:      	orr	x1, x16, xzr
    cbd0:      	add	x1, x0, x1
    cbd4:      	ldrb	w1, [x1]
    cbd8:      	b	0xc814 <_stogir.floating.operands+0xf0>
    cbdc:      	mov	x0, x20
    cbe0:      	mov	x1, x21
    cbe4:      	b	0xc85c <_stogir.floating.operands+0x138>
    cbe8:      	brk	#0
    cbec:      	b	0xcbe8 <_stogir.floating.operands+0x4c4>
    cbf0:      	brk	#0
    cbf4:      	b	0xcbf0 <_stogir.floating.operands+0x4cc>
    cbf8:      	brk	#0
    cbfc:      	b	0xcbf8 <_stogir.floating.operands+0x4d4>
    cc00:      	mov	x23, x8
    cc04:      	b	0xc980 <_stogir.floating.operands+0x25c>

000000000000cc08 <_stogir.types.signed?>:
    cc08:      	sxtw	x0, w0
    cc0c:      	cmp	x0, #0x7
    cc10:      	b.lt	0xcc24 <_stogir.types.signed?+0x1c>
    cc14:      	cmp	x0, #0xb
    cc18:      	cset	w0, le
    cc1c:      	ubfx	x0, x0, #0, #8
    cc20:      	b	0xcc28 <_stogir.types.signed?+0x20>
    cc24:      	movz	x0, #0x0, lsl #48
    cc28:      	ret

000000000000cc2c <_stogir.integer-binary.logical?>:
    cc2c:      	sxtw	x0, w0
    cc30:      	cmp	x0, #0x2e
    cc34:      	b.ne	0xcc50 <_stogir.integer-binary.logical?+0x24>
    cc38:      	mov	x0, #0x1                ; =1
    cc3c:      	b	0xcc4c <_stogir.integer-binary.logical?+0x20>
    cc40:      	cmp	x0, #0x30
    cc44:      	cset	w0, eq
    cc48:      	ubfx	x0, x0, #0, #8
    cc4c:      	ret
    cc50:      	cmp	x0, #0x2f
    cc54:      	b.ne	0xcc40 <_stogir.integer-binary.logical?+0x14>
    cc58:      	mov	x0, #0x1                ; =1
    cc5c:      	b	0xcc4c <_stogir.integer-binary.logical?+0x20>

000000000000cc60 <_inherent$slice$data__i8>:
    cc60:      	ret

000000000000cc64 <_inherent$slice$data__u32>:
    cc64:      	ret

000000000000cc68 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    cc68:      	sub	sp, sp, #0x10
    cc6c:      	mov	x1, sp
    cc70:      	ldr	x2, [x0]
    cc74:      	ldr	x0, [x0, #0x8]
    cc78:      	str	x2, [x1]
    cc7c:      	str	x0, [x1, #0x8]
    cc80:      	ldr	x0, [sp]
    cc84:      	ldr	x1, [sp, #0x8]
    cc88:      	add	sp, sp, #0x10
    cc8c:      	ret

000000000000cc90 <_inherent$slice$at__stogir.node.Node>:
    cc90:      	add	x0, x0, x2, lsl #4
    cc94:      	ret

000000000000cc98 <_inherent$slice$new__u8>:
    cc98:      	sub	sp, sp, #0x10
    cc9c:      	mov	x2, sp
    cca0:      	str	x0, [x2]
    cca4:      	str	x1, [x2, #0x8]
    cca8:      	ldr	x0, [sp]
    ccac:      	ldr	x1, [sp, #0x8]
    ccb0:      	add	sp, sp, #0x10
    ccb4:      	ret

000000000000ccb8 <_stogir.vector-lanes.operands>:
    ccb8:      	sub	sp, sp, #0x110
    ccbc:      	str	x29, [sp]
    ccc0:      	str	x30, [sp, #0x8]
    ccc4:      	mov	x29, sp
    ccc8:      	str	x19, [sp, #0xc0]
    cccc:      	str	x20, [sp, #0xc8]
    ccd0:      	str	x21, [sp, #0xd0]
    ccd4:      	str	x22, [sp, #0xd8]
    ccd8:      	str	x23, [sp, #0xe0]
    ccdc:      	str	x24, [sp, #0xe8]
    cce0:      	str	x25, [sp, #0xf0]
    cce4:      	str	x26, [sp, #0xf8]
    cce8:      	str	x27, [sp, #0x100]
    ccec:      	str	x28, [sp, #0x108]
    ccf0:      	sxtw	x4, w4
    ccf4:      	cmp	x4, #0x0
    ccf8:      	cset	w7, gt
    ccfc:      	movz	x16, #0x0, lsl #48
    cd00:      	sub	x9, x16, x4
    cd04:      	sub	x10, x9, #0x1
    cd08:      	uxtb	w16, w7
    cd0c:      	cmp	w16, wzr
    cd10:      	b.eq	0xcd50 <_stogir.vector-lanes.operands+0x98>
    cd14:      	ldr	x9, [x0, #0x8]
    cd18:      	cmp	x4, x9
    cd1c:      	b.ge	0xcdb0 <_stogir.vector-lanes.operands+0xf8>
    cd20:      	add	x9, x0, #0x78
    cd24:      	ldr	x9, [x9, #0x8]
    cd28:      	cmp	x4, x9
    cd2c:      	b.ge	0xceb8 <_stogir.vector-lanes.operands+0x200>
    cd30:      	ldr	x9, [x0, #0x78]
    cd34:      	add	x9, x9, x4, lsl #2
    cd38:      	ldr	w9, [x9]
    cd3c:      	sxtw	x9, w9
    cd40:      	cmp	x9, #0x0
    cd44:      	cset	w9, ge
    cd48:      	ubfx	x9, x9, #0, #8
    cd4c:      	b	0xcebc <_stogir.vector-lanes.operands+0x204>
    cd50:      	cmp	x4, #0x0
    cd54:      	b.ge	0xcdb8 <_stogir.vector-lanes.operands+0x100>
    cd58:      	add	x11, x0, #0x28
    cd5c:      	add	x12, x0, #0x50
    cd60:      	ldr	x11, [x11, #0x8]
    cd64:      	ldr	x12, [x12, #0x8]
    cd68:      	cmp	x11, x12
    cd6c:      	b.ne	0xcd98 <_stogir.vector-lanes.operands+0xe0>
    cd70:      	cmp	x9, x11
    cd74:      	b.gt	0xd054 <_stogir.vector-lanes.operands+0x39c>
    cd78:      	ldr	x9, [x0, #0x50]
    cd7c:      	add	x9, x9, x10, lsl #2
    cd80:      	ldr	w9, [x9]
    cd84:      	sxtw	x9, w9
    cd88:      	cmp	x9, #0x0
    cd8c:      	cset	w9, gt
    cd90:      	ubfx	x9, x9, #0, #8
    cd94:      	b	0xd058 <_stogir.vector-lanes.operands+0x3a0>
    cd98:      	movz	x9, #0x0, lsl #48
    cd9c:      	b	0xcdbc <_stogir.vector-lanes.operands+0x104>
    cda0:      	mov	x2, x1
    cda4:      	mov	x1, x0
    cda8:      	mov	x0, #0x1                ; =1
    cdac:      	b	0xce4c <_stogir.vector-lanes.operands+0x194>
    cdb0:      	movz	x9, #0x0, lsl #48
    cdb4:      	b	0xcdbc <_stogir.vector-lanes.operands+0x104>
    cdb8:      	movz	x9, #0x0, lsl #48
    cdbc:      	cmp	x9, #0x0
    cdc0:      	b.eq	0xcdf8 <_stogir.vector-lanes.operands+0x140>
    cdc4:      	uxtb	w16, w7
    cdc8:      	cmp	w16, wzr
    cdcc:      	b.eq	0xcde0 <_stogir.vector-lanes.operands+0x128>
    cdd0:      	ldr	x7, [x0]
    cdd4:      	add	x4, x7, x4, lsl #4
    cdd8:      	ldr	x4, [x4]
    cddc:      	b	0xcdec <_stogir.vector-lanes.operands+0x134>
    cde0:      	ldr	x4, [x0, #0x28]
    cde4:      	add	x4, x4, x10, lsl #4
    cde8:      	ldr	x4, [x4]
    cdec:      	mov	x7, x4
    cdf0:      	mov	x4, #0x1                ; =1
    cdf4:      	b	0xce00 <_stogir.vector-lanes.operands+0x148>
    cdf8:      	movz	x4, #0x0, lsl #48
    cdfc:      	movz	x7, #0x0, lsl #48
    ce00:      	lsr	w4, w4, #0
    ce04:      	lsr	x16, x4, #0
    ce08:      	cmp	x16, #0x1
    ce0c:      	b.eq	0xce28 <_stogir.vector-lanes.operands+0x170>
    ce10:      	b.lo	0xce18 <_stogir.vector-lanes.operands+0x160>
    ce14:      	b	0xce2c <_stogir.vector-lanes.operands+0x174>
    ce18:      	cmp	x16, #0x0
    ce1c:      	b.eq	0xce24 <_stogir.vector-lanes.operands+0x16c>
    ce20:      	b	0xce2c <_stogir.vector-lanes.operands+0x174>
    ce24:      	b	0xce30 <_stogir.vector-lanes.operands+0x178>
    ce28:      	b	0xce94 <_stogir.vector-lanes.operands+0x1dc>
    ce2c:      	b	0xd3e8 <_stogir.vector-lanes.operands+0x730>
    ce30:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000ce30:  ARM64_RELOC_PAGE21	l_stogir.484
    ce34:      	ldr	x16, [x16]
		000000000000ce34:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    ce38:      	orr	x0, x16, xzr
    ce3c:      	str	x8, [sp, #0xa0]
    ce40:      	mov	x1, x0
    ce44:      	mov	x0, #0x1                ; =1
    ce48:      	mov	x2, #0x1b               ; =27
    ce4c:      	ldr	x3, [sp, #0xa0]
    ce50:      	str	x0, [x3]
    ce54:      	str	x1, [x3, #0x8]
    ce58:      	str	x2, [x3, #0x10]
    ce5c:      	ldr	x19, [sp, #0xc0]
    ce60:      	ldr	x20, [sp, #0xc8]
    ce64:      	ldr	x21, [sp, #0xd0]
    ce68:      	ldr	x22, [sp, #0xd8]
    ce6c:      	ldr	x23, [sp, #0xe0]
    ce70:      	ldr	x24, [sp, #0xe8]
    ce74:      	ldr	x25, [sp, #0xf0]
    ce78:      	ldr	x26, [sp, #0xf8]
    ce7c:      	ldr	x27, [sp, #0x100]
    ce80:      	ldr	x28, [sp, #0x108]
    ce84:      	ldr	x29, [sp]
    ce88:      	ldr	x30, [sp, #0x8]
    ce8c:      	add	sp, sp, #0x110
    ce90:      	ret
    ce94:      	sxtw	x19, w1
    ce98:      	sxtw	x1, w2
    ce9c:      	lsr	w4, w7, #0
    cea0:      	ubfx	x4, x4, #8, #8
    cea4:      	orr	x20, x4, xzr
    cea8:      	cmp	x19, #0x3d
    ceac:      	b.ne	0xcec0 <_stogir.vector-lanes.operands+0x208>
    ceb0:      	mov	x21, x20
    ceb4:      	b	0xcec4 <_stogir.vector-lanes.operands+0x20c>
    ceb8:      	movz	x9, #0x0, lsl #48
    cebc:      	b	0xcdb4 <_stogir.vector-lanes.operands+0xfc>
    cec0:      	mov	x21, x1
    cec4:      	cmp	x19, #0x3d
    cec8:      	b.eq	0xced0 <_stogir.vector-lanes.operands+0x218>
    cecc:      	mov	x1, x20
    ced0:      	lsr	w22, w21, #0
    ced4:      	sxtw	x23, w22
    ced8:      	cmp	x23, #0xf
    cedc:      	cset	w24, gt
    cee0:      	cmp	x23, #0x80
    cee4:      	cset	w25, lt
    cee8:      	and	x4, x23, #0xf
    ceec:      	lsr	w4, w4, #0
    cef0:      	sxtw	x4, w4
    cef4:      	cmp	x4, #0x1
    cef8:      	cset	w26, ge
    cefc:      	cmp	x4, #0xd
    cf00:      	cset	w27, le
    cf04:      	cmp	x19, #0x3d
    cf08:      	b.lt	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf0c:      	cmp	x19, #0x3f
    cf10:      	b.gt	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf14:      	uxtb	w16, w24
    cf18:      	cmp	w16, wzr
    cf1c:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf20:      	uxtb	w16, w25
    cf24:      	cmp	w16, wzr
    cf28:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf2c:      	uxtb	w16, w26
    cf30:      	cmp	w16, wzr
    cf34:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf38:      	uxtb	w16, w27
    cf3c:      	cmp	w16, wzr
    cf40:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    cf44:      	sxtw	x4, w3
    cf48:      	cmp	x4, #0x4
    cf4c:      	b.eq	0xd418 <_stogir.vector-lanes.operands+0x760>
    cf50:      	cmp	x4, #0x8
    cf54:      	b.eq	0xd418 <_stogir.vector-lanes.operands+0x760>
    cf58:      	adrp	x16, 0xc000 <_stogir.conversion.policy+0x3b4>
		000000000000cf58:  ARM64_RELOC_PAGE21	l_stogir.485
    cf5c:      	ldr	x16, [x16]
		000000000000cf5c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    cf60:      	orr	x4, x16, xzr
    cf64:      	mov	x28, x4
    cf68:      	mov	x4, #0x36               ; =54
    cf6c:      	sxtw	x7, w5
    cf70:      	sxtw	x9, w6
    cf74:      	cmp	x9, #0x0
    cf78:      	cset	w9, eq
    cf7c:      	cmp	x19, #0x3f
    cf80:      	b.ne	0xd454 <_stogir.vector-lanes.operands+0x79c>
    cf84:      	lsr	w1, w1, #0
    cf88:      	lsr	w3, w3, #0
    cf8c:      	mov	w0, w22
    cf90:      	mov	w2, w3
    cf94:      	mov	x19, x8
    cf98:      	mov	x20, x4
    cf9c:      	mov	x22, x7
    cfa0:      	mov	w23, w9
    cfa4:      	bl	0xcfa4 <_stogir.vector-lanes.operands+0x2ec>
		000000000000cfa4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    cfa8:      	cmp	x0, #0x0
    cfac:      	b.eq	0xd090 <_stogir.vector-lanes.operands+0x3d8>
    cfb0:      	mov	x1, x28
    cfb4:      	movz	x0, #0x0, lsl #48
    cfb8:      	b	0xd098 <_stogir.vector-lanes.operands+0x3e0>
    cfbc:      	cmp	x19, #0x3d
    cfc0:      	b.ne	0xd460 <_stogir.vector-lanes.operands+0x7a8>
    cfc4:      	lsr	w2, w2, #0
    cfc8:      	lsr	w3, w3, #0
    cfcc:      	str	x0, [sp, #0x80]
    cfd0:      	mov	w0, w22
    cfd4:      	str	w3, [sp, #0xb0]
    cfd8:      	str	x1, [sp, #0xa0]
    cfdc:      	mov	w1, w2
    cfe0:      	mov	w2, w3
    cfe4:      	str	x4, [sp, #0xa8]
    cfe8:      	str	w8, [sp, #0xb8]
    cfec:      	str	w22, [sp, #0x88]
    cff0:      	mov	x22, x7
    cff4:      	str	x28, [sp, #0x90]
    cff8:      	mov	w28, w5
    cffc:      	str	x21, [sp, #0x98]
    d000:      	mov	w21, w6
    d004:      	bl	0xd004 <_stogir.vector-lanes.operands+0x34c>
		000000000000d004:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d008:      	cmp	x0, #0x0
    d00c:      	b.ne	0xd0c0 <_stogir.vector-lanes.operands+0x408>
    d010:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d010:  ARM64_RELOC_PAGE21	l_stogir.486
    d014:      	ldr	x16, [x16]
		000000000000d014:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    d018:      	orr	x0, x16, xzr
    d01c:      	mov	x1, #0x26               ; =38
    d020:      	b	0xd0c8 <_stogir.vector-lanes.operands+0x410>
    d024:      	mov	x0, x1
    d028:      	mov	x1, x20
    d02c:      	str	x21, [sp, #0x98]
    d030:      	str	x19, [sp, #0xa0]
    d034:      	cmp	x1, #0x0
    d038:      	b.ne	0xcda0 <_stogir.vector-lanes.operands+0xe8>
    d03c:      	ldr	x0, [sp, #0x98]
    d040:      	and	x0, x0, #0xffffffff
    d044:      	mov	x1, x0
    d048:      	movz	x0, #0x0, lsl #48
    d04c:      	movz	x2, #0x0, lsl #48
    d050:      	b	0xcdac <_stogir.vector-lanes.operands+0xf4>
    d054:      	movz	x9, #0x0, lsl #48
    d058:      	b	0xcd9c <_stogir.vector-lanes.operands+0xe4>
    d05c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d05c:  ARM64_RELOC_PAGE21	l_stogir.487
    d060:      	ldr	x16, [x16]
		000000000000d060:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    d064:      	orr	x0, x16, xzr
    d068:      	mov	x1, #0x20               ; =32
    d06c:      	b	0xd034 <_stogir.vector-lanes.operands+0x37c>
    d070:      	mov	x0, #0x1                ; =1
    d074:      	cmp	x0, #0x0
    d078:      	b.eq	0xd024 <_stogir.vector-lanes.operands+0x36c>
    d07c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d07c:  ARM64_RELOC_PAGE21	l_stogir.488
    d080:      	ldr	x16, [x16]
		000000000000d080:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    d084:      	orr	x0, x16, xzr
    d088:      	mov	x1, #0x24               ; =36
    d08c:      	b	0xd02c <_stogir.vector-lanes.operands+0x374>
    d090:      	mov	x1, x28
    d094:      	mov	x0, #0x1                ; =1
    d098:      	cmp	x0, #0x0
    d09c:      	b.eq	0xd0a8 <_stogir.vector-lanes.operands+0x3f0>
    d0a0:      	mov	x0, #0x1                ; =1
    d0a4:      	b	0xd074 <_stogir.vector-lanes.operands+0x3bc>
    d0a8:      	cmp	x22, #0x0
    d0ac:      	b.ne	0xd070 <_stogir.vector-lanes.operands+0x3b8>
    d0b0:      	uxtb	w16, w23
    d0b4:      	cmp	w16, wzr
    d0b8:      	cset	x0, eq
    d0bc:      	b	0xd074 <_stogir.vector-lanes.operands+0x3bc>
    d0c0:      	ldr	x0, [sp, #0x90]
    d0c4:      	ldr	x1, [sp, #0xa8]
    d0c8:      	cmp	x19, #0x3e
    d0cc:      	b.ne	0xd0f4 <_stogir.vector-lanes.operands+0x43c>
    d0d0:      	cmp	x20, x23
    d0d4:      	cset	w2, eq
    d0d8:      	uxtb	w16, w2
    d0dc:      	cmp	w16, wzr
    d0e0:      	cset	x2, eq
    d0e4:      	fmov	d31, x0
    d0e8:      	mov	x0, x2
    d0ec:      	fmov	x2, d31
    d0f0:      	b	0xd0fc <_stogir.vector-lanes.operands+0x444>
    d0f4:      	mov	x2, x0
    d0f8:      	movz	x0, #0x0, lsl #48
    d0fc:      	cmp	x0, #0x0
    d100:      	b.eq	0xd11c <_stogir.vector-lanes.operands+0x464>
    d104:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d104:  ARM64_RELOC_PAGE21	l_stogir.489
    d108:      	ldr	x16, [x16]
		000000000000d108:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    d10c:      	orr	x0, x16, xzr
    d110:      	mov	x20, x0
    d114:      	mov	x0, #0x27               ; =39
    d118:      	b	0xd124 <_stogir.vector-lanes.operands+0x46c>
    d11c:      	mov	x20, x2
    d120:      	mov	x0, x1
    d124:      	lsr	w28, w28, #0
    d128:      	add	x8, sp, #0x10
    d12c:      	mov	w1, w28
    d130:      	mov	x28, x0
    d134:      	ldr	x0, [sp, #0x80]
    d138:      	bl	0xd138 <_stogir.vector-lanes.operands+0x480>
		000000000000d138:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d13c:      	add	x16, sp, #0x10
    d140:      	ldr	w0, [x16]
    d144:      	lsr	x16, x0, #0
    d148:      	cmp	x16, #0x1
    d14c:      	b.eq	0xd168 <_stogir.vector-lanes.operands+0x4b0>
    d150:      	b.lo	0xd158 <_stogir.vector-lanes.operands+0x4a0>
    d154:      	b	0xd16c <_stogir.vector-lanes.operands+0x4b4>
    d158:      	cmp	x16, #0x0
    d15c:      	b.eq	0xd164 <_stogir.vector-lanes.operands+0x4ac>
    d160:      	b	0xd16c <_stogir.vector-lanes.operands+0x4b4>
    d164:      	b	0xd170 <_stogir.vector-lanes.operands+0x4b8>
    d168:      	b	0xd1e8 <_stogir.vector-lanes.operands+0x530>
    d16c:      	b	0xd444 <_stogir.vector-lanes.operands+0x78c>
    d170:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d170:  ARM64_RELOC_PAGE21	l_stogir.490
    d174:      	ldr	x16, [x16]
		000000000000d174:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    d178:      	orr	x0, x16, xzr
    d17c:      	mov	x20, x0
    d180:      	mov	x22, #0x19              ; =25
    d184:      	cmp	x19, #0x3e
    d188:      	b.ne	0xd250 <_stogir.vector-lanes.operands+0x598>
    d18c:      	lsr	w21, w21, #0
    d190:      	add	x8, sp, #0x50
    d194:      	ldr	x0, [sp, #0x80]
    d198:      	mov	w1, w21
    d19c:      	bl	0xd19c <_stogir.vector-lanes.operands+0x4e4>
		000000000000d19c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d1a0:      	add	x16, sp, #0x50
    d1a4:      	ldr	w0, [x16]
    d1a8:      	lsr	x16, x0, #0
    d1ac:      	cmp	x16, #0x1
    d1b0:      	b.eq	0xd1cc <_stogir.vector-lanes.operands+0x514>
    d1b4:      	b.lo	0xd1bc <_stogir.vector-lanes.operands+0x504>
    d1b8:      	b	0xd1d0 <_stogir.vector-lanes.operands+0x518>
    d1bc:      	cmp	x16, #0x0
    d1c0:      	b.eq	0xd1c8 <_stogir.vector-lanes.operands+0x510>
    d1c4:      	b	0xd1d0 <_stogir.vector-lanes.operands+0x518>
    d1c8:      	b	0xd1d4 <_stogir.vector-lanes.operands+0x51c>
    d1cc:      	b	0xd318 <_stogir.vector-lanes.operands+0x660>
    d1d0:      	b	0xd44c <_stogir.vector-lanes.operands+0x794>
    d1d4:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d1d4:  ARM64_RELOC_PAGE21	l_stogir.491
    d1d8:      	ldr	x16, [x16]
		000000000000d1d8:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    d1dc:      	orr	x0, x16, xzr
    d1e0:      	mov	x1, #0x20               ; =32
    d1e4:      	b	0xd06c <_stogir.vector-lanes.operands+0x3b4>
    d1e8:      	add	x16, sp, #0x10
    d1ec:      	orr	x0, x16, xzr
    d1f0:      	add	x0, x0, #0x8
    d1f4:      	add	x16, sp, #0x10
    d1f8:      	ldr	x1, [x16, #0x8]
    d1fc:      	add	x16, sp, #0x40
    d200:      	str	x1, [x16]
    d204:      	lsr	w1, w1, #0
    d208:      	ldr	x0, [x0, #0x8]
    d20c:      	add	x16, sp, #0x40
    d210:      	str	x0, [x16, #0x8]
    d214:      	ubfx	x0, x1, #8, #8
    d218:      	cmp	x0, #0x1
    d21c:      	b.lt	0xd27c <_stogir.vector-lanes.operands+0x5c4>
    d220:      	cmp	x0, #0xb
    d224:      	b.gt	0xd27c <_stogir.vector-lanes.operands+0x5c4>
    d228:      	add	x16, sp, #0x40
    d22c:      	ldr	w0, [x16]
    d230:      	uxtb	w0, w0
    d234:      	cmp	x0, #0x48
    d238:      	b.eq	0xd27c <_stogir.vector-lanes.operands+0x5c4>
    d23c:      	cmp	x0, #0x46
    d240:      	b.eq	0xd27c <_stogir.vector-lanes.operands+0x5c4>
    d244:      	mov	x0, x20
    d248:      	mov	x1, x28
    d24c:      	b	0xd28c <_stogir.vector-lanes.operands+0x5d4>
    d250:      	ldr	w0, [sp, #0xb8]
    d254:      	uxtb	w16, w0
    d258:      	cmp	w16, wzr
    d25c:      	b.eq	0xd05c <_stogir.vector-lanes.operands+0x3a4>
    d260:      	mov	x0, x20
    d264:      	mov	x1, x22
    d268:      	b	0xd06c <_stogir.vector-lanes.operands+0x3b4>
    d26c:      	mov	x0, x2
    d270:      	mov	x20, x0
    d274:      	mov	x22, x1
    d278:      	b	0xd184 <_stogir.vector-lanes.operands+0x4cc>
    d27c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d27c:  ARM64_RELOC_PAGE21	l_stogir.492
    d280:      	ldr	x16, [x16]
		000000000000d280:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    d284:      	orr	x0, x16, xzr
    d288:      	mov	x1, #0x2b               ; =43
    d28c:      	cmp	x22, #0x0
    d290:      	b.ge	0xd2bc <_stogir.vector-lanes.operands+0x604>
    d294:      	add	x16, sp, #0x40
    d298:      	ldr	w2, [x16]
    d29c:      	uxtb	w3, w2
    d2a0:      	ubfx	x2, x2, #8, #8
    d2a4:      	cmp	x3, x2
    d2a8:      	b.eq	0xd380 <_stogir.vector-lanes.operands+0x6c8>
    d2ac:      	cmp	x3, #0x49
    d2b0:      	b.eq	0xd380 <_stogir.vector-lanes.operands+0x6c8>
    d2b4:      	movz	x2, #0x0, lsl #48
    d2b8:      	b	0xd308 <_stogir.vector-lanes.operands+0x650>
    d2bc:      	mov	x2, x0
    d2c0:      	movz	x0, #0x0, lsl #48
    d2c4:      	cmp	x0, #0x0
    d2c8:      	b.eq	0xd26c <_stogir.vector-lanes.operands+0x5b4>
    d2cc:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d2cc:  ARM64_RELOC_PAGE21	l_stogir.493
    d2d0:      	ldr	x16, [x16]
		000000000000d2d0:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    d2d4:      	orr	x0, x16, xzr
    d2d8:      	mov	x1, #0x28               ; =40
    d2dc:      	b	0xd270 <_stogir.vector-lanes.operands+0x5b8>
    d2e0:      	movn	x4, #0x0, lsl #48
    d2e4:      	ubfx	x2, x2, #0, #32
    d2e8:      	ubfx	x3, x3, #0, #32
    d2ec:      	lsl	x3, x3, #32
    d2f0:      	orr	x2, x3, x2
    d2f4:      	lsr	w4, w4, #0
    d2f8:      	sxtw	x4, w4
    d2fc:      	cmp	x2, x4
    d300:      	cset	w2, hs
    d304:      	ubfx	x2, x2, #0, #8
    d308:      	fmov	d31, x0
    d30c:      	mov	x0, x2
    d310:      	fmov	x2, d31
    d314:      	b	0xd2c4 <_stogir.vector-lanes.operands+0x60c>
    d318:      	add	x16, sp, #0x50
    d31c:      	ldr	x0, [x16, #0x8]
    d320:      	uxtb	w1, w0
    d324:      	cmp	x1, #0x48
    d328:      	b.eq	0xd36c <_stogir.vector-lanes.operands+0x6b4>
    d32c:      	cmp	x1, #0x46
    d330:      	b.eq	0xd36c <_stogir.vector-lanes.operands+0x6b4>
    d334:      	ldr	w1, [sp, #0xb0]
    d338:      	lsr	w1, w1, #0
    d33c:      	lsr	w0, w0, #0
    d340:      	ubfx	x0, x0, #8, #8
    d344:      	lsr	w0, w0, #0
    d348:      	mov	w2, w1
    d34c:      	mov	w1, w0
    d350:      	ldr	w0, [sp, #0x88]
    d354:      	bl	0xd354 <_stogir.vector-lanes.operands+0x69c>
		000000000000d354:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d358:      	cmp	x0, #0x0
    d35c:      	b.eq	0xd36c <_stogir.vector-lanes.operands+0x6b4>
    d360:      	mov	x0, x20
    d364:      	mov	x1, x22
    d368:      	b	0xd37c <_stogir.vector-lanes.operands+0x6c4>
    d36c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d36c:  ARM64_RELOC_PAGE21	l_stogir.494
    d370:      	ldr	x16, [x16]
		000000000000d370:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    d374:      	orr	x0, x16, xzr
    d378:      	mov	x1, #0x27               ; =39
    d37c:      	b	0xd1e4 <_stogir.vector-lanes.operands+0x52c>
    d380:      	add	x16, sp, #0x40
    d384:      	ldr	w2, [x16, #0x8]
    d388:      	add	x16, sp, #0x40
    d38c:      	ldr	w3, [x16, #0xc]
    d390:      	uxtb	w16, w24
    d394:      	cmp	w16, wzr
    d398:      	b.eq	0xd3f0 <_stogir.vector-lanes.operands+0x738>
    d39c:      	uxtb	w16, w25
    d3a0:      	cmp	w16, wzr
    d3a4:      	b.eq	0xd3f0 <_stogir.vector-lanes.operands+0x738>
    d3a8:      	uxtb	w16, w26
    d3ac:      	cmp	w16, wzr
    d3b0:      	b.eq	0xd3f0 <_stogir.vector-lanes.operands+0x738>
    d3b4:      	uxtb	w16, w27
    d3b8:      	cmp	w16, wzr
    d3bc:      	b.eq	0xd3f0 <_stogir.vector-lanes.operands+0x738>
    d3c0:      	ubfx	x4, x23, #4, #32
    d3c4:      	sxtw	x4, w4
    d3c8:      	sub	x4, x4, #0x1
    d3cc:      	lsr	w4, w4, #0
    d3d0:      	sxtw	x4, w4
    d3d4:      	mov	x16, #0x1               ; =1
    d3d8:      	lsl	x4, x16, x4
    d3dc:      	lsr	w4, w4, #0
    d3e0:      	sxtw	x4, w4
    d3e4:      	b	0xd2e4 <_stogir.vector-lanes.operands+0x62c>
    d3e8:      	brk	#0
    d3ec:      	b	0xd3e8 <_stogir.vector-lanes.operands+0x730>
    d3f0:      	cmp	x23, #0x0
    d3f4:      	b.lt	0xd2e0 <_stogir.vector-lanes.operands+0x628>
    d3f8:      	cmp	x23, #0xd
    d3fc:      	b.gt	0xd2e0 <_stogir.vector-lanes.operands+0x628>
    d400:      	cmp	x23, #0x0
    d404:      	cset	w4, eq
    d408:      	uxtb	w16, w4
    d40c:      	cmp	w16, wzr
    d410:      	cset	x4, eq
    d414:      	b	0xd2e4 <_stogir.vector-lanes.operands+0x62c>
    d418:      	uxtb	w7, w7
    d41c:      	cmp	x7, #0x48
    d420:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    d424:      	cmp	x7, #0x46
    d428:      	b.eq	0xcf58 <_stogir.vector-lanes.operands+0x2a0>
    d42c:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d42c:  ARM64_RELOC_PAGE21	l_stogir.495
    d430:      	ldr	x16, [x16]
		000000000000d430:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    d434:      	orr	x4, x16, xzr
    d438:      	mov	x28, x4
    d43c:      	movz	x4, #0x0, lsl #48
    d440:      	b	0xcf6c <_stogir.vector-lanes.operands+0x2b4>
    d444:      	brk	#0
    d448:      	b	0xd444 <_stogir.vector-lanes.operands+0x78c>
    d44c:      	brk	#0
    d450:      	b	0xd44c <_stogir.vector-lanes.operands+0x794>
    d454:      	mov	x1, x8
    d458:      	mov	w8, w9
    d45c:      	b	0xcfbc <_stogir.vector-lanes.operands+0x304>
    d460:      	str	x21, [sp, #0x98]
    d464:      	str	x1, [sp, #0xa0]
    d468:      	str	x0, [sp, #0x80]
    d46c:      	str	w3, [sp, #0xb0]
    d470:      	mov	w21, w6
    d474:      	str	w22, [sp, #0x88]
    d478:      	mov	x22, x7
    d47c:      	str	w8, [sp, #0xb8]
    d480:      	str	x28, [sp, #0x90]
    d484:      	mov	w28, w5
    d488:      	str	x4, [sp, #0xa8]
    d48c:      	b	0xd0c0 <_stogir.vector-lanes.operands+0x408>

000000000000d490 <_stogir.vector-comparison.operation?>:
    d490:      	sxtw	x0, w0
    d494:      	cmp	x0, #0xe
    d498:      	b.lt	0xd4ac <_stogir.vector-comparison.operation?+0x1c>
    d49c:      	cmp	x0, #0x19
    d4a0:      	cset	w0, le
    d4a4:      	ubfx	x0, x0, #0, #8
    d4a8:      	b	0xd4b0 <_stogir.vector-comparison.operation?+0x20>
    d4ac:      	movz	x0, #0x0, lsl #48
    d4b0:      	ret

000000000000d4b4 <_stogir.vector-comparison.operands>:
    d4b4:      	sub	sp, sp, #0xc0
    d4b8:      	str	x29, [sp]
    d4bc:      	str	x30, [sp, #0x8]
    d4c0:      	mov	x29, sp
    d4c4:      	str	x19, [sp, #0x70]
    d4c8:      	str	x20, [sp, #0x78]
    d4cc:      	str	x21, [sp, #0x80]
    d4d0:      	str	x22, [sp, #0x88]
    d4d4:      	str	x23, [sp, #0x90]
    d4d8:      	str	x24, [sp, #0x98]
    d4dc:      	str	x25, [sp, #0xa0]
    d4e0:      	str	x26, [sp, #0xa8]
    d4e4:      	str	x27, [sp, #0xb0]
    d4e8:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d4e8:  ARM64_RELOC_PAGE21	l_stogir.496
    d4ec:      	ldr	x16, [x16]
		000000000000d4ec:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    d4f0:      	orr	x19, x16, xzr
    d4f4:      	lsr	w4, w4, #0
    d4f8:      	mov	x20, x8
    d4fc:      	add	x8, sp, #0x10
    d500:      	mov	x21, x0
    d504:      	mov	w22, w1
    d508:      	mov	w1, w4
    d50c:      	mov	w23, w2
    d510:      	mov	w24, w3
    d514:      	mov	w25, w5
    d518:      	bl	0xd518 <_stogir.vector-comparison.operands+0x64>
		000000000000d518:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d51c:      	add	x16, sp, #0x10
    d520:      	ldr	w0, [x16]
    d524:      	lsr	x16, x0, #0
    d528:      	cmp	x16, #0x1
    d52c:      	b.eq	0xd548 <_stogir.vector-comparison.operands+0x94>
    d530:      	b.lo	0xd538 <_stogir.vector-comparison.operands+0x84>
    d534:      	b	0xd54c <_stogir.vector-comparison.operands+0x98>
    d538:      	cmp	x16, #0x0
    d53c:      	b.eq	0xd544 <_stogir.vector-comparison.operands+0x90>
    d540:      	b	0xd54c <_stogir.vector-comparison.operands+0x98>
    d544:      	b	0xd550 <_stogir.vector-comparison.operands+0x9c>
    d548:      	b	0xd59c <_stogir.vector-comparison.operands+0xe8>
    d54c:      	b	0xd724 <_stogir.vector-comparison.operands+0x270>
    d550:      	mov	x1, x19
    d554:      	mov	x0, #0x1                ; =1
    d558:      	mov	x2, #0x21               ; =33
    d55c:      	str	x0, [x20]
    d560:      	str	x1, [x20, #0x8]
    d564:      	str	x2, [x20, #0x10]
    d568:      	ldr	x19, [sp, #0x70]
    d56c:      	ldr	x20, [sp, #0x78]
    d570:      	ldr	x21, [sp, #0x80]
    d574:      	ldr	x22, [sp, #0x88]
    d578:      	ldr	x23, [sp, #0x90]
    d57c:      	ldr	x24, [sp, #0x98]
    d580:      	ldr	x25, [sp, #0xa0]
    d584:      	ldr	x26, [sp, #0xa8]
    d588:      	ldr	x27, [sp, #0xb0]
    d58c:      	ldr	x29, [sp]
    d590:      	ldr	x30, [sp, #0x8]
    d594:      	add	sp, sp, #0xc0
    d598:      	ret
    d59c:      	lsr	w25, w25, #0
    d5a0:      	add	x16, sp, #0x10
    d5a4:      	ldr	x26, [x16, #0x8]
    d5a8:      	add	x8, sp, #0x40
    d5ac:      	mov	x0, x21
    d5b0:      	mov	w1, w25
    d5b4:      	bl	0xd5b4 <_stogir.vector-comparison.operands+0x100>
		000000000000d5b4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d5b8:      	add	x16, sp, #0x40
    d5bc:      	ldr	w0, [x16]
    d5c0:      	lsr	x16, x0, #0
    d5c4:      	cmp	x16, #0x1
    d5c8:      	b.eq	0xd5e4 <_stogir.vector-comparison.operands+0x130>
    d5cc:      	b.lo	0xd5d4 <_stogir.vector-comparison.operands+0x120>
    d5d0:      	b	0xd5e8 <_stogir.vector-comparison.operands+0x134>
    d5d4:      	cmp	x16, #0x0
    d5d8:      	b.eq	0xd5e0 <_stogir.vector-comparison.operands+0x12c>
    d5dc:      	b	0xd5e8 <_stogir.vector-comparison.operands+0x134>
    d5e0:      	b	0xd5ec <_stogir.vector-comparison.operands+0x138>
    d5e4:      	b	0xd5fc <_stogir.vector-comparison.operands+0x148>
    d5e8:      	b	0xd72c <_stogir.vector-comparison.operands+0x278>
    d5ec:      	mov	x1, x19
    d5f0:      	mov	x0, #0x1                ; =1
    d5f4:      	mov	x2, #0x21               ; =33
    d5f8:      	b	0xd55c <_stogir.vector-comparison.operands+0xa8>
    d5fc:      	sxtw	x0, w24
    d600:      	add	x16, sp, #0x40
    d604:      	ldr	x19, [x16, #0x8]
    d608:      	cmp	x0, #0x4
    d60c:      	b.eq	0xd634 <_stogir.vector-comparison.operands+0x180>
    d610:      	cmp	x0, #0x8
    d614:      	b.eq	0xd634 <_stogir.vector-comparison.operands+0x180>
    d618:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000d618:  ARM64_RELOC_PAGE21	l_stogir.497
    d61c:      	ldr	x16, [x16]
		000000000000d61c:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    d620:      	orr	x0, x16, xzr
    d624:      	mov	x1, x0
    d628:      	mov	x0, #0x1                ; =1
    d62c:      	mov	x2, #0x33               ; =51
    d630:      	b	0xd5f8 <_stogir.vector-comparison.operands+0x144>
    d634:      	lsr	w22, w22, #0
    d638:      	lsr	w0, w26, #0
    d63c:      	ubfx	x21, x0, #8, #8
    d640:      	orr	x0, x21, xzr
    d644:      	lsr	w0, w0, #0
    d648:      	mov	w1, w0
    d64c:      	mov	w0, w22
    d650:      	bl	0xd650 <_stogir.vector-comparison.operands+0x19c>
		000000000000d650:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    d654:      	cmp	x0, #0x0
    d658:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d65c:      	lsr	w0, w19, #0
    d660:      	ubfx	x0, x0, #8, #8
    d664:      	cmp	x21, x0
    d668:      	b.ne	0xd618 <_stogir.vector-comparison.operands+0x164>
    d66c:      	uxtb	w26, w26
    d670:      	cmp	x26, #0x48
    d674:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d678:      	cmp	x26, #0x46
    d67c:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d680:      	uxtb	w19, w19
    d684:      	cmp	x19, #0x48
    d688:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d68c:      	cmp	x19, #0x46
    d690:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d694:      	sxtw	x23, w23
    d698:      	cmp	x23, #0xf
    d69c:      	cset	w0, gt
    d6a0:      	uxtb	w16, w0
    d6a4:      	cmp	w16, wzr
    d6a8:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d6ac:      	cmp	x23, #0x80
    d6b0:      	cset	w1, lt
    d6b4:      	uxtb	w16, w1
    d6b8:      	cmp	w16, wzr
    d6bc:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d6c0:      	and	x2, x23, #0xf
    d6c4:      	lsr	w2, w2, #0
    d6c8:      	sxtw	x2, w2
    d6cc:      	cmp	x2, #0x1
    d6d0:      	cset	w3, ge
    d6d4:      	uxtb	w16, w3
    d6d8:      	cmp	w16, wzr
    d6dc:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d6e0:      	cmp	x2, #0xd
    d6e4:      	cset	w4, le
    d6e8:      	uxtb	w16, w4
    d6ec:      	cmp	w16, wzr
    d6f0:      	b.eq	0xd618 <_stogir.vector-comparison.operands+0x164>
    d6f4:      	cmp	x23, #0x0
    d6f8:      	cset	w5, ge
    d6fc:      	cmp	x23, #0xd
    d700:      	cset	w6, le
    d704:      	uxtb	w16, w5
    d708:      	cmp	w16, wzr
    d70c:      	b.eq	0xd734 <_stogir.vector-comparison.operands+0x280>
    d710:      	uxtb	w16, w6
    d714:      	cmp	w16, wzr
    d718:      	b.eq	0xd734 <_stogir.vector-comparison.operands+0x280>
    d71c:      	mov	x7, x2
    d720:      	b	0xd768 <_stogir.vector-comparison.operands+0x2b4>
    d724:      	brk	#0
    d728:      	b	0xd724 <_stogir.vector-comparison.operands+0x270>
    d72c:      	brk	#0
    d730:      	b	0xd72c <_stogir.vector-comparison.operands+0x278>
    d734:      	uxtb	w16, w0
    d738:      	cmp	w16, wzr
    d73c:      	b.eq	0xd764 <_stogir.vector-comparison.operands+0x2b0>
    d740:      	uxtb	w16, w1
    d744:      	cmp	w16, wzr
    d748:      	b.eq	0xd764 <_stogir.vector-comparison.operands+0x2b0>
    d74c:      	uxtb	w16, w3
    d750:      	cmp	w16, wzr
    d754:      	b.eq	0xd764 <_stogir.vector-comparison.operands+0x2b0>
    d758:      	uxtb	w16, w4
    d75c:      	cmp	w16, wzr
    d760:      	b.ne	0xd71c <_stogir.vector-comparison.operands+0x268>
    d764:      	movn	x7, #0x0, lsl #48
    d768:      	lsr	w7, w7, #0
    d76c:      	sxtw	x7, w7
    d770:      	cmp	x7, #0x1
    d774:      	b.lt	0xd618 <_stogir.vector-comparison.operands+0x164>
    d778:      	cmp	x7, #0xb
    d77c:      	b.gt	0xd618 <_stogir.vector-comparison.operands+0x164>
    d780:      	uxtb	w16, w0
    d784:      	cmp	w16, wzr
    d788:      	b.eq	0xd7d8 <_stogir.vector-comparison.operands+0x324>
    d78c:      	uxtb	w16, w1
    d790:      	cmp	w16, wzr
    d794:      	b.eq	0xd7d8 <_stogir.vector-comparison.operands+0x324>
    d798:      	uxtb	w16, w3
    d79c:      	cmp	w16, wzr
    d7a0:      	b.eq	0xd7d8 <_stogir.vector-comparison.operands+0x324>
    d7a4:      	uxtb	w16, w4
    d7a8:      	cmp	w16, wzr
    d7ac:      	b.eq	0xd7d8 <_stogir.vector-comparison.operands+0x324>
    d7b0:      	ubfx	x7, x23, #4, #32
    d7b4:      	sxtw	x7, w7
    d7b8:      	sub	x7, x7, #0x1
    d7bc:      	lsr	w7, w7, #0
    d7c0:      	sxtw	x7, w7
    d7c4:      	mov	x16, #0x1               ; =1
    d7c8:      	lsl	x7, x16, x7
    d7cc:      	lsr	w7, w7, #0
    d7d0:      	sxtw	x7, w7
    d7d4:      	b	0xd848 <_stogir.vector-comparison.operands+0x394>
    d7d8:      	uxtb	w16, w5
    d7dc:      	cmp	w16, wzr
    d7e0:      	b.eq	0xd844 <_stogir.vector-comparison.operands+0x390>
    d7e4:      	uxtb	w16, w6
    d7e8:      	cmp	w16, wzr
    d7ec:      	b.eq	0xd844 <_stogir.vector-comparison.operands+0x390>
    d7f0:      	cmp	x23, #0x0
    d7f4:      	cset	w7, eq
    d7f8:      	uxtb	w16, w7
    d7fc:      	cmp	w16, wzr
    d800:      	cset	x7, eq
    d804:      	b	0xd848 <_stogir.vector-comparison.operands+0x394>
    d808:      	movn	x8, #0x0, lsl #48
    d80c:      	lsr	w7, w7, #0
    d810:      	sxtw	x7, w7
    d814:      	lsr	w8, w8, #0
    d818:      	sxtw	x8, w8
    d81c:      	cmp	x7, x8
    d820:      	b.ne	0xd618 <_stogir.vector-comparison.operands+0x164>
    d824:      	uxtb	w16, w5
    d828:      	cmp	w16, wzr
    d82c:      	b.eq	0xd8f8 <_stogir.vector-comparison.operands+0x444>
    d830:      	uxtb	w16, w6
    d834:      	cmp	w16, wzr
    d838:      	b.eq	0xd8f8 <_stogir.vector-comparison.operands+0x444>
    d83c:      	mov	x0, x2
    d840:      	b	0xd92c <_stogir.vector-comparison.operands+0x478>
    d844:      	movn	x7, #0x0, lsl #48
    d848:      	and	x8, x21, #0xf
    d84c:      	cmp	x21, #0xd
    d850:      	cset	w19, le
    d854:      	cmp	x21, #0xf
    d858:      	cset	w22, gt
    d85c:      	cmp	x21, #0x80
    d860:      	cset	w23, lt
    d864:      	lsr	w8, w8, #0
    d868:      	sxtw	x25, w8
    d86c:      	cmp	x25, #0x1
    d870:      	cset	w26, ge
    d874:      	cmp	x25, #0xd
    d878:      	cset	w27, le
    d87c:      	uxtb	w16, w22
    d880:      	cmp	w16, wzr
    d884:      	b.eq	0xd8d4 <_stogir.vector-comparison.operands+0x420>
    d888:      	uxtb	w16, w23
    d88c:      	cmp	w16, wzr
    d890:      	b.eq	0xd8d4 <_stogir.vector-comparison.operands+0x420>
    d894:      	uxtb	w16, w26
    d898:      	cmp	w16, wzr
    d89c:      	b.eq	0xd8d4 <_stogir.vector-comparison.operands+0x420>
    d8a0:      	uxtb	w16, w27
    d8a4:      	cmp	w16, wzr
    d8a8:      	b.eq	0xd8d4 <_stogir.vector-comparison.operands+0x420>
    d8ac:      	ubfx	x8, x21, #4, #32
    d8b0:      	sxtw	x8, w8
    d8b4:      	sub	x8, x8, #0x1
    d8b8:      	lsr	w8, w8, #0
    d8bc:      	sxtw	x8, w8
    d8c0:      	mov	x16, #0x1               ; =1
    d8c4:      	lsl	x8, x16, x8
    d8c8:      	lsr	w8, w8, #0
    d8cc:      	sxtw	x8, w8
    d8d0:      	b	0xd80c <_stogir.vector-comparison.operands+0x358>
    d8d4:      	uxtb	w16, w19
    d8d8:      	cmp	w16, wzr
    d8dc:      	b.eq	0xd808 <_stogir.vector-comparison.operands+0x354>
    d8e0:      	cmp	x21, #0x0
    d8e4:      	cset	w8, eq
    d8e8:      	uxtb	w16, w8
    d8ec:      	cmp	w16, wzr
    d8f0:      	cset	x8, eq
    d8f4:      	b	0xd80c <_stogir.vector-comparison.operands+0x358>
    d8f8:      	uxtb	w16, w0
    d8fc:      	cmp	w16, wzr
    d900:      	b.eq	0xd928 <_stogir.vector-comparison.operands+0x474>
    d904:      	uxtb	w16, w1
    d908:      	cmp	w16, wzr
    d90c:      	b.eq	0xd928 <_stogir.vector-comparison.operands+0x474>
    d910:      	uxtb	w16, w3
    d914:      	cmp	w16, wzr
    d918:      	b.eq	0xd928 <_stogir.vector-comparison.operands+0x474>
    d91c:      	uxtb	w16, w4
    d920:      	cmp	w16, wzr
    d924:      	b.ne	0xd83c <_stogir.vector-comparison.operands+0x388>
    d928:      	movn	x0, #0x0, lsl #48
    d92c:      	lsr	w24, w24, #0
    d930:      	lsr	w0, w0, #0
    d934:      	lsr	w0, w0, #0
    d938:      	mov	w1, w24
    d93c:      	bl	0xd93c <_stogir.vector-comparison.operands+0x488>
		000000000000d93c:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    d940:      	uxtb	w16, w19
    d944:      	cmp	w16, wzr
    d948:      	b.ne	0xd97c <_stogir.vector-comparison.operands+0x4c8>
    d94c:      	uxtb	w16, w22
    d950:      	cmp	w16, wzr
    d954:      	b.eq	0xd9c0 <_stogir.vector-comparison.operands+0x50c>
    d958:      	uxtb	w16, w23
    d95c:      	cmp	w16, wzr
    d960:      	b.eq	0xd9c0 <_stogir.vector-comparison.operands+0x50c>
    d964:      	uxtb	w16, w26
    d968:      	cmp	w16, wzr
    d96c:      	b.eq	0xd9c0 <_stogir.vector-comparison.operands+0x50c>
    d970:      	uxtb	w16, w27
    d974:      	cmp	w16, wzr
    d978:      	b.eq	0xd9c0 <_stogir.vector-comparison.operands+0x50c>
    d97c:      	mov	x1, x25
    d980:      	lsr	w0, w0, #0
    d984:      	sxtw	x19, w0
    d988:      	lsr	w1, w1, #0
    d98c:      	lsr	w1, w1, #0
    d990:      	mov	w0, w1
    d994:      	mov	w1, w24
    d998:      	bl	0xd998 <_stogir.vector-comparison.operands+0x4e4>
		000000000000d998:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    d99c:      	lsr	w0, w0, #0
    d9a0:      	sxtw	x0, w0
    d9a4:      	cmp	x19, x0
    d9a8:      	b.ne	0xd618 <_stogir.vector-comparison.operands+0x164>
    d9ac:      	and	x0, x21, #0xffffffff
    d9b0:      	mov	x1, x0
    d9b4:      	movz	x0, #0x0, lsl #48
    d9b8:      	movz	x2, #0x0, lsl #48
    d9bc:      	b	0xd630 <_stogir.vector-comparison.operands+0x17c>
    d9c0:      	movn	x1, #0x0, lsl #48
    d9c4:      	b	0xd980 <_stogir.vector-comparison.operands+0x4cc>

000000000000d9c8 <_stogir.vector-arithmetic.operation?>:
    d9c8:      	sxtw	x0, w0
    d9cc:      	cmp	x0, #0x1f
    d9d0:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9d4:      	cmp	x0, #0x20
    d9d8:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9dc:      	cmp	x0, #0x2d
    d9e0:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9e4:      	cmp	x0, #0x36
    d9e8:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9ec:      	cmp	x0, #0x37
    d9f0:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9f4:      	cmp	x0, #0x38
    d9f8:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    d9fc:      	cmp	x0, #0x39
    da00:      	b.eq	0xda2c <_stogir.vector-arithmetic.operation?+0x64>
    da04:      	cmp	x0, #0x3a
    da08:      	b.eq	0xda34 <_stogir.vector-arithmetic.operation?+0x6c>
    da0c:      	cmp	x0, #0x3b
    da10:      	b.eq	0xda34 <_stogir.vector-arithmetic.operation?+0x6c>
    da14:      	cmp	x0, #0x31
    da18:      	b.lt	0xda4c <_stogir.vector-arithmetic.operation?+0x84>
    da1c:      	cmp	x0, #0x35
    da20:      	b.gt	0xda4c <_stogir.vector-arithmetic.operation?+0x84>
    da24:      	mov	x0, #0x1                ; =1
    da28:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da2c:      	mov	x0, #0x1                ; =1
    da30:      	ret
    da34:      	mov	x0, #0x1                ; =1
    da38:      	b	0xda30 <_stogir.vector-arithmetic.operation?+0x68>
    da3c:      	cmp	x0, #0x30
    da40:      	cset	w0, eq
    da44:      	ubfx	x0, x0, #0, #8
    da48:      	b	0xda38 <_stogir.vector-arithmetic.operation?+0x70>
    da4c:      	cmp	x0, #0x1a
    da50:      	b.ne	0xda5c <_stogir.vector-arithmetic.operation?+0x94>
    da54:      	mov	x0, #0x1                ; =1
    da58:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da5c:      	cmp	x0, #0x1b
    da60:      	b.ne	0xda6c <_stogir.vector-arithmetic.operation?+0xa4>
    da64:      	mov	x0, #0x1                ; =1
    da68:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da6c:      	cmp	x0, #0x1c
    da70:      	b.ne	0xda7c <_stogir.vector-arithmetic.operation?+0xb4>
    da74:      	mov	x0, #0x1                ; =1
    da78:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da7c:      	cmp	x0, #0x1d
    da80:      	b.ne	0xda8c <_stogir.vector-arithmetic.operation?+0xc4>
    da84:      	mov	x0, #0x1                ; =1
    da88:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da8c:      	cmp	x0, #0x1e
    da90:      	b.ne	0xda9c <_stogir.vector-arithmetic.operation?+0xd4>
    da94:      	mov	x0, #0x1                ; =1
    da98:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    da9c:      	cmp	x0, #0x2e
    daa0:      	b.ne	0xdaac <_stogir.vector-arithmetic.operation?+0xe4>
    daa4:      	mov	x0, #0x1                ; =1
    daa8:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>
    daac:      	cmp	x0, #0x2f
    dab0:      	b.ne	0xda3c <_stogir.vector-arithmetic.operation?+0x74>
    dab4:      	mov	x0, #0x1                ; =1
    dab8:      	b	0xda48 <_stogir.vector-arithmetic.operation?+0x80>

000000000000dabc <_stogir.vector-arithmetic.unary?>:
    dabc:      	sxtw	x0, w0
    dac0:      	cmp	x0, #0x1f
    dac4:      	b.ne	0xdae0 <_stogir.vector-arithmetic.unary?+0x24>
    dac8:      	mov	x0, #0x1                ; =1
    dacc:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>
    dad0:      	cmp	x0, #0x39
    dad4:      	cset	w0, eq
    dad8:      	ubfx	x0, x0, #0, #8
    dadc:      	ret
    dae0:      	cmp	x0, #0x20
    dae4:      	b.ne	0xdaf0 <_stogir.vector-arithmetic.unary?+0x34>
    dae8:      	mov	x0, #0x1                ; =1
    daec:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>
    daf0:      	cmp	x0, #0x2d
    daf4:      	b.ne	0xdb00 <_stogir.vector-arithmetic.unary?+0x44>
    daf8:      	mov	x0, #0x1                ; =1
    dafc:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>
    db00:      	cmp	x0, #0x36
    db04:      	b.ne	0xdb10 <_stogir.vector-arithmetic.unary?+0x54>
    db08:      	mov	x0, #0x1                ; =1
    db0c:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>
    db10:      	cmp	x0, #0x37
    db14:      	b.ne	0xdb20 <_stogir.vector-arithmetic.unary?+0x64>
    db18:      	mov	x0, #0x1                ; =1
    db1c:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>
    db20:      	cmp	x0, #0x38
    db24:      	b.ne	0xdad0 <_stogir.vector-arithmetic.unary?+0x14>
    db28:      	mov	x0, #0x1                ; =1
    db2c:      	b	0xdadc <_stogir.vector-arithmetic.unary?+0x20>

000000000000db30 <_stogir.vector-arithmetic.operands>:
    db30:      	sub	sp, sp, #0x80
    db34:      	str	x29, [sp]
    db38:      	str	x30, [sp, #0x8]
    db3c:      	mov	x29, sp
    db40:      	str	x19, [sp, #0x30]
    db44:      	str	x20, [sp, #0x38]
    db48:      	str	x21, [sp, #0x40]
    db4c:      	str	x22, [sp, #0x48]
    db50:      	str	x23, [sp, #0x50]
    db54:      	str	x24, [sp, #0x58]
    db58:      	str	x25, [sp, #0x60]
    db5c:      	str	x26, [sp, #0x68]
    db60:      	str	x27, [sp, #0x70]
    db64:      	str	x28, [sp, #0x78]
    db68:      	lsr	w1, w1, #0
    db6c:      	lsr	w2, w2, #0
    db70:      	mov	x19, x8
    db74:      	mov	x20, x0
    db78:      	mov	w0, w1
    db7c:      	mov	w21, w1
    db80:      	mov	w1, w2
    db84:      	mov	w22, w2
    db88:      	mov	w23, w3
    db8c:      	mov	w24, w4
    db90:      	mov	w25, w5
    db94:      	bl	0xdb94 <_stogir.vector-arithmetic.operands+0x64>
		000000000000db94:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    db98:      	cmp	x0, #0x0
    db9c:      	b.eq	0xdbb4 <_stogir.vector-arithmetic.operands+0x84>
    dba0:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000dba0:  ARM64_RELOC_PAGE21	l_stogir.498
    dba4:      	ldr	x16, [x16]
		000000000000dba4:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    dba8:      	orr	x0, x16, xzr
    dbac:      	movz	x1, #0x0, lsl #48
    dbb0:      	b	0xdbc4 <_stogir.vector-arithmetic.operands+0x94>
    dbb4:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000dbb4:  ARM64_RELOC_PAGE21	l_stogir.499
    dbb8:      	ldr	x16, [x16]
		000000000000dbb8:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    dbbc:      	orr	x0, x16, xzr
    dbc0:      	mov	x1, #0x37               ; =55
    dbc4:      	sxtw	x21, w21
    dbc8:      	sxtw	x22, w22
    dbcc:      	sxtw	x23, w23
    dbd0:      	sxtw	x24, w24
    dbd4:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000dbd4:  ARM64_RELOC_PAGE21	l_stogir.500
    dbd8:      	ldr	x16, [x16]
		000000000000dbd8:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    dbdc:      	orr	x2, x16, xzr
    dbe0:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000dbe0:  ARM64_RELOC_PAGE21	l_stogir.501
    dbe4:      	ldr	x16, [x16]
		000000000000dbe4:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    dbe8:      	orr	x3, x16, xzr
    dbec:      	add	x4, x20, #0x78
    dbf0:      	add	x5, x20, #0x28
    dbf4:      	add	x6, x20, #0x50
    dbf8:      	cmp	x21, #0x31
    dbfc:      	cset	w7, ge
    dc00:      	cmp	x21, #0x35
    dc04:      	cset	w8, le
    dc08:      	cmp	x21, #0x1f
    dc0c:      	cset	w9, eq
    dc10:      	cmp	x21, #0x20
    dc14:      	cset	w10, eq
    dc18:      	cmp	x21, #0x2d
    dc1c:      	cset	w11, eq
    dc20:      	cmp	x21, #0x36
    dc24:      	cset	w12, eq
    dc28:      	cmp	x21, #0x37
    dc2c:      	cset	w13, eq
    dc30:      	cmp	x21, #0x38
    dc34:      	cset	w14, eq
    dc38:      	cmp	x21, #0x39
    dc3c:      	cset	w15, eq
    dc40:      	mov	x26, x1
    dc44:      	mov	x1, x0
    dc48:      	movz	x0, #0x0, lsl #48
    dc4c:      	b	0xdd24 <_stogir.vector-arithmetic.operands+0x1f4>
    dc50:      	movz	x2, #0x0, lsl #48
    dc54:      	b	0xdc64 <_stogir.vector-arithmetic.operands+0x134>
    dc58:      	movz	x2, #0x0, lsl #48
    dc5c:      	b	0xdc6c <_stogir.vector-arithmetic.operands+0x13c>
    dc60:      	movz	x2, #0x0, lsl #48
    dc64:      	b	0xdc7c <_stogir.vector-arithmetic.operands+0x14c>
    dc68:      	movz	x2, #0x0, lsl #48
    dc6c:      	str	x4, [sp, #0x20]
    dc70:      	str	x5, [sp, #0x28]
    dc74:      	b	0xdc7c <_stogir.vector-arithmetic.operands+0x14c>
    dc78:      	movz	x2, #0x0, lsl #48
    dc7c:      	cmp	x2, #0x0
    dc80:      	b.eq	0xdcb8 <_stogir.vector-arithmetic.operands+0x188>
    dc84:      	uxtb	w16, w28
    dc88:      	cmp	w16, wzr
    dc8c:      	b.eq	0xdca0 <_stogir.vector-arithmetic.operands+0x170>
    dc90:      	ldr	x2, [x20]
    dc94:      	add	x1, x2, x1, lsl #4
    dc98:      	ldr	x1, [x1]
    dc9c:      	b	0xdcac <_stogir.vector-arithmetic.operands+0x17c>
    dca0:      	ldr	x1, [x20, #0x28]
    dca4:      	add	x1, x1, x3, lsl #4
    dca8:      	ldr	x1, [x1]
    dcac:      	mov	x2, x1
    dcb0:      	mov	x1, #0x1                ; =1
    dcb4:      	b	0xdcc0 <_stogir.vector-arithmetic.operands+0x190>
    dcb8:      	movz	x1, #0x0, lsl #48
    dcbc:      	movz	x2, #0x0, lsl #48
    dcc0:      	lsr	w1, w1, #0
    dcc4:      	lsr	x16, x1, #0
    dcc8:      	cmp	x16, #0x1
    dccc:      	b.eq	0xdce8 <_stogir.vector-arithmetic.operands+0x1b8>
    dcd0:      	b.lo	0xdcd8 <_stogir.vector-arithmetic.operands+0x1a8>
    dcd4:      	b	0xdcec <_stogir.vector-arithmetic.operands+0x1bc>
    dcd8:      	cmp	x16, #0x0
    dcdc:      	b.eq	0xdce4 <_stogir.vector-arithmetic.operands+0x1b4>
    dce0:      	b	0xdcec <_stogir.vector-arithmetic.operands+0x1bc>
    dce4:      	b	0xdcf0 <_stogir.vector-arithmetic.operands+0x1c0>
    dce8:      	b	0xde60 <_stogir.vector-arithmetic.operands+0x330>
    dcec:      	b	0xe0a4 <_stogir.vector-arithmetic.operands+0x574>
    dcf0:      	ldr	x1, [sp, #0x10]
    dcf4:      	mov	x2, #0x21               ; =33
    dcf8:      	b	0xdd04 <_stogir.vector-arithmetic.operands+0x1d4>
    dcfc:      	ldr	x1, [sp, #0x18]
    dd00:      	mov	x2, #0x32               ; =50
    dd04:      	add	x0, x0, #0x1
    dd08:      	lsr	w0, w0, #0
    dd0c:      	sxtw	x0, w0
    dd10:      	ldr	x3, [sp, #0x18]
    dd14:      	ldr	x4, [sp, #0x20]
    dd18:      	ldr	x5, [sp, #0x28]
    dd1c:      	mov	x26, x2
    dd20:      	ldr	x2, [sp, #0x10]
    dd24:      	uxtb	w16, w9
    dd28:      	cmp	w16, wzr
    dd2c:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd30:      	uxtb	w16, w10
    dd34:      	cmp	w16, wzr
    dd38:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd3c:      	uxtb	w16, w11
    dd40:      	cmp	w16, wzr
    dd44:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd48:      	uxtb	w16, w12
    dd4c:      	cmp	w16, wzr
    dd50:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd54:      	uxtb	w16, w13
    dd58:      	cmp	w16, wzr
    dd5c:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd60:      	uxtb	w16, w14
    dd64:      	cmp	w16, wzr
    dd68:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd6c:      	uxtb	w16, w15
    dd70:      	cmp	w16, wzr
    dd74:      	b.ne	0xdd88 <_stogir.vector-arithmetic.operands+0x258>
    dd78:      	mov	x27, x26
    dd7c:      	mov	x26, x1
    dd80:      	mov	x1, #0x2                ; =2
    dd84:      	b	0xdd94 <_stogir.vector-arithmetic.operands+0x264>
    dd88:      	mov	x27, x26
    dd8c:      	mov	x26, x1
    dd90:      	mov	x1, #0x1                ; =1
    dd94:      	cmp	x0, x1
    dd98:      	b.ge	0xdec0 <_stogir.vector-arithmetic.operands+0x390>
    dd9c:      	cmp	x0, #0x0
    dda0:      	b.ne	0xddac <_stogir.vector-arithmetic.operands+0x27c>
    dda4:      	mov	x1, x23
    dda8:      	b	0xddb0 <_stogir.vector-arithmetic.operands+0x280>
    ddac:      	mov	x1, x24
    ddb0:      	lsr	w1, w1, #0
    ddb4:      	sxtw	x1, w1
    ddb8:      	cmp	x1, #0x0
    ddbc:      	cset	w28, gt
    ddc0:      	str	x2, [sp, #0x10]
    ddc4:      	movz	x16, #0x0, lsl #48
    ddc8:      	sub	x2, x16, x1
    ddcc:      	str	x3, [sp, #0x18]
    ddd0:      	sub	x3, x2, #0x1
    ddd4:      	uxtb	w16, w28
    ddd8:      	cmp	w16, wzr
    dddc:      	b.eq	0xde18 <_stogir.vector-arithmetic.operands+0x2e8>
    dde0:      	ldr	x2, [x20, #0x8]
    dde4:      	cmp	x1, x2
    dde8:      	b.ge	0xdc68 <_stogir.vector-arithmetic.operands+0x138>
    ddec:      	ldr	x2, [x4, #0x8]
    ddf0:      	cmp	x1, x2
    ddf4:      	b.ge	0xdc58 <_stogir.vector-arithmetic.operands+0x128>
    ddf8:      	ldr	x2, [x20, #0x78]
    ddfc:      	add	x2, x2, x1, lsl #2
    de00:      	ldr	w2, [x2]
    de04:      	sxtw	x2, w2
    de08:      	cmp	x2, #0x0
    de0c:      	cset	w2, ge
    de10:      	ubfx	x2, x2, #0, #8
    de14:      	b	0xdc5c <_stogir.vector-arithmetic.operands+0x12c>
    de18:      	cmp	x1, #0x0
    de1c:      	b.ge	0xe198 <_stogir.vector-arithmetic.operands+0x668>
    de20:      	str	x4, [sp, #0x20]
    de24:      	ldr	x4, [x5, #0x8]
    de28:      	str	x5, [sp, #0x28]
    de2c:      	ldr	x5, [x6, #0x8]
    de30:      	cmp	x4, x5
    de34:      	b.ne	0xdc60 <_stogir.vector-arithmetic.operands+0x130>
    de38:      	cmp	x2, x4
    de3c:      	b.gt	0xdc50 <_stogir.vector-arithmetic.operands+0x120>
    de40:      	ldr	x2, [x20, #0x50]
    de44:      	add	x2, x2, x3, lsl #2
    de48:      	ldr	w2, [x2]
    de4c:      	sxtw	x2, w2
    de50:      	cmp	x2, #0x0
    de54:      	cset	w2, gt
    de58:      	ubfx	x2, x2, #0, #8
    de5c:      	b	0xdc54 <_stogir.vector-arithmetic.operands+0x124>
    de60:      	lsr	w1, w2, #0
    de64:      	ubfx	x1, x1, #8, #8
    de68:      	cmp	x1, x22
    de6c:      	b.eq	0xdea0 <_stogir.vector-arithmetic.operands+0x370>
    de70:      	cmp	x0, #0x1
    de74:      	b.ne	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    de78:      	uxtb	w16, w7
    de7c:      	cmp	w16, wzr
    de80:      	b.eq	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    de84:      	uxtb	w16, w8
    de88:      	cmp	w16, wzr
    de8c:      	b.eq	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    de90:      	cmp	x1, #0x1
    de94:      	b.lt	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    de98:      	cmp	x1, #0xb
    de9c:      	b.gt	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    dea0:      	uxtb	w2, w2
    dea4:      	cmp	x2, #0x48
    dea8:      	b.eq	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    deac:      	cmp	x2, #0x46
    deb0:      	b.eq	0xdcfc <_stogir.vector-arithmetic.operands+0x1cc>
    deb4:      	mov	x1, x26
    deb8:      	mov	x2, x27
    debc:      	b	0xdd04 <_stogir.vector-arithmetic.operands+0x1d4>
    dec0:      	sxtw	x25, w25
    dec4:      	cmp	x25, #0x0
    dec8:      	b.ne	0xdedc <_stogir.vector-arithmetic.operands+0x3ac>
    decc:      	mov	x1, x26
    ded0:      	mov	x2, x27
    ded4:      	movz	x0, #0x0, lsl #48
    ded8:      	b	0xdee8 <_stogir.vector-arithmetic.operands+0x3b8>
    dedc:      	mov	x1, x26
    dee0:      	mov	x2, x27
    dee4:      	mov	x0, #0x1                ; =1
    dee8:      	cmp	x0, #0x0
    deec:      	b.eq	0xdf00 <_stogir.vector-arithmetic.operands+0x3d0>
    def0:      	cmp	x21, #0x1d
    def4:      	b.ne	0xdff0 <_stogir.vector-arithmetic.operands+0x4c0>
    def8:      	mov	x0, #0x1                ; =1
    defc:      	b	0xdffc <_stogir.vector-arithmetic.operands+0x4cc>
    df00:      	mov	x0, x1
    df04:      	mov	x1, x2
    df08:      	cmp	x1, #0x0
    df0c:      	b.ne	0xdf24 <_stogir.vector-arithmetic.operands+0x3f4>
    df10:      	and	x0, x22, #0xffffffff
    df14:      	mov	x1, x0
    df18:      	movz	x0, #0x0, lsl #48
    df1c:      	movz	x2, #0x0, lsl #48
    df20:      	b	0xdf30 <_stogir.vector-arithmetic.operands+0x400>
    df24:      	mov	x2, x1
    df28:      	mov	x1, x0
    df2c:      	mov	x0, #0x1                ; =1
    df30:      	str	x0, [x19]
    df34:      	str	x1, [x19, #0x8]
    df38:      	str	x2, [x19, #0x10]
    df3c:      	ldr	x19, [sp, #0x30]
    df40:      	ldr	x20, [sp, #0x38]
    df44:      	ldr	x21, [sp, #0x40]
    df48:      	ldr	x22, [sp, #0x48]
    df4c:      	ldr	x23, [sp, #0x50]
    df50:      	ldr	x24, [sp, #0x58]
    df54:      	ldr	x25, [sp, #0x60]
    df58:      	ldr	x26, [sp, #0x68]
    df5c:      	ldr	x27, [sp, #0x70]
    df60:      	ldr	x28, [sp, #0x78]
    df64:      	ldr	x29, [sp]
    df68:      	ldr	x30, [sp, #0x8]
    df6c:      	add	sp, sp, #0x80
    df70:      	ret
    df74:      	mov	x0, #0x1                ; =1
    df78:      	cmp	x0, #0x0
    df7c:      	b.eq	0xdf94 <_stogir.vector-arithmetic.operands+0x464>
    df80:      	adrp	x16, 0xd000 <_stogir.vector-lanes.operands+0x348>
		000000000000df80:  ARM64_RELOC_PAGE21	l_stogir.502
    df84:      	ldr	x16, [x16]
		000000000000df84:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    df88:      	orr	x0, x16, xzr
    df8c:      	mov	x1, #0x23               ; =35
    df90:      	b	0xdf08 <_stogir.vector-arithmetic.operands+0x3d8>
    df94:      	cmp	x25, #0x0
    df98:      	cset	w0, gt
    df9c:      	movz	x16, #0x0, lsl #48
    dfa0:      	sub	x3, x16, x25
    dfa4:      	sub	x4, x3, #0x1
    dfa8:      	uxtb	w16, w0
    dfac:      	cmp	w16, wzr
    dfb0:      	b.eq	0xe05c <_stogir.vector-arithmetic.operands+0x52c>
    dfb4:      	ldr	x3, [x20, #0x8]
    dfb8:      	cmp	x25, x3
    dfbc:      	b.ge	0xe0ac <_stogir.vector-arithmetic.operands+0x57c>
    dfc0:      	add	x3, x20, #0x78
    dfc4:      	ldr	x3, [x3, #0x8]
    dfc8:      	cmp	x25, x3
    dfcc:      	b.ge	0xe174 <_stogir.vector-arithmetic.operands+0x644>
    dfd0:      	ldr	x3, [x20, #0x78]
    dfd4:      	add	x3, x3, x25, lsl #2
    dfd8:      	ldr	w3, [x3]
    dfdc:      	sxtw	x3, w3
    dfe0:      	cmp	x3, #0x0
    dfe4:      	cset	w3, ge
    dfe8:      	ubfx	x3, x3, #0, #8
    dfec:      	b	0xe178 <_stogir.vector-arithmetic.operands+0x648>
    dff0:      	cmp	x21, #0x1e
    dff4:      	cset	w0, eq
    dff8:      	ubfx	x0, x0, #0, #8
    dffc:      	cmp	x0, #0x0
    e000:      	b.eq	0xdf74 <_stogir.vector-arithmetic.operands+0x444>
    e004:      	movz	x0, #0x0, lsl #48
    e008:      	b	0xdf78 <_stogir.vector-arithmetic.operands+0x448>
    e00c:      	movz	x0, #0x0, lsl #48
    e010:      	uxtb	w0, w0
    e014:      	and	x0, x0, #0x2
    e018:      	uxtb	w0, w0
    e01c:      	cmp	x0, #0x0
    e020:      	cset	w0, eq
    e024:      	uxtb	w16, w0
    e028:      	cmp	w16, wzr
    e02c:      	cset	x0, eq
    e030:      	cmp	x0, #0x0
    e034:      	b.ne	0xe17c <_stogir.vector-arithmetic.operands+0x64c>
    e038:      	cmp	x3, #0x65
    e03c:      	b.eq	0xe17c <_stogir.vector-arithmetic.operands+0x64c>
    e040:      	cmp	x3, #0x66
    e044:      	b.eq	0xe17c <_stogir.vector-arithmetic.operands+0x64c>
    e048:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e048:  ARM64_RELOC_PAGE21	l_stogir.503
    e04c:      	ldr	x16, [x16]
		000000000000e04c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    e050:      	orr	x0, x16, xzr
    e054:      	mov	x1, #0x34               ; =52
    e058:      	b	0xdf90 <_stogir.vector-arithmetic.operands+0x460>
    e05c:      	cmp	x25, #0x0
    e060:      	b.ge	0xe0b4 <_stogir.vector-arithmetic.operands+0x584>
    e064:      	add	x5, x20, #0x28
    e068:      	add	x6, x20, #0x50
    e06c:      	ldr	x5, [x5, #0x8]
    e070:      	ldr	x6, [x6, #0x8]
    e074:      	cmp	x5, x6
    e078:      	b.ne	0xe16c <_stogir.vector-arithmetic.operands+0x63c>
    e07c:      	cmp	x3, x5
    e080:      	b.gt	0xe188 <_stogir.vector-arithmetic.operands+0x658>
    e084:      	ldr	x3, [x20, #0x50]
    e088:      	add	x3, x3, x4, lsl #2
    e08c:      	ldr	w3, [x3]
    e090:      	sxtw	x3, w3
    e094:      	cmp	x3, #0x0
    e098:      	cset	w3, gt
    e09c:      	ubfx	x3, x3, #0, #8
    e0a0:      	b	0xe18c <_stogir.vector-arithmetic.operands+0x65c>
    e0a4:      	brk	#0
    e0a8:      	b	0xe0a4 <_stogir.vector-arithmetic.operands+0x574>
    e0ac:      	movz	x3, #0x0, lsl #48
    e0b0:      	b	0xe0b8 <_stogir.vector-arithmetic.operands+0x588>
    e0b4:      	movz	x3, #0x0, lsl #48
    e0b8:      	cmp	x3, #0x0
    e0bc:      	b.eq	0xe0f4 <_stogir.vector-arithmetic.operands+0x5c4>
    e0c0:      	uxtb	w16, w0
    e0c4:      	cmp	w16, wzr
    e0c8:      	b.eq	0xe0dc <_stogir.vector-arithmetic.operands+0x5ac>
    e0cc:      	ldr	x0, [x20]
    e0d0:      	add	x0, x0, x25, lsl #4
    e0d4:      	ldr	x0, [x0]
    e0d8:      	b	0xe0e8 <_stogir.vector-arithmetic.operands+0x5b8>
    e0dc:      	ldr	x0, [x20, #0x28]
    e0e0:      	add	x0, x0, x4, lsl #4
    e0e4:      	ldr	x0, [x0]
    e0e8:      	mov	x3, x0
    e0ec:      	mov	x0, #0x1                ; =1
    e0f0:      	b	0xe0fc <_stogir.vector-arithmetic.operands+0x5cc>
    e0f4:      	movz	x0, #0x0, lsl #48
    e0f8:      	movz	x3, #0x0, lsl #48
    e0fc:      	lsr	w0, w0, #0
    e100:      	lsr	x16, x0, #0
    e104:      	cmp	x16, #0x1
    e108:      	b.eq	0xe124 <_stogir.vector-arithmetic.operands+0x5f4>
    e10c:      	b.lo	0xe114 <_stogir.vector-arithmetic.operands+0x5e4>
    e110:      	b	0xe128 <_stogir.vector-arithmetic.operands+0x5f8>
    e114:      	cmp	x16, #0x0
    e118:      	b.eq	0xe120 <_stogir.vector-arithmetic.operands+0x5f0>
    e11c:      	b	0xe128 <_stogir.vector-arithmetic.operands+0x5f8>
    e120:      	b	0xe12c <_stogir.vector-arithmetic.operands+0x5fc>
    e124:      	b	0xe140 <_stogir.vector-arithmetic.operands+0x610>
    e128:      	b	0xe190 <_stogir.vector-arithmetic.operands+0x660>
    e12c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e12c:  ARM64_RELOC_PAGE21	l_stogir.504
    e130:      	ldr	x16, [x16]
		000000000000e130:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    e134:      	orr	x0, x16, xzr
    e138:      	mov	x1, #0x1d               ; =29
    e13c:      	b	0xe058 <_stogir.vector-arithmetic.operands+0x528>
    e140:      	cmp	x25, #0x0
    e144:      	b.le	0xe048 <_stogir.vector-arithmetic.operands+0x518>
    e148:      	uxtb	w3, w3
    e14c:      	cmp	x3, #0x83
    e150:      	b.ge	0xe00c <_stogir.vector-arithmetic.operands+0x4dc>
    e154:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e154:  ARM64_RELOC_PAGE21	l_stogir.505
    e158:      	ldr	x16, [x16]
		000000000000e158:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    e15c:      	orr	x0, x16, xzr
    e160:      	add	x0, x3, x0
    e164:      	ldrb	w0, [x0]
    e168:      	b	0xe010 <_stogir.vector-arithmetic.operands+0x4e0>
    e16c:      	movz	x3, #0x0, lsl #48
    e170:      	b	0xe0b8 <_stogir.vector-arithmetic.operands+0x588>
    e174:      	movz	x3, #0x0, lsl #48
    e178:      	b	0xe0b0 <_stogir.vector-arithmetic.operands+0x580>
    e17c:      	mov	x0, x1
    e180:      	mov	x1, x2
    e184:      	b	0xe058 <_stogir.vector-arithmetic.operands+0x528>
    e188:      	movz	x3, #0x0, lsl #48
    e18c:      	b	0xe170 <_stogir.vector-arithmetic.operands+0x640>
    e190:      	brk	#0
    e194:      	b	0xe190 <_stogir.vector-arithmetic.operands+0x660>
    e198:      	str	x4, [sp, #0x20]
    e19c:      	str	x5, [sp, #0x28]
    e1a0:      	b	0xdc78 <_stogir.vector-arithmetic.operands+0x148>

000000000000e1a4 <_stogir.types.base-type>:
    e1a4:      	sxtw	x0, w0
    e1a8:      	and	x1, x0, #0xf
    e1ac:      	lsr	w1, w1, #0
    e1b0:      	sxtw	x1, w1
    e1b4:      	cmp	x0, #0x0
    e1b8:      	b.lt	0xe1cc <_stogir.types.base-type+0x28>
    e1bc:      	cmp	x0, #0xd
    e1c0:      	b.gt	0xe1cc <_stogir.types.base-type+0x28>
    e1c4:      	mov	x0, x1
    e1c8:      	b	0xe1f0 <_stogir.types.base-type+0x4c>
    e1cc:      	cmp	x0, #0xf
    e1d0:      	b.le	0xe1ec <_stogir.types.base-type+0x48>
    e1d4:      	cmp	x0, #0x80
    e1d8:      	b.ge	0xe1ec <_stogir.types.base-type+0x48>
    e1dc:      	cmp	x1, #0x1
    e1e0:      	b.lt	0xe1ec <_stogir.types.base-type+0x48>
    e1e4:      	cmp	x1, #0xd
    e1e8:      	b.le	0xe1c4 <_stogir.types.base-type+0x20>
    e1ec:      	movn	x0, #0x0, lsl #48
    e1f0:      	ret

000000000000e1f4 <_stogir.types.lanes>:
    e1f4:      	sxtw	x0, w0
    e1f8:      	cmp	x0, #0xf
    e1fc:      	b.le	0xe24c <_stogir.types.lanes+0x58>
    e200:      	cmp	x0, #0x80
    e204:      	b.ge	0xe24c <_stogir.types.lanes+0x58>
    e208:      	and	x1, x0, #0xf
    e20c:      	lsr	w1, w1, #0
    e210:      	sxtw	x1, w1
    e214:      	cmp	x1, #0x1
    e218:      	b.lt	0xe24c <_stogir.types.lanes+0x58>
    e21c:      	cmp	x1, #0xd
    e220:      	b.gt	0xe24c <_stogir.types.lanes+0x58>
    e224:      	ubfx	x0, x0, #4, #32
    e228:      	sxtw	x0, w0
    e22c:      	sub	x0, x0, #0x1
    e230:      	lsr	w0, w0, #0
    e234:      	sxtw	x0, w0
    e238:      	mov	x16, #0x1               ; =1
    e23c:      	lsl	x0, x16, x0
    e240:      	lsr	w0, w0, #0
    e244:      	sxtw	x0, w0
    e248:      	b	0xe278 <_stogir.types.lanes+0x84>
    e24c:      	cmp	x0, #0x0
    e250:      	b.lt	0xe274 <_stogir.types.lanes+0x80>
    e254:      	cmp	x0, #0xd
    e258:      	b.gt	0xe274 <_stogir.types.lanes+0x80>
    e25c:      	cmp	x0, #0x0
    e260:      	cset	w0, eq
    e264:      	uxtb	w16, w0
    e268:      	cmp	w16, wzr
    e26c:      	cset	x0, eq
    e270:      	b	0xe278 <_stogir.types.lanes+0x84>
    e274:      	movn	x0, #0x0, lsl #48
    e278:      	ret

000000000000e27c <_coil.core.Get$slice$get__u8>:
    e27c:      	add	x0, x0, x2
    e280:      	ldrb	w0, [x0]
    e284:      	ret

000000000000e288 <_stogir.checked.valid-type?>:
    e288:      	sxtw	x0, w0
    e28c:      	cmp	x0, #0x1
    e290:      	b.lt	0xe2b4 <_stogir.checked.valid-type?+0x2c>
    e294:      	cmp	x0, #0xb
    e298:      	b.gt	0xe2b4 <_stogir.checked.valid-type?+0x2c>
    e29c:      	cmp	x0, #0x1
    e2a0:      	cset	w0, eq
    e2a4:      	uxtb	w16, w0
    e2a8:      	cmp	w16, wzr
    e2ac:      	cset	x0, eq
    e2b0:      	b	0xe2b8 <_stogir.checked.valid-type?+0x30>
    e2b4:      	movz	x0, #0x0, lsl #48
    e2b8:      	ret

000000000000e2bc <_coil.core.Iterable$slice$iter__i32>:
    e2bc:      	str	x0, [x8]
    e2c0:      	str	x1, [x8, #0x8]
    e2c4:      	movz	x17, #0x0, lsl #48
    e2c8:      	str	x17, [x8, #0x10]
    e2cc:      	ret

000000000000e2d0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    e2d0:      	sub	sp, sp, #0x10
    e2d4:      	mov	x1, sp
    e2d8:      	ldr	x2, [x0, #0x10]
    e2dc:      	ldr	x3, [x0]
    e2e0:      	ldr	x4, [x0, #0x8]
    e2e4:      	cmp	x2, x4
    e2e8:      	b.ge	0xe310 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x40>
    e2ec:      	add	x4, x2, #0x1
    e2f0:      	add	x2, x3, x2, lsl #2
    e2f4:      	str	x4, [x0, #0x10]
    e2f8:      	ldr	w0, [x2]
    e2fc:      	sxtw	x0, w0
    e300:      	and	x0, x0, #0xffffffff
    e304:      	mov	x2, x0
    e308:      	mov	x0, #0x1                ; =1
    e30c:      	b	0xe318 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x48>
    e310:      	movz	x0, #0x0, lsl #48
    e314:      	movz	x2, #0x0, lsl #48
    e318:      	str	x0, [x1]
    e31c:      	str	x2, [x1, #0x8]
    e320:      	ldr	x0, [sp]
    e324:      	ldr	x1, [sp, #0x8]
    e328:      	add	sp, sp, #0x10
    e32c:      	ret

000000000000e330 <_stogir.terminal.previous-input>:
    e330:      	sxtw	x1, w1
    e334:      	cmp	x1, #0x0
    e338:      	b.ne	0xe358 <_stogir.terminal.previous-input+0x28>
    e33c:      	movz	x0, #0x0, lsl #48
    e340:      	movz	x1, #0x0, lsl #48
    e344:      	movz	x2, #0x0, lsl #48
    e348:      	str	x0, [x8]
    e34c:      	str	x1, [x8, #0x8]
    e350:      	str	x2, [x8, #0x10]
    e354:      	ret
    e358:      	cmp	x1, #0x0
    e35c:      	cset	w2, gt
    e360:      	movz	x16, #0x0, lsl #48
    e364:      	sub	x3, x16, x1
    e368:      	sub	x4, x3, #0x1
    e36c:      	uxtb	w16, w2
    e370:      	cmp	w16, wzr
    e374:      	b.eq	0xe3d0 <_stogir.terminal.previous-input+0xa0>
    e378:      	ldr	x3, [x0, #0x8]
    e37c:      	cmp	x1, x3
    e380:      	b.ge	0xe418 <_stogir.terminal.previous-input+0xe8>
    e384:      	add	x3, x0, #0x78
    e388:      	ldr	x3, [x3, #0x8]
    e38c:      	cmp	x1, x3
    e390:      	b.ge	0xe4e8 <_stogir.terminal.previous-input+0x1b8>
    e394:      	ldr	x3, [x0, #0x78]
    e398:      	add	x3, x3, x1, lsl #2
    e39c:      	ldr	w3, [x3]
    e3a0:      	sxtw	x3, w3
    e3a4:      	cmp	x3, #0x0
    e3a8:      	cset	w3, ge
    e3ac:      	ubfx	x3, x3, #0, #8
    e3b0:      	b	0xe4ec <_stogir.terminal.previous-input+0x1bc>
    e3b4:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e3b4:  ARM64_RELOC_PAGE21	l_stogir.506
    e3b8:      	ldr	x16, [x16]
		000000000000e3b8:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    e3bc:      	orr	x0, x16, xzr
    e3c0:      	mov	x1, x0
    e3c4:      	mov	x0, #0x1                ; =1
    e3c8:      	mov	x2, #0x2e               ; =46
    e3cc:      	b	0xe348 <_stogir.terminal.previous-input+0x18>
    e3d0:      	cmp	x1, #0x0
    e3d4:      	b.ge	0xe420 <_stogir.terminal.previous-input+0xf0>
    e3d8:      	add	x5, x0, #0x28
    e3dc:      	add	x6, x0, #0x50
    e3e0:      	ldr	x5, [x5, #0x8]
    e3e4:      	ldr	x6, [x6, #0x8]
    e3e8:      	cmp	x5, x6
    e3ec:      	b.ne	0xe4e0 <_stogir.terminal.previous-input+0x1b0>
    e3f0:      	cmp	x3, x5
    e3f4:      	b.gt	0xe4f0 <_stogir.terminal.previous-input+0x1c0>
    e3f8:      	ldr	x3, [x0, #0x50]
    e3fc:      	add	x3, x3, x4, lsl #2
    e400:      	ldr	w3, [x3]
    e404:      	sxtw	x3, w3
    e408:      	cmp	x3, #0x0
    e40c:      	cset	w3, gt
    e410:      	ubfx	x3, x3, #0, #8
    e414:      	b	0xe4f4 <_stogir.terminal.previous-input+0x1c4>
    e418:      	movz	x3, #0x0, lsl #48
    e41c:      	b	0xe424 <_stogir.terminal.previous-input+0xf4>
    e420:      	movz	x3, #0x0, lsl #48
    e424:      	cmp	x3, #0x0
    e428:      	b.eq	0xe460 <_stogir.terminal.previous-input+0x130>
    e42c:      	uxtb	w16, w2
    e430:      	cmp	w16, wzr
    e434:      	b.eq	0xe448 <_stogir.terminal.previous-input+0x118>
    e438:      	ldr	x0, [x0]
    e43c:      	add	x0, x0, x1, lsl #4
    e440:      	ldr	x0, [x0]
    e444:      	b	0xe454 <_stogir.terminal.previous-input+0x124>
    e448:      	ldr	x0, [x0, #0x28]
    e44c:      	add	x0, x0, x4, lsl #4
    e450:      	ldr	x0, [x0]
    e454:      	mov	x2, x0
    e458:      	mov	x0, #0x1                ; =1
    e45c:      	b	0xe468 <_stogir.terminal.previous-input+0x138>
    e460:      	movz	x0, #0x0, lsl #48
    e464:      	movz	x2, #0x0, lsl #48
    e468:      	lsr	w0, w0, #0
    e46c:      	lsr	x16, x0, #0
    e470:      	cmp	x16, #0x1
    e474:      	b.eq	0xe490 <_stogir.terminal.previous-input+0x160>
    e478:      	b.lo	0xe480 <_stogir.terminal.previous-input+0x150>
    e47c:      	b	0xe494 <_stogir.terminal.previous-input+0x164>
    e480:      	cmp	x16, #0x0
    e484:      	b.eq	0xe48c <_stogir.terminal.previous-input+0x15c>
    e488:      	b	0xe494 <_stogir.terminal.previous-input+0x164>
    e48c:      	b	0xe498 <_stogir.terminal.previous-input+0x168>
    e490:      	b	0xe4b4 <_stogir.terminal.previous-input+0x184>
    e494:      	b	0xe538 <_stogir.terminal.previous-input+0x208>
    e498:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e498:  ARM64_RELOC_PAGE21	l_stogir.507
    e49c:      	ldr	x16, [x16]
		000000000000e49c:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    e4a0:      	orr	x0, x16, xzr
    e4a4:      	mov	x1, x0
    e4a8:      	mov	x0, #0x1                ; =1
    e4ac:      	mov	x2, #0x1d               ; =29
    e4b0:      	b	0xe3cc <_stogir.terminal.previous-input+0x9c>
    e4b4:      	cmp	x1, #0x0
    e4b8:      	b.le	0xe3b4 <_stogir.terminal.previous-input+0x84>
    e4bc:      	uxtb	w2, w2
    e4c0:      	cmp	x2, #0x83
    e4c4:      	b.ge	0xe4f8 <_stogir.terminal.previous-input+0x1c8>
    e4c8:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e4c8:  ARM64_RELOC_PAGE21	l_stogir.508
    e4cc:      	ldr	x16, [x16]
		000000000000e4cc:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    e4d0:      	orr	x0, x16, xzr
    e4d4:      	add	x0, x2, x0
    e4d8:      	ldrb	w0, [x0]
    e4dc:      	b	0xe4fc <_stogir.terminal.previous-input+0x1cc>
    e4e0:      	movz	x3, #0x0, lsl #48
    e4e4:      	b	0xe424 <_stogir.terminal.previous-input+0xf4>
    e4e8:      	movz	x3, #0x0, lsl #48
    e4ec:      	b	0xe41c <_stogir.terminal.previous-input+0xec>
    e4f0:      	movz	x3, #0x0, lsl #48
    e4f4:      	b	0xe4e4 <_stogir.terminal.previous-input+0x1b4>
    e4f8:      	movz	x0, #0x0, lsl #48
    e4fc:      	uxtb	w0, w0
    e500:      	and	x0, x0, #0x8
    e504:      	uxtb	w0, w0
    e508:      	cmp	x0, #0x0
    e50c:      	cset	w0, eq
    e510:      	uxtb	w16, w0
    e514:      	cmp	w16, wzr
    e518:      	cset	x0, eq
    e51c:      	cmp	x0, #0x0
    e520:      	b.eq	0xe3b4 <_stogir.terminal.previous-input+0x84>
    e524:      	and	x0, x1, #0xffffffff
    e528:      	mov	x1, x0
    e52c:      	movz	x0, #0x0, lsl #48
    e530:      	movz	x2, #0x0, lsl #48
    e534:      	b	0xe3cc <_stogir.terminal.previous-input+0x9c>
    e538:      	brk	#0
    e53c:      	b	0xe538 <_stogir.terminal.previous-input+0x208>

000000000000e540 <_stogir.switch.selector-type>:
    e540:      	sxtw	x1, w1
    e544:      	cmp	x1, #0x0
    e548:      	cset	w2, gt
    e54c:      	movz	x16, #0x0, lsl #48
    e550:      	sub	x3, x16, x1
    e554:      	sub	x4, x3, #0x1
    e558:      	uxtb	w16, w2
    e55c:      	cmp	w16, wzr
    e560:      	b.eq	0xe5a0 <_stogir.switch.selector-type+0x60>
    e564:      	ldr	x3, [x0, #0x8]
    e568:      	cmp	x1, x3
    e56c:      	b.ge	0xe5f0 <_stogir.switch.selector-type+0xb0>
    e570:      	add	x3, x0, #0x78
    e574:      	ldr	x3, [x3, #0x8]
    e578:      	cmp	x1, x3
    e57c:      	b.ge	0xe6ec <_stogir.switch.selector-type+0x1ac>
    e580:      	ldr	x3, [x0, #0x78]
    e584:      	add	x3, x3, x1, lsl #2
    e588:      	ldr	w3, [x3]
    e58c:      	sxtw	x3, w3
    e590:      	cmp	x3, #0x0
    e594:      	cset	w3, ge
    e598:      	ubfx	x3, x3, #0, #8
    e59c:      	b	0xe6f0 <_stogir.switch.selector-type+0x1b0>
    e5a0:      	cmp	x1, #0x0
    e5a4:      	b.ge	0xe5f8 <_stogir.switch.selector-type+0xb8>
    e5a8:      	add	x5, x0, #0x28
    e5ac:      	add	x6, x0, #0x50
    e5b0:      	ldr	x5, [x5, #0x8]
    e5b4:      	ldr	x6, [x6, #0x8]
    e5b8:      	cmp	x5, x6
    e5bc:      	b.ne	0xe5e8 <_stogir.switch.selector-type+0xa8>
    e5c0:      	cmp	x3, x5
    e5c4:      	b.gt	0xe6f4 <_stogir.switch.selector-type+0x1b4>
    e5c8:      	ldr	x3, [x0, #0x50]
    e5cc:      	add	x3, x3, x4, lsl #2
    e5d0:      	ldr	w3, [x3]
    e5d4:      	sxtw	x3, w3
    e5d8:      	cmp	x3, #0x0
    e5dc:      	cset	w3, gt
    e5e0:      	ubfx	x3, x3, #0, #8
    e5e4:      	b	0xe6f8 <_stogir.switch.selector-type+0x1b8>
    e5e8:      	movz	x3, #0x0, lsl #48
    e5ec:      	b	0xe5fc <_stogir.switch.selector-type+0xbc>
    e5f0:      	movz	x3, #0x0, lsl #48
    e5f4:      	b	0xe5fc <_stogir.switch.selector-type+0xbc>
    e5f8:      	movz	x3, #0x0, lsl #48
    e5fc:      	cmp	x3, #0x0
    e600:      	b.eq	0xe638 <_stogir.switch.selector-type+0xf8>
    e604:      	uxtb	w16, w2
    e608:      	cmp	w16, wzr
    e60c:      	b.eq	0xe620 <_stogir.switch.selector-type+0xe0>
    e610:      	ldr	x0, [x0]
    e614:      	add	x0, x0, x1, lsl #4
    e618:      	ldr	x0, [x0]
    e61c:      	b	0xe62c <_stogir.switch.selector-type+0xec>
    e620:      	ldr	x0, [x0, #0x28]
    e624:      	add	x0, x0, x4, lsl #4
    e628:      	ldr	x0, [x0]
    e62c:      	mov	x1, x0
    e630:      	mov	x0, #0x1                ; =1
    e634:      	b	0xe640 <_stogir.switch.selector-type+0x100>
    e638:      	movz	x0, #0x0, lsl #48
    e63c:      	movz	x1, #0x0, lsl #48
    e640:      	lsr	w0, w0, #0
    e644:      	lsr	x16, x0, #0
    e648:      	cmp	x16, #0x1
    e64c:      	b.eq	0xe668 <_stogir.switch.selector-type+0x128>
    e650:      	b.lo	0xe658 <_stogir.switch.selector-type+0x118>
    e654:      	b	0xe66c <_stogir.switch.selector-type+0x12c>
    e658:      	cmp	x16, #0x0
    e65c:      	b.eq	0xe664 <_stogir.switch.selector-type+0x124>
    e660:      	b	0xe66c <_stogir.switch.selector-type+0x12c>
    e664:      	b	0xe670 <_stogir.switch.selector-type+0x130>
    e668:      	b	0xe6b4 <_stogir.switch.selector-type+0x174>
    e66c:      	b	0xe6fc <_stogir.switch.selector-type+0x1bc>
    e670:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e670:  ARM64_RELOC_PAGE21	l_stogir.509
    e674:      	ldr	x16, [x16]
		000000000000e674:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    e678:      	orr	x0, x16, xzr
    e67c:      	mov	x1, x0
    e680:      	mov	x0, #0x1                ; =1
    e684:      	mov	x2, #0x17               ; =23
    e688:      	b	0xe6a4 <_stogir.switch.selector-type+0x164>
    e68c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e68c:  ARM64_RELOC_PAGE21	l_stogir.510
    e690:      	ldr	x16, [x16]
		000000000000e690:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    e694:      	orr	x0, x16, xzr
    e698:      	mov	x1, x0
    e69c:      	mov	x0, #0x1                ; =1
    e6a0:      	mov	x2, #0x20               ; =32
    e6a4:      	str	x0, [x8]
    e6a8:      	str	x1, [x8, #0x8]
    e6ac:      	str	x2, [x8, #0x10]
    e6b0:      	ret
    e6b4:      	lsr	w0, w1, #0
    e6b8:      	ubfx	x0, x0, #8, #8
    e6bc:      	cmp	x0, #0x1
    e6c0:      	b.lt	0xe68c <_stogir.switch.selector-type+0x14c>
    e6c4:      	cmp	x0, #0xb
    e6c8:      	b.gt	0xe68c <_stogir.switch.selector-type+0x14c>
    e6cc:      	uxtb	w1, w1
    e6d0:      	cmp	x1, #0x48
    e6d4:      	b.eq	0xe68c <_stogir.switch.selector-type+0x14c>
    e6d8:      	and	x0, x0, #0xffffffff
    e6dc:      	mov	x1, x0
    e6e0:      	movz	x0, #0x0, lsl #48
    e6e4:      	movz	x2, #0x0, lsl #48
    e6e8:      	b	0xe6a4 <_stogir.switch.selector-type+0x164>
    e6ec:      	movz	x3, #0x0, lsl #48
    e6f0:      	b	0xe5f4 <_stogir.switch.selector-type+0xb4>
    e6f4:      	movz	x3, #0x0, lsl #48
    e6f8:      	b	0xe5ec <_stogir.switch.selector-type+0xac>
    e6fc:      	brk	#0
    e700:      	b	0xe6fc <_stogir.switch.selector-type+0x1bc>

000000000000e704 <_stogir.switch.key>:
    e704:      	sub	sp, sp, #0x30
    e708:      	str	x19, [sp]
    e70c:      	str	x20, [sp, #0x8]
    e710:      	str	x21, [sp, #0x10]
    e714:      	str	x22, [sp, #0x18]
    e718:      	str	x23, [sp, #0x20]
    e71c:      	sxtw	x2, w2
    e720:      	cmp	x2, #0x1
    e724:      	b.lt	0xe79c <_stogir.switch.key+0x98>
    e728:      	cmp	x2, #0xb
    e72c:      	cset	w3, le
    e730:      	uxtb	w16, w3
    e734:      	cmp	w16, wzr
    e738:      	b.eq	0xe79c <_stogir.switch.key+0x98>
    e73c:      	sxtw	x1, w1
    e740:      	cmp	x1, #0x0
    e744:      	cset	w4, gt
    e748:      	movz	x16, #0x0, lsl #48
    e74c:      	sub	x5, x16, x1
    e750:      	sub	x6, x5, #0x1
    e754:      	uxtb	w16, w4
    e758:      	cmp	w16, wzr
    e75c:      	b.eq	0xe820 <_stogir.switch.key+0x11c>
    e760:      	ldr	x5, [x0, #0x8]
    e764:      	cmp	x1, x5
    e768:      	b.ge	0xe868 <_stogir.switch.key+0x164>
    e76c:      	add	x5, x0, #0x78
    e770:      	ldr	x5, [x5, #0x8]
    e774:      	cmp	x1, x5
    e778:      	b.ge	0xe9cc <_stogir.switch.key+0x2c8>
    e77c:      	ldr	x5, [x0, #0x78]
    e780:      	add	x5, x5, x1, lsl #2
    e784:      	ldr	w5, [x5]
    e788:      	sxtw	x5, w5
    e78c:      	cmp	x5, #0x0
    e790:      	cset	w5, ge
    e794:      	ubfx	x5, x5, #0, #8
    e798:      	b	0xe9d0 <_stogir.switch.key+0x2cc>
    e79c:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e79c:  ARM64_RELOC_PAGE21	l_stogir.511
    e7a0:      	ldr	x16, [x16]
		000000000000e7a0:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    e7a4:      	orr	x0, x16, xzr
    e7a8:      	mov	x1, x0
    e7ac:      	mov	x0, #0x1                ; =1
    e7b0:      	mov	x2, #0x24               ; =36
    e7b4:      	str	x0, [x8]
    e7b8:      	str	x1, [x8, #0x8]
    e7bc:      	str	x2, [x8, #0x10]
    e7c0:      	ldr	x19, [sp]
    e7c4:      	ldr	x20, [sp, #0x8]
    e7c8:      	ldr	x21, [sp, #0x10]
    e7cc:      	ldr	x22, [sp, #0x18]
    e7d0:      	ldr	x23, [sp, #0x20]
    e7d4:      	add	sp, sp, #0x30
    e7d8:      	ret
    e7dc:      	mov	x23, #0x1               ; =1
    e7e0:      	cmp	x1, #0x0
    e7e4:      	b.ge	0xe804 <_stogir.switch.key+0x100>
    e7e8:      	lsr	w1, w4, #0
    e7ec:      	uxtb	w4, w4
    e7f0:      	ubfx	x1, x1, #8, #8
    e7f4:      	cmp	x4, x1
    e7f8:      	b.eq	0xea74 <_stogir.switch.key+0x370>
    e7fc:      	cmp	x4, #0x49
    e800:      	b.eq	0xea74 <_stogir.switch.key+0x370>
    e804:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e804:  ARM64_RELOC_PAGE21	l_stogir.512
    e808:      	ldr	x16, [x16]
		000000000000e808:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    e80c:      	orr	x0, x16, xzr
    e810:      	mov	x1, x0
    e814:      	mov	x0, #0x1                ; =1
    e818:      	mov	x2, #0x30               ; =48
    e81c:      	b	0xe7b4 <_stogir.switch.key+0xb0>
    e820:      	cmp	x1, #0x0
    e824:      	b.ge	0xe870 <_stogir.switch.key+0x16c>
    e828:      	add	x7, x0, #0x28
    e82c:      	add	x9, x0, #0x50
    e830:      	ldr	x7, [x7, #0x8]
    e834:      	ldr	x9, [x9, #0x8]
    e838:      	cmp	x7, x9
    e83c:      	b.ne	0xe9c4 <_stogir.switch.key+0x2c0>
    e840:      	cmp	x5, x7
    e844:      	b.gt	0xea6c <_stogir.switch.key+0x368>
    e848:      	ldr	x5, [x0, #0x50]
    e84c:      	add	x5, x5, x6, lsl #2
    e850:      	ldr	w5, [x5]
    e854:      	sxtw	x5, w5
    e858:      	cmp	x5, #0x0
    e85c:      	cset	w5, gt
    e860:      	ubfx	x5, x5, #0, #8
    e864:      	b	0xea70 <_stogir.switch.key+0x36c>
    e868:      	movz	x5, #0x0, lsl #48
    e86c:      	b	0xe874 <_stogir.switch.key+0x170>
    e870:      	movz	x5, #0x0, lsl #48
    e874:      	cmp	x5, #0x0
    e878:      	b.eq	0xe8d4 <_stogir.switch.key+0x1d0>
    e87c:      	uxtb	w16, w4
    e880:      	cmp	w16, wzr
    e884:      	b.eq	0xe8a8 <_stogir.switch.key+0x1a4>
    e888:      	ldr	x0, [x0]
    e88c:      	add	x0, x0, x1, lsl #4
    e890:      	ldr	x4, [x0]
    e894:      	ldr	x0, [x0, #0x8]
    e898:      	fmov	d31, x0
    e89c:      	mov	x0, x4
    e8a0:      	fmov	x4, d31
    e8a4:      	b	0xe8c4 <_stogir.switch.key+0x1c0>
    e8a8:      	ldr	x0, [x0, #0x28]
    e8ac:      	add	x0, x0, x6, lsl #4
    e8b0:      	ldr	x4, [x0]
    e8b4:      	ldr	x0, [x0, #0x8]
    e8b8:      	fmov	d31, x0
    e8bc:      	mov	x0, x4
    e8c0:      	fmov	x4, d31
    e8c4:      	mov	x5, x4
    e8c8:      	mov	x4, x0
    e8cc:      	mov	x0, #0x1                ; =1
    e8d0:      	b	0xe8e0 <_stogir.switch.key+0x1dc>
    e8d4:      	movz	x0, #0x0, lsl #48
    e8d8:      	movz	x4, #0x0, lsl #48
    e8dc:      	movz	x5, #0x0, lsl #48
    e8e0:      	lsr	w0, w0, #0
    e8e4:      	lsr	x16, x0, #0
    e8e8:      	cmp	x16, #0x1
    e8ec:      	b.eq	0xe908 <_stogir.switch.key+0x204>
    e8f0:      	b.lo	0xe8f8 <_stogir.switch.key+0x1f4>
    e8f4:      	b	0xe90c <_stogir.switch.key+0x208>
    e8f8:      	cmp	x16, #0x0
    e8fc:      	b.eq	0xe904 <_stogir.switch.key+0x200>
    e900:      	b	0xe90c <_stogir.switch.key+0x208>
    e904:      	b	0xe910 <_stogir.switch.key+0x20c>
    e908:      	b	0xe92c <_stogir.switch.key+0x228>
    e90c:      	b	0xeb18 <_stogir.switch.key+0x414>
    e910:      	adrp	x16, 0xe000 <_stogir.vector-arithmetic.operands+0x4d0>
		000000000000e910:  ARM64_RELOC_PAGE21	l_stogir.513
    e914:      	ldr	x16, [x16]
		000000000000e914:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    e918:      	orr	x0, x16, xzr
    e91c:      	mov	x1, x0
    e920:      	mov	x0, #0x1                ; =1
    e924:      	mov	x2, #0x1c               ; =28
    e928:      	b	0xe81c <_stogir.switch.key+0x118>
    e92c:      	cmp	x2, #0x1
    e930:      	cset	w0, eq
    e934:      	cmp	x2, #0x0
    e938:      	cset	w6, eq
    e93c:      	cmp	x2, #0x2
    e940:      	cset	w7, eq
    e944:      	cmp	x2, #0x7
    e948:      	cset	w9, eq
    e94c:      	cmp	x2, #0x8
    e950:      	cset	w10, eq
    e954:      	cmp	x2, #0x3
    e958:      	cset	w11, eq
    e95c:      	cmp	x2, #0x9
    e960:      	cset	w12, eq
    e964:      	cmp	x2, #0x4
    e968:      	cset	w13, eq
    e96c:      	cmp	x2, #0xa
    e970:      	cset	w14, eq
    e974:      	cmp	x2, #0xd
    e978:      	cset	w15, eq
    e97c:      	cmp	x2, #0x5
    e980:      	cset	w19, eq
    e984:      	cmp	x2, #0xb
    e988:      	cset	w20, eq
    e98c:      	cmp	x2, #0xc
    e990:      	cset	w21, eq
    e994:      	cmp	x2, #0x6
    e998:      	cset	w22, eq
    e99c:      	uxtb	w16, w22
    e9a0:      	cmp	w16, wzr
    e9a4:      	mov	x16, #0x8               ; =8
    e9a8:      	movn	x17, #0x0, lsl #48
    e9ac:      	csel	x22, x16, x17, ne
    e9b0:      	uxtb	w16, w6
    e9b4:      	cmp	w16, wzr
    e9b8:      	b.eq	0xe9d4 <_stogir.switch.key+0x2d0>
    e9bc:      	movz	x23, #0x0, lsl #48
    e9c0:      	b	0xe7e0 <_stogir.switch.key+0xdc>
    e9c4:      	movz	x5, #0x0, lsl #48
    e9c8:      	b	0xe874 <_stogir.switch.key+0x170>
    e9cc:      	movz	x5, #0x0, lsl #48
    e9d0:      	b	0xe86c <_stogir.switch.key+0x168>
    e9d4:      	uxtb	w16, w0
    e9d8:      	cmp	w16, wzr
    e9dc:      	b.ne	0xe7dc <_stogir.switch.key+0xd8>
    e9e0:      	uxtb	w16, w7
    e9e4:      	cmp	w16, wzr
    e9e8:      	b.ne	0xe7dc <_stogir.switch.key+0xd8>
    e9ec:      	uxtb	w16, w9
    e9f0:      	cmp	w16, wzr
    e9f4:      	b.ne	0xe7dc <_stogir.switch.key+0xd8>
    e9f8:      	uxtb	w16, w10
    e9fc:      	cmp	w16, wzr
    ea00:      	b.ne	0xe7dc <_stogir.switch.key+0xd8>
    ea04:      	uxtb	w16, w11
    ea08:      	cmp	w16, wzr
    ea0c:      	b.ne	0xeb10 <_stogir.switch.key+0x40c>
    ea10:      	uxtb	w16, w12
    ea14:      	cmp	w16, wzr
    ea18:      	b.ne	0xeb10 <_stogir.switch.key+0x40c>
    ea1c:      	uxtb	w16, w13
    ea20:      	cmp	w16, wzr
    ea24:      	b.ne	0xebe8 <_stogir.switch.key+0x4e4>
    ea28:      	uxtb	w16, w14
    ea2c:      	cmp	w16, wzr
    ea30:      	b.ne	0xebe8 <_stogir.switch.key+0x4e4>
    ea34:      	uxtb	w16, w15
    ea38:      	cmp	w16, wzr
    ea3c:      	b.ne	0xebe8 <_stogir.switch.key+0x4e4>
    ea40:      	uxtb	w16, w19
    ea44:      	cmp	w16, wzr
    ea48:      	b.ne	0xebf0 <_stogir.switch.key+0x4ec>
    ea4c:      	uxtb	w16, w20
    ea50:      	cmp	w16, wzr
    ea54:      	b.ne	0xebf0 <_stogir.switch.key+0x4ec>
    ea58:      	uxtb	w16, w21
    ea5c:      	cmp	w16, wzr
    ea60:      	b.ne	0xebf0 <_stogir.switch.key+0x4ec>
    ea64:      	mov	x23, x22
    ea68:      	b	0xebf4 <_stogir.switch.key+0x4f0>
    ea6c:      	movz	x5, #0x0, lsl #48
    ea70:      	b	0xe9c8 <_stogir.switch.key+0x2c4>
    ea74:      	cmp	x1, x2
    ea78:      	b.ne	0xe804 <_stogir.switch.key+0x100>
    ea7c:      	lsr	w23, w23, #0
    ea80:      	lsr	w1, w5, #0
    ea84:      	sxtw	x23, w23
    ea88:      	ubfx	x1, x1, #0, #32
    ea8c:      	lsr	x4, x5, #32
    ea90:      	lsl	x5, x23, #3
    ea94:      	ubfx	x4, x4, #0, #32
    ea98:      	lsr	w5, w5, #0
    ea9c:      	lsl	x4, x4, #32
    eaa0:      	sxtw	x5, w5
    eaa4:      	orr	x1, x4, x1
    eaa8:      	cmp	x5, #0x40
    eaac:      	b.ge	0xeabc <_stogir.switch.key+0x3b8>
    eab0:      	lsr	x4, x1, x5
    eab4:      	cmp	x4, #0x0
    eab8:      	b.ne	0xe804 <_stogir.switch.key+0x100>
    eabc:      	uxtb	w16, w0
    eac0:      	cmp	w16, wzr
    eac4:      	b.eq	0xead0 <_stogir.switch.key+0x3cc>
    eac8:      	cmp	x1, #0x1
    eacc:      	b.hi	0xe804 <_stogir.switch.key+0x100>
    ead0:      	cmp	x2, #0x7
    ead4:      	b.lt	0xeaf8 <_stogir.switch.key+0x3f4>
    ead8:      	uxtb	w16, w3
    eadc:      	cmp	w16, wzr
    eae0:      	b.eq	0xeaf8 <_stogir.switch.key+0x3f4>
    eae4:      	uxtb	w16, w6
    eae8:      	cmp	w16, wzr
    eaec:      	b.eq	0xeb50 <_stogir.switch.key+0x44c>
    eaf0:      	movz	x0, #0x0, lsl #48
    eaf4:      	b	0xeb24 <_stogir.switch.key+0x420>
    eaf8:      	movz	x0, #0x0, lsl #48
    eafc:      	eor	x0, x0, x1
    eb00:      	mov	x1, x0
    eb04:      	movz	x0, #0x0, lsl #48
    eb08:      	movz	x2, #0x0, lsl #48
    eb0c:      	b	0xe81c <_stogir.switch.key+0x118>
    eb10:      	mov	x23, #0x2               ; =2
    eb14:      	b	0xe7e0 <_stogir.switch.key+0xdc>
    eb18:      	brk	#0
    eb1c:      	b	0xeb18 <_stogir.switch.key+0x414>
    eb20:      	mov	x0, #0x1                ; =1
    eb24:      	lsr	w0, w0, #0
    eb28:      	sxtw	x0, w0
    eb2c:      	lsl	x0, x0, #3
    eb30:      	lsr	w0, w0, #0
    eb34:      	sxtw	x0, w0
    eb38:      	sub	x0, x0, #0x1
    eb3c:      	lsr	w0, w0, #0
    eb40:      	sxtw	x0, w0
    eb44:      	mov	x16, #0x1               ; =1
    eb48:      	lsl	x0, x16, x0
    eb4c:      	b	0xeafc <_stogir.switch.key+0x3f8>
    eb50:      	uxtb	w16, w0
    eb54:      	cmp	w16, wzr
    eb58:      	b.ne	0xeb20 <_stogir.switch.key+0x41c>
    eb5c:      	uxtb	w16, w7
    eb60:      	cmp	w16, wzr
    eb64:      	b.ne	0xeb20 <_stogir.switch.key+0x41c>
    eb68:      	uxtb	w16, w9
    eb6c:      	cmp	w16, wzr
    eb70:      	b.ne	0xeb20 <_stogir.switch.key+0x41c>
    eb74:      	uxtb	w16, w10
    eb78:      	cmp	w16, wzr
    eb7c:      	b.ne	0xeb20 <_stogir.switch.key+0x41c>
    eb80:      	uxtb	w16, w11
    eb84:      	cmp	w16, wzr
    eb88:      	b.ne	0xebf8 <_stogir.switch.key+0x4f4>
    eb8c:      	uxtb	w16, w12
    eb90:      	cmp	w16, wzr
    eb94:      	b.ne	0xebf8 <_stogir.switch.key+0x4f4>
    eb98:      	uxtb	w16, w13
    eb9c:      	cmp	w16, wzr
    eba0:      	b.ne	0xec00 <_stogir.switch.key+0x4fc>
    eba4:      	uxtb	w16, w14
    eba8:      	cmp	w16, wzr
    ebac:      	b.ne	0xec00 <_stogir.switch.key+0x4fc>
    ebb0:      	uxtb	w16, w15
    ebb4:      	cmp	w16, wzr
    ebb8:      	b.ne	0xec00 <_stogir.switch.key+0x4fc>
    ebbc:      	uxtb	w16, w19
    ebc0:      	cmp	w16, wzr
    ebc4:      	b.ne	0xec08 <_stogir.switch.key+0x504>
    ebc8:      	uxtb	w16, w20
    ebcc:      	cmp	w16, wzr
    ebd0:      	b.ne	0xec08 <_stogir.switch.key+0x504>
    ebd4:      	uxtb	w16, w21
    ebd8:      	cmp	w16, wzr
    ebdc:      	b.ne	0xec08 <_stogir.switch.key+0x504>
    ebe0:      	mov	x0, x22
    ebe4:      	b	0xec0c <_stogir.switch.key+0x508>
    ebe8:      	mov	x23, #0x4               ; =4
    ebec:      	b	0xeb14 <_stogir.switch.key+0x410>
    ebf0:      	mov	x23, #0x8               ; =8
    ebf4:      	b	0xebec <_stogir.switch.key+0x4e8>
    ebf8:      	mov	x0, #0x2                ; =2
    ebfc:      	b	0xeb24 <_stogir.switch.key+0x420>
    ec00:      	mov	x0, #0x4                ; =4
    ec04:      	b	0xebfc <_stogir.switch.key+0x4f8>
    ec08:      	mov	x0, #0x8                ; =8
    ec0c:      	b	0xec04 <_stogir.switch.key+0x500>

000000000000ec10 <_stogir.stack.entry-allocation?>:
    ec10:      	sub	sp, sp, #0x10
    ec14:      	add	x2, x0, #0x78
    ec18:      	add	x3, x0, #0x28
    ec1c:      	add	x4, x0, #0x50
    ec20:      	add	x5, x0, #0x78
    ec24:      	add	x6, x0, #0x28
    ec28:      	add	x7, x0, #0x50
    ec2c:      	sxtw	x1, w1
    ec30:      	mov	x9, x1
    ec34:      	mov	x1, #0x1                ; =1
    ec38:      	movz	x8, #0x0, lsl #48
    ec3c:      	b	0xed84 <_stogir.stack.entry-allocation?+0x174>
    ec40:      	movz	x12, #0x0, lsl #48
    ec44:      	b	0xecbc <_stogir.stack.entry-allocation?+0xac>
    ec48:      	movz	x10, #0x0, lsl #48
    ec4c:      	movz	x11, #0x0, lsl #48
    ec50:      	lsr	w10, w10, #0
    ec54:      	lsr	x16, x10, #0
    ec58:      	cmp	x16, #0x1
    ec5c:      	b.eq	0xec78 <_stogir.stack.entry-allocation?+0x68>
    ec60:      	b.lo	0xec68 <_stogir.stack.entry-allocation?+0x58>
    ec64:      	b	0xec7c <_stogir.stack.entry-allocation?+0x6c>
    ec68:      	cmp	x16, #0x0
    ec6c:      	b.eq	0xec74 <_stogir.stack.entry-allocation?+0x64>
    ec70:      	b	0xec7c <_stogir.stack.entry-allocation?+0x6c>
    ec74:      	b	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ec78:      	b	0xec80 <_stogir.stack.entry-allocation?+0x70>
    ec7c:      	b	0xefb8 <_stogir.stack.entry-allocation?+0x3a8>
    ec80:      	uxtb	w10, w11
    ec84:      	lsr	w11, w11, #0
    ec88:      	ubfx	x11, x11, #8, #8
    ec8c:      	cmp	x10, x11
    ec90:      	b.eq	0xefa8 <_stogir.stack.entry-allocation?+0x398>
    ec94:      	cmp	x10, #0x49
    ec98:      	b.eq	0xefa8 <_stogir.stack.entry-allocation?+0x398>
    ec9c:      	movz	x1, #0x0, lsl #48
    eca0:      	fmov	d31, x8
    eca4:      	mov	x8, x9
    eca8:      	fmov	x9, d31
    ecac:      	b	0xee68 <_stogir.stack.entry-allocation?+0x258>
    ecb0:      	movz	x12, #0x0, lsl #48
    ecb4:      	b	0xecc4 <_stogir.stack.entry-allocation?+0xb4>
    ecb8:      	movz	x12, #0x0, lsl #48
    ecbc:      	b	0xeccc <_stogir.stack.entry-allocation?+0xbc>
    ecc0:      	movz	x12, #0x0, lsl #48
    ecc4:      	b	0xeccc <_stogir.stack.entry-allocation?+0xbc>
    ecc8:      	movz	x12, #0x0, lsl #48
    eccc:      	cmp	x12, #0x0
    ecd0:      	b.eq	0xed2c <_stogir.stack.entry-allocation?+0x11c>
    ecd4:      	uxtb	w16, w11
    ecd8:      	cmp	w16, wzr
    ecdc:      	b.eq	0xed00 <_stogir.stack.entry-allocation?+0xf0>
    ece0:      	ldr	x11, [x0]
    ece4:      	add	x10, x11, x10, lsl #4
    ece8:      	ldr	x11, [x10]
    ecec:      	ldr	x10, [x10, #0x8]
    ecf0:      	fmov	d31, x10
    ecf4:      	mov	x10, x11
    ecf8:      	fmov	x11, d31
    ecfc:      	b	0xed1c <_stogir.stack.entry-allocation?+0x10c>
    ed00:      	ldr	x10, [x0, #0x28]
    ed04:      	add	x10, x10, x13, lsl #4
    ed08:      	ldr	x11, [x10]
    ed0c:      	ldr	x10, [x10, #0x8]
    ed10:      	fmov	d31, x10
    ed14:      	mov	x10, x11
    ed18:      	fmov	x11, d31
    ed1c:      	mov	x12, x11
    ed20:      	mov	x11, x10
    ed24:      	mov	x10, #0x1               ; =1
    ed28:      	b	0xed38 <_stogir.stack.entry-allocation?+0x128>
    ed2c:      	movz	x10, #0x0, lsl #48
    ed30:      	movz	x11, #0x0, lsl #48
    ed34:      	movz	x12, #0x0, lsl #48
    ed38:      	lsr	w10, w10, #0
    ed3c:      	lsr	x16, x10, #0
    ed40:      	cmp	x16, #0x1
    ed44:      	b.eq	0xed60 <_stogir.stack.entry-allocation?+0x150>
    ed48:      	b.lo	0xed50 <_stogir.stack.entry-allocation?+0x140>
    ed4c:      	b	0xed64 <_stogir.stack.entry-allocation?+0x154>
    ed50:      	cmp	x16, #0x0
    ed54:      	b.eq	0xed5c <_stogir.stack.entry-allocation?+0x14c>
    ed58:      	b	0xed64 <_stogir.stack.entry-allocation?+0x154>
    ed5c:      	b	0xed68 <_stogir.stack.entry-allocation?+0x158>
    ed60:      	b	0xee34 <_stogir.stack.entry-allocation?+0x224>
    ed64:      	b	0xef10 <_stogir.stack.entry-allocation?+0x300>
    ed68:      	fmov	d31, x8
    ed6c:      	mov	x8, x9
    ed70:      	fmov	x9, d31
    ed74:      	movz	x1, #0x0, lsl #48
    ed78:      	fmov	d31, x8
    ed7c:      	mov	x8, x9
    ed80:      	fmov	x9, d31
    ed84:      	cmp	x1, #0x0
    ed88:      	b.eq	0xeef4 <_stogir.stack.entry-allocation?+0x2e4>
    ed8c:      	cmp	x8, #0x0
    ed90:      	b.ne	0xeef4 <_stogir.stack.entry-allocation?+0x2e4>
    ed94:      	lsr	w10, w9, #0
    ed98:      	sxtw	x10, w10
    ed9c:      	cmp	x10, #0x0
    eda0:      	cset	w11, gt
    eda4:      	movz	x16, #0x0, lsl #48
    eda8:      	sub	x12, x16, x10
    edac:      	sub	x13, x12, #0x1
    edb0:      	uxtb	w16, w11
    edb4:      	cmp	w16, wzr
    edb8:      	b.eq	0xedf4 <_stogir.stack.entry-allocation?+0x1e4>
    edbc:      	ldr	x12, [x0, #0x8]
    edc0:      	cmp	x10, x12
    edc4:      	b.ge	0xecc0 <_stogir.stack.entry-allocation?+0xb0>
    edc8:      	ldr	x12, [x2, #0x8]
    edcc:      	cmp	x10, x12
    edd0:      	b.ge	0xecb0 <_stogir.stack.entry-allocation?+0xa0>
    edd4:      	ldr	x12, [x0, #0x78]
    edd8:      	add	x12, x12, x10, lsl #2
    eddc:      	ldr	w12, [x12]
    ede0:      	sxtw	x12, w12
    ede4:      	cmp	x12, #0x0
    ede8:      	cset	w12, ge
    edec:      	ubfx	x12, x12, #0, #8
    edf0:      	b	0xecb4 <_stogir.stack.entry-allocation?+0xa4>
    edf4:      	cmp	x10, #0x0
    edf8:      	b.ge	0xecc8 <_stogir.stack.entry-allocation?+0xb8>
    edfc:      	ldr	x14, [x3, #0x8]
    ee00:      	ldr	x15, [x4, #0x8]
    ee04:      	cmp	x14, x15
    ee08:      	b.ne	0xecb8 <_stogir.stack.entry-allocation?+0xa8>
    ee0c:      	cmp	x12, x14
    ee10:      	b.gt	0xec40 <_stogir.stack.entry-allocation?+0x30>
    ee14:      	ldr	x12, [x0, #0x50]
    ee18:      	add	x12, x12, x13, lsl #2
    ee1c:      	ldr	w12, [x12]
    ee20:      	sxtw	x12, w12
    ee24:      	cmp	x12, #0x0
    ee28:      	cset	w12, gt
    ee2c:      	ubfx	x12, x12, #0, #8
    ee30:      	b	0xec44 <_stogir.stack.entry-allocation?+0x34>
    ee34:      	uxtb	w10, w11
    ee38:      	asr	x13, x11, #32
    ee3c:      	mov	x16, sp
    ee40:      	str	x11, [x16]
    ee44:      	mov	x16, sp
    ee48:      	str	x12, [x16, #0x8]
    ee4c:      	cmp	x10, #0x68
    ee50:      	b.ne	0xee6c <_stogir.stack.entry-allocation?+0x25c>
    ee54:      	cmp	x13, #0x0
    ee58:      	cset	w1, eq
    ee5c:      	ubfx	x1, x1, #0, #8
    ee60:      	mov	x8, x9
    ee64:      	mov	x9, #0x1                ; =1
    ee68:      	b	0xed78 <_stogir.stack.entry-allocation?+0x168>
    ee6c:      	cmp	x9, #0x0
    ee70:      	b.le	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ee74:      	cmp	x10, #0x51
    ee78:      	b.ne	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ee7c:      	cmp	x13, #0x0
    ee80:      	b.le	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ee84:      	cmp	x13, x9
    ee88:      	b.ge	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ee8c:      	lsr	w12, w12, #0
    ee90:      	sxtw	x12, w12
    ee94:      	cmp	x12, #0x0
    ee98:      	b.ge	0xec9c <_stogir.stack.entry-allocation?+0x8c>
    ee9c:      	cmp	x12, #0x0
    eea0:      	cset	w10, gt
    eea4:      	movz	x16, #0x0, lsl #48
    eea8:      	sub	x11, x16, x12
    eeac:      	sub	x13, x11, #0x1
    eeb0:      	uxtb	w16, w10
    eeb4:      	cmp	w16, wzr
    eeb8:      	b.eq	0xef60 <_stogir.stack.entry-allocation?+0x350>
    eebc:      	ldr	x11, [x0, #0x8]
    eec0:      	cmp	x12, x11
    eec4:      	b.ge	0xef58 <_stogir.stack.entry-allocation?+0x348>
    eec8:      	ldr	x11, [x5, #0x8]
    eecc:      	cmp	x12, x11
    eed0:      	b.ge	0xefa0 <_stogir.stack.entry-allocation?+0x390>
    eed4:      	ldr	x11, [x0, #0x78]
    eed8:      	add	x11, x11, x12, lsl #2
    eedc:      	ldr	w11, [x11]
    eee0:      	sxtw	x11, w11
    eee4:      	cmp	x11, #0x0
    eee8:      	cset	w11, ge
    eeec:      	ubfx	x11, x11, #0, #8
    eef0:      	b	0xefa4 <_stogir.stack.entry-allocation?+0x394>
    eef4:      	cmp	x1, #0x0
    eef8:      	b.eq	0xef04 <_stogir.stack.entry-allocation?+0x2f4>
    eefc:      	mov	x0, x8
    ef00:      	b	0xef08 <_stogir.stack.entry-allocation?+0x2f8>
    ef04:      	movz	x0, #0x0, lsl #48
    ef08:      	add	sp, sp, #0x10
    ef0c:      	ret
    ef10:      	brk	#0
    ef14:      	b	0xef10 <_stogir.stack.entry-allocation?+0x300>
    ef18:      	ldr	x10, [x0, #0x28]
    ef1c:      	add	x10, x10, x13, lsl #4
    ef20:      	ldr	x10, [x10]
    ef24:      	mov	x11, x10
    ef28:      	mov	x10, #0x1               ; =1
    ef2c:      	b	0xec50 <_stogir.stack.entry-allocation?+0x40>
    ef30:      	movz	x11, #0x0, lsl #48
    ef34:      	cmp	x11, #0x0
    ef38:      	b.eq	0xec48 <_stogir.stack.entry-allocation?+0x38>
    ef3c:      	uxtb	w16, w10
    ef40:      	cmp	w16, wzr
    ef44:      	b.eq	0xef18 <_stogir.stack.entry-allocation?+0x308>
    ef48:      	ldr	x10, [x0]
    ef4c:      	add	x10, x10, x12, lsl #4
    ef50:      	ldr	x10, [x10]
    ef54:      	b	0xef24 <_stogir.stack.entry-allocation?+0x314>
    ef58:      	movz	x11, #0x0, lsl #48
    ef5c:      	b	0xef34 <_stogir.stack.entry-allocation?+0x324>
    ef60:      	ldr	x14, [x6, #0x8]
    ef64:      	ldr	x15, [x7, #0x8]
    ef68:      	cmp	x14, x15
    ef6c:      	b.ne	0xef30 <_stogir.stack.entry-allocation?+0x320>
    ef70:      	cmp	x11, x14
    ef74:      	b.gt	0xef98 <_stogir.stack.entry-allocation?+0x388>
    ef78:      	ldr	x11, [x0, #0x50]
    ef7c:      	add	x11, x11, x13, lsl #2
    ef80:      	ldr	w11, [x11]
    ef84:      	sxtw	x11, w11
    ef88:      	cmp	x11, #0x0
    ef8c:      	cset	w11, gt
    ef90:      	ubfx	x11, x11, #0, #8
    ef94:      	b	0xef9c <_stogir.stack.entry-allocation?+0x38c>
    ef98:      	movz	x11, #0x0, lsl #48
    ef9c:      	b	0xef34 <_stogir.stack.entry-allocation?+0x324>
    efa0:      	movz	x11, #0x0, lsl #48
    efa4:      	b	0xef5c <_stogir.stack.entry-allocation?+0x34c>
    efa8:      	mov	x16, sp
    efac:      	ldr	w9, [x16, #0x4]
    efb0:      	sxtw	x9, w9
    efb4:      	b	0xeca0 <_stogir.stack.entry-allocation?+0x90>
    efb8:      	brk	#0
    efbc:      	b	0xefb8 <_stogir.stack.entry-allocation?+0x3a8>

000000000000efc0 <_stogir.stack.constant-size>:
    efc0:      	sub	sp, sp, #0x10
    efc4:      	str	x29, [sp]
    efc8:      	str	x30, [sp, #0x8]
    efcc:      	mov	x29, sp
    efd0:      	mov	x2, sp
    efd4:      	sxtw	x1, w1
    efd8:      	sub	sp, sp, #0x10
    efdc:      	mov	x3, sp
    efe0:      	cmp	x1, #0x0
    efe4:      	cset	w4, gt
    efe8:      	movz	x16, #0x0, lsl #48
    efec:      	sub	x5, x16, x1
    eff0:      	sub	x6, x5, #0x1
    eff4:      	uxtb	w16, w4
    eff8:      	cmp	w16, wzr
    effc:      	b.eq	0xf03c <_stogir.stack.constant-size+0x7c>
    f000:      	ldr	x5, [x0, #0x8]
    f004:      	cmp	x1, x5
    f008:      	b.ge	0xf08c <_stogir.stack.constant-size+0xcc>
    f00c:      	add	x5, x0, #0x78
    f010:      	ldr	x5, [x5, #0x8]
    f014:      	cmp	x1, x5
    f018:      	b.ge	0xf1f8 <_stogir.stack.constant-size+0x238>
    f01c:      	ldr	x5, [x0, #0x78]
    f020:      	add	x5, x5, x1, lsl #2
    f024:      	ldr	w5, [x5]
    f028:      	sxtw	x5, w5
    f02c:      	cmp	x5, #0x0
    f030:      	cset	w5, ge
    f034:      	ubfx	x5, x5, #0, #8
    f038:      	b	0xf1fc <_stogir.stack.constant-size+0x23c>
    f03c:      	cmp	x1, #0x0
    f040:      	b.ge	0xf094 <_stogir.stack.constant-size+0xd4>
    f044:      	add	x7, x0, #0x28
    f048:      	add	x9, x0, #0x50
    f04c:      	ldr	x7, [x7, #0x8]
    f050:      	ldr	x9, [x9, #0x8]
    f054:      	cmp	x7, x9
    f058:      	b.ne	0xf084 <_stogir.stack.constant-size+0xc4>
    f05c:      	cmp	x5, x7
    f060:      	b.gt	0xf280 <_stogir.stack.constant-size+0x2c0>
    f064:      	ldr	x5, [x0, #0x50]
    f068:      	add	x5, x5, x6, lsl #2
    f06c:      	ldr	w5, [x5]
    f070:      	sxtw	x5, w5
    f074:      	cmp	x5, #0x0
    f078:      	cset	w5, gt
    f07c:      	ubfx	x5, x5, #0, #8
    f080:      	b	0xf284 <_stogir.stack.constant-size+0x2c4>
    f084:      	movz	x5, #0x0, lsl #48
    f088:      	b	0xf098 <_stogir.stack.constant-size+0xd8>
    f08c:      	movz	x5, #0x0, lsl #48
    f090:      	b	0xf098 <_stogir.stack.constant-size+0xd8>
    f094:      	movz	x5, #0x0, lsl #48
    f098:      	cmp	x5, #0x0
    f09c:      	b.eq	0xf0f8 <_stogir.stack.constant-size+0x138>
    f0a0:      	uxtb	w16, w4
    f0a4:      	cmp	w16, wzr
    f0a8:      	b.eq	0xf0cc <_stogir.stack.constant-size+0x10c>
    f0ac:      	ldr	x0, [x0]
    f0b0:      	add	x0, x0, x1, lsl #4
    f0b4:      	ldr	x4, [x0]
    f0b8:      	ldr	x0, [x0, #0x8]
    f0bc:      	fmov	d31, x0
    f0c0:      	mov	x0, x4
    f0c4:      	fmov	x4, d31
    f0c8:      	b	0xf0e8 <_stogir.stack.constant-size+0x128>
    f0cc:      	ldr	x0, [x0, #0x28]
    f0d0:      	add	x0, x0, x6, lsl #4
    f0d4:      	ldr	x4, [x0]
    f0d8:      	ldr	x0, [x0, #0x8]
    f0dc:      	fmov	d31, x0
    f0e0:      	mov	x0, x4
    f0e4:      	fmov	x4, d31
    f0e8:      	mov	x5, x4
    f0ec:      	mov	x4, x0
    f0f0:      	mov	x0, #0x1                ; =1
    f0f4:      	b	0xf104 <_stogir.stack.constant-size+0x144>
    f0f8:      	movz	x0, #0x0, lsl #48
    f0fc:      	movz	x4, #0x0, lsl #48
    f100:      	movz	x5, #0x0, lsl #48
    f104:      	lsr	w0, w0, #0
    f108:      	lsr	x16, x0, #0
    f10c:      	cmp	x16, #0x1
    f110:      	b.eq	0xf12c <_stogir.stack.constant-size+0x16c>
    f114:      	b.lo	0xf11c <_stogir.stack.constant-size+0x15c>
    f118:      	b	0xf130 <_stogir.stack.constant-size+0x170>
    f11c:      	cmp	x16, #0x0
    f120:      	b.eq	0xf128 <_stogir.stack.constant-size+0x168>
    f124:      	b	0xf130 <_stogir.stack.constant-size+0x170>
    f128:      	b	0xf134 <_stogir.stack.constant-size+0x174>
    f12c:      	b	0xf1d8 <_stogir.stack.constant-size+0x218>
    f130:      	b	0xf338 <_stogir.stack.constant-size+0x378>
    f134:      	adrp	x16, 0xf000 <_stogir.stack.constant-size+0x40>
		000000000000f134:  ARM64_RELOC_PAGE21	l_stogir.514
    f138:      	ldr	x16, [x16]
		000000000000f138:  ARM64_RELOC_PAGEOFF12	l_stogir.514
    f13c:      	orr	x0, x16, xzr
    f140:      	mov	x1, x0
    f144:      	mov	x0, #0x1                ; =1
    f148:      	mov	x3, #0x18               ; =24
    f14c:      	b	0xf1b4 <_stogir.stack.constant-size+0x1f4>
    f150:      	mov	x4, #0x1                ; =1
    f154:      	ldr	w5, [x3, #0x8]
    f158:      	ldr	w6, [x3, #0xc]
    f15c:      	cmp	x1, #0x0
    f160:      	b.ge	0xf19c <_stogir.stack.constant-size+0x1dc>
    f164:      	cmp	x0, #0x1
    f168:      	b.lt	0xf19c <_stogir.stack.constant-size+0x1dc>
    f16c:      	cmp	x0, #0xb
    f170:      	cset	w1, le
    f174:      	uxtb	w16, w1
    f178:      	cmp	w16, wzr
    f17c:      	b.eq	0xf19c <_stogir.stack.constant-size+0x1dc>
    f180:      	ldr	w3, [x3]
    f184:      	uxtb	w7, w3
    f188:      	ubfx	x3, x3, #8, #8
    f18c:      	cmp	x7, x3
    f190:      	b.eq	0xf288 <_stogir.stack.constant-size+0x2c8>
    f194:      	cmp	x7, #0x49
    f198:      	b.eq	0xf288 <_stogir.stack.constant-size+0x2c8>
    f19c:      	adrp	x16, 0xf000 <_stogir.stack.constant-size+0x40>
		000000000000f19c:  ARM64_RELOC_PAGE21	l_stogir.515
    f1a0:      	ldr	x16, [x16]
		000000000000f1a0:  ARM64_RELOC_PAGEOFF12	l_stogir.515
    f1a4:      	orr	x0, x16, xzr
    f1a8:      	mov	x1, x0
    f1ac:      	mov	x0, #0x1                ; =1
    f1b0:      	mov	x3, #0x30               ; =48
    f1b4:      	mov	sp, x2
    f1b8:      	str	x0, [x8]
    f1bc:      	str	x1, [x8, #0x8]
    f1c0:      	str	x3, [x8, #0x10]
    f1c4:      	sub	sp, x29, #0x0
    f1c8:      	ldr	x29, [sp]
    f1cc:      	ldr	x30, [sp, #0x8]
    f1d0:      	add	sp, sp, #0x10
    f1d4:      	ret
    f1d8:      	lsr	w0, w4, #0
    f1dc:      	str	x4, [x3]
    f1e0:      	str	x5, [x3, #0x8]
    f1e4:      	ubfx	x0, x0, #8, #8
    f1e8:      	cmp	x0, #0x0
    f1ec:      	b.ne	0xf200 <_stogir.stack.constant-size+0x240>
    f1f0:      	movz	x4, #0x0, lsl #48
    f1f4:      	b	0xf154 <_stogir.stack.constant-size+0x194>
    f1f8:      	movz	x5, #0x0, lsl #48
    f1fc:      	b	0xf090 <_stogir.stack.constant-size+0xd0>
    f200:      	cmp	x0, #0x1
    f204:      	b.eq	0xf150 <_stogir.stack.constant-size+0x190>
    f208:      	cmp	x0, #0x2
    f20c:      	b.eq	0xf150 <_stogir.stack.constant-size+0x190>
    f210:      	cmp	x0, #0x7
    f214:      	b.eq	0xf150 <_stogir.stack.constant-size+0x190>
    f218:      	cmp	x0, #0x8
    f21c:      	b.eq	0xf150 <_stogir.stack.constant-size+0x190>
    f220:      	cmp	x0, #0x3
    f224:      	b.eq	0xf330 <_stogir.stack.constant-size+0x370>
    f228:      	cmp	x0, #0x9
    f22c:      	b.eq	0xf330 <_stogir.stack.constant-size+0x370>
    f230:      	cmp	x0, #0x4
    f234:      	b.eq	0xf340 <_stogir.stack.constant-size+0x380>
    f238:      	cmp	x0, #0xa
    f23c:      	b.eq	0xf340 <_stogir.stack.constant-size+0x380>
    f240:      	cmp	x0, #0xd
    f244:      	b.eq	0xf340 <_stogir.stack.constant-size+0x380>
    f248:      	cmp	x0, #0x5
    f24c:      	b.eq	0xf348 <_stogir.stack.constant-size+0x388>
    f250:      	cmp	x0, #0xb
    f254:      	b.eq	0xf348 <_stogir.stack.constant-size+0x388>
    f258:      	cmp	x0, #0xc
    f25c:      	b.eq	0xf348 <_stogir.stack.constant-size+0x388>
    f260:      	cmp	x0, #0x6
    f264:      	cset	w4, eq
    f268:      	uxtb	w16, w4
    f26c:      	cmp	w16, wzr
    f270:      	mov	x16, #0x8               ; =8
    f274:      	movn	x17, #0x0, lsl #48
    f278:      	csel	x4, x16, x17, ne
    f27c:      	b	0xf34c <_stogir.stack.constant-size+0x38c>
    f280:      	movz	x5, #0x0, lsl #48
    f284:      	b	0xf088 <_stogir.stack.constant-size+0xc8>
    f288:      	lsr	w4, w4, #0
    f28c:      	sxtw	x4, w4
    f290:      	cmp	x4, #0x0
    f294:      	b.le	0xf19c <_stogir.stack.constant-size+0x1dc>
    f298:      	ubfx	x5, x5, #0, #32
    f29c:      	ubfx	x6, x6, #0, #32
    f2a0:      	lsl	x3, x6, #32
    f2a4:      	orr	x3, x3, x5
    f2a8:      	cmp	x4, #0x8
    f2ac:      	b.ge	0xf2c8 <_stogir.stack.constant-size+0x308>
    f2b0:      	lsl	x5, x4, #3
    f2b4:      	lsr	w5, w5, #0
    f2b8:      	sxtw	x5, w5
    f2bc:      	lsr	x5, x3, x5
    f2c0:      	cmp	x5, #0x0
    f2c4:      	b.ne	0xf19c <_stogir.stack.constant-size+0x1dc>
    f2c8:      	cmp	x0, #0x7
    f2cc:      	b.lt	0xf308 <_stogir.stack.constant-size+0x348>
    f2d0:      	uxtb	w16, w1
    f2d4:      	cmp	w16, wzr
    f2d8:      	b.eq	0xf308 <_stogir.stack.constant-size+0x348>
    f2dc:      	lsl	x0, x4, #3
    f2e0:      	lsr	w0, w0, #0
    f2e4:      	sxtw	x0, w0
    f2e8:      	sub	x0, x0, #0x1
    f2ec:      	lsr	w0, w0, #0
    f2f0:      	sxtw	x0, w0
    f2f4:      	mov	x16, #0x1               ; =1
    f2f8:      	lsl	x0, x16, x0
    f2fc:      	and	x0, x0, x3
    f300:      	cmp	x0, #0x0
    f304:      	b.ne	0xf19c <_stogir.stack.constant-size+0x1dc>
    f308:      	mov	x17, #-0x10             ; =-16
    f30c:      	movk	x17, #0x7fff, lsl #48
    f310:      	cmp	x3, x17
    f314:      	b.hi	0xf19c <_stogir.stack.constant-size+0x1dc>
    f318:      	add	x0, x3, #0xf
    f31c:      	and	x0, x0, #0xfffffffffffffff0
    f320:      	mov	x1, x0
    f324:      	movz	x0, #0x0, lsl #48
    f328:      	movz	x3, #0x0, lsl #48
    f32c:      	b	0xf1b4 <_stogir.stack.constant-size+0x1f4>
    f330:      	mov	x4, #0x2                ; =2
    f334:      	b	0xf154 <_stogir.stack.constant-size+0x194>
    f338:      	brk	#0
    f33c:      	b	0xf338 <_stogir.stack.constant-size+0x378>
    f340:      	mov	x4, #0x4                ; =4
    f344:      	b	0xf334 <_stogir.stack.constant-size+0x374>
    f348:      	mov	x4, #0x8                ; =8
    f34c:      	b	0xf344 <_stogir.stack.constant-size+0x384>

000000000000f350 <_stogir.frame.valid-alignment?>:
    f350:      	cmp	x0, #0x0
    f354:      	b.le	0xf370 <_stogir.frame.valid-alignment?+0x20>
    f358:      	sub	x1, x0, #0x1
    f35c:      	and	x0, x1, x0
    f360:      	cmp	x0, #0x0
    f364:      	cset	w0, eq
    f368:      	ubfx	x0, x0, #0, #8
    f36c:      	b	0xf374 <_stogir.frame.valid-alignment?+0x24>
    f370:      	movz	x0, #0x0, lsl #48
    f374:      	ret

000000000000f378 <_stogir.stack.constant-size-aligned>:
    f378:      	sub	sp, sp, #0x10
    f37c:      	cmp	x2, #0x10
    f380:      	b.lt	0xf3fc <_stogir.stack.constant-size-aligned+0x84>
    f384:      	cmp	x2, #0x0
    f388:      	b.le	0xf3fc <_stogir.stack.constant-size-aligned+0x84>
    f38c:      	sub	x3, x2, #0x1
    f390:      	and	x3, x3, x2
    f394:      	cmp	x3, #0x0
    f398:      	b.ne	0xf3fc <_stogir.stack.constant-size-aligned+0x84>
    f39c:      	sxtw	x1, w1
    f3a0:      	cmp	x1, #0x0
    f3a4:      	cset	w3, gt
    f3a8:      	movz	x16, #0x0, lsl #48
    f3ac:      	sub	x4, x16, x1
    f3b0:      	sub	x5, x4, #0x1
    f3b4:      	uxtb	w16, w3
    f3b8:      	cmp	w16, wzr
    f3bc:      	b.eq	0xf49c <_stogir.stack.constant-size-aligned+0x124>
    f3c0:      	ldr	x4, [x0, #0x8]
    f3c4:      	cmp	x1, x4
    f3c8:      	b.ge	0xf4e4 <_stogir.stack.constant-size-aligned+0x16c>
    f3cc:      	add	x4, x0, #0x78
    f3d0:      	ldr	x4, [x4, #0x8]
    f3d4:      	cmp	x1, x4
    f3d8:      	b.ge	0xf5d8 <_stogir.stack.constant-size-aligned+0x260>
    f3dc:      	ldr	x4, [x0, #0x78]
    f3e0:      	add	x4, x4, x1, lsl #2
    f3e4:      	ldr	w4, [x4]
    f3e8:      	sxtw	x4, w4
    f3ec:      	cmp	x4, #0x0
    f3f0:      	cset	w4, ge
    f3f4:      	ubfx	x4, x4, #0, #8
    f3f8:      	b	0xf5dc <_stogir.stack.constant-size-aligned+0x264>
    f3fc:      	adrp	x16, 0xf000 <_stogir.stack.constant-size+0x40>
		000000000000f3fc:  ARM64_RELOC_PAGE21	l_stogir.516
    f400:      	ldr	x16, [x16]
		000000000000f400:  ARM64_RELOC_PAGEOFF12	l_stogir.516
    f404:      	orr	x0, x16, xzr
    f408:      	mov	x1, x0
    f40c:      	mov	x0, #0x1                ; =1
    f410:      	mov	x2, #0x20               ; =32
    f414:      	str	x0, [x8]
    f418:      	str	x1, [x8, #0x8]
    f41c:      	str	x2, [x8, #0x10]
    f420:      	add	sp, sp, #0x10
    f424:      	ret
    f428:      	mov	x3, #0x1                ; =1
    f42c:      	mov	x16, sp
    f430:      	ldr	w4, [x16, #0x8]
    f434:      	mov	x16, sp
    f438:      	ldr	w5, [x16, #0xc]
    f43c:      	cmp	x1, #0x0
    f440:      	b.ge	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f444:      	cmp	x0, #0x1
    f448:      	b.lt	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f44c:      	cmp	x0, #0xb
    f450:      	cset	w1, le
    f454:      	uxtb	w16, w1
    f458:      	cmp	w16, wzr
    f45c:      	b.eq	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f460:      	mov	x16, sp
    f464:      	ldr	w6, [x16]
    f468:      	uxtb	w7, w6
    f46c:      	ubfx	x6, x6, #8, #8
    f470:      	cmp	x7, x6
    f474:      	b.eq	0xf668 <_stogir.stack.constant-size-aligned+0x2f0>
    f478:      	cmp	x7, #0x49
    f47c:      	b.eq	0xf668 <_stogir.stack.constant-size-aligned+0x2f0>
    f480:      	adrp	x16, 0xf000 <_stogir.stack.constant-size+0x40>
		000000000000f480:  ARM64_RELOC_PAGE21	l_stogir.517
    f484:      	ldr	x16, [x16]
		000000000000f484:  ARM64_RELOC_PAGEOFF12	l_stogir.517
    f488:      	orr	x0, x16, xzr
    f48c:      	mov	x1, x0
    f490:      	mov	x0, #0x1                ; =1
    f494:      	mov	x2, #0x30               ; =48
    f498:      	b	0xf414 <_stogir.stack.constant-size-aligned+0x9c>
    f49c:      	cmp	x1, #0x0
    f4a0:      	b.ge	0xf4ec <_stogir.stack.constant-size-aligned+0x174>
    f4a4:      	add	x6, x0, #0x28
    f4a8:      	add	x7, x0, #0x50
    f4ac:      	ldr	x6, [x6, #0x8]
    f4b0:      	ldr	x7, [x7, #0x8]
    f4b4:      	cmp	x6, x7
    f4b8:      	b.ne	0xf5d0 <_stogir.stack.constant-size-aligned+0x258>
    f4bc:      	cmp	x4, x6
    f4c0:      	b.gt	0xf660 <_stogir.stack.constant-size-aligned+0x2e8>
    f4c4:      	ldr	x4, [x0, #0x50]
    f4c8:      	add	x4, x4, x5, lsl #2
    f4cc:      	ldr	w4, [x4]
    f4d0:      	sxtw	x4, w4
    f4d4:      	cmp	x4, #0x0
    f4d8:      	cset	w4, gt
    f4dc:      	ubfx	x4, x4, #0, #8
    f4e0:      	b	0xf664 <_stogir.stack.constant-size-aligned+0x2ec>
    f4e4:      	movz	x4, #0x0, lsl #48
    f4e8:      	b	0xf4f0 <_stogir.stack.constant-size-aligned+0x178>
    f4ec:      	movz	x4, #0x0, lsl #48
    f4f0:      	cmp	x4, #0x0
    f4f4:      	b.eq	0xf550 <_stogir.stack.constant-size-aligned+0x1d8>
    f4f8:      	uxtb	w16, w3
    f4fc:      	cmp	w16, wzr
    f500:      	b.eq	0xf524 <_stogir.stack.constant-size-aligned+0x1ac>
    f504:      	ldr	x0, [x0]
    f508:      	add	x0, x0, x1, lsl #4
    f50c:      	ldr	x3, [x0]
    f510:      	ldr	x0, [x0, #0x8]
    f514:      	fmov	d31, x0
    f518:      	mov	x0, x3
    f51c:      	fmov	x3, d31
    f520:      	b	0xf540 <_stogir.stack.constant-size-aligned+0x1c8>
    f524:      	ldr	x0, [x0, #0x28]
    f528:      	add	x0, x0, x5, lsl #4
    f52c:      	ldr	x3, [x0]
    f530:      	ldr	x0, [x0, #0x8]
    f534:      	fmov	d31, x0
    f538:      	mov	x0, x3
    f53c:      	fmov	x3, d31
    f540:      	mov	x4, x3
    f544:      	mov	x3, x0
    f548:      	mov	x0, #0x1                ; =1
    f54c:      	b	0xf55c <_stogir.stack.constant-size-aligned+0x1e4>
    f550:      	movz	x0, #0x0, lsl #48
    f554:      	movz	x3, #0x0, lsl #48
    f558:      	movz	x4, #0x0, lsl #48
    f55c:      	lsr	w0, w0, #0
    f560:      	lsr	x16, x0, #0
    f564:      	cmp	x16, #0x1
    f568:      	b.eq	0xf584 <_stogir.stack.constant-size-aligned+0x20c>
    f56c:      	b.lo	0xf574 <_stogir.stack.constant-size-aligned+0x1fc>
    f570:      	b	0xf588 <_stogir.stack.constant-size-aligned+0x210>
    f574:      	cmp	x16, #0x0
    f578:      	b.eq	0xf580 <_stogir.stack.constant-size-aligned+0x208>
    f57c:      	b	0xf588 <_stogir.stack.constant-size-aligned+0x210>
    f580:      	b	0xf58c <_stogir.stack.constant-size-aligned+0x214>
    f584:      	b	0xf5a8 <_stogir.stack.constant-size-aligned+0x230>
    f588:      	b	0xf728 <_stogir.stack.constant-size-aligned+0x3b0>
    f58c:      	adrp	x16, 0xf000 <_stogir.stack.constant-size+0x40>
		000000000000f58c:  ARM64_RELOC_PAGE21	l_stogir.518
    f590:      	ldr	x16, [x16]
		000000000000f590:  ARM64_RELOC_PAGEOFF12	l_stogir.518
    f594:      	orr	x0, x16, xzr
    f598:      	mov	x1, x0
    f59c:      	mov	x0, #0x1                ; =1
    f5a0:      	mov	x2, #0x18               ; =24
    f5a4:      	b	0xf498 <_stogir.stack.constant-size-aligned+0x120>
    f5a8:      	lsr	w0, w3, #0
    f5ac:      	mov	x16, sp
    f5b0:      	str	x3, [x16]
    f5b4:      	mov	x16, sp
    f5b8:      	str	x4, [x16, #0x8]
    f5bc:      	ubfx	x0, x0, #8, #8
    f5c0:      	cmp	x0, #0x0
    f5c4:      	b.ne	0xf5e0 <_stogir.stack.constant-size-aligned+0x268>
    f5c8:      	movz	x3, #0x0, lsl #48
    f5cc:      	b	0xf42c <_stogir.stack.constant-size-aligned+0xb4>
    f5d0:      	movz	x4, #0x0, lsl #48
    f5d4:      	b	0xf4f0 <_stogir.stack.constant-size-aligned+0x178>
    f5d8:      	movz	x4, #0x0, lsl #48
    f5dc:      	b	0xf4e8 <_stogir.stack.constant-size-aligned+0x170>
    f5e0:      	cmp	x0, #0x1
    f5e4:      	b.eq	0xf428 <_stogir.stack.constant-size-aligned+0xb0>
    f5e8:      	cmp	x0, #0x2
    f5ec:      	b.eq	0xf428 <_stogir.stack.constant-size-aligned+0xb0>
    f5f0:      	cmp	x0, #0x7
    f5f4:      	b.eq	0xf428 <_stogir.stack.constant-size-aligned+0xb0>
    f5f8:      	cmp	x0, #0x8
    f5fc:      	b.eq	0xf428 <_stogir.stack.constant-size-aligned+0xb0>
    f600:      	cmp	x0, #0x3
    f604:      	b.eq	0xf720 <_stogir.stack.constant-size-aligned+0x3a8>
    f608:      	cmp	x0, #0x9
    f60c:      	b.eq	0xf720 <_stogir.stack.constant-size-aligned+0x3a8>
    f610:      	cmp	x0, #0x4
    f614:      	b.eq	0xf730 <_stogir.stack.constant-size-aligned+0x3b8>
    f618:      	cmp	x0, #0xa
    f61c:      	b.eq	0xf730 <_stogir.stack.constant-size-aligned+0x3b8>
    f620:      	cmp	x0, #0xd
    f624:      	b.eq	0xf730 <_stogir.stack.constant-size-aligned+0x3b8>
    f628:      	cmp	x0, #0x5
    f62c:      	b.eq	0xf738 <_stogir.stack.constant-size-aligned+0x3c0>
    f630:      	cmp	x0, #0xb
    f634:      	b.eq	0xf738 <_stogir.stack.constant-size-aligned+0x3c0>
    f638:      	cmp	x0, #0xc
    f63c:      	b.eq	0xf738 <_stogir.stack.constant-size-aligned+0x3c0>
    f640:      	cmp	x0, #0x6
    f644:      	cset	w3, eq
    f648:      	uxtb	w16, w3
    f64c:      	cmp	w16, wzr
    f650:      	mov	x16, #0x8               ; =8
    f654:      	movn	x17, #0x0, lsl #48
    f658:      	csel	x3, x16, x17, ne
    f65c:      	b	0xf73c <_stogir.stack.constant-size-aligned+0x3c4>
    f660:      	movz	x4, #0x0, lsl #48
    f664:      	b	0xf5d4 <_stogir.stack.constant-size-aligned+0x25c>
    f668:      	lsr	w3, w3, #0
    f66c:      	sxtw	x3, w3
    f670:      	cmp	x3, #0x0
    f674:      	b.le	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f678:      	ubfx	x4, x4, #0, #32
    f67c:      	ubfx	x5, x5, #0, #32
    f680:      	lsl	x5, x5, #32
    f684:      	orr	x4, x5, x4
    f688:      	cmp	x3, #0x8
    f68c:      	b.ge	0xf6a8 <_stogir.stack.constant-size-aligned+0x330>
    f690:      	lsl	x5, x3, #3
    f694:      	lsr	w5, w5, #0
    f698:      	sxtw	x5, w5
    f69c:      	lsr	x5, x4, x5
    f6a0:      	cmp	x5, #0x0
    f6a4:      	b.ne	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f6a8:      	cmp	x0, #0x7
    f6ac:      	b.lt	0xf6e8 <_stogir.stack.constant-size-aligned+0x370>
    f6b0:      	uxtb	w16, w1
    f6b4:      	cmp	w16, wzr
    f6b8:      	b.eq	0xf6e8 <_stogir.stack.constant-size-aligned+0x370>
    f6bc:      	lsl	x0, x3, #3
    f6c0:      	lsr	w0, w0, #0
    f6c4:      	sxtw	x0, w0
    f6c8:      	sub	x0, x0, #0x1
    f6cc:      	lsr	w0, w0, #0
    f6d0:      	sxtw	x0, w0
    f6d4:      	mov	x16, #0x1               ; =1
    f6d8:      	lsl	x0, x16, x0
    f6dc:      	and	x0, x0, x4
    f6e0:      	cmp	x0, #0x0
    f6e4:      	b.ne	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f6e8:      	sub	x0, x2, #0x1
    f6ec:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
    f6f0:      	sub	x0, x16, x0
    f6f4:      	cmp	x4, x0
    f6f8:      	b.hi	0xf480 <_stogir.stack.constant-size-aligned+0x108>
    f6fc:      	sub	x0, x2, #0x1
    f700:      	movz	x16, #0x0, lsl #48
    f704:      	sub	x1, x16, x2
    f708:      	add	x0, x0, x4
    f70c:      	and	x0, x1, x0
    f710:      	mov	x1, x0
    f714:      	movz	x0, #0x0, lsl #48
    f718:      	movz	x2, #0x0, lsl #48
    f71c:      	b	0xf498 <_stogir.stack.constant-size-aligned+0x120>
    f720:      	mov	x3, #0x2                ; =2
    f724:      	b	0xf42c <_stogir.stack.constant-size-aligned+0xb4>
    f728:      	brk	#0
    f72c:      	b	0xf728 <_stogir.stack.constant-size-aligned+0x3b0>
    f730:      	mov	x3, #0x4                ; =4
    f734:      	b	0xf724 <_stogir.stack.constant-size-aligned+0x3ac>
    f738:      	mov	x3, #0x8                ; =8
    f73c:      	b	0xf734 <_stogir.stack.constant-size-aligned+0x3bc>

000000000000f740 <_stogir.numeric-conversion.operation?>:
    f740:      	sxtw	x0, w0
    f744:      	cmp	x0, #0x25
    f748:      	b.lt	0xf75c <_stogir.numeric-conversion.operation?+0x1c>
    f74c:      	cmp	x0, #0x27
    f750:      	cset	w0, le
    f754:      	ubfx	x0, x0, #0, #8
    f758:      	b	0xf760 <_stogir.numeric-conversion.operation?+0x20>
    f75c:      	movz	x0, #0x0, lsl #48
    f760:      	ret

000000000000f764 <_stogir.numeric-conversion.valid-types?>:
    f764:      	sxtw	x0, w0
    f768:      	sxtw	x1, w1
    f76c:      	sxtw	x2, w2
    f770:      	cmp	x2, #0xc
    f774:      	cset	w3, eq
    f778:      	cmp	x2, #0xd
    f77c:      	cset	w4, eq
    f780:      	ubfx	x4, x4, #0, #8
    f784:      	cmp	x0, #0x25
    f788:      	b.ne	0xf7b0 <_stogir.numeric-conversion.valid-types?+0x4c>
    f78c:      	cmp	x1, #0x1
    f790:      	b.lt	0xf818 <_stogir.numeric-conversion.valid-types?+0xb4>
    f794:      	cmp	x1, #0xb
    f798:      	b.gt	0xf818 <_stogir.numeric-conversion.valid-types?+0xb4>
    f79c:      	uxtb	w16, w3
    f7a0:      	cmp	w16, wzr
    f7a4:      	b.eq	0xf828 <_stogir.numeric-conversion.valid-types?+0xc4>
    f7a8:      	mov	x0, #0x1                ; =1
    f7ac:      	b	0xf82c <_stogir.numeric-conversion.valid-types?+0xc8>
    f7b0:      	cmp	x1, #0xc
    f7b4:      	cset	w5, eq
    f7b8:      	cmp	x1, #0xd
    f7bc:      	cset	w1, eq
    f7c0:      	cmp	x0, #0x26
    f7c4:      	b.ne	0xf7e8 <_stogir.numeric-conversion.valid-types?+0x84>
    f7c8:      	uxtb	w16, w5
    f7cc:      	cmp	w16, wzr
    f7d0:      	b.ne	0xf838 <_stogir.numeric-conversion.valid-types?+0xd4>
    f7d4:      	uxtb	w16, w1
    f7d8:      	cmp	w16, wzr
    f7dc:      	b.ne	0xf838 <_stogir.numeric-conversion.valid-types?+0xd4>
    f7e0:      	movz	x0, #0x0, lsl #48
    f7e4:      	b	0xf814 <_stogir.numeric-conversion.valid-types?+0xb0>
    f7e8:      	cmp	x0, #0x27
    f7ec:      	b.ne	0xf820 <_stogir.numeric-conversion.valid-types?+0xbc>
    f7f0:      	uxtb	w16, w5
    f7f4:      	cmp	w16, wzr
    f7f8:      	b.ne	0xf850 <_stogir.numeric-conversion.valid-types?+0xec>
    f7fc:      	uxtb	w16, w1
    f800:      	cmp	w16, wzr
    f804:      	b.ne	0xf850 <_stogir.numeric-conversion.valid-types?+0xec>
    f808:      	movz	x0, #0x0, lsl #48
    f80c:      	b	0xf834 <_stogir.numeric-conversion.valid-types?+0xd0>
    f810:      	movz	x0, #0x0, lsl #48
    f814:      	b	0xf824 <_stogir.numeric-conversion.valid-types?+0xc0>
    f818:      	movz	x0, #0x0, lsl #48
    f81c:      	b	0xf824 <_stogir.numeric-conversion.valid-types?+0xc0>
    f820:      	movz	x0, #0x0, lsl #48
    f824:      	ret
    f828:      	mov	x0, x4
    f82c:      	b	0xf81c <_stogir.numeric-conversion.valid-types?+0xb8>
    f830:      	mov	x0, x4
    f834:      	b	0xf824 <_stogir.numeric-conversion.valid-types?+0xc0>
    f838:      	cmp	x2, #0x1
    f83c:      	b.lt	0xf810 <_stogir.numeric-conversion.valid-types?+0xac>
    f840:      	cmp	x2, #0xb
    f844:      	cset	w0, le
    f848:      	ubfx	x0, x0, #0, #8
    f84c:      	b	0xf814 <_stogir.numeric-conversion.valid-types?+0xb0>
    f850:      	uxtb	w16, w3
    f854:      	cmp	w16, wzr
    f858:      	b.eq	0xf830 <_stogir.numeric-conversion.valid-types?+0xcc>
    f85c:      	mov	x0, #0x1                ; =1
    f860:      	b	0xf834 <_stogir.numeric-conversion.valid-types?+0xd0>

000000000000f864 <_inherent$slice$new__stogir.node.Node>:
    f864:      	sub	sp, sp, #0x10
    f868:      	mov	x2, sp
    f86c:      	str	x0, [x2]
    f870:      	str	x1, [x2, #0x8]
    f874:      	ldr	x0, [sp]
    f878:      	ldr	x1, [sp, #0x8]
    f87c:      	add	sp, sp, #0x10
    f880:      	ret

000000000000f884 <_inherent$slice$data__stogir.node.Node>:
    f884:      	ret

000000000000f888 <_coil.slice.element-ref__stogir.node.Node>:
    f888:      	ret

000000000000f88c <_stogir.vector-lanes.ordinary?>:
    f88c:      	ldr	w0, [x0]
    f890:      	uxtb	w0, w0
    f894:      	cmp	x0, #0x48
    f898:      	b.ne	0xf8a4 <_stogir.vector-lanes.ordinary?+0x18>
    f89c:      	movz	x0, #0x0, lsl #48
    f8a0:      	b	0xf8b8 <_stogir.vector-lanes.ordinary?+0x2c>
    f8a4:      	cmp	x0, #0x46
    f8a8:      	cset	w0, eq
    f8ac:      	uxtb	w16, w0
    f8b0:      	cmp	w16, wzr
    f8b4:      	cset	x0, eq
    f8b8:      	ret

000000000000f8bc <_stogir.vector-lanes.compatible?>:
    f8bc:      	sxtw	x0, w0
    f8c0:      	and	x3, x0, #0xf
    f8c4:      	cmp	x0, #0xf
    f8c8:      	cset	w4, gt
    f8cc:      	cmp	x0, #0x80
    f8d0:      	cset	w5, lt
    f8d4:      	lsr	w3, w3, #0
    f8d8:      	sxtw	x3, w3
    f8dc:      	cmp	x3, #0x1
    f8e0:      	cset	w6, ge
    f8e4:      	cmp	x3, #0xd
    f8e8:      	cset	w7, le
    f8ec:      	cmp	x0, #0x0
    f8f0:      	b.lt	0xf904 <_stogir.vector-lanes.compatible?+0x48>
    f8f4:      	cmp	x0, #0xd
    f8f8:      	b.gt	0xf904 <_stogir.vector-lanes.compatible?+0x48>
    f8fc:      	mov	x0, x3
    f900:      	b	0xf938 <_stogir.vector-lanes.compatible?+0x7c>
    f904:      	uxtb	w16, w4
    f908:      	cmp	w16, wzr
    f90c:      	b.eq	0xf934 <_stogir.vector-lanes.compatible?+0x78>
    f910:      	uxtb	w16, w5
    f914:      	cmp	w16, wzr
    f918:      	b.eq	0xf934 <_stogir.vector-lanes.compatible?+0x78>
    f91c:      	uxtb	w16, w6
    f920:      	cmp	w16, wzr
    f924:      	b.eq	0xf934 <_stogir.vector-lanes.compatible?+0x78>
    f928:      	uxtb	w16, w7
    f92c:      	cmp	w16, wzr
    f930:      	b.ne	0xf8fc <_stogir.vector-lanes.compatible?+0x40>
    f934:      	movn	x0, #0x0, lsl #48
    f938:      	uxtb	w16, w4
    f93c:      	cmp	w16, wzr
    f940:      	b.eq	0xf99c <_stogir.vector-lanes.compatible?+0xe0>
    f944:      	uxtb	w16, w5
    f948:      	cmp	w16, wzr
    f94c:      	b.eq	0xf99c <_stogir.vector-lanes.compatible?+0xe0>
    f950:      	uxtb	w16, w6
    f954:      	cmp	w16, wzr
    f958:      	b.eq	0xf99c <_stogir.vector-lanes.compatible?+0xe0>
    f95c:      	uxtb	w16, w7
    f960:      	cmp	w16, wzr
    f964:      	b.eq	0xf99c <_stogir.vector-lanes.compatible?+0xe0>
    f968:      	sxtw	x2, w2
    f96c:      	cmp	x2, #0x4
    f970:      	cset	w3, eq
    f974:      	cmp	x2, #0x8
    f978:      	cset	w4, eq
    f97c:      	uxtb	w16, w3
    f980:      	cmp	w16, wzr
    f984:      	b.ne	0xf9ac <_stogir.vector-lanes.compatible?+0xf0>
    f988:      	uxtb	w16, w4
    f98c:      	cmp	w16, wzr
    f990:      	b.ne	0xf9ac <_stogir.vector-lanes.compatible?+0xf0>
    f994:      	movz	x0, #0x0, lsl #48
    f998:      	b	0xf9a8 <_stogir.vector-lanes.compatible?+0xec>
    f99c:      	movz	x0, #0x0, lsl #48
    f9a0:      	ret
    f9a4:      	movz	x0, #0x0, lsl #48
    f9a8:      	b	0xf9a0 <_stogir.vector-lanes.compatible?+0xe4>
    f9ac:      	sxtw	x1, w1
    f9b0:      	cmp	x1, #0x0
    f9b4:      	b.lt	0xf9a4 <_stogir.vector-lanes.compatible?+0xe8>
    f9b8:      	cmp	x1, #0xd
    f9bc:      	b.gt	0xf9a4 <_stogir.vector-lanes.compatible?+0xe8>
    f9c0:      	cmp	x1, #0x0
    f9c4:      	b.le	0xf9e0 <_stogir.vector-lanes.compatible?+0x124>
    f9c8:      	lsr	w0, w0, #0
    f9cc:      	sxtw	x0, w0
    f9d0:      	cmp	x0, x1
    f9d4:      	b.ne	0xf9e8 <_stogir.vector-lanes.compatible?+0x12c>
    f9d8:      	mov	x0, #0x1                ; =1
    f9dc:      	b	0xf9e4 <_stogir.vector-lanes.compatible?+0x128>
    f9e0:      	movz	x0, #0x0, lsl #48
    f9e4:      	b	0xf9a8 <_stogir.vector-lanes.compatible?+0xec>
    f9e8:      	cmp	x0, #0x1
    f9ec:      	b.lt	0xfa28 <_stogir.vector-lanes.compatible?+0x16c>
    f9f0:      	cmp	x0, #0xb
    f9f4:      	b.gt	0xfa28 <_stogir.vector-lanes.compatible?+0x16c>
    f9f8:      	cmp	x1, #0x1
    f9fc:      	b.lt	0xfa30 <_stogir.vector-lanes.compatible?+0x174>
    fa00:      	cmp	x1, #0xb
    fa04:      	b.gt	0xfa30 <_stogir.vector-lanes.compatible?+0x174>
    fa08:      	uxtb	w16, w3
    fa0c:      	cmp	w16, wzr
    fa10:      	b.ne	0xfa5c <_stogir.vector-lanes.compatible?+0x1a0>
    fa14:      	uxtb	w16, w4
    fa18:      	cmp	w16, wzr
    fa1c:      	b.ne	0xfa5c <_stogir.vector-lanes.compatible?+0x1a0>
    fa20:      	movn	x0, #0x0, lsl #48
    fa24:      	b	0xfa70 <_stogir.vector-lanes.compatible?+0x1b4>
    fa28:      	movz	x0, #0x0, lsl #48
    fa2c:      	b	0xf9dc <_stogir.vector-lanes.compatible?+0x120>
    fa30:      	movz	x0, #0x0, lsl #48
    fa34:      	b	0xfa2c <_stogir.vector-lanes.compatible?+0x170>
    fa38:      	mov	x1, #0x1                ; =1
    fa3c:      	lsr	w0, w0, #0
    fa40:      	sxtw	x0, w0
    fa44:      	lsr	w1, w1, #0
    fa48:      	sxtw	x1, w1
    fa4c:      	cmp	x0, x1
    fa50:      	cset	w0, eq
    fa54:      	ubfx	x0, x0, #0, #8
    fa58:      	b	0xfa34 <_stogir.vector-lanes.compatible?+0x178>
    fa5c:      	cmp	x0, #0x0
    fa60:      	b.ne	0xfb10 <_stogir.vector-lanes.compatible?+0x254>
    fa64:      	movz	x0, #0x0, lsl #48
    fa68:      	b	0xfa70 <_stogir.vector-lanes.compatible?+0x1b4>
    fa6c:      	mov	x0, #0x1                ; =1
    fa70:      	uxtb	w16, w3
    fa74:      	cmp	w16, wzr
    fa78:      	b.ne	0xfa90 <_stogir.vector-lanes.compatible?+0x1d4>
    fa7c:      	uxtb	w16, w4
    fa80:      	cmp	w16, wzr
    fa84:      	b.ne	0xfa90 <_stogir.vector-lanes.compatible?+0x1d4>
    fa88:      	movn	x1, #0x0, lsl #48
    fa8c:      	b	0xfa3c <_stogir.vector-lanes.compatible?+0x180>
    fa90:      	cmp	x1, #0x0
    fa94:      	b.ne	0xfaa0 <_stogir.vector-lanes.compatible?+0x1e4>
    fa98:      	movz	x1, #0x0, lsl #48
    fa9c:      	b	0xfa3c <_stogir.vector-lanes.compatible?+0x180>
    faa0:      	cmp	x1, #0x1
    faa4:      	b.eq	0xfa38 <_stogir.vector-lanes.compatible?+0x17c>
    faa8:      	cmp	x1, #0x2
    faac:      	b.eq	0xfa38 <_stogir.vector-lanes.compatible?+0x17c>
    fab0:      	cmp	x1, #0x7
    fab4:      	b.eq	0xfa38 <_stogir.vector-lanes.compatible?+0x17c>
    fab8:      	cmp	x1, #0x8
    fabc:      	b.eq	0xfa38 <_stogir.vector-lanes.compatible?+0x17c>
    fac0:      	cmp	x1, #0x3
    fac4:      	b.eq	0xfb80 <_stogir.vector-lanes.compatible?+0x2c4>
    fac8:      	cmp	x1, #0x9
    facc:      	b.eq	0xfb80 <_stogir.vector-lanes.compatible?+0x2c4>
    fad0:      	cmp	x1, #0x4
    fad4:      	b.eq	0xfb90 <_stogir.vector-lanes.compatible?+0x2d4>
    fad8:      	cmp	x1, #0xa
    fadc:      	b.eq	0xfb90 <_stogir.vector-lanes.compatible?+0x2d4>
    fae0:      	cmp	x1, #0xd
    fae4:      	b.eq	0xfb90 <_stogir.vector-lanes.compatible?+0x2d4>
    fae8:      	cmp	x1, #0x5
    faec:      	b.eq	0xfba0 <_stogir.vector-lanes.compatible?+0x2e4>
    faf0:      	cmp	x1, #0xb
    faf4:      	b.eq	0xfba0 <_stogir.vector-lanes.compatible?+0x2e4>
    faf8:      	cmp	x1, #0xc
    fafc:      	b.eq	0xfba0 <_stogir.vector-lanes.compatible?+0x2e4>
    fb00:      	cmp	x1, #0x6
    fb04:      	b.ne	0xfbb0 <_stogir.vector-lanes.compatible?+0x2f4>
    fb08:      	mov	x1, x2
    fb0c:      	b	0xfbb4 <_stogir.vector-lanes.compatible?+0x2f8>
    fb10:      	cmp	x0, #0x1
    fb14:      	b.eq	0xfa6c <_stogir.vector-lanes.compatible?+0x1b0>
    fb18:      	cmp	x0, #0x2
    fb1c:      	b.eq	0xfa6c <_stogir.vector-lanes.compatible?+0x1b0>
    fb20:      	cmp	x0, #0x7
    fb24:      	b.eq	0xfa6c <_stogir.vector-lanes.compatible?+0x1b0>
    fb28:      	cmp	x0, #0x8
    fb2c:      	b.eq	0xfa6c <_stogir.vector-lanes.compatible?+0x1b0>
    fb30:      	cmp	x0, #0x3
    fb34:      	b.eq	0xfb88 <_stogir.vector-lanes.compatible?+0x2cc>
    fb38:      	cmp	x0, #0x9
    fb3c:      	b.eq	0xfb88 <_stogir.vector-lanes.compatible?+0x2cc>
    fb40:      	cmp	x0, #0x4
    fb44:      	b.eq	0xfb98 <_stogir.vector-lanes.compatible?+0x2dc>
    fb48:      	cmp	x0, #0xa
    fb4c:      	b.eq	0xfb98 <_stogir.vector-lanes.compatible?+0x2dc>
    fb50:      	cmp	x0, #0xd
    fb54:      	b.eq	0xfb98 <_stogir.vector-lanes.compatible?+0x2dc>
    fb58:      	cmp	x0, #0x5
    fb5c:      	b.eq	0xfba8 <_stogir.vector-lanes.compatible?+0x2ec>
    fb60:      	cmp	x0, #0xb
    fb64:      	b.eq	0xfba8 <_stogir.vector-lanes.compatible?+0x2ec>
    fb68:      	cmp	x0, #0xc
    fb6c:      	b.eq	0xfba8 <_stogir.vector-lanes.compatible?+0x2ec>
    fb70:      	cmp	x0, #0x6
    fb74:      	b.ne	0xfbb8 <_stogir.vector-lanes.compatible?+0x2fc>
    fb78:      	mov	x0, x2
    fb7c:      	b	0xfbbc <_stogir.vector-lanes.compatible?+0x300>
    fb80:      	mov	x1, #0x2                ; =2
    fb84:      	b	0xfa3c <_stogir.vector-lanes.compatible?+0x180>
    fb88:      	mov	x0, #0x2                ; =2
    fb8c:      	b	0xfa70 <_stogir.vector-lanes.compatible?+0x1b4>
    fb90:      	mov	x1, #0x4                ; =4
    fb94:      	b	0xfb84 <_stogir.vector-lanes.compatible?+0x2c8>
    fb98:      	mov	x0, #0x4                ; =4
    fb9c:      	b	0xfb8c <_stogir.vector-lanes.compatible?+0x2d0>
    fba0:      	mov	x1, #0x8                ; =8
    fba4:      	b	0xfb94 <_stogir.vector-lanes.compatible?+0x2d8>
    fba8:      	mov	x0, #0x8                ; =8
    fbac:      	b	0xfb9c <_stogir.vector-lanes.compatible?+0x2e0>
    fbb0:      	movn	x1, #0x0, lsl #48
    fbb4:      	b	0xfba4 <_stogir.vector-lanes.compatible?+0x2e8>
    fbb8:      	movn	x0, #0x0, lsl #48
    fbbc:      	b	0xfbac <_stogir.vector-lanes.compatible?+0x2f0>

000000000000fbc0 <_stogir.symbols.numeric?>:
    fbc0:      	ldr	w0, [x0]
    fbc4:      	uxtb	w1, w0
    fbc8:      	ubfx	x0, x0, #8, #8
    fbcc:      	cmp	x1, x0
    fbd0:      	b.ne	0xfbdc <_stogir.symbols.numeric?+0x1c>
    fbd4:      	mov	x0, #0x1                ; =1
    fbd8:      	b	0xfbe8 <_stogir.symbols.numeric?+0x28>
    fbdc:      	cmp	x1, #0x49
    fbe0:      	cset	w0, eq
    fbe4:      	ubfx	x0, x0, #0, #8
    fbe8:      	ret

000000000000fbec <_stogir.node.constant-bits>:
    fbec:      	ldr	w1, [x0, #0x8]
    fbf0:      	ubfx	x1, x1, #0, #32
    fbf4:      	ldr	w0, [x0, #0xc]
    fbf8:      	ubfx	x0, x0, #0, #32
    fbfc:      	lsl	x0, x0, #32
    fc00:      	orr	x0, x0, x1
    fc04:      	ret

000000000000fc08 <_stogir.vector-comparison.valid-type?>:
    fc08:      	sxtw	x0, w0
    fc0c:      	cmp	x0, #0xe
    fc10:      	b.lt	0xfcac <_stogir.vector-comparison.valid-type?+0xa4>
    fc14:      	cmp	x0, #0x19
    fc18:      	b.gt	0xfcac <_stogir.vector-comparison.valid-type?+0xa4>
    fc1c:      	sxtw	x1, w1
    fc20:      	cmp	x1, #0xf
    fc24:      	cset	w2, gt
    fc28:      	uxtb	w16, w2
    fc2c:      	cmp	w16, wzr
    fc30:      	b.eq	0xfcb4 <_stogir.vector-comparison.valid-type?+0xac>
    fc34:      	cmp	x1, #0x80
    fc38:      	cset	w3, lt
    fc3c:      	uxtb	w16, w3
    fc40:      	cmp	w16, wzr
    fc44:      	b.eq	0xfcb4 <_stogir.vector-comparison.valid-type?+0xac>
    fc48:      	and	x4, x1, #0xf
    fc4c:      	lsr	w4, w4, #0
    fc50:      	sxtw	x4, w4
    fc54:      	cmp	x4, #0x1
    fc58:      	cset	w5, ge
    fc5c:      	uxtb	w16, w5
    fc60:      	cmp	w16, wzr
    fc64:      	b.eq	0xfcb4 <_stogir.vector-comparison.valid-type?+0xac>
    fc68:      	cmp	x4, #0xd
    fc6c:      	cset	w6, le
    fc70:      	uxtb	w16, w6
    fc74:      	cmp	w16, wzr
    fc78:      	b.eq	0xfcb4 <_stogir.vector-comparison.valid-type?+0xac>
    fc7c:      	cmp	x1, #0x0
    fc80:      	cset	w7, ge
    fc84:      	cmp	x1, #0xd
    fc88:      	cset	w1, le
    fc8c:      	uxtb	w16, w7
    fc90:      	cmp	w16, wzr
    fc94:      	b.eq	0xfcc4 <_stogir.vector-comparison.valid-type?+0xbc>
    fc98:      	uxtb	w16, w1
    fc9c:      	cmp	w16, wzr
    fca0:      	b.eq	0xfcc4 <_stogir.vector-comparison.valid-type?+0xbc>
    fca4:      	mov	x8, x4
    fca8:      	b	0xfcf8 <_stogir.vector-comparison.valid-type?+0xf0>
    fcac:      	movz	x0, #0x0, lsl #48
    fcb0:      	ret
    fcb4:      	movz	x0, #0x0, lsl #48
    fcb8:      	b	0xfcb0 <_stogir.vector-comparison.valid-type?+0xa8>
    fcbc:      	mov	x0, #0x1                ; =1
    fcc0:      	b	0xfcb8 <_stogir.vector-comparison.valid-type?+0xb0>
    fcc4:      	uxtb	w16, w2
    fcc8:      	cmp	w16, wzr
    fccc:      	b.eq	0xfcf4 <_stogir.vector-comparison.valid-type?+0xec>
    fcd0:      	uxtb	w16, w3
    fcd4:      	cmp	w16, wzr
    fcd8:      	b.eq	0xfcf4 <_stogir.vector-comparison.valid-type?+0xec>
    fcdc:      	uxtb	w16, w5
    fce0:      	cmp	w16, wzr
    fce4:      	b.eq	0xfcf4 <_stogir.vector-comparison.valid-type?+0xec>
    fce8:      	uxtb	w16, w6
    fcec:      	cmp	w16, wzr
    fcf0:      	b.ne	0xfca4 <_stogir.vector-comparison.valid-type?+0x9c>
    fcf4:      	movn	x8, #0x0, lsl #48
    fcf8:      	lsr	w8, w8, #0
    fcfc:      	sxtw	x8, w8
    fd00:      	cmp	x8, #0xc
    fd04:      	b.eq	0xfcbc <_stogir.vector-comparison.valid-type?+0xb4>
    fd08:      	cmp	x8, #0xd
    fd0c:      	b.eq	0xfcbc <_stogir.vector-comparison.valid-type?+0xb4>
    fd10:      	uxtb	w16, w7
    fd14:      	cmp	w16, wzr
    fd18:      	b.eq	0xfd38 <_stogir.vector-comparison.valid-type?+0x130>
    fd1c:      	uxtb	w16, w1
    fd20:      	cmp	w16, wzr
    fd24:      	b.eq	0xfd38 <_stogir.vector-comparison.valid-type?+0x130>
    fd28:      	mov	x1, x4
    fd2c:      	b	0xfd6c <_stogir.vector-comparison.valid-type?+0x164>
    fd30:      	movz	x0, #0x0, lsl #48
    fd34:      	b	0xfcc0 <_stogir.vector-comparison.valid-type?+0xb8>
    fd38:      	uxtb	w16, w2
    fd3c:      	cmp	w16, wzr
    fd40:      	b.eq	0xfd68 <_stogir.vector-comparison.valid-type?+0x160>
    fd44:      	uxtb	w16, w3
    fd48:      	cmp	w16, wzr
    fd4c:      	b.eq	0xfd68 <_stogir.vector-comparison.valid-type?+0x160>
    fd50:      	uxtb	w16, w5
    fd54:      	cmp	w16, wzr
    fd58:      	b.eq	0xfd68 <_stogir.vector-comparison.valid-type?+0x160>
    fd5c:      	uxtb	w16, w6
    fd60:      	cmp	w16, wzr
    fd64:      	b.ne	0xfd28 <_stogir.vector-comparison.valid-type?+0x120>
    fd68:      	movn	x1, #0x0, lsl #48
    fd6c:      	lsr	w1, w1, #0
    fd70:      	sxtw	x1, w1
    fd74:      	cmp	x1, #0x1
    fd78:      	b.lt	0xfd30 <_stogir.vector-comparison.valid-type?+0x128>
    fd7c:      	cmp	x1, #0xb
    fd80:      	b.gt	0xfd30 <_stogir.vector-comparison.valid-type?+0x128>
    fd84:      	cmp	x0, #0x17
    fd88:      	cset	w0, le
    fd8c:      	ubfx	x0, x0, #0, #8
    fd90:      	b	0xfd34 <_stogir.vector-comparison.valid-type?+0x12c>

000000000000fd94 <_stogir.vector-arithmetic.extrema?>:
    fd94:      	sxtw	x0, w0
    fd98:      	cmp	x0, #0x3a
    fd9c:      	b.ne	0xfda8 <_stogir.vector-arithmetic.extrema?+0x14>
    fda0:      	mov	x0, #0x1                ; =1
    fda4:      	b	0xfdb4 <_stogir.vector-arithmetic.extrema?+0x20>
    fda8:      	cmp	x0, #0x3b
    fdac:      	cset	w0, eq
    fdb0:      	ubfx	x0, x0, #0, #8
    fdb4:      	ret

000000000000fdb8 <_stogir.vector-arithmetic.shift?>:
    fdb8:      	sxtw	x0, w0
    fdbc:      	cmp	x0, #0x31
    fdc0:      	b.lt	0xfdd4 <_stogir.vector-arithmetic.shift?+0x1c>
    fdc4:      	cmp	x0, #0x35
    fdc8:      	cset	w0, le
    fdcc:      	ubfx	x0, x0, #0, #8
    fdd0:      	b	0xfdd8 <_stogir.vector-arithmetic.shift?+0x20>
    fdd4:      	movz	x0, #0x0, lsl #48
    fdd8:      	ret

000000000000fddc <_stogir.vector-arithmetic.valid-type?>:
    fddc:      	sub	sp, sp, #0x30
    fde0:      	str	x29, [sp]
    fde4:      	str	x30, [sp, #0x8]
    fde8:      	mov	x29, sp
    fdec:      	str	x19, [sp, #0x10]
    fdf0:      	str	x20, [sp, #0x18]
    fdf4:      	str	x21, [sp, #0x20]
    fdf8:      	str	x22, [sp, #0x28]
    fdfc:      	sxtw	x1, w1
    fe00:      	cmp	x1, #0xf
    fe04:      	cset	w2, gt
    fe08:      	cmp	x1, #0x80
    fe0c:      	cset	w3, lt
    fe10:      	and	x4, x1, #0xf
    fe14:      	lsr	w4, w4, #0
    fe18:      	sxtw	x4, w4
    fe1c:      	cmp	x4, #0x1
    fe20:      	cset	w5, ge
    fe24:      	cmp	x4, #0xd
    fe28:      	cset	w6, le
    fe2c:      	cmp	x1, #0x0
    fe30:      	b.lt	0xfe44 <_stogir.vector-arithmetic.valid-type?+0x68>
    fe34:      	cmp	x1, #0xd
    fe38:      	b.gt	0xfe44 <_stogir.vector-arithmetic.valid-type?+0x68>
    fe3c:      	mov	x1, x4
    fe40:      	b	0xfe78 <_stogir.vector-arithmetic.valid-type?+0x9c>
    fe44:      	uxtb	w16, w2
    fe48:      	cmp	w16, wzr
    fe4c:      	b.eq	0xfe74 <_stogir.vector-arithmetic.valid-type?+0x98>
    fe50:      	uxtb	w16, w3
    fe54:      	cmp	w16, wzr
    fe58:      	b.eq	0xfe74 <_stogir.vector-arithmetic.valid-type?+0x98>
    fe5c:      	uxtb	w16, w5
    fe60:      	cmp	w16, wzr
    fe64:      	b.eq	0xfe74 <_stogir.vector-arithmetic.valid-type?+0x98>
    fe68:      	uxtb	w16, w6
    fe6c:      	cmp	w16, wzr
    fe70:      	b.ne	0xfe3c <_stogir.vector-arithmetic.valid-type?+0x60>
    fe74:      	movn	x1, #0x0, lsl #48
    fe78:      	uxtb	w16, w2
    fe7c:      	cmp	w16, wzr
    fe80:      	b.eq	0x1006c <_stogir.vector-arithmetic.valid-type?+0x290>
    fe84:      	uxtb	w16, w3
    fe88:      	cmp	w16, wzr
    fe8c:      	b.eq	0x1006c <_stogir.vector-arithmetic.valid-type?+0x290>
    fe90:      	uxtb	w16, w5
    fe94:      	cmp	w16, wzr
    fe98:      	b.eq	0x1006c <_stogir.vector-arithmetic.valid-type?+0x290>
    fe9c:      	uxtb	w16, w6
    fea0:      	cmp	w16, wzr
    fea4:      	b.eq	0x1006c <_stogir.vector-arithmetic.valid-type?+0x290>
    fea8:      	sxtw	x2, w0
    feac:      	cmp	x2, #0x1f
    feb0:      	cset	w19, eq
    feb4:      	cmp	x2, #0x20
    feb8:      	cset	w20, eq
    febc:      	cmp	x2, #0x2e
    fec0:      	cset	w3, eq
    fec4:      	cmp	x2, #0x2f
    fec8:      	cset	w4, eq
    fecc:      	cmp	x2, #0x30
    fed0:      	cset	w5, eq
    fed4:      	cmp	x2, #0x1e
    fed8:      	cset	w6, eq
    fedc:      	cmp	x2, #0x31
    fee0:      	cset	w7, ge
    fee4:      	cmp	x2, #0x35
    fee8:      	cset	w8, le
    feec:      	cmp	x2, #0x3a
    fef0:      	cset	w9, eq
    fef4:      	cmp	x2, #0x3b
    fef8:      	cset	w10, eq
    fefc:      	cmp	x2, #0x2d
    ff00:      	cset	w11, eq
    ff04:      	cmp	x2, #0x36
    ff08:      	cset	w12, eq
    ff0c:      	cmp	x2, #0x37
    ff10:      	cset	w13, eq
    ff14:      	cmp	x2, #0x38
    ff18:      	cset	w14, eq
    ff1c:      	cmp	x2, #0x39
    ff20:      	cset	w15, eq
    ff24:      	uxtb	w16, w19
    ff28:      	cmp	w16, wzr
    ff2c:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff30:      	uxtb	w16, w20
    ff34:      	cmp	w16, wzr
    ff38:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff3c:      	uxtb	w16, w11
    ff40:      	cmp	w16, wzr
    ff44:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff48:      	uxtb	w16, w12
    ff4c:      	cmp	w16, wzr
    ff50:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff54:      	uxtb	w16, w13
    ff58:      	cmp	w16, wzr
    ff5c:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff60:      	uxtb	w16, w14
    ff64:      	cmp	w16, wzr
    ff68:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff6c:      	uxtb	w16, w15
    ff70:      	cmp	w16, wzr
    ff74:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff78:      	uxtb	w16, w9
    ff7c:      	cmp	w16, wzr
    ff80:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff84:      	uxtb	w16, w10
    ff88:      	cmp	w16, wzr
    ff8c:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
    ff90:      	uxtb	w16, w7
    ff94:      	cmp	w16, wzr
    ff98:      	b.eq	0x10188 <_stogir.vector-arithmetic.valid-type?+0x3ac>
    ff9c:      	uxtb	w16, w8
    ffa0:      	cmp	w16, wzr
    ffa4:      	b.eq	0x10188 <_stogir.vector-arithmetic.valid-type?+0x3ac>
    ffa8:      	lsr	w1, w1, #0
    ffac:      	sxtw	x2, w1
    ffb0:      	cmp	x2, #0xc
    ffb4:      	cset	w21, eq
    ffb8:      	cmp	x2, #0xd
    ffbc:      	cset	w22, eq
    ffc0:      	uxtb	w16, w19
    ffc4:      	cmp	w16, wzr
    ffc8:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
    ffcc:      	uxtb	w16, w20
    ffd0:      	cmp	w16, wzr
    ffd4:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
    ffd8:      	uxtb	w16, w11
    ffdc:      	cmp	w16, wzr
    ffe0:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
    ffe4:      	uxtb	w16, w12
    ffe8:      	cmp	w16, wzr
    ffec:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
    fff0:      	uxtb	w16, w13
    fff4:      	cmp	w16, wzr
    fff8:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
    fffc:      	uxtb	w16, w14
   10000:      	cmp	w16, wzr
   10004:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
   10008:      	uxtb	w16, w15
   1000c:      	cmp	w16, wzr
   10010:      	b.ne	0x1009c <_stogir.vector-arithmetic.valid-type?+0x2c0>
   10014:      	cmp	x2, #0x1
   10018:      	cset	w0, eq
   1001c:      	cmp	x2, #0x1
   10020:      	cset	w1, ge
   10024:      	cmp	x2, #0xb
   10028:      	cset	w2, le
   1002c:      	uxtb	w16, w7
   10030:      	cmp	w16, wzr
   10034:      	b.eq	0x100f4 <_stogir.vector-arithmetic.valid-type?+0x318>
   10038:      	uxtb	w16, w8
   1003c:      	cmp	w16, wzr
   10040:      	b.eq	0x100f4 <_stogir.vector-arithmetic.valid-type?+0x318>
   10044:      	uxtb	w16, w1
   10048:      	cmp	w16, wzr
   1004c:      	b.eq	0x10180 <_stogir.vector-arithmetic.valid-type?+0x3a4>
   10050:      	uxtb	w16, w2
   10054:      	cmp	w16, wzr
   10058:      	b.eq	0x10180 <_stogir.vector-arithmetic.valid-type?+0x3a4>
   1005c:      	uxtb	w16, w0
   10060:      	cmp	w16, wzr
   10064:      	cset	x0, eq
   10068:      	b	0x10184 <_stogir.vector-arithmetic.valid-type?+0x3a8>
   1006c:      	movz	x0, #0x0, lsl #48
   10070:      	ldr	x19, [sp, #0x10]
   10074:      	ldr	x20, [sp, #0x18]
   10078:      	ldr	x21, [sp, #0x20]
   1007c:      	ldr	x22, [sp, #0x28]
   10080:      	ldr	x29, [sp]
   10084:      	ldr	x30, [sp, #0x8]
   10088:      	add	sp, sp, #0x30
   1008c:      	ret
   10090:      	ubfx	x20, x20, #0, #8
   10094:      	mov	x0, x20
   10098:      	b	0x10070 <_stogir.vector-arithmetic.valid-type?+0x294>
   1009c:      	lsr	w0, w0, #0
   100a0:      	lsr	w1, w1, #0
   100a4:      	bl	0x100a4 <_stogir.vector-arithmetic.valid-type?+0x2c8>
		00000000000100a4:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   100a8:      	cmp	x0, #0x0
   100ac:      	b.eq	0x100b8 <_stogir.vector-arithmetic.valid-type?+0x2dc>
   100b0:      	mov	x0, #0x1                ; =1
   100b4:      	b	0x10098 <_stogir.vector-arithmetic.valid-type?+0x2bc>
   100b8:      	uxtb	w16, w21
   100bc:      	cmp	w16, wzr
   100c0:      	b.ne	0x100d8 <_stogir.vector-arithmetic.valid-type?+0x2fc>
   100c4:      	uxtb	w16, w22
   100c8:      	cmp	w16, wzr
   100cc:      	b.ne	0x100d8 <_stogir.vector-arithmetic.valid-type?+0x2fc>
   100d0:      	movz	x0, #0x0, lsl #48
   100d4:      	b	0x10098 <_stogir.vector-arithmetic.valid-type?+0x2bc>
   100d8:      	uxtb	w16, w19
   100dc:      	cmp	w16, wzr
   100e0:      	b.eq	0x10090 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   100e4:      	mov	x0, #0x1                ; =1
   100e8:      	b	0x10098 <_stogir.vector-arithmetic.valid-type?+0x2bc>
   100ec:      	movz	x0, #0x0, lsl #48
   100f0:      	b	0x10098 <_stogir.vector-arithmetic.valid-type?+0x2bc>
   100f4:      	uxtb	w16, w3
   100f8:      	cmp	w16, wzr
   100fc:      	b.ne	0x10168 <_stogir.vector-arithmetic.valid-type?+0x38c>
   10100:      	uxtb	w16, w4
   10104:      	cmp	w16, wzr
   10108:      	b.ne	0x10168 <_stogir.vector-arithmetic.valid-type?+0x38c>
   1010c:      	uxtb	w16, w5
   10110:      	cmp	w16, wzr
   10114:      	b.ne	0x10168 <_stogir.vector-arithmetic.valid-type?+0x38c>
   10118:      	uxtb	w16, w21
   1011c:      	cmp	w16, wzr
   10120:      	b.ne	0x101e0 <_stogir.vector-arithmetic.valid-type?+0x404>
   10124:      	uxtb	w16, w22
   10128:      	cmp	w16, wzr
   1012c:      	b.ne	0x101e0 <_stogir.vector-arithmetic.valid-type?+0x404>
   10130:      	uxtb	w16, w1
   10134:      	cmp	w16, wzr
   10138:      	b.eq	0x101f0 <_stogir.vector-arithmetic.valid-type?+0x414>
   1013c:      	uxtb	w16, w2
   10140:      	cmp	w16, wzr
   10144:      	b.eq	0x101f0 <_stogir.vector-arithmetic.valid-type?+0x414>
   10148:      	uxtb	w16, w0
   1014c:      	cmp	w16, wzr
   10150:      	b.eq	0x101f8 <_stogir.vector-arithmetic.valid-type?+0x41c>
   10154:      	uxtb	w16, w9
   10158:      	cmp	w16, wzr
   1015c:      	b.eq	0x10200 <_stogir.vector-arithmetic.valid-type?+0x424>
   10160:      	mov	x0, #0x1                ; =1
   10164:      	b	0x10208 <_stogir.vector-arithmetic.valid-type?+0x42c>
   10168:      	uxtb	w16, w1
   1016c:      	cmp	w16, wzr
   10170:      	b.eq	0x100ec <_stogir.vector-arithmetic.valid-type?+0x310>
   10174:      	ubfx	x2, x2, #0, #8
   10178:      	mov	x0, x2
   1017c:      	b	0x100f0 <_stogir.vector-arithmetic.valid-type?+0x314>
   10180:      	movz	x0, #0x0, lsl #48
   10184:      	b	0x100f0 <_stogir.vector-arithmetic.valid-type?+0x314>
   10188:      	cmp	x2, #0x1a
   1018c:      	b.eq	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10190:      	cmp	x2, #0x1b
   10194:      	b.eq	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   10198:      	cmp	x2, #0x1c
   1019c:      	b.eq	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101a0:      	cmp	x2, #0x1d
   101a4:      	b.eq	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101a8:      	uxtb	w16, w6
   101ac:      	cmp	w16, wzr
   101b0:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101b4:      	uxtb	w16, w3
   101b8:      	cmp	w16, wzr
   101bc:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101c0:      	uxtb	w16, w4
   101c4:      	cmp	w16, wzr
   101c8:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101cc:      	uxtb	w16, w5
   101d0:      	cmp	w16, wzr
   101d4:      	b.ne	0xffa8 <_stogir.vector-arithmetic.valid-type?+0x1cc>
   101d8:      	movz	x0, #0x0, lsl #48
   101dc:      	b	0x10098 <_stogir.vector-arithmetic.valid-type?+0x2bc>
   101e0:      	uxtb	w16, w6
   101e4:      	cmp	w16, wzr
   101e8:      	cset	x0, eq
   101ec:      	b	0x100f0 <_stogir.vector-arithmetic.valid-type?+0x314>
   101f0:      	movz	x0, #0x0, lsl #48
   101f4:      	b	0x101ec <_stogir.vector-arithmetic.valid-type?+0x410>
   101f8:      	mov	x0, #0x1                ; =1
   101fc:      	b	0x101f4 <_stogir.vector-arithmetic.valid-type?+0x418>
   10200:      	ubfx	x10, x10, #0, #8
   10204:      	mov	x0, x10
   10208:      	b	0x101fc <_stogir.vector-arithmetic.valid-type?+0x420>

000000000001020c <_coil.core.Len$slice$len__i32>:
   1020c:      	mov	x0, x1
   10210:      	ret

0000000000010214 <_inherent$slice$data__i32>:
   10214:      	ret

0000000000010218 <_stogir.opcode.terminator?>:
   10218:      	sxtw	x0, w0
   1021c:      	cmp	x0, #0x0
   10220:      	b.lt	0x10244 <_stogir.opcode.terminator?+0x2c>
   10224:      	cmp	x0, #0x83
   10228:      	b.ge	0x10244 <_stogir.opcode.terminator?+0x2c>
   1022c:      	adrp	x16, 0x10000 <_stogir.vector-arithmetic.valid-type?+0x224>
		000000000001022c:  ARM64_RELOC_PAGE21	l_stogir.519
   10230:      	ldr	x16, [x16]
		0000000000010230:  ARM64_RELOC_PAGEOFF12	l_stogir.519
   10234:      	orr	x1, x16, xzr
   10238:      	add	x0, x1, x0
   1023c:      	ldrb	w0, [x0]
   10240:      	b	0x10248 <_stogir.opcode.terminator?+0x30>
   10244:      	movz	x0, #0x0, lsl #48
   10248:      	uxtb	w0, w0
   1024c:      	and	x0, x0, #0x8
   10250:      	uxtb	w0, w0
   10254:      	cmp	x0, #0x0
   10258:      	cset	w0, eq
   1025c:      	uxtb	w16, w0
   10260:      	cmp	w16, wzr
   10264:      	cset	x0, eq
   10268:      	ret

000000000001026c <_stogir.switch.sign-mask>:
   1026c:      	sxtw	x0, w0
   10270:      	cmp	x0, #0x7
   10274:      	b.lt	0x10290 <_stogir.switch.sign-mask+0x24>
   10278:      	cmp	x0, #0xb
   1027c:      	b.gt	0x10290 <_stogir.switch.sign-mask+0x24>
   10280:      	cmp	x0, #0x0
   10284:      	b.ne	0x102c8 <_stogir.switch.sign-mask+0x5c>
   10288:      	movz	x0, #0x0, lsl #48
   1028c:      	b	0x1029c <_stogir.switch.sign-mask+0x30>
   10290:      	movz	x0, #0x0, lsl #48
   10294:      	ret
   10298:      	mov	x0, #0x1                ; =1
   1029c:      	lsr	w0, w0, #0
   102a0:      	sxtw	x0, w0
   102a4:      	lsl	x0, x0, #3
   102a8:      	lsr	w0, w0, #0
   102ac:      	sxtw	x0, w0
   102b0:      	sub	x0, x0, #0x1
   102b4:      	lsr	w0, w0, #0
   102b8:      	sxtw	x0, w0
   102bc:      	mov	x16, #0x1               ; =1
   102c0:      	lsl	x0, x16, x0
   102c4:      	b	0x10294 <_stogir.switch.sign-mask+0x28>
   102c8:      	cmp	x0, #0x1
   102cc:      	b.eq	0x10298 <_stogir.switch.sign-mask+0x2c>
   102d0:      	cmp	x0, #0x2
   102d4:      	b.eq	0x10298 <_stogir.switch.sign-mask+0x2c>
   102d8:      	cmp	x0, #0x7
   102dc:      	b.eq	0x10298 <_stogir.switch.sign-mask+0x2c>
   102e0:      	cmp	x0, #0x8
   102e4:      	b.eq	0x10298 <_stogir.switch.sign-mask+0x2c>
   102e8:      	cmp	x0, #0x3
   102ec:      	b.eq	0x10348 <_stogir.switch.sign-mask+0xdc>
   102f0:      	cmp	x0, #0x9
   102f4:      	b.eq	0x10348 <_stogir.switch.sign-mask+0xdc>
   102f8:      	cmp	x0, #0x4
   102fc:      	b.eq	0x10350 <_stogir.switch.sign-mask+0xe4>
   10300:      	cmp	x0, #0xa
   10304:      	b.eq	0x10350 <_stogir.switch.sign-mask+0xe4>
   10308:      	cmp	x0, #0xd
   1030c:      	b.eq	0x10350 <_stogir.switch.sign-mask+0xe4>
   10310:      	cmp	x0, #0x5
   10314:      	b.eq	0x10358 <_stogir.switch.sign-mask+0xec>
   10318:      	cmp	x0, #0xb
   1031c:      	b.eq	0x10358 <_stogir.switch.sign-mask+0xec>
   10320:      	cmp	x0, #0xc
   10324:      	b.eq	0x10358 <_stogir.switch.sign-mask+0xec>
   10328:      	cmp	x0, #0x6
   1032c:      	cset	w0, eq
   10330:      	uxtb	w16, w0
   10334:      	cmp	w16, wzr
   10338:      	mov	x16, #0x8               ; =8
   1033c:      	movn	x17, #0x0, lsl #48
   10340:      	csel	x0, x16, x17, ne
   10344:      	b	0x1035c <_stogir.switch.sign-mask+0xf0>
   10348:      	mov	x0, #0x2                ; =2
   1034c:      	b	0x1029c <_stogir.switch.sign-mask+0x30>
   10350:      	mov	x0, #0x4                ; =4
   10354:      	b	0x1034c <_stogir.switch.sign-mask+0xe0>
   10358:      	mov	x0, #0x8                ; =8
   1035c:      	b	0x10354 <_stogir.switch.sign-mask+0xe8>
