
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/symbol-cast-placement/build/hot-code-audit/candidate-verify.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x130
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0xe0]
     1b4:      	str	x20, [sp, #0xe8]
     1b8:      	str	x21, [sp, #0xf0]
     1bc:      	str	x22, [sp, #0xf8]
     1c0:      	str	x23, [sp, #0x100]
     1c4:      	str	x24, [sp, #0x108]
     1c8:      	str	x25, [sp, #0x110]
     1cc:      	str	x26, [sp, #0x118]
     1d0:      	str	x27, [sp, #0x120]
     1d4:      	str	x28, [sp, #0x128]
     1d8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001d8:  ARM64_RELOC_PAGE21	l_stogir.304
     1dc:      	ldr	x16, [x16]
		00000000000001dc:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1e0:      	orr	x19, x16, xzr
     1e4:      	add	x1, x0, #0x78
     1e8:      	ldr	x20, [x0, #0x8]
     1ec:      	mov	x21, x8
     1f0:      	mov	x22, x0
     1f4:      	mov	x0, x1
     1f8:      	bl	0x1f8 <_stogir.verify.structure+0x58>
		00000000000001f8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1fc:      	cmp	x20, x0
     200:      	b.ne	0x498 <_stogir.verify.structure+0x2f8>
     204:      	mov	x0, x19
     208:      	movz	x1, #0x0, lsl #48
     20c:      	add	x20, x22, #0x110
     210:      	add	x23, x22, #0x78
     214:      	add	x24, x22, #0x28
     218:      	add	x25, x22, #0x50
     21c:      	add	x26, x22, #0x78
     220:      	add	x27, x22, #0x28
     224:      	add	x28, x22, #0x50
     228:      	add	x2, x20, #0x28
     22c:      	mov	x3, x0
     230:      	mov	x4, x1
     234:      	mov	x0, #0x1                ; =1
     238:      	movz	x1, #0x0, lsl #48
     23c:      	b	0x2b8 <_stogir.verify.structure+0x118>
     240:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000240:  ARM64_RELOC_PAGE21	l_stogir.305
     244:      	ldr	x16, [x16]
		0000000000000244:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     248:      	orr	x1, x16, xzr
     24c:      	mov	x2, x1
     250:      	mov	x1, x19
     254:      	mov	x3, #0x16               ; =22
     258:      	b	0x294 <_stogir.verify.structure+0xf4>
     25c:      	nop
     260:      	mov	x0, x21
     264:      	str	x20, [sp, #0x78]
     268:      	str	x19, [sp, #0x80]
     26c:      	ldr	x19, [sp, #0x40]
     270:      	mov	x21, x23
     274:      	str	x24, [sp, #0x60]
     278:      	str	x25, [sp, #0x58]
     27c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000027c:  ARM64_RELOC_PAGE21	l_stogir.306
     280:      	ldr	x16, [x16]
		0000000000000280:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     284:      	orr	x1, x16, xzr
     288:      	mov	x2, x1
     28c:      	mov	x1, x19
     290:      	mov	x3, #0x23               ; =35
     294:      	ldr	x19, [sp, #0x30]
     298:      	ldr	x20, [sp, #0x78]
     29c:      	mov	x23, x21
     2a0:      	ldr	x21, [sp, #0x38]
     2a4:      	ldr	x24, [sp, #0x60]
     2a8:      	ldr	x25, [sp, #0x58]
     2ac:      	mov	x4, x3
     2b0:      	mov	x3, x2
     2b4:      	ldr	x2, [sp, #0x80]
     2b8:      	str	x1, [sp, #0x40]
     2bc:      	mov	x1, x4
     2c0:      	str	x3, [sp, #0x48]
     2c4:      	str	x4, [sp, #0x50]
     2c8:      	str	x19, [sp, #0x30]
     2cc:      	str	x21, [sp, #0x38]
     2d0:      	mov	x21, x0
     2d4:      	mov	x0, x3
     2d8:      	fmov	d31, x2
     2dc:      	mov	x2, x19
     2e0:      	fmov	x19, d31
     2e4:      	movz	x3, #0x0, lsl #48
     2e8:      	bl	0x2e8 <_stogir.verify.structure+0x148>
		00000000000002e8:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     2ec:      	cmp	x0, #0x0
     2f0:      	b.eq	0xccc <_stogir.verify.structure+0xb2c>
     2f4:      	ldr	x0, [x22, #0x8]
     2f8:      	cmp	x21, x0
     2fc:      	b.ge	0xcd4 <_stogir.verify.structure+0xb34>
     300:      	lsl	x0, x21, #4
     304:      	lsl	x1, x21, #2
     308:      	ldr	x2, [x22]
     30c:      	add	x0, x0, x2
     310:      	ldr	x0, [x0]
     314:      	ldr	x2, [x22, #0x78]
     318:      	add	x1, x1, x2
     31c:      	ldr	w1, [x1]
     320:      	sxtw	x1, w1
     324:      	cmp	x1, #0x0
     328:      	b.lt	0x260 <_stogir.verify.structure+0xc0>
     32c:      	mov	x17, #0xffff            ; =65535
     330:      	cmp	x1, x17
     334:      	b.gt	0xcdc <_stogir.verify.structure+0xb3c>
     338:      	uxtb	w2, w0
     33c:      	orr	x3, x2, xzr
     340:      	lsr	w3, w3, #0
     344:      	str	w3, [sp, #0x70]
     348:      	str	x25, [sp, #0x58]
     34c:      	mov	x25, x0
     350:      	mov	w0, w3
     354:      	str	x24, [sp, #0x60]
     358:      	mov	x24, x1
     35c:      	str	x23, [sp, #0x68]
     360:      	mov	w23, w2
     364:      	bl	0x364 <_stogir.verify.structure+0x1c4>
		0000000000000364:  ARM64_RELOC_BRANCH26	_stogir.opcode.valid?
     368:      	cmp	x0, #0x0
     36c:      	b.eq	0xcfc <_stogir.verify.structure+0xb5c>
     370:      	lsr	w25, w25, #0
     374:      	ubfx	x0, x25, #8, #8
     378:      	orr	x1, x0, xzr
     37c:      	lsr	w1, w1, #0
     380:      	str	x20, [sp, #0x78]
     384:      	mov	w20, w0
     388:      	mov	w0, w1
     38c:      	bl	0x38c <_stogir.verify.structure+0x1ec>
		000000000000038c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     390:      	cmp	x0, #0x0
     394:      	b.eq	0xd14 <_stogir.verify.structure+0xb74>
     398:      	ldr	w0, [sp, #0x70]
     39c:      	bl	0x39c <_stogir.verify.structure+0x1fc>
		000000000000039c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     3a0:      	lsr	w0, w0, #0
     3a4:      	sxtw	x0, w0
     3a8:      	cmp	x0, #0x0
     3ac:      	b.lt	0xa70 <_stogir.verify.structure+0x8d0>
     3b0:      	ldr	w0, [sp, #0x70]
     3b4:      	bl	0x3b4 <_stogir.verify.structure+0x214>
		00000000000003b4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     3b8:      	lsr	w0, w0, #0
     3bc:      	sxtw	x0, w0
     3c0:      	cmp	x24, x0
     3c4:      	b.eq	0xa70 <_stogir.verify.structure+0x8d0>
     3c8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000003c8:  ARM64_RELOC_PAGE21	l_stogir.307
     3cc:      	ldr	x16, [x16]
		00000000000003cc:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     3d0:      	orr	x0, x16, xzr
     3d4:      	str	x19, [sp, #0x80]
     3d8:      	ldr	x1, [sp, #0x40]
     3dc:      	mov	x2, x0
     3e0:      	mov	x0, x21
     3e4:      	ldr	x21, [sp, #0x68]
     3e8:      	mov	x3, #0x23               ; =35
     3ec:      	b	0x494 <_stogir.verify.structure+0x2f4>
     3f0:      	ldr	x0, [sp, #0x48]
     3f4:      	ldr	x1, [sp, #0x50]
     3f8:      	ldr	x2, [sp, #0x30]
     3fc:      	movz	x3, #0x0, lsl #48
     400:      	bl	0x400 <_stogir.verify.structure+0x260>
		0000000000000400:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     404:      	cmp	x0, #0x0
     408:      	b.eq	0x420 <_stogir.verify.structure+0x280>
     40c:      	and	x0, x19, #0xffffffff
     410:      	mov	x1, x0
     414:      	movz	x0, #0x0, lsl #48
     418:      	movz	x2, #0x0, lsl #48
     41c:      	b	0x42c <_stogir.verify.structure+0x28c>
     420:      	ldr	x1, [sp, #0x48]
     424:      	ldr	x2, [sp, #0x50]
     428:      	mov	x0, #0x1                ; =1
     42c:      	ldr	x3, [sp, #0x38]
     430:      	str	x0, [x3]
     434:      	str	x1, [x3, #0x8]
     438:      	str	x2, [x3, #0x10]
     43c:      	ldr	x19, [sp, #0xe0]
     440:      	ldr	x20, [sp, #0xe8]
     444:      	ldr	x21, [sp, #0xf0]
     448:      	ldr	x22, [sp, #0xf8]
     44c:      	ldr	x23, [sp, #0x100]
     450:      	ldr	x24, [sp, #0x108]
     454:      	ldr	x25, [sp, #0x110]
     458:      	ldr	x26, [sp, #0x118]
     45c:      	ldr	x27, [sp, #0x120]
     460:      	ldr	x28, [sp, #0x128]
     464:      	ldr	x29, [sp, #0x10]
     468:      	ldr	x30, [sp, #0x18]
     46c:      	add	sp, sp, #0x130
     470:      	ret
     474:      	ldr	x0, [sp, #0xc8]
     478:      	add	x0, x25, x0
     47c:      	ldr	x19, [sp, #0x40]
     480:      	add	x1, x19, #0x1
     484:      	lsr	w1, w1, #0
     488:      	sxtw	x1, w1
     48c:      	ldr	x2, [sp, #0xb0]
     490:      	ldr	x3, [sp, #0xb8]
     494:      	b	0x258 <_stogir.verify.structure+0xb8>
     498:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000498:  ARM64_RELOC_PAGE21	l_stogir.308
     49c:      	ldr	x16, [x16]
		000000000000049c:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     4a0:      	orr	x0, x16, xzr
     4a4:      	mov	x1, #0x2c               ; =44
     4a8:      	b	0x20c <_stogir.verify.structure+0x6c>
     4ac:      	mov	x11, x9
     4b0:      	movz	x9, #0x0, lsl #48
     4b4:      	cmp	x9, #0x0
     4b8:      	b.eq	0xd28 <_stogir.verify.structure+0xb88>
     4bc:      	cmp	x0, #0x0
     4c0:      	b.eq	0xb5c <_stogir.verify.structure+0x9bc>
     4c4:      	ldr	x21, [sp, #0x68]
     4c8:      	ldr	x0, [sp, #0x60]
     4cc:      	ldr	x4, [sp, #0x58]
     4d0:      	mov	x3, x7
     4d4:      	mov	x5, x11
     4d8:      	b	0xae8 <_stogir.verify.structure+0x948>
     4dc:      	mov	x0, x1
     4e0:      	ldr	x1, [sp, #0xd0]
     4e4:      	b	0x4f0 <_stogir.verify.structure+0x350>
     4e8:      	mov	x0, x11
     4ec:      	ldr	x1, [sp, #0xd0]
     4f0:      	b	0x608 <_stogir.verify.structure+0x468>
     4f4:      	lsr	x3, x2, #0
     4f8:      	str	x1, [sp, #0xa0]
     4fc:      	str	x2, [sp, #0xa8]
     500:      	mov	x2, x3
     504:      	str	w19, [sp, #0x98]
     508:      	mov	x19, x0
     50c:      	mov	x0, x1
     510:      	ldr	x1, [sp, #0x30]
     514:      	bl	0x514 <_stogir.verify.structure+0x374>
		0000000000000514:  ARM64_RELOC_BRANCH26	_memcmp
     518:      	lsr	w0, w0, #0
     51c:      	sxtw	x0, w0
     520:      	cmp	x0, #0x0
     524:      	cset	w0, eq
     528:      	ubfx	x0, x0, #0, #8
     52c:      	ldr	x1, [sp, #0xa0]
     530:      	ldr	x2, [sp, #0xa8]
     534:      	b	0x544 <_stogir.verify.structure+0x3a4>
     538:      	ldr	x1, [sp, #0xa0]
     53c:      	ldr	x2, [sp, #0xa8]
     540:      	movz	x0, #0x0, lsl #48
     544:      	cmp	x0, #0x0
     548:      	b.eq	0x55c <_stogir.verify.structure+0x3bc>
     54c:      	cmp	x19, x24
     550:      	cset	w0, le
     554:      	ubfx	x0, x0, #0, #8
     558:      	b	0x560 <_stogir.verify.structure+0x3c0>
     55c:      	movz	x0, #0x0, lsl #48
     560:      	cmp	x0, #0x0
     564:      	b.eq	0xd3c <_stogir.verify.structure+0xb9c>
     568:      	lsr	w0, w19, #0
     56c:      	str	x1, [sp, #0xb0]
     570:      	mov	w1, w0
     574:      	str	x2, [sp, #0xb8]
     578:      	str	x24, [sp, #0xc0]
     57c:      	mov	w24, w0
     580:      	ldr	w0, [sp, #0x70]
     584:      	bl	0x584 <_stogir.verify.structure+0x3e4>
		0000000000000584:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     588:      	add	x16, sp, #0x20
     58c:      	str	x16, [sp]
     590:      	ldr	w1, [sp, #0x98]
     594:      	mov	w2, w24
     598:      	str	x21, [sp, #0xc8]
     59c:      	mov	x21, x0
     5a0:      	mov	x0, x22
     5a4:      	bl	0x5a4 <_stogir.verify.structure+0x404>
		00000000000005a4:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     5a8:      	ldr	x16, [sp]
     5ac:      	str	x0, [x16]
     5b0:      	str	x1, [x16, #0x8]
     5b4:      	add	x16, sp, #0x20
     5b8:      	ldr	x0, [x16]
     5bc:      	add	x16, sp, #0x20
     5c0:      	ldr	x1, [x16, #0x8]
     5c4:      	lsr	w0, w0, #0
     5c8:      	lsr	x16, x0, #0
     5cc:      	cmp	x16, #0x1
     5d0:      	b.eq	0x5ec <_stogir.verify.structure+0x44c>
     5d4:      	b.lo	0x5dc <_stogir.verify.structure+0x43c>
     5d8:      	b	0x5f0 <_stogir.verify.structure+0x450>
     5dc:      	cmp	x16, #0x0
     5e0:      	b.eq	0x5e8 <_stogir.verify.structure+0x448>
     5e4:      	b	0x5f0 <_stogir.verify.structure+0x450>
     5e8:      	b	0x5f4 <_stogir.verify.structure+0x454>
     5ec:      	b	0x65c <_stogir.verify.structure+0x4bc>
     5f0:      	b	0xc64 <_stogir.verify.structure+0xac4>
     5f4:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000005f4:  ARM64_RELOC_PAGE21	l_stogir.309
     5f8:      	ldr	x16, [x16]
		00000000000005f8:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     5fc:      	orr	x0, x16, xzr
     600:      	ldr	x21, [sp, #0x68]
     604:      	mov	x1, #0x17               ; =23
     608:      	add	x2, x19, #0x1
     60c:      	lsr	w2, w2, #0
     610:      	sxtw	x2, w2
     614:      	ldr	x24, [sp, #0xc0]
     618:      	ldr	w19, [sp, #0x98]
     61c:      	str	x21, [sp, #0x68]
     620:      	ldr	x21, [sp, #0xc8]
     624:      	fmov	d31, x0
     628:      	mov	x0, x2
     62c:      	mov	x2, x1
     630:      	fmov	x1, d31
     634:      	cmp	x2, #0x0
     638:      	b.ne	0xd50 <_stogir.verify.structure+0xbb0>
     63c:      	cmp	x2, #0x0
     640:      	b.ne	0x4f4 <_stogir.verify.structure+0x354>
     644:      	str	w19, [sp, #0x98]
     648:      	mov	x19, x0
     64c:      	str	x1, [sp, #0xa0]
     650:      	str	x2, [sp, #0xa8]
     654:      	mov	x0, #0x1                ; =1
     658:      	b	0x52c <_stogir.verify.structure+0x38c>
     65c:      	lsr	w21, w21, #0
     660:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000660:  ARM64_RELOC_PAGE21	l_stogir.310
     664:      	ldr	x16, [x16]
		0000000000000664:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     668:      	ldr	w0, [x16]
     66c:      	orr	x2, x21, xzr
     670:      	cmp	x2, x0
     674:      	b.ne	0x680 <_stogir.verify.structure+0x4e0>
     678:      	mov	x0, #0x1                ; =1
     67c:      	b	0x698 <_stogir.verify.structure+0x4f8>
     680:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000680:  ARM64_RELOC_PAGE21	l_stogir.311
     684:      	ldr	x16, [x16]
		0000000000000684:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     688:      	ldr	w0, [x16]
     68c:      	cmp	x2, x0
     690:      	cset	w0, eq
     694:      	ubfx	x0, x0, #0, #8
     698:      	lsr	w1, w1, #0
     69c:      	sxtw	x1, w1
     6a0:      	cmp	x1, #0x0
     6a4:      	cset	w3, gt
     6a8:      	lsl	x4, x1, #2
     6ac:      	cmp	x1, #0x0
     6b0:      	cset	w5, lt
     6b4:      	movz	x16, #0x0, lsl #48
     6b8:      	sub	x6, x16, x1
     6bc:      	sub	x7, x6, #0x1
     6c0:      	lsl	x8, x7, #2
     6c4:      	cmp	x0, #0x0
     6c8:      	b.eq	0x710 <_stogir.verify.structure+0x570>
     6cc:      	uxtb	w16, w3
     6d0:      	cmp	w16, wzr
     6d4:      	b.eq	0x9a8 <_stogir.verify.structure+0x808>
     6d8:      	ldr	x9, [x22, #0x8]
     6dc:      	cmp	x1, x9
     6e0:      	b.ge	0x9ec <_stogir.verify.structure+0x84c>
     6e4:      	ldr	x9, [x26, #0x8]
     6e8:      	cmp	x1, x9
     6ec:      	b.ge	0xbc0 <_stogir.verify.structure+0xa20>
     6f0:      	ldr	x9, [x22, #0x78]
     6f4:      	add	x9, x4, x9
     6f8:      	ldr	w9, [x9]
     6fc:      	sxtw	x9, w9
     700:      	cmp	x9, #0x0
     704:      	cset	w9, ge
     708:      	ubfx	x9, x9, #0, #8
     70c:      	b	0xbc4 <_stogir.verify.structure+0xa24>
     710:      	ldr	x9, [sp, #0xb0]
     714:      	ldr	x10, [sp, #0xb8]
     718:      	movz	x7, #0x0, lsl #48
     71c:      	b	0x734 <_stogir.verify.structure+0x594>
     720:      	ldr	x7, [sp, #0xb0]
     724:      	ldr	x10, [sp, #0xb8]
     728:      	fmov	d31, x7
     72c:      	mov	x7, x9
     730:      	fmov	x9, d31
     734:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000734:  ARM64_RELOC_PAGE21	l_stogir.312
     738:      	ldr	x16, [x16]
		0000000000000738:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     73c:      	ldr	w11, [x16]
     740:      	cmp	x2, x11
     744:      	b.ne	0xd64 <_stogir.verify.structure+0xbc4>
     748:      	cmp	x1, #0x0
     74c:      	b.gt	0x948 <_stogir.verify.structure+0x7a8>
     750:      	ldr	x12, [sp, #0x78]
     754:      	ldr	x2, [sp, #0x80]
     758:      	mov	x11, x9
     75c:      	movz	x9, #0x0, lsl #48
     760:      	lsr	w9, w9, #0
     764:      	lsr	x16, x9, #0
     768:      	cmp	x16, #0x1
     76c:      	b.eq	0x788 <_stogir.verify.structure+0x5e8>
     770:      	b.lo	0x778 <_stogir.verify.structure+0x5d8>
     774:      	b	0x78c <_stogir.verify.structure+0x5ec>
     778:      	cmp	x16, #0x0
     77c:      	b.eq	0x784 <_stogir.verify.structure+0x5e4>
     780:      	b	0x78c <_stogir.verify.structure+0x5ec>
     784:      	b	0x790 <_stogir.verify.structure+0x5f0>
     788:      	b	0x7a4 <_stogir.verify.structure+0x604>
     78c:      	b	0xcc4 <_stogir.verify.structure+0xb24>
     790:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000790:  ARM64_RELOC_PAGE21	l_stogir.313
     794:      	ldr	x16, [x16]
		0000000000000794:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     798:      	orr	x9, x16, xzr
     79c:      	mov	x10, #0x21              ; =33
     7a0:      	b	0x7a8 <_stogir.verify.structure+0x608>
     7a4:      	mov	x9, x11
     7a8:      	cmp	x21, #0xf
     7ac:      	b.hs	0x4ac <_stogir.verify.structure+0x30c>
     7b0:      	mov	x16, #0x1               ; =1
     7b4:      	lsl	x11, x16, x21
     7b8:      	lsr	w11, w11, #0
     7bc:      	mov	x17, #0x5e1c            ; =24092
     7c0:      	and	x11, x11, x17
     7c4:      	lsr	w11, w11, #0
     7c8:      	cmp	x11, #0x0
     7cc:      	cset	w11, eq
     7d0:      	uxtb	w16, w11
     7d4:      	cmp	w16, wzr
     7d8:      	cset	x11, eq
     7dc:      	fmov	d31, x9
     7e0:      	mov	x9, x11
     7e4:      	fmov	x11, d31
     7e8:      	b	0x4b4 <_stogir.verify.structure+0x314>
     7ec:      	lsr	w0, w21, #0
     7f0:      	lsr	w19, w0, #0
     7f4:      	cmp	x23, #0x78
     7f8:      	cset	w23, eq
     7fc:      	cmp	x20, #0x0
     800:      	cset	w20, eq
     804:      	mov	x2, x1
     808:      	ldr	x1, [sp, #0x88]
     80c:      	mov	x0, #0x1                ; =1
     810:      	b	0x634 <_stogir.verify.structure+0x494>
     814:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000814:  ARM64_RELOC_PAGE21	l_stogir.314
     818:      	ldr	x16, [x16]
		0000000000000818:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     81c:      	orr	x0, x16, xzr
     820:      	mov	x1, #0x1b               ; =27
     824:      	b	0x8b8 <_stogir.verify.structure+0x718>
     828:      	lsr	x3, x2, #0
     82c:      	str	x1, [sp, #0x88]
     830:      	str	x2, [sp, #0x90]
     834:      	mov	x2, x3
     838:      	str	x19, [sp, #0x80]
     83c:      	mov	x19, x0
     840:      	mov	x0, x1
     844:      	ldr	x1, [sp, #0x30]
     848:      	bl	0x848 <_stogir.verify.structure+0x6a8>
		0000000000000848:  ARM64_RELOC_BRANCH26	_memcmp
     84c:      	lsr	w0, w0, #0
     850:      	sxtw	x0, w0
     854:      	cmp	x0, #0x0
     858:      	cset	w0, eq
     85c:      	ubfx	x0, x0, #0, #8
     860:      	ldr	x1, [sp, #0x90]
     864:      	b	0x870 <_stogir.verify.structure+0x6d0>
     868:      	ldr	x1, [sp, #0x90]
     86c:      	movz	x0, #0x0, lsl #48
     870:      	cmp	x0, #0x0
     874:      	b.eq	0x888 <_stogir.verify.structure+0x6e8>
     878:      	cmp	x19, x25
     87c:      	cset	w0, lt
     880:      	ubfx	x0, x0, #0, #8
     884:      	b	0x88c <_stogir.verify.structure+0x6ec>
     888:      	movz	x0, #0x0, lsl #48
     88c:      	cmp	x0, #0x0
     890:      	b.eq	0x7ec <_stogir.verify.structure+0x64c>
     894:      	add	x0, x19, x21
     898:      	ldr	x2, [x22, #0x78]
     89c:      	lsl	x0, x0, #2
     8a0:      	add	x0, x0, x2
     8a4:      	ldr	w0, [x0]
     8a8:      	sxtw	x0, w0
     8ac:      	cmn	x0, #0x1
     8b0:      	b.ne	0x814 <_stogir.verify.structure+0x674>
     8b4:      	ldr	x0, [sp, #0x88]
     8b8:      	add	x2, x19, #0x1
     8bc:      	ldr	x19, [sp, #0x80]
     8c0:      	fmov	d31, x0
     8c4:      	mov	x0, x2
     8c8:      	mov	x2, x1
     8cc:      	fmov	x1, d31
     8d0:      	cmp	x2, #0x0
     8d4:      	b.ne	0xd70 <_stogir.verify.structure+0xbd0>
     8d8:      	cmp	x2, #0x0
     8dc:      	b.ne	0x828 <_stogir.verify.structure+0x688>
     8e0:      	str	x19, [sp, #0x80]
     8e4:      	mov	x19, x0
     8e8:      	str	x1, [sp, #0x88]
     8ec:      	str	x2, [sp, #0x90]
     8f0:      	mov	x0, #0x1                ; =1
     8f4:      	b	0x860 <_stogir.verify.structure+0x6c0>
     8f8:      	ldr	x0, [sp, #0x48]
     8fc:      	ldr	x1, [sp, #0x50]
     900:      	add	x2, x24, #0x4
     904:      	ldr	x3, [x22, #0x8]
     908:      	asr	x16, x2, #63
     90c:      	lsr	x16, x16, #62
     910:      	add	x2, x2, x16
     914:      	asr	x2, x2, #2
     918:      	orr	x25, x2, xzr
     91c:      	add	x2, x25, x21
     920:      	cmp	x2, x3
     924:      	b.le	0x938 <_stogir.verify.structure+0x798>
     928:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000928:  ARM64_RELOC_PAGE21	l_stogir.315
     92c:      	ldr	x16, [x16]
		000000000000092c:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     930:      	orr	x0, x16, xzr
     934:      	mov	x1, #0x15               ; =21
     938:      	mov	x2, x1
     93c:      	mov	x1, x0
     940:      	mov	x0, #0x1                ; =1
     944:      	b	0x8d0 <_stogir.verify.structure+0x730>
     948:      	ldr	x2, [sp, #0x80]
     94c:      	ldr	x11, [x2, #0x8]
     950:      	cmp	x1, x11
     954:      	b.gt	0xd84 <_stogir.verify.structure+0xbe4>
     958:      	sub	x11, x1, #0x1
     95c:      	ldr	x12, [sp, #0x78]
     960:      	ldr	x13, [x12, #0x28]
     964:      	mov	x17, #0x18              ; =24
     968:      	mul	x11, x11, x17
     96c:      	add	x11, x11, x13
     970:      	ldr	x13, [x11]
     974:      	ldr	x11, [x11, #0x8]
     978:      	ldr	x14, [x12, #0x8]
     97c:      	cmp	x13, #0x0
     980:      	b.lt	0xba4 <_stogir.verify.structure+0xa04>
     984:      	cmp	x13, x14
     988:      	b.gt	0xba4 <_stogir.verify.structure+0xa04>
     98c:      	cmp	x11, #0x0
     990:      	b.lt	0xba4 <_stogir.verify.structure+0xa04>
     994:      	sub	x13, x14, x13
     998:      	cmp	x11, x13
     99c:      	b.gt	0xba4 <_stogir.verify.structure+0xa04>
     9a0:      	mov	x11, #0x1               ; =1
     9a4:      	b	0xba8 <_stogir.verify.structure+0xa08>
     9a8:      	uxtb	w16, w5
     9ac:      	cmp	w16, wzr
     9b0:      	b.eq	0x9f4 <_stogir.verify.structure+0x854>
     9b4:      	ldr	x9, [x27, #0x8]
     9b8:      	ldr	x10, [x28, #0x8]
     9bc:      	cmp	x9, x10
     9c0:      	b.ne	0xbb8 <_stogir.verify.structure+0xa18>
     9c4:      	cmp	x6, x9
     9c8:      	b.gt	0xc30 <_stogir.verify.structure+0xa90>
     9cc:      	ldr	x9, [x22, #0x50]
     9d0:      	add	x9, x8, x9
     9d4:      	ldr	w9, [x9]
     9d8:      	sxtw	x9, w9
     9dc:      	cmp	x9, #0x0
     9e0:      	cset	w9, gt
     9e4:      	ubfx	x9, x9, #0, #8
     9e8:      	b	0xc34 <_stogir.verify.structure+0xa94>
     9ec:      	movz	x9, #0x0, lsl #48
     9f0:      	b	0x9f8 <_stogir.verify.structure+0x858>
     9f4:      	movz	x9, #0x0, lsl #48
     9f8:      	cmp	x9, #0x0
     9fc:      	b.eq	0xa2c <_stogir.verify.structure+0x88c>
     a00:      	uxtb	w16, w3
     a04:      	cmp	w16, wzr
     a08:      	b.eq	0xa1c <_stogir.verify.structure+0x87c>
     a0c:      	lsl	x7, x1, #4
     a10:      	ldr	x9, [x22]
     a14:      	add	x7, x7, x9
     a18:      	b	0xa28 <_stogir.verify.structure+0x888>
     a1c:      	lsl	x7, x7, #4
     a20:      	ldr	x9, [x22, #0x28]
     a24:      	add	x7, x7, x9
     a28:      	b	0xa30 <_stogir.verify.structure+0x890>
     a2c:      	movz	x7, #0x0, lsl #48
     a30:      	cmp	x7, #0x0
     a34:      	cset	w9, eq
     a38:      	uxtb	w16, w9
     a3c:      	cmp	w16, wzr
     a40:      	cset	x9, eq
     a44:      	cmp	x9, #0x0
     a48:      	b.eq	0x720 <_stogir.verify.structure+0x580>
     a4c:      	ldr	w7, [x7]
     a50:      	uxtb	w7, w7
     a54:      	cmp	x7, #0x48
     a58:      	b.ne	0x720 <_stogir.verify.structure+0x580>
     a5c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000a5c:  ARM64_RELOC_PAGE21	l_stogir.316
     a60:      	ldr	x16, [x16]
		0000000000000a60:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     a64:      	orr	x7, x16, xzr
     a68:      	mov	x10, #0x25              ; =37
     a6c:      	b	0x728 <_stogir.verify.structure+0x588>
     a70:      	ldr	w0, [sp, #0x70]
     a74:      	bl	0xa74 <_stogir.verify.structure+0x8d4>
		0000000000000a74:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     a78:      	lsr	w0, w0, #0
     a7c:      	sxtw	x0, w0
     a80:      	cmn	x0, #0x1
     a84:      	b.ne	0x8f8 <_stogir.verify.structure+0x758>
     a88:      	ubfx	x0, x25, #16, #16
     a8c:      	cmp	x24, x0
     a90:      	b.eq	0x8f8 <_stogir.verify.structure+0x758>
     a94:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000a94:  ARM64_RELOC_PAGE21	l_stogir.317
     a98:      	ldr	x16, [x16]
		0000000000000a98:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     a9c:      	orr	x0, x16, xzr
     aa0:      	mov	x1, #0x24               ; =36
     aa4:      	b	0x900 <_stogir.verify.structure+0x760>
     aa8:      	mov	x0, #0x1                ; =1
     aac:      	cmp	x0, #0x0
     ab0:      	b.eq	0x4dc <_stogir.verify.structure+0x33c>
     ab4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ab4:  ARM64_RELOC_PAGE21	l_stogir.318
     ab8:      	ldr	x16, [x16]
		0000000000000ab8:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     abc:      	orr	x0, x16, xzr
     ac0:      	mov	x1, #0x1a               ; =26
     ac4:      	b	0x4e4 <_stogir.verify.structure+0x344>
     ac8:      	movz	x0, #0x0, lsl #48
     acc:      	ldr	x1, [sp, #0xd8]
     ad0:      	cmp	x0, #0x0
     ad4:      	b.eq	0xaa8 <_stogir.verify.structure+0x908>
     ad8:      	movz	x0, #0x0, lsl #48
     adc:      	b	0xaac <_stogir.verify.structure+0x90c>
     ae0:      	movz	x3, #0x0, lsl #48
     ae4:      	mov	x5, x11
     ae8:      	cmp	x3, #0x0
     aec:      	b.eq	0xb10 <_stogir.verify.structure+0x970>
     af0:      	str	x12, [sp, #0x78]
     af4:      	str	x2, [sp, #0x80]
     af8:      	str	x0, [sp, #0x60]
     afc:      	str	x4, [sp, #0x58]
     b00:      	str	x10, [sp, #0xd0]
     b04:      	mov	x1, x5
     b08:      	mov	x0, #0x1                ; =1
     b0c:      	b	0xad0 <_stogir.verify.structure+0x930>
     b10:      	cmp	x1, #0x0
     b14:      	b.ne	0xd8c <_stogir.verify.structure+0xbec>
     b18:      	mov	w1, w24
     b1c:      	str	x2, [sp, #0x80]
     b20:      	str	x12, [sp, #0x78]
     b24:      	str	x10, [sp, #0xd0]
     b28:      	str	x0, [sp, #0x60]
     b2c:      	ldr	w0, [sp, #0x70]
     b30:      	str	x4, [sp, #0x58]
     b34:      	str	x5, [sp, #0xd8]
     b38:      	bl	0xb38 <_stogir.verify.structure+0x998>
		0000000000000b38:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     b3c:      	lsr	w0, w0, #0
     b40:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000b40:  ARM64_RELOC_PAGE21	l_stogir.319
     b44:      	ldr	x16, [x16]
		0000000000000b44:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     b48:      	ldr	w1, [x16]
     b4c:      	cmp	x0, x1
     b50:      	b.ne	0xc38 <_stogir.verify.structure+0xa98>
     b54:      	mov	x0, #0x1                ; =1
     b58:      	b	0xbcc <_stogir.verify.structure+0xa2c>
     b5c:      	uxtb	w16, w3
     b60:      	cmp	w16, wzr
     b64:      	b.eq	0xda8 <_stogir.verify.structure+0xc08>
     b68:      	ldr	x0, [x22, #0x8]
     b6c:      	cmp	x1, x0
     b70:      	b.ge	0xdb0 <_stogir.verify.structure+0xc10>
     b74:      	ldr	x21, [sp, #0x68]
     b78:      	ldr	x0, [x21, #0x8]
     b7c:      	cmp	x1, x0
     b80:      	b.ge	0xc5c <_stogir.verify.structure+0xabc>
     b84:      	ldr	x0, [x22, #0x78]
     b88:      	add	x0, x4, x0
     b8c:      	ldr	w0, [x0]
     b90:      	sxtw	x0, w0
     b94:      	cmp	x0, #0x0
     b98:      	cset	w0, ge
     b9c:      	ubfx	x0, x0, #0, #8
     ba0:      	b	0xc60 <_stogir.verify.structure+0xac0>
     ba4:      	movz	x11, #0x0, lsl #48
     ba8:      	fmov	d31, x9
     bac:      	mov	x9, x11
     bb0:      	fmov	x11, d31
     bb4:      	b	0x760 <_stogir.verify.structure+0x5c0>
     bb8:      	movz	x9, #0x0, lsl #48
     bbc:      	b	0x9f8 <_stogir.verify.structure+0x858>
     bc0:      	movz	x9, #0x0, lsl #48
     bc4:      	b	0x9f0 <_stogir.verify.structure+0x850>
     bc8:      	movz	x0, #0x0, lsl #48
     bcc:      	b	0xacc <_stogir.verify.structure+0x92c>
     bd0:      	movz	x0, #0x0, lsl #48
     bd4:      	ldr	x4, [sp, #0x58]
     bd8:      	mov	x3, x0
     bdc:      	ldr	x0, [sp, #0x60]
     be0:      	b	0xae4 <_stogir.verify.structure+0x944>
     be4:      	uxtb	w16, w5
     be8:      	cmp	w16, wzr
     bec:      	b.eq	0xdb8 <_stogir.verify.structure+0xc18>
     bf0:      	ldr	x0, [sp, #0x60]
     bf4:      	ldr	x3, [x0, #0x8]
     bf8:      	ldr	x4, [sp, #0x58]
     bfc:      	ldr	x5, [x4, #0x8]
     c00:      	cmp	x3, x5
     c04:      	b.ne	0xc54 <_stogir.verify.structure+0xab4>
     c08:      	cmp	x6, x3
     c0c:      	b.gt	0xc88 <_stogir.verify.structure+0xae8>
     c10:      	ldr	x3, [x22, #0x50]
     c14:      	add	x3, x8, x3
     c18:      	ldr	w3, [x3]
     c1c:      	sxtw	x3, w3
     c20:      	cmp	x3, #0x0
     c24:      	cset	w3, gt
     c28:      	ubfx	x3, x3, #0, #8
     c2c:      	b	0xc8c <_stogir.verify.structure+0xaec>
     c30:      	movz	x9, #0x0, lsl #48
     c34:      	b	0xbbc <_stogir.verify.structure+0xa1c>
     c38:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000c38:  ARM64_RELOC_PAGE21	l_stogir.320
     c3c:      	ldr	x16, [x16]
		0000000000000c3c:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     c40:      	ldr	w1, [x16]
     c44:      	cmp	x0, x1
     c48:      	b.ne	0xc6c <_stogir.verify.structure+0xacc>
     c4c:      	mov	x0, #0x1                ; =1
     c50:      	b	0xbcc <_stogir.verify.structure+0xa2c>
     c54:      	movz	x3, #0x0, lsl #48
     c58:      	b	0xae4 <_stogir.verify.structure+0x944>
     c5c:      	movz	x0, #0x0, lsl #48
     c60:      	b	0xbd4 <_stogir.verify.structure+0xa34>
     c64:      	brk	#0
     c68:      	b	0xc64 <_stogir.verify.structure+0xac4>
     c6c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000c6c:  ARM64_RELOC_PAGE21	l_stogir.321
     c70:      	ldr	x16, [x16]
		0000000000000c70:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     c74:      	ldr	w1, [x16]
     c78:      	cmp	x0, x1
     c7c:      	b.ne	0xc90 <_stogir.verify.structure+0xaf0>
     c80:      	mov	x0, #0x1                ; =1
     c84:      	b	0xbcc <_stogir.verify.structure+0xa2c>
     c88:      	movz	x3, #0x0, lsl #48
     c8c:      	b	0xc58 <_stogir.verify.structure+0xab8>
     c90:      	uxtb	w16, w23
     c94:      	cmp	w16, wzr
     c98:      	b.eq	0xbc8 <_stogir.verify.structure+0xa28>
     c9c:      	uxtb	w16, w20
     ca0:      	cmp	w16, wzr
     ca4:      	b.eq	0xcbc <_stogir.verify.structure+0xb1c>
     ca8:      	sxtw	x24, w24
     cac:      	cmp	x24, #0x2
     cb0:      	cset	w0, eq
     cb4:      	ubfx	x0, x0, #0, #8
     cb8:      	b	0xcc0 <_stogir.verify.structure+0xb20>
     cbc:      	movz	x0, #0x0, lsl #48
     cc0:      	b	0xbcc <_stogir.verify.structure+0xa2c>
     cc4:      	brk	#0
     cc8:      	b	0xcc4 <_stogir.verify.structure+0xb24>
     ccc:      	ldr	x19, [sp, #0x40]
     cd0:      	b	0x3f0 <_stogir.verify.structure+0x250>
     cd4:      	ldr	x19, [sp, #0x40]
     cd8:      	b	0x3f0 <_stogir.verify.structure+0x250>
     cdc:      	mov	x0, x21
     ce0:      	str	x20, [sp, #0x78]
     ce4:      	str	x19, [sp, #0x80]
     ce8:      	ldr	x19, [sp, #0x40]
     cec:      	mov	x21, x23
     cf0:      	str	x24, [sp, #0x60]
     cf4:      	str	x25, [sp, #0x58]
     cf8:      	b	0x27c <_stogir.verify.structure+0xdc>
     cfc:      	mov	x0, x21
     d00:      	str	x20, [sp, #0x78]
     d04:      	str	x19, [sp, #0x80]
     d08:      	ldr	x19, [sp, #0x40]
     d0c:      	ldr	x21, [sp, #0x68]
     d10:      	b	0x240 <_stogir.verify.structure+0xa0>
     d14:      	mov	x0, x21
     d18:      	str	x19, [sp, #0x80]
     d1c:      	ldr	x19, [sp, #0x40]
     d20:      	ldr	x21, [sp, #0x68]
     d24:      	b	0x240 <_stogir.verify.structure+0xa0>
     d28:      	str	x12, [sp, #0x78]
     d2c:      	str	x2, [sp, #0x80]
     d30:      	ldr	x21, [sp, #0x68]
     d34:      	str	x10, [sp, #0xd0]
     d38:      	b	0x4e8 <_stogir.verify.structure+0x348>
     d3c:      	str	x21, [sp, #0xc8]
     d40:      	ldr	x21, [sp, #0x68]
     d44:      	str	x1, [sp, #0xb0]
     d48:      	str	x2, [sp, #0xb8]
     d4c:      	b	0x474 <_stogir.verify.structure+0x2d4>
     d50:      	str	w19, [sp, #0x98]
     d54:      	mov	x19, x0
     d58:      	str	x1, [sp, #0xa0]
     d5c:      	str	x2, [sp, #0xa8]
     d60:      	b	0x538 <_stogir.verify.structure+0x398>
     d64:      	ldr	x12, [sp, #0x78]
     d68:      	ldr	x2, [sp, #0x80]
     d6c:      	b	0x7a8 <_stogir.verify.structure+0x608>
     d70:      	str	x19, [sp, #0x80]
     d74:      	mov	x19, x0
     d78:      	str	x1, [sp, #0x88]
     d7c:      	str	x2, [sp, #0x90]
     d80:      	b	0x868 <_stogir.verify.structure+0x6c8>
     d84:      	ldr	x12, [sp, #0x78]
     d88:      	b	0x758 <_stogir.verify.structure+0x5b8>
     d8c:      	str	x12, [sp, #0x78]
     d90:      	str	x2, [sp, #0x80]
     d94:      	str	x0, [sp, #0x60]
     d98:      	str	x4, [sp, #0x58]
     d9c:      	str	x5, [sp, #0xd8]
     da0:      	str	x10, [sp, #0xd0]
     da4:      	b	0xac8 <_stogir.verify.structure+0x928>
     da8:      	ldr	x21, [sp, #0x68]
     dac:      	b	0xbe4 <_stogir.verify.structure+0xa44>
     db0:      	ldr	x21, [sp, #0x68]
     db4:      	b	0xbd0 <_stogir.verify.structure+0xa30>
     db8:      	ldr	x0, [sp, #0x60]
     dbc:      	ldr	x4, [sp, #0x58]
     dc0:      	b	0xae0 <_stogir.verify.structure+0x940>

0000000000000dc4 <_stogir.verify.integer-operations-target-structured>:
     dc4:      	sub	sp, sp, #0x430
     dc8:      	str	x29, [sp, #0x10]
     dcc:      	str	x30, [sp, #0x18]
     dd0:      	add	x29, sp, #0x10
     dd4:      	str	x19, [sp, #0x3d8]
     dd8:      	str	x20, [sp, #0x3e0]
     ddc:      	str	x21, [sp, #0x3e8]
     de0:      	str	x22, [sp, #0x3f0]
     de4:      	str	x23, [sp, #0x3f8]
     de8:      	str	x24, [sp, #0x400]
     dec:      	str	x25, [sp, #0x408]
     df0:      	str	x26, [sp, #0x410]
     df4:      	str	x27, [sp, #0x418]
     df8:      	str	x28, [sp, #0x420]
     dfc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000dfc:  ARM64_RELOC_PAGE21	l_stogir.322
     e00:      	ldr	x16, [x16]
		0000000000000e00:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     e04:      	orr	x2, x16, xzr
     e08:      	lsr	w19, w1, #0
     e0c:      	lsr	w20, w1, #0
     e10:      	lsr	w21, w1, #0
     e14:      	add	x16, sp, #0x20
     e18:      	orr	x22, x16, xzr
     e1c:      	add	x16, sp, #0x30
     e20:      	orr	x1, x16, xzr
     e24:      	add	x23, x1, #0x8
     e28:      	add	x16, sp, #0x50
     e2c:      	orr	x1, x16, xzr
     e30:      	add	x24, x1, #0x8
     e34:      	add	x16, sp, #0xe0
     e38:      	orr	x1, x16, xzr
     e3c:      	add	x25, x1, #0x8
     e40:      	add	x16, sp, #0x100
     e44:      	orr	x1, x16, xzr
     e48:      	add	x26, x1, #0x8
     e4c:      	add	x16, sp, #0x120
     e50:      	orr	x1, x16, xzr
     e54:      	add	x27, x1, #0x8
     e58:      	add	x16, sp, #0x140
     e5c:      	orr	x1, x16, xzr
     e60:      	add	x28, x1, #0x8
     e64:      	add	x16, sp, #0x160
     e68:      	orr	x1, x16, xzr
     e6c:      	add	x1, x1, #0x8
     e70:      	add	x16, sp, #0x180
     e74:      	orr	x3, x16, xzr
     e78:      	add	x3, x3, #0x8
     e7c:      	add	x16, sp, #0x1a0
     e80:      	orr	x4, x16, xzr
     e84:      	add	x4, x4, #0x8
     e88:      	add	x16, sp, #0x1f0
     e8c:      	orr	x5, x16, xzr
     e90:      	add	x5, x5, #0x8
     e94:      	mov	x7, x2
     e98:      	mov	x2, #0x1                ; =1
     e9c:      	movz	x6, #0x0, lsl #48
     ea0:      	movz	x9, #0x0, lsl #48
     ea4:      	cmp	x9, #0x0
     ea8:      	cset	w10, eq
     eac:      	uxtb	w16, w10
     eb0:      	cmp	w16, wzr
     eb4:      	b.eq	0x2308 <_stogir.verify.integer-operations-target-structured+0x1544>
     eb8:      	ldr	x11, [x0, #0x8]
     ebc:      	cmp	x2, x11
     ec0:      	b.ge	0x231c <_stogir.verify.integer-operations-target-structured+0x1558>
     ec4:      	lsl	x10, x2, #4
     ec8:      	lsl	x11, x2, #2
     ecc:      	ldr	x12, [x0]
     ed0:      	add	x10, x10, x12
     ed4:      	ldr	x12, [x10]
     ed8:      	uxtb	w13, w12
     edc:      	ldr	x10, [x10, #0x8]
     ee0:      	orr	x14, x13, xzr
     ee4:      	add	x16, sp, #0x20
     ee8:      	str	x12, [x16]
     eec:      	add	x16, sp, #0x20
     ef0:      	str	x10, [x16, #0x8]
     ef4:      	ldr	x10, [x0, #0x78]
     ef8:      	add	x10, x11, x10
     efc:      	ldr	w10, [x10]
     f00:      	cmp	x14, #0xe
     f04:      	b.lt	0x18bc <_stogir.verify.integer-operations-target-structured+0xaf8>
     f08:      	cmp	x14, #0x17
     f0c:      	cset	w11, le
     f10:      	ubfx	x11, x11, #0, #8
     f14:      	cmp	x14, #0x1a
     f18:      	b.lt	0x18c4 <_stogir.verify.integer-operations-target-structured+0xb00>
     f1c:      	cmp	x14, #0x1e
     f20:      	b.gt	0x18c4 <_stogir.verify.integer-operations-target-structured+0xb00>
     f24:      	mov	x12, #0x1               ; =1
     f28:      	cmp	x14, #0x1f
     f2c:      	b.ne	0x18fc <_stogir.verify.integer-operations-target-structured+0xb38>
     f30:      	mov	x15, #0x1               ; =1
     f34:      	str	x0, [sp, #0x230]
     f38:      	lsr	w0, w2, #0
     f3c:      	lsr	w10, w10, #0
     f40:      	lsr	w0, w0, #0
     f44:      	str	x8, [sp, #0x258]
     f48:      	str	x4, [sp, #0x288]
     f4c:      	str	x5, [sp, #0x268]
     f50:      	str	x2, [sp, #0x260]
     f54:      	mov	x2, x22
     f58:      	str	x7, [sp, #0x270]
     f5c:      	str	x9, [sp, #0x278]
     f60:      	str	w13, [sp, #0x280]
     f64:      	str	w10, [sp, #0x290]
     f68:      	str	x11, [sp, #0x298]
     f6c:      	str	x12, [sp, #0x2a0]
     f70:      	str	x15, [sp, #0x2a8]
     f74:      	str	w0, [sp, #0x2b0]
     f78:      	str	w19, [sp, #0x238]
     f7c:      	mov	x19, x6
     f80:      	str	w20, [sp, #0x240]
     f84:      	mov	x20, x1
     f88:      	mov	w1, w0
     f8c:      	ldr	x0, [sp, #0x230]
     f90:      	str	w21, [sp, #0x248]
     f94:      	mov	x21, x3
     f98:      	mov	w3, w10
     f9c:      	str	x22, [sp, #0x250]
     fa0:      	mov	x22, x14
     fa4:      	bl	0xfa4 <_stogir.verify.integer-operations-target-structured+0x1e0>
		0000000000000fa4:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
     fa8:      	uxtb	w1, w0
     fac:      	cmp	x1, #0x0
     fb0:      	cset	w1, ne
     fb4:      	cmp	x22, #0x3d
     fb8:      	b.lt	0x195c <_stogir.verify.integer-operations-target-structured+0xb98>
     fbc:      	cmp	x22, #0x3f
     fc0:      	b.gt	0x195c <_stogir.verify.integer-operations-target-structured+0xb98>
     fc4:      	add	x8, sp, #0x30
     fc8:      	ldr	w2, [sp, #0x238]
     fcc:      	str	x0, [sp, #0x2b8]
     fd0:      	ldr	x0, [sp, #0x230]
     fd4:      	str	x21, [sp, #0x2c0]
     fd8:      	mov	w21, w1
     fdc:      	ldr	w1, [sp, #0x2b0]
     fe0:      	bl	0xfe0 <_stogir.verify.integer-operations-target-structured+0x21c>
		0000000000000fe0:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
     fe4:      	add	x16, sp, #0x30
     fe8:      	ldr	w0, [x16]
     fec:      	lsr	x16, x0, #0
     ff0:      	cmp	x16, #0x1
     ff4:      	b.eq	0x1010 <_stogir.verify.integer-operations-target-structured+0x24c>
     ff8:      	b.lo	0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
     ffc:      	b	0x1014 <_stogir.verify.integer-operations-target-structured+0x250>
    1000:      	cmp	x16, #0x0
    1004:      	b.eq	0x100c <_stogir.verify.integer-operations-target-structured+0x248>
    1008:      	b	0x1014 <_stogir.verify.integer-operations-target-structured+0x250>
    100c:      	b	0x1980 <_stogir.verify.integer-operations-target-structured+0xbbc>
    1010:      	b	0x1018 <_stogir.verify.integer-operations-target-structured+0x254>
    1014:      	b	0x228c <_stogir.verify.integer-operations-target-structured+0x14c8>
    1018:      	add	x16, sp, #0x30
    101c:      	ldr	x0, [x16, #0x8]
    1020:      	ldr	x1, [x23, #0x8]
    1024:      	mov	x2, x1
    1028:      	mov	x1, x0
    102c:      	mov	x0, x19
    1030:      	mov	x19, x0
    1034:      	mov	x0, x1
    1038:      	mov	x1, x2
    103c:      	cmp	x22, #0x44
    1040:      	b.ne	0x19a8 <_stogir.verify.integer-operations-target-structured+0xbe4>
    1044:      	uxtb	w16, w21
    1048:      	cmp	w16, wzr
    104c:      	b.eq	0x1998 <_stogir.verify.integer-operations-target-structured+0xbd4>
    1050:      	mov	x2, x1
    1054:      	mov	x1, x0
    1058:      	movz	x0, #0x0, lsl #48
    105c:      	cmp	x0, #0x0
    1060:      	b.eq	0x2330 <_stogir.verify.integer-operations-target-structured+0x156c>
    1064:      	add	x8, sp, #0x50
    1068:      	ldr	x0, [sp, #0x230]
    106c:      	str	x1, [sp, #0x2c8]
    1070:      	ldr	w1, [sp, #0x2b0]
    1074:      	str	x2, [sp, #0x2d0]
    1078:      	bl	0x1078 <_stogir.verify.integer-operations-target-structured+0x2b4>
		0000000000001078:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    107c:      	add	x16, sp, #0x50
    1080:      	ldr	w0, [x16]
    1084:      	lsr	x16, x0, #0
    1088:      	cmp	x16, #0x1
    108c:      	b.eq	0x10a8 <_stogir.verify.integer-operations-target-structured+0x2e4>
    1090:      	b.lo	0x1098 <_stogir.verify.integer-operations-target-structured+0x2d4>
    1094:      	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x2e8>
    1098:      	cmp	x16, #0x0
    109c:      	b.eq	0x10a4 <_stogir.verify.integer-operations-target-structured+0x2e0>
    10a0:      	b	0x10ac <_stogir.verify.integer-operations-target-structured+0x2e8>
    10a4:      	b	0x19b8 <_stogir.verify.integer-operations-target-structured+0xbf4>
    10a8:      	b	0x10b0 <_stogir.verify.integer-operations-target-structured+0x2ec>
    10ac:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc0c>
    10b0:      	add	x16, sp, #0x50
    10b4:      	ldr	x0, [x16, #0x8]
    10b8:      	ldr	x1, [x24, #0x8]
    10bc:      	mov	x2, x1
    10c0:      	mov	x1, x0
    10c4:      	mov	x0, x19
    10c8:      	mov	x19, x0
    10cc:      	mov	x0, x1
    10d0:      	mov	x1, x2
    10d4:      	cmp	x22, #0x1d
    10d8:      	b.ne	0x19e4 <_stogir.verify.integer-operations-target-structured+0xc20>
    10dc:      	mov	x2, x1
    10e0:      	mov	x1, x0
    10e4:      	mov	x0, #0x1                ; =1
    10e8:      	cmp	x0, #0x0
    10ec:      	b.eq	0x1a0c <_stogir.verify.integer-operations-target-structured+0xc48>
    10f0:      	add	x16, sp, #0x20
    10f4:      	ldr	w0, [x16, #0xc]
    10f8:      	sxtw	x0, w0
    10fc:      	cmp	x0, #0x0
    1100:      	b.ne	0x1a04 <_stogir.verify.integer-operations-target-structured+0xc40>
    1104:      	movz	x0, #0x0, lsl #48
    1108:      	cmp	x0, #0x0
    110c:      	b.eq	0x233c <_stogir.verify.integer-operations-target-structured+0x1578>
    1110:      	add	x16, sp, #0x20
    1114:      	ldr	w0, [x16, #0xc]
    1118:      	lsr	w0, w0, #0
    111c:      	add	x8, sp, #0x70
    1120:      	str	x1, [sp, #0x2d8]
    1124:      	mov	w1, w0
    1128:      	ldr	x0, [sp, #0x230]
    112c:      	str	x2, [sp, #0x2e0]
    1130:      	bl	0x1130 <_stogir.verify.integer-operations-target-structured+0x36c>
		0000000000001130:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1134:      	add	x16, sp, #0x70
    1138:      	ldr	w0, [x16]
    113c:      	lsr	x16, x0, #0
    1140:      	cmp	x16, #0x1
    1144:      	b.eq	0x1160 <_stogir.verify.integer-operations-target-structured+0x39c>
    1148:      	b.lo	0x1150 <_stogir.verify.integer-operations-target-structured+0x38c>
    114c:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x3a0>
    1150:      	cmp	x16, #0x0
    1154:      	b.eq	0x115c <_stogir.verify.integer-operations-target-structured+0x398>
    1158:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x3a0>
    115c:      	b	0x1168 <_stogir.verify.integer-operations-target-structured+0x3a4>
    1160:      	b	0x1a14 <_stogir.verify.integer-operations-target-structured+0xc50>
    1164:      	b	0x1adc <_stogir.verify.integer-operations-target-structured+0xd18>
    1168:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001168:  ARM64_RELOC_PAGE21	l_stogir.323
    116c:      	ldr	x16, [x16]
		000000000000116c:  ARM64_RELOC_PAGEOFF12	l_stogir.323
    1170:      	orr	x0, x16, xzr
    1174:      	mov	x1, #0x16               ; =22
    1178:      	cmp	x22, #0x29
    117c:      	b.lt	0x1af0 <_stogir.verify.integer-operations-target-structured+0xd2c>
    1180:      	cmp	x22, #0x2b
    1184:      	cset	w2, le
    1188:      	ubfx	x2, x2, #0, #8
    118c:      	fmov	d31, x0
    1190:      	mov	x0, x2
    1194:      	mov	x2, x1
    1198:      	fmov	x1, d31
    119c:      	cmp	x22, #0x2c
    11a0:      	cset	w3, eq
    11a4:      	cmp	x0, #0x0
    11a8:      	b.eq	0x1b00 <_stogir.verify.integer-operations-target-structured+0xd3c>
    11ac:      	mov	x0, #0x1                ; =1
    11b0:      	cmp	x0, #0x0
    11b4:      	b.eq	0x2348 <_stogir.verify.integer-operations-target-structured+0x1584>
    11b8:      	uxtb	w16, w3
    11bc:      	cmp	w16, wzr
    11c0:      	b.eq	0x2354 <_stogir.verify.integer-operations-target-structured+0x1590>
    11c4:      	add	x8, sp, #0xa0
    11c8:      	ldr	x0, [sp, #0x230]
    11cc:      	str	x1, [sp, #0x2e8]
    11d0:      	ldr	w1, [sp, #0x2b0]
    11d4:      	str	x2, [sp, #0x2f0]
    11d8:      	bl	0x11d8 <_stogir.verify.integer-operations-target-structured+0x414>
		00000000000011d8:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    11dc:      	add	x16, sp, #0xa0
    11e0:      	ldr	x0, [x16]
    11e4:      	add	x16, sp, #0xa0
    11e8:      	ldr	x1, [x16, #0x8]
    11ec:      	add	x16, sp, #0xa0
    11f0:      	ldr	x2, [x16, #0x10]
    11f4:      	mov	x3, x1
    11f8:      	ldr	x1, [sp, #0x2f0]
    11fc:      	mov	x4, x2
    1200:      	mov	x2, x0
    1204:      	ldr	x0, [sp, #0x2e8]
    1208:      	lsr	w2, w2, #0
    120c:      	lsr	x16, x2, #0
    1210:      	cmp	x16, #0x1
    1214:      	b.eq	0x1230 <_stogir.verify.integer-operations-target-structured+0x46c>
    1218:      	b.lo	0x1220 <_stogir.verify.integer-operations-target-structured+0x45c>
    121c:      	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x470>
    1220:      	cmp	x16, #0x0
    1224:      	b.eq	0x122c <_stogir.verify.integer-operations-target-structured+0x468>
    1228:      	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x470>
    122c:      	b	0x1b48 <_stogir.verify.integer-operations-target-structured+0xd84>
    1230:      	b	0x1238 <_stogir.verify.integer-operations-target-structured+0x474>
    1234:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xda4>
    1238:      	mov	x0, x19
    123c:      	mov	x1, x3
    1240:      	mov	x2, x4
    1244:      	mov	x19, x0
    1248:      	mov	x0, x1
    124c:      	mov	x1, x2
    1250:      	cmp	x22, #0x7e
    1254:      	b.lt	0x1b7c <_stogir.verify.integer-operations-target-structured+0xdb8>
    1258:      	cmp	x22, #0x82
    125c:      	cset	w2, le
    1260:      	ubfx	x2, x2, #0, #8
    1264:      	fmov	d31, x0
    1268:      	mov	x0, x2
    126c:      	mov	x2, x1
    1270:      	fmov	x1, d31
    1274:      	cmp	x0, #0x0
    1278:      	b.eq	0x2360 <_stogir.verify.integer-operations-target-structured+0x159c>
    127c:      	add	x8, sp, #0xe0
    1280:      	ldr	x0, [sp, #0x230]
    1284:      	str	x1, [sp, #0x2f8]
    1288:      	ldr	w1, [sp, #0x2b0]
    128c:      	str	x2, [sp, #0x300]
    1290:      	bl	0x1290 <_stogir.verify.integer-operations-target-structured+0x4cc>
		0000000000001290:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    1294:      	add	x16, sp, #0xe0
    1298:      	ldr	w0, [x16]
    129c:      	lsr	x16, x0, #0
    12a0:      	cmp	x16, #0x1
    12a4:      	b.eq	0x12c0 <_stogir.verify.integer-operations-target-structured+0x4fc>
    12a8:      	b.lo	0x12b0 <_stogir.verify.integer-operations-target-structured+0x4ec>
    12ac:      	b	0x12c4 <_stogir.verify.integer-operations-target-structured+0x500>
    12b0:      	cmp	x16, #0x0
    12b4:      	b.eq	0x12bc <_stogir.verify.integer-operations-target-structured+0x4f8>
    12b8:      	b	0x12c4 <_stogir.verify.integer-operations-target-structured+0x500>
    12bc:      	b	0x1b8c <_stogir.verify.integer-operations-target-structured+0xdc8>
    12c0:      	b	0x12c8 <_stogir.verify.integer-operations-target-structured+0x504>
    12c4:      	b	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xde0>
    12c8:      	add	x16, sp, #0xe0
    12cc:      	ldr	x0, [x16, #0x8]
    12d0:      	ldr	x1, [x25, #0x8]
    12d4:      	mov	x2, x1
    12d8:      	mov	x1, x0
    12dc:      	mov	x0, x19
    12e0:      	mov	x19, x0
    12e4:      	mov	x0, x1
    12e8:      	mov	x1, x2
    12ec:      	cmp	x22, #0x60
    12f0:      	b.ne	0x1bb8 <_stogir.verify.integer-operations-target-structured+0xdf4>
    12f4:      	mov	x2, x1
    12f8:      	mov	x1, x0
    12fc:      	mov	x0, #0x1                ; =1
    1300:      	cmp	x0, #0x0
    1304:      	b.eq	0x236c <_stogir.verify.integer-operations-target-structured+0x15a8>
    1308:      	add	x8, sp, #0x100
    130c:      	ldr	x0, [sp, #0x230]
    1310:      	str	x1, [sp, #0x308]
    1314:      	ldr	w1, [sp, #0x2b0]
    1318:      	str	x2, [sp, #0x310]
    131c:      	bl	0x131c <_stogir.verify.integer-operations-target-structured+0x558>
		000000000000131c:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1320:      	add	x16, sp, #0x100
    1324:      	ldr	w0, [x16]
    1328:      	lsr	x16, x0, #0
    132c:      	cmp	x16, #0x1
    1330:      	b.eq	0x134c <_stogir.verify.integer-operations-target-structured+0x588>
    1334:      	b.lo	0x133c <_stogir.verify.integer-operations-target-structured+0x578>
    1338:      	b	0x1350 <_stogir.verify.integer-operations-target-structured+0x58c>
    133c:      	cmp	x16, #0x0
    1340:      	b.eq	0x1348 <_stogir.verify.integer-operations-target-structured+0x584>
    1344:      	b	0x1350 <_stogir.verify.integer-operations-target-structured+0x58c>
    1348:      	b	0x1bd8 <_stogir.verify.integer-operations-target-structured+0xe14>
    134c:      	b	0x1354 <_stogir.verify.integer-operations-target-structured+0x590>
    1350:      	b	0x1bf0 <_stogir.verify.integer-operations-target-structured+0xe2c>
    1354:      	add	x16, sp, #0x100
    1358:      	ldr	x0, [x16, #0x8]
    135c:      	ldr	x1, [x26, #0x8]
    1360:      	mov	x2, x1
    1364:      	mov	x1, x0
    1368:      	mov	x0, x19
    136c:      	mov	x19, x0
    1370:      	mov	x0, x1
    1374:      	mov	x1, x2
    1378:      	cmp	x22, #0x75
    137c:      	b.ne	0x1c04 <_stogir.verify.integer-operations-target-structured+0xe40>
    1380:      	mov	x2, x1
    1384:      	mov	x1, x0
    1388:      	mov	x0, #0x1                ; =1
    138c:      	cmp	x0, #0x0
    1390:      	b.eq	0x2378 <_stogir.verify.integer-operations-target-structured+0x15b4>
    1394:      	add	x8, sp, #0x120
    1398:      	ldr	x0, [sp, #0x230]
    139c:      	str	x1, [sp, #0x318]
    13a0:      	ldr	w1, [sp, #0x2b0]
    13a4:      	str	x2, [sp, #0x320]
    13a8:      	bl	0x13a8 <_stogir.verify.integer-operations-target-structured+0x5e4>
		00000000000013a8:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    13ac:      	add	x16, sp, #0x120
    13b0:      	ldr	w0, [x16]
    13b4:      	lsr	x16, x0, #0
    13b8:      	cmp	x16, #0x1
    13bc:      	b.eq	0x13d8 <_stogir.verify.integer-operations-target-structured+0x614>
    13c0:      	b.lo	0x13c8 <_stogir.verify.integer-operations-target-structured+0x604>
    13c4:      	b	0x13dc <_stogir.verify.integer-operations-target-structured+0x618>
    13c8:      	cmp	x16, #0x0
    13cc:      	b.eq	0x13d4 <_stogir.verify.integer-operations-target-structured+0x610>
    13d0:      	b	0x13dc <_stogir.verify.integer-operations-target-structured+0x618>
    13d4:      	b	0x1c34 <_stogir.verify.integer-operations-target-structured+0xe70>
    13d8:      	b	0x13e0 <_stogir.verify.integer-operations-target-structured+0x61c>
    13dc:      	b	0x1c4c <_stogir.verify.integer-operations-target-structured+0xe88>
    13e0:      	add	x16, sp, #0x120
    13e4:      	ldr	x0, [x16, #0x8]
    13e8:      	ldr	x1, [x27, #0x8]
    13ec:      	mov	x2, x1
    13f0:      	mov	x1, x0
    13f4:      	mov	x0, x19
    13f8:      	mov	x19, x0
    13fc:      	mov	x0, x1
    1400:      	mov	x1, x2
    1404:      	cmp	x22, #0x42
    1408:      	b.ne	0x1c60 <_stogir.verify.integer-operations-target-structured+0xe9c>
    140c:      	mov	x2, x1
    1410:      	mov	x1, x0
    1414:      	mov	x0, #0x1                ; =1
    1418:      	cmp	x0, #0x0
    141c:      	b.eq	0x2384 <_stogir.verify.integer-operations-target-structured+0x15c0>
    1420:      	add	x8, sp, #0x140
    1424:      	ldr	x0, [sp, #0x230]
    1428:      	str	x1, [sp, #0x328]
    142c:      	ldr	w1, [sp, #0x2b0]
    1430:      	str	x2, [sp, #0x330]
    1434:      	bl	0x1434 <_stogir.verify.integer-operations-target-structured+0x670>
		0000000000001434:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    1438:      	add	x16, sp, #0x140
    143c:      	ldr	w0, [x16]
    1440:      	lsr	x16, x0, #0
    1444:      	cmp	x16, #0x1
    1448:      	b.eq	0x1464 <_stogir.verify.integer-operations-target-structured+0x6a0>
    144c:      	b.lo	0x1454 <_stogir.verify.integer-operations-target-structured+0x690>
    1450:      	b	0x1468 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1454:      	cmp	x16, #0x0
    1458:      	b.eq	0x1460 <_stogir.verify.integer-operations-target-structured+0x69c>
    145c:      	b	0x1468 <_stogir.verify.integer-operations-target-structured+0x6a4>
    1460:      	b	0x1cb0 <_stogir.verify.integer-operations-target-structured+0xeec>
    1464:      	b	0x146c <_stogir.verify.integer-operations-target-structured+0x6a8>
    1468:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xf04>
    146c:      	add	x16, sp, #0x140
    1470:      	ldr	x0, [x16, #0x8]
    1474:      	ldr	x1, [x28, #0x8]
    1478:      	mov	x2, x1
    147c:      	mov	x1, x0
    1480:      	mov	x0, x19
    1484:      	mov	x19, x0
    1488:      	mov	x0, x1
    148c:      	mov	x1, x2
    1490:      	cmp	x22, #0x41
    1494:      	b.ne	0x1cdc <_stogir.verify.integer-operations-target-structured+0xf18>
    1498:      	mov	x2, x1
    149c:      	mov	x1, x0
    14a0:      	mov	x0, #0x1                ; =1
    14a4:      	cmp	x0, #0x0
    14a8:      	b.eq	0x2390 <_stogir.verify.integer-operations-target-structured+0x15cc>
    14ac:      	add	x8, sp, #0x160
    14b0:      	ldr	x0, [sp, #0x230]
    14b4:      	str	x1, [sp, #0x338]
    14b8:      	ldr	w1, [sp, #0x2b0]
    14bc:      	str	x2, [sp, #0x340]
    14c0:      	ldr	w2, [sp, #0x240]
    14c4:      	bl	0x14c4 <_stogir.verify.integer-operations-target-structured+0x700>
		00000000000014c4:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    14c8:      	add	x16, sp, #0x160
    14cc:      	ldr	w0, [x16]
    14d0:      	lsr	x16, x0, #0
    14d4:      	cmp	x16, #0x1
    14d8:      	b.eq	0x14f4 <_stogir.verify.integer-operations-target-structured+0x730>
    14dc:      	b.lo	0x14e4 <_stogir.verify.integer-operations-target-structured+0x720>
    14e0:      	b	0x14f8 <_stogir.verify.integer-operations-target-structured+0x734>
    14e4:      	cmp	x16, #0x0
    14e8:      	b.eq	0x14f0 <_stogir.verify.integer-operations-target-structured+0x72c>
    14ec:      	b	0x14f8 <_stogir.verify.integer-operations-target-structured+0x734>
    14f0:      	b	0x1d1c <_stogir.verify.integer-operations-target-structured+0xf58>
    14f4:      	b	0x14fc <_stogir.verify.integer-operations-target-structured+0x738>
    14f8:      	b	0x1d34 <_stogir.verify.integer-operations-target-structured+0xf70>
    14fc:      	add	x16, sp, #0x160
    1500:      	ldr	x0, [x16, #0x8]
    1504:      	ldr	x1, [x20, #0x8]
    1508:      	mov	x2, x1
    150c:      	mov	x1, x0
    1510:      	mov	x0, x19
    1514:      	mov	x19, x0
    1518:      	mov	x0, x1
    151c:      	mov	x1, x2
    1520:      	cmp	x22, #0x21
    1524:      	b.lt	0x1d48 <_stogir.verify.integer-operations-target-structured+0xf84>
    1528:      	cmp	x22, #0x27
    152c:      	cset	w2, le
    1530:      	ubfx	x2, x2, #0, #8
    1534:      	fmov	d31, x0
    1538:      	mov	x0, x2
    153c:      	mov	x2, x1
    1540:      	fmov	x1, d31
    1544:      	cmp	x0, #0x0
    1548:      	b.eq	0x239c <_stogir.verify.integer-operations-target-structured+0x15d8>
    154c:      	add	x8, sp, #0x180
    1550:      	ldr	x0, [sp, #0x230]
    1554:      	str	x1, [sp, #0x348]
    1558:      	ldr	w1, [sp, #0x2b0]
    155c:      	str	x2, [sp, #0x350]
    1560:      	ldr	w2, [sp, #0x248]
    1564:      	bl	0x1564 <_stogir.verify.integer-operations-target-structured+0x7a0>
		0000000000001564:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    1568:      	add	x16, sp, #0x180
    156c:      	ldr	w0, [x16]
    1570:      	lsr	x16, x0, #0
    1574:      	cmp	x16, #0x1
    1578:      	b.eq	0x1598 <_stogir.verify.integer-operations-target-structured+0x7d4>
    157c:      	b.lo	0x1584 <_stogir.verify.integer-operations-target-structured+0x7c0>
    1580:      	b	0x159c <_stogir.verify.integer-operations-target-structured+0x7d8>
    1584:      	cmp	x16, #0x0
    1588:      	b.eq	0x1590 <_stogir.verify.integer-operations-target-structured+0x7cc>
    158c:      	b	0x159c <_stogir.verify.integer-operations-target-structured+0x7d8>
    1590:      	ldr	x1, [sp, #0x2c0]
    1594:      	b	0x1d58 <_stogir.verify.integer-operations-target-structured+0xf94>
    1598:      	b	0x15a0 <_stogir.verify.integer-operations-target-structured+0x7dc>
    159c:      	b	0x1d70 <_stogir.verify.integer-operations-target-structured+0xfac>
    15a0:      	add	x16, sp, #0x180
    15a4:      	ldr	x0, [x16, #0x8]
    15a8:      	ldr	x1, [sp, #0x2c0]
    15ac:      	ldr	x2, [x1, #0x8]
    15b0:      	mov	x3, x2
    15b4:      	mov	x2, x0
    15b8:      	mov	x0, x19
    15bc:      	mov	x19, x0
    15c0:      	mov	x0, x2
    15c4:      	mov	x2, x3
    15c8:      	cmp	x22, #0x3c
    15cc:      	b.ne	0x23ac <_stogir.verify.integer-operations-target-structured+0x15e8>
    15d0:      	add	x8, sp, #0x1a0
    15d4:      	str	x1, [sp, #0x2c0]
    15d8:      	ldr	w1, [sp, #0x2b0]
    15dc:      	str	x0, [sp, #0x358]
    15e0:      	ldr	x0, [sp, #0x230]
    15e4:      	str	x2, [sp, #0x360]
    15e8:      	bl	0x15e8 <_stogir.verify.integer-operations-target-structured+0x824>
		00000000000015e8:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    15ec:      	add	x16, sp, #0x1a0
    15f0:      	ldr	w0, [x16]
    15f4:      	lsr	x16, x0, #0
    15f8:      	cmp	x16, #0x1
    15fc:      	b.eq	0x161c <_stogir.verify.integer-operations-target-structured+0x858>
    1600:      	b.lo	0x1608 <_stogir.verify.integer-operations-target-structured+0x844>
    1604:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0x85c>
    1608:      	cmp	x16, #0x0
    160c:      	b.eq	0x1614 <_stogir.verify.integer-operations-target-structured+0x850>
    1610:      	b	0x1620 <_stogir.verify.integer-operations-target-structured+0x85c>
    1614:      	ldr	x1, [sp, #0x288]
    1618:      	b	0x1d84 <_stogir.verify.integer-operations-target-structured+0xfc0>
    161c:      	b	0x1624 <_stogir.verify.integer-operations-target-structured+0x860>
    1620:      	b	0x1d9c <_stogir.verify.integer-operations-target-structured+0xfd8>
    1624:      	add	x16, sp, #0x1a0
    1628:      	ldr	x0, [x16, #0x8]
    162c:      	ldr	x1, [sp, #0x288]
    1630:      	ldr	x2, [x1, #0x8]
    1634:      	mov	x3, x2
    1638:      	mov	x2, x0
    163c:      	mov	x0, x19
    1640:      	mov	x19, x0
    1644:      	mov	x0, x2
    1648:      	mov	x2, x3
    164c:      	cmp	x22, #0x78
    1650:      	b.ne	0x23c0 <_stogir.verify.integer-operations-target-structured+0x15fc>
    1654:      	add	x16, sp, #0x20
    1658:      	ldr	w3, [x16]
    165c:      	ubfx	x3, x3, #8, #8
    1660:      	cmp	x3, #0x0
    1664:      	b.ne	0x1dcc <_stogir.verify.integer-operations-target-structured+0x1008>
    1668:      	add	x16, sp, #0x20
    166c:      	ldr	w3, [x16, #0x8]
    1670:      	sxtw	x3, w3
    1674:      	cmp	x3, #0x0
    1678:      	b.ne	0x1db0 <_stogir.verify.integer-operations-target-structured+0xfec>
    167c:      	mov	x3, x2
    1680:      	mov	x2, x0
    1684:      	movz	x0, #0x0, lsl #48
    1688:      	cmp	x0, #0x0
    168c:      	b.eq	0x1dc0 <_stogir.verify.integer-operations-target-structured+0xffc>
    1690:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001690:  ARM64_RELOC_PAGE21	l_stogir.324
    1694:      	ldr	x16, [x16]
		0000000000001694:  ARM64_RELOC_PAGEOFF12	l_stogir.324
    1698:      	orr	x0, x16, xzr
    169c:      	mov	x2, #0x1f               ; =31
    16a0:      	str	x1, [sp, #0x288]
    16a4:      	mov	x1, x2
    16a8:      	add	x2, x19, #0x1
    16ac:      	lsr	w2, w2, #0
    16b0:      	sxtw	x2, w2
    16b4:      	mov	x19, x2
    16b8:      	ldr	x2, [sp, #0x2b8]
    16bc:      	uxth	w2, w2
    16c0:      	mov	w17, #0x8               ; =8
    16c4:      	uxth	w16, w2
    16c8:      	ubfx	w17, w17, #0, #4
    16cc:      	lsr	w2, w16, w17
    16d0:      	uxth	w2, w2
    16d4:      	uxtb	w2, w2
    16d8:      	cmp	x2, #0x0
    16dc:      	b.eq	0x23d0 <_stogir.verify.integer-operations-target-structured+0x160c>
    16e0:      	add	x8, sp, #0x1f0
    16e4:      	str	x0, [sp, #0x378]
    16e8:      	ldr	x0, [sp, #0x230]
    16ec:      	str	x1, [sp, #0x380]
    16f0:      	ldr	w1, [sp, #0x2b0]
    16f4:      	str	x20, [sp, #0x388]
    16f8:      	mov	x20, x2
    16fc:      	bl	0x16fc <_stogir.verify.integer-operations-target-structured+0x938>
		00000000000016fc:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    1700:      	add	x16, sp, #0x1f0
    1704:      	ldr	w0, [x16]
    1708:      	lsr	x16, x0, #0
    170c:      	cmp	x16, #0x1
    1710:      	b.eq	0x1730 <_stogir.verify.integer-operations-target-structured+0x96c>
    1714:      	b.lo	0x171c <_stogir.verify.integer-operations-target-structured+0x958>
    1718:      	b	0x1734 <_stogir.verify.integer-operations-target-structured+0x970>
    171c:      	cmp	x16, #0x0
    1720:      	b.eq	0x1728 <_stogir.verify.integer-operations-target-structured+0x964>
    1724:      	b	0x1734 <_stogir.verify.integer-operations-target-structured+0x970>
    1728:      	ldr	x1, [sp, #0x268]
    172c:      	b	0x1e94 <_stogir.verify.integer-operations-target-structured+0x10d0>
    1730:      	b	0x1738 <_stogir.verify.integer-operations-target-structured+0x974>
    1734:      	b	0x1eac <_stogir.verify.integer-operations-target-structured+0x10e8>
    1738:      	add	x16, sp, #0x1f0
    173c:      	ldr	x0, [x16, #0x8]
    1740:      	ldr	x1, [sp, #0x268]
    1744:      	ldr	x2, [x1, #0x8]
    1748:      	mov	x3, x2
    174c:      	mov	x2, x0
    1750:      	mov	x0, x19
    1754:      	mov	x19, x0
    1758:      	mov	x0, x2
    175c:      	mov	x2, x3
    1760:      	uxtb	w16, w21
    1764:      	cmp	w16, wzr
    1768:      	b.eq	0x1ec0 <_stogir.verify.integer-operations-target-structured+0x10fc>
    176c:      	mov	x3, x2
    1770:      	mov	x2, x0
    1774:      	movz	x0, #0x0, lsl #48
    1778:      	cmp	x0, #0x0
    177c:      	b.eq	0x23e8 <_stogir.verify.integer-operations-target-structured+0x1624>
    1780:      	cmp	x20, #0x0
    1784:      	b.eq	0x1ed0 <_stogir.verify.integer-operations-target-structured+0x110c>
    1788:      	movz	x0, #0x0, lsl #48
    178c:      	cmp	x0, #0x0
    1790:      	b.eq	0x23f4 <_stogir.verify.integer-operations-target-structured+0x1630>
    1794:      	ldr	x20, [sp, #0x298]
    1798:      	cmp	x20, #0x0
    179c:      	b.eq	0x1ed8 <_stogir.verify.integer-operations-target-structured+0x1114>
    17a0:      	ldr	x21, [sp, #0x2a0]
    17a4:      	mov	x0, #0x1                ; =1
    17a8:      	cmp	x0, #0x0
    17ac:      	b.eq	0x2400 <_stogir.verify.integer-operations-target-structured+0x163c>
    17b0:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		00000000000017b0:  ARM64_RELOC_PAGE21	l_stogir.325
    17b4:      	ldr	x16, [x16]
		00000000000017b4:  ARM64_RELOC_PAGEOFF12	l_stogir.325
    17b8:      	orr	x0, x16, xzr
    17bc:      	add	x16, sp, #0x210
    17c0:      	str	x16, [sp]
    17c4:      	str	x1, [sp, #0x268]
    17c8:      	ldr	w1, [sp, #0x2b0]
    17cc:      	str	x2, [sp, #0x390]
    17d0:      	str	x3, [sp, #0x398]
    17d4:      	str	x0, [sp, #0x3a0]
    17d8:      	ldr	x0, [sp, #0x230]
    17dc:      	mov	x2, #0x1                ; =1
    17e0:      	bl	0x17e0 <_stogir.verify.integer-operations-target-structured+0xa1c>
		00000000000017e0:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    17e4:      	ldr	x16, [sp]
    17e8:      	str	x0, [x16]
    17ec:      	str	x1, [x16, #0x8]
    17f0:      	add	x16, sp, #0x210
    17f4:      	ldr	x0, [x16]
    17f8:      	add	x16, sp, #0x210
    17fc:      	ldr	x1, [x16, #0x8]
    1800:      	lsr	w0, w0, #0
    1804:      	lsr	x16, x0, #0
    1808:      	cmp	x16, #0x1
    180c:      	b.eq	0x1828 <_stogir.verify.integer-operations-target-structured+0xa64>
    1810:      	b.lo	0x1818 <_stogir.verify.integer-operations-target-structured+0xa54>
    1814:      	b	0x182c <_stogir.verify.integer-operations-target-structured+0xa68>
    1818:      	cmp	x16, #0x0
    181c:      	b.eq	0x1824 <_stogir.verify.integer-operations-target-structured+0xa60>
    1820:      	b	0x182c <_stogir.verify.integer-operations-target-structured+0xa68>
    1824:      	b	0x1830 <_stogir.verify.integer-operations-target-structured+0xa6c>
    1828:      	b	0x1f04 <_stogir.verify.integer-operations-target-structured+0x1140>
    182c:      	b	0x2274 <_stogir.verify.integer-operations-target-structured+0x14b0>
    1830:      	str	x23, [sp, #0x3a8]
    1834:      	ldr	x0, [sp, #0x3a0]
    1838:      	mov	x1, #0x17               ; =23
    183c:      	add	x2, x19, #0x1
    1840:      	lsr	w2, w2, #0
    1844:      	sxtw	x2, w2
    1848:      	fmov	d31, x0
    184c:      	mov	x0, x2
    1850:      	mov	x2, x1
    1854:      	fmov	x1, d31
    1858:      	ldr	w3, [sp, #0x290]
    185c:      	sxtw	x3, w3
    1860:      	add	x3, x3, #0x4
    1864:      	asr	x16, x3, #63
    1868:      	lsr	x16, x16, #62
    186c:      	add	x3, x3, x16
    1870:      	asr	x3, x3, #2
    1874:      	ldr	x4, [sp, #0x260]
    1878:      	add	x3, x3, x4
    187c:      	ldr	x8, [sp, #0x258]
    1880:      	ldr	x22, [sp, #0x250]
    1884:      	ldr	w19, [sp, #0x238]
    1888:      	ldr	x23, [sp, #0x3a8]
    188c:      	ldr	w20, [sp, #0x240]
    1890:      	ldr	w21, [sp, #0x248]
    1894:      	ldr	x4, [sp, #0x288]
    1898:      	ldr	x5, [sp, #0x268]
    189c:      	mov	x6, x0
    18a0:      	ldr	x0, [sp, #0x230]
    18a4:      	mov	x7, x1
    18a8:      	ldr	x1, [sp, #0x388]
    18ac:      	mov	x9, x2
    18b0:      	mov	x2, x3
    18b4:      	ldr	x3, [sp, #0x2c0]
    18b8:      	b	0xea4 <_stogir.verify.integer-operations-target-structured+0xe0>
    18bc:      	movz	x11, #0x0, lsl #48
    18c0:      	b	0xf14 <_stogir.verify.integer-operations-target-structured+0x150>
    18c4:      	cmp	x14, #0x2e
    18c8:      	b.lt	0x18dc <_stogir.verify.integer-operations-target-structured+0xb18>
    18cc:      	cmp	x14, #0x35
    18d0:      	b.gt	0x18dc <_stogir.verify.integer-operations-target-structured+0xb18>
    18d4:      	mov	x12, #0x1               ; =1
    18d8:      	b	0xf28 <_stogir.verify.integer-operations-target-structured+0x164>
    18dc:      	cmp	x14, #0x3a
    18e0:      	b.ne	0x18ec <_stogir.verify.integer-operations-target-structured+0xb28>
    18e4:      	mov	x12, #0x1               ; =1
    18e8:      	b	0x18d8 <_stogir.verify.integer-operations-target-structured+0xb14>
    18ec:      	cmp	x14, #0x3b
    18f0:      	cset	w12, eq
    18f4:      	ubfx	x12, x12, #0, #8
    18f8:      	b	0x18e8 <_stogir.verify.integer-operations-target-structured+0xb24>
    18fc:      	cmp	x14, #0x20
    1900:      	b.ne	0x190c <_stogir.verify.integer-operations-target-structured+0xb48>
    1904:      	mov	x15, #0x1               ; =1
    1908:      	b	0xf34 <_stogir.verify.integer-operations-target-structured+0x170>
    190c:      	cmp	x14, #0x2d
    1910:      	b.ne	0x191c <_stogir.verify.integer-operations-target-structured+0xb58>
    1914:      	mov	x15, #0x1               ; =1
    1918:      	b	0x1908 <_stogir.verify.integer-operations-target-structured+0xb44>
    191c:      	cmp	x14, #0x36
    1920:      	b.ne	0x192c <_stogir.verify.integer-operations-target-structured+0xb68>
    1924:      	mov	x15, #0x1               ; =1
    1928:      	b	0x1918 <_stogir.verify.integer-operations-target-structured+0xb54>
    192c:      	cmp	x14, #0x37
    1930:      	b.ne	0x193c <_stogir.verify.integer-operations-target-structured+0xb78>
    1934:      	mov	x15, #0x1               ; =1
    1938:      	b	0x1928 <_stogir.verify.integer-operations-target-structured+0xb64>
    193c:      	cmp	x14, #0x38
    1940:      	b.ne	0x194c <_stogir.verify.integer-operations-target-structured+0xb88>
    1944:      	mov	x15, #0x1               ; =1
    1948:      	b	0x1938 <_stogir.verify.integer-operations-target-structured+0xb74>
    194c:      	cmp	x14, #0x39
    1950:      	cset	w15, eq
    1954:      	ubfx	x15, x15, #0, #8
    1958:      	b	0x1948 <_stogir.verify.integer-operations-target-structured+0xb84>
    195c:      	uxtb	w16, w1
    1960:      	cmp	w16, wzr
    1964:      	b.ne	0xfc4 <_stogir.verify.integer-operations-target-structured+0x200>
    1968:      	str	x0, [sp, #0x2b8]
    196c:      	str	x21, [sp, #0x2c0]
    1970:      	mov	w21, w1
    1974:      	ldr	x0, [sp, #0x270]
    1978:      	ldr	x1, [sp, #0x278]
    197c:      	b	0x103c <_stogir.verify.integer-operations-target-structured+0x278>
    1980:      	add	x0, x19, #0x1
    1984:      	lsr	w0, w0, #0
    1988:      	sxtw	x0, w0
    198c:      	ldr	x1, [sp, #0x270]
    1990:      	ldr	x2, [sp, #0x278]
    1994:      	b	0x1030 <_stogir.verify.integer-operations-target-structured+0x26c>
    1998:      	mov	x2, x1
    199c:      	mov	x1, x0
    19a0:      	mov	x0, #0x1                ; =1
    19a4:      	b	0x105c <_stogir.verify.integer-operations-target-structured+0x298>
    19a8:      	mov	x2, x1
    19ac:      	mov	x1, x0
    19b0:      	movz	x0, #0x0, lsl #48
    19b4:      	b	0x105c <_stogir.verify.integer-operations-target-structured+0x298>
    19b8:      	add	x0, x19, #0x1
    19bc:      	lsr	w0, w0, #0
    19c0:      	sxtw	x0, w0
    19c4:      	ldr	x1, [sp, #0x2c8]
    19c8:      	ldr	x2, [sp, #0x2d0]
    19cc:      	b	0x10c8 <_stogir.verify.integer-operations-target-structured+0x304>
    19d0:      	brk	#0
    19d4:      	b	0x19d0 <_stogir.verify.integer-operations-target-structured+0xc0c>
    19d8:      	ldr	x0, [sp, #0x2c8]
    19dc:      	ldr	x1, [sp, #0x2d0]
    19e0:      	b	0x10d4 <_stogir.verify.integer-operations-target-structured+0x310>
    19e4:      	cmp	x22, #0x1e
    19e8:      	cset	w2, eq
    19ec:      	ubfx	x2, x2, #0, #8
    19f0:      	fmov	d31, x0
    19f4:      	mov	x0, x2
    19f8:      	mov	x2, x1
    19fc:      	fmov	x1, d31
    1a00:      	b	0x10e8 <_stogir.verify.integer-operations-target-structured+0x324>
    1a04:      	mov	x0, #0x1                ; =1
    1a08:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x344>
    1a0c:      	movz	x0, #0x0, lsl #48
    1a10:      	b	0x1108 <_stogir.verify.integer-operations-target-structured+0x344>
    1a14:      	add	x16, sp, #0x70
    1a18:      	ldr	x0, [x16, #0x8]
    1a1c:      	add	x16, sp, #0x20
    1a20:      	ldr	w1, [x16, #0xc]
    1a24:      	sxtw	x1, w1
    1a28:      	cmp	x1, #0x0
    1a2c:      	b.ge	0x1a58 <_stogir.verify.integer-operations-target-structured+0xc94>
    1a30:      	ldr	x1, [sp, #0x2d8]
    1a34:      	ldr	x2, [sp, #0x2e0]
    1a38:      	mov	x0, #0x1                ; =1
    1a3c:      	cmp	x0, #0x0
    1a40:      	b.eq	0x1ad0 <_stogir.verify.integer-operations-target-structured+0xd0c>
    1a44:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001a44:  ARM64_RELOC_PAGE21	l_stogir.326
    1a48:      	ldr	x16, [x16]
		0000000000001a48:  ARM64_RELOC_PAGEOFF12	l_stogir.326
    1a4c:      	orr	x0, x16, xzr
    1a50:      	mov	x1, #0x2d               ; =45
    1a54:      	b	0x1178 <_stogir.verify.integer-operations-target-structured+0x3b4>
    1a58:      	uxtb	w0, w0
    1a5c:      	cmp	x0, #0x83
    1a60:      	b.ge	0x1ac0 <_stogir.verify.integer-operations-target-structured+0xcfc>
    1a64:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001a64:  ARM64_RELOC_PAGE21	l_stogir.327
    1a68:      	ldr	x16, [x16]
		0000000000001a68:  ARM64_RELOC_PAGEOFF12	l_stogir.327
    1a6c:      	orr	x1, x16, xzr
    1a70:      	add	x1, x0, x1
    1a74:      	ldrb	w1, [x1]
    1a78:      	uxtb	w1, w1
    1a7c:      	and	x1, x1, #0x2
    1a80:      	uxtb	w1, w1
    1a84:      	cmp	x1, #0x0
    1a88:      	cset	w1, eq
    1a8c:      	uxtb	w16, w1
    1a90:      	cmp	w16, wzr
    1a94:      	cset	x1, eq
    1a98:      	cmp	x1, #0x0
    1a9c:      	b.ne	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xd04>
    1aa0:      	cmp	x0, #0x65
    1aa4:      	b.eq	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xd04>
    1aa8:      	cmp	x0, #0x66
    1aac:      	b.eq	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xd04>
    1ab0:      	mov	x0, #0x1                ; =1
    1ab4:      	ldr	x1, [sp, #0x2d8]
    1ab8:      	ldr	x2, [sp, #0x2e0]
    1abc:      	b	0x1a3c <_stogir.verify.integer-operations-target-structured+0xc78>
    1ac0:      	movz	x1, #0x0, lsl #48
    1ac4:      	b	0x1a78 <_stogir.verify.integer-operations-target-structured+0xcb4>
    1ac8:      	movz	x0, #0x0, lsl #48
    1acc:      	b	0x1ab4 <_stogir.verify.integer-operations-target-structured+0xcf0>
    1ad0:      	mov	x0, x1
    1ad4:      	mov	x1, x2
    1ad8:      	b	0x1a54 <_stogir.verify.integer-operations-target-structured+0xc90>
    1adc:      	brk	#0
    1ae0:      	b	0x1adc <_stogir.verify.integer-operations-target-structured+0xd18>
    1ae4:      	ldr	x0, [sp, #0x2d8]
    1ae8:      	ldr	x1, [sp, #0x2e0]
    1aec:      	b	0x1178 <_stogir.verify.integer-operations-target-structured+0x3b4>
    1af0:      	mov	x2, x1
    1af4:      	mov	x1, x0
    1af8:      	movz	x0, #0x0, lsl #48
    1afc:      	b	0x119c <_stogir.verify.integer-operations-target-structured+0x3d8>
    1b00:      	ubfx	x0, x3, #0, #8
    1b04:      	b	0x11b0 <_stogir.verify.integer-operations-target-structured+0x3ec>
    1b08:      	add	x8, sp, #0xc0
    1b0c:      	ldr	x0, [sp, #0x230]
    1b10:      	ldr	w1, [sp, #0x2b0]
    1b14:      	bl	0x1b14 <_stogir.verify.integer-operations-target-structured+0xd50>
		0000000000001b14:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1b18:      	add	x16, sp, #0xc0
    1b1c:      	ldr	x0, [x16]
    1b20:      	add	x16, sp, #0xc0
    1b24:      	ldr	x1, [x16, #0x8]
    1b28:      	add	x16, sp, #0xc0
    1b2c:      	ldr	x2, [x16, #0x10]
    1b30:      	mov	x3, x1
    1b34:      	ldr	x1, [sp, #0x2f0]
    1b38:      	mov	x4, x2
    1b3c:      	mov	x2, x0
    1b40:      	ldr	x0, [sp, #0x2e8]
    1b44:      	b	0x1208 <_stogir.verify.integer-operations-target-structured+0x444>
    1b48:      	add	x2, x19, #0x1
    1b4c:      	lsr	w2, w2, #0
    1b50:      	sxtw	x2, w2
    1b54:      	fmov	d31, x0
    1b58:      	mov	x0, x2
    1b5c:      	mov	x2, x1
    1b60:      	fmov	x1, d31
    1b64:      	b	0x1244 <_stogir.verify.integer-operations-target-structured+0x480>
    1b68:      	brk	#0
    1b6c:      	b	0x1b68 <_stogir.verify.integer-operations-target-structured+0xda4>
    1b70:      	ldr	x0, [sp, #0x2e8]
    1b74:      	ldr	x1, [sp, #0x2f0]
    1b78:      	b	0x1250 <_stogir.verify.integer-operations-target-structured+0x48c>
    1b7c:      	mov	x2, x1
    1b80:      	mov	x1, x0
    1b84:      	movz	x0, #0x0, lsl #48
    1b88:      	b	0x1274 <_stogir.verify.integer-operations-target-structured+0x4b0>
    1b8c:      	add	x0, x19, #0x1
    1b90:      	lsr	w0, w0, #0
    1b94:      	sxtw	x0, w0
    1b98:      	ldr	x1, [sp, #0x2f8]
    1b9c:      	ldr	x2, [sp, #0x300]
    1ba0:      	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x51c>
    1ba4:      	brk	#0
    1ba8:      	b	0x1ba4 <_stogir.verify.integer-operations-target-structured+0xde0>
    1bac:      	ldr	x0, [sp, #0x2f8]
    1bb0:      	ldr	x1, [sp, #0x300]
    1bb4:      	b	0x12ec <_stogir.verify.integer-operations-target-structured+0x528>
    1bb8:      	cmp	x22, #0x79
    1bbc:      	cset	w2, eq
    1bc0:      	ubfx	x2, x2, #0, #8
    1bc4:      	fmov	d31, x0
    1bc8:      	mov	x0, x2
    1bcc:      	mov	x2, x1
    1bd0:      	fmov	x1, d31
    1bd4:      	b	0x1300 <_stogir.verify.integer-operations-target-structured+0x53c>
    1bd8:      	add	x0, x19, #0x1
    1bdc:      	lsr	w0, w0, #0
    1be0:      	sxtw	x0, w0
    1be4:      	ldr	x1, [sp, #0x308]
    1be8:      	ldr	x2, [sp, #0x310]
    1bec:      	b	0x136c <_stogir.verify.integer-operations-target-structured+0x5a8>
    1bf0:      	brk	#0
    1bf4:      	b	0x1bf0 <_stogir.verify.integer-operations-target-structured+0xe2c>
    1bf8:      	ldr	x0, [sp, #0x308]
    1bfc:      	ldr	x1, [sp, #0x310]
    1c00:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x5b4>
    1c04:      	cmp	x22, #0x6d
    1c08:      	b.lt	0x1c2c <_stogir.verify.integer-operations-target-structured+0xe68>
    1c0c:      	cmp	x22, #0x6f
    1c10:      	cset	w2, le
    1c14:      	ubfx	x2, x2, #0, #8
    1c18:      	fmov	d31, x0
    1c1c:      	mov	x0, x2
    1c20:      	mov	x2, x1
    1c24:      	fmov	x1, d31
    1c28:      	b	0x138c <_stogir.verify.integer-operations-target-structured+0x5c8>
    1c2c:      	movz	x2, #0x0, lsl #48
    1c30:      	b	0x1c18 <_stogir.verify.integer-operations-target-structured+0xe54>
    1c34:      	add	x0, x19, #0x1
    1c38:      	lsr	w0, w0, #0
    1c3c:      	sxtw	x0, w0
    1c40:      	ldr	x1, [sp, #0x318]
    1c44:      	ldr	x2, [sp, #0x320]
    1c48:      	b	0x13f8 <_stogir.verify.integer-operations-target-structured+0x634>
    1c4c:      	brk	#0
    1c50:      	b	0x1c4c <_stogir.verify.integer-operations-target-structured+0xe88>
    1c54:      	ldr	x0, [sp, #0x318]
    1c58:      	ldr	x1, [sp, #0x320]
    1c5c:      	b	0x1404 <_stogir.verify.integer-operations-target-structured+0x640>
    1c60:      	cmp	x22, #0x51
    1c64:      	b.ne	0x1c80 <_stogir.verify.integer-operations-target-structured+0xebc>
    1c68:      	mov	x2, #0x1                ; =1
    1c6c:      	fmov	d31, x0
    1c70:      	mov	x0, x2
    1c74:      	mov	x2, x1
    1c78:      	fmov	x1, d31
    1c7c:      	b	0x1418 <_stogir.verify.integer-operations-target-structured+0x654>
    1c80:      	cmp	x22, #0x52
    1c84:      	b.ne	0x1c90 <_stogir.verify.integer-operations-target-structured+0xecc>
    1c88:      	mov	x2, #0x1                ; =1
    1c8c:      	b	0x1c6c <_stogir.verify.integer-operations-target-structured+0xea8>
    1c90:      	cmp	x22, #0x53
    1c94:      	b.ne	0x1ca0 <_stogir.verify.integer-operations-target-structured+0xedc>
    1c98:      	mov	x2, #0x1                ; =1
    1c9c:      	b	0x1c8c <_stogir.verify.integer-operations-target-structured+0xec8>
    1ca0:      	cmp	x22, #0x54
    1ca4:      	cset	w2, eq
    1ca8:      	ubfx	x2, x2, #0, #8
    1cac:      	b	0x1c9c <_stogir.verify.integer-operations-target-structured+0xed8>
    1cb0:      	add	x0, x19, #0x1
    1cb4:      	lsr	w0, w0, #0
    1cb8:      	sxtw	x0, w0
    1cbc:      	ldr	x1, [sp, #0x328]
    1cc0:      	ldr	x2, [sp, #0x330]
    1cc4:      	b	0x1484 <_stogir.verify.integer-operations-target-structured+0x6c0>
    1cc8:      	brk	#0
    1ccc:      	b	0x1cc8 <_stogir.verify.integer-operations-target-structured+0xf04>
    1cd0:      	ldr	x0, [sp, #0x328]
    1cd4:      	ldr	x1, [sp, #0x330]
    1cd8:      	b	0x1490 <_stogir.verify.integer-operations-target-structured+0x6cc>
    1cdc:      	cmp	x22, #0x48
    1ce0:      	b.ne	0x1cfc <_stogir.verify.integer-operations-target-structured+0xf38>
    1ce4:      	mov	x2, #0x1                ; =1
    1ce8:      	fmov	d31, x0
    1cec:      	mov	x0, x2
    1cf0:      	mov	x2, x1
    1cf4:      	fmov	x1, d31
    1cf8:      	b	0x14a4 <_stogir.verify.integer-operations-target-structured+0x6e0>
    1cfc:      	cmp	x22, #0x55
    1d00:      	b.lt	0x1d14 <_stogir.verify.integer-operations-target-structured+0xf50>
    1d04:      	cmp	x22, #0x58
    1d08:      	cset	w2, le
    1d0c:      	ubfx	x2, x2, #0, #8
    1d10:      	b	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xf24>
    1d14:      	movz	x2, #0x0, lsl #48
    1d18:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xf4c>
    1d1c:      	add	x0, x19, #0x1
    1d20:      	lsr	w0, w0, #0
    1d24:      	sxtw	x0, w0
    1d28:      	ldr	x1, [sp, #0x338]
    1d2c:      	ldr	x2, [sp, #0x340]
    1d30:      	b	0x1514 <_stogir.verify.integer-operations-target-structured+0x750>
    1d34:      	brk	#0
    1d38:      	b	0x1d34 <_stogir.verify.integer-operations-target-structured+0xf70>
    1d3c:      	ldr	x0, [sp, #0x338]
    1d40:      	ldr	x1, [sp, #0x340]
    1d44:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x75c>
    1d48:      	mov	x2, x1
    1d4c:      	mov	x1, x0
    1d50:      	movz	x0, #0x0, lsl #48
    1d54:      	b	0x1544 <_stogir.verify.integer-operations-target-structured+0x780>
    1d58:      	add	x0, x19, #0x1
    1d5c:      	lsr	w0, w0, #0
    1d60:      	sxtw	x0, w0
    1d64:      	ldr	x2, [sp, #0x348]
    1d68:      	ldr	x3, [sp, #0x350]
    1d6c:      	b	0x15bc <_stogir.verify.integer-operations-target-structured+0x7f8>
    1d70:      	brk	#0
    1d74:      	b	0x1d70 <_stogir.verify.integer-operations-target-structured+0xfac>
    1d78:      	ldr	x0, [sp, #0x348]
    1d7c:      	ldr	x2, [sp, #0x350]
    1d80:      	b	0x15c8 <_stogir.verify.integer-operations-target-structured+0x804>
    1d84:      	add	x0, x19, #0x1
    1d88:      	lsr	w0, w0, #0
    1d8c:      	sxtw	x0, w0
    1d90:      	ldr	x2, [sp, #0x358]
    1d94:      	ldr	x3, [sp, #0x360]
    1d98:      	b	0x1640 <_stogir.verify.integer-operations-target-structured+0x87c>
    1d9c:      	brk	#0
    1da0:      	b	0x1d9c <_stogir.verify.integer-operations-target-structured+0xfd8>
    1da4:      	ldr	x0, [sp, #0x358]
    1da8:      	ldr	x2, [sp, #0x360]
    1dac:      	b	0x164c <_stogir.verify.integer-operations-target-structured+0x888>
    1db0:      	mov	x3, x2
    1db4:      	mov	x2, x0
    1db8:      	mov	x0, #0x1                ; =1
    1dbc:      	b	0x1688 <_stogir.verify.integer-operations-target-structured+0x8c4>
    1dc0:      	mov	x0, x2
    1dc4:      	mov	x2, x3
    1dc8:      	b	0x16a0 <_stogir.verify.integer-operations-target-structured+0x8dc>
    1dcc:      	add	x16, sp, #0x20
    1dd0:      	ldr	w3, [x16, #0x8]
    1dd4:      	lsr	w3, w3, #0
    1dd8:      	add	x8, sp, #0x1c0
    1ddc:      	str	x1, [sp, #0x288]
    1de0:      	mov	w1, w3
    1de4:      	str	x0, [sp, #0x368]
    1de8:      	ldr	x0, [sp, #0x230]
    1dec:      	str	x2, [sp, #0x370]
    1df0:      	bl	0x1df0 <_stogir.verify.integer-operations-target-structured+0x102c>
		0000000000001df0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1df4:      	add	x16, sp, #0x1c0
    1df8:      	ldr	w0, [x16]
    1dfc:      	lsr	x16, x0, #0
    1e00:      	cmp	x16, #0x1
    1e04:      	b.eq	0x1e20 <_stogir.verify.integer-operations-target-structured+0x105c>
    1e08:      	b.lo	0x1e10 <_stogir.verify.integer-operations-target-structured+0x104c>
    1e0c:      	b	0x1e24 <_stogir.verify.integer-operations-target-structured+0x1060>
    1e10:      	cmp	x16, #0x0
    1e14:      	b.eq	0x1e1c <_stogir.verify.integer-operations-target-structured+0x1058>
    1e18:      	b	0x1e24 <_stogir.verify.integer-operations-target-structured+0x1060>
    1e1c:      	b	0x1e28 <_stogir.verify.integer-operations-target-structured+0x1064>
    1e20:      	b	0x1e3c <_stogir.verify.integer-operations-target-structured+0x1078>
    1e24:      	b	0x1e80 <_stogir.verify.integer-operations-target-structured+0x10bc>
    1e28:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001e28:  ARM64_RELOC_PAGE21	l_stogir.328
    1e2c:      	ldr	x16, [x16]
		0000000000001e2c:  ARM64_RELOC_PAGEOFF12	l_stogir.328
    1e30:      	orr	x0, x16, xzr
    1e34:      	mov	x1, #0x14               ; =20
    1e38:      	b	0x16a8 <_stogir.verify.integer-operations-target-structured+0x8e4>
    1e3c:      	add	x16, sp, #0x1c0
    1e40:      	ldr	x0, [x16, #0x8]
    1e44:      	add	x16, sp, #0x20
    1e48:      	ldr	w1, [x16]
    1e4c:      	lsr	w0, w0, #0
    1e50:      	ubfx	x1, x1, #8, #8
    1e54:      	ubfx	x0, x0, #8, #8
    1e58:      	cmp	x0, x1
    1e5c:      	b.ne	0x1e6c <_stogir.verify.integer-operations-target-structured+0x10a8>
    1e60:      	ldr	x0, [sp, #0x368]
    1e64:      	ldr	x1, [sp, #0x370]
    1e68:      	b	0x1e38 <_stogir.verify.integer-operations-target-structured+0x1074>
    1e6c:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001e6c:  ARM64_RELOC_PAGE21	l_stogir.329
    1e70:      	ldr	x16, [x16]
		0000000000001e70:  ARM64_RELOC_PAGEOFF12	l_stogir.329
    1e74:      	orr	x0, x16, xzr
    1e78:      	mov	x1, #0x1a               ; =26
    1e7c:      	b	0x1e68 <_stogir.verify.integer-operations-target-structured+0x10a4>
    1e80:      	brk	#0
    1e84:      	b	0x1e80 <_stogir.verify.integer-operations-target-structured+0x10bc>
    1e88:      	ldr	x0, [sp, #0x368]
    1e8c:      	ldr	x1, [sp, #0x370]
    1e90:      	b	0x16b8 <_stogir.verify.integer-operations-target-structured+0x8f4>
    1e94:      	add	x0, x19, #0x1
    1e98:      	lsr	w0, w0, #0
    1e9c:      	sxtw	x0, w0
    1ea0:      	ldr	x2, [sp, #0x378]
    1ea4:      	ldr	x3, [sp, #0x380]
    1ea8:      	b	0x1754 <_stogir.verify.integer-operations-target-structured+0x990>
    1eac:      	brk	#0
    1eb0:      	b	0x1eac <_stogir.verify.integer-operations-target-structured+0x10e8>
    1eb4:      	ldr	x0, [sp, #0x378]
    1eb8:      	ldr	x2, [sp, #0x380]
    1ebc:      	b	0x1760 <_stogir.verify.integer-operations-target-structured+0x99c>
    1ec0:      	mov	x3, x2
    1ec4:      	mov	x2, x0
    1ec8:      	mov	x0, #0x1                ; =1
    1ecc:      	b	0x1778 <_stogir.verify.integer-operations-target-structured+0x9b4>
    1ed0:      	mov	x0, #0x1                ; =1
    1ed4:      	b	0x178c <_stogir.verify.integer-operations-target-structured+0x9c8>
    1ed8:      	ldr	x21, [sp, #0x2a0]
    1edc:      	cmp	x21, #0x0
    1ee0:      	b.eq	0x1eec <_stogir.verify.integer-operations-target-structured+0x1128>
    1ee4:      	mov	x0, #0x1                ; =1
    1ee8:      	b	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9e4>
    1eec:      	ldr	x0, [sp, #0x2a8]
    1ef0:      	b	0x1ee8 <_stogir.verify.integer-operations-target-structured+0x1124>
    1ef4:      	movz	x0, #0x0, lsl #48
    1ef8:      	b	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9e4>
    1efc:      	movz	x0, #0x0, lsl #48
    1f00:      	b	0x17a8 <_stogir.verify.integer-operations-target-structured+0x9e4>
    1f04:      	lsr	w1, w1, #0
    1f08:      	lsr	w1, w1, #0
    1f0c:      	ldr	x0, [sp, #0x230]
    1f10:      	bl	0x1f10 <_stogir.verify.integer-operations-target-structured+0x114c>
		0000000000001f10:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    1f14:      	cmp	x0, #0x0
    1f18:      	b.ne	0x1f2c <_stogir.verify.integer-operations-target-structured+0x1168>
    1f1c:      	str	x23, [sp, #0x3a8]
    1f20:      	ldr	x0, [sp, #0x3a0]
    1f24:      	mov	x1, #0x17               ; =23
    1f28:      	b	0x183c <_stogir.verify.integer-operations-target-structured+0xa78>
    1f2c:      	ldr	w0, [x0]
    1f30:      	add	x16, sp, #0x20
    1f34:      	ldr	w1, [x16]
    1f38:      	ubfx	x0, x0, #8, #8
    1f3c:      	orr	x2, x0, xzr
    1f40:      	ubfx	x1, x1, #8, #8
    1f44:      	cmp	x1, #0x6
    1f48:      	b.ne	0x20c8 <_stogir.verify.integer-operations-target-structured+0x1304>
    1f4c:      	cmp	x2, #0x6
    1f50:      	b.ne	0x20b8 <_stogir.verify.integer-operations-target-structured+0x12f4>
    1f54:      	cmp	x22, #0x1a
    1f58:      	b.ne	0x20a0 <_stogir.verify.integer-operations-target-structured+0x12dc>
    1f5c:      	ldr	x3, [sp, #0x390]
    1f60:      	ldr	x4, [sp, #0x398]
    1f64:      	mov	x1, #0x1                ; =1
    1f68:      	mov	x22, x1
    1f6c:      	mov	x1, x3
    1f70:      	mov	x3, x4
    1f74:      	cmp	x2, #0x1
    1f78:      	b.lt	0x20d8 <_stogir.verify.integer-operations-target-structured+0x1314>
    1f7c:      	cmp	x2, #0xb
    1f80:      	cset	w4, le
    1f84:      	ubfx	x4, x4, #0, #8
    1f88:      	fmov	d31, x1
    1f8c:      	mov	x1, x4
    1f90:      	mov	x4, x3
    1f94:      	fmov	x3, d31
    1f98:      	cmp	x1, #0x0
    1f9c:      	b.eq	0x20e8 <_stogir.verify.integer-operations-target-structured+0x1324>
    1fa0:      	movz	x1, #0x0, lsl #48
    1fa4:      	cmp	x1, #0x0
    1fa8:      	b.eq	0x20f0 <_stogir.verify.integer-operations-target-structured+0x132c>
    1fac:      	str	x23, [sp, #0x3a8]
    1fb0:      	mov	x23, x2
    1fb4:      	mov	x1, x3
    1fb8:      	mov	x2, x4
    1fbc:      	mov	x0, #0x1                ; =1
    1fc0:      	cmp	x0, #0x0
    1fc4:      	b.eq	0x217c <_stogir.verify.integer-operations-target-structured+0x13b8>
    1fc8:      	adrp	x16, 0x1000 <_stogir.verify.integer-operations-target-structured+0x23c>
		0000000000001fc8:  ARM64_RELOC_PAGE21	l_stogir.330
    1fcc:      	ldr	x16, [x16]
		0000000000001fcc:  ARM64_RELOC_PAGEOFF12	l_stogir.330
    1fd0:      	orr	x0, x16, xzr
    1fd4:      	mov	x1, #0x1c               ; =28
    1fd8:      	add	x16, sp, #0x20
    1fdc:      	ldr	w2, [x16]
    1fe0:      	cmp	x20, #0x0
    1fe4:      	b.eq	0x2188 <_stogir.verify.integer-operations-target-structured+0x13c4>
    1fe8:      	mov	x3, x0
    1fec:      	mov	x0, #0x1                ; =1
    1ff0:      	lsr	w0, w0, #0
    1ff4:      	ubfx	x2, x2, #8, #8
    1ff8:      	sxtw	x0, w0
    1ffc:      	cmp	x2, x0
    2000:      	b.ne	0x2194 <_stogir.verify.integer-operations-target-structured+0x13d0>
    2004:      	mov	x0, x3
    2008:      	cmp	x20, #0x0
    200c:      	b.eq	0x21a8 <_stogir.verify.integer-operations-target-structured+0x13e4>
    2010:      	mov	x20, x0
    2014:      	mov	x0, #0x1                ; =1
    2018:      	cmp	x0, #0x0
    201c:      	b.eq	0x2414 <_stogir.verify.integer-operations-target-structured+0x1650>
    2020:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002020:  ARM64_RELOC_PAGE21	l_stogir.331
    2024:      	ldr	x16, [x16]
		0000000000002024:  ARM64_RELOC_PAGEOFF12	l_stogir.331
    2028:      	orr	x21, x16, xzr
    202c:      	add	x16, sp, #0x220
    2030:      	str	x16, [sp]
    2034:      	ldr	x0, [sp, #0x230]
    2038:      	str	x1, [sp, #0x3d0]
    203c:      	ldr	w1, [sp, #0x2b0]
    2040:      	mov	x2, #0x2                ; =2
    2044:      	bl	0x2044 <_stogir.verify.integer-operations-target-structured+0x1280>
		0000000000002044:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    2048:      	ldr	x16, [sp]
    204c:      	str	x0, [x16]
    2050:      	str	x1, [x16, #0x8]
    2054:      	add	x16, sp, #0x220
    2058:      	ldr	x0, [x16]
    205c:      	add	x16, sp, #0x220
    2060:      	ldr	x1, [x16, #0x8]
    2064:      	lsr	w0, w0, #0
    2068:      	lsr	x16, x0, #0
    206c:      	cmp	x16, #0x1
    2070:      	b.eq	0x208c <_stogir.verify.integer-operations-target-structured+0x12c8>
    2074:      	b.lo	0x207c <_stogir.verify.integer-operations-target-structured+0x12b8>
    2078:      	b	0x2090 <_stogir.verify.integer-operations-target-structured+0x12cc>
    207c:      	cmp	x16, #0x0
    2080:      	b.eq	0x2088 <_stogir.verify.integer-operations-target-structured+0x12c4>
    2084:      	b	0x2090 <_stogir.verify.integer-operations-target-structured+0x12cc>
    2088:      	b	0x2094 <_stogir.verify.integer-operations-target-structured+0x12d0>
    208c:      	b	0x21b4 <_stogir.verify.integer-operations-target-structured+0x13f0>
    2090:      	b	0x2260 <_stogir.verify.integer-operations-target-structured+0x149c>
    2094:      	mov	x0, x21
    2098:      	mov	x1, #0x1d               ; =29
    209c:      	b	0x1f28 <_stogir.verify.integer-operations-target-structured+0x1164>
    20a0:      	cmp	x22, #0x1b
    20a4:      	cset	w1, eq
    20a8:      	ubfx	x1, x1, #0, #8
    20ac:      	ldr	x3, [sp, #0x390]
    20b0:      	ldr	x4, [sp, #0x398]
    20b4:      	b	0x1f68 <_stogir.verify.integer-operations-target-structured+0x11a4>
    20b8:      	ldr	x3, [sp, #0x390]
    20bc:      	ldr	x4, [sp, #0x398]
    20c0:      	movz	x1, #0x0, lsl #48
    20c4:      	b	0x1f68 <_stogir.verify.integer-operations-target-structured+0x11a4>
    20c8:      	ldr	x1, [sp, #0x390]
    20cc:      	ldr	x3, [sp, #0x398]
    20d0:      	movz	x22, #0x0, lsl #48
    20d4:      	b	0x1f74 <_stogir.verify.integer-operations-target-structured+0x11b0>
    20d8:      	mov	x4, x3
    20dc:      	mov	x3, x1
    20e0:      	movz	x1, #0x0, lsl #48
    20e4:      	b	0x1f98 <_stogir.verify.integer-operations-target-structured+0x11d4>
    20e8:      	mov	x1, #0x1                ; =1
    20ec:      	b	0x1fa4 <_stogir.verify.integer-operations-target-structured+0x11e0>
    20f0:      	ldr	w12, [sp, #0x280]
    20f4:      	lsr	w1, w12, #0
    20f8:      	lsr	w0, w0, #0
    20fc:      	ldr	x5, [sp, #0x2a8]
    2100:      	cmp	x5, #0x0
    2104:      	b.eq	0x241c <_stogir.verify.integer-operations-target-structured+0x1658>
    2108:      	str	x3, [sp, #0x3b0]
    210c:      	str	x4, [sp, #0x3b8]
    2110:      	str	w1, [sp, #0x3c0]
    2114:      	str	w0, [sp, #0x3c8]
    2118:      	str	x23, [sp, #0x3a8]
    211c:      	mov	x23, x2
    2120:      	fmov	s31, w0
    2124:      	mov	w0, w1
    2128:      	fmov	w1, s31
    212c:      	bl	0x212c <_stogir.verify.integer-operations-target-structured+0x1368>
		000000000000212c:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    2130:      	cmp	x0, #0x0
    2134:      	b.ne	0x2148 <_stogir.verify.integer-operations-target-structured+0x1384>
    2138:      	mov	x0, #0x1                ; =1
    213c:      	ldr	x1, [sp, #0x3b0]
    2140:      	ldr	x2, [sp, #0x3b8]
    2144:      	b	0x1fc0 <_stogir.verify.integer-operations-target-structured+0x11fc>
    2148:      	cmp	x21, #0x0
    214c:      	b.eq	0x2174 <_stogir.verify.integer-operations-target-structured+0x13b0>
    2150:      	ldr	w0, [sp, #0x3c0]
    2154:      	ldr	w1, [sp, #0x3c8]
    2158:      	bl	0x2158 <_stogir.verify.integer-operations-target-structured+0x1394>
		0000000000002158:  ARM64_RELOC_BRANCH26	_stogir.integer-binary.valid-type?
    215c:      	cmp	x0, #0x0
    2160:      	cset	w0, ne
    2164:      	uxtb	w16, w0
    2168:      	cmp	w16, wzr
    216c:      	cset	x0, eq
    2170:      	b	0x213c <_stogir.verify.integer-operations-target-structured+0x1378>
    2174:      	movz	x0, #0x0, lsl #48
    2178:      	b	0x2170 <_stogir.verify.integer-operations-target-structured+0x13ac>
    217c:      	mov	x0, x1
    2180:      	mov	x1, x2
    2184:      	b	0x1fd8 <_stogir.verify.integer-operations-target-structured+0x1214>
    2188:      	mov	x3, x0
    218c:      	mov	x0, x23
    2190:      	b	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x122c>
    2194:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002194:  ARM64_RELOC_PAGE21	l_stogir.332
    2198:      	ldr	x16, [x16]
		0000000000002198:  ARM64_RELOC_PAGEOFF12	l_stogir.332
    219c:      	orr	x0, x16, xzr
    21a0:      	mov	x1, #0x26               ; =38
    21a4:      	b	0x2008 <_stogir.verify.integer-operations-target-structured+0x1244>
    21a8:      	mov	x20, x0
    21ac:      	mov	x0, x21
    21b0:      	b	0x2018 <_stogir.verify.integer-operations-target-structured+0x1254>
    21b4:      	lsr	w1, w1, #0
    21b8:      	lsr	w1, w1, #0
    21bc:      	ldr	x0, [sp, #0x230]
    21c0:      	bl	0x21c0 <_stogir.verify.integer-operations-target-structured+0x13fc>
		00000000000021c0:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    21c4:      	cmp	x0, #0x0
    21c8:      	b.ne	0x21d8 <_stogir.verify.integer-operations-target-structured+0x1414>
    21cc:      	mov	x0, x21
    21d0:      	mov	x1, #0x1d               ; =29
    21d4:      	b	0x209c <_stogir.verify.integer-operations-target-structured+0x12d8>
    21d8:      	ldr	w0, [x0]
    21dc:      	ubfx	x0, x0, #8, #8
    21e0:      	cmp	x23, x0
    21e4:      	b.ne	0x2218 <_stogir.verify.integer-operations-target-structured+0x1454>
    21e8:      	mov	x1, x20
    21ec:      	mov	x0, #0x1                ; =1
    21f0:      	cmp	x0, #0x0
    21f4:      	b.eq	0x224c <_stogir.verify.integer-operations-target-structured+0x1488>
    21f8:      	movz	x0, #0x0, lsl #48
    21fc:      	cmp	x0, #0x0
    2200:      	b.eq	0x2254 <_stogir.verify.integer-operations-target-structured+0x1490>
    2204:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002204:  ARM64_RELOC_PAGE21	l_stogir.333
    2208:      	ldr	x16, [x16]
		0000000000002208:  ARM64_RELOC_PAGEOFF12	l_stogir.333
    220c:      	orr	x0, x16, xzr
    2210:      	mov	x1, #0x1d               ; =29
    2214:      	b	0x21d4 <_stogir.verify.integer-operations-target-structured+0x1410>
    2218:      	cmp	x22, #0x0
    221c:      	b.eq	0x2244 <_stogir.verify.integer-operations-target-structured+0x1480>
    2220:      	cmp	x0, #0x5
    2224:      	b.ne	0x2234 <_stogir.verify.integer-operations-target-structured+0x1470>
    2228:      	mov	x0, #0x1                ; =1
    222c:      	mov	x1, x20
    2230:      	b	0x21f0 <_stogir.verify.integer-operations-target-structured+0x142c>
    2234:      	cmp	x0, #0xb
    2238:      	cset	w0, eq
    223c:      	ubfx	x0, x0, #0, #8
    2240:      	b	0x222c <_stogir.verify.integer-operations-target-structured+0x1468>
    2244:      	movz	x0, #0x0, lsl #48
    2248:      	b	0x222c <_stogir.verify.integer-operations-target-structured+0x1468>
    224c:      	mov	x0, #0x1                ; =1
    2250:      	b	0x21fc <_stogir.verify.integer-operations-target-structured+0x1438>
    2254:      	mov	x0, x1
    2258:      	ldr	x1, [sp, #0x3d0]
    225c:      	b	0x2214 <_stogir.verify.integer-operations-target-structured+0x1450>
    2260:      	brk	#0
    2264:      	b	0x2260 <_stogir.verify.integer-operations-target-structured+0x149c>
    2268:      	mov	x0, x20
    226c:      	ldr	x1, [sp, #0x3d0]
    2270:      	b	0x209c <_stogir.verify.integer-operations-target-structured+0x12d8>
    2274:      	brk	#0
    2278:      	b	0x2274 <_stogir.verify.integer-operations-target-structured+0x14b0>
    227c:      	mov	x0, x19
    2280:      	ldr	x1, [sp, #0x390]
    2284:      	ldr	x2, [sp, #0x398]
    2288:      	b	0x1858 <_stogir.verify.integer-operations-target-structured+0xa94>
    228c:      	brk	#0
    2290:      	b	0x228c <_stogir.verify.integer-operations-target-structured+0x14c8>
    2294:      	uxtb	w16, w10
    2298:      	cmp	w16, wzr
    229c:      	b.eq	0x22f8 <_stogir.verify.integer-operations-target-structured+0x1534>
    22a0:      	and	x0, x19, #0xffffffff
    22a4:      	mov	x1, x0
    22a8:      	movz	x0, #0x0, lsl #48
    22ac:      	movz	x2, #0x0, lsl #48
    22b0:      	ldr	x3, [sp, #0x258]
    22b4:      	str	x0, [x3]
    22b8:      	str	x1, [x3, #0x8]
    22bc:      	str	x2, [x3, #0x10]
    22c0:      	ldr	x19, [sp, #0x3d8]
    22c4:      	ldr	x20, [sp, #0x3e0]
    22c8:      	ldr	x21, [sp, #0x3e8]
    22cc:      	ldr	x22, [sp, #0x3f0]
    22d0:      	ldr	x23, [sp, #0x3f8]
    22d4:      	ldr	x24, [sp, #0x400]
    22d8:      	ldr	x25, [sp, #0x408]
    22dc:      	ldr	x26, [sp, #0x410]
    22e0:      	ldr	x27, [sp, #0x418]
    22e4:      	ldr	x28, [sp, #0x420]
    22e8:      	ldr	x29, [sp, #0x10]
    22ec:      	ldr	x30, [sp, #0x18]
    22f0:      	add	sp, sp, #0x430
    22f4:      	ret
    22f8:      	ldr	x1, [sp, #0x270]
    22fc:      	ldr	x2, [sp, #0x278]
    2300:      	mov	x0, #0x1                ; =1
    2304:      	b	0x22b0 <_stogir.verify.integer-operations-target-structured+0x14ec>
    2308:      	mov	x19, x6
    230c:      	str	x8, [sp, #0x258]
    2310:      	str	x7, [sp, #0x270]
    2314:      	str	x9, [sp, #0x278]
    2318:      	b	0x2294 <_stogir.verify.integer-operations-target-structured+0x14d0>
    231c:      	mov	x19, x6
    2320:      	str	x8, [sp, #0x258]
    2324:      	str	x7, [sp, #0x270]
    2328:      	str	x9, [sp, #0x278]
    232c:      	b	0x2294 <_stogir.verify.integer-operations-target-structured+0x14d0>
    2330:      	str	x1, [sp, #0x2c8]
    2334:      	str	x2, [sp, #0x2d0]
    2338:      	b	0x19d8 <_stogir.verify.integer-operations-target-structured+0xc14>
    233c:      	str	x1, [sp, #0x2d8]
    2340:      	str	x2, [sp, #0x2e0]
    2344:      	b	0x1ae4 <_stogir.verify.integer-operations-target-structured+0xd20>
    2348:      	str	x1, [sp, #0x2e8]
    234c:      	str	x2, [sp, #0x2f0]
    2350:      	b	0x1b70 <_stogir.verify.integer-operations-target-structured+0xdac>
    2354:      	str	x1, [sp, #0x2e8]
    2358:      	str	x2, [sp, #0x2f0]
    235c:      	b	0x1b08 <_stogir.verify.integer-operations-target-structured+0xd44>
    2360:      	str	x1, [sp, #0x2f8]
    2364:      	str	x2, [sp, #0x300]
    2368:      	b	0x1bac <_stogir.verify.integer-operations-target-structured+0xde8>
    236c:      	str	x1, [sp, #0x308]
    2370:      	str	x2, [sp, #0x310]
    2374:      	b	0x1bf8 <_stogir.verify.integer-operations-target-structured+0xe34>
    2378:      	str	x1, [sp, #0x318]
    237c:      	str	x2, [sp, #0x320]
    2380:      	b	0x1c54 <_stogir.verify.integer-operations-target-structured+0xe90>
    2384:      	str	x1, [sp, #0x328]
    2388:      	str	x2, [sp, #0x330]
    238c:      	b	0x1cd0 <_stogir.verify.integer-operations-target-structured+0xf0c>
    2390:      	str	x1, [sp, #0x338]
    2394:      	str	x2, [sp, #0x340]
    2398:      	b	0x1d3c <_stogir.verify.integer-operations-target-structured+0xf78>
    239c:      	str	x1, [sp, #0x348]
    23a0:      	ldr	x1, [sp, #0x2c0]
    23a4:      	str	x2, [sp, #0x350]
    23a8:      	b	0x1d78 <_stogir.verify.integer-operations-target-structured+0xfb4>
    23ac:      	str	x1, [sp, #0x2c0]
    23b0:      	ldr	x1, [sp, #0x288]
    23b4:      	str	x0, [sp, #0x358]
    23b8:      	str	x2, [sp, #0x360]
    23bc:      	b	0x1da4 <_stogir.verify.integer-operations-target-structured+0xfe0>
    23c0:      	str	x1, [sp, #0x288]
    23c4:      	str	x0, [sp, #0x368]
    23c8:      	str	x2, [sp, #0x370]
    23cc:      	b	0x1e88 <_stogir.verify.integer-operations-target-structured+0x10c4>
    23d0:      	str	x20, [sp, #0x388]
    23d4:      	mov	x20, x2
    23d8:      	str	x0, [sp, #0x378]
    23dc:      	str	x1, [sp, #0x380]
    23e0:      	ldr	x1, [sp, #0x268]
    23e4:      	b	0x1eb4 <_stogir.verify.integer-operations-target-structured+0x10f0>
    23e8:      	ldr	x20, [sp, #0x298]
    23ec:      	ldr	x21, [sp, #0x2a0]
    23f0:      	b	0x1efc <_stogir.verify.integer-operations-target-structured+0x1138>
    23f4:      	ldr	x20, [sp, #0x298]
    23f8:      	ldr	x21, [sp, #0x2a0]
    23fc:      	b	0x1ef4 <_stogir.verify.integer-operations-target-structured+0x1130>
    2400:      	str	x23, [sp, #0x3a8]
    2404:      	str	x1, [sp, #0x268]
    2408:      	str	x2, [sp, #0x390]
    240c:      	str	x3, [sp, #0x398]
    2410:      	b	0x227c <_stogir.verify.integer-operations-target-structured+0x14b8>
    2414:      	str	x1, [sp, #0x3d0]
    2418:      	b	0x2268 <_stogir.verify.integer-operations-target-structured+0x14a4>
    241c:      	str	w1, [sp, #0x3c0]
    2420:      	str	x23, [sp, #0x3a8]
    2424:      	mov	x23, x2
    2428:      	str	w0, [sp, #0x3c8]
    242c:      	str	x3, [sp, #0x3b0]
    2430:      	str	x4, [sp, #0x3b8]
    2434:      	b	0x2148 <_stogir.verify.integer-operations-target-structured+0x1384>

0000000000002438 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2438:      	ldr	x0, [x0, #0x8]
    243c:      	ret

0000000000002440 <_coil.core.Eq$slice<u8>$=>:
    2440:      	sub	sp, sp, #0x10
    2444:      	str	x29, [sp]
    2448:      	str	x30, [sp, #0x8]
    244c:      	mov	x29, sp
    2450:      	cmp	x1, x3
    2454:      	b.ne	0x2494 <_coil.core.Eq$slice<u8>$=+0x54>
    2458:      	cmp	x1, #0x0
    245c:      	b.ne	0x2468 <_coil.core.Eq$slice<u8>$=+0x28>
    2460:      	mov	x0, #0x1                ; =1
    2464:      	b	0x2490 <_coil.core.Eq$slice<u8>$=+0x50>
    2468:      	lsr	x1, x1, #0
    246c:      	fmov	d31, x1
    2470:      	mov	x1, x2
    2474:      	fmov	x2, d31
    2478:      	bl	0x2478 <_coil.core.Eq$slice<u8>$=+0x38>
		0000000000002478:  ARM64_RELOC_BRANCH26	_memcmp
    247c:      	lsr	w0, w0, #0
    2480:      	sxtw	x0, w0
    2484:      	cmp	x0, #0x0
    2488:      	cset	w0, eq
    248c:      	ubfx	x0, x0, #0, #8
    2490:      	b	0x2498 <_coil.core.Eq$slice<u8>$=+0x58>
    2494:      	movz	x0, #0x0, lsl #48
    2498:      	ldr	x29, [sp]
    249c:      	ldr	x30, [sp, #0x8]
    24a0:      	add	sp, sp, #0x10
    24a4:      	ret

00000000000024a8 <_stogir.node.opcode>:
    24a8:      	ldr	w0, [x0]
    24ac:      	uxtb	w0, w0
    24b0:      	ret

00000000000024b4 <_stogir.opcode.valid?>:
    24b4:      	sxtw	x0, w0
    24b8:      	cmp	x0, #0x0
    24bc:      	b.lt	0x24d0 <_stogir.opcode.valid?+0x1c>
    24c0:      	cmp	x0, #0x83
    24c4:      	cset	w0, lt
    24c8:      	ubfx	x0, x0, #0, #8
    24cc:      	b	0x24d4 <_stogir.opcode.valid?+0x20>
    24d0:      	movz	x0, #0x0, lsl #48
    24d4:      	ret

00000000000024d8 <_stogir.node.type-id>:
    24d8:      	ldr	w0, [x0]
    24dc:      	ubfx	x0, x0, #8, #8
    24e0:      	ret

00000000000024e4 <_stogir.types.valid?>:
    24e4:      	sxtw	x0, w0
    24e8:      	cmp	x0, #0x0
    24ec:      	b.lt	0x2500 <_stogir.types.valid?+0x1c>
    24f0:      	cmp	x0, #0xd
    24f4:      	b.gt	0x2500 <_stogir.types.valid?+0x1c>
    24f8:      	mov	x0, #0x1                ; =1
    24fc:      	ret
    2500:      	cmp	x0, #0xf
    2504:      	b.le	0x253c <_stogir.types.valid?+0x58>
    2508:      	cmp	x0, #0x80
    250c:      	b.ge	0x2534 <_stogir.types.valid?+0x50>
    2510:      	and	x0, x0, #0xf
    2514:      	lsr	w0, w0, #0
    2518:      	sxtw	x0, w0
    251c:      	cmp	x0, #0x1
    2520:      	b.lt	0x2544 <_stogir.types.valid?+0x60>
    2524:      	cmp	x0, #0xd
    2528:      	cset	w0, le
    252c:      	ubfx	x0, x0, #0, #8
    2530:      	b	0x2548 <_stogir.types.valid?+0x64>
    2534:      	movz	x0, #0x0, lsl #48
    2538:      	b	0x2540 <_stogir.types.valid?+0x5c>
    253c:      	movz	x0, #0x0, lsl #48
    2540:      	ret
    2544:      	movz	x0, #0x0, lsl #48
    2548:      	b	0x2538 <_stogir.types.valid?+0x54>

000000000000254c <_stogir.opcode.operand-slots>:
    254c:      	sxtw	x0, w0
    2550:      	cmp	x0, #0x0
    2554:      	b.lt	0x2580 <_stogir.opcode.operand-slots+0x34>
    2558:      	cmp	x0, #0x83
    255c:      	b.ge	0x2580 <_stogir.opcode.operand-slots+0x34>
    2560:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002560:  ARM64_RELOC_PAGE21	l_stogir.334
    2564:      	ldr	x16, [x16]
		0000000000002564:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    2568:      	orr	x1, x16, xzr
    256c:      	lsr	x0, x0, #0
    2570:      	add	x0, x0, x1
    2574:      	ldrsb	w0, [x0]
    2578:      	sxtb	x0, w0
    257c:      	b	0x2584 <_stogir.opcode.operand-slots+0x38>
    2580:      	mov	x0, #-0x2               ; =-2
    2584:      	ret

0000000000002588 <_stogir.opcode.input-count>:
    2588:      	sxtw	x0, w0
    258c:      	cmp	x0, #0x0
    2590:      	b.lt	0x25bc <_stogir.opcode.input-count+0x34>
    2594:      	cmp	x0, #0x83
    2598:      	b.ge	0x25bc <_stogir.opcode.input-count+0x34>
    259c:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		000000000000259c:  ARM64_RELOC_PAGE21	l_stogir.335
    25a0:      	ldr	x16, [x16]
		00000000000025a0:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    25a4:      	orr	x1, x16, xzr
    25a8:      	lsr	x0, x0, #0
    25ac:      	add	x0, x0, x1
    25b0:      	ldrsb	w0, [x0]
    25b4:      	sxtb	x0, w0
    25b8:      	b	0x25c0 <_stogir.opcode.input-count+0x38>
    25bc:      	mov	x0, #-0x2               ; =-2
    25c0:      	ret

00000000000025c4 <_stogir.node.auxiliary>:
    25c4:      	ldr	w0, [x0]
    25c8:      	ubfx	x0, x0, #16, #16
    25cc:      	ret

00000000000025d0 <_stogir.opcode.operand-code>:
    25d0:      	sxtw	x0, w0
    25d4:      	cmp	x0, #0x0
    25d8:      	b.lt	0x2618 <_stogir.opcode.operand-code+0x48>
    25dc:      	cmp	x0, #0x83
    25e0:      	b.ge	0x2618 <_stogir.opcode.operand-code+0x48>
    25e4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		00000000000025e4:  ARM64_RELOC_PAGE21	l_stogir.336
    25e8:      	ldr	x16, [x16]
		00000000000025e8:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    25ec:      	orr	x2, x16, xzr
    25f0:      	lsl	x0, x0, #2
    25f4:      	sxtw	x1, w1
    25f8:      	add	x0, x0, x2
    25fc:      	ldr	w0, [x0]
    2600:      	cmp	x1, #0x0
    2604:      	b.le	0x264c <_stogir.opcode.operand-code+0x7c>
    2608:      	cmp	x1, #0x4
    260c:      	b.le	0x2620 <_stogir.opcode.operand-code+0x50>
    2610:      	mov	x1, #0x4                ; =4
    2614:      	b	0x262c <_stogir.opcode.operand-code+0x5c>
    2618:      	movz	x0, #0x0, lsl #48
    261c:      	ret
    2620:      	sub	x1, x1, #0x1
    2624:      	lsr	w1, w1, #0
    2628:      	sxtw	x1, w1
    262c:      	lsl	x1, x1, #2
    2630:      	lsr	w1, w1, #0
    2634:      	ubfx	x1, x1, #0, #32
    2638:      	lsr	x0, x0, x1
    263c:      	lsr	w0, w0, #0
    2640:      	and	x0, x0, #0xf
    2644:      	lsr	w0, w0, #0
    2648:      	b	0x2650 <_stogir.opcode.operand-code+0x80>
    264c:      	movz	x0, #0x0, lsl #48
    2650:      	ret

0000000000002654 <_stogir.graph.operand>:
    2654:      	sub	sp, sp, #0x10
    2658:      	mov	x3, sp
    265c:      	sxtw	x1, w1
    2660:      	cmp	x1, #0x0
    2664:      	b.le	0x26a8 <_stogir.graph.operand+0x54>
    2668:      	lsl	x4, x1, #2
    266c:      	ldr	x5, [x0, #0x8]
    2670:      	cmp	x1, x5
    2674:      	b.ge	0x26dc <_stogir.graph.operand+0x88>
    2678:      	add	x5, x0, #0x78
    267c:      	ldr	x5, [x5, #0x8]
    2680:      	cmp	x1, x5
    2684:      	b.ge	0x26d4 <_stogir.graph.operand+0x80>
    2688:      	ldr	x5, [x0, #0x78]
    268c:      	add	x5, x4, x5
    2690:      	ldr	w5, [x5]
    2694:      	sxtw	x5, w5
    2698:      	cmp	x5, #0x0
    269c:      	cset	w5, ge
    26a0:      	ubfx	x5, x5, #0, #8
    26a4:      	b	0x26d8 <_stogir.graph.operand+0x84>
    26a8:      	movz	x0, #0x0, lsl #48
    26ac:      	movz	x1, #0x0, lsl #48
    26b0:      	str	x0, [x3]
    26b4:      	str	x1, [x3, #0x8]
    26b8:      	ldr	x0, [sp]
    26bc:      	ldr	x1, [sp, #0x8]
    26c0:      	add	sp, sp, #0x10
    26c4:      	ret
    26c8:      	movz	x0, #0x0, lsl #48
    26cc:      	movz	x1, #0x0, lsl #48
    26d0:      	b	0x26b0 <_stogir.graph.operand+0x5c>
    26d4:      	movz	x5, #0x0, lsl #48
    26d8:      	b	0x26e0 <_stogir.graph.operand+0x8c>
    26dc:      	movz	x5, #0x0, lsl #48
    26e0:      	cmp	x5, #0x0
    26e4:      	b.eq	0x26a8 <_stogir.graph.operand+0x54>
    26e8:      	sxtw	x2, w2
    26ec:      	cmp	x2, #0x1
    26f0:      	b.lt	0x26c8 <_stogir.graph.operand+0x74>
    26f4:      	ldr	x5, [x0, #0x78]
    26f8:      	add	x4, x4, x5
    26fc:      	ldr	w4, [x4]
    2700:      	sxtw	x4, w4
    2704:      	cmp	x2, x4
    2708:      	b.gt	0x26c8 <_stogir.graph.operand+0x74>
    270c:      	asr	x16, x2, #63
    2710:      	lsr	x16, x16, #62
    2714:      	add	x4, x2, x16
    2718:      	asr	x4, x4, #2
    271c:      	asr	x16, x2, #63
    2720:      	lsr	x16, x16, #62
    2724:      	add	x2, x2, x16
    2728:      	and	x2, x2, #0x3
    272c:      	sub	x2, x2, x16
    2730:      	ldr	x0, [x0]
    2734:      	add	x1, x4, x1
    2738:      	lsl	x2, x2, #2
    273c:      	lsl	x1, x1, #4
    2740:      	add	x0, x1, x0
    2744:      	add	x0, x2, x0
    2748:      	ldr	w0, [x0]
    274c:      	sxtw	x0, w0
    2750:      	and	x0, x0, #0xffffffff
    2754:      	mov	x1, x0
    2758:      	mov	x0, #0x1                ; =1
    275c:      	b	0x26d0 <_stogir.graph.operand+0x7c>

0000000000002760 <_stogir.graph.borrow-node>:
    2760:      	sxtw	x1, w1
    2764:      	cmp	x1, #0x0
    2768:      	cset	w2, gt
    276c:      	movz	x16, #0x0, lsl #48
    2770:      	sub	x3, x16, x1
    2774:      	sub	x4, x3, #0x1
    2778:      	uxtb	w16, w2
    277c:      	cmp	w16, wzr
    2780:      	b.eq	0x27c4 <_stogir.graph.borrow-node+0x64>
    2784:      	ldr	x3, [x0, #0x8]
    2788:      	cmp	x1, x3
    278c:      	b.ge	0x2818 <_stogir.graph.borrow-node+0xb8>
    2790:      	add	x3, x0, #0x78
    2794:      	ldr	x3, [x3, #0x8]
    2798:      	cmp	x1, x3
    279c:      	b.ge	0x2860 <_stogir.graph.borrow-node+0x100>
    27a0:      	lsl	x3, x1, #2
    27a4:      	ldr	x5, [x0, #0x78]
    27a8:      	add	x3, x3, x5
    27ac:      	ldr	w3, [x3]
    27b0:      	sxtw	x3, w3
    27b4:      	cmp	x3, #0x0
    27b8:      	cset	w3, ge
    27bc:      	ubfx	x3, x3, #0, #8
    27c0:      	b	0x2864 <_stogir.graph.borrow-node+0x104>
    27c4:      	cmp	x1, #0x0
    27c8:      	b.ge	0x2820 <_stogir.graph.borrow-node+0xc0>
    27cc:      	add	x5, x0, #0x28
    27d0:      	add	x6, x0, #0x50
    27d4:      	ldr	x5, [x5, #0x8]
    27d8:      	ldr	x6, [x6, #0x8]
    27dc:      	cmp	x5, x6
    27e0:      	b.ne	0x2810 <_stogir.graph.borrow-node+0xb0>
    27e4:      	cmp	x3, x5
    27e8:      	b.gt	0x2868 <_stogir.graph.borrow-node+0x108>
    27ec:      	lsl	x3, x4, #2
    27f0:      	ldr	x5, [x0, #0x50]
    27f4:      	add	x3, x3, x5
    27f8:      	ldr	w3, [x3]
    27fc:      	sxtw	x3, w3
    2800:      	cmp	x3, #0x0
    2804:      	cset	w3, gt
    2808:      	ubfx	x3, x3, #0, #8
    280c:      	b	0x286c <_stogir.graph.borrow-node+0x10c>
    2810:      	movz	x3, #0x0, lsl #48
    2814:      	b	0x2824 <_stogir.graph.borrow-node+0xc4>
    2818:      	movz	x3, #0x0, lsl #48
    281c:      	b	0x2824 <_stogir.graph.borrow-node+0xc4>
    2820:      	movz	x3, #0x0, lsl #48
    2824:      	cmp	x3, #0x0
    2828:      	b.eq	0x2858 <_stogir.graph.borrow-node+0xf8>
    282c:      	uxtb	w16, w2
    2830:      	cmp	w16, wzr
    2834:      	b.eq	0x2848 <_stogir.graph.borrow-node+0xe8>
    2838:      	lsl	x1, x1, #4
    283c:      	ldr	x0, [x0]
    2840:      	add	x0, x1, x0
    2844:      	b	0x2854 <_stogir.graph.borrow-node+0xf4>
    2848:      	lsl	x1, x4, #4
    284c:      	ldr	x0, [x0, #0x28]
    2850:      	add	x0, x1, x0
    2854:      	b	0x285c <_stogir.graph.borrow-node+0xfc>
    2858:      	movz	x0, #0x0, lsl #48
    285c:      	ret
    2860:      	movz	x3, #0x0, lsl #48
    2864:      	b	0x281c <_stogir.graph.borrow-node+0xbc>
    2868:      	movz	x3, #0x0, lsl #48
    286c:      	b	0x2814 <_stogir.graph.borrow-node+0xb4>

0000000000002870 <_stogir.strings.lookup>:
    2870:      	sxtw	x1, w1
    2874:      	cmp	x1, #0x0
    2878:      	b.le	0x28f4 <_stogir.strings.lookup+0x84>
    287c:      	add	x2, x0, #0x28
    2880:      	ldr	x2, [x2, #0x8]
    2884:      	cmp	x1, x2
    2888:      	b.gt	0x28f4 <_stogir.strings.lookup+0x84>
    288c:      	sub	x1, x1, #0x1
    2890:      	mov	x17, #0x18              ; =24
    2894:      	mul	x1, x1, x17
    2898:      	ldr	x2, [x0, #0x28]
    289c:      	add	x1, x1, x2
    28a0:      	ldr	x2, [x1]
    28a4:      	ldr	x1, [x1, #0x8]
    28a8:      	ldr	x3, [x0, #0x8]
    28ac:      	cmp	x2, #0x0
    28b0:      	b.lt	0x2910 <_stogir.strings.lookup+0xa0>
    28b4:      	cmp	x2, x3
    28b8:      	b.gt	0x2910 <_stogir.strings.lookup+0xa0>
    28bc:      	cmp	x1, #0x0
    28c0:      	b.lt	0x2910 <_stogir.strings.lookup+0xa0>
    28c4:      	sub	x3, x3, x2
    28c8:      	cmp	x1, x3
    28cc:      	b.gt	0x2910 <_stogir.strings.lookup+0xa0>
    28d0:      	add	x1, x1, x2
    28d4:      	lsr	x3, x2, #0
    28d8:      	sub	x1, x1, x2
    28dc:      	ldr	x0, [x0]
    28e0:      	add	x0, x3, x0
    28e4:      	mov	x2, x1
    28e8:      	mov	x1, x0
    28ec:      	mov	x0, #0x1                ; =1
    28f0:      	b	0x291c <_stogir.strings.lookup+0xac>
    28f4:      	movz	x0, #0x0, lsl #48
    28f8:      	movz	x1, #0x0, lsl #48
    28fc:      	movz	x2, #0x0, lsl #48
    2900:      	str	x0, [x8]
    2904:      	str	x1, [x8, #0x8]
    2908:      	str	x2, [x8, #0x10]
    290c:      	ret
    2910:      	movz	x0, #0x0, lsl #48
    2914:      	movz	x1, #0x0, lsl #48
    2918:      	movz	x2, #0x0, lsl #48
    291c:      	b	0x2900 <_stogir.strings.lookup+0x90>

0000000000002920 <_stogir.uses.edge-code?>:
    2920:      	ubfx	x0, x0, #0, #32
    2924:      	cmp	x0, #0xf
    2928:      	b.hs	0x295c <_stogir.uses.edge-code?+0x3c>
    292c:      	mov	x16, #0x1               ; =1
    2930:      	lsl	x0, x16, x0
    2934:      	lsr	w0, w0, #0
    2938:      	mov	x17, #0x5e1c            ; =24092
    293c:      	and	x0, x0, x17
    2940:      	lsr	w0, w0, #0
    2944:      	cmp	x0, #0x0
    2948:      	cset	w0, eq
    294c:      	uxtb	w16, w0
    2950:      	cmp	w16, wzr
    2954:      	cset	x0, eq
    2958:      	b	0x2960 <_stogir.uses.edge-code?+0x40>
    295c:      	movz	x0, #0x0, lsl #48
    2960:      	ret

0000000000002964 <_stogir.graph.contains?>:
    2964:      	sxtw	x1, w1
    2968:      	cmp	x1, #0x0
    296c:      	b.le	0x29b0 <_stogir.graph.contains?+0x4c>
    2970:      	ldr	x2, [x0, #0x8]
    2974:      	cmp	x1, x2
    2978:      	b.ge	0x2a10 <_stogir.graph.contains?+0xac>
    297c:      	add	x2, x0, #0x78
    2980:      	ldr	x2, [x2, #0x8]
    2984:      	cmp	x1, x2
    2988:      	b.ge	0x2a20 <_stogir.graph.contains?+0xbc>
    298c:      	lsl	x1, x1, #2
    2990:      	ldr	x0, [x0, #0x78]
    2994:      	add	x0, x1, x0
    2998:      	ldr	w0, [x0]
    299c:      	sxtw	x0, w0
    29a0:      	cmp	x0, #0x0
    29a4:      	cset	w0, ge
    29a8:      	ubfx	x0, x0, #0, #8
    29ac:      	b	0x2a24 <_stogir.graph.contains?+0xc0>
    29b0:      	cmp	x1, #0x0
    29b4:      	b.ge	0x2a18 <_stogir.graph.contains?+0xb4>
    29b8:      	add	x2, x0, #0x28
    29bc:      	add	x3, x0, #0x50
    29c0:      	ldr	x2, [x2, #0x8]
    29c4:      	ldr	x3, [x3, #0x8]
    29c8:      	cmp	x2, x3
    29cc:      	b.ne	0x2a30 <_stogir.graph.contains?+0xcc>
    29d0:      	movz	x16, #0x0, lsl #48
    29d4:      	sub	x3, x16, x1
    29d8:      	cmp	x3, x2
    29dc:      	b.gt	0x2a28 <_stogir.graph.contains?+0xc4>
    29e0:      	movz	x16, #0x0, lsl #48
    29e4:      	sub	x1, x16, x1
    29e8:      	sub	x1, x1, #0x1
    29ec:      	lsl	x1, x1, #2
    29f0:      	ldr	x0, [x0, #0x50]
    29f4:      	add	x0, x1, x0
    29f8:      	ldr	w0, [x0]
    29fc:      	sxtw	x0, w0
    2a00:      	cmp	x0, #0x0
    2a04:      	cset	w0, gt
    2a08:      	ubfx	x0, x0, #0, #8
    2a0c:      	b	0x2a2c <_stogir.graph.contains?+0xc8>
    2a10:      	movz	x0, #0x0, lsl #48
    2a14:      	b	0x2a24 <_stogir.graph.contains?+0xc0>
    2a18:      	movz	x0, #0x0, lsl #48
    2a1c:      	b	0x2a2c <_stogir.graph.contains?+0xc8>
    2a20:      	movz	x0, #0x0, lsl #48
    2a24:      	b	0x2a2c <_stogir.graph.contains?+0xc8>
    2a28:      	movz	x0, #0x0, lsl #48
    2a2c:      	ret
    2a30:      	movz	x0, #0x0, lsl #48
    2a34:      	b	0x2a2c <_stogir.graph.contains?+0xc8>

0000000000002a38 <_stogir.opcode.optional-reference?>:
    2a38:      	sub	sp, sp, #0x30
    2a3c:      	str	x29, [sp]
    2a40:      	str	x30, [sp, #0x8]
    2a44:      	mov	x29, sp
    2a48:      	str	x19, [sp, #0x10]
    2a4c:      	str	x20, [sp, #0x18]
    2a50:      	str	x21, [sp, #0x20]
    2a54:      	lsr	w0, w0, #0
    2a58:      	lsr	w2, w2, #0
    2a5c:      	mov	w19, w0
    2a60:      	mov	w20, w1
    2a64:      	mov	w1, w2
    2a68:      	mov	w21, w2
    2a6c:      	bl	0x2a6c <_stogir.opcode.optional-reference?+0x34>
		0000000000002a6c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2a70:      	lsr	w0, w0, #0
    2a74:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002a74:  ARM64_RELOC_PAGE21	l_stogir.337
    2a78:      	ldr	x16, [x16]
		0000000000002a78:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    2a7c:      	ldr	w1, [x16]
    2a80:      	cmp	x0, x1
    2a84:      	b.ne	0x2ab0 <_stogir.opcode.optional-reference?+0x78>
    2a88:      	mov	x0, #0x1                ; =1
    2a8c:      	b	0x2a94 <_stogir.opcode.optional-reference?+0x5c>
    2a90:      	movz	x0, #0x0, lsl #48
    2a94:      	ldr	x19, [sp, #0x10]
    2a98:      	ldr	x20, [sp, #0x18]
    2a9c:      	ldr	x21, [sp, #0x20]
    2aa0:      	ldr	x29, [sp]
    2aa4:      	ldr	x30, [sp, #0x8]
    2aa8:      	add	sp, sp, #0x30
    2aac:      	ret
    2ab0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002ab0:  ARM64_RELOC_PAGE21	l_stogir.338
    2ab4:      	ldr	x16, [x16]
		0000000000002ab4:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    2ab8:      	ldr	w1, [x16]
    2abc:      	cmp	x0, x1
    2ac0:      	b.ne	0x2acc <_stogir.opcode.optional-reference?+0x94>
    2ac4:      	mov	x0, #0x1                ; =1
    2ac8:      	b	0x2a94 <_stogir.opcode.optional-reference?+0x5c>
    2acc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002acc:  ARM64_RELOC_PAGE21	l_stogir.339
    2ad0:      	ldr	x16, [x16]
		0000000000002ad0:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2ad4:      	ldr	w1, [x16]
    2ad8:      	cmp	x0, x1
    2adc:      	b.ne	0x2ae8 <_stogir.opcode.optional-reference?+0xb0>
    2ae0:      	mov	x0, #0x1                ; =1
    2ae4:      	b	0x2a94 <_stogir.opcode.optional-reference?+0x5c>
    2ae8:      	sxtw	x19, w19
    2aec:      	cmp	x19, #0x78
    2af0:      	b.ne	0x2b14 <_stogir.opcode.optional-reference?+0xdc>
    2af4:      	sxtw	x20, w20
    2af8:      	cmp	x20, #0x0
    2afc:      	b.ne	0x2a90 <_stogir.opcode.optional-reference?+0x58>
    2b00:      	sxtw	x21, w21
    2b04:      	cmp	x21, #0x2
    2b08:      	cset	w0, eq
    2b0c:      	ubfx	x0, x0, #0, #8
    2b10:      	b	0x2a94 <_stogir.opcode.optional-reference?+0x5c>
    2b14:      	movz	x0, #0x0, lsl #48
    2b18:      	b	0x2a94 <_stogir.opcode.optional-reference?+0x5c>

0000000000002b1c <_stogir.integer-binary.operation?>:
    2b1c:      	sxtw	x0, w0
    2b20:      	cmp	x0, #0x1a
    2b24:      	b.lt	0x2b38 <_stogir.integer-binary.operation?+0x1c>
    2b28:      	cmp	x0, #0x1e
    2b2c:      	b.gt	0x2b38 <_stogir.integer-binary.operation?+0x1c>
    2b30:      	mov	x0, #0x1                ; =1
    2b34:      	b	0x2b6c <_stogir.integer-binary.operation?+0x50>
    2b38:      	cmp	x0, #0x2e
    2b3c:      	b.lt	0x2b50 <_stogir.integer-binary.operation?+0x34>
    2b40:      	cmp	x0, #0x35
    2b44:      	b.gt	0x2b50 <_stogir.integer-binary.operation?+0x34>
    2b48:      	mov	x0, #0x1                ; =1
    2b4c:      	b	0x2b6c <_stogir.integer-binary.operation?+0x50>
    2b50:      	cmp	x0, #0x3a
    2b54:      	b.ne	0x2b60 <_stogir.integer-binary.operation?+0x44>
    2b58:      	mov	x0, #0x1                ; =1
    2b5c:      	b	0x2b6c <_stogir.integer-binary.operation?+0x50>
    2b60:      	cmp	x0, #0x3b
    2b64:      	cset	w0, eq
    2b68:      	ubfx	x0, x0, #0, #8
    2b6c:      	ret

0000000000002b70 <_stogir.integer-unary.operation?>:
    2b70:      	sxtw	x0, w0
    2b74:      	cmp	x0, #0x1f
    2b78:      	b.ne	0x2b94 <_stogir.integer-unary.operation?+0x24>
    2b7c:      	mov	x0, #0x1                ; =1
    2b80:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>
    2b84:      	cmp	x0, #0x39
    2b88:      	cset	w0, eq
    2b8c:      	ubfx	x0, x0, #0, #8
    2b90:      	ret
    2b94:      	cmp	x0, #0x20
    2b98:      	b.ne	0x2ba4 <_stogir.integer-unary.operation?+0x34>
    2b9c:      	mov	x0, #0x1                ; =1
    2ba0:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>
    2ba4:      	cmp	x0, #0x2d
    2ba8:      	b.ne	0x2bb4 <_stogir.integer-unary.operation?+0x44>
    2bac:      	mov	x0, #0x1                ; =1
    2bb0:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>
    2bb4:      	cmp	x0, #0x36
    2bb8:      	b.ne	0x2bc4 <_stogir.integer-unary.operation?+0x54>
    2bbc:      	mov	x0, #0x1                ; =1
    2bc0:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>
    2bc4:      	cmp	x0, #0x37
    2bc8:      	b.ne	0x2bd4 <_stogir.integer-unary.operation?+0x64>
    2bcc:      	mov	x0, #0x1                ; =1
    2bd0:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>
    2bd4:      	cmp	x0, #0x38
    2bd8:      	b.ne	0x2b84 <_stogir.integer-unary.operation?+0x14>
    2bdc:      	mov	x0, #0x1                ; =1
    2be0:      	b	0x2b90 <_stogir.integer-unary.operation?+0x20>

0000000000002be4 <_stogir.verify.classifications>:
    2be4:      	sub	sp, sp, #0xc0
    2be8:      	str	x29, [sp]
    2bec:      	str	x30, [sp, #0x8]
    2bf0:      	mov	x29, sp
    2bf4:      	str	x19, [sp, #0x70]
    2bf8:      	str	x20, [sp, #0x78]
    2bfc:      	str	x21, [sp, #0x80]
    2c00:      	str	x22, [sp, #0x88]
    2c04:      	str	x23, [sp, #0x90]
    2c08:      	str	x24, [sp, #0x98]
    2c0c:      	str	x25, [sp, #0xa0]
    2c10:      	str	x26, [sp, #0xa8]
    2c14:      	str	x27, [sp, #0xb0]
    2c18:      	str	x28, [sp, #0xb8]
    2c1c:      	ldr	w4, [x2]
    2c20:      	orr	x5, x4, xzr
    2c24:      	ubfx	x5, x5, #8, #8
    2c28:      	orr	x19, x5, xzr
    2c2c:      	cmp	x19, #0xf
    2c30:      	b.le	0x2c6c <_stogir.verify.classifications+0x88>
    2c34:      	cmp	x19, #0x80
    2c38:      	b.ge	0x2c60 <_stogir.verify.classifications+0x7c>
    2c3c:      	and	x5, x19, #0xf
    2c40:      	lsr	w5, w5, #0
    2c44:      	sxtw	x5, w5
    2c48:      	cmp	x5, #0x1
    2c4c:      	b.lt	0x322c <_stogir.verify.classifications+0x648>
    2c50:      	cmp	x5, #0xd
    2c54:      	cset	w5, le
    2c58:      	ubfx	x5, x5, #0, #8
    2c5c:      	b	0x3230 <_stogir.verify.classifications+0x64c>
    2c60:      	movz	x5, #0x0, lsl #48
    2c64:      	mov	x20, x5
    2c68:      	b	0x2c70 <_stogir.verify.classifications+0x8c>
    2c6c:      	movz	x20, #0x0, lsl #48
    2c70:      	uxtb	w21, w4
    2c74:      	orr	x4, x21, xzr
    2c78:      	lsr	w22, w4, #0
    2c7c:      	mov	x23, x0
    2c80:      	mov	w0, w22
    2c84:      	mov	w24, w1
    2c88:      	mov	x25, x2
    2c8c:      	mov	w26, w3
    2c90:      	bl	0x2c90 <_stogir.verify.classifications+0xac>
		0000000000002c90:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2c94:      	cmp	x0, #0x0
    2c98:      	b.eq	0x2cb8 <_stogir.verify.classifications+0xd4>
    2c9c:      	cmp	x20, #0x0
    2ca0:      	cset	w0, ne
    2ca4:      	uxtb	w16, w0
    2ca8:      	cmp	w16, wzr
    2cac:      	cset	x0, eq
    2cb0:      	mov	x27, x0
    2cb4:      	b	0x2cbc <_stogir.verify.classifications+0xd8>
    2cb8:      	movz	x27, #0x0, lsl #48
    2cbc:      	cmp	x27, #0x0
    2cc0:      	cset	w28, ne
    2cc4:      	uxtb	w16, w28
    2cc8:      	cmp	w16, wzr
    2ccc:      	b.eq	0x2d00 <_stogir.verify.classifications+0x11c>
    2cd0:      	ldr	w0, [x25, #0x4]
    2cd4:      	lsr	w0, w0, #0
    2cd8:      	mov	w1, w0
    2cdc:      	mov	x0, x23
    2ce0:      	bl	0x2ce0 <_stogir.verify.classifications+0xfc>
		0000000000002ce0:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2ce4:      	cmp	x0, #0x0
    2ce8:      	b.ne	0x2cf4 <_stogir.verify.classifications+0x110>
    2cec:      	movn	x0, #0x0, lsl #48
    2cf0:      	b	0x2cfc <_stogir.verify.classifications+0x118>
    2cf4:      	ldr	w0, [x0]
    2cf8:      	ubfx	x0, x0, #8, #8
    2cfc:      	b	0x2d04 <_stogir.verify.classifications+0x120>
    2d00:      	movn	x0, #0x0, lsl #48
    2d04:      	lsr	w0, w0, #0
    2d08:      	sxtw	x0, w0
    2d0c:      	cmp	x0, #0xf
    2d10:      	cset	w1, gt
    2d14:      	cmp	x0, #0x80
    2d18:      	cset	w2, lt
    2d1c:      	and	x3, x0, #0xf
    2d20:      	lsr	w3, w3, #0
    2d24:      	sxtw	x3, w3
    2d28:      	cmp	x3, #0x1
    2d2c:      	cset	w4, ge
    2d30:      	cmp	x3, #0xd
    2d34:      	cset	w3, le
    2d38:      	cmp	x27, #0x0
    2d3c:      	b.eq	0x2d94 <_stogir.verify.classifications+0x1b0>
    2d40:      	uxtb	w16, w1
    2d44:      	cmp	w16, wzr
    2d48:      	b.eq	0x3234 <_stogir.verify.classifications+0x650>
    2d4c:      	uxtb	w16, w2
    2d50:      	cmp	w16, wzr
    2d54:      	b.eq	0x3234 <_stogir.verify.classifications+0x650>
    2d58:      	uxtb	w16, w4
    2d5c:      	cmp	w16, wzr
    2d60:      	b.eq	0x3234 <_stogir.verify.classifications+0x650>
    2d64:      	uxtb	w16, w3
    2d68:      	cmp	w16, wzr
    2d6c:      	b.eq	0x3234 <_stogir.verify.classifications+0x650>
    2d70:      	movz	x0, #0x0, lsl #48
    2d74:      	b	0x2d7c <_stogir.verify.classifications+0x198>
    2d78:      	mov	x0, #0x1                ; =1
    2d7c:      	mov	x19, x0
    2d80:      	b	0x2d98 <_stogir.verify.classifications+0x1b4>
    2d84:      	movz	x3, #0x0, lsl #48
    2d88:      	b	0x2dd4 <_stogir.verify.classifications+0x1f0>
    2d8c:      	movz	x0, #0x0, lsl #48
    2d90:      	b	0x2ddc <_stogir.verify.classifications+0x1f8>
    2d94:      	movz	x19, #0x0, lsl #48
    2d98:      	sxtw	x26, w26
    2d9c:      	ubfx	x21, x3, #0, #8
    2da0:      	add	x27, x23, #0x78
    2da4:      	add	x0, x23, #0x28
    2da8:      	add	x3, x23, #0x50
    2dac:      	sxtw	x24, w24
    2db0:      	add	x5, x23, #0x78
    2db4:      	cmp	x24, #0x0
    2db8:      	cset	w6, le
    2dbc:      	lsl	x7, x24, #2
    2dc0:      	mov	x8, #0x1                ; =1
    2dc4:      	b	0x2ecc <_stogir.verify.classifications+0x2e8>
    2dc8:      	movz	x3, #0x0, lsl #48
    2dcc:      	b	0x2df4 <_stogir.verify.classifications+0x210>
    2dd0:      	movz	x3, #0x0, lsl #48
    2dd4:      	b	0x2e04 <_stogir.verify.classifications+0x220>
    2dd8:      	movz	x0, #0x0, lsl #48
    2ddc:      	ldr	x5, [sp, #0x58]
    2de0:      	ldr	x6, [sp, #0x50]
    2de4:      	ldr	x8, [sp, #0x48]
    2de8:      	ldr	x1, [sp, #0x60]
    2dec:      	b	0x2e84 <_stogir.verify.classifications+0x2a0>
    2df0:      	movz	x3, #0x0, lsl #48
    2df4:      	ldr	x6, [sp, #0x50]
    2df8:      	ldr	x8, [sp, #0x48]
    2dfc:      	b	0x2e04 <_stogir.verify.classifications+0x220>
    2e00:      	movz	x3, #0x0, lsl #48
    2e04:      	cmp	x3, #0x0
    2e08:      	b.eq	0x2e38 <_stogir.verify.classifications+0x254>
    2e0c:      	uxtb	w16, w2
    2e10:      	cmp	w16, wzr
    2e14:      	b.eq	0x2e28 <_stogir.verify.classifications+0x244>
    2e18:      	lsl	x0, x0, #4
    2e1c:      	ldr	x2, [x23]
    2e20:      	add	x0, x0, x2
    2e24:      	b	0x2e34 <_stogir.verify.classifications+0x250>
    2e28:      	lsl	x0, x4, #4
    2e2c:      	ldr	x2, [x23, #0x28]
    2e30:      	add	x0, x0, x2
    2e34:      	b	0x2e3c <_stogir.verify.classifications+0x258>
    2e38:      	movz	x0, #0x0, lsl #48
    2e3c:      	cmp	x0, #0x0
    2e40:      	b.eq	0x2e80 <_stogir.verify.classifications+0x29c>
    2e44:      	ldr	w0, [x0]
    2e48:      	ubfx	x0, x0, #8, #8
    2e4c:      	cmp	x0, #0xf
    2e50:      	b.le	0x2e80 <_stogir.verify.classifications+0x29c>
    2e54:      	cmp	x0, #0x80
    2e58:      	b.ge	0x2e80 <_stogir.verify.classifications+0x29c>
    2e5c:      	and	x0, x0, #0xf
    2e60:      	lsr	w0, w0, #0
    2e64:      	sxtw	x0, w0
    2e68:      	cmp	x0, #0x1
    2e6c:      	b.lt	0x2e80 <_stogir.verify.classifications+0x29c>
    2e70:      	cmp	x0, #0xd
    2e74:      	b.gt	0x2e80 <_stogir.verify.classifications+0x29c>
    2e78:      	mov	x0, #0x1                ; =1
    2e7c:      	b	0x2e84 <_stogir.verify.classifications+0x2a0>
    2e80:      	ldr	x0, [sp, #0x40]
    2e84:      	add	x2, x27, #0x1
    2e88:      	lsr	w2, w2, #0
    2e8c:      	sxtw	x2, w2
    2e90:      	mov	w4, w26
    2e94:      	ldr	x26, [sp, #0x30]
    2e98:      	mov	x27, x5
    2e9c:      	mov	x3, x8
    2ea0:      	mov	x7, x1
    2ea4:      	mov	w1, w21
    2ea8:      	ldr	x21, [sp, #0x20]
    2eac:      	mov	x5, x20
    2eb0:      	mov	x20, x0
    2eb4:      	mov	x0, x6
    2eb8:      	mov	w6, w19
    2ebc:      	ldr	x19, [sp, #0x38]
    2ec0:      	mov	x8, x2
    2ec4:      	mov	w2, w22
    2ec8:      	ldr	w22, [sp, #0x28]
    2ecc:      	cmp	x20, #0x0
    2ed0:      	b.ne	0x3298 <_stogir.verify.classifications+0x6b4>
    2ed4:      	cmp	x8, x26
    2ed8:      	b.gt	0x32a4 <_stogir.verify.classifications+0x6c0>
    2edc:      	lsr	w9, w8, #0
    2ee0:      	str	x0, [sp, #0x50]
    2ee4:      	mov	w0, w22
    2ee8:      	str	x3, [sp, #0x48]
    2eec:      	str	x7, [sp, #0x60]
    2ef0:      	str	w9, [sp, #0x68]
    2ef4:      	str	x21, [sp, #0x20]
    2ef8:      	mov	w21, w1
    2efc:      	mov	w1, w9
    2f00:      	str	w22, [sp, #0x28]
    2f04:      	mov	w22, w2
    2f08:      	str	x26, [sp, #0x30]
    2f0c:      	mov	w26, w4
    2f10:      	str	x19, [sp, #0x38]
    2f14:      	mov	w19, w6
    2f18:      	str	x20, [sp, #0x40]
    2f1c:      	mov	x20, x5
    2f20:      	str	x27, [sp, #0x58]
    2f24:      	mov	x27, x8
    2f28:      	bl	0x2f28 <_stogir.verify.classifications+0x344>
		0000000000002f28:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2f2c:      	lsr	w0, w0, #0
    2f30:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002f30:  ARM64_RELOC_PAGE21	l_stogir.340
    2f34:      	ldr	x16, [x16]
		0000000000002f34:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    2f38:      	ldr	w1, [x16]
    2f3c:      	cmp	x0, x1
    2f40:      	b.eq	0x2f70 <_stogir.verify.classifications+0x38c>
    2f44:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x123c>
		0000000000002f44:  ARM64_RELOC_PAGE21	l_stogir.341
    2f48:      	ldr	x16, [x16]
		0000000000002f48:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    2f4c:      	ldr	w1, [x16]
    2f50:      	cmp	x0, x1
    2f54:      	b.eq	0x2f70 <_stogir.verify.classifications+0x38c>
    2f58:      	ldr	x5, [sp, #0x58]
    2f5c:      	ldr	x6, [sp, #0x50]
    2f60:      	ldr	x8, [sp, #0x48]
    2f64:      	ldr	x1, [sp, #0x60]
    2f68:      	ldr	x0, [sp, #0x40]
    2f6c:      	b	0x2e84 <_stogir.verify.classifications+0x2a0>
    2f70:      	cmp	x27, #0x1
    2f74:      	b.ne	0x2fb0 <_stogir.verify.classifications+0x3cc>
    2f78:      	uxtb	w16, w28
    2f7c:      	cmp	w16, wzr
    2f80:      	b.eq	0x2fb0 <_stogir.verify.classifications+0x3cc>
    2f84:      	uxtb	w16, w21
    2f88:      	cmp	w16, wzr
    2f8c:      	b.eq	0x2dd8 <_stogir.verify.classifications+0x1f4>
    2f90:      	uxtb	w16, w22
    2f94:      	cmp	w16, wzr
    2f98:      	b.eq	0x2d8c <_stogir.verify.classifications+0x1a8>
    2f9c:      	uxtb	w16, w26
    2fa0:      	cmp	w16, wzr
    2fa4:      	b.eq	0x3164 <_stogir.verify.classifications+0x580>
    2fa8:      	ldr	x0, [sp, #0x20]
    2fac:      	b	0x3168 <_stogir.verify.classifications+0x584>
    2fb0:      	cmp	x27, #0x1
    2fb4:      	b.ne	0x302c <_stogir.verify.classifications+0x448>
    2fb8:      	ldr	w0, [x25, #0x4]
    2fbc:      	sxtw	x0, w0
    2fc0:      	ldr	x1, [sp, #0x60]
    2fc4:      	lsr	w0, w0, #0
    2fc8:      	sxtw	x0, w0
    2fcc:      	cmp	x0, #0x0
    2fd0:      	cset	w2, gt
    2fd4:      	movz	x16, #0x0, lsl #48
    2fd8:      	sub	x3, x16, x0
    2fdc:      	sub	x4, x3, #0x1
    2fe0:      	uxtb	w16, w2
    2fe4:      	cmp	w16, wzr
    2fe8:      	b.eq	0x32b0 <_stogir.verify.classifications+0x6cc>
    2fec:      	ldr	x3, [x23, #0x8]
    2ff0:      	cmp	x0, x3
    2ff4:      	b.ge	0x32b8 <_stogir.verify.classifications+0x6d4>
    2ff8:      	ldr	x5, [sp, #0x58]
    2ffc:      	ldr	x3, [x5, #0x8]
    3000:      	cmp	x0, x3
    3004:      	b.ge	0x2dc8 <_stogir.verify.classifications+0x1e4>
    3008:      	lsl	x3, x0, #2
    300c:      	ldr	x6, [x23, #0x78]
    3010:      	add	x3, x3, x6
    3014:      	ldr	w3, [x3]
    3018:      	sxtw	x3, w3
    301c:      	cmp	x3, #0x0
    3020:      	cset	w3, ge
    3024:      	ubfx	x3, x3, #0, #8
    3028:      	b	0x2dcc <_stogir.verify.classifications+0x1e8>
    302c:      	cmp	x27, #0x2
    3030:      	b.ne	0x3090 <_stogir.verify.classifications+0x4ac>
    3034:      	ldr	w0, [x25, #0x8]
    3038:      	sxtw	x0, w0
    303c:      	ldr	x1, [sp, #0x60]
    3040:      	b	0x2fc4 <_stogir.verify.classifications+0x3e0>
    3044:      	cmp	x0, #0x0
    3048:      	b.ge	0x32c0 <_stogir.verify.classifications+0x6dc>
    304c:      	ldr	x6, [sp, #0x50]
    3050:      	ldr	x7, [x6, #0x8]
    3054:      	ldr	x8, [sp, #0x48]
    3058:      	ldr	x9, [x8, #0x8]
    305c:      	cmp	x7, x9
    3060:      	b.ne	0x2dd0 <_stogir.verify.classifications+0x1ec>
    3064:      	cmp	x3, x7
    3068:      	b.gt	0x2d84 <_stogir.verify.classifications+0x1a0>
    306c:      	lsl	x3, x4, #2
    3070:      	ldr	x7, [x23, #0x50]
    3074:      	add	x3, x3, x7
    3078:      	ldr	w3, [x3]
    307c:      	sxtw	x3, w3
    3080:      	cmp	x3, #0x0
    3084:      	cset	w3, gt
    3088:      	ubfx	x3, x3, #0, #8
    308c:      	b	0x2d88 <_stogir.verify.classifications+0x1a4>
    3090:      	cmp	x27, #0x3
    3094:      	b.ne	0x3114 <_stogir.verify.classifications+0x530>
    3098:      	ldr	w0, [x25, #0xc]
    309c:      	sxtw	x0, w0
    30a0:      	ldr	x1, [sp, #0x60]
    30a4:      	b	0x3040 <_stogir.verify.classifications+0x45c>
    30a8:      	ldr	x0, [sp, #0x40]
    30ac:      	uxtb	w0, w0
    30b0:      	ldr	x1, [sp, #0x38]
    30b4:      	uxtb	w1, w1
    30b8:      	add	x16, sp, #0x10
    30bc:      	movz	w17, #0x0, lsl #16
    30c0:      	strh	w17, [x16]
    30c4:      	add	x16, sp, #0x10
    30c8:      	strb	w0, [x16]
    30cc:      	add	x16, sp, #0x10
    30d0:      	strb	w1, [x16, #0x1]
    30d4:      	add	x16, sp, #0x10
    30d8:      	ldrh	w0, [x16]
    30dc:      	ldr	x19, [sp, #0x70]
    30e0:      	ldr	x20, [sp, #0x78]
    30e4:      	ldr	x21, [sp, #0x80]
    30e8:      	ldr	x22, [sp, #0x88]
    30ec:      	ldr	x23, [sp, #0x90]
    30f0:      	ldr	x24, [sp, #0x98]
    30f4:      	ldr	x25, [sp, #0xa0]
    30f8:      	ldr	x26, [sp, #0xa8]
    30fc:      	ldr	x27, [sp, #0xb0]
    3100:      	ldr	x28, [sp, #0xb8]
    3104:      	ldr	x29, [sp]
    3108:      	ldr	x30, [sp, #0x8]
    310c:      	add	sp, sp, #0xc0
    3110:      	ret
    3114:      	uxtb	w16, w19
    3118:      	cmp	w16, wzr
    311c:      	b.eq	0x317c <_stogir.verify.classifications+0x598>
    3120:      	ldr	x1, [sp, #0x60]
    3124:      	movz	x0, #0x0, lsl #48
    3128:      	movz	x2, #0x0, lsl #48
    312c:      	lsr	w0, w0, #0
    3130:      	lsr	x16, x0, #0
    3134:      	cmp	x16, #0x1
    3138:      	b.eq	0x3154 <_stogir.verify.classifications+0x570>
    313c:      	b.lo	0x3144 <_stogir.verify.classifications+0x560>
    3140:      	b	0x3158 <_stogir.verify.classifications+0x574>
    3144:      	cmp	x16, #0x0
    3148:      	b.eq	0x3150 <_stogir.verify.classifications+0x56c>
    314c:      	b	0x3158 <_stogir.verify.classifications+0x574>
    3150:      	b	0x315c <_stogir.verify.classifications+0x578>
    3154:      	b	0x316c <_stogir.verify.classifications+0x588>
    3158:      	b	0x3290 <_stogir.verify.classifications+0x6ac>
    315c:      	movz	x0, #0x0, lsl #48
    3160:      	b	0x3178 <_stogir.verify.classifications+0x594>
    3164:      	movz	x0, #0x0, lsl #48
    3168:      	b	0x2d90 <_stogir.verify.classifications+0x1ac>
    316c:      	lsr	w2, w2, #0
    3170:      	sxtw	x2, w2
    3174:      	mov	x0, x2
    3178:      	b	0x30a4 <_stogir.verify.classifications+0x4c0>
    317c:      	ldr	x0, [x23, #0x8]
    3180:      	cmp	x24, x0
    3184:      	b.ge	0x32cc <_stogir.verify.classifications+0x6e8>
    3188:      	ldr	x0, [x20, #0x8]
    318c:      	cmp	x24, x0
    3190:      	b.ge	0x32d4 <_stogir.verify.classifications+0x6f0>
    3194:      	ldr	x0, [x23, #0x78]
    3198:      	ldr	x1, [sp, #0x60]
    319c:      	add	x0, x1, x0
    31a0:      	ldr	w0, [x0]
    31a4:      	sxtw	x0, w0
    31a8:      	cmp	x0, #0x0
    31ac:      	b.lt	0x3124 <_stogir.verify.classifications+0x540>
    31b0:      	ldr	w0, [sp, #0x68]
    31b4:      	sxtw	x0, w0
    31b8:      	cmp	x0, #0x1
    31bc:      	b.lt	0x3274 <_stogir.verify.classifications+0x690>
    31c0:      	ldr	x2, [x23, #0x78]
    31c4:      	add	x2, x1, x2
    31c8:      	ldr	w2, [x2]
    31cc:      	sxtw	x2, w2
    31d0:      	cmp	x0, x2
    31d4:      	b.gt	0x3274 <_stogir.verify.classifications+0x690>
    31d8:      	ldr	x2, [x23]
    31dc:      	asr	x16, x0, #63
    31e0:      	lsr	x16, x16, #62
    31e4:      	add	x3, x0, x16
    31e8:      	asr	x3, x3, #2
    31ec:      	asr	x16, x0, #63
    31f0:      	lsr	x16, x16, #62
    31f4:      	add	x0, x0, x16
    31f8:      	and	x0, x0, #0x3
    31fc:      	sub	x0, x0, x16
    3200:      	add	x3, x3, x24
    3204:      	lsl	x0, x0, #2
    3208:      	lsl	x3, x3, #4
    320c:      	add	x2, x3, x2
    3210:      	add	x0, x0, x2
    3214:      	ldr	w0, [x0]
    3218:      	sxtw	x0, w0
    321c:      	and	x0, x0, #0xffffffff
    3220:      	mov	x2, x0
    3224:      	mov	x0, #0x1                ; =1
    3228:      	b	0x327c <_stogir.verify.classifications+0x698>
    322c:      	movz	x5, #0x0, lsl #48
    3230:      	b	0x2c64 <_stogir.verify.classifications+0x80>
    3234:      	cmp	x21, #0x18
    3238:      	b.ne	0x3244 <_stogir.verify.classifications+0x660>
    323c:      	mov	x0, #0x1                ; =1
    3240:      	b	0x2d7c <_stogir.verify.classifications+0x198>
    3244:      	cmp	x21, #0x19
    3248:      	b.ne	0x3254 <_stogir.verify.classifications+0x670>
    324c:      	mov	x0, #0x1                ; =1
    3250:      	b	0x2d7c <_stogir.verify.classifications+0x198>
    3254:      	cmp	x19, #0xc
    3258:      	b.eq	0x2d78 <_stogir.verify.classifications+0x194>
    325c:      	cmp	x19, #0xd
    3260:      	b.eq	0x2d78 <_stogir.verify.classifications+0x194>
    3264:      	cmp	x0, #0xc
    3268:      	b.ne	0x3280 <_stogir.verify.classifications+0x69c>
    326c:      	mov	x0, #0x1                ; =1
    3270:      	b	0x328c <_stogir.verify.classifications+0x6a8>
    3274:      	movz	x0, #0x0, lsl #48
    3278:      	movz	x2, #0x0, lsl #48
    327c:      	b	0x312c <_stogir.verify.classifications+0x548>
    3280:      	cmp	x0, #0xd
    3284:      	cset	w0, eq
    3288:      	ubfx	x0, x0, #0, #8
    328c:      	b	0x2d7c <_stogir.verify.classifications+0x198>
    3290:      	brk	#0
    3294:      	b	0x3290 <_stogir.verify.classifications+0x6ac>
    3298:      	str	x19, [sp, #0x38]
    329c:      	str	x20, [sp, #0x40]
    32a0:      	b	0x30a8 <_stogir.verify.classifications+0x4c4>
    32a4:      	str	x19, [sp, #0x38]
    32a8:      	str	x20, [sp, #0x40]
    32ac:      	b	0x30a8 <_stogir.verify.classifications+0x4c4>
    32b0:      	ldr	x5, [sp, #0x58]
    32b4:      	b	0x3044 <_stogir.verify.classifications+0x460>
    32b8:      	ldr	x5, [sp, #0x58]
    32bc:      	b	0x2df0 <_stogir.verify.classifications+0x20c>
    32c0:      	ldr	x6, [sp, #0x50]
    32c4:      	ldr	x8, [sp, #0x48]
    32c8:      	b	0x2e00 <_stogir.verify.classifications+0x21c>
    32cc:      	ldr	x1, [sp, #0x60]
    32d0:      	b	0x3124 <_stogir.verify.classifications+0x540>
    32d4:      	ldr	x1, [sp, #0x60]
    32d8:      	b	0x3124 <_stogir.verify.classifications+0x540>

00000000000032dc <_stogir.vector-lanes.operation?>:
    32dc:      	sxtw	x0, w0
    32e0:      	cmp	x0, #0x3d
    32e4:      	b.lt	0x32f8 <_stogir.vector-lanes.operation?+0x1c>
    32e8:      	cmp	x0, #0x3f
    32ec:      	cset	w0, le
    32f0:      	ubfx	x0, x0, #0, #8
    32f4:      	b	0x32fc <_stogir.vector-lanes.operation?+0x20>
    32f8:      	movz	x0, #0x0, lsl #48
    32fc:      	ret

0000000000003300 <_stogir.vector.validate>:
    3300:      	sub	sp, sp, #0x210
    3304:      	str	x29, [sp]
    3308:      	str	x30, [sp, #0x8]
    330c:      	mov	x29, sp
    3310:      	str	x19, [sp, #0x1c0]
    3314:      	str	x20, [sp, #0x1c8]
    3318:      	str	x21, [sp, #0x1d0]
    331c:      	str	x22, [sp, #0x1d8]
    3320:      	str	x23, [sp, #0x1e0]
    3324:      	str	x24, [sp, #0x1e8]
    3328:      	str	x25, [sp, #0x1f0]
    332c:      	str	x26, [sp, #0x1f8]
    3330:      	str	x27, [sp, #0x200]
    3334:      	str	x28, [sp, #0x208]
    3338:      	lsr	w19, w1, #0
    333c:      	mov	x20, x8
    3340:      	add	x8, sp, #0x10
    3344:      	mov	x21, x0
    3348:      	mov	w22, w1
    334c:      	mov	w1, w19
    3350:      	mov	w23, w2
    3354:      	bl	0x3354 <_stogir.vector.validate+0x54>
		0000000000003354:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3358:      	add	x16, sp, #0x10
    335c:      	ldr	w0, [x16]
    3360:      	lsr	x16, x0, #0
    3364:      	cmp	x16, #0x1
    3368:      	b.eq	0x3384 <_stogir.vector.validate+0x84>
    336c:      	b.lo	0x3374 <_stogir.vector.validate+0x74>
    3370:      	b	0x3388 <_stogir.vector.validate+0x88>
    3374:      	cmp	x16, #0x0
    3378:      	b.eq	0x3380 <_stogir.vector.validate+0x80>
    337c:      	b	0x3388 <_stogir.vector.validate+0x88>
    3380:      	b	0x338c <_stogir.vector.validate+0x8c>
    3384:      	b	0x3424 <_stogir.vector.validate+0x124>
    3388:      	b	0x364c <_stogir.vector.validate+0x34c>
    338c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		000000000000338c:  ARM64_RELOC_PAGE21	l_stogir.342
    3390:      	ldr	x16, [x16]
		0000000000003390:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    3394:      	orr	x0, x16, xzr
    3398:      	str	x20, [sp, #0x1a8]
    339c:      	mov	x1, x0
    33a0:      	mov	x0, #0x1                ; =1
    33a4:      	mov	x2, #0x1a               ; =26
    33a8:      	b	0x33dc <_stogir.vector.validate+0xdc>
    33ac:      	lsr	w23, w23, #0
    33b0:      	add	x8, sp, #0x70
    33b4:      	mov	x0, x21
    33b8:      	ldr	w1, [sp, #0x1a0]
    33bc:      	mov	w2, w23
    33c0:      	bl	0x33c0 <_stogir.vector.validate+0xc0>
		00000000000033c0:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    33c4:      	add	x16, sp, #0x70
    33c8:      	ldr	x0, [x16]
    33cc:      	add	x16, sp, #0x70
    33d0:      	ldr	x1, [x16, #0x8]
    33d4:      	add	x16, sp, #0x70
    33d8:      	ldr	x2, [x16, #0x10]
    33dc:      	ldr	x3, [sp, #0x1a8]
    33e0:      	str	x0, [x3]
    33e4:      	str	x1, [x3, #0x8]
    33e8:      	str	x2, [x3, #0x10]
    33ec:      	ldr	x19, [sp, #0x1c0]
    33f0:      	ldr	x20, [sp, #0x1c8]
    33f4:      	ldr	x21, [sp, #0x1d0]
    33f8:      	ldr	x22, [sp, #0x1d8]
    33fc:      	ldr	x23, [sp, #0x1e0]
    3400:      	ldr	x24, [sp, #0x1e8]
    3404:      	ldr	x25, [sp, #0x1f0]
    3408:      	ldr	x26, [sp, #0x1f8]
    340c:      	ldr	x27, [sp, #0x200]
    3410:      	ldr	x28, [sp, #0x208]
    3414:      	ldr	x29, [sp]
    3418:      	ldr	x30, [sp, #0x8]
    341c:      	add	sp, sp, #0x210
    3420:      	ret
    3424:      	sxtw	x22, w22
    3428:      	add	x16, sp, #0x10
    342c:      	orr	x0, x16, xzr
    3430:      	cmp	x22, #0x0
    3434:      	cset	w24, le
    3438:      	add	x0, x0, #0x8
    343c:      	add	x16, sp, #0x10
    3440:      	ldr	x1, [x16, #0x8]
    3444:      	add	x16, sp, #0x40
    3448:      	str	x1, [x16]
    344c:      	ldr	x0, [x0, #0x8]
    3450:      	add	x16, sp, #0x40
    3454:      	str	x0, [x16, #0x8]
    3458:      	uxtb	w16, w24
    345c:      	cmp	w16, wzr
    3460:      	b.eq	0x3484 <_stogir.vector.validate+0x184>
    3464:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003464:  ARM64_RELOC_PAGE21	l_stogir.343
    3468:      	ldr	x16, [x16]
		0000000000003468:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    346c:      	orr	x0, x16, xzr
    3470:      	str	x20, [sp, #0x1a8]
    3474:      	mov	x1, x0
    3478:      	mov	x0, #0x1                ; =1
    347c:      	mov	x2, #0x3b               ; =59
    3480:      	b	0x33dc <_stogir.vector.validate+0xdc>
    3484:      	lsl	x25, x22, #2
    3488:      	add	x16, sp, #0x40
    348c:      	ldr	w26, [x16]
    3490:      	uxtb	w0, w26
    3494:      	ldr	x1, [x21, #0x78]
    3498:      	orr	x27, x0, xzr
    349c:      	cmp	x27, #0x44
    34a0:      	cset	w0, eq
    34a4:      	add	x1, x25, x1
    34a8:      	ldr	w28, [x1]
    34ac:      	cmp	x27, #0x24
    34b0:      	b.ne	0x34f4 <_stogir.vector.validate+0x1f4>
    34b4:      	str	x20, [sp, #0x1a8]
    34b8:      	str	w19, [sp, #0x1a0]
    34bc:      	uxtb	w16, w0
    34c0:      	cmp	w16, wzr
    34c4:      	b.eq	0x33ac <_stogir.vector.validate+0xac>
    34c8:      	add	x8, sp, #0x50
    34cc:      	mov	x0, x21
    34d0:      	ldr	w1, [sp, #0x1a0]
    34d4:      	bl	0x34d4 <_stogir.vector.validate+0x1d4>
		00000000000034d4:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    34d8:      	add	x16, sp, #0x50
    34dc:      	ldr	x0, [x16]
    34e0:      	add	x16, sp, #0x50
    34e4:      	ldr	x1, [x16, #0x8]
    34e8:      	add	x16, sp, #0x50
    34ec:      	ldr	x2, [x16, #0x10]
    34f0:      	b	0x33dc <_stogir.vector.validate+0xdc>
    34f4:      	uxtb	w16, w0
    34f8:      	cmp	w16, wzr
    34fc:      	b.ne	0x3db0 <_stogir.vector.validate+0xab0>
    3500:      	cmp	x27, #0x3c
    3504:      	b.ne	0x35b8 <_stogir.vector.validate+0x2b8>
    3508:      	add	x8, sp, #0x90
    350c:      	mov	x0, x21
    3510:      	mov	w1, w19
    3514:      	bl	0x3514 <_stogir.vector.validate+0x214>
		0000000000003514:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3518:      	add	x16, sp, #0x90
    351c:      	ldr	x0, [x16]
    3520:      	add	x16, sp, #0x90
    3524:      	ldr	x1, [x16, #0x8]
    3528:      	add	x16, sp, #0x90
    352c:      	ldr	x2, [x16, #0x10]
    3530:      	str	x20, [sp, #0x1a8]
    3534:      	b	0x35b4 <_stogir.vector.validate+0x2b4>
    3538:      	cmp	x27, #0x41
    353c:      	cset	w0, eq
    3540:      	cmp	x27, #0x48
    3544:      	cset	w1, eq
    3548:      	cmp	x27, #0x55
    354c:      	cset	w2, ge
    3550:      	cmp	x27, #0x58
    3554:      	cset	w3, le
    3558:      	cmp	x27, #0x47
    355c:      	b.ne	0x3654 <_stogir.vector.validate+0x354>
    3560:      	str	x20, [sp, #0x1a8]
    3564:      	str	w19, [sp, #0x1a0]
    3568:      	mov	w19, w0
    356c:      	mov	w20, w1
    3570:      	str	w2, [sp, #0x1b0]
    3574:      	str	w3, [sp, #0x1b8]
    3578:      	mov	x0, x21
    357c:      	ldr	w1, [sp, #0x1a0]
    3580:      	bl	0x3580 <_stogir.vector.validate+0x280>
		0000000000003580:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    3584:      	cmp	x0, #0x0
    3588:      	b.eq	0x3678 <_stogir.vector.validate+0x378>
    358c:      	add	x8, sp, #0xf0
    3590:      	mov	x0, x21
    3594:      	ldr	w1, [sp, #0x1a0]
    3598:      	bl	0x3598 <_stogir.vector.validate+0x298>
		0000000000003598:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    359c:      	add	x16, sp, #0xf0
    35a0:      	ldr	x0, [x16]
    35a4:      	add	x16, sp, #0xf0
    35a8:      	ldr	x1, [x16, #0x8]
    35ac:      	add	x16, sp, #0xf0
    35b0:      	ldr	x2, [x16, #0x10]
    35b4:      	b	0x33dc <_stogir.vector.validate+0xdc>
    35b8:      	cmp	x27, #0x3d
    35bc:      	b.lt	0x3600 <_stogir.vector.validate+0x300>
    35c0:      	cmp	x27, #0x3f
    35c4:      	b.gt	0x3600 <_stogir.vector.validate+0x300>
    35c8:      	lsr	w23, w23, #0
    35cc:      	add	x8, sp, #0xb0
    35d0:      	mov	x0, x21
    35d4:      	mov	w1, w19
    35d8:      	mov	w2, w23
    35dc:      	bl	0x35dc <_stogir.vector.validate+0x2dc>
		00000000000035dc:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    35e0:      	add	x16, sp, #0xb0
    35e4:      	ldr	x0, [x16]
    35e8:      	add	x16, sp, #0xb0
    35ec:      	ldr	x1, [x16, #0x8]
    35f0:      	add	x16, sp, #0xb0
    35f4:      	ldr	x2, [x16, #0x10]
    35f8:      	str	x20, [sp, #0x1a8]
    35fc:      	b	0x35b4 <_stogir.vector.validate+0x2b4>
    3600:      	mov	x0, x21
    3604:      	mov	w1, w19
    3608:      	bl	0x3608 <_stogir.vector.validate+0x308>
		0000000000003608:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    360c:      	cmp	x0, #0x0
    3610:      	b.eq	0x3538 <_stogir.vector.validate+0x238>
    3614:      	lsr	w23, w23, #0
    3618:      	add	x8, sp, #0xd0
    361c:      	mov	x0, x21
    3620:      	mov	w1, w19
    3624:      	mov	w2, w23
    3628:      	bl	0x3628 <_stogir.vector.validate+0x328>
		0000000000003628:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    362c:      	add	x16, sp, #0xd0
    3630:      	ldr	x0, [x16]
    3634:      	add	x16, sp, #0xd0
    3638:      	ldr	x1, [x16, #0x8]
    363c:      	add	x16, sp, #0xd0
    3640:      	ldr	x2, [x16, #0x10]
    3644:      	str	x20, [sp, #0x1a8]
    3648:      	b	0x35b4 <_stogir.vector.validate+0x2b4>
    364c:      	brk	#0
    3650:      	b	0x364c <_stogir.vector.validate+0x34c>
    3654:      	cmp	x27, #0x4f
    3658:      	b.ne	0x36f4 <_stogir.vector.validate+0x3f4>
    365c:      	str	x20, [sp, #0x1a8]
    3660:      	str	w19, [sp, #0x1a0]
    3664:      	mov	w19, w0
    3668:      	mov	w20, w1
    366c:      	str	w2, [sp, #0x1b0]
    3670:      	str	w3, [sp, #0x1b8]
    3674:      	b	0x3578 <_stogir.vector.validate+0x278>
    3678:      	uxtb	w16, w19
    367c:      	cmp	w16, wzr
    3680:      	b.ne	0x36c0 <_stogir.vector.validate+0x3c0>
    3684:      	uxtb	w16, w20
    3688:      	cmp	w16, wzr
    368c:      	b.ne	0x36c0 <_stogir.vector.validate+0x3c0>
    3690:      	ldr	w0, [sp, #0x1b0]
    3694:      	uxtb	w16, w0
    3698:      	cmp	w16, wzr
    369c:      	b.eq	0x36b0 <_stogir.vector.validate+0x3b0>
    36a0:      	ldr	w0, [sp, #0x1b8]
    36a4:      	uxtb	w16, w0
    36a8:      	cmp	w16, wzr
    36ac:      	b.ne	0x36c0 <_stogir.vector.validate+0x3c0>
    36b0:      	movz	x0, #0x0, lsl #48
    36b4:      	movz	x1, #0x0, lsl #48
    36b8:      	movz	x2, #0x0, lsl #48
    36bc:      	b	0x36f0 <_stogir.vector.validate+0x3f0>
    36c0:      	lsr	w23, w23, #0
    36c4:      	add	x8, sp, #0x110
    36c8:      	mov	x0, x21
    36cc:      	ldr	w1, [sp, #0x1a0]
    36d0:      	mov	w2, w23
    36d4:      	bl	0x36d4 <_stogir.vector.validate+0x3d4>
		00000000000036d4:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    36d8:      	add	x16, sp, #0x110
    36dc:      	ldr	x0, [x16]
    36e0:      	add	x16, sp, #0x110
    36e4:      	ldr	x1, [x16, #0x8]
    36e8:      	add	x16, sp, #0x110
    36ec:      	ldr	x2, [x16, #0x10]
    36f0:      	b	0x35b4 <_stogir.vector.validate+0x2b4>
    36f4:      	cmp	x27, #0x50
    36f8:      	b.eq	0x3dbc <_stogir.vector.validate+0xabc>
    36fc:      	cmp	x27, #0x78
    3700:      	b.ne	0x3720 <_stogir.vector.validate+0x420>
    3704:      	str	x20, [sp, #0x1a8]
    3708:      	str	w19, [sp, #0x1a0]
    370c:      	mov	w19, w0
    3710:      	mov	w20, w1
    3714:      	str	w2, [sp, #0x1b0]
    3718:      	str	w3, [sp, #0x1b8]
    371c:      	b	0x3578 <_stogir.vector.validate+0x278>
    3720:      	uxtb	w16, w0
    3724:      	cmp	w16, wzr
    3728:      	b.ne	0x3808 <_stogir.vector.validate+0x508>
    372c:      	uxtb	w16, w1
    3730:      	cmp	w16, wzr
    3734:      	b.ne	0x3808 <_stogir.vector.validate+0x508>
    3738:      	uxtb	w16, w2
    373c:      	cmp	w16, wzr
    3740:      	b.eq	0x3750 <_stogir.vector.validate+0x450>
    3744:      	uxtb	w16, w3
    3748:      	cmp	w16, wzr
    374c:      	b.ne	0x3808 <_stogir.vector.validate+0x508>
    3750:      	str	w2, [sp, #0x1b0]
    3754:      	str	w3, [sp, #0x1b8]
    3758:      	str	w19, [sp, #0x1a0]
    375c:      	str	x20, [sp, #0x1a8]
    3760:      	mov	w20, w1
    3764:      	mov	w1, w19
    3768:      	mov	w19, w0
    376c:      	mov	x0, x21
    3770:      	bl	0x3770 <_stogir.vector.validate+0x470>
		0000000000003770:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    3774:      	cmp	x0, #0x0
    3778:      	b.ne	0x3578 <_stogir.vector.validate+0x278>
    377c:      	sxtw	x28, w28
    3780:      	ubfx	x0, x26, #8, #8
    3784:      	orr	x1, x0, xzr
    3788:      	lsr	w19, w1, #0
    378c:      	cmp	x27, #0x5b
    3790:      	b.eq	0x3840 <_stogir.vector.validate+0x540>
    3794:      	cmp	x27, #0x5c
    3798:      	b.eq	0x3840 <_stogir.vector.validate+0x540>
    379c:      	orr	x20, x0, xzr
    37a0:      	cmp	x27, #0x5d
    37a4:      	b.eq	0x38b8 <_stogir.vector.validate+0x5b8>
    37a8:      	cmp	x27, #0x5e
    37ac:      	b.eq	0x38b8 <_stogir.vector.validate+0x5b8>
    37b0:      	cmp	x27, #0x43
    37b4:      	b.ne	0x3934 <_stogir.vector.validate+0x634>
    37b8:      	mov	w0, w19
    37bc:      	bl	0x37bc <_stogir.vector.validate+0x4bc>
		00000000000037bc:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    37c0:      	cmp	x0, #0x0
    37c4:      	b.eq	0x3c64 <_stogir.vector.validate+0x964>
    37c8:      	lsr	w23, w23, #0
    37cc:      	mov	w0, w19
    37d0:      	mov	w1, w23
    37d4:      	bl	0x37d4 <_stogir.vector.validate+0x4d4>
		00000000000037d4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    37d8:      	lsr	w0, w0, #0
    37dc:      	sxtw	x0, w0
    37e0:      	cmp	x0, #0x0
    37e4:      	b.le	0x3c64 <_stogir.vector.validate+0x964>
    37e8:      	cmp	x28, #0x3
    37ec:      	b.lt	0x3c64 <_stogir.vector.validate+0x964>
    37f0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		00000000000037f0:  ARM64_RELOC_PAGE21	l_stogir.344
    37f4:      	ldr	x16, [x16]
		00000000000037f4:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    37f8:      	orr	x0, x16, xzr
    37fc:      	mov	x26, x0
    3800:      	movz	x27, #0x0, lsl #48
    3804:      	b	0x3c78 <_stogir.vector.validate+0x978>
    3808:      	str	x20, [sp, #0x1a8]
    380c:      	str	w19, [sp, #0x1a0]
    3810:      	mov	w19, w0
    3814:      	mov	w20, w1
    3818:      	str	w2, [sp, #0x1b0]
    381c:      	str	w3, [sp, #0x1b8]
    3820:      	b	0x3578 <_stogir.vector.validate+0x278>
    3824:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003824:  ARM64_RELOC_PAGE21	l_stogir.345
    3828:      	ldr	x16, [x16]
		0000000000003828:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    382c:      	orr	x0, x16, xzr
    3830:      	mov	x1, x0
    3834:      	mov	x0, #0x1                ; =1
    3838:      	mov	x2, #0x19               ; =25
    383c:      	b	0x35b4 <_stogir.vector.validate+0x2b4>
    3840:      	cmp	x28, #0x2
    3844:      	b.ne	0x3824 <_stogir.vector.validate+0x524>
    3848:      	lsr	w23, w23, #0
    384c:      	add	x16, sp, #0x40
    3850:      	ldr	w0, [x16, #0x4]
    3854:      	add	x16, sp, #0x40
    3858:      	ldr	w1, [x16, #0x8]
    385c:      	lsr	w0, w0, #0
    3860:      	lsr	w1, w1, #0
    3864:      	add	x8, sp, #0x130
    3868:      	mov	w2, w23
    386c:      	mov	w3, w0
    3870:      	mov	x0, x21
    3874:      	mov	w4, w1
    3878:      	mov	w1, w19
    387c:      	bl	0x387c <_stogir.vector.validate+0x57c>
		000000000000387c:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    3880:      	add	x16, sp, #0x130
    3884:      	ldr	x0, [x16]
    3888:      	add	x16, sp, #0x130
    388c:      	ldr	x1, [x16, #0x8]
    3890:      	add	x16, sp, #0x130
    3894:      	ldr	x2, [x16, #0x10]
    3898:      	b	0x383c <_stogir.vector.validate+0x53c>
    389c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		000000000000389c:  ARM64_RELOC_PAGE21	l_stogir.346
    38a0:      	ldr	x16, [x16]
		00000000000038a0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    38a4:      	orr	x0, x16, xzr
    38a8:      	mov	x1, x0
    38ac:      	mov	x0, #0x1                ; =1
    38b0:      	mov	x2, #0x1a               ; =26
    38b4:      	b	0x383c <_stogir.vector.validate+0x53c>
    38b8:      	cmp	x28, #0x3
    38bc:      	b.ne	0x389c <_stogir.vector.validate+0x59c>
    38c0:      	cmp	x20, #0x0
    38c4:      	b.ne	0x389c <_stogir.vector.validate+0x59c>
    38c8:      	lsr	w23, w23, #0
    38cc:      	add	x16, sp, #0x40
    38d0:      	ldr	w0, [x16, #0x4]
    38d4:      	add	x16, sp, #0x40
    38d8:      	ldr	w1, [x16, #0x8]
    38dc:      	lsr	w0, w0, #0
    38e0:      	add	x16, sp, #0x40
    38e4:      	ldr	w2, [x16, #0xc]
    38e8:      	lsr	w1, w1, #0
    38ec:      	lsr	w2, w2, #0
    38f0:      	add	x8, sp, #0x150
    38f4:      	mov	w3, w1
    38f8:      	mov	w1, w23
    38fc:      	mov	w4, w2
    3900:      	mov	w2, w0
    3904:      	mov	x0, x21
    3908:      	bl	0x3908 <_stogir.vector.validate+0x608>
		0000000000003908:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    390c:      	add	x16, sp, #0x150
    3910:      	ldr	x0, [x16]
    3914:      	add	x16, sp, #0x150
    3918:      	ldr	x1, [x16, #0x8]
    391c:      	add	x16, sp, #0x150
    3920:      	ldr	x2, [x16, #0x10]
    3924:      	b	0x38b4 <_stogir.vector.validate+0x5b4>
    3928:      	mov	x2, x6
    392c:      	mov	x0, #0x1                ; =1
    3930:      	b	0x38b4 <_stogir.vector.validate+0x5b4>
    3934:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003934:  ARM64_RELOC_PAGE21	l_stogir.347
    3938:      	ldr	x16, [x16]
		0000000000003938:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    393c:      	orr	x0, x16, xzr
    3940:      	mov	x1, x0
    3944:      	mov	x0, #0x1                ; =1
    3948:      	mov	x2, #0x28               ; =40
    394c:      	b	0x3930 <_stogir.vector.validate+0x630>
    3950:      	mov	x0, x1
    3954:      	mov	x1, x27
    3958:      	add	x2, x21, #0x78
    395c:      	add	x3, x21, #0x28
    3960:      	add	x4, x21, #0x50
    3964:      	add	x5, x21, #0x78
    3968:      	mov	x6, x1
    396c:      	mov	x1, x0
    3970:      	mov	x0, #0x2                ; =2
    3974:      	b	0x3a00 <_stogir.vector.validate+0x700>
    3978:      	lsr	w8, w8, #0
    397c:      	ubfx	x7, x8, #8, #8
    3980:      	cmp	x7, x20
    3984:      	b.eq	0x3998 <_stogir.vector.validate+0x698>
    3988:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003988:  ARM64_RELOC_PAGE21	l_stogir.348
    398c:      	ldr	x16, [x16]
		000000000000398c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    3990:      	orr	x1, x16, xzr
    3994:      	mov	x6, #0x1e               ; =30
    3998:      	b	0x39f4 <_stogir.vector.validate+0x6f4>
    399c:      	movz	x7, #0x0, lsl #48
    39a0:      	movz	x8, #0x0, lsl #48
    39a4:      	b	0x39b0 <_stogir.vector.validate+0x6b0>
    39a8:      	movz	x7, #0x0, lsl #48
    39ac:      	movz	x8, #0x0, lsl #48
    39b0:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		00000000000039b0:  ARM64_RELOC_PAGE21	l_stogir.349
    39b4:      	ldr	x16, [x16]
		00000000000039b4:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    39b8:      	orr	x9, x16, xzr
    39bc:      	lsr	w7, w7, #0
    39c0:      	lsr	x16, x7, #0
    39c4:      	cmp	x16, #0x1
    39c8:      	b.eq	0x39e4 <_stogir.vector.validate+0x6e4>
    39cc:      	b.lo	0x39d4 <_stogir.vector.validate+0x6d4>
    39d0:      	b	0x39e8 <_stogir.vector.validate+0x6e8>
    39d4:      	cmp	x16, #0x0
    39d8:      	b.eq	0x39e0 <_stogir.vector.validate+0x6e0>
    39dc:      	b	0x39e8 <_stogir.vector.validate+0x6e8>
    39e0:      	b	0x39ec <_stogir.vector.validate+0x6ec>
    39e4:      	b	0x3a60 <_stogir.vector.validate+0x760>
    39e8:      	b	0x3d98 <_stogir.vector.validate+0xa98>
    39ec:      	mov	x1, x9
    39f0:      	mov	x6, #0x18               ; =24
    39f4:      	add	x0, x0, #0x1
    39f8:      	lsr	w0, w0, #0
    39fc:      	sxtw	x0, w0
    3a00:      	cmp	x6, #0x0
    3a04:      	cset	w7, eq
    3a08:      	uxtb	w16, w7
    3a0c:      	cmp	w16, wzr
    3a10:      	b.eq	0x3b98 <_stogir.vector.validate+0x898>
    3a14:      	cmp	x0, x28
    3a18:      	b.gt	0x3b98 <_stogir.vector.validate+0x898>
    3a1c:      	uxtb	w16, w24
    3a20:      	cmp	w16, wzr
    3a24:      	b.ne	0x39a8 <_stogir.vector.validate+0x6a8>
    3a28:      	ldr	x7, [x21, #0x8]
    3a2c:      	cmp	x22, x7
    3a30:      	b.ge	0x3acc <_stogir.vector.validate+0x7cc>
    3a34:      	ldr	x7, [x5, #0x8]
    3a38:      	cmp	x22, x7
    3a3c:      	b.ge	0x3ac4 <_stogir.vector.validate+0x7c4>
    3a40:      	ldr	x7, [x21, #0x78]
    3a44:      	add	x7, x25, x7
    3a48:      	ldr	w7, [x7]
    3a4c:      	sxtw	x7, w7
    3a50:      	cmp	x7, #0x0
    3a54:      	cset	w7, ge
    3a58:      	ubfx	x7, x7, #0, #8
    3a5c:      	b	0x3ac8 <_stogir.vector.validate+0x7c8>
    3a60:      	lsr	w8, w8, #0
    3a64:      	sxtw	x8, w8
    3a68:      	cmp	x8, #0x0
    3a6c:      	cset	w7, gt
    3a70:      	movz	x16, #0x0, lsl #48
    3a74:      	sub	x10, x16, x8
    3a78:      	sub	x11, x10, #0x1
    3a7c:      	uxtb	w16, w7
    3a80:      	cmp	w16, wzr
    3a84:      	b.eq	0x3b54 <_stogir.vector.validate+0x854>
    3a88:      	ldr	x10, [x21, #0x8]
    3a8c:      	cmp	x8, x10
    3a90:      	b.ge	0x3bd0 <_stogir.vector.validate+0x8d0>
    3a94:      	ldr	x10, [x2, #0x8]
    3a98:      	cmp	x8, x10
    3a9c:      	b.ge	0x3ce4 <_stogir.vector.validate+0x9e4>
    3aa0:      	lsl	x10, x8, #2
    3aa4:      	ldr	x12, [x21, #0x78]
    3aa8:      	add	x10, x10, x12
    3aac:      	ldr	w10, [x10]
    3ab0:      	sxtw	x10, w10
    3ab4:      	cmp	x10, #0x0
    3ab8:      	cset	w10, ge
    3abc:      	ubfx	x10, x10, #0, #8
    3ac0:      	b	0x3ce8 <_stogir.vector.validate+0x9e8>
    3ac4:      	movz	x7, #0x0, lsl #48
    3ac8:      	b	0x3ad0 <_stogir.vector.validate+0x7d0>
    3acc:      	movz	x7, #0x0, lsl #48
    3ad0:      	cmp	x7, #0x0
    3ad4:      	b.eq	0x39a8 <_stogir.vector.validate+0x6a8>
    3ad8:      	lsr	w7, w0, #0
    3adc:      	sxtw	x7, w7
    3ae0:      	cmp	x7, #0x1
    3ae4:      	b.lt	0x399c <_stogir.vector.validate+0x69c>
    3ae8:      	ldr	x8, [x21, #0x78]
    3aec:      	add	x8, x25, x8
    3af0:      	ldr	w8, [x8]
    3af4:      	sxtw	x8, w8
    3af8:      	cmp	x7, x8
    3afc:      	b.gt	0x399c <_stogir.vector.validate+0x69c>
    3b00:      	ldr	x8, [x21]
    3b04:      	asr	x16, x7, #63
    3b08:      	lsr	x16, x16, #62
    3b0c:      	add	x9, x7, x16
    3b10:      	asr	x9, x9, #2
    3b14:      	asr	x16, x7, #63
    3b18:      	lsr	x16, x16, #62
    3b1c:      	add	x7, x7, x16
    3b20:      	and	x7, x7, #0x3
    3b24:      	sub	x7, x7, x16
    3b28:      	add	x9, x9, x22
    3b2c:      	lsl	x7, x7, #2
    3b30:      	lsl	x9, x9, #4
    3b34:      	add	x8, x9, x8
    3b38:      	add	x7, x7, x8
    3b3c:      	ldr	w7, [x7]
    3b40:      	sxtw	x7, w7
    3b44:      	and	x7, x7, #0xffffffff
    3b48:      	mov	x8, x7
    3b4c:      	mov	x7, #0x1                ; =1
    3b50:      	b	0x39a4 <_stogir.vector.validate+0x6a4>
    3b54:      	cmp	x8, #0x0
    3b58:      	b.ge	0x3bd8 <_stogir.vector.validate+0x8d8>
    3b5c:      	ldr	x12, [x3, #0x8]
    3b60:      	ldr	x13, [x4, #0x8]
    3b64:      	cmp	x12, x13
    3b68:      	b.ne	0x3cdc <_stogir.vector.validate+0x9dc>
    3b6c:      	cmp	x10, x12
    3b70:      	b.gt	0x3d14 <_stogir.vector.validate+0xa14>
    3b74:      	lsl	x10, x11, #2
    3b78:      	ldr	x12, [x21, #0x50]
    3b7c:      	add	x10, x10, x12
    3b80:      	ldr	w10, [x10]
    3b84:      	sxtw	x10, w10
    3b88:      	cmp	x10, #0x0
    3b8c:      	cset	w10, gt
    3b90:      	ubfx	x10, x10, #0, #8
    3b94:      	b	0x3d18 <_stogir.vector.validate+0xa18>
    3b98:      	uxtb	w16, w7
    3b9c:      	cmp	w16, wzr
    3ba0:      	b.eq	0x3928 <_stogir.vector.validate+0x628>
    3ba4:      	lsr	w23, w23, #0
    3ba8:      	mov	w0, w19
    3bac:      	mov	w1, w23
    3bb0:      	bl	0x3bb0 <_stogir.vector.validate+0x8b0>
		0000000000003bb0:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3bb4:      	lsr	w0, w0, #0
    3bb8:      	sxtw	x0, w0
    3bbc:      	and	x0, x0, #0xffffffff
    3bc0:      	mov	x1, x0
    3bc4:      	movz	x0, #0x0, lsl #48
    3bc8:      	movz	x2, #0x0, lsl #48
    3bcc:      	b	0x3930 <_stogir.vector.validate+0x630>
    3bd0:      	movz	x10, #0x0, lsl #48
    3bd4:      	b	0x3bdc <_stogir.vector.validate+0x8dc>
    3bd8:      	movz	x10, #0x0, lsl #48
    3bdc:      	cmp	x10, #0x0
    3be0:      	b.eq	0x3c20 <_stogir.vector.validate+0x920>
    3be4:      	uxtb	w16, w7
    3be8:      	cmp	w16, wzr
    3bec:      	b.eq	0x3c04 <_stogir.vector.validate+0x904>
    3bf0:      	lsl	x7, x8, #4
    3bf4:      	ldr	x8, [x21]
    3bf8:      	add	x7, x7, x8
    3bfc:      	ldr	x7, [x7]
    3c00:      	b	0x3c14 <_stogir.vector.validate+0x914>
    3c04:      	lsl	x7, x11, #4
    3c08:      	ldr	x8, [x21, #0x28]
    3c0c:      	add	x7, x7, x8
    3c10:      	ldr	x7, [x7]
    3c14:      	mov	x8, x7
    3c18:      	mov	x7, #0x1                ; =1
    3c1c:      	b	0x3c28 <_stogir.vector.validate+0x928>
    3c20:      	movz	x7, #0x0, lsl #48
    3c24:      	movz	x8, #0x0, lsl #48
    3c28:      	lsr	w7, w7, #0
    3c2c:      	lsr	x16, x7, #0
    3c30:      	cmp	x16, #0x1
    3c34:      	b.eq	0x3c50 <_stogir.vector.validate+0x950>
    3c38:      	b.lo	0x3c40 <_stogir.vector.validate+0x940>
    3c3c:      	b	0x3c54 <_stogir.vector.validate+0x954>
    3c40:      	cmp	x16, #0x0
    3c44:      	b.eq	0x3c4c <_stogir.vector.validate+0x94c>
    3c48:      	b	0x3c54 <_stogir.vector.validate+0x954>
    3c4c:      	b	0x3c58 <_stogir.vector.validate+0x958>
    3c50:      	b	0x3978 <_stogir.vector.validate+0x678>
    3c54:      	b	0x3da0 <_stogir.vector.validate+0xaa0>
    3c58:      	mov	x1, x9
    3c5c:      	mov	x6, #0x18               ; =24
    3c60:      	b	0x3998 <_stogir.vector.validate+0x698>
    3c64:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003c64:  ARM64_RELOC_PAGE21	l_stogir.350
    3c68:      	ldr	x16, [x16]
		0000000000003c68:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3c6c:      	orr	x0, x16, xzr
    3c70:      	mov	x26, x0
    3c74:      	mov	x27, #0x20              ; =32
    3c78:      	add	x16, sp, #0x40
    3c7c:      	ldr	w0, [x16, #0x4]
    3c80:      	lsr	w0, w0, #0
    3c84:      	add	x8, sp, #0x170
    3c88:      	mov	w1, w0
    3c8c:      	mov	x0, x21
    3c90:      	bl	0x3c90 <_stogir.vector.validate+0x990>
		0000000000003c90:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3c94:      	add	x16, sp, #0x170
    3c98:      	ldr	w0, [x16]
    3c9c:      	lsr	x16, x0, #0
    3ca0:      	cmp	x16, #0x1
    3ca4:      	b.eq	0x3cc0 <_stogir.vector.validate+0x9c0>
    3ca8:      	b.lo	0x3cb0 <_stogir.vector.validate+0x9b0>
    3cac:      	b	0x3cc4 <_stogir.vector.validate+0x9c4>
    3cb0:      	cmp	x16, #0x0
    3cb4:      	b.eq	0x3cbc <_stogir.vector.validate+0x9bc>
    3cb8:      	b	0x3cc4 <_stogir.vector.validate+0x9c4>
    3cbc:      	b	0x3cc8 <_stogir.vector.validate+0x9c8>
    3cc0:      	b	0x3cec <_stogir.vector.validate+0x9ec>
    3cc4:      	b	0x3da8 <_stogir.vector.validate+0xaa8>
    3cc8:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003cc8:  ARM64_RELOC_PAGE21	l_stogir.351
    3ccc:      	ldr	x16, [x16]
		0000000000003ccc:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3cd0:      	orr	x0, x16, xzr
    3cd4:      	mov	x1, #0x19               ; =25
    3cd8:      	b	0x3958 <_stogir.vector.validate+0x658>
    3cdc:      	movz	x10, #0x0, lsl #48
    3ce0:      	b	0x3bdc <_stogir.vector.validate+0x8dc>
    3ce4:      	movz	x10, #0x0, lsl #48
    3ce8:      	b	0x3bd4 <_stogir.vector.validate+0x8d4>
    3cec:      	add	x16, sp, #0x170
    3cf0:      	ldr	x0, [x16, #0x8]
    3cf4:      	add	x16, sp, #0x40
    3cf8:      	ldr	w1, [x16, #0x4]
    3cfc:      	sxtw	x1, w1
    3d00:      	cmp	x1, #0x0
    3d04:      	b.gt	0x3d7c <_stogir.vector.validate+0xa7c>
    3d08:      	mov	x1, x26
    3d0c:      	mov	x0, #0x1                ; =1
    3d10:      	b	0x3d60 <_stogir.vector.validate+0xa60>
    3d14:      	movz	x10, #0x0, lsl #48
    3d18:      	b	0x3ce0 <_stogir.vector.validate+0x9e0>
    3d1c:      	add	x16, sp, #0x40
    3d20:      	ldr	w0, [x16, #0x4]
    3d24:      	sxtw	x0, w0
    3d28:      	ldr	x1, [x21, #0x78]
    3d2c:      	lsl	x0, x0, #2
    3d30:      	add	x0, x0, x1
    3d34:      	ldr	w0, [x0]
    3d38:      	sxtw	x0, w0
    3d3c:      	add	x0, x0, #0x1
    3d40:      	lsr	w0, w0, #0
    3d44:      	sxtw	x0, w0
    3d48:      	cmp	x28, x0
    3d4c:      	cset	w0, eq
    3d50:      	uxtb	w16, w0
    3d54:      	cmp	w16, wzr
    3d58:      	cset	x0, eq
    3d5c:      	mov	x1, x26
    3d60:      	cmp	x0, #0x0
    3d64:      	b.eq	0x3950 <_stogir.vector.validate+0x650>
    3d68:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003d68:  ARM64_RELOC_PAGE21	l_stogir.352
    3d6c:      	ldr	x16, [x16]
		0000000000003d6c:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3d70:      	orr	x0, x16, xzr
    3d74:      	mov	x1, #0x19               ; =25
    3d78:      	b	0x3958 <_stogir.vector.validate+0x658>
    3d7c:      	uxtb	w0, w0
    3d80:      	cmp	x0, #0x70
    3d84:      	b.eq	0x3d1c <_stogir.vector.validate+0xa1c>
    3d88:      	cmp	x0, #0x71
    3d8c:      	b.eq	0x3d1c <_stogir.vector.validate+0xa1c>
    3d90:      	mov	x0, #0x1                ; =1
    3d94:      	b	0x3d5c <_stogir.vector.validate+0xa5c>
    3d98:      	brk	#0
    3d9c:      	b	0x3d98 <_stogir.vector.validate+0xa98>
    3da0:      	brk	#0
    3da4:      	b	0x3da0 <_stogir.vector.validate+0xaa0>
    3da8:      	brk	#0
    3dac:      	b	0x3da8 <_stogir.vector.validate+0xaa8>
    3db0:      	str	x20, [sp, #0x1a8]
    3db4:      	str	w19, [sp, #0x1a0]
    3db8:      	b	0x34bc <_stogir.vector.validate+0x1bc>
    3dbc:      	str	x20, [sp, #0x1a8]
    3dc0:      	str	w19, [sp, #0x1a0]
    3dc4:      	mov	w19, w0
    3dc8:      	mov	w20, w1
    3dcc:      	str	w2, [sp, #0x1b0]
    3dd0:      	str	w3, [sp, #0x1b8]
    3dd4:      	b	0x3578 <_stogir.vector.validate+0x278>

0000000000003dd8 <_stogir.copy.validate>:
    3dd8:      	sub	sp, sp, #0x40
    3ddc:      	str	x29, [sp]
    3de0:      	str	x30, [sp, #0x8]
    3de4:      	mov	x29, sp
    3de8:      	str	x19, [sp, #0x20]
    3dec:      	str	x20, [sp, #0x28]
    3df0:      	str	x21, [sp, #0x30]
    3df4:      	sxtw	x1, w1
    3df8:      	lsl	x2, x1, #2
    3dfc:      	cmp	x1, #0x0
    3e00:      	cset	w3, gt
    3e04:      	movz	x16, #0x0, lsl #48
    3e08:      	sub	x4, x16, x1
    3e0c:      	sub	x5, x4, #0x1
    3e10:      	uxtb	w16, w3
    3e14:      	cmp	w16, wzr
    3e18:      	b.eq	0x3e58 <_stogir.copy.validate+0x80>
    3e1c:      	ldr	x4, [x0, #0x8]
    3e20:      	cmp	x1, x4
    3e24:      	b.ge	0x3eac <_stogir.copy.validate+0xd4>
    3e28:      	add	x4, x0, #0x78
    3e2c:      	ldr	x4, [x4, #0x8]
    3e30:      	cmp	x1, x4
    3e34:      	b.ge	0x3fd8 <_stogir.copy.validate+0x200>
    3e38:      	ldr	x4, [x0, #0x78]
    3e3c:      	add	x4, x2, x4
    3e40:      	ldr	w4, [x4]
    3e44:      	sxtw	x4, w4
    3e48:      	cmp	x4, #0x0
    3e4c:      	cset	w4, ge
    3e50:      	ubfx	x4, x4, #0, #8
    3e54:      	b	0x3fdc <_stogir.copy.validate+0x204>
    3e58:      	cmp	x1, #0x0
    3e5c:      	b.ge	0x3eb4 <_stogir.copy.validate+0xdc>
    3e60:      	add	x6, x0, #0x28
    3e64:      	add	x7, x0, #0x50
    3e68:      	ldr	x6, [x6, #0x8]
    3e6c:      	ldr	x7, [x7, #0x8]
    3e70:      	cmp	x6, x7
    3e74:      	b.ne	0x3ea4 <_stogir.copy.validate+0xcc>
    3e78:      	cmp	x4, x6
    3e7c:      	b.gt	0x4020 <_stogir.copy.validate+0x248>
    3e80:      	lsl	x4, x5, #2
    3e84:      	ldr	x6, [x0, #0x50]
    3e88:      	add	x4, x4, x6
    3e8c:      	ldr	w4, [x4]
    3e90:      	sxtw	x4, w4
    3e94:      	cmp	x4, #0x0
    3e98:      	cset	w4, gt
    3e9c:      	ubfx	x4, x4, #0, #8
    3ea0:      	b	0x4024 <_stogir.copy.validate+0x24c>
    3ea4:      	movz	x4, #0x0, lsl #48
    3ea8:      	b	0x3eb8 <_stogir.copy.validate+0xe0>
    3eac:      	movz	x4, #0x0, lsl #48
    3eb0:      	b	0x3eb8 <_stogir.copy.validate+0xe0>
    3eb4:      	movz	x4, #0x0, lsl #48
    3eb8:      	cmp	x4, #0x0
    3ebc:      	b.eq	0x3f20 <_stogir.copy.validate+0x148>
    3ec0:      	uxtb	w16, w3
    3ec4:      	cmp	w16, wzr
    3ec8:      	b.eq	0x3ef0 <_stogir.copy.validate+0x118>
    3ecc:      	lsl	x3, x1, #4
    3ed0:      	ldr	x4, [x0]
    3ed4:      	add	x3, x3, x4
    3ed8:      	ldr	x4, [x3]
    3edc:      	ldr	x3, [x3, #0x8]
    3ee0:      	fmov	d31, x3
    3ee4:      	mov	x3, x4
    3ee8:      	fmov	x4, d31
    3eec:      	b	0x3f10 <_stogir.copy.validate+0x138>
    3ef0:      	lsl	x3, x5, #4
    3ef4:      	ldr	x4, [x0, #0x28]
    3ef8:      	add	x3, x3, x4
    3efc:      	ldr	x4, [x3]
    3f00:      	ldr	x3, [x3, #0x8]
    3f04:      	fmov	d31, x3
    3f08:      	mov	x3, x4
    3f0c:      	fmov	x4, d31
    3f10:      	mov	x5, x4
    3f14:      	mov	x4, x3
    3f18:      	mov	x3, #0x1                ; =1
    3f1c:      	b	0x3f2c <_stogir.copy.validate+0x154>
    3f20:      	movz	x3, #0x0, lsl #48
    3f24:      	movz	x4, #0x0, lsl #48
    3f28:      	movz	x5, #0x0, lsl #48
    3f2c:      	lsr	w3, w3, #0
    3f30:      	lsr	x16, x3, #0
    3f34:      	cmp	x16, #0x1
    3f38:      	b.eq	0x3f54 <_stogir.copy.validate+0x17c>
    3f3c:      	b.lo	0x3f44 <_stogir.copy.validate+0x16c>
    3f40:      	b	0x3f58 <_stogir.copy.validate+0x180>
    3f44:      	cmp	x16, #0x0
    3f48:      	b.eq	0x3f50 <_stogir.copy.validate+0x178>
    3f4c:      	b	0x3f58 <_stogir.copy.validate+0x180>
    3f50:      	b	0x3f5c <_stogir.copy.validate+0x184>
    3f54:      	b	0x3fa0 <_stogir.copy.validate+0x1c8>
    3f58:      	b	0x40b0 <_stogir.copy.validate+0x2d8>
    3f5c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003f5c:  ARM64_RELOC_PAGE21	l_stogir.353
    3f60:      	ldr	x16, [x16]
		0000000000003f60:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    3f64:      	orr	x0, x16, xzr
    3f68:      	mov	x20, x8
    3f6c:      	mov	x1, x0
    3f70:      	mov	x0, #0x1                ; =1
    3f74:      	mov	x2, #0x18               ; =24
    3f78:      	str	x0, [x20]
    3f7c:      	str	x1, [x20, #0x8]
    3f80:      	str	x2, [x20, #0x10]
    3f84:      	ldr	x19, [sp, #0x20]
    3f88:      	ldr	x20, [sp, #0x28]
    3f8c:      	ldr	x21, [sp, #0x30]
    3f90:      	ldr	x29, [sp]
    3f94:      	ldr	x30, [sp, #0x8]
    3f98:      	add	sp, sp, #0x40
    3f9c:      	ret
    3fa0:      	add	x16, sp, #0x10
    3fa4:      	str	x4, [x16]
    3fa8:      	add	x16, sp, #0x10
    3fac:      	str	x5, [x16, #0x8]
    3fb0:      	cmp	x1, #0x0
    3fb4:      	b.gt	0x3fe0 <_stogir.copy.validate+0x208>
    3fb8:      	mov	x20, x8
    3fbc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x41c>
		0000000000003fbc:  ARM64_RELOC_PAGE21	l_stogir.354
    3fc0:      	ldr	x16, [x16]
		0000000000003fc0:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    3fc4:      	orr	x0, x16, xzr
    3fc8:      	mov	x1, x0
    3fcc:      	mov	x0, #0x1                ; =1
    3fd0:      	mov	x2, #0x21               ; =33
    3fd4:      	b	0x3f78 <_stogir.copy.validate+0x1a0>
    3fd8:      	movz	x4, #0x0, lsl #48
    3fdc:      	b	0x3eb0 <_stogir.copy.validate+0xd8>
    3fe0:      	uxtb	w1, w4
    3fe4:      	cmp	x1, #0x44
    3fe8:      	b.ne	0x4214 <_stogir.copy.validate+0x43c>
    3fec:      	ldr	x1, [x0, #0x78]
    3ff0:      	add	x1, x2, x1
    3ff4:      	ldr	w1, [x1]
    3ff8:      	sxtw	x1, w1
    3ffc:      	cmp	x1, #0x2
    4000:      	b.ne	0x421c <_stogir.copy.validate+0x444>
    4004:      	lsr	w4, w4, #0
    4008:      	ubfx	x1, x4, #8, #8
    400c:      	orr	x19, x1, xzr
    4010:      	cmp	x19, #0x0
    4014:      	b.ne	0x4028 <_stogir.copy.validate+0x250>
    4018:      	mov	x20, x8
    401c:      	b	0x3fbc <_stogir.copy.validate+0x1e4>
    4020:      	movz	x4, #0x0, lsl #48
    4024:      	b	0x3ea8 <_stogir.copy.validate+0xd0>
    4028:      	lsr	w1, w1, #0
    402c:      	mov	x20, x8
    4030:      	mov	x21, x0
    4034:      	mov	w0, w1
    4038:      	bl	0x4038 <_stogir.copy.validate+0x260>
		0000000000004038:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    403c:      	cmp	x0, #0x0
    4040:      	b.eq	0x3fbc <_stogir.copy.validate+0x1e4>
    4044:      	add	x16, sp, #0x10
    4048:      	ldr	w0, [x16, #0x4]
    404c:      	sxtw	x0, w0
    4050:      	cmp	x0, #0x0
    4054:      	cset	w1, gt
    4058:      	movz	x16, #0x0, lsl #48
    405c:      	sub	x2, x16, x0
    4060:      	sub	x3, x2, #0x1
    4064:      	uxtb	w16, w1
    4068:      	cmp	w16, wzr
    406c:      	b.eq	0x40d4 <_stogir.copy.validate+0x2fc>
    4070:      	ldr	x2, [x21, #0x8]
    4074:      	cmp	x0, x2
    4078:      	b.ge	0x4120 <_stogir.copy.validate+0x348>
    407c:      	add	x2, x21, #0x78
    4080:      	ldr	x2, [x2, #0x8]
    4084:      	cmp	x0, x2
    4088:      	b.ge	0x41fc <_stogir.copy.validate+0x424>
    408c:      	lsl	x2, x0, #2
    4090:      	ldr	x4, [x21, #0x78]
    4094:      	add	x2, x2, x4
    4098:      	ldr	w2, [x2]
    409c:      	sxtw	x2, w2
    40a0:      	cmp	x2, #0x0
    40a4:      	cset	w2, ge
    40a8:      	ubfx	x2, x2, #0, #8
    40ac:      	b	0x4200 <_stogir.copy.validate+0x428>
    40b0:      	brk	#0
    40b4:      	b	0x40b0 <_stogir.copy.validate+0x2d8>
    40b8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		00000000000040b8:  ARM64_RELOC_PAGE21	l_stogir.355
    40bc:      	ldr	x16, [x16]
		00000000000040bc:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    40c0:      	orr	x0, x16, xzr
    40c4:      	mov	x1, x0
    40c8:      	mov	x0, #0x1                ; =1
    40cc:      	mov	x2, #0x20               ; =32
    40d0:      	b	0x3fd4 <_stogir.copy.validate+0x1fc>
    40d4:      	cmp	x0, #0x0
    40d8:      	b.ge	0x4128 <_stogir.copy.validate+0x350>
    40dc:      	add	x4, x21, #0x28
    40e0:      	add	x5, x21, #0x50
    40e4:      	ldr	x4, [x4, #0x8]
    40e8:      	ldr	x5, [x5, #0x8]
    40ec:      	cmp	x4, x5
    40f0:      	b.ne	0x41f4 <_stogir.copy.validate+0x41c>
    40f4:      	cmp	x2, x4
    40f8:      	b.gt	0x4204 <_stogir.copy.validate+0x42c>
    40fc:      	lsl	x2, x3, #2
    4100:      	ldr	x4, [x21, #0x50]
    4104:      	add	x2, x2, x4
    4108:      	ldr	w2, [x2]
    410c:      	sxtw	x2, w2
    4110:      	cmp	x2, #0x0
    4114:      	cset	w2, gt
    4118:      	ubfx	x2, x2, #0, #8
    411c:      	b	0x4208 <_stogir.copy.validate+0x430>
    4120:      	movz	x2, #0x0, lsl #48
    4124:      	b	0x412c <_stogir.copy.validate+0x354>
    4128:      	movz	x2, #0x0, lsl #48
    412c:      	cmp	x2, #0x0
    4130:      	b.eq	0x4170 <_stogir.copy.validate+0x398>
    4134:      	uxtb	w16, w1
    4138:      	cmp	w16, wzr
    413c:      	b.eq	0x4154 <_stogir.copy.validate+0x37c>
    4140:      	lsl	x0, x0, #4
    4144:      	ldr	x1, [x21]
    4148:      	add	x0, x0, x1
    414c:      	ldr	x0, [x0]
    4150:      	b	0x4164 <_stogir.copy.validate+0x38c>
    4154:      	lsl	x0, x3, #4
    4158:      	ldr	x1, [x21, #0x28]
    415c:      	add	x0, x0, x1
    4160:      	ldr	x0, [x0]
    4164:      	mov	x1, x0
    4168:      	mov	x0, #0x1                ; =1
    416c:      	b	0x4178 <_stogir.copy.validate+0x3a0>
    4170:      	movz	x0, #0x0, lsl #48
    4174:      	movz	x1, #0x0, lsl #48
    4178:      	lsr	w0, w0, #0
    417c:      	lsr	x16, x0, #0
    4180:      	cmp	x16, #0x1
    4184:      	b.eq	0x41a0 <_stogir.copy.validate+0x3c8>
    4188:      	b.lo	0x4190 <_stogir.copy.validate+0x3b8>
    418c:      	b	0x41a4 <_stogir.copy.validate+0x3cc>
    4190:      	cmp	x16, #0x0
    4194:      	b.eq	0x419c <_stogir.copy.validate+0x3c4>
    4198:      	b	0x41a4 <_stogir.copy.validate+0x3cc>
    419c:      	b	0x41a8 <_stogir.copy.validate+0x3d0>
    41a0:      	b	0x41c4 <_stogir.copy.validate+0x3ec>
    41a4:      	b	0x420c <_stogir.copy.validate+0x434>
    41a8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		00000000000041a8:  ARM64_RELOC_PAGE21	l_stogir.356
    41ac:      	ldr	x16, [x16]
		00000000000041ac:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    41b0:      	orr	x0, x16, xzr
    41b4:      	mov	x1, x0
    41b8:      	mov	x0, #0x1                ; =1
    41bc:      	mov	x2, #0x13               ; =19
    41c0:      	b	0x40d0 <_stogir.copy.validate+0x2f8>
    41c4:      	lsr	w1, w1, #0
    41c8:      	add	x16, sp, #0x10
    41cc:      	ldr	w0, [x16]
    41d0:      	ubfx	x1, x1, #8, #8
    41d4:      	ubfx	x0, x0, #8, #8
    41d8:      	cmp	x1, x0
    41dc:      	b.ne	0x40b8 <_stogir.copy.validate+0x2e0>
    41e0:      	and	x0, x19, #0xffffffff
    41e4:      	mov	x1, x0
    41e8:      	movz	x0, #0x0, lsl #48
    41ec:      	movz	x2, #0x0, lsl #48
    41f0:      	b	0x40d0 <_stogir.copy.validate+0x2f8>
    41f4:      	movz	x2, #0x0, lsl #48
    41f8:      	b	0x412c <_stogir.copy.validate+0x354>
    41fc:      	movz	x2, #0x0, lsl #48
    4200:      	b	0x4124 <_stogir.copy.validate+0x34c>
    4204:      	movz	x2, #0x0, lsl #48
    4208:      	b	0x41f8 <_stogir.copy.validate+0x420>
    420c:      	brk	#0
    4210:      	b	0x420c <_stogir.copy.validate+0x434>
    4214:      	mov	x20, x8
    4218:      	b	0x3fbc <_stogir.copy.validate+0x1e4>
    421c:      	mov	x20, x8
    4220:      	b	0x3fbc <_stogir.copy.validate+0x1e4>

0000000000004224 <_stogir.graph.lookup>:
    4224:      	sxtw	x1, w1
    4228:      	cmp	x1, #0x0
    422c:      	cset	w2, gt
    4230:      	movz	x16, #0x0, lsl #48
    4234:      	sub	x3, x16, x1
    4238:      	sub	x4, x3, #0x1
    423c:      	uxtb	w16, w2
    4240:      	cmp	w16, wzr
    4244:      	b.eq	0x4288 <_stogir.graph.lookup+0x64>
    4248:      	ldr	x3, [x0, #0x8]
    424c:      	cmp	x1, x3
    4250:      	b.ge	0x42dc <_stogir.graph.lookup+0xb8>
    4254:      	add	x3, x0, #0x78
    4258:      	ldr	x3, [x3, #0x8]
    425c:      	cmp	x1, x3
    4260:      	b.ge	0x437c <_stogir.graph.lookup+0x158>
    4264:      	lsl	x3, x1, #2
    4268:      	ldr	x5, [x0, #0x78]
    426c:      	add	x3, x3, x5
    4270:      	ldr	w3, [x3]
    4274:      	sxtw	x3, w3
    4278:      	cmp	x3, #0x0
    427c:      	cset	w3, ge
    4280:      	ubfx	x3, x3, #0, #8
    4284:      	b	0x4380 <_stogir.graph.lookup+0x15c>
    4288:      	cmp	x1, #0x0
    428c:      	b.ge	0x42e4 <_stogir.graph.lookup+0xc0>
    4290:      	add	x5, x0, #0x28
    4294:      	add	x6, x0, #0x50
    4298:      	ldr	x5, [x5, #0x8]
    429c:      	ldr	x6, [x6, #0x8]
    42a0:      	cmp	x5, x6
    42a4:      	b.ne	0x42d4 <_stogir.graph.lookup+0xb0>
    42a8:      	cmp	x3, x5
    42ac:      	b.gt	0x4384 <_stogir.graph.lookup+0x160>
    42b0:      	lsl	x3, x4, #2
    42b4:      	ldr	x5, [x0, #0x50]
    42b8:      	add	x3, x3, x5
    42bc:      	ldr	w3, [x3]
    42c0:      	sxtw	x3, w3
    42c4:      	cmp	x3, #0x0
    42c8:      	cset	w3, gt
    42cc:      	ubfx	x3, x3, #0, #8
    42d0:      	b	0x4388 <_stogir.graph.lookup+0x164>
    42d4:      	movz	x3, #0x0, lsl #48
    42d8:      	b	0x42e8 <_stogir.graph.lookup+0xc4>
    42dc:      	movz	x3, #0x0, lsl #48
    42e0:      	b	0x42e8 <_stogir.graph.lookup+0xc4>
    42e4:      	movz	x3, #0x0, lsl #48
    42e8:      	cmp	x3, #0x0
    42ec:      	b.eq	0x4350 <_stogir.graph.lookup+0x12c>
    42f0:      	uxtb	w16, w2
    42f4:      	cmp	w16, wzr
    42f8:      	b.eq	0x4320 <_stogir.graph.lookup+0xfc>
    42fc:      	lsl	x1, x1, #4
    4300:      	ldr	x0, [x0]
    4304:      	add	x0, x1, x0
    4308:      	ldr	x1, [x0]
    430c:      	ldr	x0, [x0, #0x8]
    4310:      	fmov	d31, x0
    4314:      	mov	x0, x1
    4318:      	fmov	x1, d31
    431c:      	b	0x4340 <_stogir.graph.lookup+0x11c>
    4320:      	lsl	x1, x4, #4
    4324:      	ldr	x0, [x0, #0x28]
    4328:      	add	x0, x1, x0
    432c:      	ldr	x1, [x0]
    4330:      	ldr	x0, [x0, #0x8]
    4334:      	fmov	d31, x0
    4338:      	mov	x0, x1
    433c:      	fmov	x1, d31
    4340:      	mov	x2, x1
    4344:      	mov	x1, x0
    4348:      	mov	x0, #0x1                ; =1
    434c:      	b	0x435c <_stogir.graph.lookup+0x138>
    4350:      	movz	x0, #0x0, lsl #48
    4354:      	movz	x1, #0x0, lsl #48
    4358:      	movz	x2, #0x0, lsl #48
    435c:      	str	x0, [x8]
    4360:      	str	x1, [x8, #0x8]
    4364:      	str	x2, [x8, #0x10]
    4368:      	movz	x17, #0x0, lsl #48
    436c:      	str	x17, [x8, #0x18]
    4370:      	movz	x17, #0x0, lsl #48
    4374:      	str	x17, [x8, #0x20]
    4378:      	ret
    437c:      	movz	x3, #0x0, lsl #48
    4380:      	b	0x42e0 <_stogir.graph.lookup+0xbc>
    4384:      	movz	x3, #0x0, lsl #48
    4388:      	b	0x42d8 <_stogir.graph.lookup+0xb4>

000000000000438c <_stogir.opcode.block-start?>:
    438c:      	sxtw	x0, w0
    4390:      	cmp	x0, #0x0
    4394:      	b.lt	0x43bc <_stogir.opcode.block-start?+0x30>
    4398:      	cmp	x0, #0x83
    439c:      	b.ge	0x43bc <_stogir.opcode.block-start?+0x30>
    43a0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		00000000000043a0:  ARM64_RELOC_PAGE21	l_stogir.357
    43a4:      	ldr	x16, [x16]
		00000000000043a4:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    43a8:      	orr	x1, x16, xzr
    43ac:      	lsr	x0, x0, #0
    43b0:      	add	x0, x0, x1
    43b4:      	ldrb	w0, [x0]
    43b8:      	b	0x43c0 <_stogir.opcode.block-start?+0x34>
    43bc:      	movz	x0, #0x0, lsl #48
    43c0:      	uxtb	w0, w0
    43c4:      	and	x0, x0, #0x2
    43c8:      	uxtb	w0, w0
    43cc:      	cmp	x0, #0x0
    43d0:      	cset	w0, eq
    43d4:      	uxtb	w16, w0
    43d8:      	cmp	w16, wzr
    43dc:      	cset	x0, eq
    43e0:      	ret

00000000000043e4 <_stogir.checked.operation?>:
    43e4:      	sxtw	x0, w0
    43e8:      	cmp	x0, #0x29
    43ec:      	b.lt	0x4400 <_stogir.checked.operation?+0x1c>
    43f0:      	cmp	x0, #0x2b
    43f4:      	cset	w0, le
    43f8:      	ubfx	x0, x0, #0, #8
    43fc:      	b	0x4404 <_stogir.checked.operation?+0x20>
    4400:      	movz	x0, #0x0, lsl #48
    4404:      	ret

0000000000004408 <_stogir.checked.validate-projection>:
    4408:      	sub	sp, sp, #0x40
    440c:      	str	x29, [sp]
    4410:      	str	x30, [sp, #0x8]
    4414:      	mov	x29, sp
    4418:      	str	x19, [sp, #0x30]
    441c:      	sxtw	x1, w1
    4420:      	lsl	x2, x1, #2
    4424:      	cmp	x1, #0x0
    4428:      	cset	w3, gt
    442c:      	movz	x16, #0x0, lsl #48
    4430:      	sub	x4, x16, x1
    4434:      	sub	x5, x4, #0x1
    4438:      	uxtb	w16, w3
    443c:      	cmp	w16, wzr
    4440:      	b.eq	0x4480 <_stogir.checked.validate-projection+0x78>
    4444:      	ldr	x4, [x0, #0x8]
    4448:      	cmp	x1, x4
    444c:      	b.ge	0x44d4 <_stogir.checked.validate-projection+0xcc>
    4450:      	add	x4, x0, #0x78
    4454:      	ldr	x4, [x4, #0x8]
    4458:      	cmp	x1, x4
    445c:      	b.ge	0x45c0 <_stogir.checked.validate-projection+0x1b8>
    4460:      	ldr	x4, [x0, #0x78]
    4464:      	add	x4, x2, x4
    4468:      	ldr	w4, [x4]
    446c:      	sxtw	x4, w4
    4470:      	cmp	x4, #0x0
    4474:      	cset	w4, ge
    4478:      	ubfx	x4, x4, #0, #8
    447c:      	b	0x45c4 <_stogir.checked.validate-projection+0x1bc>
    4480:      	cmp	x1, #0x0
    4484:      	b.ge	0x44dc <_stogir.checked.validate-projection+0xd4>
    4488:      	add	x6, x0, #0x28
    448c:      	add	x7, x0, #0x50
    4490:      	ldr	x6, [x6, #0x8]
    4494:      	ldr	x7, [x7, #0x8]
    4498:      	cmp	x6, x7
    449c:      	b.ne	0x44cc <_stogir.checked.validate-projection+0xc4>
    44a0:      	cmp	x4, x6
    44a4:      	b.gt	0x462c <_stogir.checked.validate-projection+0x224>
    44a8:      	lsl	x4, x5, #2
    44ac:      	ldr	x6, [x0, #0x50]
    44b0:      	add	x4, x4, x6
    44b4:      	ldr	w4, [x4]
    44b8:      	sxtw	x4, w4
    44bc:      	cmp	x4, #0x0
    44c0:      	cset	w4, gt
    44c4:      	ubfx	x4, x4, #0, #8
    44c8:      	b	0x4630 <_stogir.checked.validate-projection+0x228>
    44cc:      	movz	x4, #0x0, lsl #48
    44d0:      	b	0x44e0 <_stogir.checked.validate-projection+0xd8>
    44d4:      	movz	x4, #0x0, lsl #48
    44d8:      	b	0x44e0 <_stogir.checked.validate-projection+0xd8>
    44dc:      	movz	x4, #0x0, lsl #48
    44e0:      	cmp	x4, #0x0
    44e4:      	b.eq	0x4524 <_stogir.checked.validate-projection+0x11c>
    44e8:      	uxtb	w16, w3
    44ec:      	cmp	w16, wzr
    44f0:      	b.eq	0x4508 <_stogir.checked.validate-projection+0x100>
    44f4:      	lsl	x3, x1, #4
    44f8:      	ldr	x4, [x0]
    44fc:      	add	x3, x3, x4
    4500:      	ldr	x3, [x3]
    4504:      	b	0x4518 <_stogir.checked.validate-projection+0x110>
    4508:      	lsl	x3, x5, #4
    450c:      	ldr	x4, [x0, #0x28]
    4510:      	add	x3, x3, x4
    4514:      	ldr	x3, [x3]
    4518:      	mov	x4, x3
    451c:      	mov	x3, #0x1                ; =1
    4520:      	b	0x452c <_stogir.checked.validate-projection+0x124>
    4524:      	movz	x3, #0x0, lsl #48
    4528:      	movz	x4, #0x0, lsl #48
    452c:      	lsr	w3, w3, #0
    4530:      	lsr	x16, x3, #0
    4534:      	cmp	x16, #0x1
    4538:      	b.eq	0x4554 <_stogir.checked.validate-projection+0x14c>
    453c:      	b.lo	0x4544 <_stogir.checked.validate-projection+0x13c>
    4540:      	b	0x4558 <_stogir.checked.validate-projection+0x150>
    4544:      	cmp	x16, #0x0
    4548:      	b.eq	0x4550 <_stogir.checked.validate-projection+0x148>
    454c:      	b	0x4558 <_stogir.checked.validate-projection+0x150>
    4550:      	b	0x455c <_stogir.checked.validate-projection+0x154>
    4554:      	b	0x457c <_stogir.checked.validate-projection+0x174>
    4558:      	b	0x4634 <_stogir.checked.validate-projection+0x22c>
    455c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		000000000000455c:  ARM64_RELOC_PAGE21	l_stogir.358
    4560:      	ldr	x16, [x16]
		0000000000004560:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    4564:      	orr	x0, x16, xzr
    4568:      	mov	x19, x8
    456c:      	mov	x1, x0
    4570:      	mov	x0, #0x1                ; =1
    4574:      	mov	x2, #0x10               ; =16
    4578:      	b	0x45a0 <_stogir.checked.validate-projection+0x198>
    457c:      	cmp	x1, #0x0
    4580:      	b.gt	0x45c8 <_stogir.checked.validate-projection+0x1c0>
    4584:      	mov	x19, x8
    4588:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004588:  ARM64_RELOC_PAGE21	l_stogir.359
    458c:      	ldr	x16, [x16]
		000000000000458c:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    4590:      	orr	x0, x16, xzr
    4594:      	mov	x1, x0
    4598:      	mov	x0, #0x1                ; =1
    459c:      	mov	x2, #0x1c               ; =28
    45a0:      	str	x0, [x19]
    45a4:      	str	x1, [x19, #0x8]
    45a8:      	str	x2, [x19, #0x10]
    45ac:      	ldr	x19, [sp, #0x30]
    45b0:      	ldr	x29, [sp]
    45b4:      	ldr	x30, [sp, #0x8]
    45b8:      	add	sp, sp, #0x40
    45bc:      	ret
    45c0:      	movz	x4, #0x0, lsl #48
    45c4:      	b	0x44d8 <_stogir.checked.validate-projection+0xd0>
    45c8:      	uxtb	w1, w4
    45cc:      	cmp	x1, #0x2c
    45d0:      	b.ne	0x463c <_stogir.checked.validate-projection+0x234>
    45d4:      	lsr	w1, w4, #0
    45d8:      	ubfx	x1, x1, #8, #8
    45dc:      	cmp	x1, #0x1
    45e0:      	b.ne	0x4644 <_stogir.checked.validate-projection+0x23c>
    45e4:      	ldr	x1, [x0, #0x78]
    45e8:      	add	x1, x2, x1
    45ec:      	ldr	w1, [x1]
    45f0:      	sxtw	x1, w1
    45f4:      	cmp	x1, #0x1
    45f8:      	b.ne	0x464c <_stogir.checked.validate-projection+0x244>
    45fc:      	lsr	x1, x4, #32
    4600:      	lsr	w1, w1, #0
    4604:      	mov	x19, x8
    4608:      	add	x8, sp, #0x10
    460c:      	bl	0x460c <_stogir.checked.validate-projection+0x204>
		000000000000460c:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    4610:      	add	x16, sp, #0x10
    4614:      	ldr	x0, [x16]
    4618:      	add	x16, sp, #0x10
    461c:      	ldr	x1, [x16, #0x8]
    4620:      	add	x16, sp, #0x10
    4624:      	ldr	x2, [x16, #0x10]
    4628:      	b	0x45a0 <_stogir.checked.validate-projection+0x198>
    462c:      	movz	x4, #0x0, lsl #48
    4630:      	b	0x44d0 <_stogir.checked.validate-projection+0xc8>
    4634:      	brk	#0
    4638:      	b	0x4634 <_stogir.checked.validate-projection+0x22c>
    463c:      	mov	x19, x8
    4640:      	b	0x4588 <_stogir.checked.validate-projection+0x180>
    4644:      	mov	x19, x8
    4648:      	b	0x4588 <_stogir.checked.validate-projection+0x180>
    464c:      	mov	x19, x8
    4650:      	b	0x4588 <_stogir.checked.validate-projection+0x180>

0000000000004654 <_stogir.checked.validate>:
    4654:      	sub	sp, sp, #0x40
    4658:      	str	x29, [sp]
    465c:      	str	x30, [sp, #0x8]
    4660:      	mov	x29, sp
    4664:      	str	x19, [sp, #0x10]
    4668:      	str	x20, [sp, #0x18]
    466c:      	str	x21, [sp, #0x20]
    4670:      	str	x22, [sp, #0x28]
    4674:      	str	x23, [sp, #0x30]
    4678:      	sxtw	x1, w1
    467c:      	lsl	x2, x1, #2
    4680:      	cmp	x1, #0x0
    4684:      	cset	w3, gt
    4688:      	movz	x16, #0x0, lsl #48
    468c:      	sub	x4, x16, x1
    4690:      	sub	x5, x4, #0x1
    4694:      	uxtb	w16, w3
    4698:      	cmp	w16, wzr
    469c:      	b.eq	0x46dc <_stogir.checked.validate+0x88>
    46a0:      	ldr	x4, [x0, #0x8]
    46a4:      	cmp	x1, x4
    46a8:      	b.ge	0x4730 <_stogir.checked.validate+0xdc>
    46ac:      	add	x4, x0, #0x78
    46b0:      	ldr	x4, [x4, #0x8]
    46b4:      	cmp	x1, x4
    46b8:      	b.ge	0x4858 <_stogir.checked.validate+0x204>
    46bc:      	ldr	x4, [x0, #0x78]
    46c0:      	add	x4, x2, x4
    46c4:      	ldr	w4, [x4]
    46c8:      	sxtw	x4, w4
    46cc:      	cmp	x4, #0x0
    46d0:      	cset	w4, ge
    46d4:      	ubfx	x4, x4, #0, #8
    46d8:      	b	0x485c <_stogir.checked.validate+0x208>
    46dc:      	cmp	x1, #0x0
    46e0:      	b.ge	0x4738 <_stogir.checked.validate+0xe4>
    46e4:      	add	x6, x0, #0x28
    46e8:      	add	x7, x0, #0x50
    46ec:      	ldr	x6, [x6, #0x8]
    46f0:      	ldr	x7, [x7, #0x8]
    46f4:      	cmp	x6, x7
    46f8:      	b.ne	0x4728 <_stogir.checked.validate+0xd4>
    46fc:      	cmp	x4, x6
    4700:      	b.gt	0x48dc <_stogir.checked.validate+0x288>
    4704:      	lsl	x4, x5, #2
    4708:      	ldr	x6, [x0, #0x50]
    470c:      	add	x4, x4, x6
    4710:      	ldr	w4, [x4]
    4714:      	sxtw	x4, w4
    4718:      	cmp	x4, #0x0
    471c:      	cset	w4, gt
    4720:      	ubfx	x4, x4, #0, #8
    4724:      	b	0x48e0 <_stogir.checked.validate+0x28c>
    4728:      	movz	x4, #0x0, lsl #48
    472c:      	b	0x473c <_stogir.checked.validate+0xe8>
    4730:      	movz	x4, #0x0, lsl #48
    4734:      	b	0x473c <_stogir.checked.validate+0xe8>
    4738:      	movz	x4, #0x0, lsl #48
    473c:      	cmp	x4, #0x0
    4740:      	b.eq	0x47a4 <_stogir.checked.validate+0x150>
    4744:      	uxtb	w16, w3
    4748:      	cmp	w16, wzr
    474c:      	b.eq	0x4774 <_stogir.checked.validate+0x120>
    4750:      	lsl	x3, x1, #4
    4754:      	ldr	x4, [x0]
    4758:      	add	x3, x3, x4
    475c:      	ldr	x4, [x3]
    4760:      	ldr	x3, [x3, #0x8]
    4764:      	fmov	d31, x3
    4768:      	mov	x3, x4
    476c:      	fmov	x4, d31
    4770:      	b	0x4794 <_stogir.checked.validate+0x140>
    4774:      	lsl	x3, x5, #4
    4778:      	ldr	x4, [x0, #0x28]
    477c:      	add	x3, x3, x4
    4780:      	ldr	x4, [x3]
    4784:      	ldr	x3, [x3, #0x8]
    4788:      	fmov	d31, x3
    478c:      	mov	x3, x4
    4790:      	fmov	x4, d31
    4794:      	mov	x5, x4
    4798:      	mov	x4, x3
    479c:      	mov	x3, #0x1                ; =1
    47a0:      	b	0x47b0 <_stogir.checked.validate+0x15c>
    47a4:      	movz	x3, #0x0, lsl #48
    47a8:      	movz	x4, #0x0, lsl #48
    47ac:      	movz	x5, #0x0, lsl #48
    47b0:      	lsr	w3, w3, #0
    47b4:      	lsr	x16, x3, #0
    47b8:      	cmp	x16, #0x1
    47bc:      	b.eq	0x47d8 <_stogir.checked.validate+0x184>
    47c0:      	b.lo	0x47c8 <_stogir.checked.validate+0x174>
    47c4:      	b	0x47dc <_stogir.checked.validate+0x188>
    47c8:      	cmp	x16, #0x0
    47cc:      	b.eq	0x47d4 <_stogir.checked.validate+0x180>
    47d0:      	b	0x47dc <_stogir.checked.validate+0x188>
    47d4:      	b	0x47e0 <_stogir.checked.validate+0x18c>
    47d8:      	b	0x4800 <_stogir.checked.validate+0x1ac>
    47dc:      	b	0x4b8c <_stogir.checked.validate+0x538>
    47e0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		00000000000047e0:  ARM64_RELOC_PAGE21	l_stogir.360
    47e4:      	ldr	x16, [x16]
		00000000000047e4:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    47e8:      	orr	x0, x16, xzr
    47ec:      	mov	x23, x8
    47f0:      	mov	x1, x0
    47f4:      	mov	x0, #0x1                ; =1
    47f8:      	mov	x2, #0x1a               ; =26
    47fc:      	b	0x4824 <_stogir.checked.validate+0x1d0>
    4800:      	cmp	x1, #0x0
    4804:      	b.gt	0x4860 <_stogir.checked.validate+0x20c>
    4808:      	mov	x23, x8
    480c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		000000000000480c:  ARM64_RELOC_PAGE21	l_stogir.361
    4810:      	ldr	x16, [x16]
		0000000000004810:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4814:      	orr	x0, x16, xzr
    4818:      	mov	x1, x0
    481c:      	mov	x0, #0x1                ; =1
    4820:      	mov	x2, #0x26               ; =38
    4824:      	str	x0, [x23]
    4828:      	str	x1, [x23, #0x8]
    482c:      	str	x2, [x23, #0x10]
    4830:      	sub	sp, x29, #0x0
    4834:      	ldr	x19, [sp, #0x10]
    4838:      	ldr	x20, [sp, #0x18]
    483c:      	ldr	x21, [sp, #0x20]
    4840:      	ldr	x22, [sp, #0x28]
    4844:      	ldr	x23, [sp, #0x30]
    4848:      	ldr	x29, [sp]
    484c:      	ldr	x30, [sp, #0x8]
    4850:      	add	sp, sp, #0x40
    4854:      	ret
    4858:      	movz	x4, #0x0, lsl #48
    485c:      	b	0x4734 <_stogir.checked.validate+0xe0>
    4860:      	uxtb	w1, w4
    4864:      	cmp	x1, #0x29
    4868:      	b.lt	0x4bac <_stogir.checked.validate+0x558>
    486c:      	cmp	x1, #0x2b
    4870:      	b.gt	0x4bb4 <_stogir.checked.validate+0x560>
    4874:      	ldr	x1, [x0, #0x78]
    4878:      	add	x1, x2, x1
    487c:      	ldr	w1, [x1]
    4880:      	sxtw	x1, w1
    4884:      	cmp	x1, #0x2
    4888:      	b.ne	0x4bbc <_stogir.checked.validate+0x568>
    488c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		000000000000488c:  ARM64_RELOC_PAGE21	l_stogir.362
    4890:      	ldr	x16, [x16]
		0000000000004890:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    4894:      	orr	x1, x16, xzr
    4898:      	lsr	w2, w4, #0
    489c:      	mov	x19, sp
    48a0:      	sub	sp, sp, #0x10
    48a4:      	mov	x3, sp
    48a8:      	sub	sp, sp, #0x10
    48ac:      	mov	x6, sp
    48b0:      	ubfx	x2, x2, #8, #8
    48b4:      	orr	x20, x2, xzr
    48b8:      	cmp	x20, #0x1
    48bc:      	b.lt	0x4b2c <_stogir.checked.validate+0x4d8>
    48c0:      	cmp	x20, #0xb
    48c4:      	b.gt	0x4b2c <_stogir.checked.validate+0x4d8>
    48c8:      	cmp	x20, #0x1
    48cc:      	b.eq	0x4b2c <_stogir.checked.validate+0x4d8>
    48d0:      	mov	x2, x1
    48d4:      	movz	x7, #0x0, lsl #48
    48d8:      	b	0x4b3c <_stogir.checked.validate+0x4e8>
    48dc:      	movz	x4, #0x0, lsl #48
    48e0:      	b	0x472c <_stogir.checked.validate+0xd8>
    48e4:      	lsr	x0, x22, #0
    48e8:      	mov	x2, x0
    48ec:      	mov	x0, x21
    48f0:      	mov	x23, x8
    48f4:      	bl	0x48f4 <_stogir.checked.validate+0x2a0>
		00000000000048f4:  ARM64_RELOC_BRANCH26	_memcmp
    48f8:      	lsr	w0, w0, #0
    48fc:      	sxtw	x0, w0
    4900:      	cmp	x0, #0x0
    4904:      	b.eq	0x4a1c <_stogir.checked.validate+0x3c8>
    4908:      	mov	x1, x21
    490c:      	mov	x2, x22
    4910:      	mov	x0, #0x1                ; =1
    4914:      	mov	sp, x19
    4918:      	b	0x4824 <_stogir.checked.validate+0x1d0>
    491c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		000000000000491c:  ARM64_RELOC_PAGE21	l_stogir.363
    4920:      	ldr	x16, [x16]
		0000000000004920:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    4924:      	orr	x2, x16, xzr
    4928:      	mov	x3, #0x28               ; =40
    492c:      	mov	x21, x2
    4930:      	mov	x22, x3
    4934:      	mov	x2, x4
    4938:      	cmp	x2, #0x2
    493c:      	b.ge	0x4968 <_stogir.checked.validate+0x314>
    4940:      	add	x3, x2, #0x1
    4944:      	lsl	x2, x2, #2
    4948:      	add	x2, x2, x9
    494c:      	ldr	w2, [x2]
    4950:      	sxtw	x2, w2
    4954:      	and	x2, x2, #0xffffffff
    4958:      	mov	x4, x3
    495c:      	mov	x3, x2
    4960:      	mov	x2, #0x1                ; =1
    4964:      	b	0x4974 <_stogir.checked.validate+0x320>
    4968:      	mov	x4, x2
    496c:      	movz	x2, #0x0, lsl #48
    4970:      	movz	x3, #0x0, lsl #48
    4974:      	lsr	w2, w2, #0
    4978:      	lsr	x16, x2, #0
    497c:      	cmp	x16, #0x1
    4980:      	b.eq	0x499c <_stogir.checked.validate+0x348>
    4984:      	b.lo	0x498c <_stogir.checked.validate+0x338>
    4988:      	b	0x49a0 <_stogir.checked.validate+0x34c>
    498c:      	cmp	x16, #0x0
    4990:      	b.eq	0x4998 <_stogir.checked.validate+0x344>
    4994:      	b	0x49a0 <_stogir.checked.validate+0x34c>
    4998:      	b	0x4a08 <_stogir.checked.validate+0x3b4>
    499c:      	b	0x49a4 <_stogir.checked.validate+0x350>
    49a0:      	b	0x4b9c <_stogir.checked.validate+0x548>
    49a4:      	lsr	w3, w3, #0
    49a8:      	sxtw	x3, w3
    49ac:      	cmp	x3, #0x0
    49b0:      	cset	w2, gt
    49b4:      	movz	x16, #0x0, lsl #48
    49b8:      	sub	x5, x16, x3
    49bc:      	sub	x6, x5, #0x1
    49c0:      	uxtb	w16, w2
    49c4:      	cmp	w16, wzr
    49c8:      	b.eq	0x4a30 <_stogir.checked.validate+0x3dc>
    49cc:      	ldr	x5, [x0, #0x8]
    49d0:      	cmp	x3, x5
    49d4:      	b.ge	0x4a74 <_stogir.checked.validate+0x420>
    49d8:      	ldr	x5, [x10, #0x8]
    49dc:      	cmp	x3, x5
    49e0:      	b.ge	0x4b84 <_stogir.checked.validate+0x530>
    49e4:      	lsl	x5, x3, #2
    49e8:      	ldr	x7, [x0, #0x78]
    49ec:      	add	x5, x5, x7
    49f0:      	ldr	w5, [x5]
    49f4:      	sxtw	x5, w5
    49f8:      	cmp	x5, #0x0
    49fc:      	cset	w5, ge
    4a00:      	ubfx	x5, x5, #0, #8
    4a04:      	b	0x4b88 <_stogir.checked.validate+0x534>
    4a08:      	cmp	x22, #0x0
    4a0c:      	b.ne	0x4bc4 <_stogir.checked.validate+0x570>
    4a10:      	cmp	x22, #0x0
    4a14:      	b.ne	0x48e4 <_stogir.checked.validate+0x290>
    4a18:      	mov	x23, x8
    4a1c:      	and	x0, x20, #0xffffffff
    4a20:      	mov	x1, x0
    4a24:      	movz	x0, #0x0, lsl #48
    4a28:      	movz	x2, #0x0, lsl #48
    4a2c:      	b	0x4914 <_stogir.checked.validate+0x2c0>
    4a30:      	cmp	x3, #0x0
    4a34:      	b.ge	0x4a7c <_stogir.checked.validate+0x428>
    4a38:      	ldr	x7, [x11, #0x8]
    4a3c:      	ldr	x13, [x12, #0x8]
    4a40:      	cmp	x7, x13
    4a44:      	b.ne	0x4b7c <_stogir.checked.validate+0x528>
    4a48:      	cmp	x5, x7
    4a4c:      	b.gt	0x4b94 <_stogir.checked.validate+0x540>
    4a50:      	lsl	x5, x6, #2
    4a54:      	ldr	x7, [x0, #0x50]
    4a58:      	add	x5, x5, x7
    4a5c:      	ldr	w5, [x5]
    4a60:      	sxtw	x5, w5
    4a64:      	cmp	x5, #0x0
    4a68:      	cset	w5, gt
    4a6c:      	ubfx	x5, x5, #0, #8
    4a70:      	b	0x4b98 <_stogir.checked.validate+0x544>
    4a74:      	movz	x5, #0x0, lsl #48
    4a78:      	b	0x4a80 <_stogir.checked.validate+0x42c>
    4a7c:      	movz	x5, #0x0, lsl #48
    4a80:      	cmp	x5, #0x0
    4a84:      	b.eq	0x4ac4 <_stogir.checked.validate+0x470>
    4a88:      	uxtb	w16, w2
    4a8c:      	cmp	w16, wzr
    4a90:      	b.eq	0x4aa8 <_stogir.checked.validate+0x454>
    4a94:      	lsl	x2, x3, #4
    4a98:      	ldr	x3, [x0]
    4a9c:      	add	x2, x2, x3
    4aa0:      	ldr	x2, [x2]
    4aa4:      	b	0x4ab8 <_stogir.checked.validate+0x464>
    4aa8:      	lsl	x2, x6, #4
    4aac:      	ldr	x3, [x0, #0x28]
    4ab0:      	add	x2, x2, x3
    4ab4:      	ldr	x2, [x2]
    4ab8:      	mov	x3, x2
    4abc:      	mov	x2, #0x1                ; =1
    4ac0:      	b	0x4acc <_stogir.checked.validate+0x478>
    4ac4:      	movz	x2, #0x0, lsl #48
    4ac8:      	movz	x3, #0x0, lsl #48
    4acc:      	lsr	w2, w2, #0
    4ad0:      	lsr	x16, x2, #0
    4ad4:      	cmp	x16, #0x1
    4ad8:      	b.eq	0x4af4 <_stogir.checked.validate+0x4a0>
    4adc:      	b.lo	0x4ae4 <_stogir.checked.validate+0x490>
    4ae0:      	b	0x4af8 <_stogir.checked.validate+0x4a4>
    4ae4:      	cmp	x16, #0x0
    4ae8:      	b.eq	0x4af0 <_stogir.checked.validate+0x49c>
    4aec:      	b	0x4af8 <_stogir.checked.validate+0x4a4>
    4af0:      	b	0x4afc <_stogir.checked.validate+0x4a8>
    4af4:      	b	0x4b10 <_stogir.checked.validate+0x4bc>
    4af8:      	b	0x4ba4 <_stogir.checked.validate+0x550>
    4afc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004afc:  ARM64_RELOC_PAGE21	l_stogir.364
    4b00:      	ldr	x16, [x16]
		0000000000004b00:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4b04:      	orr	x2, x16, xzr
    4b08:      	mov	x3, #0x22               ; =34
    4b0c:      	b	0x492c <_stogir.checked.validate+0x2d8>
    4b10:      	lsr	w3, w3, #0
    4b14:      	ubfx	x2, x3, #8, #8
    4b18:      	cmp	x2, x20
    4b1c:      	b.ne	0x491c <_stogir.checked.validate+0x2c8>
    4b20:      	mov	x2, x21
    4b24:      	mov	x3, x22
    4b28:      	b	0x492c <_stogir.checked.validate+0x2d8>
    4b2c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004b2c:  ARM64_RELOC_PAGE21	l_stogir.365
    4b30:      	ldr	x16, [x16]
		0000000000004b30:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4b34:      	orr	x2, x16, xzr
    4b38:      	mov	x7, #0x36               ; =54
    4b3c:      	orr	x9, x6, xzr
    4b40:      	add	x10, x0, #0x78
    4b44:      	add	x11, x0, #0x28
    4b48:      	add	x12, x0, #0x50
    4b4c:      	lsr	w5, w5, #0
    4b50:      	lsr	x4, x4, #32
    4b54:      	lsr	w5, w5, #0
    4b58:      	lsr	w4, w4, #0
    4b5c:      	str	w4, [x3]
    4b60:      	str	w5, [x3, #0x4]
    4b64:      	ldr	x3, [x3]
    4b68:      	str	x3, [x6]
    4b6c:      	mov	x21, x2
    4b70:      	mov	x22, x7
    4b74:      	movz	x2, #0x0, lsl #48
    4b78:      	b	0x4938 <_stogir.checked.validate+0x2e4>
    4b7c:      	movz	x5, #0x0, lsl #48
    4b80:      	b	0x4a80 <_stogir.checked.validate+0x42c>
    4b84:      	movz	x5, #0x0, lsl #48
    4b88:      	b	0x4a78 <_stogir.checked.validate+0x424>
    4b8c:      	brk	#0
    4b90:      	b	0x4b8c <_stogir.checked.validate+0x538>
    4b94:      	movz	x5, #0x0, lsl #48
    4b98:      	b	0x4b80 <_stogir.checked.validate+0x52c>
    4b9c:      	brk	#0
    4ba0:      	b	0x4b9c <_stogir.checked.validate+0x548>
    4ba4:      	brk	#0
    4ba8:      	b	0x4ba4 <_stogir.checked.validate+0x550>
    4bac:      	mov	x23, x8
    4bb0:      	b	0x480c <_stogir.checked.validate+0x1b8>
    4bb4:      	mov	x23, x8
    4bb8:      	b	0x480c <_stogir.checked.validate+0x1b8>
    4bbc:      	mov	x23, x8
    4bc0:      	b	0x480c <_stogir.checked.validate+0x1b8>
    4bc4:      	mov	x23, x8
    4bc8:      	b	0x4908 <_stogir.checked.validate+0x2b4>

0000000000004bcc <_stogir.atomic.operation?>:
    4bcc:      	sxtw	x0, w0
    4bd0:      	cmp	x0, #0x7e
    4bd4:      	b.lt	0x4be8 <_stogir.atomic.operation?+0x1c>
    4bd8:      	cmp	x0, #0x82
    4bdc:      	cset	w0, le
    4be0:      	ubfx	x0, x0, #0, #8
    4be4:      	b	0x4bec <_stogir.atomic.operation?+0x20>
    4be8:      	movz	x0, #0x0, lsl #48
    4bec:      	ret

0000000000004bf0 <_stogir.atomic.validate>:
    4bf0:      	sub	sp, sp, #0xf0
    4bf4:      	str	x29, [sp, #0x10]
    4bf8:      	str	x30, [sp, #0x18]
    4bfc:      	add	x29, sp, #0x10
    4c00:      	str	x19, [sp, #0xa0]
    4c04:      	str	x20, [sp, #0xa8]
    4c08:      	str	x21, [sp, #0xb0]
    4c0c:      	str	x22, [sp, #0xb8]
    4c10:      	str	x23, [sp, #0xc0]
    4c14:      	str	x24, [sp, #0xc8]
    4c18:      	str	x25, [sp, #0xd0]
    4c1c:      	str	x26, [sp, #0xd8]
    4c20:      	str	x27, [sp, #0xe0]
    4c24:      	str	x28, [sp, #0xe8]
    4c28:      	sxtw	x2, w1
    4c2c:      	lsl	x3, x2, #2
    4c30:      	cmp	x2, #0x0
    4c34:      	cset	w4, gt
    4c38:      	movz	x16, #0x0, lsl #48
    4c3c:      	sub	x5, x16, x2
    4c40:      	sub	x6, x5, #0x1
    4c44:      	uxtb	w16, w4
    4c48:      	cmp	w16, wzr
    4c4c:      	b.eq	0x4c8c <_stogir.atomic.validate+0x9c>
    4c50:      	ldr	x5, [x0, #0x8]
    4c54:      	cmp	x2, x5
    4c58:      	b.ge	0x4ce0 <_stogir.atomic.validate+0xf0>
    4c5c:      	add	x5, x0, #0x78
    4c60:      	ldr	x5, [x5, #0x8]
    4c64:      	cmp	x2, x5
    4c68:      	b.ge	0x4e58 <_stogir.atomic.validate+0x268>
    4c6c:      	ldr	x5, [x0, #0x78]
    4c70:      	add	x5, x3, x5
    4c74:      	ldr	w5, [x5]
    4c78:      	sxtw	x5, w5
    4c7c:      	cmp	x5, #0x0
    4c80:      	cset	w5, ge
    4c84:      	ubfx	x5, x5, #0, #8
    4c88:      	b	0x4e5c <_stogir.atomic.validate+0x26c>
    4c8c:      	cmp	x2, #0x0
    4c90:      	b.ge	0x4ce8 <_stogir.atomic.validate+0xf8>
    4c94:      	add	x7, x0, #0x28
    4c98:      	add	x9, x0, #0x50
    4c9c:      	ldr	x7, [x7, #0x8]
    4ca0:      	ldr	x9, [x9, #0x8]
    4ca4:      	cmp	x7, x9
    4ca8:      	b.ne	0x4cd8 <_stogir.atomic.validate+0xe8>
    4cac:      	cmp	x5, x7
    4cb0:      	b.gt	0x4f2c <_stogir.atomic.validate+0x33c>
    4cb4:      	lsl	x5, x6, #2
    4cb8:      	ldr	x7, [x0, #0x50]
    4cbc:      	add	x5, x5, x7
    4cc0:      	ldr	w5, [x5]
    4cc4:      	sxtw	x5, w5
    4cc8:      	cmp	x5, #0x0
    4ccc:      	cset	w5, gt
    4cd0:      	ubfx	x5, x5, #0, #8
    4cd4:      	b	0x4f30 <_stogir.atomic.validate+0x340>
    4cd8:      	movz	x5, #0x0, lsl #48
    4cdc:      	b	0x4cec <_stogir.atomic.validate+0xfc>
    4ce0:      	movz	x5, #0x0, lsl #48
    4ce4:      	b	0x4cec <_stogir.atomic.validate+0xfc>
    4ce8:      	movz	x5, #0x0, lsl #48
    4cec:      	cmp	x5, #0x0
    4cf0:      	b.eq	0x4d50 <_stogir.atomic.validate+0x160>
    4cf4:      	uxtb	w16, w4
    4cf8:      	cmp	w16, wzr
    4cfc:      	b.eq	0x4d24 <_stogir.atomic.validate+0x134>
    4d00:      	lsl	x4, x2, #4
    4d04:      	ldr	x5, [x0]
    4d08:      	add	x4, x4, x5
    4d0c:      	ldr	x5, [x4]
    4d10:      	ldr	x4, [x4, #0x8]
    4d14:      	fmov	d31, x4
    4d18:      	mov	x4, x5
    4d1c:      	fmov	x5, d31
    4d20:      	b	0x4d44 <_stogir.atomic.validate+0x154>
    4d24:      	lsl	x4, x6, #4
    4d28:      	ldr	x5, [x0, #0x28]
    4d2c:      	add	x4, x4, x5
    4d30:      	ldr	x5, [x4]
    4d34:      	ldr	x4, [x4, #0x8]
    4d38:      	fmov	d31, x4
    4d3c:      	mov	x4, x5
    4d40:      	fmov	x5, d31
    4d44:      	mov	x19, x4
    4d48:      	mov	x4, #0x1                ; =1
    4d4c:      	b	0x4d5c <_stogir.atomic.validate+0x16c>
    4d50:      	movz	x4, #0x0, lsl #48
    4d54:      	movz	x19, #0x0, lsl #48
    4d58:      	movz	x5, #0x0, lsl #48
    4d5c:      	lsr	w4, w4, #0
    4d60:      	lsr	x16, x4, #0
    4d64:      	cmp	x16, #0x1
    4d68:      	b.eq	0x4d84 <_stogir.atomic.validate+0x194>
    4d6c:      	b.lo	0x4d74 <_stogir.atomic.validate+0x184>
    4d70:      	b	0x4d88 <_stogir.atomic.validate+0x198>
    4d74:      	cmp	x16, #0x0
    4d78:      	b.eq	0x4d80 <_stogir.atomic.validate+0x190>
    4d7c:      	b	0x4d88 <_stogir.atomic.validate+0x198>
    4d80:      	b	0x4d8c <_stogir.atomic.validate+0x19c>
    4d84:      	b	0x4dec <_stogir.atomic.validate+0x1fc>
    4d88:      	b	0x5560 <_stogir.atomic.validate+0x970>
    4d8c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004d8c:  ARM64_RELOC_PAGE21	l_stogir.366
    4d90:      	ldr	x16, [x16]
		0000000000004d90:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4d94:      	orr	x0, x16, xzr
    4d98:      	mov	x24, x8
    4d9c:      	mov	x1, x0
    4da0:      	mov	x0, #0x1                ; =1
    4da4:      	mov	x2, #0x1a               ; =26
    4da8:      	str	x0, [x24]
    4dac:      	str	x1, [x24, #0x8]
    4db0:      	str	x2, [x24, #0x10]
    4db4:      	ldr	x19, [sp, #0xa0]
    4db8:      	ldr	x20, [sp, #0xa8]
    4dbc:      	ldr	x21, [sp, #0xb0]
    4dc0:      	ldr	x22, [sp, #0xb8]
    4dc4:      	ldr	x23, [sp, #0xc0]
    4dc8:      	ldr	x24, [sp, #0xc8]
    4dcc:      	ldr	x25, [sp, #0xd0]
    4dd0:      	ldr	x26, [sp, #0xd8]
    4dd4:      	ldr	x27, [sp, #0xe0]
    4dd8:      	ldr	x28, [sp, #0xe8]
    4ddc:      	ldr	x29, [sp, #0x10]
    4de0:      	ldr	x30, [sp, #0x18]
    4de4:      	add	sp, sp, #0xf0
    4de8:      	ret
    4dec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004dec:  ARM64_RELOC_PAGE21	l_stogir.367
    4df0:      	ldr	x16, [x16]
		0000000000004df0:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4df4:      	orr	x20, x16, xzr
    4df8:      	uxtb	w4, w19
    4dfc:      	add	x16, sp, #0x20
    4e00:      	str	x19, [x16]
    4e04:      	orr	x21, x4, xzr
    4e08:      	add	x16, sp, #0x20
    4e0c:      	str	x5, [x16, #0x8]
    4e10:      	cmp	x2, #0x0
    4e14:      	b.le	0x4eac <_stogir.atomic.validate+0x2bc>
    4e18:      	cmp	x21, #0x7e
    4e1c:      	b.lt	0x4eac <_stogir.atomic.validate+0x2bc>
    4e20:      	cmp	x21, #0x82
    4e24:      	b.gt	0x4eac <_stogir.atomic.validate+0x2bc>
    4e28:      	ldr	x2, [x0, #0x78]
    4e2c:      	add	x2, x3, x2
    4e30:      	ldr	w2, [x2]
    4e34:      	cmp	x21, #0x83
    4e38:      	b.ge	0x548c <_stogir.atomic.validate+0x89c>
    4e3c:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004e3c:  ARM64_RELOC_PAGE21	l_stogir.368
    4e40:      	ldr	x16, [x16]
		0000000000004e40:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4e44:      	orr	x3, x16, xzr
    4e48:      	add	x3, x21, x3
    4e4c:      	ldrsb	w3, [x3]
    4e50:      	sxtb	x3, w3
    4e54:      	b	0x5490 <_stogir.atomic.validate+0x8a0>
    4e58:      	movz	x5, #0x0, lsl #48
    4e5c:      	b	0x4ce4 <_stogir.atomic.validate+0xf4>
    4e60:      	mov	x19, x21
    4e64:      	mov	x21, x23
    4e68:      	cmp	x21, #0x0
    4e6c:      	b.ne	0x4e9c <_stogir.atomic.validate+0x2ac>
    4e70:      	cmp	x21, #0x0
    4e74:      	b.eq	0x5334 <_stogir.atomic.validate+0x744>
    4e78:      	lsr	x0, x21, #0
    4e7c:      	mov	x1, x20
    4e80:      	mov	x2, x0
    4e84:      	mov	x0, x19
    4e88:      	bl	0x4e88 <_stogir.atomic.validate+0x298>
		0000000000004e88:  ARM64_RELOC_BRANCH26	_memcmp
    4e8c:      	lsr	w0, w0, #0
    4e90:      	sxtw	x0, w0
    4e94:      	cmp	x0, #0x0
    4e98:      	b.eq	0x5334 <_stogir.atomic.validate+0x744>
    4e9c:      	mov	x1, x19
    4ea0:      	mov	x2, x21
    4ea4:      	mov	x0, #0x1                ; =1
    4ea8:      	b	0x4da8 <_stogir.atomic.validate+0x1b8>
    4eac:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004eac:  ARM64_RELOC_PAGE21	l_stogir.369
    4eb0:      	ldr	x16, [x16]
		0000000000004eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4eb4:      	orr	x2, x16, xzr
    4eb8:      	mov	x22, x2
    4ebc:      	mov	x23, #0x20              ; =32
    4ec0:      	add	x16, sp, #0x20
    4ec4:      	ldr	w2, [x16, #0x4]
    4ec8:      	lsr	w2, w2, #0
    4ecc:      	mov	x24, x8
    4ed0:      	add	x8, sp, #0x30
    4ed4:      	mov	x25, x0
    4ed8:      	mov	w26, w1
    4edc:      	mov	w1, w2
    4ee0:      	bl	0x4ee0 <_stogir.atomic.validate+0x2f0>
		0000000000004ee0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    4ee4:      	add	x16, sp, #0x30
    4ee8:      	ldr	w0, [x16]
    4eec:      	lsr	x16, x0, #0
    4ef0:      	cmp	x16, #0x1
    4ef4:      	b.eq	0x4f10 <_stogir.atomic.validate+0x320>
    4ef8:      	b.lo	0x4f00 <_stogir.atomic.validate+0x310>
    4efc:      	b	0x4f14 <_stogir.atomic.validate+0x324>
    4f00:      	cmp	x16, #0x0
    4f04:      	b.eq	0x4f0c <_stogir.atomic.validate+0x31c>
    4f08:      	b	0x4f14 <_stogir.atomic.validate+0x324>
    4f0c:      	b	0x4f18 <_stogir.atomic.validate+0x328>
    4f10:      	b	0x5014 <_stogir.atomic.validate+0x424>
    4f14:      	b	0x5598 <_stogir.atomic.validate+0x9a8>
    4f18:      	adrp	x16, 0x4000 <_stogir.copy.validate+0x228>
		0000000000004f18:  ARM64_RELOC_PAGE21	l_stogir.370
    4f1c:      	ldr	x16, [x16]
		0000000000004f1c:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    4f20:      	orr	x0, x16, xzr
    4f24:      	mov	x1, #0x16               ; =22
    4f28:      	b	0x4f3c <_stogir.atomic.validate+0x34c>
    4f2c:      	movz	x5, #0x0, lsl #48
    4f30:      	b	0x4cdc <_stogir.atomic.validate+0xec>
    4f34:      	mov	x0, x1
    4f38:      	mov	x1, x2
    4f3c:      	cmp	x21, #0x82
    4f40:      	cset	w22, eq
    4f44:      	lsr	w19, w19, #0
    4f48:      	ubfx	x2, x19, #8, #8
    4f4c:      	orr	x19, x2, xzr
    4f50:      	cmp	x19, #0x0
    4f54:      	cset	w23, eq
    4f58:      	uxtb	w16, w22
    4f5c:      	cmp	w16, wzr
    4f60:      	b.eq	0x4f88 <_stogir.atomic.validate+0x398>
    4f64:      	uxtb	w16, w23
    4f68:      	cmp	w16, wzr
    4f6c:      	b.eq	0x5180 <_stogir.atomic.validate+0x590>
    4f70:      	mov	x2, x0
    4f74:      	movz	x0, #0x0, lsl #48
    4f78:      	b	0x5188 <_stogir.atomic.validate+0x598>
    4f7c:      	mov	x0, x2
    4f80:      	mov	x27, x1
    4f84:      	b	0x4f8c <_stogir.atomic.validate+0x39c>
    4f88:      	mov	x27, x1
    4f8c:      	uxtb	w16, w22
    4f90:      	cmp	w16, wzr
    4f94:      	b.eq	0x4fa4 <_stogir.atomic.validate+0x3b4>
    4f98:      	mov	x28, x0
    4f9c:      	movz	x0, #0x0, lsl #48
    4fa0:      	b	0x4fac <_stogir.atomic.validate+0x3bc>
    4fa4:      	mov	x28, x0
    4fa8:      	mov	x0, #0x1                ; =1
    4fac:      	cmp	x0, #0x0
    4fb0:      	b.eq	0x4fe4 <_stogir.atomic.validate+0x3f4>
    4fb4:      	add	x16, sp, #0x20
    4fb8:      	ldr	w0, [x16, #0x8]
    4fbc:      	lsr	w0, w0, #0
    4fc0:      	mov	w1, w0
    4fc4:      	mov	x0, x25
    4fc8:      	mov	x2, #0x6                ; =6
    4fcc:      	bl	0x4fcc <_stogir.atomic.validate+0x3dc>
		0000000000004fcc:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    4fd0:      	cmp	x0, #0x0
    4fd4:      	b.eq	0x5134 <_stogir.atomic.validate+0x544>
    4fd8:      	mov	x1, x28
    4fdc:      	movz	x0, #0x0, lsl #48
    4fe0:      	b	0x513c <_stogir.atomic.validate+0x54c>
    4fe4:      	mov	x0, x19
    4fe8:      	mov	x1, x28
    4fec:      	mov	x2, x27
    4ff0:      	cmp	x21, #0x80
    4ff4:      	cset	w19, eq
    4ff8:      	uxtb	w16, w19
    4ffc:      	cmp	w16, wzr
    5000:      	b.eq	0x5040 <_stogir.atomic.validate+0x450>
    5004:      	mov	x21, x1
    5008:      	mov	x23, x2
    500c:      	mov	x1, #0x1                ; =1
    5010:      	b	0x5058 <_stogir.atomic.validate+0x468>
    5014:      	add	x16, sp, #0x30
    5018:      	ldr	x0, [x16, #0x8]
    501c:      	add	x16, sp, #0x20
    5020:      	ldr	w1, [x16, #0x4]
    5024:      	sxtw	x1, w1
    5028:      	cmp	x1, #0x0
    502c:      	b.gt	0x51ec <_stogir.atomic.validate+0x5fc>
    5030:      	mov	x1, x22
    5034:      	mov	x2, x23
    5038:      	mov	x0, #0x1                ; =1
    503c:      	b	0x51d0 <_stogir.atomic.validate+0x5e0>
    5040:      	cmp	x21, #0x81
    5044:      	cset	w3, eq
    5048:      	ubfx	x3, x3, #0, #8
    504c:      	mov	x21, x1
    5050:      	mov	x1, x3
    5054:      	mov	x23, x2
    5058:      	lsr	w27, w0, #0
    505c:      	cmp	x1, #0x0
    5060:      	b.eq	0x4e60 <_stogir.atomic.validate+0x270>
    5064:      	lsr	w26, w26, #0
    5068:      	add	x16, sp, #0x90
    506c:      	str	x16, [sp]
    5070:      	mov	x0, x25
    5074:      	mov	w1, w26
    5078:      	mov	x2, #0x4                ; =4
    507c:      	bl	0x507c <_stogir.atomic.validate+0x48c>
		000000000000507c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    5080:      	ldr	x16, [sp]
    5084:      	str	x0, [x16]
    5088:      	str	x1, [x16, #0x8]
    508c:      	add	x16, sp, #0x90
    5090:      	ldr	x0, [x16]
    5094:      	add	x16, sp, #0x90
    5098:      	ldr	x1, [x16, #0x8]
    509c:      	lsr	w0, w0, #0
    50a0:      	lsr	x16, x0, #0
    50a4:      	cmp	x16, #0x1
    50a8:      	b.eq	0x50c4 <_stogir.atomic.validate+0x4d4>
    50ac:      	b.lo	0x50b4 <_stogir.atomic.validate+0x4c4>
    50b0:      	b	0x50c8 <_stogir.atomic.validate+0x4d8>
    50b4:      	cmp	x16, #0x0
    50b8:      	b.eq	0x50c0 <_stogir.atomic.validate+0x4d0>
    50bc:      	b	0x50c8 <_stogir.atomic.validate+0x4d8>
    50c0:      	b	0x50cc <_stogir.atomic.validate+0x4dc>
    50c4:      	b	0x5348 <_stogir.atomic.validate+0x758>
    50c8:      	b	0x55a8 <_stogir.atomic.validate+0x9b8>
    50cc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		00000000000050cc:  ARM64_RELOC_PAGE21	l_stogir.371
    50d0:      	ldr	x16, [x16]
		00000000000050d0:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    50d4:      	orr	x0, x16, xzr
    50d8:      	mov	x1, #0x1d               ; =29
    50dc:      	b	0x5108 <_stogir.atomic.validate+0x518>
    50e0:      	mov	x0, x1
    50e4:      	mov	x1, x2
    50e8:      	mov	x2, x1
    50ec:      	mov	x1, x0
    50f0:      	mov	x0, x19
    50f4:      	b	0x4ff0 <_stogir.atomic.validate+0x400>
    50f8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		00000000000050f8:  ARM64_RELOC_PAGE21	l_stogir.372
    50fc:      	ldr	x16, [x16]
		00000000000050fc:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    5100:      	orr	x0, x16, xzr
    5104:      	mov	x1, #0x24               ; =36
    5108:      	mov	x19, x0
    510c:      	mov	x21, x1
    5110:      	b	0x4e68 <_stogir.atomic.validate+0x278>
    5114:      	mov	x0, #0x1                ; =1
    5118:      	lsr	w0, w0, #0
    511c:      	sxtw	x0, w0
    5120:      	and	x0, x0, #0xffffffff
    5124:      	mov	x1, x0
    5128:      	movz	x0, #0x0, lsl #48
    512c:      	movz	x2, #0x0, lsl #48
    5130:      	b	0x4ea8 <_stogir.atomic.validate+0x2b8>
    5134:      	mov	x1, x28
    5138:      	mov	x0, #0x1                ; =1
    513c:      	cmp	x0, #0x0
    5140:      	b.eq	0x5158 <_stogir.atomic.validate+0x568>
    5144:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005144:  ARM64_RELOC_PAGE21	l_stogir.373
    5148:      	ldr	x16, [x16]
		0000000000005148:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    514c:      	orr	x0, x16, xzr
    5150:      	mov	x1, #0x1b               ; =27
    5154:      	b	0x5160 <_stogir.atomic.validate+0x570>
    5158:      	mov	x0, x1
    515c:      	mov	x1, x27
    5160:      	cmp	x21, #0x7f
    5164:      	b.ne	0x5250 <_stogir.atomic.validate+0x660>
    5168:      	uxtb	w16, w23
    516c:      	cmp	w16, wzr
    5170:      	b.eq	0x5388 <_stogir.atomic.validate+0x798>
    5174:      	mov	x2, x0
    5178:      	movz	x0, #0x0, lsl #48
    517c:      	b	0x5390 <_stogir.atomic.validate+0x7a0>
    5180:      	mov	x2, x0
    5184:      	mov	x0, #0x1                ; =1
    5188:      	cmp	x0, #0x0
    518c:      	b.eq	0x4f7c <_stogir.atomic.validate+0x38c>
    5190:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005190:  ARM64_RELOC_PAGE21	l_stogir.374
    5194:      	ldr	x16, [x16]
		0000000000005194:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    5198:      	orr	x0, x16, xzr
    519c:      	mov	x1, #0x19               ; =25
    51a0:      	b	0x4f80 <_stogir.atomic.validate+0x390>
    51a4:      	mov	x1, x3
    51a8:      	movz	x0, #0x0, lsl #48
    51ac:      	uxtb	w0, w0
    51b0:      	and	x0, x0, #0x4
    51b4:      	uxtb	w0, w0
    51b8:      	cmp	x0, #0x0
    51bc:      	cset	w0, eq
    51c0:      	uxtb	w16, w0
    51c4:      	cmp	w16, wzr
    51c8:      	cset	x0, eq
    51cc:      	mov	x2, x23
    51d0:      	cmp	x0, #0x0
    51d4:      	b.eq	0x4f34 <_stogir.atomic.validate+0x344>
    51d8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		00000000000051d8:  ARM64_RELOC_PAGE21	l_stogir.375
    51dc:      	ldr	x16, [x16]
		00000000000051dc:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    51e0:      	orr	x0, x16, xzr
    51e4:      	mov	x1, #0x16               ; =22
    51e8:      	b	0x4f3c <_stogir.atomic.validate+0x34c>
    51ec:      	uxtb	w0, w0
    51f0:      	cmp	x0, #0x83
    51f4:      	cset	w1, lt
    51f8:      	ubfx	x1, x1, #0, #8
    51fc:      	cmp	x1, #0x0
    5200:      	cset	w1, ne
    5204:      	uxtb	w16, w1
    5208:      	cmp	w16, wzr
    520c:      	b.eq	0x5468 <_stogir.atomic.validate+0x878>
    5210:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005210:  ARM64_RELOC_PAGE21	l_stogir.376
    5214:      	ldr	x16, [x16]
		0000000000005214:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    5218:      	orr	x2, x16, xzr
    521c:      	add	x2, x0, x2
    5220:      	ldrb	w2, [x2]
    5224:      	mov	x3, x22
    5228:      	b	0x5470 <_stogir.atomic.validate+0x880>
    522c:      	add	x16, sp, #0x60
    5230:      	ldr	x0, [x16, #0x8]
    5234:      	lsr	w0, w0, #0
    5238:      	ubfx	x0, x0, #8, #8
    523c:      	mov	x1, x23
    5240:      	mov	x2, x27
    5244:      	mov	x19, x0
    5248:      	mov	x0, x1
    524c:      	mov	x1, x2
    5250:      	cmp	x19, #0x2
    5254:      	b.ge	0x52fc <_stogir.atomic.validate+0x70c>
    5258:      	mov	x2, x1
    525c:      	mov	x1, x0
    5260:      	mov	x0, #0x1                ; =1
    5264:      	b	0x5318 <_stogir.atomic.validate+0x728>
    5268:      	mov	x1, x27
    526c:      	mov	x2, x23
    5270:      	movz	x0, #0x0, lsl #48
    5274:      	cmp	x0, #0x0
    5278:      	b.eq	0x50e0 <_stogir.atomic.validate+0x4f0>
    527c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		000000000000527c:  ARM64_RELOC_PAGE21	l_stogir.377
    5280:      	ldr	x16, [x16]
		0000000000005280:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    5284:      	orr	x0, x16, xzr
    5288:      	mov	x1, #0x22               ; =34
    528c:      	b	0x50e8 <_stogir.atomic.validate+0x4f8>
    5290:      	mov	x1, x27
    5294:      	mov	x0, #0x1                ; =1
    5298:      	mov	x2, x23
    529c:      	b	0x5274 <_stogir.atomic.validate+0x684>
    52a0:      	mov	x27, x0
    52a4:      	mov	x0, #0x1                ; =1
    52a8:      	cmp	x0, #0x0
    52ac:      	b.eq	0x5268 <_stogir.atomic.validate+0x678>
    52b0:      	lsr	w0, w19, #0
    52b4:      	add	x16, sp, #0x20
    52b8:      	ldr	w1, [x16, #0xc]
    52bc:      	lsr	w1, w1, #0
    52c0:      	mov	w2, w0
    52c4:      	mov	x0, x25
    52c8:      	bl	0x52c8 <_stogir.atomic.validate+0x6d8>
		00000000000052c8:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    52cc:      	cmp	x0, #0x0
    52d0:      	b.eq	0x5290 <_stogir.atomic.validate+0x6a0>
    52d4:      	mov	x1, x27
    52d8:      	movz	x0, #0x0, lsl #48
    52dc:      	b	0x5298 <_stogir.atomic.validate+0x6a8>
    52e0:      	mov	x0, x1
    52e4:      	mov	x23, x2
    52e8:      	cmp	x21, #0x7e
    52ec:      	b.ne	0x52a0 <_stogir.atomic.validate+0x6b0>
    52f0:      	mov	x27, x0
    52f4:      	movz	x0, #0x0, lsl #48
    52f8:      	b	0x52a8 <_stogir.atomic.validate+0x6b8>
    52fc:      	cmp	x19, #0x5
    5300:      	cset	w2, gt
    5304:      	ubfx	x2, x2, #0, #8
    5308:      	fmov	d31, x0
    530c:      	mov	x0, x2
    5310:      	mov	x2, x1
    5314:      	fmov	x1, d31
    5318:      	cmp	x0, #0x0
    531c:      	b.eq	0x52e0 <_stogir.atomic.validate+0x6f0>
    5320:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005320:  ARM64_RELOC_PAGE21	l_stogir.378
    5324:      	ldr	x16, [x16]
		0000000000005324:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    5328:      	orr	x0, x16, xzr
    532c:      	mov	x23, #0x25              ; =37
    5330:      	b	0x52e8 <_stogir.atomic.validate+0x6f8>
    5334:      	uxtb	w16, w22
    5338:      	cmp	w16, wzr
    533c:      	b.eq	0x5374 <_stogir.atomic.validate+0x784>
    5340:      	movz	x0, #0x0, lsl #48
    5344:      	b	0x5120 <_stogir.atomic.validate+0x530>
    5348:      	lsr	w1, w1, #0
    534c:      	uxtb	w16, w19
    5350:      	cmp	w16, wzr
    5354:      	b.eq	0x54bc <_stogir.atomic.validate+0x8cc>
    5358:      	sxtw	x1, w1
    535c:      	cmp	x1, #0x0
    5360:      	b.ge	0x5568 <_stogir.atomic.validate+0x978>
    5364:      	mov	x1, x21
    5368:      	mov	x2, x23
    536c:      	mov	x0, #0x1                ; =1
    5370:      	b	0x557c <_stogir.atomic.validate+0x98c>
    5374:      	sxtw	x27, w27
    5378:      	cmp	x27, #0x0
    537c:      	b.ne	0x54e0 <_stogir.atomic.validate+0x8f0>
    5380:      	movz	x0, #0x0, lsl #48
    5384:      	b	0x5118 <_stogir.atomic.validate+0x528>
    5388:      	mov	x2, x0
    538c:      	mov	x0, #0x1                ; =1
    5390:      	cmp	x0, #0x0
    5394:      	b.eq	0x53b0 <_stogir.atomic.validate+0x7c0>
    5398:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005398:  ARM64_RELOC_PAGE21	l_stogir.379
    539c:      	ldr	x16, [x16]
		000000000000539c:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    53a0:      	orr	x0, x16, xzr
    53a4:      	mov	x23, x0
    53a8:      	mov	x27, #0x19              ; =25
    53ac:      	b	0x53b8 <_stogir.atomic.validate+0x7c8>
    53b0:      	mov	x23, x2
    53b4:      	mov	x27, x1
    53b8:      	add	x16, sp, #0x20
    53bc:      	ldr	w0, [x16, #0xc]
    53c0:      	lsr	w0, w0, #0
    53c4:      	add	x8, sp, #0x60
    53c8:      	mov	w1, w0
    53cc:      	mov	x0, x25
    53d0:      	bl	0x53d0 <_stogir.atomic.validate+0x7e0>
		00000000000053d0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    53d4:      	add	x16, sp, #0x60
    53d8:      	ldr	w0, [x16]
    53dc:      	lsr	x16, x0, #0
    53e0:      	cmp	x16, #0x1
    53e4:      	b.eq	0x5400 <_stogir.atomic.validate+0x810>
    53e8:      	b.lo	0x53f0 <_stogir.atomic.validate+0x800>
    53ec:      	b	0x5404 <_stogir.atomic.validate+0x814>
    53f0:      	cmp	x16, #0x0
    53f4:      	b.eq	0x53fc <_stogir.atomic.validate+0x80c>
    53f8:      	b	0x5404 <_stogir.atomic.validate+0x814>
    53fc:      	b	0x5408 <_stogir.atomic.validate+0x818>
    5400:      	b	0x522c <_stogir.atomic.validate+0x63c>
    5404:      	b	0x55b0 <_stogir.atomic.validate+0x9c0>
    5408:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005408:  ARM64_RELOC_PAGE21	l_stogir.380
    540c:      	ldr	x16, [x16]
		000000000000540c:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    5410:      	orr	x0, x16, xzr
    5414:      	mov	x1, x0
    5418:      	mov	x0, x19
    541c:      	mov	x2, #0x1a               ; =26
    5420:      	b	0x5244 <_stogir.atomic.validate+0x654>
    5424:      	mov	x2, #0x1                ; =1
    5428:      	cmp	x2, #0x0
    542c:      	b.eq	0x5440 <_stogir.atomic.validate+0x850>
    5430:      	mov	x1, x3
    5434:      	mov	x2, x23
    5438:      	mov	x0, #0x1                ; =1
    543c:      	b	0x51d0 <_stogir.atomic.validate+0x5e0>
    5440:      	uxtb	w16, w1
    5444:      	cmp	w16, wzr
    5448:      	b.eq	0x51a4 <_stogir.atomic.validate+0x5b4>
    544c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		000000000000544c:  ARM64_RELOC_PAGE21	l_stogir.376
    5450:      	ldr	x16, [x16]
		0000000000005450:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    5454:      	orr	x1, x16, xzr
    5458:      	add	x0, x0, x1
    545c:      	ldrb	w0, [x0]
    5460:      	mov	x1, x3
    5464:      	b	0x51ac <_stogir.atomic.validate+0x5bc>
    5468:      	mov	x3, x22
    546c:      	movz	x2, #0x0, lsl #48
    5470:      	uxtb	w2, w2
    5474:      	and	x2, x2, #0x1
    5478:      	uxtb	w2, w2
    547c:      	cmp	x2, #0x0
    5480:      	b.eq	0x5424 <_stogir.atomic.validate+0x834>
    5484:      	movz	x2, #0x0, lsl #48
    5488:      	b	0x5428 <_stogir.atomic.validate+0x838>
    548c:      	mov	x3, #-0x2               ; =-2
    5490:      	sxtw	x2, w2
    5494:      	lsr	w3, w3, #0
    5498:      	sxtw	x3, w3
    549c:      	cmp	x2, x3
    54a0:      	b.ne	0x4eac <_stogir.atomic.validate+0x2bc>
    54a4:      	mov	x22, x20
    54a8:      	movz	x23, #0x0, lsl #48
    54ac:      	b	0x4ec0 <_stogir.atomic.validate+0x2d0>
    54b0:      	mov	x0, x1
    54b4:      	mov	x1, x2
    54b8:      	b	0x5108 <_stogir.atomic.validate+0x518>
    54bc:      	lsr	w1, w1, #0
    54c0:      	mov	x0, x25
    54c4:      	mov	w2, w27
    54c8:      	bl	0x54c8 <_stogir.atomic.validate+0x8d8>
		00000000000054c8:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    54cc:      	cmp	x0, #0x0
    54d0:      	b.eq	0x50f8 <_stogir.atomic.validate+0x508>
    54d4:      	mov	x0, x21
    54d8:      	mov	x1, x23
    54dc:      	b	0x5108 <_stogir.atomic.validate+0x518>
    54e0:      	cmp	x27, #0x1
    54e4:      	b.eq	0x5114 <_stogir.atomic.validate+0x524>
    54e8:      	cmp	x27, #0x2
    54ec:      	b.eq	0x5114 <_stogir.atomic.validate+0x524>
    54f0:      	cmp	x27, #0x7
    54f4:      	b.eq	0x5114 <_stogir.atomic.validate+0x524>
    54f8:      	cmp	x27, #0x8
    54fc:      	b.eq	0x5114 <_stogir.atomic.validate+0x524>
    5500:      	cmp	x27, #0x3
    5504:      	b.eq	0x55a0 <_stogir.atomic.validate+0x9b0>
    5508:      	cmp	x27, #0x9
    550c:      	b.eq	0x55a0 <_stogir.atomic.validate+0x9b0>
    5510:      	cmp	x27, #0x4
    5514:      	b.eq	0x55b8 <_stogir.atomic.validate+0x9c8>
    5518:      	cmp	x27, #0xa
    551c:      	b.eq	0x55b8 <_stogir.atomic.validate+0x9c8>
    5520:      	cmp	x27, #0xd
    5524:      	b.eq	0x55b8 <_stogir.atomic.validate+0x9c8>
    5528:      	cmp	x27, #0x5
    552c:      	b.eq	0x55c0 <_stogir.atomic.validate+0x9d0>
    5530:      	cmp	x27, #0xb
    5534:      	b.eq	0x55c0 <_stogir.atomic.validate+0x9d0>
    5538:      	cmp	x27, #0xc
    553c:      	b.eq	0x55c0 <_stogir.atomic.validate+0x9d0>
    5540:      	cmp	x27, #0x6
    5544:      	cset	w0, eq
    5548:      	uxtb	w16, w0
    554c:      	cmp	w16, wzr
    5550:      	mov	x16, #0x8               ; =8
    5554:      	movn	x17, #0x0, lsl #48
    5558:      	csel	x0, x16, x17, ne
    555c:      	b	0x55c4 <_stogir.atomic.validate+0x9d4>
    5560:      	brk	#0
    5564:      	b	0x5560 <_stogir.atomic.validate+0x970>
    5568:      	cmp	x1, #0x9
    556c:      	cset	w0, gt
    5570:      	ubfx	x0, x0, #0, #8
    5574:      	mov	x1, x21
    5578:      	mov	x2, x23
    557c:      	cmp	x0, #0x0
    5580:      	b.eq	0x54b0 <_stogir.atomic.validate+0x8c0>
    5584:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005584:  ARM64_RELOC_PAGE21	l_stogir.381
    5588:      	ldr	x16, [x16]
		0000000000005588:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    558c:      	orr	x0, x16, xzr
    5590:      	mov	x1, #0x1c               ; =28
    5594:      	b	0x54b8 <_stogir.atomic.validate+0x8c8>
    5598:      	brk	#0
    559c:      	b	0x5598 <_stogir.atomic.validate+0x9a8>
    55a0:      	mov	x0, #0x2                ; =2
    55a4:      	b	0x5118 <_stogir.atomic.validate+0x528>
    55a8:      	brk	#0
    55ac:      	b	0x55a8 <_stogir.atomic.validate+0x9b8>
    55b0:      	brk	#0
    55b4:      	b	0x55b0 <_stogir.atomic.validate+0x9c0>
    55b8:      	mov	x0, #0x4                ; =4
    55bc:      	b	0x55a4 <_stogir.atomic.validate+0x9b4>
    55c0:      	mov	x0, #0x8                ; =8
    55c4:      	b	0x55bc <_stogir.atomic.validate+0x9cc>

00000000000055c8 <_stogir.terminal.operation?>:
    55c8:      	sxtw	x0, w0
    55cc:      	cmp	x0, #0x60
    55d0:      	b.ne	0x55dc <_stogir.terminal.operation?+0x14>
    55d4:      	mov	x0, #0x1                ; =1
    55d8:      	b	0x55e8 <_stogir.terminal.operation?+0x20>
    55dc:      	cmp	x0, #0x79
    55e0:      	cset	w0, eq
    55e4:      	ubfx	x0, x0, #0, #8
    55e8:      	ret

00000000000055ec <_stogir.terminal.validate>:
    55ec:      	sub	sp, sp, #0x50
    55f0:      	str	x29, [sp]
    55f4:      	str	x30, [sp, #0x8]
    55f8:      	mov	x29, sp
    55fc:      	str	x19, [sp, #0x40]
    5600:      	sxtw	x1, w1
    5604:      	lsl	x2, x1, #2
    5608:      	cmp	x1, #0x0
    560c:      	cset	w3, gt
    5610:      	movz	x16, #0x0, lsl #48
    5614:      	sub	x4, x16, x1
    5618:      	sub	x5, x4, #0x1
    561c:      	uxtb	w16, w3
    5620:      	cmp	w16, wzr
    5624:      	b.eq	0x5664 <_stogir.terminal.validate+0x78>
    5628:      	ldr	x4, [x0, #0x8]
    562c:      	cmp	x1, x4
    5630:      	b.ge	0x56b8 <_stogir.terminal.validate+0xcc>
    5634:      	add	x4, x0, #0x78
    5638:      	ldr	x4, [x4, #0x8]
    563c:      	cmp	x1, x4
    5640:      	b.ge	0x57dc <_stogir.terminal.validate+0x1f0>
    5644:      	ldr	x4, [x0, #0x78]
    5648:      	add	x4, x2, x4
    564c:      	ldr	w4, [x4]
    5650:      	sxtw	x4, w4
    5654:      	cmp	x4, #0x0
    5658:      	cset	w4, ge
    565c:      	ubfx	x4, x4, #0, #8
    5660:      	b	0x57e0 <_stogir.terminal.validate+0x1f4>
    5664:      	cmp	x1, #0x0
    5668:      	b.ge	0x56c0 <_stogir.terminal.validate+0xd4>
    566c:      	add	x6, x0, #0x28
    5670:      	add	x7, x0, #0x50
    5674:      	ldr	x6, [x6, #0x8]
    5678:      	ldr	x7, [x7, #0x8]
    567c:      	cmp	x6, x7
    5680:      	b.ne	0x56b0 <_stogir.terminal.validate+0xc4>
    5684:      	cmp	x4, x6
    5688:      	b.gt	0x581c <_stogir.terminal.validate+0x230>
    568c:      	lsl	x4, x5, #2
    5690:      	ldr	x6, [x0, #0x50]
    5694:      	add	x4, x4, x6
    5698:      	ldr	w4, [x4]
    569c:      	sxtw	x4, w4
    56a0:      	cmp	x4, #0x0
    56a4:      	cset	w4, gt
    56a8:      	ubfx	x4, x4, #0, #8
    56ac:      	b	0x5820 <_stogir.terminal.validate+0x234>
    56b0:      	movz	x4, #0x0, lsl #48
    56b4:      	b	0x56c4 <_stogir.terminal.validate+0xd8>
    56b8:      	movz	x4, #0x0, lsl #48
    56bc:      	b	0x56c4 <_stogir.terminal.validate+0xd8>
    56c0:      	movz	x4, #0x0, lsl #48
    56c4:      	cmp	x4, #0x0
    56c8:      	b.eq	0x572c <_stogir.terminal.validate+0x140>
    56cc:      	uxtb	w16, w3
    56d0:      	cmp	w16, wzr
    56d4:      	b.eq	0x56fc <_stogir.terminal.validate+0x110>
    56d8:      	lsl	x3, x1, #4
    56dc:      	ldr	x4, [x0]
    56e0:      	add	x3, x3, x4
    56e4:      	ldr	x4, [x3]
    56e8:      	ldr	x3, [x3, #0x8]
    56ec:      	fmov	d31, x3
    56f0:      	mov	x3, x4
    56f4:      	fmov	x4, d31
    56f8:      	b	0x571c <_stogir.terminal.validate+0x130>
    56fc:      	lsl	x3, x5, #4
    5700:      	ldr	x4, [x0, #0x28]
    5704:      	add	x3, x3, x4
    5708:      	ldr	x4, [x3]
    570c:      	ldr	x3, [x3, #0x8]
    5710:      	fmov	d31, x3
    5714:      	mov	x3, x4
    5718:      	fmov	x4, d31
    571c:      	mov	x5, x4
    5720:      	mov	x4, x3
    5724:      	mov	x3, #0x1                ; =1
    5728:      	b	0x5738 <_stogir.terminal.validate+0x14c>
    572c:      	movz	x3, #0x0, lsl #48
    5730:      	movz	x4, #0x0, lsl #48
    5734:      	movz	x5, #0x0, lsl #48
    5738:      	lsr	w3, w3, #0
    573c:      	lsr	x16, x3, #0
    5740:      	cmp	x16, #0x1
    5744:      	b.eq	0x5760 <_stogir.terminal.validate+0x174>
    5748:      	b.lo	0x5750 <_stogir.terminal.validate+0x164>
    574c:      	b	0x5764 <_stogir.terminal.validate+0x178>
    5750:      	cmp	x16, #0x0
    5754:      	b.eq	0x575c <_stogir.terminal.validate+0x170>
    5758:      	b	0x5764 <_stogir.terminal.validate+0x178>
    575c:      	b	0x5768 <_stogir.terminal.validate+0x17c>
    5760:      	b	0x5788 <_stogir.terminal.validate+0x19c>
    5764:      	b	0x58f8 <_stogir.terminal.validate+0x30c>
    5768:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005768:  ARM64_RELOC_PAGE21	l_stogir.382
    576c:      	ldr	x16, [x16]
		000000000000576c:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    5770:      	orr	x0, x16, xzr
    5774:      	mov	x19, x8
    5778:      	mov	x1, x0
    577c:      	mov	x0, #0x1                ; =1
    5780:      	mov	x2, #0x21               ; =33
    5784:      	b	0x57bc <_stogir.terminal.validate+0x1d0>
    5788:      	add	x16, sp, #0x10
    578c:      	str	x4, [x16]
    5790:      	add	x16, sp, #0x10
    5794:      	str	x5, [x16, #0x8]
    5798:      	cmp	x1, #0x0
    579c:      	b.gt	0x57e4 <_stogir.terminal.validate+0x1f8>
    57a0:      	mov	x19, x8
    57a4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		00000000000057a4:  ARM64_RELOC_PAGE21	l_stogir.383
    57a8:      	ldr	x16, [x16]
		00000000000057a8:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    57ac:      	orr	x0, x16, xzr
    57b0:      	mov	x1, x0
    57b4:      	mov	x0, #0x1                ; =1
    57b8:      	mov	x2, #0x1b               ; =27
    57bc:      	str	x0, [x19]
    57c0:      	str	x1, [x19, #0x8]
    57c4:      	str	x2, [x19, #0x10]
    57c8:      	ldr	x19, [sp, #0x40]
    57cc:      	ldr	x29, [sp]
    57d0:      	ldr	x30, [sp, #0x8]
    57d4:      	add	sp, sp, #0x50
    57d8:      	ret
    57dc:      	movz	x4, #0x0, lsl #48
    57e0:      	b	0x56bc <_stogir.terminal.validate+0xd0>
    57e4:      	uxtb	w4, w4
    57e8:      	orr	x1, x4, xzr
    57ec:      	cmp	x1, #0x60
    57f0:      	cset	w3, eq
    57f4:      	cmp	x1, #0x79
    57f8:      	cset	w1, eq
    57fc:      	uxtb	w16, w3
    5800:      	cmp	w16, wzr
    5804:      	b.ne	0x5824 <_stogir.terminal.validate+0x238>
    5808:      	uxtb	w16, w1
    580c:      	cmp	w16, wzr
    5810:      	b.ne	0x5824 <_stogir.terminal.validate+0x238>
    5814:      	mov	x19, x8
    5818:      	b	0x57a4 <_stogir.terminal.validate+0x1b8>
    581c:      	movz	x4, #0x0, lsl #48
    5820:      	b	0x56b4 <_stogir.terminal.validate+0xc8>
    5824:      	add	x16, sp, #0x10
    5828:      	ldr	w5, [x16]
    582c:      	ubfx	x5, x5, #8, #8
    5830:      	cmp	x5, #0x0
    5834:      	b.ne	0x5900 <_stogir.terminal.validate+0x314>
    5838:      	uxtb	w16, w3
    583c:      	cmp	w16, wzr
    5840:      	mov	x16, #0x1               ; =1
    5844:      	mov	x17, #0x3               ; =3
    5848:      	csel	x3, x16, x17, ne
    584c:      	lsr	w3, w3, #0
    5850:      	sxtw	x3, w3
    5854:      	ldr	x5, [x0, #0x78]
    5858:      	add	x2, x2, x5
    585c:      	ldr	w2, [x2]
    5860:      	sxtw	x2, w2
    5864:      	cmp	x2, x3
    5868:      	b.ne	0x5908 <_stogir.terminal.validate+0x31c>
    586c:      	uxtb	w16, w1
    5870:      	cmp	w16, wzr
    5874:      	b.eq	0x58d4 <_stogir.terminal.validate+0x2e8>
    5878:      	add	x16, sp, #0x10
    587c:      	ldr	w2, [x16, #0x8]
    5880:      	sxtw	x2, w2
    5884:      	cmp	x2, #0x0
    5888:      	b.eq	0x58d4 <_stogir.terminal.validate+0x2e8>
    588c:      	mov	x19, x8
    5890:      	b	0x57a4 <_stogir.terminal.validate+0x1b8>
    5894:      	movz	x1, #0x0, lsl #48
    5898:      	lsr	w2, w2, #0
    589c:      	lsr	w4, w4, #0
    58a0:      	lsr	w1, w1, #0
    58a4:      	mov	w3, w1
    58a8:      	mov	w1, w4
    58ac:      	mov	x19, x8
    58b0:      	add	x8, sp, #0x20
    58b4:      	bl	0x58b4 <_stogir.terminal.validate+0x2c8>
		00000000000058b4:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    58b8:      	add	x16, sp, #0x20
    58bc:      	ldr	x0, [x16]
    58c0:      	add	x16, sp, #0x20
    58c4:      	ldr	x1, [x16, #0x8]
    58c8:      	add	x16, sp, #0x20
    58cc:      	ldr	x2, [x16, #0x10]
    58d0:      	b	0x57bc <_stogir.terminal.validate+0x1d0>
    58d4:      	add	x16, sp, #0x10
    58d8:      	ldr	w2, [x16, #0x4]
    58dc:      	uxtb	w16, w1
    58e0:      	cmp	w16, wzr
    58e4:      	b.eq	0x5894 <_stogir.terminal.validate+0x2a8>
    58e8:      	add	x16, sp, #0x10
    58ec:      	ldr	w1, [x16, #0xc]
    58f0:      	sxtw	x1, w1
    58f4:      	b	0x5898 <_stogir.terminal.validate+0x2ac>
    58f8:      	brk	#0
    58fc:      	b	0x58f8 <_stogir.terminal.validate+0x30c>
    5900:      	mov	x19, x8
    5904:      	b	0x57a4 <_stogir.terminal.validate+0x1b8>
    5908:      	mov	x19, x8
    590c:      	b	0x57a4 <_stogir.terminal.validate+0x1b8>

0000000000005910 <_stogir.switch.operation?>:
    5910:      	sxtw	x0, w0
    5914:      	cmp	x0, #0x75
    5918:      	b.ne	0x592c <_stogir.switch.operation?+0x1c>
    591c:      	mov	x0, #0x1                ; =1
    5920:      	b	0x5928 <_stogir.switch.operation?+0x18>
    5924:      	movz	x0, #0x0, lsl #48
    5928:      	ret
    592c:      	cmp	x0, #0x6d
    5930:      	b.lt	0x5924 <_stogir.switch.operation?+0x14>
    5934:      	cmp	x0, #0x6f
    5938:      	cset	w0, le
    593c:      	ubfx	x0, x0, #0, #8
    5940:      	b	0x5928 <_stogir.switch.operation?+0x18>

0000000000005944 <_stogir.switch.validate>:
    5944:      	sub	sp, sp, #0x70
    5948:      	str	x29, [sp]
    594c:      	str	x30, [sp, #0x8]
    5950:      	mov	x29, sp
    5954:      	str	x19, [sp, #0x60]
    5958:      	sxtw	x1, w1
    595c:      	lsl	x2, x1, #2
    5960:      	cmp	x1, #0x0
    5964:      	cset	w3, gt
    5968:      	movz	x16, #0x0, lsl #48
    596c:      	sub	x4, x16, x1
    5970:      	sub	x5, x4, #0x1
    5974:      	uxtb	w16, w3
    5978:      	cmp	w16, wzr
    597c:      	b.eq	0x59bc <_stogir.switch.validate+0x78>
    5980:      	ldr	x4, [x0, #0x8]
    5984:      	cmp	x1, x4
    5988:      	b.ge	0x5a10 <_stogir.switch.validate+0xcc>
    598c:      	add	x4, x0, #0x78
    5990:      	ldr	x4, [x4, #0x8]
    5994:      	cmp	x1, x4
    5998:      	b.ge	0x5b34 <_stogir.switch.validate+0x1f0>
    599c:      	ldr	x4, [x0, #0x78]
    59a0:      	add	x4, x2, x4
    59a4:      	ldr	w4, [x4]
    59a8:      	sxtw	x4, w4
    59ac:      	cmp	x4, #0x0
    59b0:      	cset	w4, ge
    59b4:      	ubfx	x4, x4, #0, #8
    59b8:      	b	0x5b38 <_stogir.switch.validate+0x1f4>
    59bc:      	cmp	x1, #0x0
    59c0:      	b.ge	0x5a18 <_stogir.switch.validate+0xd4>
    59c4:      	add	x6, x0, #0x28
    59c8:      	add	x7, x0, #0x50
    59cc:      	ldr	x6, [x6, #0x8]
    59d0:      	ldr	x7, [x7, #0x8]
    59d4:      	cmp	x6, x7
    59d8:      	b.ne	0x5a08 <_stogir.switch.validate+0xc4>
    59dc:      	cmp	x4, x6
    59e0:      	b.gt	0x5b70 <_stogir.switch.validate+0x22c>
    59e4:      	lsl	x4, x5, #2
    59e8:      	ldr	x6, [x0, #0x50]
    59ec:      	add	x4, x4, x6
    59f0:      	ldr	w4, [x4]
    59f4:      	sxtw	x4, w4
    59f8:      	cmp	x4, #0x0
    59fc:      	cset	w4, gt
    5a00:      	ubfx	x4, x4, #0, #8
    5a04:      	b	0x5b74 <_stogir.switch.validate+0x230>
    5a08:      	movz	x4, #0x0, lsl #48
    5a0c:      	b	0x5a1c <_stogir.switch.validate+0xd8>
    5a10:      	movz	x4, #0x0, lsl #48
    5a14:      	b	0x5a1c <_stogir.switch.validate+0xd8>
    5a18:      	movz	x4, #0x0, lsl #48
    5a1c:      	cmp	x4, #0x0
    5a20:      	b.eq	0x5a84 <_stogir.switch.validate+0x140>
    5a24:      	uxtb	w16, w3
    5a28:      	cmp	w16, wzr
    5a2c:      	b.eq	0x5a54 <_stogir.switch.validate+0x110>
    5a30:      	lsl	x3, x1, #4
    5a34:      	ldr	x4, [x0]
    5a38:      	add	x3, x3, x4
    5a3c:      	ldr	x4, [x3]
    5a40:      	ldr	x3, [x3, #0x8]
    5a44:      	fmov	d31, x3
    5a48:      	mov	x3, x4
    5a4c:      	fmov	x4, d31
    5a50:      	b	0x5a74 <_stogir.switch.validate+0x130>
    5a54:      	lsl	x3, x5, #4
    5a58:      	ldr	x4, [x0, #0x28]
    5a5c:      	add	x3, x3, x4
    5a60:      	ldr	x4, [x3]
    5a64:      	ldr	x3, [x3, #0x8]
    5a68:      	fmov	d31, x3
    5a6c:      	mov	x3, x4
    5a70:      	fmov	x4, d31
    5a74:      	mov	x5, x4
    5a78:      	mov	x4, x3
    5a7c:      	mov	x3, #0x1                ; =1
    5a80:      	b	0x5a90 <_stogir.switch.validate+0x14c>
    5a84:      	movz	x3, #0x0, lsl #48
    5a88:      	movz	x4, #0x0, lsl #48
    5a8c:      	movz	x5, #0x0, lsl #48
    5a90:      	lsr	w3, w3, #0
    5a94:      	lsr	x16, x3, #0
    5a98:      	cmp	x16, #0x1
    5a9c:      	b.eq	0x5ab8 <_stogir.switch.validate+0x174>
    5aa0:      	b.lo	0x5aa8 <_stogir.switch.validate+0x164>
    5aa4:      	b	0x5abc <_stogir.switch.validate+0x178>
    5aa8:      	cmp	x16, #0x0
    5aac:      	b.eq	0x5ab4 <_stogir.switch.validate+0x170>
    5ab0:      	b	0x5abc <_stogir.switch.validate+0x178>
    5ab4:      	b	0x5ac0 <_stogir.switch.validate+0x17c>
    5ab8:      	b	0x5ae0 <_stogir.switch.validate+0x19c>
    5abc:      	b	0x5c74 <_stogir.switch.validate+0x330>
    5ac0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005ac0:  ARM64_RELOC_PAGE21	l_stogir.384
    5ac4:      	ldr	x16, [x16]
		0000000000005ac4:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    5ac8:      	orr	x0, x16, xzr
    5acc:      	mov	x19, x8
    5ad0:      	mov	x1, x0
    5ad4:      	mov	x0, #0x1                ; =1
    5ad8:      	mov	x2, #0x1a               ; =26
    5adc:      	b	0x5b14 <_stogir.switch.validate+0x1d0>
    5ae0:      	add	x16, sp, #0x10
    5ae4:      	str	x4, [x16]
    5ae8:      	add	x16, sp, #0x10
    5aec:      	str	x5, [x16, #0x8]
    5af0:      	cmp	x1, #0x0
    5af4:      	b.gt	0x5b3c <_stogir.switch.validate+0x1f8>
    5af8:      	mov	x19, x8
    5afc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005afc:  ARM64_RELOC_PAGE21	l_stogir.385
    5b00:      	ldr	x16, [x16]
		0000000000005b00:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    5b04:      	orr	x0, x16, xzr
    5b08:      	mov	x1, x0
    5b0c:      	mov	x0, #0x1                ; =1
    5b10:      	mov	x2, #0x20               ; =32
    5b14:      	str	x0, [x19]
    5b18:      	str	x1, [x19, #0x8]
    5b1c:      	str	x2, [x19, #0x10]
    5b20:      	ldr	x19, [sp, #0x60]
    5b24:      	ldr	x29, [sp]
    5b28:      	ldr	x30, [sp, #0x8]
    5b2c:      	add	sp, sp, #0x70
    5b30:      	ret
    5b34:      	movz	x4, #0x0, lsl #48
    5b38:      	b	0x5a14 <_stogir.switch.validate+0xd0>
    5b3c:      	uxtb	w4, w4
    5b40:      	orr	x1, x4, xzr
    5b44:      	cmp	x1, #0x75
    5b48:      	cset	w3, eq
    5b4c:      	uxtb	w16, w3
    5b50:      	cmp	w16, wzr
    5b54:      	b.ne	0x5b78 <_stogir.switch.validate+0x234>
    5b58:      	cmp	x1, #0x6d
    5b5c:      	b.lt	0x5c7c <_stogir.switch.validate+0x338>
    5b60:      	cmp	x1, #0x6f
    5b64:      	b.le	0x5b78 <_stogir.switch.validate+0x234>
    5b68:      	mov	x19, x8
    5b6c:      	b	0x5afc <_stogir.switch.validate+0x1b8>
    5b70:      	movz	x4, #0x0, lsl #48
    5b74:      	b	0x5a0c <_stogir.switch.validate+0xc8>
    5b78:      	add	x16, sp, #0x10
    5b7c:      	ldr	w5, [x16]
    5b80:      	ubfx	x5, x5, #8, #8
    5b84:      	cmp	x5, #0x0
    5b88:      	b.ne	0x5c84 <_stogir.switch.validate+0x340>
    5b8c:      	ldr	x5, [x0, #0x78]
    5b90:      	add	x2, x2, x5
    5b94:      	ldr	w2, [x2]
    5b98:      	cmp	x1, #0x6d
    5b9c:      	b.eq	0x5c10 <_stogir.switch.validate+0x2cc>
    5ba0:      	cmp	x1, #0x6e
    5ba4:      	b.eq	0x5c10 <_stogir.switch.validate+0x2cc>
    5ba8:      	mov	x1, #0x2                ; =2
    5bac:      	b	0x5c14 <_stogir.switch.validate+0x2d0>
    5bb0:      	lsr	w4, w4, #0
    5bb4:      	add	x16, sp, #0x10
    5bb8:      	ldr	w1, [x16, #0x4]
    5bbc:      	add	x16, sp, #0x10
    5bc0:      	ldr	w2, [x16, #0x8]
    5bc4:      	lsr	w1, w1, #0
    5bc8:      	add	x16, sp, #0x10
    5bcc:      	ldr	w3, [x16, #0xc]
    5bd0:      	lsr	w2, w2, #0
    5bd4:      	lsr	w3, w3, #0
    5bd8:      	add	x8, sp, #0x40
    5bdc:      	fmov	s31, w1
    5be0:      	mov	w1, w4
    5be4:      	mov	w4, w3
    5be8:      	mov	w3, w2
    5bec:      	fmov	w2, s31
    5bf0:      	bl	0x5bf0 <_stogir.switch.validate+0x2ac>
		0000000000005bf0:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    5bf4:      	add	x16, sp, #0x40
    5bf8:      	ldr	x0, [x16]
    5bfc:      	add	x16, sp, #0x40
    5c00:      	ldr	x1, [x16, #0x8]
    5c04:      	add	x16, sp, #0x40
    5c08:      	ldr	x2, [x16, #0x10]
    5c0c:      	b	0x5b14 <_stogir.switch.validate+0x1d0>
    5c10:      	mov	x1, #0x3                ; =3
    5c14:      	sxtw	x2, w2
    5c18:      	lsr	w1, w1, #0
    5c1c:      	sxtw	x1, w1
    5c20:      	cmp	x2, x1
    5c24:      	b.ne	0x5c8c <_stogir.switch.validate+0x348>
    5c28:      	uxtb	w16, w3
    5c2c:      	cmp	w16, wzr
    5c30:      	b.eq	0x5c94 <_stogir.switch.validate+0x350>
    5c34:      	add	x16, sp, #0x10
    5c38:      	ldr	w1, [x16, #0x4]
    5c3c:      	add	x16, sp, #0x10
    5c40:      	ldr	w2, [x16, #0x8]
    5c44:      	lsr	w1, w1, #0
    5c48:      	lsr	w2, w2, #0
    5c4c:      	mov	x19, x8
    5c50:      	add	x8, sp, #0x20
    5c54:      	bl	0x5c54 <_stogir.switch.validate+0x310>
		0000000000005c54:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5c58:      	add	x16, sp, #0x20
    5c5c:      	ldr	x0, [x16]
    5c60:      	add	x16, sp, #0x20
    5c64:      	ldr	x1, [x16, #0x8]
    5c68:      	add	x16, sp, #0x20
    5c6c:      	ldr	x2, [x16, #0x10]
    5c70:      	b	0x5c0c <_stogir.switch.validate+0x2c8>
    5c74:      	brk	#0
    5c78:      	b	0x5c74 <_stogir.switch.validate+0x330>
    5c7c:      	mov	x19, x8
    5c80:      	b	0x5afc <_stogir.switch.validate+0x1b8>
    5c84:      	mov	x19, x8
    5c88:      	b	0x5afc <_stogir.switch.validate+0x1b8>
    5c8c:      	mov	x19, x8
    5c90:      	b	0x5afc <_stogir.switch.validate+0x1b8>
    5c94:      	mov	x19, x8
    5c98:      	b	0x5bb0 <_stogir.switch.validate+0x26c>

0000000000005c9c <_stogir.stack.operation?>:
    5c9c:      	sxtw	x0, w0
    5ca0:      	cmp	x0, #0x42
    5ca4:      	b.ne	0x5cc0 <_stogir.stack.operation?+0x24>
    5ca8:      	mov	x0, #0x1                ; =1
    5cac:      	b	0x5cbc <_stogir.stack.operation?+0x20>
    5cb0:      	cmp	x0, #0x54
    5cb4:      	cset	w0, eq
    5cb8:      	ubfx	x0, x0, #0, #8
    5cbc:      	ret
    5cc0:      	cmp	x0, #0x51
    5cc4:      	b.ne	0x5cd0 <_stogir.stack.operation?+0x34>
    5cc8:      	mov	x0, #0x1                ; =1
    5ccc:      	b	0x5cbc <_stogir.stack.operation?+0x20>
    5cd0:      	cmp	x0, #0x52
    5cd4:      	b.ne	0x5ce0 <_stogir.stack.operation?+0x44>
    5cd8:      	mov	x0, #0x1                ; =1
    5cdc:      	b	0x5cbc <_stogir.stack.operation?+0x20>
    5ce0:      	cmp	x0, #0x53
    5ce4:      	b.ne	0x5cb0 <_stogir.stack.operation?+0x14>
    5ce8:      	mov	x0, #0x1                ; =1
    5cec:      	b	0x5cbc <_stogir.stack.operation?+0x20>

0000000000005cf0 <_stogir.stack.validate>:
    5cf0:      	sub	sp, sp, #0x90
    5cf4:      	str	x29, [sp]
    5cf8:      	str	x30, [sp, #0x8]
    5cfc:      	mov	x29, sp
    5d00:      	str	x19, [sp, #0x60]
    5d04:      	str	x20, [sp, #0x68]
    5d08:      	str	x21, [sp, #0x70]
    5d0c:      	str	x22, [sp, #0x78]
    5d10:      	str	x23, [sp, #0x80]
    5d14:      	sxtw	x1, w1
    5d18:      	lsl	x2, x1, #2
    5d1c:      	cmp	x1, #0x0
    5d20:      	cset	w3, gt
    5d24:      	movz	x16, #0x0, lsl #48
    5d28:      	sub	x4, x16, x1
    5d2c:      	cmp	x1, #0x0
    5d30:      	cset	w5, lt
    5d34:      	sub	x6, x4, #0x1
    5d38:      	lsl	x7, x6, #2
    5d3c:      	uxtb	w16, w3
    5d40:      	cmp	w16, wzr
    5d44:      	b.eq	0x5d84 <_stogir.stack.validate+0x94>
    5d48:      	ldr	x9, [x0, #0x8]
    5d4c:      	cmp	x1, x9
    5d50:      	b.ge	0x5e04 <_stogir.stack.validate+0x114>
    5d54:      	add	x9, x0, #0x78
    5d58:      	ldr	x9, [x9, #0x8]
    5d5c:      	cmp	x1, x9
    5d60:      	b.ge	0x5f70 <_stogir.stack.validate+0x280>
    5d64:      	ldr	x9, [x0, #0x78]
    5d68:      	add	x9, x2, x9
    5d6c:      	ldr	w9, [x9]
    5d70:      	sxtw	x9, w9
    5d74:      	cmp	x9, #0x0
    5d78:      	cset	w9, ge
    5d7c:      	ubfx	x9, x9, #0, #8
    5d80:      	b	0x5f74 <_stogir.stack.validate+0x284>
    5d84:      	uxtb	w16, w5
    5d88:      	cmp	w16, wzr
    5d8c:      	b.eq	0x5e0c <_stogir.stack.validate+0x11c>
    5d90:      	add	x9, x0, #0x28
    5d94:      	add	x10, x0, #0x50
    5d98:      	ldr	x9, [x9, #0x8]
    5d9c:      	ldr	x10, [x10, #0x8]
    5da0:      	cmp	x9, x10
    5da4:      	b.ne	0x5dd0 <_stogir.stack.validate+0xe0>
    5da8:      	cmp	x4, x9
    5dac:      	b.gt	0x5f78 <_stogir.stack.validate+0x288>
    5db0:      	ldr	x9, [x0, #0x50]
    5db4:      	add	x9, x7, x9
    5db8:      	ldr	w9, [x9]
    5dbc:      	sxtw	x9, w9
    5dc0:      	cmp	x9, #0x0
    5dc4:      	cset	w9, gt
    5dc8:      	ubfx	x9, x9, #0, #8
    5dcc:      	b	0x5f7c <_stogir.stack.validate+0x28c>
    5dd0:      	movz	x9, #0x0, lsl #48
    5dd4:      	b	0x5e10 <_stogir.stack.validate+0x120>
    5dd8:      	uxtb	w16, w9
    5ddc:      	cmp	w16, wzr
    5de0:      	b.eq	0x5fa0 <_stogir.stack.validate+0x2b0>
    5de4:      	mov	x22, x8
    5de8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005de8:  ARM64_RELOC_PAGE21	l_stogir.386
    5dec:      	ldr	x16, [x16]
		0000000000005dec:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5df0:      	orr	x0, x16, xzr
    5df4:      	mov	x1, x0
    5df8:      	mov	x0, #0x1                ; =1
    5dfc:      	mov	x2, #0x19               ; =25
    5e00:      	b	0x5ed0 <_stogir.stack.validate+0x1e0>
    5e04:      	movz	x9, #0x0, lsl #48
    5e08:      	b	0x5e10 <_stogir.stack.validate+0x120>
    5e0c:      	movz	x9, #0x0, lsl #48
    5e10:      	lsl	x10, x1, #4
    5e14:      	lsl	x6, x6, #4
    5e18:      	cmp	x9, #0x0
    5e1c:      	b.eq	0x5e78 <_stogir.stack.validate+0x188>
    5e20:      	uxtb	w16, w3
    5e24:      	cmp	w16, wzr
    5e28:      	b.eq	0x5e4c <_stogir.stack.validate+0x15c>
    5e2c:      	ldr	x9, [x0]
    5e30:      	add	x9, x10, x9
    5e34:      	ldr	x11, [x9]
    5e38:      	ldr	x9, [x9, #0x8]
    5e3c:      	fmov	d31, x9
    5e40:      	mov	x9, x11
    5e44:      	fmov	x11, d31
    5e48:      	b	0x5e68 <_stogir.stack.validate+0x178>
    5e4c:      	ldr	x9, [x0, #0x28]
    5e50:      	add	x9, x6, x9
    5e54:      	ldr	x11, [x9]
    5e58:      	ldr	x9, [x9, #0x8]
    5e5c:      	fmov	d31, x9
    5e60:      	mov	x9, x11
    5e64:      	fmov	x11, d31
    5e68:      	mov	x12, x11
    5e6c:      	mov	x11, x9
    5e70:      	mov	x9, #0x1                ; =1
    5e74:      	b	0x5e84 <_stogir.stack.validate+0x194>
    5e78:      	movz	x9, #0x0, lsl #48
    5e7c:      	movz	x11, #0x0, lsl #48
    5e80:      	movz	x12, #0x0, lsl #48
    5e84:      	lsr	w9, w9, #0
    5e88:      	lsr	x16, x9, #0
    5e8c:      	cmp	x16, #0x1
    5e90:      	b.eq	0x5eac <_stogir.stack.validate+0x1bc>
    5e94:      	b.lo	0x5e9c <_stogir.stack.validate+0x1ac>
    5e98:      	b	0x5eb0 <_stogir.stack.validate+0x1c0>
    5e9c:      	cmp	x16, #0x0
    5ea0:      	b.eq	0x5ea8 <_stogir.stack.validate+0x1b8>
    5ea4:      	b	0x5eb0 <_stogir.stack.validate+0x1c0>
    5ea8:      	b	0x5eb4 <_stogir.stack.validate+0x1c4>
    5eac:      	b	0x5f00 <_stogir.stack.validate+0x210>
    5eb0:      	b	0x62f4 <_stogir.stack.validate+0x604>
    5eb4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005eb4:  ARM64_RELOC_PAGE21	l_stogir.387
    5eb8:      	ldr	x16, [x16]
		0000000000005eb8:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5ebc:      	orr	x0, x16, xzr
    5ec0:      	mov	x22, x8
    5ec4:      	mov	x1, x0
    5ec8:      	mov	x0, #0x1                ; =1
    5ecc:      	mov	x2, #0x19               ; =25
    5ed0:      	str	x0, [x22]
    5ed4:      	str	x1, [x22, #0x8]
    5ed8:      	str	x2, [x22, #0x10]
    5edc:      	ldr	x19, [sp, #0x60]
    5ee0:      	ldr	x20, [sp, #0x68]
    5ee4:      	ldr	x21, [sp, #0x70]
    5ee8:      	ldr	x22, [sp, #0x78]
    5eec:      	ldr	x23, [sp, #0x80]
    5ef0:      	ldr	x29, [sp]
    5ef4:      	ldr	x30, [sp, #0x8]
    5ef8:      	add	sp, sp, #0x90
    5efc:      	ret
    5f00:      	cmp	x1, #0x0
    5f04:      	cset	w9, le
    5f08:      	uxtb	w19, w11
    5f0c:      	add	x16, sp, #0x10
    5f10:      	str	x11, [x16]
    5f14:      	orr	x11, x19, xzr
    5f18:      	add	x16, sp, #0x10
    5f1c:      	str	x12, [x16, #0x8]
    5f20:      	cmp	x11, #0x42
    5f24:      	b.ne	0x5dd8 <_stogir.stack.validate+0xe8>
    5f28:      	uxtb	w16, w3
    5f2c:      	cmp	w16, wzr
    5f30:      	b.eq	0x5fec <_stogir.stack.validate+0x2fc>
    5f34:      	ldr	x4, [x0, #0x8]
    5f38:      	cmp	x1, x4
    5f3c:      	b.ge	0x6038 <_stogir.stack.validate+0x348>
    5f40:      	add	x4, x0, #0x78
    5f44:      	ldr	x4, [x4, #0x8]
    5f48:      	cmp	x1, x4
    5f4c:      	b.ge	0x612c <_stogir.stack.validate+0x43c>
    5f50:      	ldr	x1, [x0, #0x78]
    5f54:      	add	x1, x2, x1
    5f58:      	ldr	w1, [x1]
    5f5c:      	sxtw	x1, w1
    5f60:      	cmp	x1, #0x0
    5f64:      	cset	w1, ge
    5f68:      	ubfx	x1, x1, #0, #8
    5f6c:      	b	0x6130 <_stogir.stack.validate+0x440>
    5f70:      	movz	x9, #0x0, lsl #48
    5f74:      	b	0x5e08 <_stogir.stack.validate+0x118>
    5f78:      	movz	x9, #0x0, lsl #48
    5f7c:      	b	0x5dd4 <_stogir.stack.validate+0xe4>
    5f80:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x410>
		0000000000005f80:  ARM64_RELOC_PAGE21	l_stogir.388
    5f84:      	ldr	x16, [x16]
		0000000000005f84:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    5f88:      	orr	x0, x16, xzr
    5f8c:      	mov	x1, x0
    5f90:      	mov	x0, #0x1                ; =1
    5f94:      	mov	x2, #0x1e               ; =30
    5f98:      	mov	x22, x8
    5f9c:      	b	0x5e00 <_stogir.stack.validate+0x110>
    5fa0:      	cmp	x11, #0x51
    5fa4:      	cset	w1, eq
    5fa8:      	cmp	x11, #0x53
    5fac:      	cset	w20, eq
    5fb0:      	cmp	x11, #0x54
    5fb4:      	cset	w21, eq
    5fb8:      	uxtb	w16, w1
    5fbc:      	cmp	w16, wzr
    5fc0:      	b.ne	0x6134 <_stogir.stack.validate+0x444>
    5fc4:      	cmp	x11, #0x52
    5fc8:      	b.eq	0x6134 <_stogir.stack.validate+0x444>
    5fcc:      	uxtb	w16, w20
    5fd0:      	cmp	w16, wzr
    5fd4:      	b.ne	0x6134 <_stogir.stack.validate+0x444>
    5fd8:      	uxtb	w16, w21
    5fdc:      	cmp	w16, wzr
    5fe0:      	b.ne	0x6134 <_stogir.stack.validate+0x444>
    5fe4:      	mov	x22, x8
    5fe8:      	b	0x5de8 <_stogir.stack.validate+0xf8>
    5fec:      	uxtb	w16, w5
    5ff0:      	cmp	w16, wzr
    5ff4:      	b.eq	0x6040 <_stogir.stack.validate+0x350>
    5ff8:      	add	x1, x0, #0x28
    5ffc:      	add	x5, x0, #0x50
    6000:      	ldr	x1, [x1, #0x8]
    6004:      	ldr	x5, [x5, #0x8]
    6008:      	cmp	x1, x5
    600c:      	b.ne	0x6124 <_stogir.stack.validate+0x434>
    6010:      	cmp	x4, x1
    6014:      	b.gt	0x6290 <_stogir.stack.validate+0x5a0>
    6018:      	ldr	x1, [x0, #0x50]
    601c:      	add	x1, x7, x1
    6020:      	ldr	w1, [x1]
    6024:      	sxtw	x1, w1
    6028:      	cmp	x1, #0x0
    602c:      	cset	w1, gt
    6030:      	ubfx	x1, x1, #0, #8
    6034:      	b	0x6294 <_stogir.stack.validate+0x5a4>
    6038:      	movz	x1, #0x0, lsl #48
    603c:      	b	0x6044 <_stogir.stack.validate+0x354>
    6040:      	movz	x1, #0x0, lsl #48
    6044:      	cmp	x1, #0x0
    6048:      	b.eq	0x6080 <_stogir.stack.validate+0x390>
    604c:      	uxtb	w16, w3
    6050:      	cmp	w16, wzr
    6054:      	b.eq	0x6068 <_stogir.stack.validate+0x378>
    6058:      	ldr	x1, [x0]
    605c:      	add	x1, x10, x1
    6060:      	ldr	x1, [x1]
    6064:      	b	0x6074 <_stogir.stack.validate+0x384>
    6068:      	ldr	x1, [x0, #0x28]
    606c:      	add	x1, x6, x1
    6070:      	ldr	x1, [x1]
    6074:      	mov	x3, x1
    6078:      	mov	x1, #0x1                ; =1
    607c:      	b	0x6088 <_stogir.stack.validate+0x398>
    6080:      	movz	x1, #0x0, lsl #48
    6084:      	movz	x3, #0x0, lsl #48
    6088:      	lsr	w1, w1, #0
    608c:      	lsr	x16, x1, #0
    6090:      	cmp	x16, #0x1
    6094:      	b.eq	0x60b0 <_stogir.stack.validate+0x3c0>
    6098:      	b.lo	0x60a0 <_stogir.stack.validate+0x3b0>
    609c:      	b	0x60b4 <_stogir.stack.validate+0x3c4>
    60a0:      	cmp	x16, #0x0
    60a4:      	b.eq	0x60ac <_stogir.stack.validate+0x3bc>
    60a8:      	b	0x60b4 <_stogir.stack.validate+0x3c4>
    60ac:      	b	0x60b8 <_stogir.stack.validate+0x3c8>
    60b0:      	b	0x60d4 <_stogir.stack.validate+0x3e4>
    60b4:      	b	0x62fc <_stogir.stack.validate+0x60c>
    60b8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		00000000000060b8:  ARM64_RELOC_PAGE21	l_stogir.389
    60bc:      	ldr	x16, [x16]
		00000000000060bc:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    60c0:      	orr	x0, x16, xzr
    60c4:      	mov	x1, x0
    60c8:      	mov	x0, #0x1                ; =1
    60cc:      	mov	x2, #0x21               ; =33
    60d0:      	b	0x5f98 <_stogir.stack.validate+0x2a8>
    60d4:      	uxtb	w16, w9
    60d8:      	cmp	w16, wzr
    60dc:      	b.ne	0x5f80 <_stogir.stack.validate+0x290>
    60e0:      	uxtb	w1, w3
    60e4:      	cmp	x1, #0x42
    60e8:      	b.ne	0x5f80 <_stogir.stack.validate+0x290>
    60ec:      	lsr	w3, w3, #0
    60f0:      	ubfx	x1, x3, #8, #8
    60f4:      	cmp	x1, #0x6
    60f8:      	b.ne	0x5f80 <_stogir.stack.validate+0x290>
    60fc:      	ldr	x0, [x0, #0x78]
    6100:      	add	x0, x2, x0
    6104:      	ldr	w0, [x0]
    6108:      	sxtw	x0, w0
    610c:      	cmp	x0, #0x0
    6110:      	b.ne	0x5f80 <_stogir.stack.validate+0x290>
    6114:      	movz	x0, #0x0, lsl #48
    6118:      	mov	x1, #0x8                ; =8
    611c:      	movz	x2, #0x0, lsl #48
    6120:      	b	0x5f98 <_stogir.stack.validate+0x2a8>
    6124:      	movz	x1, #0x0, lsl #48
    6128:      	b	0x6044 <_stogir.stack.validate+0x354>
    612c:      	movz	x1, #0x0, lsl #48
    6130:      	b	0x603c <_stogir.stack.validate+0x34c>
    6134:      	ldr	x3, [x0, #0x78]
    6138:      	add	x2, x2, x3
    613c:      	ldr	w2, [x2]
    6140:      	uxtb	w16, w1
    6144:      	cmp	w16, wzr
    6148:      	b.eq	0x61b4 <_stogir.stack.validate+0x4c4>
    614c:      	mov	x1, #0x3                ; =3
    6150:      	b	0x61c8 <_stogir.stack.validate+0x4d8>
    6154:      	add	x16, sp, #0x10
    6158:      	ldr	w0, [x16]
    615c:      	add	x16, sp, #0x10
    6160:      	ldr	w1, [x16, #0x4]
    6164:      	add	x16, sp, #0x10
    6168:      	ldr	w2, [x16, #0x8]
    616c:      	lsr	w1, w1, #0
    6170:      	ubfx	x0, x0, #8, #8
    6174:      	lsr	w2, w2, #0
    6178:      	lsr	w0, w0, #0
    617c:      	add	x8, sp, #0x20
    6180:      	mov	w3, w1
    6184:      	mov	w1, w19
    6188:      	mov	w4, w2
    618c:      	mov	w2, w0
    6190:      	mov	x0, x23
    6194:      	bl	0x6194 <_stogir.stack.validate+0x4a4>
		0000000000006194:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    6198:      	add	x16, sp, #0x20
    619c:      	ldr	x0, [x16]
    61a0:      	add	x16, sp, #0x20
    61a4:      	ldr	x1, [x16, #0x8]
    61a8:      	add	x16, sp, #0x20
    61ac:      	ldr	x2, [x16, #0x10]
    61b0:      	b	0x5e00 <_stogir.stack.validate+0x110>
    61b4:      	uxtb	w16, w20
    61b8:      	cmp	w16, wzr
    61bc:      	mov	x16, #0x1               ; =1
    61c0:      	mov	x17, #0x2               ; =2
    61c4:      	csel	x1, x16, x17, ne
    61c8:      	sxtw	x2, w2
    61cc:      	lsr	w1, w1, #0
    61d0:      	sxtw	x1, w1
    61d4:      	cmp	x2, x1
    61d8:      	b.ne	0x6304 <_stogir.stack.validate+0x614>
    61dc:      	add	x16, sp, #0x10
    61e0:      	ldr	w1, [x16]
    61e4:      	orr	x2, x1, xzr
    61e8:      	ubfx	x2, x2, #16, #16
    61ec:      	and	x3, x2, #0x8000
    61f0:      	uxth	w3, w3
    61f4:      	cmp	x3, #0x0
    61f8:      	b.ne	0x6298 <_stogir.stack.validate+0x5a8>
    61fc:      	mov	x22, x8
    6200:      	mov	x23, x0
    6204:      	lsr	w19, w19, #0
    6208:      	uxtb	w16, w20
    620c:      	cmp	w16, wzr
    6210:      	b.ne	0x6154 <_stogir.stack.validate+0x464>
    6214:      	uxtb	w16, w21
    6218:      	cmp	w16, wzr
    621c:      	b.ne	0x6154 <_stogir.stack.validate+0x464>
    6220:      	add	x16, sp, #0x10
    6224:      	ldr	w0, [x16]
    6228:      	add	x16, sp, #0x10
    622c:      	ldr	w1, [x16, #0x4]
    6230:      	add	x16, sp, #0x10
    6234:      	ldr	w2, [x16, #0x8]
    6238:      	lsr	w1, w1, #0
    623c:      	ubfx	x0, x0, #8, #8
    6240:      	add	x16, sp, #0x10
    6244:      	ldr	w3, [x16, #0xc]
    6248:      	lsr	w2, w2, #0
    624c:      	lsr	w3, w3, #0
    6250:      	lsr	w0, w0, #0
    6254:      	add	x8, sp, #0x40
    6258:      	mov	w4, w2
    625c:      	mov	w2, w0
    6260:      	mov	x0, x23
    6264:      	mov	w5, w3
    6268:      	mov	w3, w1
    626c:      	mov	w1, w19
    6270:      	bl	0x6270 <_stogir.stack.validate+0x580>
		0000000000006270:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    6274:      	add	x16, sp, #0x40
    6278:      	ldr	x0, [x16]
    627c:      	add	x16, sp, #0x40
    6280:      	ldr	x1, [x16, #0x8]
    6284:      	add	x16, sp, #0x40
    6288:      	ldr	x2, [x16, #0x10]
    628c:      	b	0x61b0 <_stogir.stack.validate+0x4c0>
    6290:      	movz	x1, #0x0, lsl #48
    6294:      	b	0x6128 <_stogir.stack.validate+0x438>
    6298:      	uxtb	w1, w1
    629c:      	cmp	x1, #0x51
    62a0:      	b.ne	0x630c <_stogir.stack.validate+0x61c>
    62a4:      	cmp	x2, #0x8, lsl #12       ; =0x8000
    62a8:      	b.ne	0x6314 <_stogir.stack.validate+0x624>
    62ac:      	add	x16, sp, #0x10
    62b0:      	ldr	w1, [x16, #0x4]
    62b4:      	add	x16, sp, #0x10
    62b8:      	ldr	w2, [x16, #0x8]
    62bc:      	lsr	w1, w1, #0
    62c0:      	lsr	w2, w2, #0
    62c4:      	mov	x22, x8
    62c8:      	mov	x23, x0
    62cc:      	bl	0x62cc <_stogir.stack.validate+0x5dc>
		00000000000062cc:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    62d0:      	cmp	x0, #0x0
    62d4:      	b.ne	0x6204 <_stogir.stack.validate+0x514>
    62d8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		00000000000062d8:  ARM64_RELOC_PAGE21	l_stogir.390
    62dc:      	ldr	x16, [x16]
		00000000000062dc:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    62e0:      	orr	x0, x16, xzr
    62e4:      	mov	x1, x0
    62e8:      	mov	x0, #0x1                ; =1
    62ec:      	mov	x2, #0x26               ; =38
    62f0:      	b	0x61b0 <_stogir.stack.validate+0x4c0>
    62f4:      	brk	#0
    62f8:      	b	0x62f4 <_stogir.stack.validate+0x604>
    62fc:      	brk	#0
    6300:      	b	0x62fc <_stogir.stack.validate+0x60c>
    6304:      	mov	x22, x8
    6308:      	b	0x5de8 <_stogir.stack.validate+0xf8>
    630c:      	mov	x22, x8
    6310:      	b	0x62d8 <_stogir.stack.validate+0x5e8>
    6314:      	mov	x22, x8
    6318:      	b	0x62d8 <_stogir.stack.validate+0x5e8>

000000000000631c <_stogir.locals.operation?>:
    631c:      	sxtw	x0, w0
    6320:      	cmp	x0, #0x41
    6324:      	b.ne	0x6338 <_stogir.locals.operation?+0x1c>
    6328:      	mov	x0, #0x1                ; =1
    632c:      	b	0x6334 <_stogir.locals.operation?+0x18>
    6330:      	movz	x0, #0x0, lsl #48
    6334:      	ret
    6338:      	cmp	x0, #0x48
    633c:      	b.ne	0x6348 <_stogir.locals.operation?+0x2c>
    6340:      	mov	x0, #0x1                ; =1
    6344:      	b	0x6334 <_stogir.locals.operation?+0x18>
    6348:      	cmp	x0, #0x55
    634c:      	b.lt	0x6330 <_stogir.locals.operation?+0x14>
    6350:      	cmp	x0, #0x58
    6354:      	cset	w0, le
    6358:      	ubfx	x0, x0, #0, #8
    635c:      	b	0x6334 <_stogir.locals.operation?+0x18>

0000000000006360 <_stogir.locals.validate>:
    6360:      	sub	sp, sp, #0xb0
    6364:      	str	x29, [sp]
    6368:      	str	x30, [sp, #0x8]
    636c:      	mov	x29, sp
    6370:      	str	x19, [sp, #0x70]
    6374:      	str	x20, [sp, #0x78]
    6378:      	str	x21, [sp, #0x80]
    637c:      	str	x22, [sp, #0x88]
    6380:      	str	x23, [sp, #0x90]
    6384:      	str	x24, [sp, #0x98]
    6388:      	str	x25, [sp, #0xa0]
    638c:      	sxtw	x1, w1
    6390:      	lsl	x3, x1, #2
    6394:      	cmp	x1, #0x0
    6398:      	cset	w4, gt
    639c:      	movz	x16, #0x0, lsl #48
    63a0:      	sub	x5, x16, x1
    63a4:      	sub	x6, x5, #0x1
    63a8:      	uxtb	w16, w4
    63ac:      	cmp	w16, wzr
    63b0:      	b.eq	0x63f0 <_stogir.locals.validate+0x90>
    63b4:      	ldr	x5, [x0, #0x8]
    63b8:      	cmp	x1, x5
    63bc:      	b.ge	0x6490 <_stogir.locals.validate+0x130>
    63c0:      	add	x5, x0, #0x78
    63c4:      	ldr	x5, [x5, #0x8]
    63c8:      	cmp	x1, x5
    63cc:      	b.ge	0x65b8 <_stogir.locals.validate+0x258>
    63d0:      	ldr	x5, [x0, #0x78]
    63d4:      	add	x5, x3, x5
    63d8:      	ldr	w5, [x5]
    63dc:      	sxtw	x5, w5
    63e0:      	cmp	x5, #0x0
    63e4:      	cset	w5, ge
    63e8:      	ubfx	x5, x5, #0, #8
    63ec:      	b	0x65bc <_stogir.locals.validate+0x25c>
    63f0:      	cmp	x1, #0x0
    63f4:      	b.ge	0x6498 <_stogir.locals.validate+0x138>
    63f8:      	add	x7, x0, #0x28
    63fc:      	add	x9, x0, #0x50
    6400:      	ldr	x7, [x7, #0x8]
    6404:      	ldr	x9, [x9, #0x8]
    6408:      	cmp	x7, x9
    640c:      	b.ne	0x643c <_stogir.locals.validate+0xdc>
    6410:      	cmp	x5, x7
    6414:      	b.gt	0x6640 <_stogir.locals.validate+0x2e0>
    6418:      	lsl	x5, x6, #2
    641c:      	ldr	x7, [x0, #0x50]
    6420:      	add	x5, x5, x7
    6424:      	ldr	w5, [x5]
    6428:      	sxtw	x5, w5
    642c:      	cmp	x5, #0x0
    6430:      	cset	w5, gt
    6434:      	ubfx	x5, x5, #0, #8
    6438:      	b	0x6644 <_stogir.locals.validate+0x2e4>
    643c:      	movz	x5, #0x0, lsl #48
    6440:      	b	0x649c <_stogir.locals.validate+0x13c>
    6444:      	cmp	x5, #0x0
    6448:      	cset	w5, ne
    644c:      	uxtb	w16, w5
    6450:      	cmp	w16, wzr
    6454:      	mov	x16, #0x2               ; =2
    6458:      	mov	x17, #0x3               ; =3
    645c:      	csel	x5, x16, x17, ne
    6460:      	lsr	w5, w5, #0
    6464:      	sxtw	x5, w5
    6468:      	cmp	x1, #0x0
    646c:      	b.gt	0x65c0 <_stogir.locals.validate+0x260>
    6470:      	mov	x23, x8
    6474:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006474:  ARM64_RELOC_PAGE21	l_stogir.391
    6478:      	ldr	x16, [x16]
		0000000000006478:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    647c:      	orr	x0, x16, xzr
    6480:      	mov	x1, x0
    6484:      	mov	x0, #0x1                ; =1
    6488:      	mov	x2, #0x17               ; =23
    648c:      	b	0x655c <_stogir.locals.validate+0x1fc>
    6490:      	movz	x5, #0x0, lsl #48
    6494:      	b	0x649c <_stogir.locals.validate+0x13c>
    6498:      	movz	x5, #0x0, lsl #48
    649c:      	cmp	x5, #0x0
    64a0:      	b.eq	0x6504 <_stogir.locals.validate+0x1a4>
    64a4:      	uxtb	w16, w4
    64a8:      	cmp	w16, wzr
    64ac:      	b.eq	0x64d4 <_stogir.locals.validate+0x174>
    64b0:      	lsl	x4, x1, #4
    64b4:      	ldr	x5, [x0]
    64b8:      	add	x4, x4, x5
    64bc:      	ldr	x5, [x4]
    64c0:      	ldr	x4, [x4, #0x8]
    64c4:      	fmov	d31, x4
    64c8:      	mov	x4, x5
    64cc:      	fmov	x5, d31
    64d0:      	b	0x64f4 <_stogir.locals.validate+0x194>
    64d4:      	lsl	x4, x6, #4
    64d8:      	ldr	x5, [x0, #0x28]
    64dc:      	add	x4, x4, x5
    64e0:      	ldr	x5, [x4]
    64e4:      	ldr	x4, [x4, #0x8]
    64e8:      	fmov	d31, x4
    64ec:      	mov	x4, x5
    64f0:      	fmov	x5, d31
    64f4:      	mov	x6, x5
    64f8:      	mov	x5, x4
    64fc:      	mov	x4, #0x1                ; =1
    6500:      	b	0x6510 <_stogir.locals.validate+0x1b0>
    6504:      	movz	x4, #0x0, lsl #48
    6508:      	movz	x5, #0x0, lsl #48
    650c:      	movz	x6, #0x0, lsl #48
    6510:      	lsr	w4, w4, #0
    6514:      	lsr	x16, x4, #0
    6518:      	cmp	x16, #0x1
    651c:      	b.eq	0x6538 <_stogir.locals.validate+0x1d8>
    6520:      	b.lo	0x6528 <_stogir.locals.validate+0x1c8>
    6524:      	b	0x653c <_stogir.locals.validate+0x1dc>
    6528:      	cmp	x16, #0x0
    652c:      	b.eq	0x6534 <_stogir.locals.validate+0x1d4>
    6530:      	b	0x653c <_stogir.locals.validate+0x1dc>
    6534:      	b	0x6540 <_stogir.locals.validate+0x1e0>
    6538:      	b	0x6594 <_stogir.locals.validate+0x234>
    653c:      	b	0x6784 <_stogir.locals.validate+0x424>
    6540:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006540:  ARM64_RELOC_PAGE21	l_stogir.392
    6544:      	ldr	x16, [x16]
		0000000000006544:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    6548:      	orr	x0, x16, xzr
    654c:      	mov	x23, x8
    6550:      	mov	x1, x0
    6554:      	mov	x0, #0x1                ; =1
    6558:      	mov	x2, #0x17               ; =23
    655c:      	str	x0, [x23]
    6560:      	str	x1, [x23, #0x8]
    6564:      	str	x2, [x23, #0x10]
    6568:      	ldr	x19, [sp, #0x70]
    656c:      	ldr	x20, [sp, #0x78]
    6570:      	ldr	x21, [sp, #0x80]
    6574:      	ldr	x22, [sp, #0x88]
    6578:      	ldr	x23, [sp, #0x90]
    657c:      	ldr	x24, [sp, #0x98]
    6580:      	ldr	x25, [sp, #0xa0]
    6584:      	ldr	x29, [sp]
    6588:      	ldr	x30, [sp, #0x8]
    658c:      	add	sp, sp, #0xb0
    6590:      	ret
    6594:      	uxtb	w4, w5
    6598:      	add	x16, sp, #0x10
    659c:      	str	x5, [x16]
    65a0:      	add	x16, sp, #0x10
    65a4:      	str	x6, [x16, #0x8]
    65a8:      	cmp	x4, #0x55
    65ac:      	b.ne	0x6624 <_stogir.locals.validate+0x2c4>
    65b0:      	mov	x5, #0x1                ; =1
    65b4:      	b	0x6630 <_stogir.locals.validate+0x2d0>
    65b8:      	movz	x5, #0x0, lsl #48
    65bc:      	b	0x6494 <_stogir.locals.validate+0x134>
    65c0:      	cmp	x4, #0x48
    65c4:      	cset	w21, eq
    65c8:      	uxtb	w16, w20
    65cc:      	cmp	w16, wzr
    65d0:      	b.ne	0x6648 <_stogir.locals.validate+0x2e8>
    65d4:      	uxtb	w16, w21
    65d8:      	cmp	w16, wzr
    65dc:      	b.ne	0x6648 <_stogir.locals.validate+0x2e8>
    65e0:      	cmp	x4, #0x55
    65e4:      	b.lt	0x6af8 <_stogir.locals.validate+0x798>
    65e8:      	cmp	x4, #0x58
    65ec:      	b.le	0x6648 <_stogir.locals.validate+0x2e8>
    65f0:      	mov	x23, x8
    65f4:      	b	0x6474 <_stogir.locals.validate+0x114>
    65f8:      	cmp	x4, #0x58
    65fc:      	cset	w6, eq
    6600:      	ubfx	x6, x6, #0, #8
    6604:      	mov	x19, x6
    6608:      	cmp	x4, #0x41
    660c:      	cset	w20, eq
    6610:      	uxtb	w16, w20
    6614:      	cmp	w16, wzr
    6618:      	b.eq	0x6444 <_stogir.locals.validate+0xe4>
    661c:      	mov	x5, #0x1                ; =1
    6620:      	b	0x6468 <_stogir.locals.validate+0x108>
    6624:      	cmp	x4, #0x56
    6628:      	cset	w5, eq
    662c:      	ubfx	x5, x5, #0, #8
    6630:      	cmp	x4, #0x57
    6634:      	b.ne	0x65f8 <_stogir.locals.validate+0x298>
    6638:      	mov	x19, #0x1               ; =1
    663c:      	b	0x6608 <_stogir.locals.validate+0x2a8>
    6640:      	movz	x5, #0x0, lsl #48
    6644:      	b	0x6440 <_stogir.locals.validate+0xe0>
    6648:      	lsr	w5, w5, #0
    664c:      	sxtw	x5, w5
    6650:      	ldr	x4, [x0, #0x78]
    6654:      	add	x3, x3, x4
    6658:      	ldr	w3, [x3]
    665c:      	sxtw	x3, w3
    6660:      	cmp	x3, x5
    6664:      	b.ne	0x6b00 <_stogir.locals.validate+0x7a0>
    6668:      	uxtb	w16, w20
    666c:      	cmp	w16, wzr
    6670:      	b.ne	0x6690 <_stogir.locals.validate+0x330>
    6674:      	uxtb	w16, w21
    6678:      	cmp	w16, wzr
    667c:      	b.ne	0x6690 <_stogir.locals.validate+0x330>
    6680:      	add	x16, sp, #0x10
    6684:      	ldr	w1, [x16, #0x8]
    6688:      	sxtw	x1, w1
    668c:      	b	0x66a8 <_stogir.locals.validate+0x348>
    6690:      	uxtb	w16, w21
    6694:      	cmp	w16, wzr
    6698:      	b.ne	0x66a8 <_stogir.locals.validate+0x348>
    669c:      	add	x16, sp, #0x10
    66a0:      	ldr	w1, [x16, #0x4]
    66a4:      	sxtw	x1, w1
    66a8:      	add	x16, sp, #0x20
    66ac:      	orr	x22, x16, xzr
    66b0:      	lsr	w2, w2, #0
    66b4:      	lsr	w1, w1, #0
    66b8:      	mov	x23, x8
    66bc:      	add	x8, sp, #0x20
    66c0:      	mov	x24, x0
    66c4:      	mov	w25, w2
    66c8:      	bl	0x66c8 <_stogir.locals.validate+0x368>
		00000000000066c8:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    66cc:      	add	x16, sp, #0x20
    66d0:      	ldr	w0, [x16]
    66d4:      	lsr	x16, x0, #0
    66d8:      	cmp	x16, #0x1
    66dc:      	b.eq	0x66f8 <_stogir.locals.validate+0x398>
    66e0:      	b.lo	0x66e8 <_stogir.locals.validate+0x388>
    66e4:      	b	0x66fc <_stogir.locals.validate+0x39c>
    66e8:      	cmp	x16, #0x0
    66ec:      	b.eq	0x66f4 <_stogir.locals.validate+0x394>
    66f0:      	b	0x66fc <_stogir.locals.validate+0x39c>
    66f4:      	b	0x671c <_stogir.locals.validate+0x3bc>
    66f8:      	b	0x6700 <_stogir.locals.validate+0x3a0>
    66fc:      	b	0x697c <_stogir.locals.validate+0x61c>
    6700:      	add	x0, x22, #0x8
    6704:      	add	x16, sp, #0x20
    6708:      	ldr	x1, [x16, #0x8]
    670c:      	ldr	x0, [x0, #0x8]
    6710:      	mov	x2, x0
    6714:      	mov	x0, #0x1                ; =1
    6718:      	b	0x648c <_stogir.locals.validate+0x12c>
    671c:      	add	x16, sp, #0x20
    6720:      	ldr	x22, [x16, #0x8]
    6724:      	uxtb	w16, w21
    6728:      	cmp	w16, wzr
    672c:      	b.eq	0x674c <_stogir.locals.validate+0x3ec>
    6730:      	lsr	w22, w22, #0
    6734:      	sxtw	x22, w22
    6738:      	and	x0, x22, #0xffffffff
    673c:      	mov	x1, x0
    6740:      	movz	x0, #0x0, lsl #48
    6744:      	movz	x2, #0x0, lsl #48
    6748:      	b	0x6718 <_stogir.locals.validate+0x3b8>
    674c:      	uxtb	w16, w20
    6750:      	cmp	w16, wzr
    6754:      	b.eq	0x67a8 <_stogir.locals.validate+0x448>
    6758:      	add	x16, sp, #0x10
    675c:      	ldr	w0, [x16]
    6760:      	ubfx	x0, x0, #8, #8
    6764:      	cmp	x0, #0x6
    6768:      	b.ne	0x678c <_stogir.locals.validate+0x42c>
    676c:      	sxtw	x25, w25
    6770:      	and	x0, x25, #0xffffffff
    6774:      	mov	x1, x0
    6778:      	movz	x0, #0x0, lsl #48
    677c:      	movz	x2, #0x0, lsl #48
    6780:      	b	0x67a4 <_stogir.locals.validate+0x444>
    6784:      	brk	#0
    6788:      	b	0x6784 <_stogir.locals.validate+0x424>
    678c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		000000000000678c:  ARM64_RELOC_PAGE21	l_stogir.393
    6790:      	ldr	x16, [x16]
		0000000000006790:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    6794:      	orr	x0, x16, xzr
    6798:      	mov	x1, x0
    679c:      	mov	x0, #0x1                ; =1
    67a0:      	mov	x2, #0x21               ; =33
    67a4:      	b	0x6748 <_stogir.locals.validate+0x3e8>
    67a8:      	add	x16, sp, #0x10
    67ac:      	ldr	w0, [x16, #0x4]
    67b0:      	sxtw	x0, w0
    67b4:      	cmp	x0, #0x0
    67b8:      	cset	w1, gt
    67bc:      	movz	x16, #0x0, lsl #48
    67c0:      	sub	x2, x16, x0
    67c4:      	sub	x3, x2, #0x1
    67c8:      	uxtb	w16, w1
    67cc:      	cmp	w16, wzr
    67d0:      	b.eq	0x68b8 <_stogir.locals.validate+0x558>
    67d4:      	ldr	x2, [x24, #0x8]
    67d8:      	cmp	x0, x2
    67dc:      	b.ge	0x68b0 <_stogir.locals.validate+0x550>
    67e0:      	add	x2, x24, #0x78
    67e4:      	ldr	x2, [x2, #0x8]
    67e8:      	cmp	x0, x2
    67ec:      	b.ge	0x696c <_stogir.locals.validate+0x60c>
    67f0:      	lsl	x2, x0, #2
    67f4:      	ldr	x4, [x24, #0x78]
    67f8:      	add	x2, x2, x4
    67fc:      	ldr	w2, [x2]
    6800:      	sxtw	x2, w2
    6804:      	cmp	x2, #0x0
    6808:      	cset	w2, ge
    680c:      	ubfx	x2, x2, #0, #8
    6810:      	b	0x6970 <_stogir.locals.validate+0x610>
    6814:      	movz	x0, #0x0, lsl #48
    6818:      	movz	x1, #0x0, lsl #48
    681c:      	lsr	w0, w0, #0
    6820:      	lsr	x16, x0, #0
    6824:      	cmp	x16, #0x1
    6828:      	b.eq	0x6844 <_stogir.locals.validate+0x4e4>
    682c:      	b.lo	0x6834 <_stogir.locals.validate+0x4d4>
    6830:      	b	0x6848 <_stogir.locals.validate+0x4e8>
    6834:      	cmp	x16, #0x0
    6838:      	b.eq	0x6840 <_stogir.locals.validate+0x4e0>
    683c:      	b	0x6848 <_stogir.locals.validate+0x4e8>
    6840:      	b	0x684c <_stogir.locals.validate+0x4ec>
    6844:      	b	0x6904 <_stogir.locals.validate+0x5a4>
    6848:      	b	0x6ac8 <_stogir.locals.validate+0x768>
    684c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		000000000000684c:  ARM64_RELOC_PAGE21	l_stogir.394
    6850:      	ldr	x16, [x16]
		0000000000006850:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    6854:      	orr	x0, x16, xzr
    6858:      	mov	x1, x0
    685c:      	mov	x0, #0x1                ; =1
    6860:      	mov	x2, #0x1c               ; =28
    6864:      	b	0x67a4 <_stogir.locals.validate+0x444>
    6868:      	lsl	x0, x3, #4
    686c:      	ldr	x1, [x24, #0x28]
    6870:      	add	x0, x0, x1
    6874:      	ldr	x0, [x0]
    6878:      	mov	x1, x0
    687c:      	mov	x0, #0x1                ; =1
    6880:      	b	0x681c <_stogir.locals.validate+0x4bc>
    6884:      	movz	x2, #0x0, lsl #48
    6888:      	cmp	x2, #0x0
    688c:      	b.eq	0x6814 <_stogir.locals.validate+0x4b4>
    6890:      	uxtb	w16, w1
    6894:      	cmp	w16, wzr
    6898:      	b.eq	0x6868 <_stogir.locals.validate+0x508>
    689c:      	lsl	x0, x0, #4
    68a0:      	ldr	x1, [x24]
    68a4:      	add	x0, x0, x1
    68a8:      	ldr	x0, [x0]
    68ac:      	b	0x6878 <_stogir.locals.validate+0x518>
    68b0:      	movz	x2, #0x0, lsl #48
    68b4:      	b	0x6888 <_stogir.locals.validate+0x528>
    68b8:      	cmp	x0, #0x0
    68bc:      	b.ge	0x6884 <_stogir.locals.validate+0x524>
    68c0:      	add	x4, x24, #0x28
    68c4:      	add	x5, x24, #0x50
    68c8:      	ldr	x4, [x4, #0x8]
    68cc:      	ldr	x5, [x5, #0x8]
    68d0:      	cmp	x4, x5
    68d4:      	b.ne	0x6964 <_stogir.locals.validate+0x604>
    68d8:      	cmp	x2, x4
    68dc:      	b.gt	0x6974 <_stogir.locals.validate+0x614>
    68e0:      	lsl	x2, x3, #2
    68e4:      	ldr	x4, [x24, #0x50]
    68e8:      	add	x2, x2, x4
    68ec:      	ldr	w2, [x2]
    68f0:      	sxtw	x2, w2
    68f4:      	cmp	x2, #0x0
    68f8:      	cset	w2, gt
    68fc:      	ubfx	x2, x2, #0, #8
    6900:      	b	0x6978 <_stogir.locals.validate+0x618>
    6904:      	add	x16, sp, #0x10
    6908:      	ldr	w0, [x16, #0x4]
    690c:      	sxtw	x0, w0
    6910:      	cmp	x0, #0x0
    6914:      	b.le	0x6948 <_stogir.locals.validate+0x5e8>
    6918:      	uxtb	w1, w1
    691c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		000000000000691c:  ARM64_RELOC_PAGE21	l_stogir.395
    6920:      	ldr	x16, [x16]
		0000000000006920:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6924:      	orr	x0, x16, xzr
    6928:      	cmp	x1, #0x83
    692c:      	cset	w2, lt
    6930:      	add	x0, x1, x0
    6934:      	uxtb	w16, w2
    6938:      	cmp	w16, wzr
    693c:      	b.eq	0x6984 <_stogir.locals.validate+0x624>
    6940:      	ldrb	w1, [x0]
    6944:      	b	0x6988 <_stogir.locals.validate+0x628>
    6948:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006948:  ARM64_RELOC_PAGE21	l_stogir.396
    694c:      	ldr	x16, [x16]
		000000000000694c:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6950:      	orr	x0, x16, xzr
    6954:      	mov	x1, x0
    6958:      	mov	x0, #0x1                ; =1
    695c:      	mov	x2, #0x1c               ; =28
    6960:      	b	0x6864 <_stogir.locals.validate+0x504>
    6964:      	movz	x2, #0x0, lsl #48
    6968:      	b	0x6888 <_stogir.locals.validate+0x528>
    696c:      	movz	x2, #0x0, lsl #48
    6970:      	b	0x68b4 <_stogir.locals.validate+0x554>
    6974:      	movz	x2, #0x0, lsl #48
    6978:      	b	0x6968 <_stogir.locals.validate+0x608>
    697c:      	brk	#0
    6980:      	b	0x697c <_stogir.locals.validate+0x61c>
    6984:      	movz	x1, #0x0, lsl #48
    6988:      	uxtb	w1, w1
    698c:      	and	x1, x1, #0x1
    6990:      	uxtb	w1, w1
    6994:      	cmp	x1, #0x0
    6998:      	b.eq	0x6948 <_stogir.locals.validate+0x5e8>
    699c:      	uxtb	w16, w2
    69a0:      	cmp	w16, wzr
    69a4:      	b.eq	0x69b0 <_stogir.locals.validate+0x650>
    69a8:      	ldrb	w0, [x0]
    69ac:      	b	0x69b4 <_stogir.locals.validate+0x654>
    69b0:      	movz	x0, #0x0, lsl #48
    69b4:      	uxtb	w0, w0
    69b8:      	and	x0, x0, #0x4
    69bc:      	uxtb	w0, w0
    69c0:      	cmp	x0, #0x0
    69c4:      	b.ne	0x6948 <_stogir.locals.validate+0x5e8>
    69c8:      	cmp	x19, #0x0
    69cc:      	b.eq	0x6a6c <_stogir.locals.validate+0x70c>
    69d0:      	add	x16, sp, #0x10
    69d4:      	ldr	w0, [x16, #0xc]
    69d8:      	lsr	w0, w0, #0
    69dc:      	add	x8, sp, #0x40
    69e0:      	mov	w1, w0
    69e4:      	mov	x0, x24
    69e8:      	bl	0x69e8 <_stogir.locals.validate+0x688>
		00000000000069e8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    69ec:      	add	x16, sp, #0x40
    69f0:      	ldr	x0, [x16]
    69f4:      	add	x16, sp, #0x40
    69f8:      	ldr	x1, [x16, #0x8]
    69fc:      	mov	x20, x1
    6a00:      	b	0x6a7c <_stogir.locals.validate+0x71c>
    6a04:      	lsr	w25, w25, #0
    6a08:      	lsr	w0, w20, #0
    6a0c:      	ubfx	x0, x0, #8, #8
    6a10:      	lsr	w0, w0, #0
    6a14:      	mov	w1, w25
    6a18:      	bl	0x6a18 <_stogir.locals.validate+0x6b8>
		0000000000006a18:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6a1c:      	lsr	w0, w0, #0
    6a20:      	sxtw	x0, w0
    6a24:      	cmp	x0, #0x0
    6a28:      	b.le	0x6a50 <_stogir.locals.validate+0x6f0>
    6a2c:      	cmp	x0, x22
    6a30:      	b.gt	0x6a50 <_stogir.locals.validate+0x6f0>
    6a34:      	cmp	x19, #0x0
    6a38:      	b.eq	0x6ad0 <_stogir.locals.validate+0x770>
    6a3c:      	add	x16, sp, #0x10
    6a40:      	ldr	w1, [x16]
    6a44:      	ubfx	x1, x1, #8, #8
    6a48:      	cmp	x1, #0x0
    6a4c:      	b.eq	0x6ad0 <_stogir.locals.validate+0x770>
    6a50:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006a50:  ARM64_RELOC_PAGE21	l_stogir.397
    6a54:      	ldr	x16, [x16]
		0000000000006a54:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    6a58:      	orr	x0, x16, xzr
    6a5c:      	mov	x1, x0
    6a60:      	mov	x0, #0x1                ; =1
    6a64:      	mov	x2, #0x23               ; =35
    6a68:      	b	0x6960 <_stogir.locals.validate+0x600>
    6a6c:      	add	x16, sp, #0x10
    6a70:      	ldr	x0, [x16]
    6a74:      	mov	x20, x0
    6a78:      	mov	x0, #0x1                ; =1
    6a7c:      	lsr	w0, w0, #0
    6a80:      	lsr	x16, x0, #0
    6a84:      	cmp	x16, #0x1
    6a88:      	b.eq	0x6aa4 <_stogir.locals.validate+0x744>
    6a8c:      	b.lo	0x6a94 <_stogir.locals.validate+0x734>
    6a90:      	b	0x6aa8 <_stogir.locals.validate+0x748>
    6a94:      	cmp	x16, #0x0
    6a98:      	b.eq	0x6aa0 <_stogir.locals.validate+0x740>
    6a9c:      	b	0x6aa8 <_stogir.locals.validate+0x748>
    6aa0:      	b	0x6aac <_stogir.locals.validate+0x74c>
    6aa4:      	b	0x6a04 <_stogir.locals.validate+0x6a4>
    6aa8:      	b	0x6af0 <_stogir.locals.validate+0x790>
    6aac:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006aac:  ARM64_RELOC_PAGE21	l_stogir.398
    6ab0:      	ldr	x16, [x16]
		0000000000006ab0:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    6ab4:      	orr	x0, x16, xzr
    6ab8:      	mov	x1, x0
    6abc:      	mov	x0, #0x1                ; =1
    6ac0:      	mov	x2, #0x19               ; =25
    6ac4:      	b	0x6a68 <_stogir.locals.validate+0x708>
    6ac8:      	brk	#0
    6acc:      	b	0x6ac8 <_stogir.locals.validate+0x768>
    6ad0:      	uxtb	w20, w20
    6ad4:      	cmp	x20, #0x48
    6ad8:      	b.eq	0x6a50 <_stogir.locals.validate+0x6f0>
    6adc:      	and	x0, x0, #0xffffffff
    6ae0:      	mov	x1, x0
    6ae4:      	movz	x0, #0x0, lsl #48
    6ae8:      	movz	x2, #0x0, lsl #48
    6aec:      	b	0x6a68 <_stogir.locals.validate+0x708>
    6af0:      	brk	#0
    6af4:      	b	0x6af0 <_stogir.locals.validate+0x790>
    6af8:      	mov	x23, x8
    6afc:      	b	0x6474 <_stogir.locals.validate+0x114>
    6b00:      	mov	x23, x8
    6b04:      	b	0x6474 <_stogir.locals.validate+0x114>

0000000000006b08 <_stogir.conversion.operation?>:
    6b08:      	sxtw	x0, w0
    6b0c:      	cmp	x0, #0x21
    6b10:      	b.lt	0x6b24 <_stogir.conversion.operation?+0x1c>
    6b14:      	cmp	x0, #0x27
    6b18:      	cset	w0, le
    6b1c:      	ubfx	x0, x0, #0, #8
    6b20:      	b	0x6b28 <_stogir.conversion.operation?+0x20>
    6b24:      	movz	x0, #0x0, lsl #48
    6b28:      	ret

0000000000006b2c <_stogir.conversion.validate>:
    6b2c:      	sub	sp, sp, #0x40
    6b30:      	str	x29, [sp]
    6b34:      	str	x30, [sp, #0x8]
    6b38:      	mov	x29, sp
    6b3c:      	str	x19, [sp, #0x30]
    6b40:      	sxtw	x1, w1
    6b44:      	lsl	x3, x1, #2
    6b48:      	cmp	x1, #0x0
    6b4c:      	cset	w4, gt
    6b50:      	movz	x16, #0x0, lsl #48
    6b54:      	sub	x5, x16, x1
    6b58:      	sub	x6, x5, #0x1
    6b5c:      	uxtb	w16, w4
    6b60:      	cmp	w16, wzr
    6b64:      	b.eq	0x6ba4 <_stogir.conversion.validate+0x78>
    6b68:      	ldr	x5, [x0, #0x8]
    6b6c:      	cmp	x1, x5
    6b70:      	b.ge	0x6bf8 <_stogir.conversion.validate+0xcc>
    6b74:      	add	x5, x0, #0x78
    6b78:      	ldr	x5, [x5, #0x8]
    6b7c:      	cmp	x1, x5
    6b80:      	b.ge	0x6ce4 <_stogir.conversion.validate+0x1b8>
    6b84:      	ldr	x5, [x0, #0x78]
    6b88:      	add	x5, x3, x5
    6b8c:      	ldr	w5, [x5]
    6b90:      	sxtw	x5, w5
    6b94:      	cmp	x5, #0x0
    6b98:      	cset	w5, ge
    6b9c:      	ubfx	x5, x5, #0, #8
    6ba0:      	b	0x6ce8 <_stogir.conversion.validate+0x1bc>
    6ba4:      	cmp	x1, #0x0
    6ba8:      	b.ge	0x6c00 <_stogir.conversion.validate+0xd4>
    6bac:      	add	x7, x0, #0x28
    6bb0:      	add	x9, x0, #0x50
    6bb4:      	ldr	x7, [x7, #0x8]
    6bb8:      	ldr	x9, [x9, #0x8]
    6bbc:      	cmp	x7, x9
    6bc0:      	b.ne	0x6bf0 <_stogir.conversion.validate+0xc4>
    6bc4:      	cmp	x5, x7
    6bc8:      	b.gt	0x6d7c <_stogir.conversion.validate+0x250>
    6bcc:      	lsl	x5, x6, #2
    6bd0:      	ldr	x7, [x0, #0x50]
    6bd4:      	add	x5, x5, x7
    6bd8:      	ldr	w5, [x5]
    6bdc:      	sxtw	x5, w5
    6be0:      	cmp	x5, #0x0
    6be4:      	cset	w5, gt
    6be8:      	ubfx	x5, x5, #0, #8
    6bec:      	b	0x6d80 <_stogir.conversion.validate+0x254>
    6bf0:      	movz	x5, #0x0, lsl #48
    6bf4:      	b	0x6c04 <_stogir.conversion.validate+0xd8>
    6bf8:      	movz	x5, #0x0, lsl #48
    6bfc:      	b	0x6c04 <_stogir.conversion.validate+0xd8>
    6c00:      	movz	x5, #0x0, lsl #48
    6c04:      	cmp	x5, #0x0
    6c08:      	b.eq	0x6c48 <_stogir.conversion.validate+0x11c>
    6c0c:      	uxtb	w16, w4
    6c10:      	cmp	w16, wzr
    6c14:      	b.eq	0x6c2c <_stogir.conversion.validate+0x100>
    6c18:      	lsl	x4, x1, #4
    6c1c:      	ldr	x5, [x0]
    6c20:      	add	x4, x4, x5
    6c24:      	ldr	x4, [x4]
    6c28:      	b	0x6c3c <_stogir.conversion.validate+0x110>
    6c2c:      	lsl	x4, x6, #4
    6c30:      	ldr	x5, [x0, #0x28]
    6c34:      	add	x4, x4, x5
    6c38:      	ldr	x4, [x4]
    6c3c:      	mov	x5, x4
    6c40:      	mov	x4, #0x1                ; =1
    6c44:      	b	0x6c50 <_stogir.conversion.validate+0x124>
    6c48:      	movz	x4, #0x0, lsl #48
    6c4c:      	movz	x5, #0x0, lsl #48
    6c50:      	lsr	w4, w4, #0
    6c54:      	lsr	x16, x4, #0
    6c58:      	cmp	x16, #0x1
    6c5c:      	b.eq	0x6c78 <_stogir.conversion.validate+0x14c>
    6c60:      	b.lo	0x6c68 <_stogir.conversion.validate+0x13c>
    6c64:      	b	0x6c7c <_stogir.conversion.validate+0x150>
    6c68:      	cmp	x16, #0x0
    6c6c:      	b.eq	0x6c74 <_stogir.conversion.validate+0x148>
    6c70:      	b	0x6c7c <_stogir.conversion.validate+0x150>
    6c74:      	b	0x6c80 <_stogir.conversion.validate+0x154>
    6c78:      	b	0x6cbc <_stogir.conversion.validate+0x190>
    6c7c:      	b	0x6dfc <_stogir.conversion.validate+0x2d0>
    6c80:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006c80:  ARM64_RELOC_PAGE21	l_stogir.399
    6c84:      	ldr	x16, [x16]
		0000000000006c84:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6c88:      	orr	x0, x16, xzr
    6c8c:      	mov	x19, x8
    6c90:      	mov	x1, x0
    6c94:      	mov	x0, #0x1                ; =1
    6c98:      	mov	x2, #0x12               ; =18
    6c9c:      	str	x0, [x19]
    6ca0:      	str	x1, [x19, #0x8]
    6ca4:      	str	x2, [x19, #0x10]
    6ca8:      	ldr	x19, [sp, #0x30]
    6cac:      	ldr	x29, [sp]
    6cb0:      	ldr	x30, [sp, #0x8]
    6cb4:      	add	sp, sp, #0x40
    6cb8:      	ret
    6cbc:      	cmp	x1, #0x0
    6cc0:      	b.gt	0x6cec <_stogir.conversion.validate+0x1c0>
    6cc4:      	mov	x19, x8
    6cc8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006cc8:  ARM64_RELOC_PAGE21	l_stogir.400
    6ccc:      	ldr	x16, [x16]
		0000000000006ccc:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6cd0:      	orr	x0, x16, xzr
    6cd4:      	mov	x1, x0
    6cd8:      	mov	x0, #0x1                ; =1
    6cdc:      	mov	x2, #0x1e               ; =30
    6ce0:      	b	0x6c9c <_stogir.conversion.validate+0x170>
    6ce4:      	movz	x5, #0x0, lsl #48
    6ce8:      	b	0x6bfc <_stogir.conversion.validate+0xd0>
    6cec:      	uxtb	w1, w5
    6cf0:      	orr	x4, x1, xzr
    6cf4:      	cmp	x4, #0x21
    6cf8:      	b.lt	0x6f30 <_stogir.conversion.validate+0x404>
    6cfc:      	cmp	x4, #0x27
    6d00:      	b.gt	0x6f38 <_stogir.conversion.validate+0x40c>
    6d04:      	ldr	x4, [x0, #0x78]
    6d08:      	add	x3, x3, x4
    6d0c:      	ldr	w3, [x3]
    6d10:      	sxtw	x3, w3
    6d14:      	cmp	x3, #0x1
    6d18:      	b.ne	0x6f40 <_stogir.conversion.validate+0x414>
    6d1c:      	asr	x3, x5, #32
    6d20:      	cmp	x3, #0x0
    6d24:      	cset	w6, gt
    6d28:      	movz	x16, #0x0, lsl #48
    6d2c:      	sub	x7, x16, x3
    6d30:      	sub	x9, x7, #0x1
    6d34:      	uxtb	w16, w6
    6d38:      	cmp	w16, wzr
    6d3c:      	b.eq	0x6db0 <_stogir.conversion.validate+0x284>
    6d40:      	ldr	x7, [x0, #0x8]
    6d44:      	cmp	x3, x7
    6d48:      	b.ge	0x6e04 <_stogir.conversion.validate+0x2d8>
    6d4c:      	add	x7, x0, #0x78
    6d50:      	ldr	x7, [x7, #0x8]
    6d54:      	cmp	x3, x7
    6d58:      	b.ge	0x6eb4 <_stogir.conversion.validate+0x388>
    6d5c:      	lsl	x7, x3, #2
    6d60:      	add	x4, x7, x4
    6d64:      	ldr	w4, [x4]
    6d68:      	sxtw	x4, w4
    6d6c:      	cmp	x4, #0x0
    6d70:      	cset	w4, ge
    6d74:      	ubfx	x4, x4, #0, #8
    6d78:      	b	0x6eb8 <_stogir.conversion.validate+0x38c>
    6d7c:      	movz	x5, #0x0, lsl #48
    6d80:      	b	0x6bf4 <_stogir.conversion.validate+0xc8>
    6d84:      	uxtb	w0, w3
    6d88:      	cmp	x0, #0x48
    6d8c:      	b.ne	0x6ebc <_stogir.conversion.validate+0x390>
    6d90:      	mov	x19, x8
    6d94:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006d94:  ARM64_RELOC_PAGE21	l_stogir.401
    6d98:      	ldr	x16, [x16]
		0000000000006d98:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6d9c:      	orr	x0, x16, xzr
    6da0:      	mov	x1, x0
    6da4:      	mov	x0, #0x1                ; =1
    6da8:      	mov	x2, #0x25               ; =37
    6dac:      	b	0x6ce0 <_stogir.conversion.validate+0x1b4>
    6db0:      	cmp	x3, #0x0
    6db4:      	b.ge	0x6e0c <_stogir.conversion.validate+0x2e0>
    6db8:      	add	x4, x0, #0x28
    6dbc:      	add	x10, x0, #0x50
    6dc0:      	ldr	x4, [x4, #0x8]
    6dc4:      	ldr	x10, [x10, #0x8]
    6dc8:      	cmp	x4, x10
    6dcc:      	b.ne	0x6eac <_stogir.conversion.validate+0x380>
    6dd0:      	cmp	x7, x4
    6dd4:      	b.gt	0x6f20 <_stogir.conversion.validate+0x3f4>
    6dd8:      	lsl	x4, x9, #2
    6ddc:      	ldr	x7, [x0, #0x50]
    6de0:      	add	x4, x4, x7
    6de4:      	ldr	w4, [x4]
    6de8:      	sxtw	x4, w4
    6dec:      	cmp	x4, #0x0
    6df0:      	cset	w4, gt
    6df4:      	ubfx	x4, x4, #0, #8
    6df8:      	b	0x6f24 <_stogir.conversion.validate+0x3f8>
    6dfc:      	brk	#0
    6e00:      	b	0x6dfc <_stogir.conversion.validate+0x2d0>
    6e04:      	movz	x4, #0x0, lsl #48
    6e08:      	b	0x6e10 <_stogir.conversion.validate+0x2e4>
    6e0c:      	movz	x4, #0x0, lsl #48
    6e10:      	cmp	x4, #0x0
    6e14:      	b.eq	0x6e54 <_stogir.conversion.validate+0x328>
    6e18:      	uxtb	w16, w6
    6e1c:      	cmp	w16, wzr
    6e20:      	b.eq	0x6e38 <_stogir.conversion.validate+0x30c>
    6e24:      	lsl	x3, x3, #4
    6e28:      	ldr	x0, [x0]
    6e2c:      	add	x0, x3, x0
    6e30:      	ldr	x0, [x0]
    6e34:      	b	0x6e48 <_stogir.conversion.validate+0x31c>
    6e38:      	lsl	x3, x9, #4
    6e3c:      	ldr	x0, [x0, #0x28]
    6e40:      	add	x0, x3, x0
    6e44:      	ldr	x0, [x0]
    6e48:      	mov	x3, x0
    6e4c:      	mov	x0, #0x1                ; =1
    6e50:      	b	0x6e5c <_stogir.conversion.validate+0x330>
    6e54:      	movz	x0, #0x0, lsl #48
    6e58:      	movz	x3, #0x0, lsl #48
    6e5c:      	lsr	w0, w0, #0
    6e60:      	lsr	x16, x0, #0
    6e64:      	cmp	x16, #0x1
    6e68:      	b.eq	0x6e84 <_stogir.conversion.validate+0x358>
    6e6c:      	b.lo	0x6e74 <_stogir.conversion.validate+0x348>
    6e70:      	b	0x6e88 <_stogir.conversion.validate+0x35c>
    6e74:      	cmp	x16, #0x0
    6e78:      	b.eq	0x6e80 <_stogir.conversion.validate+0x354>
    6e7c:      	b	0x6e88 <_stogir.conversion.validate+0x35c>
    6e80:      	b	0x6e8c <_stogir.conversion.validate+0x360>
    6e84:      	b	0x6d84 <_stogir.conversion.validate+0x258>
    6e88:      	b	0x6f28 <_stogir.conversion.validate+0x3fc>
    6e8c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x310>
		0000000000006e8c:  ARM64_RELOC_PAGE21	l_stogir.402
    6e90:      	ldr	x16, [x16]
		0000000000006e90:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6e94:      	orr	x0, x16, xzr
    6e98:      	mov	x19, x8
    6e9c:      	mov	x1, x0
    6ea0:      	mov	x0, #0x1                ; =1
    6ea4:      	mov	x2, #0x19               ; =25
    6ea8:      	b	0x6dac <_stogir.conversion.validate+0x280>
    6eac:      	movz	x4, #0x0, lsl #48
    6eb0:      	b	0x6e10 <_stogir.conversion.validate+0x2e4>
    6eb4:      	movz	x4, #0x0, lsl #48
    6eb8:      	b	0x6e08 <_stogir.conversion.validate+0x2dc>
    6ebc:      	cmp	x0, #0x46
    6ec0:      	b.eq	0x6f48 <_stogir.conversion.validate+0x41c>
    6ec4:      	lsr	w2, w2, #0
    6ec8:      	lsr	w5, w5, #0
    6ecc:      	lsr	w3, w3, #0
    6ed0:      	lsr	w1, w1, #0
    6ed4:      	ubfx	x0, x5, #8, #8
    6ed8:      	ubfx	x3, x3, #8, #8
    6edc:      	lsr	w0, w0, #0
    6ee0:      	lsr	w3, w3, #0
    6ee4:      	mov	x19, x8
    6ee8:      	add	x8, sp, #0x10
    6eec:      	fmov	s31, w0
    6ef0:      	mov	w0, w1
    6ef4:      	mov	w1, w3
    6ef8:      	mov	w3, w2
    6efc:      	fmov	w2, s31
    6f00:      	bl	0x6f00 <_stogir.conversion.validate+0x3d4>
		0000000000006f00:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    6f04:      	add	x16, sp, #0x10
    6f08:      	ldr	x0, [x16]
    6f0c:      	add	x16, sp, #0x10
    6f10:      	ldr	x1, [x16, #0x8]
    6f14:      	add	x16, sp, #0x10
    6f18:      	ldr	x2, [x16, #0x10]
    6f1c:      	b	0x6dac <_stogir.conversion.validate+0x280>
    6f20:      	movz	x4, #0x0, lsl #48
    6f24:      	b	0x6eb0 <_stogir.conversion.validate+0x384>
    6f28:      	brk	#0
    6f2c:      	b	0x6f28 <_stogir.conversion.validate+0x3fc>
    6f30:      	mov	x19, x8
    6f34:      	b	0x6cc8 <_stogir.conversion.validate+0x19c>
    6f38:      	mov	x19, x8
    6f3c:      	b	0x6cc8 <_stogir.conversion.validate+0x19c>
    6f40:      	mov	x19, x8
    6f44:      	b	0x6cc8 <_stogir.conversion.validate+0x19c>
    6f48:      	mov	x19, x8
    6f4c:      	b	0x6d94 <_stogir.conversion.validate+0x268>

0000000000006f50 <_stogir.conditional.validate>:
    6f50:      	sub	sp, sp, #0x40
    6f54:      	str	x29, [sp]
    6f58:      	str	x30, [sp, #0x8]
    6f5c:      	mov	x29, sp
    6f60:      	str	x19, [sp, #0x30]
    6f64:      	sxtw	x1, w1
    6f68:      	lsl	x2, x1, #2
    6f6c:      	cmp	x1, #0x0
    6f70:      	cset	w3, gt
    6f74:      	movz	x16, #0x0, lsl #48
    6f78:      	sub	x4, x16, x1
    6f7c:      	sub	x5, x4, #0x1
    6f80:      	uxtb	w16, w3
    6f84:      	cmp	w16, wzr
    6f88:      	b.eq	0x6fc8 <_stogir.conditional.validate+0x78>
    6f8c:      	ldr	x4, [x0, #0x8]
    6f90:      	cmp	x1, x4
    6f94:      	b.ge	0x701c <_stogir.conditional.validate+0xcc>
    6f98:      	add	x4, x0, #0x78
    6f9c:      	ldr	x4, [x4, #0x8]
    6fa0:      	cmp	x1, x4
    6fa4:      	b.ge	0x7130 <_stogir.conditional.validate+0x1e0>
    6fa8:      	ldr	x4, [x0, #0x78]
    6fac:      	add	x4, x2, x4
    6fb0:      	ldr	w4, [x4]
    6fb4:      	sxtw	x4, w4
    6fb8:      	cmp	x4, #0x0
    6fbc:      	cset	w4, ge
    6fc0:      	ubfx	x4, x4, #0, #8
    6fc4:      	b	0x7134 <_stogir.conditional.validate+0x1e4>
    6fc8:      	cmp	x1, #0x0
    6fcc:      	b.ge	0x7024 <_stogir.conditional.validate+0xd4>
    6fd0:      	add	x6, x0, #0x28
    6fd4:      	add	x7, x0, #0x50
    6fd8:      	ldr	x6, [x6, #0x8]
    6fdc:      	ldr	x7, [x7, #0x8]
    6fe0:      	cmp	x6, x7
    6fe4:      	b.ne	0x7014 <_stogir.conditional.validate+0xc4>
    6fe8:      	cmp	x4, x6
    6fec:      	b.gt	0x71b8 <_stogir.conditional.validate+0x268>
    6ff0:      	lsl	x4, x5, #2
    6ff4:      	ldr	x6, [x0, #0x50]
    6ff8:      	add	x4, x4, x6
    6ffc:      	ldr	w4, [x4]
    7000:      	sxtw	x4, w4
    7004:      	cmp	x4, #0x0
    7008:      	cset	w4, gt
    700c:      	ubfx	x4, x4, #0, #8
    7010:      	b	0x71bc <_stogir.conditional.validate+0x26c>
    7014:      	movz	x4, #0x0, lsl #48
    7018:      	b	0x7028 <_stogir.conditional.validate+0xd8>
    701c:      	movz	x4, #0x0, lsl #48
    7020:      	b	0x7028 <_stogir.conditional.validate+0xd8>
    7024:      	movz	x4, #0x0, lsl #48
    7028:      	cmp	x4, #0x0
    702c:      	b.eq	0x7090 <_stogir.conditional.validate+0x140>
    7030:      	uxtb	w16, w3
    7034:      	cmp	w16, wzr
    7038:      	b.eq	0x7060 <_stogir.conditional.validate+0x110>
    703c:      	lsl	x3, x1, #4
    7040:      	ldr	x4, [x0]
    7044:      	add	x3, x3, x4
    7048:      	ldr	x4, [x3]
    704c:      	ldr	x3, [x3, #0x8]
    7050:      	fmov	d31, x3
    7054:      	mov	x3, x4
    7058:      	fmov	x4, d31
    705c:      	b	0x7080 <_stogir.conditional.validate+0x130>
    7060:      	lsl	x3, x5, #4
    7064:      	ldr	x4, [x0, #0x28]
    7068:      	add	x3, x3, x4
    706c:      	ldr	x4, [x3]
    7070:      	ldr	x3, [x3, #0x8]
    7074:      	fmov	d31, x3
    7078:      	mov	x3, x4
    707c:      	fmov	x4, d31
    7080:      	mov	x5, x4
    7084:      	mov	x4, x3
    7088:      	mov	x3, #0x1                ; =1
    708c:      	b	0x709c <_stogir.conditional.validate+0x14c>
    7090:      	movz	x3, #0x0, lsl #48
    7094:      	movz	x4, #0x0, lsl #48
    7098:      	movz	x5, #0x0, lsl #48
    709c:      	lsr	w3, w3, #0
    70a0:      	lsr	x16, x3, #0
    70a4:      	cmp	x16, #0x1
    70a8:      	b.eq	0x70c4 <_stogir.conditional.validate+0x174>
    70ac:      	b.lo	0x70b4 <_stogir.conditional.validate+0x164>
    70b0:      	b	0x70c8 <_stogir.conditional.validate+0x178>
    70b4:      	cmp	x16, #0x0
    70b8:      	b.eq	0x70c0 <_stogir.conditional.validate+0x170>
    70bc:      	b	0x70c8 <_stogir.conditional.validate+0x178>
    70c0:      	b	0x70cc <_stogir.conditional.validate+0x17c>
    70c4:      	b	0x70ec <_stogir.conditional.validate+0x19c>
    70c8:      	b	0x71c0 <_stogir.conditional.validate+0x270>
    70cc:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		00000000000070cc:  ARM64_RELOC_PAGE21	l_stogir.403
    70d0:      	ldr	x16, [x16]
		00000000000070d0:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    70d4:      	orr	x0, x16, xzr
    70d8:      	mov	x19, x8
    70dc:      	mov	x1, x0
    70e0:      	mov	x0, #0x1                ; =1
    70e4:      	mov	x2, #0x18               ; =24
    70e8:      	b	0x7110 <_stogir.conditional.validate+0x1c0>
    70ec:      	cmp	x1, #0x0
    70f0:      	b.gt	0x7138 <_stogir.conditional.validate+0x1e8>
    70f4:      	mov	x19, x8
    70f8:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		00000000000070f8:  ARM64_RELOC_PAGE21	l_stogir.404
    70fc:      	ldr	x16, [x16]
		00000000000070fc:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    7100:      	orr	x0, x16, xzr
    7104:      	mov	x1, x0
    7108:      	mov	x0, #0x1                ; =1
    710c:      	mov	x2, #0x18               ; =24
    7110:      	str	x0, [x19]
    7114:      	str	x1, [x19, #0x8]
    7118:      	str	x2, [x19, #0x10]
    711c:      	ldr	x19, [sp, #0x30]
    7120:      	ldr	x29, [sp]
    7124:      	ldr	x30, [sp, #0x8]
    7128:      	add	sp, sp, #0x40
    712c:      	ret
    7130:      	movz	x4, #0x0, lsl #48
    7134:      	b	0x7020 <_stogir.conditional.validate+0xd0>
    7138:      	uxtb	w1, w4
    713c:      	cmp	x1, #0x3c
    7140:      	b.ne	0x71c8 <_stogir.conditional.validate+0x278>
    7144:      	ldr	x1, [x0, #0x78]
    7148:      	add	x1, x2, x1
    714c:      	ldr	w1, [x1]
    7150:      	sxtw	x1, w1
    7154:      	cmp	x1, #0x3
    7158:      	b.ne	0x71d0 <_stogir.conditional.validate+0x280>
    715c:      	lsr	w1, w5, #0
    7160:      	lsr	w2, w4, #0
    7164:      	lsr	x3, x4, #32
    7168:      	lsr	w1, w1, #0
    716c:      	lsr	x4, x5, #32
    7170:      	lsr	w3, w3, #0
    7174:      	lsr	w4, w4, #0
    7178:      	ubfx	x2, x2, #8, #8
    717c:      	lsr	w2, w2, #0
    7180:      	mov	x19, x8
    7184:      	add	x8, sp, #0x10
    7188:      	fmov	s31, w1
    718c:      	mov	w1, w2
    7190:      	mov	w2, w3
    7194:      	fmov	w3, s31
    7198:      	bl	0x7198 <_stogir.conditional.validate+0x248>
		0000000000007198:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    719c:      	add	x16, sp, #0x10
    71a0:      	ldr	x0, [x16]
    71a4:      	add	x16, sp, #0x10
    71a8:      	ldr	x1, [x16, #0x8]
    71ac:      	add	x16, sp, #0x10
    71b0:      	ldr	x2, [x16, #0x10]
    71b4:      	b	0x7110 <_stogir.conditional.validate+0x1c0>
    71b8:      	movz	x4, #0x0, lsl #48
    71bc:      	b	0x7018 <_stogir.conditional.validate+0xc8>
    71c0:      	brk	#0
    71c4:      	b	0x71c0 <_stogir.conditional.validate+0x270>
    71c8:      	mov	x19, x8
    71cc:      	b	0x70f8 <_stogir.conditional.validate+0x1a8>
    71d0:      	mov	x19, x8
    71d4:      	b	0x70f8 <_stogir.conditional.validate+0x1a8>

00000000000071d8 <_stogir.floating.validate>:
    71d8:      	sub	sp, sp, #0x50
    71dc:      	str	x29, [sp]
    71e0:      	str	x30, [sp, #0x8]
    71e4:      	mov	x29, sp
    71e8:      	str	x19, [sp, #0x40]
    71ec:      	sxtw	x1, w1
    71f0:      	lsl	x2, x1, #2
    71f4:      	cmp	x1, #0x0
    71f8:      	cset	w3, gt
    71fc:      	movz	x16, #0x0, lsl #48
    7200:      	sub	x4, x16, x1
    7204:      	sub	x5, x4, #0x1
    7208:      	uxtb	w16, w3
    720c:      	cmp	w16, wzr
    7210:      	b.eq	0x7250 <_stogir.floating.validate+0x78>
    7214:      	ldr	x4, [x0, #0x8]
    7218:      	cmp	x1, x4
    721c:      	b.ge	0x72a4 <_stogir.floating.validate+0xcc>
    7220:      	add	x4, x0, #0x78
    7224:      	ldr	x4, [x4, #0x8]
    7228:      	cmp	x1, x4
    722c:      	b.ge	0x73c8 <_stogir.floating.validate+0x1f0>
    7230:      	ldr	x4, [x0, #0x78]
    7234:      	add	x4, x2, x4
    7238:      	ldr	w4, [x4]
    723c:      	sxtw	x4, w4
    7240:      	cmp	x4, #0x0
    7244:      	cset	w4, ge
    7248:      	ubfx	x4, x4, #0, #8
    724c:      	b	0x73cc <_stogir.floating.validate+0x1f4>
    7250:      	cmp	x1, #0x0
    7254:      	b.ge	0x72ac <_stogir.floating.validate+0xd4>
    7258:      	add	x6, x0, #0x28
    725c:      	add	x7, x0, #0x50
    7260:      	ldr	x6, [x6, #0x8]
    7264:      	ldr	x7, [x7, #0x8]
    7268:      	cmp	x6, x7
    726c:      	b.ne	0x729c <_stogir.floating.validate+0xc4>
    7270:      	cmp	x4, x6
    7274:      	b.gt	0x7454 <_stogir.floating.validate+0x27c>
    7278:      	lsl	x4, x5, #2
    727c:      	ldr	x6, [x0, #0x50]
    7280:      	add	x4, x4, x6
    7284:      	ldr	w4, [x4]
    7288:      	sxtw	x4, w4
    728c:      	cmp	x4, #0x0
    7290:      	cset	w4, gt
    7294:      	ubfx	x4, x4, #0, #8
    7298:      	b	0x7458 <_stogir.floating.validate+0x280>
    729c:      	movz	x4, #0x0, lsl #48
    72a0:      	b	0x72b0 <_stogir.floating.validate+0xd8>
    72a4:      	movz	x4, #0x0, lsl #48
    72a8:      	b	0x72b0 <_stogir.floating.validate+0xd8>
    72ac:      	movz	x4, #0x0, lsl #48
    72b0:      	cmp	x4, #0x0
    72b4:      	b.eq	0x7318 <_stogir.floating.validate+0x140>
    72b8:      	uxtb	w16, w3
    72bc:      	cmp	w16, wzr
    72c0:      	b.eq	0x72e8 <_stogir.floating.validate+0x110>
    72c4:      	lsl	x3, x1, #4
    72c8:      	ldr	x4, [x0]
    72cc:      	add	x3, x3, x4
    72d0:      	ldr	x4, [x3]
    72d4:      	ldr	x3, [x3, #0x8]
    72d8:      	fmov	d31, x3
    72dc:      	mov	x3, x4
    72e0:      	fmov	x4, d31
    72e4:      	b	0x7308 <_stogir.floating.validate+0x130>
    72e8:      	lsl	x3, x5, #4
    72ec:      	ldr	x4, [x0, #0x28]
    72f0:      	add	x3, x3, x4
    72f4:      	ldr	x4, [x3]
    72f8:      	ldr	x3, [x3, #0x8]
    72fc:      	fmov	d31, x3
    7300:      	mov	x3, x4
    7304:      	fmov	x4, d31
    7308:      	mov	x5, x4
    730c:      	mov	x4, x3
    7310:      	mov	x3, #0x1                ; =1
    7314:      	b	0x7324 <_stogir.floating.validate+0x14c>
    7318:      	movz	x3, #0x0, lsl #48
    731c:      	movz	x4, #0x0, lsl #48
    7320:      	movz	x5, #0x0, lsl #48
    7324:      	lsr	w3, w3, #0
    7328:      	lsr	x16, x3, #0
    732c:      	cmp	x16, #0x1
    7330:      	b.eq	0x734c <_stogir.floating.validate+0x174>
    7334:      	b.lo	0x733c <_stogir.floating.validate+0x164>
    7338:      	b	0x7350 <_stogir.floating.validate+0x178>
    733c:      	cmp	x16, #0x0
    7340:      	b.eq	0x7348 <_stogir.floating.validate+0x170>
    7344:      	b	0x7350 <_stogir.floating.validate+0x178>
    7348:      	b	0x7354 <_stogir.floating.validate+0x17c>
    734c:      	b	0x7390 <_stogir.floating.validate+0x1b8>
    7350:      	b	0x7710 <_stogir.floating.validate+0x538>
    7354:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007354:  ARM64_RELOC_PAGE21	l_stogir.405
    7358:      	ldr	x16, [x16]
		0000000000007358:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    735c:      	orr	x0, x16, xzr
    7360:      	mov	x19, x8
    7364:      	mov	x1, x0
    7368:      	mov	x0, #0x1                ; =1
    736c:      	mov	x2, #0x1c               ; =28
    7370:      	str	x0, [x19]
    7374:      	str	x1, [x19, #0x8]
    7378:      	str	x2, [x19, #0x10]
    737c:      	ldr	x19, [sp, #0x40]
    7380:      	ldr	x29, [sp]
    7384:      	ldr	x30, [sp, #0x8]
    7388:      	add	sp, sp, #0x50
    738c:      	ret
    7390:      	add	x16, sp, #0x10
    7394:      	str	x4, [x16]
    7398:      	add	x16, sp, #0x10
    739c:      	str	x5, [x16, #0x8]
    73a0:      	cmp	x1, #0x0
    73a4:      	b.gt	0x73d0 <_stogir.floating.validate+0x1f8>
    73a8:      	mov	x19, x8
    73ac:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		00000000000073ac:  ARM64_RELOC_PAGE21	l_stogir.406
    73b0:      	ldr	x16, [x16]
		00000000000073b0:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    73b4:      	orr	x0, x16, xzr
    73b8:      	mov	x1, x0
    73bc:      	mov	x0, #0x1                ; =1
    73c0:      	mov	x2, #0x1c               ; =28
    73c4:      	b	0x7370 <_stogir.floating.validate+0x198>
    73c8:      	movz	x4, #0x0, lsl #48
    73cc:      	b	0x72a8 <_stogir.floating.validate+0xd0>
    73d0:      	uxtb	w4, w4
    73d4:      	orr	x1, x4, xzr
    73d8:      	cmp	x1, #0xe
    73dc:      	cset	w3, ge
    73e0:      	cmp	x1, #0x19
    73e4:      	cset	w5, le
    73e8:      	cmp	x1, #0x1f
    73ec:      	cset	w6, eq
    73f0:      	cmp	x1, #0x20
    73f4:      	cset	w7, eq
    73f8:      	uxtb	w16, w3
    73fc:      	cmp	w16, wzr
    7400:      	b.eq	0x745c <_stogir.floating.validate+0x284>
    7404:      	uxtb	w16, w5
    7408:      	cmp	w16, wzr
    740c:      	b.eq	0x745c <_stogir.floating.validate+0x284>
    7410:      	cmp	x1, #0x1d
    7414:      	cset	w1, eq
    7418:      	ldr	x9, [x0, #0x78]
    741c:      	add	x2, x2, x9
    7420:      	ldr	w2, [x2]
    7424:      	uxtb	w16, w6
    7428:      	cmp	w16, wzr
    742c:      	b.ne	0x749c <_stogir.floating.validate+0x2c4>
    7430:      	uxtb	w16, w7
    7434:      	cmp	w16, wzr
    7438:      	b.ne	0x749c <_stogir.floating.validate+0x2c4>
    743c:      	uxtb	w16, w1
    7440:      	cmp	w16, wzr
    7444:      	mov	x16, #0x3               ; =3
    7448:      	mov	x17, #0x2               ; =2
    744c:      	csel	x6, x16, x17, ne
    7450:      	b	0x74a0 <_stogir.floating.validate+0x2c8>
    7454:      	movz	x4, #0x0, lsl #48
    7458:      	b	0x72a0 <_stogir.floating.validate+0xc8>
    745c:      	uxtb	w16, w6
    7460:      	cmp	w16, wzr
    7464:      	b.ne	0x7410 <_stogir.floating.validate+0x238>
    7468:      	uxtb	w16, w7
    746c:      	cmp	w16, wzr
    7470:      	b.ne	0x7410 <_stogir.floating.validate+0x238>
    7474:      	cmp	x1, #0x1a
    7478:      	b.lt	0x7484 <_stogir.floating.validate+0x2ac>
    747c:      	cmp	x1, #0x1d
    7480:      	b.le	0x7410 <_stogir.floating.validate+0x238>
    7484:      	cmp	x1, #0x3a
    7488:      	b.eq	0x7410 <_stogir.floating.validate+0x238>
    748c:      	cmp	x1, #0x3b
    7490:      	b.eq	0x7410 <_stogir.floating.validate+0x238>
    7494:      	mov	x19, x8
    7498:      	b	0x73ac <_stogir.floating.validate+0x1d4>
    749c:      	mov	x6, #0x1                ; =1
    74a0:      	sxtw	x2, w2
    74a4:      	lsr	w6, w6, #0
    74a8:      	sxtw	x6, w6
    74ac:      	cmp	x2, x6
    74b0:      	b.ne	0x7720 <_stogir.floating.validate+0x548>
    74b4:      	add	x16, sp, #0x10
    74b8:      	ldr	w2, [x16, #0x4]
    74bc:      	sxtw	x2, w2
    74c0:      	cmp	x2, #0x0
    74c4:      	cset	w6, gt
    74c8:      	movz	x16, #0x0, lsl #48
    74cc:      	sub	x7, x16, x2
    74d0:      	sub	x9, x7, #0x1
    74d4:      	uxtb	w16, w6
    74d8:      	cmp	w16, wzr
    74dc:      	b.eq	0x753c <_stogir.floating.validate+0x364>
    74e0:      	ldr	x7, [x0, #0x8]
    74e4:      	cmp	x2, x7
    74e8:      	b.ge	0x7588 <_stogir.floating.validate+0x3b0>
    74ec:      	add	x7, x0, #0x78
    74f0:      	ldr	x7, [x7, #0x8]
    74f4:      	cmp	x2, x7
    74f8:      	b.ge	0x7668 <_stogir.floating.validate+0x490>
    74fc:      	lsl	x7, x2, #2
    7500:      	ldr	x10, [x0, #0x78]
    7504:      	add	x7, x7, x10
    7508:      	ldr	w7, [x7]
    750c:      	sxtw	x7, w7
    7510:      	cmp	x7, #0x0
    7514:      	cset	w7, ge
    7518:      	ubfx	x7, x7, #0, #8
    751c:      	b	0x766c <_stogir.floating.validate+0x494>
    7520:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007520:  ARM64_RELOC_PAGE21	l_stogir.407
    7524:      	ldr	x16, [x16]
		0000000000007524:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    7528:      	orr	x0, x16, xzr
    752c:      	mov	x1, x0
    7530:      	mov	x0, #0x1                ; =1
    7534:      	mov	x2, #0x1d               ; =29
    7538:      	b	0x73c4 <_stogir.floating.validate+0x1ec>
    753c:      	cmp	x2, #0x0
    7540:      	b.ge	0x7590 <_stogir.floating.validate+0x3b8>
    7544:      	add	x10, x0, #0x28
    7548:      	add	x11, x0, #0x50
    754c:      	ldr	x10, [x10, #0x8]
    7550:      	ldr	x11, [x11, #0x8]
    7554:      	cmp	x10, x11
    7558:      	b.ne	0x7660 <_stogir.floating.validate+0x488>
    755c:      	cmp	x7, x10
    7560:      	b.gt	0x7708 <_stogir.floating.validate+0x530>
    7564:      	lsl	x7, x9, #2
    7568:      	ldr	x10, [x0, #0x50]
    756c:      	add	x7, x7, x10
    7570:      	ldr	w7, [x7]
    7574:      	sxtw	x7, w7
    7578:      	cmp	x7, #0x0
    757c:      	cset	w7, gt
    7580:      	ubfx	x7, x7, #0, #8
    7584:      	b	0x770c <_stogir.floating.validate+0x534>
    7588:      	movz	x7, #0x0, lsl #48
    758c:      	b	0x7594 <_stogir.floating.validate+0x3bc>
    7590:      	movz	x7, #0x0, lsl #48
    7594:      	cmp	x7, #0x0
    7598:      	b.eq	0x75d8 <_stogir.floating.validate+0x400>
    759c:      	uxtb	w16, w6
    75a0:      	cmp	w16, wzr
    75a4:      	b.eq	0x75bc <_stogir.floating.validate+0x3e4>
    75a8:      	lsl	x2, x2, #4
    75ac:      	ldr	x6, [x0]
    75b0:      	add	x2, x2, x6
    75b4:      	ldr	x2, [x2]
    75b8:      	b	0x75cc <_stogir.floating.validate+0x3f4>
    75bc:      	lsl	x2, x9, #4
    75c0:      	ldr	x6, [x0, #0x28]
    75c4:      	add	x2, x2, x6
    75c8:      	ldr	x2, [x2]
    75cc:      	mov	x6, x2
    75d0:      	mov	x2, #0x1                ; =1
    75d4:      	b	0x75e0 <_stogir.floating.validate+0x408>
    75d8:      	movz	x2, #0x0, lsl #48
    75dc:      	movz	x6, #0x0, lsl #48
    75e0:      	lsr	w2, w2, #0
    75e4:      	lsr	x16, x2, #0
    75e8:      	cmp	x16, #0x1
    75ec:      	b.eq	0x7608 <_stogir.floating.validate+0x430>
    75f0:      	b.lo	0x75f8 <_stogir.floating.validate+0x420>
    75f4:      	b	0x760c <_stogir.floating.validate+0x434>
    75f8:      	cmp	x16, #0x0
    75fc:      	b.eq	0x7604 <_stogir.floating.validate+0x42c>
    7600:      	b	0x760c <_stogir.floating.validate+0x434>
    7604:      	b	0x7610 <_stogir.floating.validate+0x438>
    7608:      	b	0x7630 <_stogir.floating.validate+0x458>
    760c:      	b	0x7718 <_stogir.floating.validate+0x540>
    7610:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007610:  ARM64_RELOC_PAGE21	l_stogir.408
    7614:      	ldr	x16, [x16]
		0000000000007614:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    7618:      	orr	x0, x16, xzr
    761c:      	mov	x19, x8
    7620:      	mov	x1, x0
    7624:      	mov	x0, #0x1                ; =1
    7628:      	mov	x2, #0x18               ; =24
    762c:      	b	0x7538 <_stogir.floating.validate+0x360>
    7630:      	lsr	w6, w6, #0
    7634:      	add	x16, sp, #0x10
    7638:      	ldr	w2, [x16]
    763c:      	ubfx	x6, x6, #8, #8
    7640:      	uxtb	w16, w3
    7644:      	cmp	w16, wzr
    7648:      	b.eq	0x76c4 <_stogir.floating.validate+0x4ec>
    764c:      	uxtb	w16, w5
    7650:      	cmp	w16, wzr
    7654:      	b.eq	0x76c4 <_stogir.floating.validate+0x4ec>
    7658:      	mov	x3, #0x1                ; =1
    765c:      	b	0x76c8 <_stogir.floating.validate+0x4f0>
    7660:      	movz	x7, #0x0, lsl #48
    7664:      	b	0x7594 <_stogir.floating.validate+0x3bc>
    7668:      	movz	x7, #0x0, lsl #48
    766c:      	b	0x758c <_stogir.floating.validate+0x3b4>
    7670:      	movz	x1, #0x0, lsl #48
    7674:      	lsr	w2, w2, #0
    7678:      	lsr	w3, w3, #0
    767c:      	lsr	w4, w4, #0
    7680:      	lsr	w6, w6, #0
    7684:      	lsr	w1, w1, #0
    7688:      	mov	w5, w1
    768c:      	mov	w1, w4
    7690:      	mov	w4, w3
    7694:      	mov	w3, w2
    7698:      	mov	w2, w6
    769c:      	mov	x19, x8
    76a0:      	add	x8, sp, #0x20
    76a4:      	bl	0x76a4 <_stogir.floating.validate+0x4cc>
		00000000000076a4:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    76a8:      	add	x16, sp, #0x20
    76ac:      	ldr	x0, [x16]
    76b0:      	add	x16, sp, #0x20
    76b4:      	ldr	x1, [x16, #0x8]
    76b8:      	add	x16, sp, #0x20
    76bc:      	ldr	x2, [x16, #0x10]
    76c0:      	b	0x7538 <_stogir.floating.validate+0x360>
    76c4:      	orr	x3, x6, xzr
    76c8:      	lsr	w3, w3, #0
    76cc:      	ubfx	x2, x2, #8, #8
    76d0:      	sxtw	x3, w3
    76d4:      	cmp	x2, x3
    76d8:      	b.ne	0x7728 <_stogir.floating.validate+0x550>
    76dc:      	add	x16, sp, #0x10
    76e0:      	ldr	w2, [x16, #0x4]
    76e4:      	add	x16, sp, #0x10
    76e8:      	ldr	w3, [x16, #0x8]
    76ec:      	uxtb	w16, w1
    76f0:      	cmp	w16, wzr
    76f4:      	b.eq	0x7670 <_stogir.floating.validate+0x498>
    76f8:      	add	x16, sp, #0x10
    76fc:      	ldr	w1, [x16, #0xc]
    7700:      	sxtw	x1, w1
    7704:      	b	0x7674 <_stogir.floating.validate+0x49c>
    7708:      	movz	x7, #0x0, lsl #48
    770c:      	b	0x7664 <_stogir.floating.validate+0x48c>
    7710:      	brk	#0
    7714:      	b	0x7710 <_stogir.floating.validate+0x538>
    7718:      	brk	#0
    771c:      	b	0x7718 <_stogir.floating.validate+0x540>
    7720:      	mov	x19, x8
    7724:      	b	0x73ac <_stogir.floating.validate+0x1d4>
    7728:      	mov	x19, x8
    772c:      	b	0x7520 <_stogir.floating.validate+0x348>

0000000000007730 <_stogir.types.integer?>:
    7730:      	sxtw	x0, w0
    7734:      	cmp	x0, #0x1
    7738:      	b.lt	0x774c <_stogir.types.integer?+0x1c>
    773c:      	cmp	x0, #0xb
    7740:      	cset	w0, le
    7744:      	ubfx	x0, x0, #0, #8
    7748:      	b	0x7750 <_stogir.types.integer?+0x20>
    774c:      	movz	x0, #0x0, lsl #48
    7750:      	ret

0000000000007754 <_stogir.integer-unary.valid-type?>:
    7754:      	sxtw	x0, w0
    7758:      	cmp	x0, #0x2d
    775c:      	cset	w2, eq
    7760:      	cmp	x0, #0x1f
    7764:      	cset	w3, eq
    7768:      	cmp	x0, #0x20
    776c:      	cset	w4, eq
    7770:      	cmp	x0, #0x36
    7774:      	cset	w5, eq
    7778:      	uxtb	w16, w3
    777c:      	cmp	w16, wzr
    7780:      	b.ne	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    7784:      	uxtb	w16, w4
    7788:      	cmp	w16, wzr
    778c:      	b.ne	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    7790:      	uxtb	w16, w2
    7794:      	cmp	w16, wzr
    7798:      	b.ne	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    779c:      	uxtb	w16, w5
    77a0:      	cmp	w16, wzr
    77a4:      	b.ne	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    77a8:      	cmp	x0, #0x37
    77ac:      	b.eq	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    77b0:      	cmp	x0, #0x38
    77b4:      	b.eq	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    77b8:      	cmp	x0, #0x39
    77bc:      	b.eq	0x77c8 <_stogir.integer-unary.valid-type?+0x74>
    77c0:      	movz	x0, #0x0, lsl #48
    77c4:      	b	0x7800 <_stogir.integer-unary.valid-type?+0xac>
    77c8:      	sxtw	x1, w1
    77cc:      	cmp	x1, #0x1
    77d0:      	b.lt	0x77fc <_stogir.integer-unary.valid-type?+0xa8>
    77d4:      	cmp	x1, #0xb
    77d8:      	cset	w0, le
    77dc:      	uxtb	w16, w0
    77e0:      	cmp	w16, wzr
    77e4:      	b.eq	0x77fc <_stogir.integer-unary.valid-type?+0xa8>
    77e8:      	uxtb	w16, w2
    77ec:      	cmp	w16, wzr
    77f0:      	b.eq	0x780c <_stogir.integer-unary.valid-type?+0xb8>
    77f4:      	mov	x0, #0x1                ; =1
    77f8:      	b	0x7808 <_stogir.integer-unary.valid-type?+0xb4>
    77fc:      	movz	x0, #0x0, lsl #48
    7800:      	ret
    7804:      	mov	x0, #0x1                ; =1
    7808:      	b	0x7800 <_stogir.integer-unary.valid-type?+0xac>
    780c:      	cmp	x1, #0x1
    7810:      	b.ne	0x781c <_stogir.integer-unary.valid-type?+0xc8>
    7814:      	movz	x0, #0x0, lsl #48
    7818:      	b	0x7808 <_stogir.integer-unary.valid-type?+0xb4>
    781c:      	cmp	x1, #0x6
    7820:      	cset	w2, eq
    7824:      	uxtb	w16, w3
    7828:      	cmp	w16, wzr
    782c:      	b.eq	0x7840 <_stogir.integer-unary.valid-type?+0xec>
    7830:      	uxtb	w16, w2
    7834:      	cmp	w16, wzr
    7838:      	cset	x0, eq
    783c:      	b	0x7808 <_stogir.integer-unary.valid-type?+0xb4>
    7840:      	uxtb	w16, w4
    7844:      	cmp	w16, wzr
    7848:      	b.eq	0x7864 <_stogir.integer-unary.valid-type?+0x110>
    784c:      	cmp	x1, #0x7
    7850:      	b.lt	0x785c <_stogir.integer-unary.valid-type?+0x108>
    7854:      	ubfx	x0, x0, #0, #8
    7858:      	b	0x7860 <_stogir.integer-unary.valid-type?+0x10c>
    785c:      	movz	x0, #0x0, lsl #48
    7860:      	b	0x7808 <_stogir.integer-unary.valid-type?+0xb4>
    7864:      	uxtb	w16, w5
    7868:      	cmp	w16, wzr
    786c:      	b.eq	0x7804 <_stogir.integer-unary.valid-type?+0xb0>
    7870:      	cmp	x1, #0x3
    7874:      	b.ne	0x7890 <_stogir.integer-unary.valid-type?+0x13c>
    7878:      	mov	x0, #0x1                ; =1
    787c:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>
    7880:      	cmp	x1, #0xb
    7884:      	cset	w0, eq
    7888:      	ubfx	x0, x0, #0, #8
    788c:      	b	0x7808 <_stogir.integer-unary.valid-type?+0xb4>
    7890:      	cmp	x1, #0x4
    7894:      	b.ne	0x78a0 <_stogir.integer-unary.valid-type?+0x14c>
    7898:      	mov	x0, #0x1                ; =1
    789c:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>
    78a0:      	cmp	x1, #0x5
    78a4:      	b.ne	0x78b0 <_stogir.integer-unary.valid-type?+0x15c>
    78a8:      	mov	x0, #0x1                ; =1
    78ac:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>
    78b0:      	uxtb	w16, w2
    78b4:      	cmp	w16, wzr
    78b8:      	b.eq	0x78c4 <_stogir.integer-unary.valid-type?+0x170>
    78bc:      	mov	x0, #0x1                ; =1
    78c0:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>
    78c4:      	cmp	x1, #0x9
    78c8:      	b.ne	0x78d4 <_stogir.integer-unary.valid-type?+0x180>
    78cc:      	mov	x0, #0x1                ; =1
    78d0:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>
    78d4:      	cmp	x1, #0xa
    78d8:      	b.ne	0x7880 <_stogir.integer-unary.valid-type?+0x12c>
    78dc:      	mov	x0, #0x1                ; =1
    78e0:      	b	0x788c <_stogir.integer-unary.valid-type?+0x138>

00000000000078e4 <_stogir.integer-binary.valid-type?>:
    78e4:      	sxtw	x0, w0
    78e8:      	cmp	x0, #0x3a
    78ec:      	cset	w2, eq
    78f0:      	cmp	x0, #0x3b
    78f4:      	cset	w3, eq
    78f8:      	cmp	x0, #0x1a
    78fc:      	b.lt	0x7950 <_stogir.integer-binary.valid-type?+0x6c>
    7900:      	cmp	x0, #0x1e
    7904:      	b.gt	0x7950 <_stogir.integer-binary.valid-type?+0x6c>
    7908:      	sxtw	x1, w1
    790c:      	cmp	x1, #0x1
    7910:      	b.lt	0x7980 <_stogir.integer-binary.valid-type?+0x9c>
    7914:      	cmp	x1, #0xb
    7918:      	b.gt	0x7980 <_stogir.integer-binary.valid-type?+0x9c>
    791c:      	cmp	x1, #0x1
    7920:      	b.ne	0x7988 <_stogir.integer-binary.valid-type?+0xa4>
    7924:      	cmp	x0, #0x2e
    7928:      	b.eq	0x7990 <_stogir.integer-binary.valid-type?+0xac>
    792c:      	cmp	x0, #0x2f
    7930:      	b.eq	0x7990 <_stogir.integer-binary.valid-type?+0xac>
    7934:      	cmp	x0, #0x30
    7938:      	b.eq	0x7990 <_stogir.integer-binary.valid-type?+0xac>
    793c:      	uxtb	w16, w2
    7940:      	cmp	w16, wzr
    7944:      	b.eq	0x7998 <_stogir.integer-binary.valid-type?+0xb4>
    7948:      	mov	x0, #0x1                ; =1
    794c:      	b	0x79a0 <_stogir.integer-binary.valid-type?+0xbc>
    7950:      	cmp	x0, #0x2e
    7954:      	b.lt	0x7960 <_stogir.integer-binary.valid-type?+0x7c>
    7958:      	cmp	x0, #0x35
    795c:      	b.le	0x7908 <_stogir.integer-binary.valid-type?+0x24>
    7960:      	uxtb	w16, w2
    7964:      	cmp	w16, wzr
    7968:      	b.ne	0x7908 <_stogir.integer-binary.valid-type?+0x24>
    796c:      	uxtb	w16, w3
    7970:      	cmp	w16, wzr
    7974:      	b.ne	0x7908 <_stogir.integer-binary.valid-type?+0x24>
    7978:      	movz	x0, #0x0, lsl #48
    797c:      	b	0x7984 <_stogir.integer-binary.valid-type?+0xa0>
    7980:      	movz	x0, #0x0, lsl #48
    7984:      	ret
    7988:      	mov	x0, #0x1                ; =1
    798c:      	b	0x7984 <_stogir.integer-binary.valid-type?+0xa0>
    7990:      	mov	x0, #0x1                ; =1
    7994:      	b	0x798c <_stogir.integer-binary.valid-type?+0xa8>
    7998:      	ubfx	x3, x3, #0, #8
    799c:      	mov	x0, x3
    79a0:      	b	0x7994 <_stogir.integer-binary.valid-type?+0xb0>

00000000000079a4 <_coil.core.Len$slice$len__u8>:
    79a4:      	mov	x0, x1
    79a8:      	ret

00000000000079ac <_inherent$slice$data__u8>:
    79ac:      	ret

00000000000079b0 <_coil.mem.eql__u8>:
    79b0:      	sub	sp, sp, #0x10
    79b4:      	str	x29, [sp]
    79b8:      	str	x30, [sp, #0x8]
    79bc:      	mov	x29, sp
    79c0:      	cmp	x2, #0x0
    79c4:      	b.ne	0x79d0 <_coil.mem.eql__u8+0x20>
    79c8:      	mov	x0, #0x1                ; =1
    79cc:      	b	0x79ec <_coil.mem.eql__u8+0x3c>
    79d0:      	lsr	x2, x2, #0
    79d4:      	bl	0x79d4 <_coil.mem.eql__u8+0x24>
		00000000000079d4:  ARM64_RELOC_BRANCH26	_memcmp
    79d8:      	lsr	w0, w0, #0
    79dc:      	sxtw	x0, w0
    79e0:      	cmp	x0, #0x0
    79e4:      	cset	w0, eq
    79e8:      	ubfx	x0, x0, #0, #8
    79ec:      	ldr	x29, [sp]
    79f0:      	ldr	x30, [sp, #0x8]
    79f4:      	add	sp, sp, #0x10
    79f8:      	ret

00000000000079fc <_stogir.opcode.count>:
    79fc:      	mov	x0, #0x83               ; =131
    7a00:      	ret

0000000000007a04 <_stogir.types.valid-scalar?>:
    7a04:      	sxtw	x0, w0
    7a08:      	cmp	x0, #0x0
    7a0c:      	b.lt	0x7a20 <_stogir.types.valid-scalar?+0x1c>
    7a10:      	cmp	x0, #0xd
    7a14:      	cset	w0, le
    7a18:      	ubfx	x0, x0, #0, #8
    7a1c:      	b	0x7a24 <_stogir.types.valid-scalar?+0x20>
    7a20:      	movz	x0, #0x0, lsl #48
    7a24:      	ret

0000000000007a28 <_stogir.types.vector?>:
    7a28:      	sxtw	x0, w0
    7a2c:      	cmp	x0, #0xf
    7a30:      	b.le	0x7a6c <_stogir.types.vector?+0x44>
    7a34:      	cmp	x0, #0x80
    7a38:      	b.ge	0x7a7c <_stogir.types.vector?+0x54>
    7a3c:      	and	x1, x0, #0xf
    7a40:      	lsr	w1, w1, #0
    7a44:      	sxtw	x1, w1
    7a48:      	cmp	x1, #0x1
    7a4c:      	b.lt	0x7a74 <_stogir.types.vector?+0x4c>
    7a50:      	and	x0, x0, #0xf
    7a54:      	lsr	w0, w0, #0
    7a58:      	sxtw	x0, w0
    7a5c:      	cmp	x0, #0xd
    7a60:      	cset	w0, le
    7a64:      	ubfx	x0, x0, #0, #8
    7a68:      	b	0x7a78 <_stogir.types.vector?+0x50>
    7a6c:      	movz	x0, #0x0, lsl #48
    7a70:      	b	0x7a78 <_stogir.types.vector?+0x50>
    7a74:      	movz	x0, #0x0, lsl #48
    7a78:      	ret
    7a7c:      	movz	x0, #0x0, lsl #48
    7a80:      	b	0x7a78 <_stogir.types.vector?+0x50>

0000000000007a84 <_coil.core.Get$slice$get__i8>:
    7a84:      	lsr	x1, x2, #0
    7a88:      	add	x0, x1, x0
    7a8c:      	ldrsb	w0, [x0]
    7a90:      	sxtb	x0, w0
    7a94:      	ret

0000000000007a98 <_stogir.opcode.metadata>:
    7a98:      	sub	sp, sp, #0x10
    7a9c:      	mov	x0, sp
    7aa0:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007aa0:  ARM64_RELOC_PAGE21	l_stogir.409
    7aa4:      	ldr	x16, [x16]
		0000000000007aa4:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    7aa8:      	orr	x1, x16, xzr
    7aac:      	str	x1, [x0]
    7ab0:      	mov	x17, #0x83              ; =131
    7ab4:      	str	x17, [x0, #0x8]
    7ab8:      	ldr	x0, [sp]
    7abc:      	ldr	x1, [sp, #0x8]
    7ac0:      	add	sp, sp, #0x10
    7ac4:      	ret

0000000000007ac8 <_coil.core.Get$slice$get__u32>:
    7ac8:      	lsl	x1, x2, #2
    7acc:      	add	x0, x1, x0
    7ad0:      	ldr	w0, [x0]
    7ad4:      	ret

0000000000007ad8 <_stogir.opcode.operand-code-word>:
    7ad8:      	sxtw	x1, w1
    7adc:      	cmp	x1, #0x0
    7ae0:      	b.le	0x7af4 <_stogir.opcode.operand-code-word+0x1c>
    7ae4:      	cmp	x1, #0x4
    7ae8:      	b.le	0x7afc <_stogir.opcode.operand-code-word+0x24>
    7aec:      	mov	x1, #0x4                ; =4
    7af0:      	b	0x7b08 <_stogir.opcode.operand-code-word+0x30>
    7af4:      	movz	x0, #0x0, lsl #48
    7af8:      	b	0x7b28 <_stogir.opcode.operand-code-word+0x50>
    7afc:      	sub	x1, x1, #0x1
    7b00:      	lsr	w1, w1, #0
    7b04:      	sxtw	x1, w1
    7b08:      	ubfx	x0, x0, #0, #32
    7b0c:      	lsl	x1, x1, #2
    7b10:      	lsr	w1, w1, #0
    7b14:      	ubfx	x1, x1, #0, #32
    7b18:      	lsr	x0, x0, x1
    7b1c:      	lsr	w0, w0, #0
    7b20:      	and	x0, x0, #0xf
    7b24:      	lsr	w0, w0, #0
    7b28:      	ret

0000000000007b2c <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7b2c:      	lsl	x1, x1, #4
    7b30:      	ldr	x0, [x0]
    7b34:      	add	x0, x1, x0
    7b38:      	ret

0000000000007b3c <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7b3c:      	ldr	x0, [x0, #0x8]
    7b40:      	ret

0000000000007b44 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7b44:      	ldr	x0, [x0, #0x8]
    7b48:      	ret

0000000000007b4c <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7b4c:      	sub	sp, sp, #0x10
    7b50:      	mov	x1, sp
    7b54:      	ldr	x2, [x0]
    7b58:      	ldr	x0, [x0, #0x8]
    7b5c:      	str	x2, [x1]
    7b60:      	str	x0, [x1, #0x8]
    7b64:      	ldr	x0, [sp]
    7b68:      	ldr	x1, [sp, #0x8]
    7b6c:      	add	sp, sp, #0x10
    7b70:      	ret

0000000000007b74 <_coil.slice.subslice__u8>:
    7b74:      	sub	sp, sp, #0x10
    7b78:      	mov	x1, sp
    7b7c:      	lsr	x4, x2, #0
    7b80:      	sub	x2, x3, x2
    7b84:      	add	x0, x4, x0
    7b88:      	str	x0, [x1]
    7b8c:      	str	x2, [x1, #0x8]
    7b90:      	ldr	x0, [sp]
    7b94:      	ldr	x1, [sp, #0x8]
    7b98:      	add	sp, sp, #0x10
    7b9c:      	ret

0000000000007ba0 <_stogir.floating.operation?>:
    7ba0:      	sxtw	x0, w0
    7ba4:      	cmp	x0, #0xe
    7ba8:      	b.lt	0x7bbc <_stogir.floating.operation?+0x1c>
    7bac:      	cmp	x0, #0x19
    7bb0:      	b.gt	0x7bbc <_stogir.floating.operation?+0x1c>
    7bb4:      	mov	x0, #0x1                ; =1
    7bb8:      	b	0x7be8 <_stogir.floating.operation?+0x48>
    7bbc:      	cmp	x0, #0x1f
    7bc0:      	b.eq	0x7be4 <_stogir.floating.operation?+0x44>
    7bc4:      	cmp	x0, #0x20
    7bc8:      	b.eq	0x7be4 <_stogir.floating.operation?+0x44>
    7bcc:      	cmp	x0, #0x1a
    7bd0:      	b.lt	0x7bfc <_stogir.floating.operation?+0x5c>
    7bd4:      	cmp	x0, #0x1d
    7bd8:      	b.gt	0x7bfc <_stogir.floating.operation?+0x5c>
    7bdc:      	mov	x0, #0x1                ; =1
    7be0:      	b	0x7bf8 <_stogir.floating.operation?+0x58>
    7be4:      	mov	x0, #0x1                ; =1
    7be8:      	ret
    7bec:      	cmp	x0, #0x3b
    7bf0:      	cset	w0, eq
    7bf4:      	ubfx	x0, x0, #0, #8
    7bf8:      	b	0x7be8 <_stogir.floating.operation?+0x48>
    7bfc:      	cmp	x0, #0x3a
    7c00:      	b.ne	0x7bec <_stogir.floating.operation?+0x4c>
    7c04:      	mov	x0, #0x1                ; =1
    7c08:      	b	0x7bf8 <_stogir.floating.operation?+0x58>

0000000000007c0c <_stogir.types.floating?>:
    7c0c:      	sxtw	x0, w0
    7c10:      	cmp	x0, #0xc
    7c14:      	b.ne	0x7c20 <_stogir.types.floating?+0x14>
    7c18:      	mov	x0, #0x1                ; =1
    7c1c:      	b	0x7c2c <_stogir.types.floating?+0x20>
    7c20:      	cmp	x0, #0xd
    7c24:      	cset	w0, eq
    7c28:      	ubfx	x0, x0, #0, #8
    7c2c:      	ret

0000000000007c30 <_stogir.vector-lanes.validate>:
    7c30:      	sub	sp, sp, #0x50
    7c34:      	str	x29, [sp]
    7c38:      	str	x30, [sp, #0x8]
    7c3c:      	mov	x29, sp
    7c40:      	str	x19, [sp, #0x40]
    7c44:      	sxtw	x1, w1
    7c48:      	lsl	x3, x1, #2
    7c4c:      	cmp	x1, #0x0
    7c50:      	cset	w4, gt
    7c54:      	movz	x16, #0x0, lsl #48
    7c58:      	sub	x5, x16, x1
    7c5c:      	sub	x6, x5, #0x1
    7c60:      	uxtb	w16, w4
    7c64:      	cmp	w16, wzr
    7c68:      	b.eq	0x7ca8 <_stogir.vector-lanes.validate+0x78>
    7c6c:      	ldr	x5, [x0, #0x8]
    7c70:      	cmp	x1, x5
    7c74:      	b.ge	0x7cfc <_stogir.vector-lanes.validate+0xcc>
    7c78:      	add	x5, x0, #0x78
    7c7c:      	ldr	x5, [x5, #0x8]
    7c80:      	cmp	x1, x5
    7c84:      	b.ge	0x7e20 <_stogir.vector-lanes.validate+0x1f0>
    7c88:      	ldr	x5, [x0, #0x78]
    7c8c:      	add	x5, x3, x5
    7c90:      	ldr	w5, [x5]
    7c94:      	sxtw	x5, w5
    7c98:      	cmp	x5, #0x0
    7c9c:      	cset	w5, ge
    7ca0:      	ubfx	x5, x5, #0, #8
    7ca4:      	b	0x7e24 <_stogir.vector-lanes.validate+0x1f4>
    7ca8:      	cmp	x1, #0x0
    7cac:      	b.ge	0x7d04 <_stogir.vector-lanes.validate+0xd4>
    7cb0:      	add	x7, x0, #0x28
    7cb4:      	add	x9, x0, #0x50
    7cb8:      	ldr	x7, [x7, #0x8]
    7cbc:      	ldr	x9, [x9, #0x8]
    7cc0:      	cmp	x7, x9
    7cc4:      	b.ne	0x7cf4 <_stogir.vector-lanes.validate+0xc4>
    7cc8:      	cmp	x5, x7
    7ccc:      	b.gt	0x7e64 <_stogir.vector-lanes.validate+0x234>
    7cd0:      	lsl	x5, x6, #2
    7cd4:      	ldr	x7, [x0, #0x50]
    7cd8:      	add	x5, x5, x7
    7cdc:      	ldr	w5, [x5]
    7ce0:      	sxtw	x5, w5
    7ce4:      	cmp	x5, #0x0
    7ce8:      	cset	w5, gt
    7cec:      	ubfx	x5, x5, #0, #8
    7cf0:      	b	0x7e68 <_stogir.vector-lanes.validate+0x238>
    7cf4:      	movz	x5, #0x0, lsl #48
    7cf8:      	b	0x7d08 <_stogir.vector-lanes.validate+0xd8>
    7cfc:      	movz	x5, #0x0, lsl #48
    7d00:      	b	0x7d08 <_stogir.vector-lanes.validate+0xd8>
    7d04:      	movz	x5, #0x0, lsl #48
    7d08:      	cmp	x5, #0x0
    7d0c:      	b.eq	0x7d70 <_stogir.vector-lanes.validate+0x140>
    7d10:      	uxtb	w16, w4
    7d14:      	cmp	w16, wzr
    7d18:      	b.eq	0x7d40 <_stogir.vector-lanes.validate+0x110>
    7d1c:      	lsl	x4, x1, #4
    7d20:      	ldr	x5, [x0]
    7d24:      	add	x4, x4, x5
    7d28:      	ldr	x5, [x4]
    7d2c:      	ldr	x4, [x4, #0x8]
    7d30:      	fmov	d31, x4
    7d34:      	mov	x4, x5
    7d38:      	fmov	x5, d31
    7d3c:      	b	0x7d60 <_stogir.vector-lanes.validate+0x130>
    7d40:      	lsl	x4, x6, #4
    7d44:      	ldr	x5, [x0, #0x28]
    7d48:      	add	x4, x4, x5
    7d4c:      	ldr	x5, [x4]
    7d50:      	ldr	x4, [x4, #0x8]
    7d54:      	fmov	d31, x4
    7d58:      	mov	x4, x5
    7d5c:      	fmov	x5, d31
    7d60:      	mov	x6, x5
    7d64:      	mov	x5, x4
    7d68:      	mov	x4, #0x1                ; =1
    7d6c:      	b	0x7d7c <_stogir.vector-lanes.validate+0x14c>
    7d70:      	movz	x4, #0x0, lsl #48
    7d74:      	movz	x5, #0x0, lsl #48
    7d78:      	movz	x6, #0x0, lsl #48
    7d7c:      	lsr	w4, w4, #0
    7d80:      	lsr	x16, x4, #0
    7d84:      	cmp	x16, #0x1
    7d88:      	b.eq	0x7da4 <_stogir.vector-lanes.validate+0x174>
    7d8c:      	b.lo	0x7d94 <_stogir.vector-lanes.validate+0x164>
    7d90:      	b	0x7da8 <_stogir.vector-lanes.validate+0x178>
    7d94:      	cmp	x16, #0x0
    7d98:      	b.eq	0x7da0 <_stogir.vector-lanes.validate+0x170>
    7d9c:      	b	0x7da8 <_stogir.vector-lanes.validate+0x178>
    7da0:      	b	0x7dac <_stogir.vector-lanes.validate+0x17c>
    7da4:      	b	0x7dcc <_stogir.vector-lanes.validate+0x19c>
    7da8:      	b	0x7f48 <_stogir.vector-lanes.validate+0x318>
    7dac:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007dac:  ARM64_RELOC_PAGE21	l_stogir.410
    7db0:      	ldr	x16, [x16]
		0000000000007db0:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    7db4:      	orr	x0, x16, xzr
    7db8:      	mov	x19, x8
    7dbc:      	mov	x1, x0
    7dc0:      	mov	x0, #0x1                ; =1
    7dc4:      	mov	x2, #0x1f               ; =31
    7dc8:      	b	0x7e00 <_stogir.vector-lanes.validate+0x1d0>
    7dcc:      	add	x16, sp, #0x10
    7dd0:      	str	x5, [x16]
    7dd4:      	add	x16, sp, #0x10
    7dd8:      	str	x6, [x16, #0x8]
    7ddc:      	cmp	x1, #0x0
    7de0:      	b.gt	0x7e28 <_stogir.vector-lanes.validate+0x1f8>
    7de4:      	mov	x19, x8
    7de8:      	adrp	x16, 0x7000 <_stogir.conditional.validate+0xb0>
		0000000000007de8:  ARM64_RELOC_PAGE21	l_stogir.411
    7dec:      	ldr	x16, [x16]
		0000000000007dec:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7df0:      	orr	x0, x16, xzr
    7df4:      	mov	x1, x0
    7df8:      	mov	x0, #0x1                ; =1
    7dfc:      	mov	x2, #0x25               ; =37
    7e00:      	str	x0, [x19]
    7e04:      	str	x1, [x19, #0x8]
    7e08:      	str	x2, [x19, #0x10]
    7e0c:      	ldr	x19, [sp, #0x40]
    7e10:      	ldr	x29, [sp]
    7e14:      	ldr	x30, [sp, #0x8]
    7e18:      	add	sp, sp, #0x50
    7e1c:      	ret
    7e20:      	movz	x5, #0x0, lsl #48
    7e24:      	b	0x7d00 <_stogir.vector-lanes.validate+0xd0>
    7e28:      	uxtb	w5, w5
    7e2c:      	orr	x1, x5, xzr
    7e30:      	cmp	x1, #0x3d
    7e34:      	b.lt	0x7f50 <_stogir.vector-lanes.validate+0x320>
    7e38:      	cmp	x1, #0x3f
    7e3c:      	b.gt	0x7f58 <_stogir.vector-lanes.validate+0x328>
    7e40:      	cmp	x1, #0x3e
    7e44:      	cset	w4, eq
    7e48:      	ldr	x6, [x0, #0x78]
    7e4c:      	add	x3, x3, x6
    7e50:      	ldr	w3, [x3]
    7e54:      	cmp	x1, #0x3d
    7e58:      	b.ne	0x7ed8 <_stogir.vector-lanes.validate+0x2a8>
    7e5c:      	mov	x6, #0x2                ; =2
    7e60:      	b	0x7eec <_stogir.vector-lanes.validate+0x2bc>
    7e64:      	movz	x5, #0x0, lsl #48
    7e68:      	b	0x7cf8 <_stogir.vector-lanes.validate+0xc8>
    7e6c:      	movz	x4, #0x0, lsl #48
    7e70:      	lsr	w2, w2, #0
    7e74:      	lsr	w6, w6, #0
    7e78:      	lsr	w1, w1, #0
    7e7c:      	lsr	w5, w5, #0
    7e80:      	lsr	w4, w4, #0
    7e84:      	ubfx	x3, x3, #8, #8
    7e88:      	lsr	w3, w3, #0
    7e8c:      	mov	x19, x8
    7e90:      	add	x8, sp, #0x20
    7e94:      	fmov	s31, w1
    7e98:      	mov	w1, w5
    7e9c:      	fmov	w5, s31
    7ea0:      	fmov	s31, w2
    7ea4:      	mov	w2, w3
    7ea8:      	fmov	w3, s31
    7eac:      	fmov	s31, w4
    7eb0:      	mov	w4, w6
    7eb4:      	fmov	w6, s31
    7eb8:      	bl	0x7eb8 <_stogir.vector-lanes.validate+0x288>
		0000000000007eb8:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7ebc:      	add	x16, sp, #0x20
    7ec0:      	ldr	x0, [x16]
    7ec4:      	add	x16, sp, #0x20
    7ec8:      	ldr	x1, [x16, #0x8]
    7ecc:      	add	x16, sp, #0x20
    7ed0:      	ldr	x2, [x16, #0x10]
    7ed4:      	b	0x7e00 <_stogir.vector-lanes.validate+0x1d0>
    7ed8:      	uxtb	w16, w4
    7edc:      	cmp	w16, wzr
    7ee0:      	mov	x16, #0x3               ; =3
    7ee4:      	mov	x17, #0x1               ; =1
    7ee8:      	csel	x6, x16, x17, ne
    7eec:      	sxtw	x3, w3
    7ef0:      	lsr	w6, w6, #0
    7ef4:      	sxtw	x6, w6
    7ef8:      	cmp	x3, x6
    7efc:      	b.ne	0x7f60 <_stogir.vector-lanes.validate+0x330>
    7f00:      	add	x16, sp, #0x10
    7f04:      	ldr	w3, [x16]
    7f08:      	add	x16, sp, #0x10
    7f0c:      	ldr	w6, [x16, #0x4]
    7f10:      	cmp	x1, #0x3f
    7f14:      	b.ne	0x7f20 <_stogir.vector-lanes.validate+0x2f0>
    7f18:      	movz	x1, #0x0, lsl #48
    7f1c:      	b	0x7f2c <_stogir.vector-lanes.validate+0x2fc>
    7f20:      	add	x16, sp, #0x10
    7f24:      	ldr	w1, [x16, #0x8]
    7f28:      	sxtw	x1, w1
    7f2c:      	uxtb	w16, w4
    7f30:      	cmp	w16, wzr
    7f34:      	b.eq	0x7e6c <_stogir.vector-lanes.validate+0x23c>
    7f38:      	add	x16, sp, #0x10
    7f3c:      	ldr	w4, [x16, #0xc]
    7f40:      	sxtw	x4, w4
    7f44:      	b	0x7e70 <_stogir.vector-lanes.validate+0x240>
    7f48:      	brk	#0
    7f4c:      	b	0x7f48 <_stogir.vector-lanes.validate+0x318>
    7f50:      	mov	x19, x8
    7f54:      	b	0x7de8 <_stogir.vector-lanes.validate+0x1b8>
    7f58:      	mov	x19, x8
    7f5c:      	b	0x7de8 <_stogir.vector-lanes.validate+0x1b8>
    7f60:      	mov	x19, x8
    7f64:      	b	0x7de8 <_stogir.vector-lanes.validate+0x1b8>

0000000000007f68 <_stogir.vector-comparison.node?>:
    7f68:      	sxtw	x1, w1
    7f6c:      	cmp	x1, #0x0
    7f70:      	cset	w2, gt
    7f74:      	movz	x16, #0x0, lsl #48
    7f78:      	sub	x3, x16, x1
    7f7c:      	sub	x4, x3, #0x1
    7f80:      	uxtb	w16, w2
    7f84:      	cmp	w16, wzr
    7f88:      	b.eq	0x7fcc <_stogir.vector-comparison.node?+0x64>
    7f8c:      	ldr	x3, [x0, #0x8]
    7f90:      	cmp	x1, x3
    7f94:      	b.ge	0x8020 <_stogir.vector-comparison.node?+0xb8>
    7f98:      	add	x3, x0, #0x78
    7f9c:      	ldr	x3, [x3, #0x8]
    7fa0:      	cmp	x1, x3
    7fa4:      	b.ge	0x8108 <_stogir.vector-comparison.node?+0x1a0>
    7fa8:      	lsl	x3, x1, #2
    7fac:      	ldr	x5, [x0, #0x78]
    7fb0:      	add	x3, x3, x5
    7fb4:      	ldr	w3, [x3]
    7fb8:      	sxtw	x3, w3
    7fbc:      	cmp	x3, #0x0
    7fc0:      	cset	w3, ge
    7fc4:      	ubfx	x3, x3, #0, #8
    7fc8:      	b	0x810c <_stogir.vector-comparison.node?+0x1a4>
    7fcc:      	cmp	x1, #0x0
    7fd0:      	b.ge	0x8028 <_stogir.vector-comparison.node?+0xc0>
    7fd4:      	add	x5, x0, #0x28
    7fd8:      	add	x6, x0, #0x50
    7fdc:      	ldr	x5, [x5, #0x8]
    7fe0:      	ldr	x6, [x6, #0x8]
    7fe4:      	cmp	x5, x6
    7fe8:      	b.ne	0x8018 <_stogir.vector-comparison.node?+0xb0>
    7fec:      	cmp	x3, x5
    7ff0:      	b.gt	0x8110 <_stogir.vector-comparison.node?+0x1a8>
    7ff4:      	lsl	x3, x4, #2
    7ff8:      	ldr	x5, [x0, #0x50]
    7ffc:      	add	x3, x3, x5
    8000:      	ldr	w3, [x3]
    8004:      	sxtw	x3, w3
    8008:      	cmp	x3, #0x0
    800c:      	cset	w3, gt
    8010:      	ubfx	x3, x3, #0, #8
    8014:      	b	0x8114 <_stogir.vector-comparison.node?+0x1ac>
    8018:      	movz	x3, #0x0, lsl #48
    801c:      	b	0x802c <_stogir.vector-comparison.node?+0xc4>
    8020:      	movz	x3, #0x0, lsl #48
    8024:      	b	0x802c <_stogir.vector-comparison.node?+0xc4>
    8028:      	movz	x3, #0x0, lsl #48
    802c:      	cmp	x3, #0x0
    8030:      	b.eq	0x8070 <_stogir.vector-comparison.node?+0x108>
    8034:      	uxtb	w16, w2
    8038:      	cmp	w16, wzr
    803c:      	b.eq	0x8054 <_stogir.vector-comparison.node?+0xec>
    8040:      	lsl	x1, x1, #4
    8044:      	ldr	x0, [x0]
    8048:      	add	x0, x1, x0
    804c:      	ldr	x0, [x0]
    8050:      	b	0x8064 <_stogir.vector-comparison.node?+0xfc>
    8054:      	lsl	x1, x4, #4
    8058:      	ldr	x0, [x0, #0x28]
    805c:      	add	x0, x1, x0
    8060:      	ldr	x0, [x0]
    8064:      	mov	x1, x0
    8068:      	mov	x0, #0x1                ; =1
    806c:      	b	0x8078 <_stogir.vector-comparison.node?+0x110>
    8070:      	movz	x0, #0x0, lsl #48
    8074:      	movz	x1, #0x0, lsl #48
    8078:      	lsr	w0, w0, #0
    807c:      	lsr	x16, x0, #0
    8080:      	cmp	x16, #0x1
    8084:      	b.eq	0x80a0 <_stogir.vector-comparison.node?+0x138>
    8088:      	b.lo	0x8090 <_stogir.vector-comparison.node?+0x128>
    808c:      	b	0x80a4 <_stogir.vector-comparison.node?+0x13c>
    8090:      	cmp	x16, #0x0
    8094:      	b.eq	0x809c <_stogir.vector-comparison.node?+0x134>
    8098:      	b	0x80a4 <_stogir.vector-comparison.node?+0x13c>
    809c:      	b	0x80a8 <_stogir.vector-comparison.node?+0x140>
    80a0:      	b	0x80b8 <_stogir.vector-comparison.node?+0x150>
    80a4:      	b	0x8130 <_stogir.vector-comparison.node?+0x1c8>
    80a8:      	movz	x0, #0x0, lsl #48
    80ac:      	b	0x80b4 <_stogir.vector-comparison.node?+0x14c>
    80b0:      	movz	x0, #0x0, lsl #48
    80b4:      	ret
    80b8:      	uxtb	w0, w1
    80bc:      	cmp	x0, #0xe
    80c0:      	b.lt	0x80b0 <_stogir.vector-comparison.node?+0x148>
    80c4:      	cmp	x0, #0x19
    80c8:      	b.gt	0x80b0 <_stogir.vector-comparison.node?+0x148>
    80cc:      	lsr	w1, w1, #0
    80d0:      	ubfx	x0, x1, #8, #8
    80d4:      	cmp	x0, #0xf
    80d8:      	b.le	0x8118 <_stogir.vector-comparison.node?+0x1b0>
    80dc:      	cmp	x0, #0x80
    80e0:      	b.ge	0x8120 <_stogir.vector-comparison.node?+0x1b8>
    80e4:      	and	x0, x0, #0xf
    80e8:      	lsr	w0, w0, #0
    80ec:      	sxtw	x0, w0
    80f0:      	cmp	x0, #0x1
    80f4:      	b.lt	0x8128 <_stogir.vector-comparison.node?+0x1c0>
    80f8:      	cmp	x0, #0xd
    80fc:      	cset	w0, le
    8100:      	ubfx	x0, x0, #0, #8
    8104:      	b	0x812c <_stogir.vector-comparison.node?+0x1c4>
    8108:      	movz	x3, #0x0, lsl #48
    810c:      	b	0x8024 <_stogir.vector-comparison.node?+0xbc>
    8110:      	movz	x3, #0x0, lsl #48
    8114:      	b	0x801c <_stogir.vector-comparison.node?+0xb4>
    8118:      	movz	x0, #0x0, lsl #48
    811c:      	b	0x80b4 <_stogir.vector-comparison.node?+0x14c>
    8120:      	movz	x0, #0x0, lsl #48
    8124:      	b	0x811c <_stogir.vector-comparison.node?+0x1b4>
    8128:      	movz	x0, #0x0, lsl #48
    812c:      	b	0x8124 <_stogir.vector-comparison.node?+0x1bc>
    8130:      	brk	#0
    8134:      	b	0x8130 <_stogir.vector-comparison.node?+0x1c8>

0000000000008138 <_stogir.vector-comparison.validate>:
    8138:      	sub	sp, sp, #0x50
    813c:      	str	x29, [sp]
    8140:      	str	x30, [sp, #0x8]
    8144:      	mov	x29, sp
    8148:      	str	x19, [sp, #0x40]
    814c:      	sxtw	x1, w1
    8150:      	lsl	x3, x1, #2
    8154:      	cmp	x1, #0x0
    8158:      	cset	w4, gt
    815c:      	movz	x16, #0x0, lsl #48
    8160:      	sub	x5, x16, x1
    8164:      	sub	x6, x5, #0x1
    8168:      	uxtb	w16, w4
    816c:      	cmp	w16, wzr
    8170:      	b.eq	0x81b0 <_stogir.vector-comparison.validate+0x78>
    8174:      	ldr	x5, [x0, #0x8]
    8178:      	cmp	x1, x5
    817c:      	b.ge	0x8204 <_stogir.vector-comparison.validate+0xcc>
    8180:      	add	x5, x0, #0x78
    8184:      	ldr	x5, [x5, #0x8]
    8188:      	cmp	x1, x5
    818c:      	b.ge	0x8328 <_stogir.vector-comparison.validate+0x1f0>
    8190:      	ldr	x5, [x0, #0x78]
    8194:      	add	x5, x3, x5
    8198:      	ldr	w5, [x5]
    819c:      	sxtw	x5, w5
    81a0:      	cmp	x5, #0x0
    81a4:      	cset	w5, ge
    81a8:      	ubfx	x5, x5, #0, #8
    81ac:      	b	0x832c <_stogir.vector-comparison.validate+0x1f4>
    81b0:      	cmp	x1, #0x0
    81b4:      	b.ge	0x820c <_stogir.vector-comparison.validate+0xd4>
    81b8:      	add	x7, x0, #0x28
    81bc:      	add	x9, x0, #0x50
    81c0:      	ldr	x7, [x7, #0x8]
    81c4:      	ldr	x9, [x9, #0x8]
    81c8:      	cmp	x7, x9
    81cc:      	b.ne	0x81fc <_stogir.vector-comparison.validate+0xc4>
    81d0:      	cmp	x5, x7
    81d4:      	b.gt	0x837c <_stogir.vector-comparison.validate+0x244>
    81d8:      	lsl	x5, x6, #2
    81dc:      	ldr	x7, [x0, #0x50]
    81e0:      	add	x5, x5, x7
    81e4:      	ldr	w5, [x5]
    81e8:      	sxtw	x5, w5
    81ec:      	cmp	x5, #0x0
    81f0:      	cset	w5, gt
    81f4:      	ubfx	x5, x5, #0, #8
    81f8:      	b	0x8380 <_stogir.vector-comparison.validate+0x248>
    81fc:      	movz	x5, #0x0, lsl #48
    8200:      	b	0x8210 <_stogir.vector-comparison.validate+0xd8>
    8204:      	movz	x5, #0x0, lsl #48
    8208:      	b	0x8210 <_stogir.vector-comparison.validate+0xd8>
    820c:      	movz	x5, #0x0, lsl #48
    8210:      	lsl	x7, x1, #4
    8214:      	cmp	x5, #0x0
    8218:      	b.eq	0x8278 <_stogir.vector-comparison.validate+0x140>
    821c:      	uxtb	w16, w4
    8220:      	cmp	w16, wzr
    8224:      	b.eq	0x8248 <_stogir.vector-comparison.validate+0x110>
    8228:      	ldr	x4, [x0]
    822c:      	add	x4, x7, x4
    8230:      	ldr	x5, [x4]
    8234:      	ldr	x4, [x4, #0x8]
    8238:      	fmov	d31, x4
    823c:      	mov	x4, x5
    8240:      	fmov	x5, d31
    8244:      	b	0x8268 <_stogir.vector-comparison.validate+0x130>
    8248:      	lsl	x4, x6, #4
    824c:      	ldr	x5, [x0, #0x28]
    8250:      	add	x4, x4, x5
    8254:      	ldr	x5, [x4]
    8258:      	ldr	x4, [x4, #0x8]
    825c:      	fmov	d31, x4
    8260:      	mov	x4, x5
    8264:      	fmov	x5, d31
    8268:      	mov	x6, x5
    826c:      	mov	x5, x4
    8270:      	mov	x4, #0x1                ; =1
    8274:      	b	0x8284 <_stogir.vector-comparison.validate+0x14c>
    8278:      	movz	x4, #0x0, lsl #48
    827c:      	movz	x5, #0x0, lsl #48
    8280:      	movz	x6, #0x0, lsl #48
    8284:      	lsr	w4, w4, #0
    8288:      	lsr	x16, x4, #0
    828c:      	cmp	x16, #0x1
    8290:      	b.eq	0x82ac <_stogir.vector-comparison.validate+0x174>
    8294:      	b.lo	0x829c <_stogir.vector-comparison.validate+0x164>
    8298:      	b	0x82b0 <_stogir.vector-comparison.validate+0x178>
    829c:      	cmp	x16, #0x0
    82a0:      	b.eq	0x82a8 <_stogir.vector-comparison.validate+0x170>
    82a4:      	b	0x82b0 <_stogir.vector-comparison.validate+0x178>
    82a8:      	b	0x82b4 <_stogir.vector-comparison.validate+0x17c>
    82ac:      	b	0x82f0 <_stogir.vector-comparison.validate+0x1b8>
    82b0:      	b	0x8490 <_stogir.vector-comparison.validate+0x358>
    82b4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		00000000000082b4:  ARM64_RELOC_PAGE21	l_stogir.412
    82b8:      	ldr	x16, [x16]
		00000000000082b8:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    82bc:      	orr	x0, x16, xzr
    82c0:      	mov	x19, x8
    82c4:      	mov	x1, x0
    82c8:      	mov	x0, #0x1                ; =1
    82cc:      	mov	x2, #0x25               ; =37
    82d0:      	str	x0, [x19]
    82d4:      	str	x1, [x19, #0x8]
    82d8:      	str	x2, [x19, #0x10]
    82dc:      	ldr	x19, [sp, #0x40]
    82e0:      	ldr	x29, [sp]
    82e4:      	ldr	x30, [sp, #0x8]
    82e8:      	add	sp, sp, #0x50
    82ec:      	ret
    82f0:      	add	x16, sp, #0x10
    82f4:      	str	x5, [x16]
    82f8:      	add	x16, sp, #0x10
    82fc:      	str	x6, [x16, #0x8]
    8300:      	cmp	x1, #0x0
    8304:      	b.gt	0x8330 <_stogir.vector-comparison.validate+0x1f8>
    8308:      	mov	x19, x8
    830c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		000000000000830c:  ARM64_RELOC_PAGE21	l_stogir.413
    8310:      	ldr	x16, [x16]
		0000000000008310:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    8314:      	orr	x0, x16, xzr
    8318:      	mov	x1, x0
    831c:      	mov	x0, #0x1                ; =1
    8320:      	mov	x2, #0x2b               ; =43
    8324:      	b	0x82d0 <_stogir.vector-comparison.validate+0x198>
    8328:      	movz	x5, #0x0, lsl #48
    832c:      	b	0x8208 <_stogir.vector-comparison.validate+0xd0>
    8330:      	ldr	x4, [x0, #0x8]
    8334:      	cmp	x1, x4
    8338:      	b.ge	0x8384 <_stogir.vector-comparison.validate+0x24c>
    833c:      	add	x4, x0, #0x78
    8340:      	ldr	x4, [x4, #0x8]
    8344:      	cmp	x1, x4
    8348:      	b.ge	0x8384 <_stogir.vector-comparison.validate+0x24c>
    834c:      	ldr	x1, [x0, #0x78]
    8350:      	add	x1, x3, x1
    8354:      	ldr	w1, [x1]
    8358:      	sxtw	x1, w1
    835c:      	cmp	x1, #0x0
    8360:      	b.lt	0x8384 <_stogir.vector-comparison.validate+0x24c>
    8364:      	ldr	x1, [x0]
    8368:      	add	x1, x7, x1
    836c:      	ldr	x1, [x1]
    8370:      	mov	x4, x1
    8374:      	mov	x1, #0x1                ; =1
    8378:      	b	0x838c <_stogir.vector-comparison.validate+0x254>
    837c:      	movz	x5, #0x0, lsl #48
    8380:      	b	0x8200 <_stogir.vector-comparison.validate+0xc8>
    8384:      	movz	x1, #0x0, lsl #48
    8388:      	movz	x4, #0x0, lsl #48
    838c:      	lsr	w1, w1, #0
    8390:      	lsr	x16, x1, #0
    8394:      	cmp	x16, #0x1
    8398:      	b.eq	0x83b4 <_stogir.vector-comparison.validate+0x27c>
    839c:      	b.lo	0x83a4 <_stogir.vector-comparison.validate+0x26c>
    83a0:      	b	0x83b8 <_stogir.vector-comparison.validate+0x280>
    83a4:      	cmp	x16, #0x0
    83a8:      	b.eq	0x83b0 <_stogir.vector-comparison.validate+0x278>
    83ac:      	b	0x83b8 <_stogir.vector-comparison.validate+0x280>
    83b0:      	b	0x83bc <_stogir.vector-comparison.validate+0x284>
    83b4:      	b	0x83c4 <_stogir.vector-comparison.validate+0x28c>
    83b8:      	b	0x8498 <_stogir.vector-comparison.validate+0x360>
    83bc:      	mov	x19, x8
    83c0:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    83c4:      	uxtb	w1, w4
    83c8:      	cmp	x1, #0xe
    83cc:      	b.lt	0x84a0 <_stogir.vector-comparison.validate+0x368>
    83d0:      	cmp	x1, #0x19
    83d4:      	b.gt	0x84a8 <_stogir.vector-comparison.validate+0x370>
    83d8:      	lsr	w4, w4, #0
    83dc:      	ubfx	x1, x4, #8, #8
    83e0:      	cmp	x1, #0xf
    83e4:      	b.le	0x84b0 <_stogir.vector-comparison.validate+0x378>
    83e8:      	cmp	x1, #0x80
    83ec:      	b.ge	0x84b8 <_stogir.vector-comparison.validate+0x380>
    83f0:      	and	x1, x1, #0xf
    83f4:      	lsr	w1, w1, #0
    83f8:      	sxtw	x1, w1
    83fc:      	cmp	x1, #0x1
    8400:      	b.lt	0x84c0 <_stogir.vector-comparison.validate+0x388>
    8404:      	cmp	x1, #0xd
    8408:      	b.gt	0x84c8 <_stogir.vector-comparison.validate+0x390>
    840c:      	ldr	x1, [x0, #0x78]
    8410:      	add	x1, x3, x1
    8414:      	ldr	w1, [x1]
    8418:      	sxtw	x1, w1
    841c:      	cmp	x1, #0x2
    8420:      	b.ne	0x84d0 <_stogir.vector-comparison.validate+0x398>
    8424:      	lsr	w2, w2, #0
    8428:      	add	x16, sp, #0x10
    842c:      	ldr	w1, [x16]
    8430:      	uxtb	w3, w1
    8434:      	add	x16, sp, #0x10
    8438:      	ldr	w4, [x16, #0x4]
    843c:      	lsr	w3, w3, #0
    8440:      	ubfx	x1, x1, #8, #8
    8444:      	add	x16, sp, #0x10
    8448:      	ldr	w5, [x16, #0x8]
    844c:      	lsr	w4, w4, #0
    8450:      	lsr	w5, w5, #0
    8454:      	lsr	w1, w1, #0
    8458:      	mov	x19, x8
    845c:      	add	x8, sp, #0x20
    8460:      	fmov	s31, w1
    8464:      	mov	w1, w3
    8468:      	mov	w3, w2
    846c:      	fmov	w2, s31
    8470:      	bl	0x8470 <_stogir.vector-comparison.validate+0x338>
		0000000000008470:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    8474:      	add	x16, sp, #0x20
    8478:      	ldr	x0, [x16]
    847c:      	add	x16, sp, #0x20
    8480:      	ldr	x1, [x16, #0x8]
    8484:      	add	x16, sp, #0x20
    8488:      	ldr	x2, [x16, #0x10]
    848c:      	b	0x8324 <_stogir.vector-comparison.validate+0x1ec>
    8490:      	brk	#0
    8494:      	b	0x8490 <_stogir.vector-comparison.validate+0x358>
    8498:      	brk	#0
    849c:      	b	0x8498 <_stogir.vector-comparison.validate+0x360>
    84a0:      	mov	x19, x8
    84a4:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84a8:      	mov	x19, x8
    84ac:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84b0:      	mov	x19, x8
    84b4:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84b8:      	mov	x19, x8
    84bc:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84c0:      	mov	x19, x8
    84c4:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84c8:      	mov	x19, x8
    84cc:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>
    84d0:      	mov	x19, x8
    84d4:      	b	0x830c <_stogir.vector-comparison.validate+0x1d4>

00000000000084d8 <_stogir.vector-arithmetic.node?>:
    84d8:      	sxtw	x1, w1
    84dc:      	cmp	x1, #0x0
    84e0:      	cset	w2, gt
    84e4:      	movz	x16, #0x0, lsl #48
    84e8:      	sub	x3, x16, x1
    84ec:      	sub	x4, x3, #0x1
    84f0:      	uxtb	w16, w2
    84f4:      	cmp	w16, wzr
    84f8:      	b.eq	0x853c <_stogir.vector-arithmetic.node?+0x64>
    84fc:      	ldr	x3, [x0, #0x8]
    8500:      	cmp	x1, x3
    8504:      	b.ge	0x8590 <_stogir.vector-arithmetic.node?+0xb8>
    8508:      	add	x3, x0, #0x78
    850c:      	ldr	x3, [x3, #0x8]
    8510:      	cmp	x1, x3
    8514:      	b.ge	0x86c0 <_stogir.vector-arithmetic.node?+0x1e8>
    8518:      	lsl	x3, x1, #2
    851c:      	ldr	x5, [x0, #0x78]
    8520:      	add	x3, x3, x5
    8524:      	ldr	w3, [x3]
    8528:      	sxtw	x3, w3
    852c:      	cmp	x3, #0x0
    8530:      	cset	w3, ge
    8534:      	ubfx	x3, x3, #0, #8
    8538:      	b	0x86c4 <_stogir.vector-arithmetic.node?+0x1ec>
    853c:      	cmp	x1, #0x0
    8540:      	b.ge	0x8598 <_stogir.vector-arithmetic.node?+0xc0>
    8544:      	add	x5, x0, #0x28
    8548:      	add	x6, x0, #0x50
    854c:      	ldr	x5, [x5, #0x8]
    8550:      	ldr	x6, [x6, #0x8]
    8554:      	cmp	x5, x6
    8558:      	b.ne	0x8588 <_stogir.vector-arithmetic.node?+0xb0>
    855c:      	cmp	x3, x5
    8560:      	b.gt	0x86d0 <_stogir.vector-arithmetic.node?+0x1f8>
    8564:      	lsl	x3, x4, #2
    8568:      	ldr	x5, [x0, #0x50]
    856c:      	add	x3, x3, x5
    8570:      	ldr	w3, [x3]
    8574:      	sxtw	x3, w3
    8578:      	cmp	x3, #0x0
    857c:      	cset	w3, gt
    8580:      	ubfx	x3, x3, #0, #8
    8584:      	b	0x86d4 <_stogir.vector-arithmetic.node?+0x1fc>
    8588:      	movz	x3, #0x0, lsl #48
    858c:      	b	0x859c <_stogir.vector-arithmetic.node?+0xc4>
    8590:      	movz	x3, #0x0, lsl #48
    8594:      	b	0x859c <_stogir.vector-arithmetic.node?+0xc4>
    8598:      	movz	x3, #0x0, lsl #48
    859c:      	cmp	x3, #0x0
    85a0:      	b.eq	0x85e0 <_stogir.vector-arithmetic.node?+0x108>
    85a4:      	uxtb	w16, w2
    85a8:      	cmp	w16, wzr
    85ac:      	b.eq	0x85c4 <_stogir.vector-arithmetic.node?+0xec>
    85b0:      	lsl	x1, x1, #4
    85b4:      	ldr	x0, [x0]
    85b8:      	add	x0, x1, x0
    85bc:      	ldr	x0, [x0]
    85c0:      	b	0x85d4 <_stogir.vector-arithmetic.node?+0xfc>
    85c4:      	lsl	x1, x4, #4
    85c8:      	ldr	x0, [x0, #0x28]
    85cc:      	add	x0, x1, x0
    85d0:      	ldr	x0, [x0]
    85d4:      	mov	x1, x0
    85d8:      	mov	x0, #0x1                ; =1
    85dc:      	b	0x85e8 <_stogir.vector-arithmetic.node?+0x110>
    85e0:      	movz	x0, #0x0, lsl #48
    85e4:      	movz	x1, #0x0, lsl #48
    85e8:      	lsr	w0, w0, #0
    85ec:      	lsr	x16, x0, #0
    85f0:      	cmp	x16, #0x1
    85f4:      	b.eq	0x8610 <_stogir.vector-arithmetic.node?+0x138>
    85f8:      	b.lo	0x8600 <_stogir.vector-arithmetic.node?+0x128>
    85fc:      	b	0x8614 <_stogir.vector-arithmetic.node?+0x13c>
    8600:      	cmp	x16, #0x0
    8604:      	b.eq	0x860c <_stogir.vector-arithmetic.node?+0x134>
    8608:      	b	0x8614 <_stogir.vector-arithmetic.node?+0x13c>
    860c:      	b	0x8618 <_stogir.vector-arithmetic.node?+0x140>
    8610:      	b	0x8628 <_stogir.vector-arithmetic.node?+0x150>
    8614:      	b	0x86e0 <_stogir.vector-arithmetic.node?+0x208>
    8618:      	movz	x0, #0x0, lsl #48
    861c:      	b	0x8624 <_stogir.vector-arithmetic.node?+0x14c>
    8620:      	movz	x0, #0x0, lsl #48
    8624:      	ret
    8628:      	uxtb	w0, w1
    862c:      	cmp	x0, #0x1f
    8630:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8634:      	cmp	x0, #0x20
    8638:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    863c:      	cmp	x0, #0x2d
    8640:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8644:      	cmp	x0, #0x36
    8648:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    864c:      	cmp	x0, #0x37
    8650:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8654:      	cmp	x0, #0x38
    8658:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    865c:      	cmp	x0, #0x39
    8660:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8664:      	cmp	x0, #0x3a
    8668:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    866c:      	cmp	x0, #0x3b
    8670:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8674:      	cmp	x0, #0x31
    8678:      	b.lt	0x86e8 <_stogir.vector-arithmetic.node?+0x210>
    867c:      	cmp	x0, #0x35
    8680:      	b.gt	0x86e8 <_stogir.vector-arithmetic.node?+0x210>
    8684:      	lsr	w1, w1, #0
    8688:      	ubfx	x0, x1, #8, #8
    868c:      	cmp	x0, #0xf
    8690:      	b.le	0x8620 <_stogir.vector-arithmetic.node?+0x148>
    8694:      	cmp	x0, #0x80
    8698:      	b.ge	0x86c8 <_stogir.vector-arithmetic.node?+0x1f0>
    869c:      	and	x0, x0, #0xf
    86a0:      	lsr	w0, w0, #0
    86a4:      	sxtw	x0, w0
    86a8:      	cmp	x0, #0x1
    86ac:      	b.lt	0x86d8 <_stogir.vector-arithmetic.node?+0x200>
    86b0:      	cmp	x0, #0xd
    86b4:      	cset	w0, le
    86b8:      	ubfx	x0, x0, #0, #8
    86bc:      	b	0x86dc <_stogir.vector-arithmetic.node?+0x204>
    86c0:      	movz	x3, #0x0, lsl #48
    86c4:      	b	0x8594 <_stogir.vector-arithmetic.node?+0xbc>
    86c8:      	movz	x0, #0x0, lsl #48
    86cc:      	b	0x8624 <_stogir.vector-arithmetic.node?+0x14c>
    86d0:      	movz	x3, #0x0, lsl #48
    86d4:      	b	0x858c <_stogir.vector-arithmetic.node?+0xb4>
    86d8:      	movz	x0, #0x0, lsl #48
    86dc:      	b	0x86cc <_stogir.vector-arithmetic.node?+0x1f4>
    86e0:      	brk	#0
    86e4:      	b	0x86e0 <_stogir.vector-arithmetic.node?+0x208>
    86e8:      	cmp	x0, #0x1a
    86ec:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    86f0:      	cmp	x0, #0x1b
    86f4:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    86f8:      	cmp	x0, #0x1c
    86fc:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8700:      	cmp	x0, #0x1d
    8704:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8708:      	cmp	x0, #0x1e
    870c:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8710:      	cmp	x0, #0x2e
    8714:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8718:      	cmp	x0, #0x2f
    871c:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8720:      	cmp	x0, #0x30
    8724:      	b.eq	0x8684 <_stogir.vector-arithmetic.node?+0x1ac>
    8728:      	movz	x0, #0x0, lsl #48
    872c:      	b	0x8624 <_stogir.vector-arithmetic.node?+0x14c>

0000000000008730 <_stogir.vector-arithmetic.validate>:
    8730:      	sub	sp, sp, #0x60
    8734:      	str	x29, [sp]
    8738:      	str	x30, [sp, #0x8]
    873c:      	mov	x29, sp
    8740:      	str	x19, [sp, #0x40]
    8744:      	str	x20, [sp, #0x48]
    8748:      	str	x21, [sp, #0x50]
    874c:      	str	x22, [sp, #0x58]
    8750:      	sxtw	x2, w1
    8754:      	lsl	x19, x2, #2
    8758:      	cmp	x2, #0x0
    875c:      	cset	w3, gt
    8760:      	movz	x16, #0x0, lsl #48
    8764:      	sub	x4, x16, x2
    8768:      	sub	x5, x4, #0x1
    876c:      	uxtb	w16, w3
    8770:      	cmp	w16, wzr
    8774:      	b.eq	0x87b4 <_stogir.vector-arithmetic.validate+0x84>
    8778:      	ldr	x4, [x0, #0x8]
    877c:      	cmp	x2, x4
    8780:      	b.ge	0x8808 <_stogir.vector-arithmetic.validate+0xd8>
    8784:      	add	x4, x0, #0x78
    8788:      	ldr	x4, [x4, #0x8]
    878c:      	cmp	x2, x4
    8790:      	b.ge	0x8934 <_stogir.vector-arithmetic.validate+0x204>
    8794:      	ldr	x4, [x0, #0x78]
    8798:      	add	x4, x19, x4
    879c:      	ldr	w4, [x4]
    87a0:      	sxtw	x4, w4
    87a4:      	cmp	x4, #0x0
    87a8:      	cset	w4, ge
    87ac:      	ubfx	x4, x4, #0, #8
    87b0:      	b	0x8938 <_stogir.vector-arithmetic.validate+0x208>
    87b4:      	cmp	x2, #0x0
    87b8:      	b.ge	0x8810 <_stogir.vector-arithmetic.validate+0xe0>
    87bc:      	add	x6, x0, #0x28
    87c0:      	add	x7, x0, #0x50
    87c4:      	ldr	x6, [x6, #0x8]
    87c8:      	ldr	x7, [x7, #0x8]
    87cc:      	cmp	x6, x7
    87d0:      	b.ne	0x8800 <_stogir.vector-arithmetic.validate+0xd0>
    87d4:      	cmp	x4, x6
    87d8:      	b.gt	0x89d0 <_stogir.vector-arithmetic.validate+0x2a0>
    87dc:      	lsl	x4, x5, #2
    87e0:      	ldr	x6, [x0, #0x50]
    87e4:      	add	x4, x4, x6
    87e8:      	ldr	w4, [x4]
    87ec:      	sxtw	x4, w4
    87f0:      	cmp	x4, #0x0
    87f4:      	cset	w4, gt
    87f8:      	ubfx	x4, x4, #0, #8
    87fc:      	b	0x89d4 <_stogir.vector-arithmetic.validate+0x2a4>
    8800:      	movz	x4, #0x0, lsl #48
    8804:      	b	0x8814 <_stogir.vector-arithmetic.validate+0xe4>
    8808:      	movz	x4, #0x0, lsl #48
    880c:      	b	0x8814 <_stogir.vector-arithmetic.validate+0xe4>
    8810:      	movz	x4, #0x0, lsl #48
    8814:      	cmp	x4, #0x0
    8818:      	b.eq	0x8878 <_stogir.vector-arithmetic.validate+0x148>
    881c:      	uxtb	w16, w3
    8820:      	cmp	w16, wzr
    8824:      	b.eq	0x884c <_stogir.vector-arithmetic.validate+0x11c>
    8828:      	lsl	x3, x2, #4
    882c:      	ldr	x4, [x0]
    8830:      	add	x3, x3, x4
    8834:      	ldr	x4, [x3]
    8838:      	ldr	x3, [x3, #0x8]
    883c:      	fmov	d31, x3
    8840:      	mov	x3, x4
    8844:      	fmov	x4, d31
    8848:      	b	0x886c <_stogir.vector-arithmetic.validate+0x13c>
    884c:      	lsl	x3, x5, #4
    8850:      	ldr	x4, [x0, #0x28]
    8854:      	add	x3, x3, x4
    8858:      	ldr	x4, [x3]
    885c:      	ldr	x3, [x3, #0x8]
    8860:      	fmov	d31, x3
    8864:      	mov	x3, x4
    8868:      	fmov	x4, d31
    886c:      	mov	x20, x3
    8870:      	mov	x3, #0x1                ; =1
    8874:      	b	0x8884 <_stogir.vector-arithmetic.validate+0x154>
    8878:      	movz	x3, #0x0, lsl #48
    887c:      	movz	x20, #0x0, lsl #48
    8880:      	movz	x4, #0x0, lsl #48
    8884:      	lsr	w3, w3, #0
    8888:      	lsr	x16, x3, #0
    888c:      	cmp	x16, #0x1
    8890:      	b.eq	0x88ac <_stogir.vector-arithmetic.validate+0x17c>
    8894:      	b.lo	0x889c <_stogir.vector-arithmetic.validate+0x16c>
    8898:      	b	0x88b0 <_stogir.vector-arithmetic.validate+0x180>
    889c:      	cmp	x16, #0x0
    88a0:      	b.eq	0x88a8 <_stogir.vector-arithmetic.validate+0x178>
    88a4:      	b	0x88b0 <_stogir.vector-arithmetic.validate+0x180>
    88a8:      	b	0x88b4 <_stogir.vector-arithmetic.validate+0x184>
    88ac:      	b	0x88d4 <_stogir.vector-arithmetic.validate+0x1a4>
    88b0:      	b	0x8a84 <_stogir.vector-arithmetic.validate+0x354>
    88b4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		00000000000088b4:  ARM64_RELOC_PAGE21	l_stogir.414
    88b8:      	ldr	x16, [x16]
		00000000000088b8:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    88bc:      	orr	x0, x16, xzr
    88c0:      	mov	x21, x8
    88c4:      	mov	x1, x0
    88c8:      	mov	x0, #0x1                ; =1
    88cc:      	mov	x2, #0x25               ; =37
    88d0:      	b	0x8908 <_stogir.vector-arithmetic.validate+0x1d8>
    88d4:      	add	x16, sp, #0x10
    88d8:      	str	x20, [x16]
    88dc:      	add	x16, sp, #0x10
    88e0:      	str	x4, [x16, #0x8]
    88e4:      	cmp	x2, #0x0
    88e8:      	b.gt	0x893c <_stogir.vector-arithmetic.validate+0x20c>
    88ec:      	mov	x21, x8
    88f0:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		00000000000088f0:  ARM64_RELOC_PAGE21	l_stogir.415
    88f4:      	ldr	x16, [x16]
		00000000000088f4:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    88f8:      	orr	x0, x16, xzr
    88fc:      	mov	x1, x0
    8900:      	mov	x0, #0x1                ; =1
    8904:      	mov	x2, #0x2b               ; =43
    8908:      	str	x0, [x21]
    890c:      	str	x1, [x21, #0x8]
    8910:      	str	x2, [x21, #0x10]
    8914:      	ldr	x19, [sp, #0x40]
    8918:      	ldr	x20, [sp, #0x48]
    891c:      	ldr	x21, [sp, #0x50]
    8920:      	ldr	x22, [sp, #0x58]
    8924:      	ldr	x29, [sp]
    8928:      	ldr	x30, [sp, #0x8]
    892c:      	add	sp, sp, #0x60
    8930:      	ret
    8934:      	movz	x4, #0x0, lsl #48
    8938:      	b	0x880c <_stogir.vector-arithmetic.validate+0xdc>
    893c:      	lsr	w1, w1, #0
    8940:      	mov	x21, x8
    8944:      	mov	x22, x0
    8948:      	bl	0x8948 <_stogir.vector-arithmetic.validate+0x218>
		0000000000008948:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    894c:      	cmp	x0, #0x0
    8950:      	b.eq	0x88f0 <_stogir.vector-arithmetic.validate+0x1c0>
    8954:      	uxtb	w20, w20
    8958:      	orr	x0, x20, xzr
    895c:      	ldr	x1, [x22, #0x78]
    8960:      	cmp	x0, #0x1d
    8964:      	cset	w2, eq
    8968:      	cmp	x0, #0x1e
    896c:      	cset	w3, eq
    8970:      	add	x1, x19, x1
    8974:      	ldr	w1, [x1]
    8978:      	cmp	x0, #0x1f
    897c:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    8980:      	cmp	x0, #0x20
    8984:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    8988:      	cmp	x0, #0x2d
    898c:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    8990:      	cmp	x0, #0x36
    8994:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    8998:      	cmp	x0, #0x37
    899c:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    89a0:      	cmp	x0, #0x38
    89a4:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    89a8:      	cmp	x0, #0x39
    89ac:      	b.eq	0x8a34 <_stogir.vector-arithmetic.validate+0x304>
    89b0:      	uxtb	w16, w2
    89b4:      	cmp	w16, wzr
    89b8:      	b.ne	0x8a8c <_stogir.vector-arithmetic.validate+0x35c>
    89bc:      	uxtb	w16, w3
    89c0:      	cmp	w16, wzr
    89c4:      	b.ne	0x8a8c <_stogir.vector-arithmetic.validate+0x35c>
    89c8:      	mov	x0, #0x2                ; =2
    89cc:      	b	0x8a90 <_stogir.vector-arithmetic.validate+0x360>
    89d0:      	movz	x4, #0x0, lsl #48
    89d4:      	b	0x8804 <_stogir.vector-arithmetic.validate+0xd4>
    89d8:      	add	x16, sp, #0x10
    89dc:      	ldr	w2, [x16, #0xc]
    89e0:      	sxtw	x2, w2
    89e4:      	lsr	w1, w1, #0
    89e8:      	lsr	w4, w4, #0
    89ec:      	lsr	w20, w20, #0
    89f0:      	lsr	w2, w2, #0
    89f4:      	ubfx	x0, x0, #8, #8
    89f8:      	lsr	w0, w0, #0
    89fc:      	add	x8, sp, #0x20
    8a00:      	mov	w3, w1
    8a04:      	mov	w1, w20
    8a08:      	mov	w5, w2
    8a0c:      	mov	w2, w0
    8a10:      	mov	x0, x22
    8a14:      	bl	0x8a14 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008a14:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8a18:      	add	x16, sp, #0x20
    8a1c:      	ldr	x0, [x16]
    8a20:      	add	x16, sp, #0x20
    8a24:      	ldr	x1, [x16, #0x8]
    8a28:      	add	x16, sp, #0x20
    8a2c:      	ldr	x2, [x16, #0x10]
    8a30:      	b	0x8908 <_stogir.vector-arithmetic.validate+0x1d8>
    8a34:      	mov	x0, #0x1                ; =1
    8a38:      	sxtw	x1, w1
    8a3c:      	lsr	w0, w0, #0
    8a40:      	sxtw	x0, w0
    8a44:      	cmp	x1, x0
    8a48:      	b.ne	0x88f0 <_stogir.vector-arithmetic.validate+0x1c0>
    8a4c:      	add	x16, sp, #0x10
    8a50:      	ldr	w0, [x16]
    8a54:      	add	x16, sp, #0x10
    8a58:      	ldr	w1, [x16, #0x4]
    8a5c:      	add	x16, sp, #0x10
    8a60:      	ldr	w4, [x16, #0x8]
    8a64:      	uxtb	w16, w2
    8a68:      	cmp	w16, wzr
    8a6c:      	b.ne	0x89d8 <_stogir.vector-arithmetic.validate+0x2a8>
    8a70:      	uxtb	w16, w3
    8a74:      	cmp	w16, wzr
    8a78:      	b.ne	0x89d8 <_stogir.vector-arithmetic.validate+0x2a8>
    8a7c:      	movz	x2, #0x0, lsl #48
    8a80:      	b	0x89e4 <_stogir.vector-arithmetic.validate+0x2b4>
    8a84:      	brk	#0
    8a88:      	b	0x8a84 <_stogir.vector-arithmetic.validate+0x354>
    8a8c:      	mov	x0, #0x3                ; =3
    8a90:      	b	0x8a38 <_stogir.vector-arithmetic.validate+0x308>

0000000000008a94 <_stogir.vector.memory-inputs>:
    8a94:      	sub	sp, sp, #0x40
    8a98:      	str	x29, [sp]
    8a9c:      	str	x30, [sp, #0x8]
    8aa0:      	mov	x29, sp
    8aa4:      	str	x19, [sp, #0x10]
    8aa8:      	str	x20, [sp, #0x18]
    8aac:      	str	x21, [sp, #0x20]
    8ab0:      	str	x22, [sp, #0x28]
    8ab4:      	str	x23, [sp, #0x30]
    8ab8:      	str	x24, [sp, #0x38]
    8abc:      	sxtw	x5, w1
    8ac0:      	cmp	x5, #0xf
    8ac4:      	b.le	0x8f80 <_stogir.vector.memory-inputs+0x4ec>
    8ac8:      	cmp	x5, #0x80
    8acc:      	b.ge	0x8f88 <_stogir.vector.memory-inputs+0x4f4>
    8ad0:      	and	x6, x5, #0xf
    8ad4:      	lsr	w6, w6, #0
    8ad8:      	sxtw	x6, w6
    8adc:      	cmp	x6, #0x1
    8ae0:      	b.lt	0x8f90 <_stogir.vector.memory-inputs+0x4fc>
    8ae4:      	and	x5, x5, #0xf
    8ae8:      	lsr	w5, w5, #0
    8aec:      	sxtw	x5, w5
    8af0:      	cmp	x5, #0xd
    8af4:      	b.gt	0x8f98 <_stogir.vector.memory-inputs+0x504>
    8af8:      	lsr	w1, w1, #0
    8afc:      	lsr	w2, w2, #0
    8b00:      	mov	x19, x8
    8b04:      	mov	x20, x0
    8b08:      	mov	w0, w1
    8b0c:      	mov	w21, w1
    8b10:      	mov	w1, w2
    8b14:      	mov	w22, w2
    8b18:      	mov	w23, w3
    8b1c:      	mov	w24, w4
    8b20:      	bl	0x8b20 <_stogir.vector.memory-inputs+0x8c>
		0000000000008b20:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8b24:      	lsr	w0, w0, #0
    8b28:      	sxtw	x0, w0
    8b2c:      	cmp	x0, #0x0
    8b30:      	b.le	0x8b98 <_stogir.vector.memory-inputs+0x104>
    8b34:      	sxtw	x23, w23
    8b38:      	cmp	x23, #0x0
    8b3c:      	cset	w0, gt
    8b40:      	movz	x16, #0x0, lsl #48
    8b44:      	sub	x1, x16, x23
    8b48:      	sub	x2, x1, #0x1
    8b4c:      	uxtb	w16, w0
    8b50:      	cmp	w16, wzr
    8b54:      	b.eq	0x8c88 <_stogir.vector.memory-inputs+0x1f4>
    8b58:      	ldr	x1, [x20, #0x8]
    8b5c:      	cmp	x23, x1
    8b60:      	b.ge	0x8c80 <_stogir.vector.memory-inputs+0x1ec>
    8b64:      	add	x1, x20, #0x78
    8b68:      	ldr	x1, [x1, #0x8]
    8b6c:      	cmp	x23, x1
    8b70:      	b.ge	0x8d30 <_stogir.vector.memory-inputs+0x29c>
    8b74:      	lsl	x1, x23, #2
    8b78:      	ldr	x3, [x20, #0x78]
    8b7c:      	add	x1, x1, x3
    8b80:      	ldr	w1, [x1]
    8b84:      	sxtw	x1, w1
    8b88:      	cmp	x1, #0x0
    8b8c:      	cset	w1, ge
    8b90:      	ubfx	x1, x1, #0, #8
    8b94:      	b	0x8d34 <_stogir.vector.memory-inputs+0x2a0>
    8b98:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008b98:  ARM64_RELOC_PAGE21	l_stogir.416
    8b9c:      	ldr	x16, [x16]
		0000000000008b9c:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    8ba0:      	orr	x0, x16, xzr
    8ba4:      	mov	x1, x0
    8ba8:      	mov	x0, #0x1                ; =1
    8bac:      	mov	x2, #0x32               ; =50
    8bb0:      	str	x0, [x19]
    8bb4:      	str	x1, [x19, #0x8]
    8bb8:      	str	x2, [x19, #0x10]
    8bbc:      	ldr	x19, [sp, #0x10]
    8bc0:      	ldr	x20, [sp, #0x18]
    8bc4:      	ldr	x21, [sp, #0x20]
    8bc8:      	ldr	x22, [sp, #0x28]
    8bcc:      	ldr	x23, [sp, #0x30]
    8bd0:      	ldr	x24, [sp, #0x38]
    8bd4:      	ldr	x29, [sp]
    8bd8:      	ldr	x30, [sp, #0x8]
    8bdc:      	add	sp, sp, #0x40
    8be0:      	ret
    8be4:      	movz	x0, #0x0, lsl #48
    8be8:      	movz	x1, #0x0, lsl #48
    8bec:      	lsr	w0, w0, #0
    8bf0:      	lsr	x16, x0, #0
    8bf4:      	cmp	x16, #0x1
    8bf8:      	b.eq	0x8c14 <_stogir.vector.memory-inputs+0x180>
    8bfc:      	b.lo	0x8c04 <_stogir.vector.memory-inputs+0x170>
    8c00:      	b	0x8c18 <_stogir.vector.memory-inputs+0x184>
    8c04:      	cmp	x16, #0x0
    8c08:      	b.eq	0x8c10 <_stogir.vector.memory-inputs+0x17c>
    8c0c:      	b	0x8c18 <_stogir.vector.memory-inputs+0x184>
    8c10:      	b	0x8c1c <_stogir.vector.memory-inputs+0x188>
    8c14:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x240>
    8c18:      	b	0x8f68 <_stogir.vector.memory-inputs+0x4d4>
    8c1c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008c1c:  ARM64_RELOC_PAGE21	l_stogir.417
    8c20:      	ldr	x16, [x16]
		0000000000008c20:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8c24:      	orr	x0, x16, xzr
    8c28:      	mov	x1, x0
    8c2c:      	mov	x0, #0x1                ; =1
    8c30:      	mov	x2, #0x1d               ; =29
    8c34:      	b	0x8bb0 <_stogir.vector.memory-inputs+0x11c>
    8c38:      	lsl	x0, x2, #4
    8c3c:      	ldr	x1, [x20, #0x28]
    8c40:      	add	x0, x0, x1
    8c44:      	ldr	x0, [x0]
    8c48:      	mov	x1, x0
    8c4c:      	mov	x0, #0x1                ; =1
    8c50:      	b	0x8bec <_stogir.vector.memory-inputs+0x158>
    8c54:      	movz	x1, #0x0, lsl #48
    8c58:      	cmp	x1, #0x0
    8c5c:      	b.eq	0x8be4 <_stogir.vector.memory-inputs+0x150>
    8c60:      	uxtb	w16, w0
    8c64:      	cmp	w16, wzr
    8c68:      	b.eq	0x8c38 <_stogir.vector.memory-inputs+0x1a4>
    8c6c:      	lsl	x0, x23, #4
    8c70:      	ldr	x1, [x20]
    8c74:      	add	x0, x0, x1
    8c78:      	ldr	x0, [x0]
    8c7c:      	b	0x8c48 <_stogir.vector.memory-inputs+0x1b4>
    8c80:      	movz	x1, #0x0, lsl #48
    8c84:      	b	0x8c58 <_stogir.vector.memory-inputs+0x1c4>
    8c88:      	cmp	x23, #0x0
    8c8c:      	b.ge	0x8c54 <_stogir.vector.memory-inputs+0x1c0>
    8c90:      	add	x3, x20, #0x28
    8c94:      	add	x4, x20, #0x50
    8c98:      	ldr	x3, [x3, #0x8]
    8c9c:      	ldr	x4, [x4, #0x8]
    8ca0:      	cmp	x3, x4
    8ca4:      	b.ne	0x8d28 <_stogir.vector.memory-inputs+0x294>
    8ca8:      	cmp	x1, x3
    8cac:      	b.gt	0x8d38 <_stogir.vector.memory-inputs+0x2a4>
    8cb0:      	lsl	x1, x2, #2
    8cb4:      	ldr	x3, [x20, #0x50]
    8cb8:      	add	x1, x1, x3
    8cbc:      	ldr	w1, [x1]
    8cc0:      	sxtw	x1, w1
    8cc4:      	cmp	x1, #0x0
    8cc8:      	cset	w1, gt
    8ccc:      	ubfx	x1, x1, #0, #8
    8cd0:      	b	0x8d3c <_stogir.vector.memory-inputs+0x2a8>
    8cd4:      	cmp	x23, #0x0
    8cd8:      	b.le	0x8d0c <_stogir.vector.memory-inputs+0x278>
    8cdc:      	uxtb	w1, w1
    8ce0:      	cmp	x1, #0x83
    8ce4:      	cset	w0, lt
    8ce8:      	uxtb	w16, w0
    8cec:      	cmp	w16, wzr
    8cf0:      	b.eq	0x8d40 <_stogir.vector.memory-inputs+0x2ac>
    8cf4:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008cf4:  ARM64_RELOC_PAGE21	l_stogir.418
    8cf8:      	ldr	x16, [x16]
		0000000000008cf8:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8cfc:      	orr	x2, x16, xzr
    8d00:      	add	x2, x1, x2
    8d04:      	ldrb	w2, [x2]
    8d08:      	b	0x8d44 <_stogir.vector.memory-inputs+0x2b0>
    8d0c:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008d0c:  ARM64_RELOC_PAGE21	l_stogir.419
    8d10:      	ldr	x16, [x16]
		0000000000008d10:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8d14:      	orr	x0, x16, xzr
    8d18:      	mov	x1, x0
    8d1c:      	mov	x0, #0x1                ; =1
    8d20:      	mov	x2, #0x2c               ; =44
    8d24:      	b	0x8c34 <_stogir.vector.memory-inputs+0x1a0>
    8d28:      	movz	x1, #0x0, lsl #48
    8d2c:      	b	0x8c58 <_stogir.vector.memory-inputs+0x1c4>
    8d30:      	movz	x1, #0x0, lsl #48
    8d34:      	b	0x8c84 <_stogir.vector.memory-inputs+0x1f0>
    8d38:      	movz	x1, #0x0, lsl #48
    8d3c:      	b	0x8d2c <_stogir.vector.memory-inputs+0x298>
    8d40:      	movz	x2, #0x0, lsl #48
    8d44:      	uxtb	w2, w2
    8d48:      	and	x2, x2, #0x1
    8d4c:      	uxtb	w2, w2
    8d50:      	cmp	x2, #0x0
    8d54:      	b.eq	0x8d0c <_stogir.vector.memory-inputs+0x278>
    8d58:      	uxtb	w16, w0
    8d5c:      	cmp	w16, wzr
    8d60:      	b.eq	0x8d7c <_stogir.vector.memory-inputs+0x2e8>
    8d64:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008d64:  ARM64_RELOC_PAGE21	l_stogir.418
    8d68:      	ldr	x16, [x16]
		0000000000008d68:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8d6c:      	orr	x0, x16, xzr
    8d70:      	add	x0, x1, x0
    8d74:      	ldrb	w0, [x0]
    8d78:      	b	0x8d80 <_stogir.vector.memory-inputs+0x2ec>
    8d7c:      	movz	x0, #0x0, lsl #48
    8d80:      	uxtb	w0, w0
    8d84:      	and	x0, x0, #0x4
    8d88:      	uxtb	w0, w0
    8d8c:      	cmp	x0, #0x0
    8d90:      	b.ne	0x8d0c <_stogir.vector.memory-inputs+0x278>
    8d94:      	sxtw	x24, w24
    8d98:      	cmp	x24, #0x0
    8d9c:      	cset	w0, gt
    8da0:      	movz	x16, #0x0, lsl #48
    8da4:      	sub	x1, x16, x24
    8da8:      	sub	x2, x1, #0x1
    8dac:      	uxtb	w16, w0
    8db0:      	cmp	w16, wzr
    8db4:      	b.eq	0x8e14 <_stogir.vector.memory-inputs+0x380>
    8db8:      	ldr	x1, [x20, #0x8]
    8dbc:      	cmp	x24, x1
    8dc0:      	b.ge	0x8e60 <_stogir.vector.memory-inputs+0x3cc>
    8dc4:      	add	x1, x20, #0x78
    8dc8:      	ldr	x1, [x1, #0x8]
    8dcc:      	cmp	x24, x1
    8dd0:      	b.ge	0x8f60 <_stogir.vector.memory-inputs+0x4cc>
    8dd4:      	lsl	x1, x24, #2
    8dd8:      	ldr	x3, [x20, #0x78]
    8ddc:      	add	x1, x1, x3
    8de0:      	ldr	w1, [x1]
    8de4:      	sxtw	x1, w1
    8de8:      	cmp	x1, #0x0
    8dec:      	cset	w1, ge
    8df0:      	ubfx	x1, x1, #0, #8
    8df4:      	b	0x8f64 <_stogir.vector.memory-inputs+0x4d0>
    8df8:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008df8:  ARM64_RELOC_PAGE21	l_stogir.420
    8dfc:      	ldr	x16, [x16]
		0000000000008dfc:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8e00:      	orr	x0, x16, xzr
    8e04:      	mov	x1, x0
    8e08:      	mov	x0, #0x1                ; =1
    8e0c:      	mov	x2, #0x2b               ; =43
    8e10:      	b	0x8d24 <_stogir.vector.memory-inputs+0x290>
    8e14:      	cmp	x24, #0x0
    8e18:      	b.ge	0x8e68 <_stogir.vector.memory-inputs+0x3d4>
    8e1c:      	add	x3, x20, #0x28
    8e20:      	add	x4, x20, #0x50
    8e24:      	ldr	x3, [x3, #0x8]
    8e28:      	ldr	x4, [x4, #0x8]
    8e2c:      	cmp	x3, x4
    8e30:      	b.ne	0x8f58 <_stogir.vector.memory-inputs+0x4c4>
    8e34:      	cmp	x1, x3
    8e38:      	b.gt	0x8f70 <_stogir.vector.memory-inputs+0x4dc>
    8e3c:      	lsl	x1, x2, #2
    8e40:      	ldr	x3, [x20, #0x50]
    8e44:      	add	x1, x1, x3
    8e48:      	ldr	w1, [x1]
    8e4c:      	sxtw	x1, w1
    8e50:      	cmp	x1, #0x0
    8e54:      	cset	w1, gt
    8e58:      	ubfx	x1, x1, #0, #8
    8e5c:      	b	0x8f74 <_stogir.vector.memory-inputs+0x4e0>
    8e60:      	movz	x1, #0x0, lsl #48
    8e64:      	b	0x8e6c <_stogir.vector.memory-inputs+0x3d8>
    8e68:      	movz	x1, #0x0, lsl #48
    8e6c:      	cmp	x1, #0x0
    8e70:      	b.eq	0x8eb0 <_stogir.vector.memory-inputs+0x41c>
    8e74:      	uxtb	w16, w0
    8e78:      	cmp	w16, wzr
    8e7c:      	b.eq	0x8e94 <_stogir.vector.memory-inputs+0x400>
    8e80:      	lsl	x0, x24, #4
    8e84:      	ldr	x1, [x20]
    8e88:      	add	x0, x0, x1
    8e8c:      	ldr	x0, [x0]
    8e90:      	b	0x8ea4 <_stogir.vector.memory-inputs+0x410>
    8e94:      	lsl	x0, x2, #4
    8e98:      	ldr	x1, [x20, #0x28]
    8e9c:      	add	x0, x0, x1
    8ea0:      	ldr	x0, [x0]
    8ea4:      	mov	x1, x0
    8ea8:      	mov	x0, #0x1                ; =1
    8eac:      	b	0x8eb8 <_stogir.vector.memory-inputs+0x424>
    8eb0:      	movz	x0, #0x0, lsl #48
    8eb4:      	movz	x1, #0x0, lsl #48
    8eb8:      	lsr	w0, w0, #0
    8ebc:      	lsr	x16, x0, #0
    8ec0:      	cmp	x16, #0x1
    8ec4:      	b.eq	0x8ee0 <_stogir.vector.memory-inputs+0x44c>
    8ec8:      	b.lo	0x8ed0 <_stogir.vector.memory-inputs+0x43c>
    8ecc:      	b	0x8ee4 <_stogir.vector.memory-inputs+0x450>
    8ed0:      	cmp	x16, #0x0
    8ed4:      	b.eq	0x8edc <_stogir.vector.memory-inputs+0x448>
    8ed8:      	b	0x8ee4 <_stogir.vector.memory-inputs+0x450>
    8edc:      	b	0x8ee8 <_stogir.vector.memory-inputs+0x454>
    8ee0:      	b	0x8f04 <_stogir.vector.memory-inputs+0x470>
    8ee4:      	b	0x8f78 <_stogir.vector.memory-inputs+0x4e4>
    8ee8:      	adrp	x16, 0x8000 <_stogir.vector-comparison.node?+0x98>
		0000000000008ee8:  ARM64_RELOC_PAGE21	l_stogir.421
    8eec:      	ldr	x16, [x16]
		0000000000008eec:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    8ef0:      	orr	x0, x16, xzr
    8ef4:      	mov	x1, x0
    8ef8:      	mov	x0, #0x1                ; =1
    8efc:      	mov	x2, #0x1d               ; =29
    8f00:      	b	0x8e10 <_stogir.vector.memory-inputs+0x37c>
    8f04:      	lsr	w0, w1, #0
    8f08:      	ubfx	x0, x0, #8, #8
    8f0c:      	cmp	x0, #0x6
    8f10:      	b.ne	0x8df8 <_stogir.vector.memory-inputs+0x364>
    8f14:      	uxtb	w1, w1
    8f18:      	cmp	x1, #0x48
    8f1c:      	b.eq	0x8df8 <_stogir.vector.memory-inputs+0x364>
    8f20:      	cmp	x1, #0x46
    8f24:      	b.eq	0x8df8 <_stogir.vector.memory-inputs+0x364>
    8f28:      	lsr	w21, w21, #0
    8f2c:      	lsr	w22, w22, #0
    8f30:      	mov	w0, w21
    8f34:      	mov	w1, w22
    8f38:      	bl	0x8f38 <_stogir.vector.memory-inputs+0x4a4>
		0000000000008f38:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8f3c:      	lsr	w0, w0, #0
    8f40:      	sxtw	x0, w0
    8f44:      	and	x0, x0, #0xffffffff
    8f48:      	mov	x1, x0
    8f4c:      	movz	x0, #0x0, lsl #48
    8f50:      	movz	x2, #0x0, lsl #48
    8f54:      	b	0x8e10 <_stogir.vector.memory-inputs+0x37c>
    8f58:      	movz	x1, #0x0, lsl #48
    8f5c:      	b	0x8e6c <_stogir.vector.memory-inputs+0x3d8>
    8f60:      	movz	x1, #0x0, lsl #48
    8f64:      	b	0x8e64 <_stogir.vector.memory-inputs+0x3d0>
    8f68:      	brk	#0
    8f6c:      	b	0x8f68 <_stogir.vector.memory-inputs+0x4d4>
    8f70:      	movz	x1, #0x0, lsl #48
    8f74:      	b	0x8f5c <_stogir.vector.memory-inputs+0x4c8>
    8f78:      	brk	#0
    8f7c:      	b	0x8f78 <_stogir.vector.memory-inputs+0x4e4>
    8f80:      	mov	x19, x8
    8f84:      	b	0x8b98 <_stogir.vector.memory-inputs+0x104>
    8f88:      	mov	x19, x8
    8f8c:      	b	0x8b98 <_stogir.vector.memory-inputs+0x104>
    8f90:      	mov	x19, x8
    8f94:      	b	0x8b98 <_stogir.vector.memory-inputs+0x104>
    8f98:      	mov	x19, x8
    8f9c:      	b	0x8b98 <_stogir.vector.memory-inputs+0x104>

0000000000008fa0 <_stogir.vector.store-inputs>:
    8fa0:      	sub	sp, sp, #0x40
    8fa4:      	str	x29, [sp]
    8fa8:      	str	x30, [sp, #0x8]
    8fac:      	mov	x29, sp
    8fb0:      	str	x19, [sp, #0x30]
    8fb4:      	sxtw	x4, w4
    8fb8:      	cmp	x4, #0x0
    8fbc:      	cset	w5, gt
    8fc0:      	movz	x16, #0x0, lsl #48
    8fc4:      	sub	x6, x16, x4
    8fc8:      	sub	x7, x6, #0x1
    8fcc:      	uxtb	w16, w5
    8fd0:      	cmp	w16, wzr
    8fd4:      	b.eq	0x9018 <_stogir.vector.store-inputs+0x78>
    8fd8:      	ldr	x6, [x0, #0x8]
    8fdc:      	cmp	x4, x6
    8fe0:      	b.ge	0x906c <_stogir.vector.store-inputs+0xcc>
    8fe4:      	add	x6, x0, #0x78
    8fe8:      	ldr	x6, [x6, #0x8]
    8fec:      	cmp	x4, x6
    8ff0:      	b.ge	0x9184 <_stogir.vector.store-inputs+0x1e4>
    8ff4:      	lsl	x6, x4, #2
    8ff8:      	ldr	x9, [x0, #0x78]
    8ffc:      	add	x6, x6, x9
    9000:      	ldr	w6, [x6]
    9004:      	sxtw	x6, w6
    9008:      	cmp	x6, #0x0
    900c:      	cset	w6, ge
    9010:      	ubfx	x6, x6, #0, #8
    9014:      	b	0x9188 <_stogir.vector.store-inputs+0x1e8>
    9018:      	cmp	x4, #0x0
    901c:      	b.ge	0x9074 <_stogir.vector.store-inputs+0xd4>
    9020:      	add	x9, x0, #0x28
    9024:      	add	x10, x0, #0x50
    9028:      	ldr	x9, [x9, #0x8]
    902c:      	ldr	x10, [x10, #0x8]
    9030:      	cmp	x9, x10
    9034:      	b.ne	0x9064 <_stogir.vector.store-inputs+0xc4>
    9038:      	cmp	x6, x9
    903c:      	b.gt	0x918c <_stogir.vector.store-inputs+0x1ec>
    9040:      	lsl	x6, x7, #2
    9044:      	ldr	x9, [x0, #0x50]
    9048:      	add	x6, x6, x9
    904c:      	ldr	w6, [x6]
    9050:      	sxtw	x6, w6
    9054:      	cmp	x6, #0x0
    9058:      	cset	w6, gt
    905c:      	ubfx	x6, x6, #0, #8
    9060:      	b	0x9190 <_stogir.vector.store-inputs+0x1f0>
    9064:      	movz	x6, #0x0, lsl #48
    9068:      	b	0x9078 <_stogir.vector.store-inputs+0xd8>
    906c:      	movz	x6, #0x0, lsl #48
    9070:      	b	0x9078 <_stogir.vector.store-inputs+0xd8>
    9074:      	movz	x6, #0x0, lsl #48
    9078:      	cmp	x6, #0x0
    907c:      	b.eq	0x90bc <_stogir.vector.store-inputs+0x11c>
    9080:      	uxtb	w16, w5
    9084:      	cmp	w16, wzr
    9088:      	b.eq	0x90a0 <_stogir.vector.store-inputs+0x100>
    908c:      	lsl	x4, x4, #4
    9090:      	ldr	x5, [x0]
    9094:      	add	x4, x4, x5
    9098:      	ldr	x4, [x4]
    909c:      	b	0x90b0 <_stogir.vector.store-inputs+0x110>
    90a0:      	lsl	x4, x7, #4
    90a4:      	ldr	x5, [x0, #0x28]
    90a8:      	add	x4, x4, x5
    90ac:      	ldr	x4, [x4]
    90b0:      	mov	x5, x4
    90b4:      	mov	x4, #0x1                ; =1
    90b8:      	b	0x90c4 <_stogir.vector.store-inputs+0x124>
    90bc:      	movz	x4, #0x0, lsl #48
    90c0:      	movz	x5, #0x0, lsl #48
    90c4:      	lsr	w4, w4, #0
    90c8:      	lsr	x16, x4, #0
    90cc:      	cmp	x16, #0x1
    90d0:      	b.eq	0x90ec <_stogir.vector.store-inputs+0x14c>
    90d4:      	b.lo	0x90dc <_stogir.vector.store-inputs+0x13c>
    90d8:      	b	0x90f0 <_stogir.vector.store-inputs+0x150>
    90dc:      	cmp	x16, #0x0
    90e0:      	b.eq	0x90e8 <_stogir.vector.store-inputs+0x148>
    90e4:      	b	0x90f0 <_stogir.vector.store-inputs+0x150>
    90e8:      	b	0x90f4 <_stogir.vector.store-inputs+0x154>
    90ec:      	b	0x9114 <_stogir.vector.store-inputs+0x174>
    90f0:      	b	0x9194 <_stogir.vector.store-inputs+0x1f4>
    90f4:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		00000000000090f4:  ARM64_RELOC_PAGE21	l_stogir.422
    90f8:      	ldr	x16, [x16]
		00000000000090f8:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    90fc:      	orr	x0, x16, xzr
    9100:      	mov	x19, x8
    9104:      	mov	x1, x0
    9108:      	mov	x0, #0x1                ; =1
    910c:      	mov	x2, #0x1a               ; =26
    9110:      	b	0x9164 <_stogir.vector.store-inputs+0x1c4>
    9114:      	lsr	w1, w1, #0
    9118:      	lsr	w2, w2, #0
    911c:      	lsr	w3, w3, #0
    9120:      	lsr	w5, w5, #0
    9124:      	ubfx	x4, x5, #8, #8
    9128:      	lsr	w4, w4, #0
    912c:      	mov	x19, x8
    9130:      	add	x8, sp, #0x10
    9134:      	fmov	s31, w1
    9138:      	mov	w1, w4
    913c:      	mov	w4, w3
    9140:      	mov	w3, w2
    9144:      	fmov	w2, s31
    9148:      	bl	0x9148 <_stogir.vector.store-inputs+0x1a8>
		0000000000009148:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    914c:      	add	x16, sp, #0x10
    9150:      	ldr	x0, [x16]
    9154:      	add	x16, sp, #0x10
    9158:      	ldr	x1, [x16, #0x8]
    915c:      	add	x16, sp, #0x10
    9160:      	ldr	x2, [x16, #0x10]
    9164:      	str	x0, [x19]
    9168:      	str	x1, [x19, #0x8]
    916c:      	str	x2, [x19, #0x10]
    9170:      	ldr	x19, [sp, #0x30]
    9174:      	ldr	x29, [sp]
    9178:      	ldr	x30, [sp, #0x8]
    917c:      	add	sp, sp, #0x40
    9180:      	ret
    9184:      	movz	x6, #0x0, lsl #48
    9188:      	b	0x9070 <_stogir.vector.store-inputs+0xd0>
    918c:      	movz	x6, #0x0, lsl #48
    9190:      	b	0x9068 <_stogir.vector.store-inputs+0xc8>
    9194:      	brk	#0
    9198:      	b	0x9194 <_stogir.vector.store-inputs+0x1f4>

000000000000919c <_stogir.types.size>:
    919c:      	sub	sp, sp, #0x60
    91a0:      	str	x29, [sp]
    91a4:      	str	x30, [sp, #0x8]
    91a8:      	mov	x29, sp
    91ac:      	str	x19, [sp, #0x10]
    91b0:      	str	x20, [sp, #0x18]
    91b4:      	str	x21, [sp, #0x20]
    91b8:      	str	x22, [sp, #0x28]
    91bc:      	str	x23, [sp, #0x30]
    91c0:      	str	x24, [sp, #0x38]
    91c4:      	str	x25, [sp, #0x40]
    91c8:      	str	x26, [sp, #0x48]
    91cc:      	str	x27, [sp, #0x50]
    91d0:      	str	x28, [sp, #0x58]
    91d4:      	sxtw	x19, w0
    91d8:      	sxtw	x20, w1
    91dc:      	cmp	x19, #0xf
    91e0:      	cset	w21, gt
    91e4:      	cmp	x19, #0x0
    91e8:      	cset	w22, eq
    91ec:      	cmp	x20, #0x4
    91f0:      	cset	w23, eq
    91f4:      	cmp	x20, #0x8
    91f8:      	cset	w24, eq
    91fc:      	uxtb	w16, w21
    9200:      	cmp	w16, wzr
    9204:      	b.eq	0x9268 <_stogir.types.size+0xcc>
    9208:      	cmp	x19, #0x80
    920c:      	cset	w25, lt
    9210:      	uxtb	w16, w25
    9214:      	cmp	w16, wzr
    9218:      	b.eq	0x9268 <_stogir.types.size+0xcc>
    921c:      	and	x1, x19, #0xf
    9220:      	lsr	w1, w1, #0
    9224:      	sxtw	x26, w1
    9228:      	cmp	x26, #0x1
    922c:      	cset	w27, ge
    9230:      	uxtb	w16, w27
    9234:      	cmp	w16, wzr
    9238:      	b.eq	0x9268 <_stogir.types.size+0xcc>
    923c:      	cmp	x26, #0xd
    9240:      	cset	w28, le
    9244:      	uxtb	w16, w28
    9248:      	cmp	w16, wzr
    924c:      	b.eq	0x9268 <_stogir.types.size+0xcc>
    9250:      	lsr	w0, w0, #0
    9254:      	bl	0x9254 <_stogir.types.size+0xb8>
		0000000000009254:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9258:      	cmp	x0, #0x0
    925c:      	b.eq	0x9348 <_stogir.types.size+0x1ac>
    9260:      	mov	x0, x26
    9264:      	b	0x934c <_stogir.types.size+0x1b0>
    9268:      	uxtb	w16, w23
    926c:      	cmp	w16, wzr
    9270:      	b.ne	0x9288 <_stogir.types.size+0xec>
    9274:      	uxtb	w16, w24
    9278:      	cmp	w16, wzr
    927c:      	b.ne	0x9288 <_stogir.types.size+0xec>
    9280:      	movn	x0, #0x0, lsl #48
    9284:      	b	0x92a0 <_stogir.types.size+0x104>
    9288:      	uxtb	w16, w22
    928c:      	cmp	w16, wzr
    9290:      	b.eq	0x92d8 <_stogir.types.size+0x13c>
    9294:      	movz	x0, #0x0, lsl #48
    9298:      	b	0x92a0 <_stogir.types.size+0x104>
    929c:      	mov	x0, #0x1                ; =1
    92a0:      	ldr	x19, [sp, #0x10]
    92a4:      	ldr	x20, [sp, #0x18]
    92a8:      	ldr	x21, [sp, #0x20]
    92ac:      	ldr	x22, [sp, #0x28]
    92b0:      	ldr	x23, [sp, #0x30]
    92b4:      	ldr	x24, [sp, #0x38]
    92b8:      	ldr	x25, [sp, #0x40]
    92bc:      	ldr	x26, [sp, #0x48]
    92c0:      	ldr	x27, [sp, #0x50]
    92c4:      	ldr	x28, [sp, #0x58]
    92c8:      	ldr	x29, [sp]
    92cc:      	ldr	x30, [sp, #0x8]
    92d0:      	add	sp, sp, #0x60
    92d4:      	ret
    92d8:      	cmp	x19, #0x1
    92dc:      	b.eq	0x929c <_stogir.types.size+0x100>
    92e0:      	cmp	x19, #0x2
    92e4:      	b.eq	0x929c <_stogir.types.size+0x100>
    92e8:      	cmp	x19, #0x7
    92ec:      	b.eq	0x929c <_stogir.types.size+0x100>
    92f0:      	cmp	x19, #0x8
    92f4:      	b.eq	0x929c <_stogir.types.size+0x100>
    92f8:      	cmp	x19, #0x3
    92fc:      	b.eq	0x94b8 <_stogir.types.size+0x31c>
    9300:      	cmp	x19, #0x9
    9304:      	b.eq	0x94b8 <_stogir.types.size+0x31c>
    9308:      	cmp	x19, #0x4
    930c:      	b.eq	0x94e0 <_stogir.types.size+0x344>
    9310:      	cmp	x19, #0xa
    9314:      	b.eq	0x94e0 <_stogir.types.size+0x344>
    9318:      	cmp	x19, #0xd
    931c:      	b.eq	0x94e0 <_stogir.types.size+0x344>
    9320:      	cmp	x19, #0x5
    9324:      	b.eq	0x94f0 <_stogir.types.size+0x354>
    9328:      	cmp	x19, #0xb
    932c:      	b.eq	0x94f0 <_stogir.types.size+0x354>
    9330:      	cmp	x19, #0xc
    9334:      	b.eq	0x94f0 <_stogir.types.size+0x354>
    9338:      	cmp	x19, #0x6
    933c:      	b.ne	0x9500 <_stogir.types.size+0x364>
    9340:      	mov	x0, x20
    9344:      	b	0x9504 <_stogir.types.size+0x368>
    9348:      	movn	x0, #0x0, lsl #48
    934c:      	uxtb	w16, w23
    9350:      	cmp	w16, wzr
    9354:      	b.ne	0x936c <_stogir.types.size+0x1d0>
    9358:      	uxtb	w16, w24
    935c:      	cmp	w16, wzr
    9360:      	b.ne	0x936c <_stogir.types.size+0x1d0>
    9364:      	movn	x0, #0x0, lsl #48
    9368:      	b	0x9388 <_stogir.types.size+0x1ec>
    936c:      	lsr	w0, w0, #0
    9370:      	sxtw	x0, w0
    9374:      	cmp	x0, #0x0
    9378:      	b.ne	0x9448 <_stogir.types.size+0x2ac>
    937c:      	movz	x0, #0x0, lsl #48
    9380:      	b	0x9388 <_stogir.types.size+0x1ec>
    9384:      	mov	x0, #0x1                ; =1
    9388:      	lsr	w0, w0, #0
    938c:      	sxtw	x0, w0
    9390:      	cmp	x0, #0x0
    9394:      	b.ge	0x93f0 <_stogir.types.size+0x254>
    9398:      	movn	x0, #0x0, lsl #48
    939c:      	b	0x93b8 <_stogir.types.size+0x21c>
    93a0:      	movn	x1, #0x0, lsl #48
    93a4:      	lsr	w1, w1, #0
    93a8:      	sxtw	x1, w1
    93ac:      	mul	x0, x1, x0
    93b0:      	lsr	w0, w0, #0
    93b4:      	sxtw	x0, w0
    93b8:      	ldr	x19, [sp, #0x10]
    93bc:      	ldr	x20, [sp, #0x18]
    93c0:      	ldr	x21, [sp, #0x20]
    93c4:      	ldr	x22, [sp, #0x28]
    93c8:      	ldr	x23, [sp, #0x30]
    93cc:      	ldr	x24, [sp, #0x38]
    93d0:      	ldr	x25, [sp, #0x40]
    93d4:      	ldr	x26, [sp, #0x48]
    93d8:      	ldr	x27, [sp, #0x50]
    93dc:      	ldr	x28, [sp, #0x58]
    93e0:      	ldr	x29, [sp]
    93e4:      	ldr	x30, [sp, #0x8]
    93e8:      	add	sp, sp, #0x60
    93ec:      	ret
    93f0:      	uxtb	w16, w21
    93f4:      	cmp	w16, wzr
    93f8:      	b.eq	0x94c0 <_stogir.types.size+0x324>
    93fc:      	uxtb	w16, w25
    9400:      	cmp	w16, wzr
    9404:      	b.eq	0x94c0 <_stogir.types.size+0x324>
    9408:      	uxtb	w16, w27
    940c:      	cmp	w16, wzr
    9410:      	b.eq	0x94c0 <_stogir.types.size+0x324>
    9414:      	uxtb	w16, w28
    9418:      	cmp	w16, wzr
    941c:      	b.eq	0x94c0 <_stogir.types.size+0x324>
    9420:      	ubfx	x1, x19, #4, #32
    9424:      	sxtw	x1, w1
    9428:      	sub	x1, x1, #0x1
    942c:      	lsr	w1, w1, #0
    9430:      	sxtw	x1, w1
    9434:      	mov	x16, #0x1               ; =1
    9438:      	lsl	x1, x16, x1
    943c:      	lsr	w1, w1, #0
    9440:      	sxtw	x1, w1
    9444:      	b	0x93a4 <_stogir.types.size+0x208>
    9448:      	cmp	x0, #0x1
    944c:      	b.eq	0x9384 <_stogir.types.size+0x1e8>
    9450:      	cmp	x0, #0x2
    9454:      	b.eq	0x9384 <_stogir.types.size+0x1e8>
    9458:      	cmp	x0, #0x7
    945c:      	b.eq	0x9384 <_stogir.types.size+0x1e8>
    9460:      	cmp	x0, #0x8
    9464:      	b.eq	0x9384 <_stogir.types.size+0x1e8>
    9468:      	cmp	x0, #0x3
    946c:      	b.eq	0x94e8 <_stogir.types.size+0x34c>
    9470:      	cmp	x0, #0x9
    9474:      	b.eq	0x94e8 <_stogir.types.size+0x34c>
    9478:      	cmp	x0, #0x4
    947c:      	b.eq	0x94f8 <_stogir.types.size+0x35c>
    9480:      	cmp	x0, #0xa
    9484:      	b.eq	0x94f8 <_stogir.types.size+0x35c>
    9488:      	cmp	x0, #0xd
    948c:      	b.eq	0x94f8 <_stogir.types.size+0x35c>
    9490:      	cmp	x0, #0x5
    9494:      	b.eq	0x9508 <_stogir.types.size+0x36c>
    9498:      	cmp	x0, #0xb
    949c:      	b.eq	0x9508 <_stogir.types.size+0x36c>
    94a0:      	cmp	x0, #0xc
    94a4:      	b.eq	0x9508 <_stogir.types.size+0x36c>
    94a8:      	cmp	x0, #0x6
    94ac:      	b.ne	0x9510 <_stogir.types.size+0x374>
    94b0:      	mov	x0, x20
    94b4:      	b	0x9514 <_stogir.types.size+0x378>
    94b8:      	mov	x0, #0x2                ; =2
    94bc:      	b	0x92a0 <_stogir.types.size+0x104>
    94c0:      	cmp	x19, #0x0
    94c4:      	b.lt	0x93a0 <_stogir.types.size+0x204>
    94c8:      	cmp	x19, #0xd
    94cc:      	b.gt	0x93a0 <_stogir.types.size+0x204>
    94d0:      	uxtb	w16, w22
    94d4:      	cmp	w16, wzr
    94d8:      	cset	x1, eq
    94dc:      	b	0x93a4 <_stogir.types.size+0x208>
    94e0:      	mov	x0, #0x4                ; =4
    94e4:      	b	0x94bc <_stogir.types.size+0x320>
    94e8:      	mov	x0, #0x2                ; =2
    94ec:      	b	0x9388 <_stogir.types.size+0x1ec>
    94f0:      	mov	x0, #0x8                ; =8
    94f4:      	b	0x94e4 <_stogir.types.size+0x348>
    94f8:      	mov	x0, #0x4                ; =4
    94fc:      	b	0x94ec <_stogir.types.size+0x350>
    9500:      	movn	x0, #0x0, lsl #48
    9504:      	b	0x94f4 <_stogir.types.size+0x358>
    9508:      	mov	x0, #0x8                ; =8
    950c:      	b	0x94fc <_stogir.types.size+0x360>
    9510:      	movn	x0, #0x0, lsl #48
    9514:      	b	0x950c <_stogir.types.size+0x370>

0000000000009518 <_stogir.opcode.properties>:
    9518:      	sxtw	x0, w0
    951c:      	cmp	x0, #0x0
    9520:      	b.lt	0x9548 <_stogir.opcode.properties+0x30>
    9524:      	cmp	x0, #0x83
    9528:      	b.ge	0x9548 <_stogir.opcode.properties+0x30>
    952c:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		000000000000952c:  ARM64_RELOC_PAGE21	l_stogir.423
    9530:      	ldr	x16, [x16]
		0000000000009530:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    9534:      	orr	x1, x16, xzr
    9538:      	lsr	x0, x0, #0
    953c:      	add	x0, x0, x1
    9540:      	ldrb	w0, [x0]
    9544:      	b	0x954c <_stogir.opcode.properties+0x34>
    9548:      	movz	x0, #0x0, lsl #48
    954c:      	ret

0000000000009550 <_stogir.checked.projection>:
    9550:      	sub	sp, sp, #0x40
    9554:      	str	x29, [sp]
    9558:      	str	x30, [sp, #0x8]
    955c:      	mov	x29, sp
    9560:      	str	x19, [sp, #0x30]
    9564:      	sxtw	x2, w1
    9568:      	cmp	x2, #0x0
    956c:      	cset	w3, gt
    9570:      	movz	x16, #0x0, lsl #48
    9574:      	sub	x4, x16, x2
    9578:      	sub	x5, x4, #0x1
    957c:      	uxtb	w16, w3
    9580:      	cmp	w16, wzr
    9584:      	b.eq	0x95c8 <_stogir.checked.projection+0x78>
    9588:      	ldr	x4, [x0, #0x8]
    958c:      	cmp	x2, x4
    9590:      	b.ge	0x961c <_stogir.checked.projection+0xcc>
    9594:      	add	x4, x0, #0x78
    9598:      	ldr	x4, [x4, #0x8]
    959c:      	cmp	x2, x4
    95a0:      	b.ge	0x973c <_stogir.checked.projection+0x1ec>
    95a4:      	lsl	x4, x2, #2
    95a8:      	ldr	x6, [x0, #0x78]
    95ac:      	add	x4, x4, x6
    95b0:      	ldr	w4, [x4]
    95b4:      	sxtw	x4, w4
    95b8:      	cmp	x4, #0x0
    95bc:      	cset	w4, ge
    95c0:      	ubfx	x4, x4, #0, #8
    95c4:      	b	0x9740 <_stogir.checked.projection+0x1f0>
    95c8:      	cmp	x2, #0x0
    95cc:      	b.ge	0x9624 <_stogir.checked.projection+0xd4>
    95d0:      	add	x6, x0, #0x28
    95d4:      	add	x7, x0, #0x50
    95d8:      	ldr	x6, [x6, #0x8]
    95dc:      	ldr	x7, [x7, #0x8]
    95e0:      	cmp	x6, x7
    95e4:      	b.ne	0x9614 <_stogir.checked.projection+0xc4>
    95e8:      	cmp	x4, x6
    95ec:      	b.gt	0x976c <_stogir.checked.projection+0x21c>
    95f0:      	lsl	x4, x5, #2
    95f4:      	ldr	x6, [x0, #0x50]
    95f8:      	add	x4, x4, x6
    95fc:      	ldr	w4, [x4]
    9600:      	sxtw	x4, w4
    9604:      	cmp	x4, #0x0
    9608:      	cset	w4, gt
    960c:      	ubfx	x4, x4, #0, #8
    9610:      	b	0x9770 <_stogir.checked.projection+0x220>
    9614:      	movz	x4, #0x0, lsl #48
    9618:      	b	0x9628 <_stogir.checked.projection+0xd8>
    961c:      	movz	x4, #0x0, lsl #48
    9620:      	b	0x9628 <_stogir.checked.projection+0xd8>
    9624:      	movz	x4, #0x0, lsl #48
    9628:      	cmp	x4, #0x0
    962c:      	b.eq	0x966c <_stogir.checked.projection+0x11c>
    9630:      	uxtb	w16, w3
    9634:      	cmp	w16, wzr
    9638:      	b.eq	0x9650 <_stogir.checked.projection+0x100>
    963c:      	lsl	x2, x2, #4
    9640:      	ldr	x3, [x0]
    9644:      	add	x2, x2, x3
    9648:      	ldr	x2, [x2]
    964c:      	b	0x9660 <_stogir.checked.projection+0x110>
    9650:      	lsl	x2, x5, #4
    9654:      	ldr	x3, [x0, #0x28]
    9658:      	add	x2, x2, x3
    965c:      	ldr	x2, [x2]
    9660:      	mov	x3, x2
    9664:      	mov	x2, #0x1                ; =1
    9668:      	b	0x9674 <_stogir.checked.projection+0x124>
    966c:      	movz	x2, #0x0, lsl #48
    9670:      	movz	x3, #0x0, lsl #48
    9674:      	lsr	w2, w2, #0
    9678:      	lsr	x16, x2, #0
    967c:      	cmp	x16, #0x1
    9680:      	b.eq	0x969c <_stogir.checked.projection+0x14c>
    9684:      	b.lo	0x968c <_stogir.checked.projection+0x13c>
    9688:      	b	0x96a0 <_stogir.checked.projection+0x150>
    968c:      	cmp	x16, #0x0
    9690:      	b.eq	0x9698 <_stogir.checked.projection+0x148>
    9694:      	b	0x96a0 <_stogir.checked.projection+0x150>
    9698:      	b	0x96a4 <_stogir.checked.projection+0x154>
    969c:      	b	0x96fc <_stogir.checked.projection+0x1ac>
    96a0:      	b	0x9774 <_stogir.checked.projection+0x224>
    96a4:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		00000000000096a4:  ARM64_RELOC_PAGE21	l_stogir.424
    96a8:      	ldr	x16, [x16]
		00000000000096a8:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    96ac:      	orr	x0, x16, xzr
    96b0:      	mov	x19, x8
    96b4:      	mov	x1, x0
    96b8:      	mov	x0, #0x1                ; =1
    96bc:      	mov	x2, #0x17               ; =23
    96c0:      	b	0x96dc <_stogir.checked.projection+0x18c>
    96c4:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		00000000000096c4:  ARM64_RELOC_PAGE21	l_stogir.425
    96c8:      	ldr	x16, [x16]
		00000000000096c8:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    96cc:      	orr	x0, x16, xzr
    96d0:      	mov	x1, x0
    96d4:      	mov	x0, #0x1                ; =1
    96d8:      	mov	x2, #0x20               ; =32
    96dc:      	str	x0, [x19]
    96e0:      	str	x1, [x19, #0x8]
    96e4:      	str	x2, [x19, #0x10]
    96e8:      	ldr	x19, [sp, #0x30]
    96ec:      	ldr	x29, [sp]
    96f0:      	ldr	x30, [sp, #0x8]
    96f4:      	add	sp, sp, #0x40
    96f8:      	ret
    96fc:      	uxtb	w2, w3
    9700:      	cmp	x2, #0x29
    9704:      	b.lt	0x977c <_stogir.checked.projection+0x22c>
    9708:      	cmp	x2, #0x2b
    970c:      	b.gt	0x9784 <_stogir.checked.projection+0x234>
    9710:      	lsr	w1, w1, #0
    9714:      	mov	x19, x8
    9718:      	add	x8, sp, #0x10
    971c:      	bl	0x971c <_stogir.checked.projection+0x1cc>
		000000000000971c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    9720:      	add	x16, sp, #0x10
    9724:      	ldr	x0, [x16]
    9728:      	add	x16, sp, #0x10
    972c:      	ldr	x1, [x16, #0x8]
    9730:      	add	x16, sp, #0x10
    9734:      	ldr	x2, [x16, #0x10]
    9738:      	b	0x96dc <_stogir.checked.projection+0x18c>
    973c:      	movz	x4, #0x0, lsl #48
    9740:      	b	0x9620 <_stogir.checked.projection+0xd0>
    9744:      	lsr	w3, w3, #0
    9748:      	ubfx	x0, x3, #8, #8
    974c:      	cmp	x0, #0x0
    9750:      	b.eq	0x96c4 <_stogir.checked.projection+0x174>
    9754:      	cmp	x0, #0xd
    9758:      	b.gt	0x96c4 <_stogir.checked.projection+0x174>
    975c:      	movz	x0, #0x0, lsl #48
    9760:      	movz	x1, #0x0, lsl #48
    9764:      	movz	x2, #0x0, lsl #48
    9768:      	b	0x96dc <_stogir.checked.projection+0x18c>
    976c:      	movz	x4, #0x0, lsl #48
    9770:      	b	0x9618 <_stogir.checked.projection+0xc8>
    9774:      	brk	#0
    9778:      	b	0x9774 <_stogir.checked.projection+0x224>
    977c:      	mov	x19, x8
    9780:      	b	0x9744 <_stogir.checked.projection+0x1f4>
    9784:      	mov	x19, x8
    9788:      	b	0x9744 <_stogir.checked.projection+0x1f4>

000000000000978c <_stogir.checked.operands>:
    978c:      	sub	sp, sp, #0x50
    9790:      	str	x29, [sp]
    9794:      	str	x30, [sp, #0x8]
    9798:      	mov	x29, sp
    979c:      	str	x19, [sp, #0x30]
    97a0:      	str	x20, [sp, #0x38]
    97a4:      	str	x21, [sp, #0x40]
    97a8:      	str	x22, [sp, #0x48]
    97ac:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		00000000000097ac:  ARM64_RELOC_PAGE21	l_stogir.426
    97b0:      	ldr	x16, [x16]
		00000000000097b0:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    97b4:      	orr	x5, x16, xzr
    97b8:      	sxtw	x1, w1
    97bc:      	sxtw	x19, w2
    97c0:      	cmp	x1, #0x29
    97c4:      	b.lt	0x9804 <_stogir.checked.operands+0x78>
    97c8:      	cmp	x1, #0x2b
    97cc:      	b.gt	0x9804 <_stogir.checked.operands+0x78>
    97d0:      	cmp	x19, #0x1
    97d4:      	b.lt	0x9804 <_stogir.checked.operands+0x78>
    97d8:      	cmp	x19, #0xb
    97dc:      	b.gt	0x9804 <_stogir.checked.operands+0x78>
    97e0:      	cmp	x19, #0x1
    97e4:      	b.eq	0x9804 <_stogir.checked.operands+0x78>
    97e8:      	mov	x1, x5
    97ec:      	movz	x2, #0x0, lsl #48
    97f0:      	b	0x9814 <_stogir.checked.operands+0x88>
    97f4:      	movz	x4, #0x0, lsl #48
    97f8:      	b	0x9864 <_stogir.checked.operands+0xd8>
    97fc:      	movz	x4, #0x0, lsl #48
    9800:      	b	0x9878 <_stogir.checked.operands+0xec>
    9804:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009804:  ARM64_RELOC_PAGE21	l_stogir.427
    9808:      	ldr	x16, [x16]
		0000000000009808:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    980c:      	orr	x1, x16, xzr
    9810:      	mov	x2, #0x36               ; =54
    9814:      	add	x16, sp, #0x20
    9818:      	orr	x6, x16, xzr
    981c:      	lsr	w3, w3, #0
    9820:      	lsr	w4, w4, #0
    9824:      	add	x7, x0, #0x78
    9828:      	add	x9, x0, #0x28
    982c:      	add	x10, x0, #0x50
    9830:      	add	x16, sp, #0x10
    9834:      	str	w3, [x16]
    9838:      	add	x16, sp, #0x10
    983c:      	str	w4, [x16, #0x4]
    9840:      	add	x16, sp, #0x10
    9844:      	ldr	x3, [x16]
    9848:      	add	x16, sp, #0x20
    984c:      	str	x3, [x16]
    9850:      	mov	x20, x1
    9854:      	mov	x21, x2
    9858:      	movz	x1, #0x0, lsl #48
    985c:      	b	0x9930 <_stogir.checked.operands+0x1a4>
    9860:      	movz	x4, #0x0, lsl #48
    9864:      	fmov	d31, x3
    9868:      	mov	x3, x4
    986c:      	fmov	x4, d31
    9870:      	b	0x9884 <_stogir.checked.operands+0xf8>
    9874:      	movz	x4, #0x0, lsl #48
    9878:      	fmov	d31, x3
    987c:      	mov	x3, x4
    9880:      	fmov	x4, d31
    9884:      	cmp	x3, #0x0
    9888:      	b.eq	0x98c8 <_stogir.checked.operands+0x13c>
    988c:      	uxtb	w16, w1
    9890:      	cmp	w16, wzr
    9894:      	b.eq	0x98ac <_stogir.checked.operands+0x120>
    9898:      	lsl	x1, x2, #4
    989c:      	ldr	x2, [x0]
    98a0:      	add	x1, x1, x2
    98a4:      	ldr	x1, [x1]
    98a8:      	b	0x98bc <_stogir.checked.operands+0x130>
    98ac:      	lsl	x1, x11, #4
    98b0:      	ldr	x2, [x0, #0x28]
    98b4:      	add	x1, x1, x2
    98b8:      	ldr	x1, [x1]
    98bc:      	mov	x2, x1
    98c0:      	mov	x1, #0x1                ; =1
    98c4:      	b	0x98d0 <_stogir.checked.operands+0x144>
    98c8:      	movz	x1, #0x0, lsl #48
    98cc:      	movz	x2, #0x0, lsl #48
    98d0:      	lsr	w1, w1, #0
    98d4:      	lsr	x16, x1, #0
    98d8:      	cmp	x16, #0x1
    98dc:      	b.eq	0x98f8 <_stogir.checked.operands+0x16c>
    98e0:      	b.lo	0x98e8 <_stogir.checked.operands+0x15c>
    98e4:      	b	0x98fc <_stogir.checked.operands+0x170>
    98e8:      	cmp	x16, #0x0
    98ec:      	b.eq	0x98f4 <_stogir.checked.operands+0x168>
    98f0:      	b	0x98fc <_stogir.checked.operands+0x170>
    98f4:      	b	0x9900 <_stogir.checked.operands+0x174>
    98f8:      	b	0x9acc <_stogir.checked.operands+0x340>
    98fc:      	b	0x9af8 <_stogir.checked.operands+0x36c>
    9900:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009900:  ARM64_RELOC_PAGE21	l_stogir.428
    9904:      	ldr	x16, [x16]
		0000000000009904:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    9908:      	orr	x1, x16, xzr
    990c:      	mov	x2, #0x22               ; =34
    9910:      	b	0x9924 <_stogir.checked.operands+0x198>
    9914:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009914:  ARM64_RELOC_PAGE21	l_stogir.429
    9918:      	ldr	x16, [x16]
		0000000000009918:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    991c:      	orr	x1, x16, xzr
    9920:      	mov	x2, #0x28               ; =40
    9924:      	mov	x20, x1
    9928:      	mov	x21, x2
    992c:      	mov	x1, x4
    9930:      	cmp	x1, #0x2
    9934:      	b.ge	0x9960 <_stogir.checked.operands+0x1d4>
    9938:      	add	x2, x1, #0x1
    993c:      	lsl	x1, x1, #2
    9940:      	add	x1, x1, x6
    9944:      	ldr	w1, [x1]
    9948:      	sxtw	x1, w1
    994c:      	and	x1, x1, #0xffffffff
    9950:      	mov	x3, x2
    9954:      	mov	x2, x1
    9958:      	mov	x1, #0x1                ; =1
    995c:      	b	0x996c <_stogir.checked.operands+0x1e0>
    9960:      	mov	x3, x1
    9964:      	movz	x1, #0x0, lsl #48
    9968:      	movz	x2, #0x0, lsl #48
    996c:      	lsr	w1, w1, #0
    9970:      	lsr	x16, x1, #0
    9974:      	cmp	x16, #0x1
    9978:      	b.eq	0x9994 <_stogir.checked.operands+0x208>
    997c:      	b.lo	0x9984 <_stogir.checked.operands+0x1f8>
    9980:      	b	0x9998 <_stogir.checked.operands+0x20c>
    9984:      	cmp	x16, #0x0
    9988:      	b.eq	0x9990 <_stogir.checked.operands+0x204>
    998c:      	b	0x9998 <_stogir.checked.operands+0x20c>
    9990:      	b	0x9a00 <_stogir.checked.operands+0x274>
    9994:      	b	0x999c <_stogir.checked.operands+0x210>
    9998:      	b	0x9af0 <_stogir.checked.operands+0x364>
    999c:      	lsr	w2, w2, #0
    99a0:      	sxtw	x2, w2
    99a4:      	cmp	x2, #0x0
    99a8:      	cset	w1, gt
    99ac:      	movz	x16, #0x0, lsl #48
    99b0:      	sub	x4, x16, x2
    99b4:      	sub	x11, x4, #0x1
    99b8:      	uxtb	w16, w1
    99bc:      	cmp	w16, wzr
    99c0:      	b.eq	0x9a28 <_stogir.checked.operands+0x29c>
    99c4:      	ldr	x4, [x0, #0x8]
    99c8:      	cmp	x2, x4
    99cc:      	b.ge	0x9860 <_stogir.checked.operands+0xd4>
    99d0:      	ldr	x4, [x7, #0x8]
    99d4:      	cmp	x2, x4
    99d8:      	b.ge	0x97f4 <_stogir.checked.operands+0x68>
    99dc:      	lsl	x4, x2, #2
    99e0:      	ldr	x12, [x0, #0x78]
    99e4:      	add	x4, x4, x12
    99e8:      	ldr	w4, [x4]
    99ec:      	sxtw	x4, w4
    99f0:      	cmp	x4, #0x0
    99f4:      	cset	w4, ge
    99f8:      	ubfx	x4, x4, #0, #8
    99fc:      	b	0x97f8 <_stogir.checked.operands+0x6c>
    9a00:      	cmp	x21, #0x0
    9a04:      	b.ne	0x9b00 <_stogir.checked.operands+0x374>
    9a08:      	cmp	x21, #0x0
    9a0c:      	b.ne	0x9a6c <_stogir.checked.operands+0x2e0>
    9a10:      	mov	x22, x8
    9a14:      	and	x0, x19, #0xffffffff
    9a18:      	mov	x1, x0
    9a1c:      	movz	x0, #0x0, lsl #48
    9a20:      	movz	x2, #0x0, lsl #48
    9a24:      	b	0x9aa0 <_stogir.checked.operands+0x314>
    9a28:      	cmp	x2, #0x0
    9a2c:      	b.ge	0x9874 <_stogir.checked.operands+0xe8>
    9a30:      	ldr	x12, [x9, #0x8]
    9a34:      	ldr	x13, [x10, #0x8]
    9a38:      	cmp	x12, x13
    9a3c:      	b.ne	0x97fc <_stogir.checked.operands+0x70>
    9a40:      	cmp	x4, x12
    9a44:      	b.gt	0x9ae8 <_stogir.checked.operands+0x35c>
    9a48:      	lsl	x4, x11, #2
    9a4c:      	ldr	x12, [x0, #0x50]
    9a50:      	add	x4, x4, x12
    9a54:      	ldr	w4, [x4]
    9a58:      	sxtw	x4, w4
    9a5c:      	cmp	x4, #0x0
    9a60:      	cset	w4, gt
    9a64:      	ubfx	x4, x4, #0, #8
    9a68:      	b	0x9aec <_stogir.checked.operands+0x360>
    9a6c:      	lsr	x0, x21, #0
    9a70:      	mov	x1, x5
    9a74:      	mov	x2, x0
    9a78:      	mov	x0, x20
    9a7c:      	mov	x22, x8
    9a80:      	bl	0x9a80 <_stogir.checked.operands+0x2f4>
		0000000000009a80:  ARM64_RELOC_BRANCH26	_memcmp
    9a84:      	lsr	w0, w0, #0
    9a88:      	sxtw	x0, w0
    9a8c:      	cmp	x0, #0x0
    9a90:      	b.eq	0x9a14 <_stogir.checked.operands+0x288>
    9a94:      	mov	x1, x20
    9a98:      	mov	x2, x21
    9a9c:      	mov	x0, #0x1                ; =1
    9aa0:      	str	x0, [x22]
    9aa4:      	str	x1, [x22, #0x8]
    9aa8:      	str	x2, [x22, #0x10]
    9aac:      	ldr	x19, [sp, #0x30]
    9ab0:      	ldr	x20, [sp, #0x38]
    9ab4:      	ldr	x21, [sp, #0x40]
    9ab8:      	ldr	x22, [sp, #0x48]
    9abc:      	ldr	x29, [sp]
    9ac0:      	ldr	x30, [sp, #0x8]
    9ac4:      	add	sp, sp, #0x50
    9ac8:      	ret
    9acc:      	lsr	w2, w2, #0
    9ad0:      	ubfx	x1, x2, #8, #8
    9ad4:      	cmp	x1, x19
    9ad8:      	b.ne	0x9914 <_stogir.checked.operands+0x188>
    9adc:      	mov	x1, x20
    9ae0:      	mov	x2, x21
    9ae4:      	b	0x9924 <_stogir.checked.operands+0x198>
    9ae8:      	movz	x4, #0x0, lsl #48
    9aec:      	b	0x9800 <_stogir.checked.operands+0x74>
    9af0:      	brk	#0
    9af4:      	b	0x9af0 <_stogir.checked.operands+0x364>
    9af8:      	brk	#0
    9afc:      	b	0x9af8 <_stogir.checked.operands+0x36c>
    9b00:      	mov	x22, x8
    9b04:      	b	0x9a94 <_stogir.checked.operands+0x308>

0000000000009b08 <_stogir.opcode.control?>:
    9b08:      	sxtw	x0, w0
    9b0c:      	cmp	x0, #0x0
    9b10:      	b.lt	0x9b38 <_stogir.opcode.control?+0x30>
    9b14:      	cmp	x0, #0x83
    9b18:      	b.ge	0x9b38 <_stogir.opcode.control?+0x30>
    9b1c:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009b1c:  ARM64_RELOC_PAGE21	l_stogir.430
    9b20:      	ldr	x16, [x16]
		0000000000009b20:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    9b24:      	orr	x1, x16, xzr
    9b28:      	lsr	x0, x0, #0
    9b2c:      	add	x0, x0, x1
    9b30:      	ldrb	w0, [x0]
    9b34:      	b	0x9b3c <_stogir.opcode.control?+0x34>
    9b38:      	movz	x0, #0x0, lsl #48
    9b3c:      	uxtb	w0, w0
    9b40:      	and	x0, x0, #0x1
    9b44:      	uxtb	w0, w0
    9b48:      	ret

0000000000009b4c <_stogir.opcode.block-end?>:
    9b4c:      	sxtw	x0, w0
    9b50:      	cmp	x0, #0x0
    9b54:      	b.lt	0x9b7c <_stogir.opcode.block-end?+0x30>
    9b58:      	cmp	x0, #0x83
    9b5c:      	b.ge	0x9b7c <_stogir.opcode.block-end?+0x30>
    9b60:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009b60:  ARM64_RELOC_PAGE21	l_stogir.431
    9b64:      	ldr	x16, [x16]
		0000000000009b64:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    9b68:      	orr	x1, x16, xzr
    9b6c:      	lsr	x0, x0, #0
    9b70:      	add	x0, x0, x1
    9b74:      	ldrb	w0, [x0]
    9b78:      	b	0x9b80 <_stogir.opcode.block-end?+0x34>
    9b7c:      	movz	x0, #0x0, lsl #48
    9b80:      	uxtb	w0, w0
    9b84:      	and	x0, x0, #0x4
    9b88:      	uxtb	w0, w0
    9b8c:      	cmp	x0, #0x0
    9b90:      	cset	w0, eq
    9b94:      	uxtb	w16, w0
    9b98:      	cmp	w16, wzr
    9b9c:      	cset	x0, eq
    9ba0:      	ret

0000000000009ba4 <_stogir.atomic.ordinary?>:
    9ba4:      	sxtw	x1, w1
    9ba8:      	cmp	x1, #0x0
    9bac:      	cset	w3, gt
    9bb0:      	movz	x16, #0x0, lsl #48
    9bb4:      	sub	x4, x16, x1
    9bb8:      	sub	x5, x4, #0x1
    9bbc:      	uxtb	w16, w3
    9bc0:      	cmp	w16, wzr
    9bc4:      	b.eq	0x9c08 <_stogir.atomic.ordinary?+0x64>
    9bc8:      	ldr	x4, [x0, #0x8]
    9bcc:      	cmp	x1, x4
    9bd0:      	b.ge	0x9c5c <_stogir.atomic.ordinary?+0xb8>
    9bd4:      	add	x4, x0, #0x78
    9bd8:      	ldr	x4, [x4, #0x8]
    9bdc:      	cmp	x1, x4
    9be0:      	b.ge	0x9d1c <_stogir.atomic.ordinary?+0x178>
    9be4:      	lsl	x4, x1, #2
    9be8:      	ldr	x6, [x0, #0x78]
    9bec:      	add	x4, x4, x6
    9bf0:      	ldr	w4, [x4]
    9bf4:      	sxtw	x4, w4
    9bf8:      	cmp	x4, #0x0
    9bfc:      	cset	w4, ge
    9c00:      	ubfx	x4, x4, #0, #8
    9c04:      	b	0x9d20 <_stogir.atomic.ordinary?+0x17c>
    9c08:      	cmp	x1, #0x0
    9c0c:      	b.ge	0x9c64 <_stogir.atomic.ordinary?+0xc0>
    9c10:      	add	x6, x0, #0x28
    9c14:      	add	x7, x0, #0x50
    9c18:      	ldr	x6, [x6, #0x8]
    9c1c:      	ldr	x7, [x7, #0x8]
    9c20:      	cmp	x6, x7
    9c24:      	b.ne	0x9c54 <_stogir.atomic.ordinary?+0xb0>
    9c28:      	cmp	x4, x6
    9c2c:      	b.gt	0x9d3c <_stogir.atomic.ordinary?+0x198>
    9c30:      	lsl	x4, x5, #2
    9c34:      	ldr	x6, [x0, #0x50]
    9c38:      	add	x4, x4, x6
    9c3c:      	ldr	w4, [x4]
    9c40:      	sxtw	x4, w4
    9c44:      	cmp	x4, #0x0
    9c48:      	cset	w4, gt
    9c4c:      	ubfx	x4, x4, #0, #8
    9c50:      	b	0x9d40 <_stogir.atomic.ordinary?+0x19c>
    9c54:      	movz	x4, #0x0, lsl #48
    9c58:      	b	0x9c68 <_stogir.atomic.ordinary?+0xc4>
    9c5c:      	movz	x4, #0x0, lsl #48
    9c60:      	b	0x9c68 <_stogir.atomic.ordinary?+0xc4>
    9c64:      	movz	x4, #0x0, lsl #48
    9c68:      	cmp	x4, #0x0
    9c6c:      	b.eq	0x9cac <_stogir.atomic.ordinary?+0x108>
    9c70:      	uxtb	w16, w3
    9c74:      	cmp	w16, wzr
    9c78:      	b.eq	0x9c90 <_stogir.atomic.ordinary?+0xec>
    9c7c:      	lsl	x1, x1, #4
    9c80:      	ldr	x0, [x0]
    9c84:      	add	x0, x1, x0
    9c88:      	ldr	x0, [x0]
    9c8c:      	b	0x9ca0 <_stogir.atomic.ordinary?+0xfc>
    9c90:      	lsl	x1, x5, #4
    9c94:      	ldr	x0, [x0, #0x28]
    9c98:      	add	x0, x1, x0
    9c9c:      	ldr	x0, [x0]
    9ca0:      	mov	x1, x0
    9ca4:      	mov	x0, #0x1                ; =1
    9ca8:      	b	0x9cb4 <_stogir.atomic.ordinary?+0x110>
    9cac:      	movz	x0, #0x0, lsl #48
    9cb0:      	movz	x1, #0x0, lsl #48
    9cb4:      	lsr	w0, w0, #0
    9cb8:      	lsr	x16, x0, #0
    9cbc:      	cmp	x16, #0x1
    9cc0:      	b.eq	0x9cdc <_stogir.atomic.ordinary?+0x138>
    9cc4:      	b.lo	0x9ccc <_stogir.atomic.ordinary?+0x128>
    9cc8:      	b	0x9ce0 <_stogir.atomic.ordinary?+0x13c>
    9ccc:      	cmp	x16, #0x0
    9cd0:      	b.eq	0x9cd8 <_stogir.atomic.ordinary?+0x134>
    9cd4:      	b	0x9ce0 <_stogir.atomic.ordinary?+0x13c>
    9cd8:      	b	0x9ce4 <_stogir.atomic.ordinary?+0x140>
    9cdc:      	b	0x9cf4 <_stogir.atomic.ordinary?+0x150>
    9ce0:      	b	0x9d44 <_stogir.atomic.ordinary?+0x1a0>
    9ce4:      	movz	x0, #0x0, lsl #48
    9ce8:      	b	0x9cf0 <_stogir.atomic.ordinary?+0x14c>
    9cec:      	movz	x0, #0x0, lsl #48
    9cf0:      	ret
    9cf4:      	sxtw	x2, w2
    9cf8:      	lsr	w0, w1, #0
    9cfc:      	ubfx	x0, x0, #8, #8
    9d00:      	cmp	x0, x2
    9d04:      	b.ne	0x9cec <_stogir.atomic.ordinary?+0x148>
    9d08:      	uxtb	w1, w1
    9d0c:      	cmp	x1, #0x46
    9d10:      	b.ne	0x9d24 <_stogir.atomic.ordinary?+0x180>
    9d14:      	movz	x0, #0x0, lsl #48
    9d18:      	b	0x9d38 <_stogir.atomic.ordinary?+0x194>
    9d1c:      	movz	x4, #0x0, lsl #48
    9d20:      	b	0x9c60 <_stogir.atomic.ordinary?+0xbc>
    9d24:      	cmp	x1, #0x48
    9d28:      	cset	w0, eq
    9d2c:      	uxtb	w16, w0
    9d30:      	cmp	w16, wzr
    9d34:      	cset	x0, eq
    9d38:      	b	0x9cf0 <_stogir.atomic.ordinary?+0x14c>
    9d3c:      	movz	x4, #0x0, lsl #48
    9d40:      	b	0x9c58 <_stogir.atomic.ordinary?+0xb4>
    9d44:      	brk	#0
    9d48:      	b	0x9d44 <_stogir.atomic.ordinary?+0x1a0>

0000000000009d4c <_stogir.types.scalar-size>:
    9d4c:      	sxtw	x1, w1
    9d50:      	cmp	x1, #0x4
    9d54:      	b.eq	0x9d68 <_stogir.types.scalar-size+0x1c>
    9d58:      	cmp	x1, #0x8
    9d5c:      	b.eq	0x9d68 <_stogir.types.scalar-size+0x1c>
    9d60:      	movn	x0, #0x0, lsl #48
    9d64:      	b	0x9d80 <_stogir.types.scalar-size+0x34>
    9d68:      	sxtw	x0, w0
    9d6c:      	cmp	x0, #0x0
    9d70:      	b.ne	0x9d84 <_stogir.types.scalar-size+0x38>
    9d74:      	movz	x0, #0x0, lsl #48
    9d78:      	b	0x9d80 <_stogir.types.scalar-size+0x34>
    9d7c:      	mov	x0, #0x1                ; =1
    9d80:      	ret
    9d84:      	cmp	x0, #0x1
    9d88:      	b.eq	0x9d7c <_stogir.types.scalar-size+0x30>
    9d8c:      	cmp	x0, #0x2
    9d90:      	b.eq	0x9d7c <_stogir.types.scalar-size+0x30>
    9d94:      	cmp	x0, #0x7
    9d98:      	b.eq	0x9d7c <_stogir.types.scalar-size+0x30>
    9d9c:      	cmp	x0, #0x8
    9da0:      	b.eq	0x9d7c <_stogir.types.scalar-size+0x30>
    9da4:      	cmp	x0, #0x3
    9da8:      	b.eq	0x9df4 <_stogir.types.scalar-size+0xa8>
    9dac:      	cmp	x0, #0x9
    9db0:      	b.eq	0x9df4 <_stogir.types.scalar-size+0xa8>
    9db4:      	cmp	x0, #0x4
    9db8:      	b.eq	0x9dfc <_stogir.types.scalar-size+0xb0>
    9dbc:      	cmp	x0, #0xa
    9dc0:      	b.eq	0x9dfc <_stogir.types.scalar-size+0xb0>
    9dc4:      	cmp	x0, #0xd
    9dc8:      	b.eq	0x9dfc <_stogir.types.scalar-size+0xb0>
    9dcc:      	cmp	x0, #0x5
    9dd0:      	b.eq	0x9e04 <_stogir.types.scalar-size+0xb8>
    9dd4:      	cmp	x0, #0xb
    9dd8:      	b.eq	0x9e04 <_stogir.types.scalar-size+0xb8>
    9ddc:      	cmp	x0, #0xc
    9de0:      	b.eq	0x9e04 <_stogir.types.scalar-size+0xb8>
    9de4:      	cmp	x0, #0x6
    9de8:      	b.ne	0x9e0c <_stogir.types.scalar-size+0xc0>
    9dec:      	mov	x0, x1
    9df0:      	b	0x9e10 <_stogir.types.scalar-size+0xc4>
    9df4:      	mov	x0, #0x2                ; =2
    9df8:      	b	0x9d80 <_stogir.types.scalar-size+0x34>
    9dfc:      	mov	x0, #0x4                ; =4
    9e00:      	b	0x9df8 <_stogir.types.scalar-size+0xac>
    9e04:      	mov	x0, #0x8                ; =8
    9e08:      	b	0x9e00 <_stogir.types.scalar-size+0xb4>
    9e0c:      	movn	x0, #0x0, lsl #48
    9e10:      	b	0x9e08 <_stogir.types.scalar-size+0xbc>

0000000000009e14 <_stogir.terminal.inputs>:
    9e14:      	sxtw	x1, w1
    9e18:      	cmp	x1, #0x60
    9e1c:      	cset	w4, eq
    9e20:      	uxtb	w16, w4
    9e24:      	cmp	w16, wzr
    9e28:      	b.ne	0x9e5c <_stogir.terminal.inputs+0x48>
    9e2c:      	cmp	x1, #0x79
    9e30:      	b.eq	0x9e5c <_stogir.terminal.inputs+0x48>
    9e34:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009e34:  ARM64_RELOC_PAGE21	l_stogir.432
    9e38:      	ldr	x16, [x16]
		0000000000009e38:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    9e3c:      	orr	x0, x16, xzr
    9e40:      	mov	x1, x0
    9e44:      	mov	x0, #0x1                ; =1
    9e48:      	mov	x2, #0x25               ; =37
    9e4c:      	str	x0, [x8]
    9e50:      	str	x1, [x8, #0x8]
    9e54:      	str	x2, [x8, #0x10]
    9e58:      	ret
    9e5c:      	sxtw	x3, w3
    9e60:      	uxtb	w16, w4
    9e64:      	cmp	w16, wzr
    9e68:      	b.eq	0x9e74 <_stogir.terminal.inputs+0x60>
    9e6c:      	cmp	x3, #0x0
    9e70:      	b.ne	0x9e34 <_stogir.terminal.inputs+0x20>
    9e74:      	sxtw	x2, w2
    9e78:      	cmp	x2, #0x0
    9e7c:      	cset	w1, gt
    9e80:      	movz	x16, #0x0, lsl #48
    9e84:      	sub	x4, x16, x2
    9e88:      	sub	x5, x4, #0x1
    9e8c:      	uxtb	w16, w1
    9e90:      	cmp	w16, wzr
    9e94:      	b.eq	0x9f7c <_stogir.terminal.inputs+0x168>
    9e98:      	ldr	x4, [x0, #0x8]
    9e9c:      	cmp	x2, x4
    9ea0:      	b.ge	0x9f74 <_stogir.terminal.inputs+0x160>
    9ea4:      	add	x4, x0, #0x78
    9ea8:      	ldr	x4, [x4, #0x8]
    9eac:      	cmp	x2, x4
    9eb0:      	b.ge	0xa024 <_stogir.terminal.inputs+0x210>
    9eb4:      	lsl	x4, x2, #2
    9eb8:      	ldr	x6, [x0, #0x78]
    9ebc:      	add	x4, x4, x6
    9ec0:      	ldr	w4, [x4]
    9ec4:      	sxtw	x4, w4
    9ec8:      	cmp	x4, #0x0
    9ecc:      	cset	w4, ge
    9ed0:      	ubfx	x4, x4, #0, #8
    9ed4:      	b	0xa028 <_stogir.terminal.inputs+0x214>
    9ed8:      	movz	x1, #0x0, lsl #48
    9edc:      	movz	x4, #0x0, lsl #48
    9ee0:      	lsr	w1, w1, #0
    9ee4:      	lsr	x16, x1, #0
    9ee8:      	cmp	x16, #0x1
    9eec:      	b.eq	0x9f08 <_stogir.terminal.inputs+0xf4>
    9ef0:      	b.lo	0x9ef8 <_stogir.terminal.inputs+0xe4>
    9ef4:      	b	0x9f0c <_stogir.terminal.inputs+0xf8>
    9ef8:      	cmp	x16, #0x0
    9efc:      	b.eq	0x9f04 <_stogir.terminal.inputs+0xf0>
    9f00:      	b	0x9f0c <_stogir.terminal.inputs+0xf8>
    9f04:      	b	0x9f10 <_stogir.terminal.inputs+0xfc>
    9f08:      	b	0x9fc8 <_stogir.terminal.inputs+0x1b4>
    9f0c:      	b	0xa17c <_stogir.terminal.inputs+0x368>
    9f10:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009f10:  ARM64_RELOC_PAGE21	l_stogir.433
    9f14:      	ldr	x16, [x16]
		0000000000009f14:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    9f18:      	orr	x0, x16, xzr
    9f1c:      	mov	x1, x0
    9f20:      	mov	x0, #0x1                ; =1
    9f24:      	mov	x2, #0x1d               ; =29
    9f28:      	b	0x9e4c <_stogir.terminal.inputs+0x38>
    9f2c:      	lsl	x1, x5, #4
    9f30:      	ldr	x4, [x0, #0x28]
    9f34:      	add	x1, x1, x4
    9f38:      	ldr	x1, [x1]
    9f3c:      	mov	x4, x1
    9f40:      	mov	x1, #0x1                ; =1
    9f44:      	b	0x9ee0 <_stogir.terminal.inputs+0xcc>
    9f48:      	movz	x4, #0x0, lsl #48
    9f4c:      	cmp	x4, #0x0
    9f50:      	b.eq	0x9ed8 <_stogir.terminal.inputs+0xc4>
    9f54:      	uxtb	w16, w1
    9f58:      	cmp	w16, wzr
    9f5c:      	b.eq	0x9f2c <_stogir.terminal.inputs+0x118>
    9f60:      	lsl	x1, x2, #4
    9f64:      	ldr	x4, [x0]
    9f68:      	add	x1, x1, x4
    9f6c:      	ldr	x1, [x1]
    9f70:      	b	0x9f3c <_stogir.terminal.inputs+0x128>
    9f74:      	movz	x4, #0x0, lsl #48
    9f78:      	b	0x9f4c <_stogir.terminal.inputs+0x138>
    9f7c:      	cmp	x2, #0x0
    9f80:      	b.ge	0x9f48 <_stogir.terminal.inputs+0x134>
    9f84:      	add	x6, x0, #0x28
    9f88:      	add	x7, x0, #0x50
    9f8c:      	ldr	x6, [x6, #0x8]
    9f90:      	ldr	x7, [x7, #0x8]
    9f94:      	cmp	x6, x7
    9f98:      	b.ne	0xa01c <_stogir.terminal.inputs+0x208>
    9f9c:      	cmp	x4, x6
    9fa0:      	b.gt	0xa02c <_stogir.terminal.inputs+0x218>
    9fa4:      	lsl	x4, x5, #2
    9fa8:      	ldr	x6, [x0, #0x50]
    9fac:      	add	x4, x4, x6
    9fb0:      	ldr	w4, [x4]
    9fb4:      	sxtw	x4, w4
    9fb8:      	cmp	x4, #0x0
    9fbc:      	cset	w4, gt
    9fc0:      	ubfx	x4, x4, #0, #8
    9fc4:      	b	0xa030 <_stogir.terminal.inputs+0x21c>
    9fc8:      	cmp	x2, #0x0
    9fcc:      	b.le	0xa000 <_stogir.terminal.inputs+0x1ec>
    9fd0:      	uxtb	w4, w4
    9fd4:      	cmp	x4, #0x83
    9fd8:      	cset	w1, lt
    9fdc:      	uxtb	w16, w1
    9fe0:      	cmp	w16, wzr
    9fe4:      	b.eq	0xa034 <_stogir.terminal.inputs+0x220>
    9fe8:      	adrp	x16, 0x9000 <_stogir.vector.store-inputs+0x60>
		0000000000009fe8:  ARM64_RELOC_PAGE21	l_stogir.434
    9fec:      	ldr	x16, [x16]
		0000000000009fec:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    9ff0:      	orr	x2, x16, xzr
    9ff4:      	add	x2, x4, x2
    9ff8:      	ldrb	w2, [x2]
    9ffc:      	b	0xa038 <_stogir.terminal.inputs+0x224>
    a000:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a000:  ARM64_RELOC_PAGE21	l_stogir.435
    a004:      	ldr	x16, [x16]
		000000000000a004:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    a008:      	orr	x0, x16, xzr
    a00c:      	mov	x1, x0
    a010:      	mov	x0, #0x1                ; =1
    a014:      	mov	x2, #0x2c               ; =44
    a018:      	b	0x9f28 <_stogir.terminal.inputs+0x114>
    a01c:      	movz	x4, #0x0, lsl #48
    a020:      	b	0x9f4c <_stogir.terminal.inputs+0x138>
    a024:      	movz	x4, #0x0, lsl #48
    a028:      	b	0x9f78 <_stogir.terminal.inputs+0x164>
    a02c:      	movz	x4, #0x0, lsl #48
    a030:      	b	0xa020 <_stogir.terminal.inputs+0x20c>
    a034:      	movz	x2, #0x0, lsl #48
    a038:      	uxtb	w2, w2
    a03c:      	and	x2, x2, #0x1
    a040:      	uxtb	w2, w2
    a044:      	cmp	x2, #0x0
    a048:      	b.eq	0xa000 <_stogir.terminal.inputs+0x1ec>
    a04c:      	uxtb	w16, w1
    a050:      	cmp	w16, wzr
    a054:      	b.eq	0xa070 <_stogir.terminal.inputs+0x25c>
    a058:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a058:  ARM64_RELOC_PAGE21	l_stogir.434
    a05c:      	ldr	x16, [x16]
		000000000000a05c:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a060:      	orr	x1, x16, xzr
    a064:      	add	x1, x4, x1
    a068:      	ldrb	w1, [x1]
    a06c:      	b	0xa074 <_stogir.terminal.inputs+0x260>
    a070:      	movz	x1, #0x0, lsl #48
    a074:      	uxtb	w1, w1
    a078:      	and	x1, x1, #0x4
    a07c:      	uxtb	w1, w1
    a080:      	cmp	x1, #0x0
    a084:      	cset	w1, eq
    a088:      	uxtb	w16, w1
    a08c:      	cmp	w16, wzr
    a090:      	cset	x1, eq
    a094:      	cmp	x1, #0x0
    a098:      	b.ne	0xa000 <_stogir.terminal.inputs+0x1ec>
    a09c:      	cmp	x3, #0x0
    a0a0:      	b.ne	0xa0b4 <_stogir.terminal.inputs+0x2a0>
    a0a4:      	movz	x0, #0x0, lsl #48
    a0a8:      	movz	x1, #0x0, lsl #48
    a0ac:      	movz	x2, #0x0, lsl #48
    a0b0:      	b	0xa018 <_stogir.terminal.inputs+0x204>
    a0b4:      	cmp	x3, #0x0
    a0b8:      	cset	w1, gt
    a0bc:      	movz	x16, #0x0, lsl #48
    a0c0:      	sub	x2, x16, x3
    a0c4:      	sub	x4, x2, #0x1
    a0c8:      	uxtb	w16, w1
    a0cc:      	cmp	w16, wzr
    a0d0:      	b.eq	0xa130 <_stogir.terminal.inputs+0x31c>
    a0d4:      	ldr	x2, [x0, #0x8]
    a0d8:      	cmp	x3, x2
    a0dc:      	b.ge	0xa184 <_stogir.terminal.inputs+0x370>
    a0e0:      	add	x2, x0, #0x78
    a0e4:      	ldr	x2, [x2, #0x8]
    a0e8:      	cmp	x3, x2
    a0ec:      	b.ge	0xa25c <_stogir.terminal.inputs+0x448>
    a0f0:      	lsl	x2, x3, #2
    a0f4:      	ldr	x5, [x0, #0x78]
    a0f8:      	add	x2, x2, x5
    a0fc:      	ldr	w2, [x2]
    a100:      	sxtw	x2, w2
    a104:      	cmp	x2, #0x0
    a108:      	cset	w2, ge
    a10c:      	ubfx	x2, x2, #0, #8
    a110:      	b	0xa260 <_stogir.terminal.inputs+0x44c>
    a114:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a114:  ARM64_RELOC_PAGE21	l_stogir.436
    a118:      	ldr	x16, [x16]
		000000000000a118:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    a11c:      	orr	x0, x16, xzr
    a120:      	mov	x1, x0
    a124:      	mov	x0, #0x1                ; =1
    a128:      	mov	x2, #0x2e               ; =46
    a12c:      	b	0xa0b0 <_stogir.terminal.inputs+0x29c>
    a130:      	cmp	x3, #0x0
    a134:      	b.ge	0xa18c <_stogir.terminal.inputs+0x378>
    a138:      	add	x5, x0, #0x28
    a13c:      	add	x6, x0, #0x50
    a140:      	ldr	x5, [x5, #0x8]
    a144:      	ldr	x6, [x6, #0x8]
    a148:      	cmp	x5, x6
    a14c:      	b.ne	0xa254 <_stogir.terminal.inputs+0x440>
    a150:      	cmp	x2, x5
    a154:      	b.gt	0xa264 <_stogir.terminal.inputs+0x450>
    a158:      	lsl	x2, x4, #2
    a15c:      	ldr	x5, [x0, #0x50]
    a160:      	add	x2, x2, x5
    a164:      	ldr	w2, [x2]
    a168:      	sxtw	x2, w2
    a16c:      	cmp	x2, #0x0
    a170:      	cset	w2, gt
    a174:      	ubfx	x2, x2, #0, #8
    a178:      	b	0xa268 <_stogir.terminal.inputs+0x454>
    a17c:      	brk	#0
    a180:      	b	0xa17c <_stogir.terminal.inputs+0x368>
    a184:      	movz	x2, #0x0, lsl #48
    a188:      	b	0xa190 <_stogir.terminal.inputs+0x37c>
    a18c:      	movz	x2, #0x0, lsl #48
    a190:      	cmp	x2, #0x0
    a194:      	b.eq	0xa1d4 <_stogir.terminal.inputs+0x3c0>
    a198:      	uxtb	w16, w1
    a19c:      	cmp	w16, wzr
    a1a0:      	b.eq	0xa1b8 <_stogir.terminal.inputs+0x3a4>
    a1a4:      	lsl	x1, x3, #4
    a1a8:      	ldr	x0, [x0]
    a1ac:      	add	x0, x1, x0
    a1b0:      	ldr	x0, [x0]
    a1b4:      	b	0xa1c8 <_stogir.terminal.inputs+0x3b4>
    a1b8:      	lsl	x1, x4, #4
    a1bc:      	ldr	x0, [x0, #0x28]
    a1c0:      	add	x0, x1, x0
    a1c4:      	ldr	x0, [x0]
    a1c8:      	mov	x1, x0
    a1cc:      	mov	x0, #0x1                ; =1
    a1d0:      	b	0xa1dc <_stogir.terminal.inputs+0x3c8>
    a1d4:      	movz	x0, #0x0, lsl #48
    a1d8:      	movz	x1, #0x0, lsl #48
    a1dc:      	lsr	w0, w0, #0
    a1e0:      	lsr	x16, x0, #0
    a1e4:      	cmp	x16, #0x1
    a1e8:      	b.eq	0xa204 <_stogir.terminal.inputs+0x3f0>
    a1ec:      	b.lo	0xa1f4 <_stogir.terminal.inputs+0x3e0>
    a1f0:      	b	0xa208 <_stogir.terminal.inputs+0x3f4>
    a1f4:      	cmp	x16, #0x0
    a1f8:      	b.eq	0xa200 <_stogir.terminal.inputs+0x3ec>
    a1fc:      	b	0xa208 <_stogir.terminal.inputs+0x3f4>
    a200:      	b	0xa20c <_stogir.terminal.inputs+0x3f8>
    a204:      	b	0xa228 <_stogir.terminal.inputs+0x414>
    a208:      	b	0xa2ac <_stogir.terminal.inputs+0x498>
    a20c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a20c:  ARM64_RELOC_PAGE21	l_stogir.437
    a210:      	ldr	x16, [x16]
		000000000000a210:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    a214:      	orr	x0, x16, xzr
    a218:      	mov	x1, x0
    a21c:      	mov	x0, #0x1                ; =1
    a220:      	mov	x2, #0x1d               ; =29
    a224:      	b	0xa12c <_stogir.terminal.inputs+0x318>
    a228:      	cmp	x3, #0x0
    a22c:      	b.le	0xa114 <_stogir.terminal.inputs+0x300>
    a230:      	uxtb	w1, w1
    a234:      	cmp	x1, #0x83
    a238:      	b.ge	0xa26c <_stogir.terminal.inputs+0x458>
    a23c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a23c:  ARM64_RELOC_PAGE21	l_stogir.434
    a240:      	ldr	x16, [x16]
		000000000000a240:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a244:      	orr	x0, x16, xzr
    a248:      	add	x0, x1, x0
    a24c:      	ldrb	w0, [x0]
    a250:      	b	0xa270 <_stogir.terminal.inputs+0x45c>
    a254:      	movz	x2, #0x0, lsl #48
    a258:      	b	0xa190 <_stogir.terminal.inputs+0x37c>
    a25c:      	movz	x2, #0x0, lsl #48
    a260:      	b	0xa188 <_stogir.terminal.inputs+0x374>
    a264:      	movz	x2, #0x0, lsl #48
    a268:      	b	0xa258 <_stogir.terminal.inputs+0x444>
    a26c:      	movz	x0, #0x0, lsl #48
    a270:      	uxtb	w0, w0
    a274:      	and	x0, x0, #0x8
    a278:      	uxtb	w0, w0
    a27c:      	cmp	x0, #0x0
    a280:      	cset	w0, eq
    a284:      	uxtb	w16, w0
    a288:      	cmp	w16, wzr
    a28c:      	cset	x0, eq
    a290:      	cmp	x0, #0x0
    a294:      	b.eq	0xa114 <_stogir.terminal.inputs+0x300>
    a298:      	and	x0, x3, #0xffffffff
    a29c:      	mov	x1, x0
    a2a0:      	movz	x0, #0x0, lsl #48
    a2a4:      	movz	x2, #0x0, lsl #48
    a2a8:      	b	0xa12c <_stogir.terminal.inputs+0x318>
    a2ac:      	brk	#0
    a2b0:      	b	0xa2ac <_stogir.terminal.inputs+0x498>

000000000000a2b4 <_stogir.switch.switch-inputs>:
    a2b4:      	sxtw	x1, w1
    a2b8:      	cmp	x1, #0x0
    a2bc:      	cset	w3, gt
    a2c0:      	movz	x16, #0x0, lsl #48
    a2c4:      	sub	x4, x16, x1
    a2c8:      	sub	x5, x4, #0x1
    a2cc:      	uxtb	w16, w3
    a2d0:      	cmp	w16, wzr
    a2d4:      	b.eq	0xa318 <_stogir.switch.switch-inputs+0x64>
    a2d8:      	ldr	x4, [x0, #0x8]
    a2dc:      	cmp	x1, x4
    a2e0:      	b.ge	0xa388 <_stogir.switch.switch-inputs+0xd4>
    a2e4:      	add	x4, x0, #0x78
    a2e8:      	ldr	x4, [x4, #0x8]
    a2ec:      	cmp	x1, x4
    a2f0:      	b.ge	0xa470 <_stogir.switch.switch-inputs+0x1bc>
    a2f4:      	lsl	x4, x1, #2
    a2f8:      	ldr	x6, [x0, #0x78]
    a2fc:      	add	x4, x4, x6
    a300:      	ldr	w4, [x4]
    a304:      	sxtw	x4, w4
    a308:      	cmp	x4, #0x0
    a30c:      	cset	w4, ge
    a310:      	ubfx	x4, x4, #0, #8
    a314:      	b	0xa474 <_stogir.switch.switch-inputs+0x1c0>
    a318:      	cmp	x1, #0x0
    a31c:      	b.ge	0xa390 <_stogir.switch.switch-inputs+0xdc>
    a320:      	add	x6, x0, #0x28
    a324:      	add	x7, x0, #0x50
    a328:      	ldr	x6, [x6, #0x8]
    a32c:      	ldr	x7, [x7, #0x8]
    a330:      	cmp	x6, x7
    a334:      	b.ne	0xa364 <_stogir.switch.switch-inputs+0xb0>
    a338:      	cmp	x4, x6
    a33c:      	b.gt	0xa478 <_stogir.switch.switch-inputs+0x1c4>
    a340:      	lsl	x4, x5, #2
    a344:      	ldr	x6, [x0, #0x50]
    a348:      	add	x4, x4, x6
    a34c:      	ldr	w4, [x4]
    a350:      	sxtw	x4, w4
    a354:      	cmp	x4, #0x0
    a358:      	cset	w4, gt
    a35c:      	ubfx	x4, x4, #0, #8
    a360:      	b	0xa47c <_stogir.switch.switch-inputs+0x1c8>
    a364:      	movz	x4, #0x0, lsl #48
    a368:      	b	0xa394 <_stogir.switch.switch-inputs+0xe0>
    a36c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a36c:  ARM64_RELOC_PAGE21	l_stogir.438
    a370:      	ldr	x16, [x16]
		000000000000a370:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    a374:      	orr	x0, x16, xzr
    a378:      	mov	x1, x0
    a37c:      	mov	x0, #0x1                ; =1
    a380:      	mov	x2, #0x16               ; =22
    a384:      	b	0xa428 <_stogir.switch.switch-inputs+0x174>
    a388:      	movz	x4, #0x0, lsl #48
    a38c:      	b	0xa394 <_stogir.switch.switch-inputs+0xe0>
    a390:      	movz	x4, #0x0, lsl #48
    a394:      	cmp	x4, #0x0
    a398:      	b.eq	0xa3d8 <_stogir.switch.switch-inputs+0x124>
    a39c:      	uxtb	w16, w3
    a3a0:      	cmp	w16, wzr
    a3a4:      	b.eq	0xa3bc <_stogir.switch.switch-inputs+0x108>
    a3a8:      	lsl	x3, x1, #4
    a3ac:      	ldr	x4, [x0]
    a3b0:      	add	x3, x3, x4
    a3b4:      	ldr	x3, [x3]
    a3b8:      	b	0xa3cc <_stogir.switch.switch-inputs+0x118>
    a3bc:      	lsl	x3, x5, #4
    a3c0:      	ldr	x4, [x0, #0x28]
    a3c4:      	add	x3, x3, x4
    a3c8:      	ldr	x3, [x3]
    a3cc:      	mov	x4, x3
    a3d0:      	mov	x3, #0x1                ; =1
    a3d4:      	b	0xa3e0 <_stogir.switch.switch-inputs+0x12c>
    a3d8:      	movz	x3, #0x0, lsl #48
    a3dc:      	movz	x4, #0x0, lsl #48
    a3e0:      	lsr	w3, w3, #0
    a3e4:      	lsr	x16, x3, #0
    a3e8:      	cmp	x16, #0x1
    a3ec:      	b.eq	0xa408 <_stogir.switch.switch-inputs+0x154>
    a3f0:      	b.lo	0xa3f8 <_stogir.switch.switch-inputs+0x144>
    a3f4:      	b	0xa40c <_stogir.switch.switch-inputs+0x158>
    a3f8:      	cmp	x16, #0x0
    a3fc:      	b.eq	0xa404 <_stogir.switch.switch-inputs+0x150>
    a400:      	b	0xa40c <_stogir.switch.switch-inputs+0x158>
    a404:      	b	0xa410 <_stogir.switch.switch-inputs+0x15c>
    a408:      	b	0xa438 <_stogir.switch.switch-inputs+0x184>
    a40c:      	b	0xa6a0 <_stogir.switch.switch-inputs+0x3ec>
    a410:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a410:  ARM64_RELOC_PAGE21	l_stogir.439
    a414:      	ldr	x16, [x16]
		000000000000a414:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    a418:      	orr	x0, x16, xzr
    a41c:      	mov	x1, x0
    a420:      	mov	x0, #0x1                ; =1
    a424:      	mov	x2, #0x16               ; =22
    a428:      	str	x0, [x8]
    a42c:      	str	x1, [x8, #0x8]
    a430:      	str	x2, [x8, #0x10]
    a434:      	ret
    a438:      	cmp	x1, #0x0
    a43c:      	b.le	0xa36c <_stogir.switch.switch-inputs+0xb8>
    a440:      	uxtb	w4, w4
    a444:      	cmp	x4, #0x83
    a448:      	cset	w1, lt
    a44c:      	uxtb	w16, w1
    a450:      	cmp	w16, wzr
    a454:      	b.eq	0xa480 <_stogir.switch.switch-inputs+0x1cc>
    a458:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a458:  ARM64_RELOC_PAGE21	l_stogir.440
    a45c:      	ldr	x16, [x16]
		000000000000a45c:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a460:      	orr	x3, x16, xzr
    a464:      	add	x3, x4, x3
    a468:      	ldrb	w3, [x3]
    a46c:      	b	0xa484 <_stogir.switch.switch-inputs+0x1d0>
    a470:      	movz	x4, #0x0, lsl #48
    a474:      	b	0xa38c <_stogir.switch.switch-inputs+0xd8>
    a478:      	movz	x4, #0x0, lsl #48
    a47c:      	b	0xa368 <_stogir.switch.switch-inputs+0xb4>
    a480:      	movz	x3, #0x0, lsl #48
    a484:      	uxtb	w3, w3
    a488:      	and	x3, x3, #0x1
    a48c:      	uxtb	w3, w3
    a490:      	cmp	x3, #0x0
    a494:      	b.eq	0xa36c <_stogir.switch.switch-inputs+0xb8>
    a498:      	uxtb	w16, w1
    a49c:      	cmp	w16, wzr
    a4a0:      	b.eq	0xa4bc <_stogir.switch.switch-inputs+0x208>
    a4a4:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a4a4:  ARM64_RELOC_PAGE21	l_stogir.440
    a4a8:      	ldr	x16, [x16]
		000000000000a4a8:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a4ac:      	orr	x1, x16, xzr
    a4b0:      	add	x1, x4, x1
    a4b4:      	ldrb	w1, [x1]
    a4b8:      	b	0xa4c0 <_stogir.switch.switch-inputs+0x20c>
    a4bc:      	movz	x1, #0x0, lsl #48
    a4c0:      	uxtb	w1, w1
    a4c4:      	and	x1, x1, #0x4
    a4c8:      	uxtb	w1, w1
    a4cc:      	cmp	x1, #0x0
    a4d0:      	cset	w1, eq
    a4d4:      	uxtb	w16, w1
    a4d8:      	cmp	w16, wzr
    a4dc:      	cset	x1, eq
    a4e0:      	cmp	x1, #0x0
    a4e4:      	b.ne	0xa36c <_stogir.switch.switch-inputs+0xb8>
    a4e8:      	sxtw	x2, w2
    a4ec:      	cmp	x2, #0x0
    a4f0:      	cset	w1, gt
    a4f4:      	movz	x16, #0x0, lsl #48
    a4f8:      	sub	x3, x16, x2
    a4fc:      	sub	x4, x3, #0x1
    a500:      	uxtb	w16, w1
    a504:      	cmp	w16, wzr
    a508:      	b.eq	0xa568 <_stogir.switch.switch-inputs+0x2b4>
    a50c:      	ldr	x3, [x0, #0x8]
    a510:      	cmp	x2, x3
    a514:      	b.ge	0xa5b4 <_stogir.switch.switch-inputs+0x300>
    a518:      	add	x3, x0, #0x78
    a51c:      	ldr	x3, [x3, #0x8]
    a520:      	cmp	x2, x3
    a524:      	b.ge	0xa698 <_stogir.switch.switch-inputs+0x3e4>
    a528:      	lsl	x3, x2, #2
    a52c:      	ldr	x5, [x0, #0x78]
    a530:      	add	x3, x3, x5
    a534:      	ldr	w3, [x3]
    a538:      	sxtw	x3, w3
    a53c:      	cmp	x3, #0x0
    a540:      	cset	w3, ge
    a544:      	ubfx	x3, x3, #0, #8
    a548:      	b	0xa69c <_stogir.switch.switch-inputs+0x3e8>
    a54c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a54c:  ARM64_RELOC_PAGE21	l_stogir.441
    a550:      	ldr	x16, [x16]
		000000000000a550:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    a554:      	orr	x0, x16, xzr
    a558:      	mov	x1, x0
    a55c:      	mov	x0, #0x1                ; =1
    a560:      	mov	x2, #0x20               ; =32
    a564:      	b	0xa384 <_stogir.switch.switch-inputs+0xd0>
    a568:      	cmp	x2, #0x0
    a56c:      	b.ge	0xa5bc <_stogir.switch.switch-inputs+0x308>
    a570:      	add	x5, x0, #0x28
    a574:      	add	x6, x0, #0x50
    a578:      	ldr	x5, [x5, #0x8]
    a57c:      	ldr	x6, [x6, #0x8]
    a580:      	cmp	x5, x6
    a584:      	b.ne	0xa690 <_stogir.switch.switch-inputs+0x3dc>
    a588:      	cmp	x3, x5
    a58c:      	b.gt	0xa6a8 <_stogir.switch.switch-inputs+0x3f4>
    a590:      	lsl	x3, x4, #2
    a594:      	ldr	x5, [x0, #0x50]
    a598:      	add	x3, x3, x5
    a59c:      	ldr	w3, [x3]
    a5a0:      	sxtw	x3, w3
    a5a4:      	cmp	x3, #0x0
    a5a8:      	cset	w3, gt
    a5ac:      	ubfx	x3, x3, #0, #8
    a5b0:      	b	0xa6ac <_stogir.switch.switch-inputs+0x3f8>
    a5b4:      	movz	x3, #0x0, lsl #48
    a5b8:      	b	0xa5c0 <_stogir.switch.switch-inputs+0x30c>
    a5bc:      	movz	x3, #0x0, lsl #48
    a5c0:      	cmp	x3, #0x0
    a5c4:      	b.eq	0xa604 <_stogir.switch.switch-inputs+0x350>
    a5c8:      	uxtb	w16, w1
    a5cc:      	cmp	w16, wzr
    a5d0:      	b.eq	0xa5e8 <_stogir.switch.switch-inputs+0x334>
    a5d4:      	lsl	x1, x2, #4
    a5d8:      	ldr	x0, [x0]
    a5dc:      	add	x0, x1, x0
    a5e0:      	ldr	x0, [x0]
    a5e4:      	b	0xa5f8 <_stogir.switch.switch-inputs+0x344>
    a5e8:      	lsl	x1, x4, #4
    a5ec:      	ldr	x0, [x0, #0x28]
    a5f0:      	add	x0, x1, x0
    a5f4:      	ldr	x0, [x0]
    a5f8:      	mov	x1, x0
    a5fc:      	mov	x0, #0x1                ; =1
    a600:      	b	0xa60c <_stogir.switch.switch-inputs+0x358>
    a604:      	movz	x0, #0x0, lsl #48
    a608:      	movz	x1, #0x0, lsl #48
    a60c:      	lsr	w0, w0, #0
    a610:      	lsr	x16, x0, #0
    a614:      	cmp	x16, #0x1
    a618:      	b.eq	0xa634 <_stogir.switch.switch-inputs+0x380>
    a61c:      	b.lo	0xa624 <_stogir.switch.switch-inputs+0x370>
    a620:      	b	0xa638 <_stogir.switch.switch-inputs+0x384>
    a624:      	cmp	x16, #0x0
    a628:      	b.eq	0xa630 <_stogir.switch.switch-inputs+0x37c>
    a62c:      	b	0xa638 <_stogir.switch.switch-inputs+0x384>
    a630:      	b	0xa63c <_stogir.switch.switch-inputs+0x388>
    a634:      	b	0xa658 <_stogir.switch.switch-inputs+0x3a4>
    a638:      	b	0xa6b0 <_stogir.switch.switch-inputs+0x3fc>
    a63c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a63c:  ARM64_RELOC_PAGE21	l_stogir.442
    a640:      	ldr	x16, [x16]
		000000000000a640:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    a644:      	orr	x0, x16, xzr
    a648:      	mov	x1, x0
    a64c:      	mov	x0, #0x1                ; =1
    a650:      	mov	x2, #0x17               ; =23
    a654:      	b	0xa564 <_stogir.switch.switch-inputs+0x2b0>
    a658:      	lsr	w0, w1, #0
    a65c:      	ubfx	x0, x0, #8, #8
    a660:      	cmp	x0, #0x1
    a664:      	b.lt	0xa54c <_stogir.switch.switch-inputs+0x298>
    a668:      	cmp	x0, #0xb
    a66c:      	b.gt	0xa54c <_stogir.switch.switch-inputs+0x298>
    a670:      	uxtb	w1, w1
    a674:      	cmp	x1, #0x48
    a678:      	b.eq	0xa54c <_stogir.switch.switch-inputs+0x298>
    a67c:      	and	x0, x0, #0xffffffff
    a680:      	mov	x1, x0
    a684:      	movz	x0, #0x0, lsl #48
    a688:      	movz	x2, #0x0, lsl #48
    a68c:      	b	0xa564 <_stogir.switch.switch-inputs+0x2b0>
    a690:      	movz	x3, #0x0, lsl #48
    a694:      	b	0xa5c0 <_stogir.switch.switch-inputs+0x30c>
    a698:      	movz	x3, #0x0, lsl #48
    a69c:      	b	0xa5b8 <_stogir.switch.switch-inputs+0x304>
    a6a0:      	brk	#0
    a6a4:      	b	0xa6a0 <_stogir.switch.switch-inputs+0x3ec>
    a6a8:      	movz	x3, #0x0, lsl #48
    a6ac:      	b	0xa694 <_stogir.switch.switch-inputs+0x3e0>
    a6b0:      	brk	#0
    a6b4:      	b	0xa6b0 <_stogir.switch.switch-inputs+0x3fc>

000000000000a6b8 <_stogir.switch.case-inputs>:
    a6b8:      	sub	sp, sp, #0xc0
    a6bc:      	str	x29, [sp]
    a6c0:      	str	x30, [sp, #0x8]
    a6c4:      	mov	x29, sp
    a6c8:      	str	x19, [sp, #0x80]
    a6cc:      	str	x20, [sp, #0x88]
    a6d0:      	str	x21, [sp, #0x90]
    a6d4:      	str	x22, [sp, #0x98]
    a6d8:      	str	x23, [sp, #0xa0]
    a6dc:      	str	x24, [sp, #0xa8]
    a6e0:      	str	x25, [sp, #0xb0]
    a6e4:      	str	x26, [sp, #0xb8]
    a6e8:      	sxtw	x2, w2
    a6ec:      	lsl	x5, x2, #2
    a6f0:      	cmp	x2, #0x0
    a6f4:      	cset	w6, gt
    a6f8:      	movz	x16, #0x0, lsl #48
    a6fc:      	sub	x7, x16, x2
    a700:      	sub	x9, x7, #0x1
    a704:      	uxtb	w16, w6
    a708:      	cmp	w16, wzr
    a70c:      	b.eq	0xa74c <_stogir.switch.case-inputs+0x94>
    a710:      	ldr	x7, [x0, #0x8]
    a714:      	cmp	x2, x7
    a718:      	b.ge	0xa7a0 <_stogir.switch.case-inputs+0xe8>
    a71c:      	add	x7, x0, #0x78
    a720:      	ldr	x7, [x7, #0x8]
    a724:      	cmp	x2, x7
    a728:      	b.ge	0xa8e0 <_stogir.switch.case-inputs+0x228>
    a72c:      	ldr	x7, [x0, #0x78]
    a730:      	add	x7, x5, x7
    a734:      	ldr	w7, [x7]
    a738:      	sxtw	x7, w7
    a73c:      	cmp	x7, #0x0
    a740:      	cset	w7, ge
    a744:      	ubfx	x7, x7, #0, #8
    a748:      	b	0xa8e4 <_stogir.switch.case-inputs+0x22c>
    a74c:      	cmp	x2, #0x0
    a750:      	b.ge	0xa7a8 <_stogir.switch.case-inputs+0xf0>
    a754:      	add	x10, x0, #0x28
    a758:      	add	x11, x0, #0x50
    a75c:      	ldr	x10, [x10, #0x8]
    a760:      	ldr	x11, [x11, #0x8]
    a764:      	cmp	x10, x11
    a768:      	b.ne	0xa798 <_stogir.switch.case-inputs+0xe0>
    a76c:      	cmp	x7, x10
    a770:      	b.gt	0xa9bc <_stogir.switch.case-inputs+0x304>
    a774:      	lsl	x7, x9, #2
    a778:      	ldr	x10, [x0, #0x50]
    a77c:      	add	x7, x7, x10
    a780:      	ldr	w7, [x7]
    a784:      	sxtw	x7, w7
    a788:      	cmp	x7, #0x0
    a78c:      	cset	w7, gt
    a790:      	ubfx	x7, x7, #0, #8
    a794:      	b	0xa9c0 <_stogir.switch.case-inputs+0x308>
    a798:      	movz	x7, #0x0, lsl #48
    a79c:      	b	0xa7ac <_stogir.switch.case-inputs+0xf4>
    a7a0:      	movz	x7, #0x0, lsl #48
    a7a4:      	b	0xa7ac <_stogir.switch.case-inputs+0xf4>
    a7a8:      	movz	x7, #0x0, lsl #48
    a7ac:      	cmp	x7, #0x0
    a7b0:      	b.eq	0xa814 <_stogir.switch.case-inputs+0x15c>
    a7b4:      	uxtb	w16, w6
    a7b8:      	cmp	w16, wzr
    a7bc:      	b.eq	0xa7e4 <_stogir.switch.case-inputs+0x12c>
    a7c0:      	lsl	x6, x2, #4
    a7c4:      	ldr	x7, [x0]
    a7c8:      	add	x6, x6, x7
    a7cc:      	ldr	x7, [x6]
    a7d0:      	ldr	x6, [x6, #0x8]
    a7d4:      	fmov	d31, x6
    a7d8:      	mov	x6, x7
    a7dc:      	fmov	x7, d31
    a7e0:      	b	0xa804 <_stogir.switch.case-inputs+0x14c>
    a7e4:      	lsl	x6, x9, #4
    a7e8:      	ldr	x7, [x0, #0x28]
    a7ec:      	add	x6, x6, x7
    a7f0:      	ldr	x7, [x6]
    a7f4:      	ldr	x6, [x6, #0x8]
    a7f8:      	fmov	d31, x6
    a7fc:      	mov	x6, x7
    a800:      	fmov	x7, d31
    a804:      	mov	x9, x7
    a808:      	mov	x7, x6
    a80c:      	mov	x6, #0x1                ; =1
    a810:      	b	0xa820 <_stogir.switch.case-inputs+0x168>
    a814:      	movz	x6, #0x0, lsl #48
    a818:      	movz	x7, #0x0, lsl #48
    a81c:      	movz	x9, #0x0, lsl #48
    a820:      	lsr	w6, w6, #0
    a824:      	lsr	x16, x6, #0
    a828:      	cmp	x16, #0x1
    a82c:      	b.eq	0xa848 <_stogir.switch.case-inputs+0x190>
    a830:      	b.lo	0xa838 <_stogir.switch.case-inputs+0x180>
    a834:      	b	0xa84c <_stogir.switch.case-inputs+0x194>
    a838:      	cmp	x16, #0x0
    a83c:      	b.eq	0xa844 <_stogir.switch.case-inputs+0x18c>
    a840:      	b	0xa84c <_stogir.switch.case-inputs+0x194>
    a844:      	b	0xa850 <_stogir.switch.case-inputs+0x198>
    a848:      	b	0xa8a8 <_stogir.switch.case-inputs+0x1f0>
    a84c:      	b	0xa9c4 <_stogir.switch.case-inputs+0x30c>
    a850:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a850:  ARM64_RELOC_PAGE21	l_stogir.443
    a854:      	ldr	x16, [x16]
		000000000000a854:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a858:      	orr	x0, x16, xzr
    a85c:      	mov	x21, x8
    a860:      	mov	x1, x0
    a864:      	mov	x0, #0x1                ; =1
    a868:      	mov	x2, #0x1a               ; =26
    a86c:      	str	x0, [x21]
    a870:      	str	x1, [x21, #0x8]
    a874:      	str	x2, [x21, #0x10]
    a878:      	ldr	x19, [sp, #0x80]
    a87c:      	ldr	x20, [sp, #0x88]
    a880:      	ldr	x21, [sp, #0x90]
    a884:      	ldr	x22, [sp, #0x98]
    a888:      	ldr	x23, [sp, #0xa0]
    a88c:      	ldr	x24, [sp, #0xa8]
    a890:      	ldr	x25, [sp, #0xb0]
    a894:      	ldr	x26, [sp, #0xb8]
    a898:      	ldr	x29, [sp]
    a89c:      	ldr	x30, [sp, #0x8]
    a8a0:      	add	sp, sp, #0xc0
    a8a4:      	ret
    a8a8:      	add	x16, sp, #0x10
    a8ac:      	str	x7, [x16]
    a8b0:      	add	x16, sp, #0x10
    a8b4:      	str	x9, [x16, #0x8]
    a8b8:      	cmp	x2, #0x0
    a8bc:      	b.gt	0xa8e8 <_stogir.switch.case-inputs+0x230>
    a8c0:      	mov	x21, x8
    a8c4:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000a8c4:  ARM64_RELOC_PAGE21	l_stogir.444
    a8c8:      	ldr	x16, [x16]
		000000000000a8c8:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    a8cc:      	orr	x0, x16, xzr
    a8d0:      	mov	x1, x0
    a8d4:      	mov	x0, #0x1                ; =1
    a8d8:      	mov	x2, #0x1f               ; =31
    a8dc:      	b	0xa86c <_stogir.switch.case-inputs+0x1b4>
    a8e0:      	movz	x7, #0x0, lsl #48
    a8e4:      	b	0xa7a4 <_stogir.switch.case-inputs+0xec>
    a8e8:      	add	x16, sp, #0x10
    a8ec:      	ldr	w2, [x16]
    a8f0:      	uxtb	w6, w2
    a8f4:      	cmp	x6, #0x75
    a8f8:      	b.ne	0xab54 <_stogir.switch.case-inputs+0x49c>
    a8fc:      	ubfx	x2, x2, #8, #8
    a900:      	cmp	x2, #0x0
    a904:      	b.ne	0xab5c <_stogir.switch.case-inputs+0x4a4>
    a908:      	ldr	x2, [x0, #0x78]
    a90c:      	add	x2, x5, x2
    a910:      	ldr	w2, [x2]
    a914:      	sxtw	x2, w2
    a918:      	cmp	x2, #0x2
    a91c:      	b.ne	0xab64 <_stogir.switch.case-inputs+0x4ac>
    a920:      	sxtw	x19, w1
    a924:      	cmp	x19, #0x6d
    a928:      	b.lt	0xab6c <_stogir.switch.case-inputs+0x4b4>
    a92c:      	cmp	x19, #0x6f
    a930:      	b.gt	0xab74 <_stogir.switch.case-inputs+0x4bc>
    a934:      	add	x16, sp, #0x20
    a938:      	orr	x20, x16, xzr
    a93c:      	add	x16, sp, #0x10
    a940:      	ldr	w1, [x16, #0x4]
    a944:      	add	x16, sp, #0x10
    a948:      	ldr	w2, [x16, #0x8]
    a94c:      	lsr	w1, w1, #0
    a950:      	lsr	w2, w2, #0
    a954:      	mov	x21, x8
    a958:      	add	x8, sp, #0x20
    a95c:      	mov	x22, x0
    a960:      	mov	w23, w3
    a964:      	mov	w24, w4
    a968:      	bl	0xa968 <_stogir.switch.case-inputs+0x2b0>
		000000000000a968:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    a96c:      	add	x16, sp, #0x20
    a970:      	ldr	w0, [x16]
    a974:      	lsr	x16, x0, #0
    a978:      	cmp	x16, #0x1
    a97c:      	b.eq	0xa998 <_stogir.switch.case-inputs+0x2e0>
    a980:      	b.lo	0xa988 <_stogir.switch.case-inputs+0x2d0>
    a984:      	b	0xa99c <_stogir.switch.case-inputs+0x2e4>
    a988:      	cmp	x16, #0x0
    a98c:      	b.eq	0xa994 <_stogir.switch.case-inputs+0x2dc>
    a990:      	b	0xa99c <_stogir.switch.case-inputs+0x2e4>
    a994:      	b	0xa9cc <_stogir.switch.case-inputs+0x314>
    a998:      	b	0xa9a0 <_stogir.switch.case-inputs+0x2e8>
    a99c:      	b	0xab3c <_stogir.switch.case-inputs+0x484>
    a9a0:      	add	x0, x20, #0x8
    a9a4:      	add	x16, sp, #0x20
    a9a8:      	ldr	x1, [x16, #0x8]
    a9ac:      	ldr	x0, [x0, #0x8]
    a9b0:      	mov	x2, x0
    a9b4:      	mov	x0, #0x1                ; =1
    a9b8:      	b	0xa8dc <_stogir.switch.case-inputs+0x224>
    a9bc:      	movz	x7, #0x0, lsl #48
    a9c0:      	b	0xa79c <_stogir.switch.case-inputs+0xe4>
    a9c4:      	brk	#0
    a9c8:      	b	0xa9c4 <_stogir.switch.case-inputs+0x30c>
    a9cc:      	add	x16, sp, #0x20
    a9d0:      	ldr	w20, [x16, #0x8]
    a9d4:      	sxtw	x0, w20
    a9d8:      	and	x25, x0, #0xffffffff
    a9dc:      	cmp	x19, #0x6f
    a9e0:      	b.ne	0xa9f4 <_stogir.switch.case-inputs+0x33c>
    a9e4:      	mov	x1, x25
    a9e8:      	movz	x0, #0x0, lsl #48
    a9ec:      	movz	x2, #0x0, lsl #48
    a9f0:      	b	0xa9b8 <_stogir.switch.case-inputs+0x300>
    a9f4:      	add	x16, sp, #0x40
    a9f8:      	orr	x26, x16, xzr
    a9fc:      	lsr	w23, w23, #0
    aa00:      	lsr	w20, w20, #0
    aa04:      	add	x8, sp, #0x40
    aa08:      	mov	x0, x22
    aa0c:      	mov	w1, w23
    aa10:      	mov	w2, w20
    aa14:      	bl	0xaa14 <_stogir.switch.case-inputs+0x35c>
		000000000000aa14:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    aa18:      	add	x16, sp, #0x40
    aa1c:      	ldr	w0, [x16]
    aa20:      	lsr	x16, x0, #0
    aa24:      	cmp	x16, #0x1
    aa28:      	b.eq	0xaa44 <_stogir.switch.case-inputs+0x38c>
    aa2c:      	b.lo	0xaa34 <_stogir.switch.case-inputs+0x37c>
    aa30:      	b	0xaa48 <_stogir.switch.case-inputs+0x390>
    aa34:      	cmp	x16, #0x0
    aa38:      	b.eq	0xaa40 <_stogir.switch.case-inputs+0x388>
    aa3c:      	b	0xaa48 <_stogir.switch.case-inputs+0x390>
    aa40:      	b	0xaa68 <_stogir.switch.case-inputs+0x3b0>
    aa44:      	b	0xaa4c <_stogir.switch.case-inputs+0x394>
    aa48:      	b	0xab44 <_stogir.switch.case-inputs+0x48c>
    aa4c:      	add	x0, x26, #0x8
    aa50:      	add	x16, sp, #0x40
    aa54:      	ldr	x1, [x16, #0x8]
    aa58:      	ldr	x0, [x0, #0x8]
    aa5c:      	mov	x2, x0
    aa60:      	mov	x0, #0x1                ; =1
    aa64:      	b	0xa9f0 <_stogir.switch.case-inputs+0x338>
    aa68:      	add	x16, sp, #0x40
    aa6c:      	ldr	x26, [x16, #0x8]
    aa70:      	cmp	x19, #0x6d
    aa74:      	b.ne	0xaa94 <_stogir.switch.case-inputs+0x3dc>
    aa78:      	sxtw	x23, w23
    aa7c:      	mov	x0, x23
    aa80:      	b	0xaa9c <_stogir.switch.case-inputs+0x3e4>
    aa84:      	mov	x1, x25
    aa88:      	movz	x0, #0x0, lsl #48
    aa8c:      	movz	x2, #0x0, lsl #48
    aa90:      	b	0xaa64 <_stogir.switch.case-inputs+0x3ac>
    aa94:      	sxtw	x24, w24
    aa98:      	mov	x0, x24
    aa9c:      	add	x16, sp, #0x60
    aaa0:      	orr	x19, x16, xzr
    aaa4:      	lsr	w20, w20, #0
    aaa8:      	lsr	w0, w0, #0
    aaac:      	add	x8, sp, #0x60
    aab0:      	mov	w1, w0
    aab4:      	mov	x0, x22
    aab8:      	mov	w2, w20
    aabc:      	bl	0xaabc <_stogir.switch.case-inputs+0x404>
		000000000000aabc:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    aac0:      	add	x16, sp, #0x60
    aac4:      	ldr	w0, [x16]
    aac8:      	lsr	x16, x0, #0
    aacc:      	cmp	x16, #0x1
    aad0:      	b.eq	0xaaec <_stogir.switch.case-inputs+0x434>
    aad4:      	b.lo	0xaadc <_stogir.switch.case-inputs+0x424>
    aad8:      	b	0xaaf0 <_stogir.switch.case-inputs+0x438>
    aadc:      	cmp	x16, #0x0
    aae0:      	b.eq	0xaae8 <_stogir.switch.case-inputs+0x430>
    aae4:      	b	0xaaf0 <_stogir.switch.case-inputs+0x438>
    aae8:      	b	0xab10 <_stogir.switch.case-inputs+0x458>
    aaec:      	b	0xaaf4 <_stogir.switch.case-inputs+0x43c>
    aaf0:      	b	0xab4c <_stogir.switch.case-inputs+0x494>
    aaf4:      	add	x0, x19, #0x8
    aaf8:      	add	x16, sp, #0x60
    aafc:      	ldr	x1, [x16, #0x8]
    ab00:      	ldr	x0, [x0, #0x8]
    ab04:      	mov	x2, x0
    ab08:      	mov	x0, #0x1                ; =1
    ab0c:      	b	0xaa90 <_stogir.switch.case-inputs+0x3d8>
    ab10:      	add	x16, sp, #0x60
    ab14:      	ldr	x0, [x16, #0x8]
    ab18:      	cmp	x26, x0
    ab1c:      	b.ls	0xaa84 <_stogir.switch.case-inputs+0x3cc>
    ab20:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000ab20:  ARM64_RELOC_PAGE21	l_stogir.445
    ab24:      	ldr	x16, [x16]
		000000000000ab24:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    ab28:      	orr	x0, x16, xzr
    ab2c:      	mov	x1, x0
    ab30:      	mov	x0, #0x1                ; =1
    ab34:      	mov	x2, #0x1a               ; =26
    ab38:      	b	0xaa90 <_stogir.switch.case-inputs+0x3d8>
    ab3c:      	brk	#0
    ab40:      	b	0xab3c <_stogir.switch.case-inputs+0x484>
    ab44:      	brk	#0
    ab48:      	b	0xab44 <_stogir.switch.case-inputs+0x48c>
    ab4c:      	brk	#0
    ab50:      	b	0xab4c <_stogir.switch.case-inputs+0x494>
    ab54:      	mov	x21, x8
    ab58:      	b	0xa8c4 <_stogir.switch.case-inputs+0x20c>
    ab5c:      	mov	x21, x8
    ab60:      	b	0xa8c4 <_stogir.switch.case-inputs+0x20c>
    ab64:      	mov	x21, x8
    ab68:      	b	0xa8c4 <_stogir.switch.case-inputs+0x20c>
    ab6c:      	mov	x21, x8
    ab70:      	b	0xa8c4 <_stogir.switch.case-inputs+0x20c>
    ab74:      	mov	x21, x8
    ab78:      	b	0xa8c4 <_stogir.switch.case-inputs+0x20c>

000000000000ab7c <_stogir.stack.validate-frame-address>:
    ab7c:      	sxtw	x1, w1
    ab80:      	lsl	x2, x1, #2
    ab84:      	cmp	x1, #0x0
    ab88:      	cset	w3, gt
    ab8c:      	movz	x16, #0x0, lsl #48
    ab90:      	sub	x4, x16, x1
    ab94:      	sub	x5, x4, #0x1
    ab98:      	uxtb	w16, w3
    ab9c:      	cmp	w16, wzr
    aba0:      	b.eq	0xabe0 <_stogir.stack.validate-frame-address+0x64>
    aba4:      	ldr	x4, [x0, #0x8]
    aba8:      	cmp	x1, x4
    abac:      	b.ge	0xac34 <_stogir.stack.validate-frame-address+0xb8>
    abb0:      	add	x4, x0, #0x78
    abb4:      	ldr	x4, [x4, #0x8]
    abb8:      	cmp	x1, x4
    abbc:      	b.ge	0xad4c <_stogir.stack.validate-frame-address+0x1d0>
    abc0:      	ldr	x4, [x0, #0x78]
    abc4:      	add	x4, x2, x4
    abc8:      	ldr	w4, [x4]
    abcc:      	sxtw	x4, w4
    abd0:      	cmp	x4, #0x0
    abd4:      	cset	w4, ge
    abd8:      	ubfx	x4, x4, #0, #8
    abdc:      	b	0xad50 <_stogir.stack.validate-frame-address+0x1d4>
    abe0:      	cmp	x1, #0x0
    abe4:      	b.ge	0xac3c <_stogir.stack.validate-frame-address+0xc0>
    abe8:      	add	x6, x0, #0x28
    abec:      	add	x7, x0, #0x50
    abf0:      	ldr	x6, [x6, #0x8]
    abf4:      	ldr	x7, [x7, #0x8]
    abf8:      	cmp	x6, x7
    abfc:      	b.ne	0xac2c <_stogir.stack.validate-frame-address+0xb0>
    ac00:      	cmp	x4, x6
    ac04:      	b.gt	0xad54 <_stogir.stack.validate-frame-address+0x1d8>
    ac08:      	lsl	x4, x5, #2
    ac0c:      	ldr	x6, [x0, #0x50]
    ac10:      	add	x4, x4, x6
    ac14:      	ldr	w4, [x4]
    ac18:      	sxtw	x4, w4
    ac1c:      	cmp	x4, #0x0
    ac20:      	cset	w4, gt
    ac24:      	ubfx	x4, x4, #0, #8
    ac28:      	b	0xad58 <_stogir.stack.validate-frame-address+0x1dc>
    ac2c:      	movz	x4, #0x0, lsl #48
    ac30:      	b	0xac40 <_stogir.stack.validate-frame-address+0xc4>
    ac34:      	movz	x4, #0x0, lsl #48
    ac38:      	b	0xac40 <_stogir.stack.validate-frame-address+0xc4>
    ac3c:      	movz	x4, #0x0, lsl #48
    ac40:      	cmp	x4, #0x0
    ac44:      	b.eq	0xac84 <_stogir.stack.validate-frame-address+0x108>
    ac48:      	uxtb	w16, w3
    ac4c:      	cmp	w16, wzr
    ac50:      	b.eq	0xac68 <_stogir.stack.validate-frame-address+0xec>
    ac54:      	lsl	x3, x1, #4
    ac58:      	ldr	x4, [x0]
    ac5c:      	add	x3, x3, x4
    ac60:      	ldr	x3, [x3]
    ac64:      	b	0xac78 <_stogir.stack.validate-frame-address+0xfc>
    ac68:      	lsl	x3, x5, #4
    ac6c:      	ldr	x4, [x0, #0x28]
    ac70:      	add	x3, x3, x4
    ac74:      	ldr	x3, [x3]
    ac78:      	mov	x4, x3
    ac7c:      	mov	x3, #0x1                ; =1
    ac80:      	b	0xac8c <_stogir.stack.validate-frame-address+0x110>
    ac84:      	movz	x3, #0x0, lsl #48
    ac88:      	movz	x4, #0x0, lsl #48
    ac8c:      	lsr	w3, w3, #0
    ac90:      	lsr	x16, x3, #0
    ac94:      	cmp	x16, #0x1
    ac98:      	b.eq	0xacb4 <_stogir.stack.validate-frame-address+0x138>
    ac9c:      	b.lo	0xaca4 <_stogir.stack.validate-frame-address+0x128>
    aca0:      	b	0xacb8 <_stogir.stack.validate-frame-address+0x13c>
    aca4:      	cmp	x16, #0x0
    aca8:      	b.eq	0xacb0 <_stogir.stack.validate-frame-address+0x134>
    acac:      	b	0xacb8 <_stogir.stack.validate-frame-address+0x13c>
    acb0:      	b	0xacbc <_stogir.stack.validate-frame-address+0x140>
    acb4:      	b	0xad00 <_stogir.stack.validate-frame-address+0x184>
    acb8:      	b	0xad5c <_stogir.stack.validate-frame-address+0x1e0>
    acbc:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000acbc:  ARM64_RELOC_PAGE21	l_stogir.446
    acc0:      	ldr	x16, [x16]
		000000000000acc0:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    acc4:      	orr	x0, x16, xzr
    acc8:      	mov	x1, x0
    accc:      	mov	x0, #0x1                ; =1
    acd0:      	mov	x2, #0x21               ; =33
    acd4:      	b	0xacf0 <_stogir.stack.validate-frame-address+0x174>
    acd8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0x1ec>
		000000000000acd8:  ARM64_RELOC_PAGE21	l_stogir.447
    acdc:      	ldr	x16, [x16]
		000000000000acdc:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    ace0:      	orr	x0, x16, xzr
    ace4:      	mov	x1, x0
    ace8:      	mov	x0, #0x1                ; =1
    acec:      	mov	x2, #0x1e               ; =30
    acf0:      	str	x0, [x8]
    acf4:      	str	x1, [x8, #0x8]
    acf8:      	str	x2, [x8, #0x10]
    acfc:      	ret
    ad00:      	cmp	x1, #0x0
    ad04:      	b.le	0xacd8 <_stogir.stack.validate-frame-address+0x15c>
    ad08:      	uxtb	w1, w4
    ad0c:      	cmp	x1, #0x42
    ad10:      	b.ne	0xacd8 <_stogir.stack.validate-frame-address+0x15c>
    ad14:      	lsr	w4, w4, #0
    ad18:      	ubfx	x1, x4, #8, #8
    ad1c:      	cmp	x1, #0x6
    ad20:      	b.ne	0xacd8 <_stogir.stack.validate-frame-address+0x15c>
    ad24:      	ldr	x0, [x0, #0x78]
    ad28:      	add	x0, x2, x0
    ad2c:      	ldr	w0, [x0]
    ad30:      	sxtw	x0, w0
    ad34:      	cmp	x0, #0x0
    ad38:      	b.ne	0xacd8 <_stogir.stack.validate-frame-address+0x15c>
    ad3c:      	movz	x0, #0x0, lsl #48
    ad40:      	mov	x1, #0x8                ; =8
    ad44:      	movz	x2, #0x0, lsl #48
    ad48:      	b	0xacf0 <_stogir.stack.validate-frame-address+0x174>
    ad4c:      	movz	x4, #0x0, lsl #48
    ad50:      	b	0xac38 <_stogir.stack.validate-frame-address+0xbc>
    ad54:      	movz	x4, #0x0, lsl #48
    ad58:      	b	0xac30 <_stogir.stack.validate-frame-address+0xb4>
    ad5c:      	brk	#0
    ad60:      	b	0xad5c <_stogir.stack.validate-frame-address+0x1e0>

000000000000ad64 <_stogir.stack.frame-object?>:
    ad64:      	ldr	w0, [x0]
    ad68:      	uxtb	w1, w0
    ad6c:      	cmp	x1, #0x51
    ad70:      	b.ne	0xad88 <_stogir.stack.frame-object?+0x24>
    ad74:      	ubfx	x0, x0, #16, #16
    ad78:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    ad7c:      	cset	w0, eq
    ad80:      	ubfx	x0, x0, #0, #8
    ad84:      	b	0xad8c <_stogir.stack.frame-object?+0x28>
    ad88:      	movz	x0, #0x0, lsl #48
    ad8c:      	ret

000000000000ad90 <_stogir.stack.valid-frame-object-inputs?>:
    ad90:      	sub	sp, sp, #0x50
    ad94:      	str	x29, [sp]
    ad98:      	str	x30, [sp, #0x8]
    ad9c:      	mov	x29, sp
    ada0:      	str	x19, [sp, #0x30]
    ada4:      	str	x20, [sp, #0x38]
    ada8:      	str	x21, [sp, #0x40]
    adac:      	add	x3, x0, #0x78
    adb0:      	add	x4, x0, #0x28
    adb4:      	add	x5, x0, #0x50
    adb8:      	add	x6, x0, #0x78
    adbc:      	add	x7, x0, #0x28
    adc0:      	add	x8, x0, #0x50
    adc4:      	sxtw	x1, w1
    adc8:      	mov	x9, sp
    adcc:      	sub	sp, sp, #0x10
    add0:      	mov	x10, sp
    add4:      	mov	x12, x1
    add8:      	mov	x1, #0x1                ; =1
    addc:      	movz	x11, #0x0, lsl #48
    ade0:      	b	0xaf30 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    ade4:      	movz	x15, #0x0, lsl #48
    ade8:      	b	0xae60 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    adec:      	movz	x13, #0x0, lsl #48
    adf0:      	movz	x14, #0x0, lsl #48
    adf4:      	lsr	w13, w13, #0
    adf8:      	lsr	x16, x13, #0
    adfc:      	cmp	x16, #0x1
    ae00:      	b.eq	0xae1c <_stogir.stack.valid-frame-object-inputs?+0x8c>
    ae04:      	b.lo	0xae0c <_stogir.stack.valid-frame-object-inputs?+0x7c>
    ae08:      	b	0xae20 <_stogir.stack.valid-frame-object-inputs?+0x90>
    ae0c:      	cmp	x16, #0x0
    ae10:      	b.eq	0xae18 <_stogir.stack.valid-frame-object-inputs?+0x88>
    ae14:      	b	0xae20 <_stogir.stack.valid-frame-object-inputs?+0x90>
    ae18:      	b	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    ae1c:      	b	0xae24 <_stogir.stack.valid-frame-object-inputs?+0x94>
    ae20:      	b	0xb218 <_stogir.stack.valid-frame-object-inputs?+0x488>
    ae24:      	uxtb	w13, w14
    ae28:      	lsr	w14, w14, #0
    ae2c:      	ubfx	x14, x14, #8, #8
    ae30:      	cmp	x13, x14
    ae34:      	b.eq	0xb204 <_stogir.stack.valid-frame-object-inputs?+0x474>
    ae38:      	cmp	x13, #0x49
    ae3c:      	b.eq	0xb204 <_stogir.stack.valid-frame-object-inputs?+0x474>
    ae40:      	movz	x1, #0x0, lsl #48
    ae44:      	fmov	d31, x11
    ae48:      	mov	x11, x12
    ae4c:      	fmov	x12, d31
    ae50:      	b	0xb014 <_stogir.stack.valid-frame-object-inputs?+0x284>
    ae54:      	movz	x15, #0x0, lsl #48
    ae58:      	b	0xae68 <_stogir.stack.valid-frame-object-inputs?+0xd8>
    ae5c:      	movz	x15, #0x0, lsl #48
    ae60:      	b	0xae70 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ae64:      	movz	x15, #0x0, lsl #48
    ae68:      	b	0xae70 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    ae6c:      	movz	x15, #0x0, lsl #48
    ae70:      	cmp	x15, #0x0
    ae74:      	b.eq	0xaed8 <_stogir.stack.valid-frame-object-inputs?+0x148>
    ae78:      	uxtb	w16, w14
    ae7c:      	cmp	w16, wzr
    ae80:      	b.eq	0xaea8 <_stogir.stack.valid-frame-object-inputs?+0x118>
    ae84:      	lsl	x13, x13, #4
    ae88:      	ldr	x14, [x0]
    ae8c:      	add	x13, x13, x14
    ae90:      	ldr	x14, [x13]
    ae94:      	ldr	x13, [x13, #0x8]
    ae98:      	fmov	d31, x13
    ae9c:      	mov	x13, x14
    aea0:      	fmov	x14, d31
    aea4:      	b	0xaec8 <_stogir.stack.valid-frame-object-inputs?+0x138>
    aea8:      	lsl	x13, x19, #4
    aeac:      	ldr	x14, [x0, #0x28]
    aeb0:      	add	x13, x13, x14
    aeb4:      	ldr	x14, [x13]
    aeb8:      	ldr	x13, [x13, #0x8]
    aebc:      	fmov	d31, x13
    aec0:      	mov	x13, x14
    aec4:      	fmov	x14, d31
    aec8:      	mov	x15, x14
    aecc:      	mov	x14, x13
    aed0:      	mov	x13, #0x1               ; =1
    aed4:      	b	0xaee4 <_stogir.stack.valid-frame-object-inputs?+0x154>
    aed8:      	movz	x13, #0x0, lsl #48
    aedc:      	movz	x14, #0x0, lsl #48
    aee0:      	movz	x15, #0x0, lsl #48
    aee4:      	lsr	w13, w13, #0
    aee8:      	lsr	x16, x13, #0
    aeec:      	cmp	x16, #0x1
    aef0:      	b.eq	0xaf0c <_stogir.stack.valid-frame-object-inputs?+0x17c>
    aef4:      	b.lo	0xaefc <_stogir.stack.valid-frame-object-inputs?+0x16c>
    aef8:      	b	0xaf10 <_stogir.stack.valid-frame-object-inputs?+0x180>
    aefc:      	cmp	x16, #0x0
    af00:      	b.eq	0xaf08 <_stogir.stack.valid-frame-object-inputs?+0x178>
    af04:      	b	0xaf10 <_stogir.stack.valid-frame-object-inputs?+0x180>
    af08:      	b	0xaf14 <_stogir.stack.valid-frame-object-inputs?+0x184>
    af0c:      	b	0xafe8 <_stogir.stack.valid-frame-object-inputs?+0x258>
    af10:      	b	0xb160 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    af14:      	fmov	d31, x11
    af18:      	mov	x11, x12
    af1c:      	fmov	x12, d31
    af20:      	movz	x1, #0x0, lsl #48
    af24:      	fmov	d31, x11
    af28:      	mov	x11, x12
    af2c:      	fmov	x12, d31
    af30:      	cmp	x1, #0x0
    af34:      	b.eq	0xb0a4 <_stogir.stack.valid-frame-object-inputs?+0x314>
    af38:      	cmp	x11, #0x0
    af3c:      	b.ne	0xb0a4 <_stogir.stack.valid-frame-object-inputs?+0x314>
    af40:      	lsr	w13, w12, #0
    af44:      	sxtw	x13, w13
    af48:      	cmp	x13, #0x0
    af4c:      	cset	w14, gt
    af50:      	movz	x16, #0x0, lsl #48
    af54:      	sub	x15, x16, x13
    af58:      	sub	x19, x15, #0x1
    af5c:      	uxtb	w16, w14
    af60:      	cmp	w16, wzr
    af64:      	b.eq	0xafa4 <_stogir.stack.valid-frame-object-inputs?+0x214>
    af68:      	ldr	x15, [x0, #0x8]
    af6c:      	cmp	x13, x15
    af70:      	b.ge	0xae64 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    af74:      	ldr	x15, [x3, #0x8]
    af78:      	cmp	x13, x15
    af7c:      	b.ge	0xae54 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    af80:      	lsl	x15, x13, #2
    af84:      	ldr	x20, [x0, #0x78]
    af88:      	add	x15, x15, x20
    af8c:      	ldr	w15, [x15]
    af90:      	sxtw	x15, w15
    af94:      	cmp	x15, #0x0
    af98:      	cset	w15, ge
    af9c:      	ubfx	x15, x15, #0, #8
    afa0:      	b	0xae58 <_stogir.stack.valid-frame-object-inputs?+0xc8>
    afa4:      	cmp	x13, #0x0
    afa8:      	b.ge	0xae6c <_stogir.stack.valid-frame-object-inputs?+0xdc>
    afac:      	ldr	x20, [x4, #0x8]
    afb0:      	ldr	x21, [x5, #0x8]
    afb4:      	cmp	x20, x21
    afb8:      	b.ne	0xae5c <_stogir.stack.valid-frame-object-inputs?+0xcc>
    afbc:      	cmp	x15, x20
    afc0:      	b.gt	0xade4 <_stogir.stack.valid-frame-object-inputs?+0x54>
    afc4:      	lsl	x15, x19, #2
    afc8:      	ldr	x20, [x0, #0x50]
    afcc:      	add	x15, x15, x20
    afd0:      	ldr	w15, [x15]
    afd4:      	sxtw	x15, w15
    afd8:      	cmp	x15, #0x0
    afdc:      	cset	w15, gt
    afe0:      	ubfx	x15, x15, #0, #8
    afe4:      	b	0xade8 <_stogir.stack.valid-frame-object-inputs?+0x58>
    afe8:      	uxtb	w13, w14
    afec:      	asr	x19, x14, #32
    aff0:      	str	x14, [x10]
    aff4:      	str	x15, [x10, #0x8]
    aff8:      	cmp	x13, #0x68
    affc:      	b.ne	0xb018 <_stogir.stack.valid-frame-object-inputs?+0x288>
    b000:      	cmp	x19, #0x0
    b004:      	cset	w1, eq
    b008:      	ubfx	x1, x1, #0, #8
    b00c:      	mov	x11, x12
    b010:      	mov	x12, #0x1               ; =1
    b014:      	b	0xaf24 <_stogir.stack.valid-frame-object-inputs?+0x194>
    b018:      	cmp	x12, #0x0
    b01c:      	b.le	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b020:      	cmp	x13, #0x51
    b024:      	b.ne	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b028:      	cmp	x19, #0x0
    b02c:      	b.le	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b030:      	cmp	x19, x12
    b034:      	b.ge	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b038:      	lsr	w15, w15, #0
    b03c:      	sxtw	x15, w15
    b040:      	cmp	x15, #0x0
    b044:      	b.ge	0xae40 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b048:      	cmp	x15, #0x0
    b04c:      	cset	w13, gt
    b050:      	movz	x16, #0x0, lsl #48
    b054:      	sub	x14, x16, x15
    b058:      	sub	x19, x14, #0x1
    b05c:      	uxtb	w16, w13
    b060:      	cmp	w16, wzr
    b064:      	b.eq	0xb1b8 <_stogir.stack.valid-frame-object-inputs?+0x428>
    b068:      	ldr	x14, [x0, #0x8]
    b06c:      	cmp	x15, x14
    b070:      	b.ge	0xb1b0 <_stogir.stack.valid-frame-object-inputs?+0x420>
    b074:      	ldr	x14, [x6, #0x8]
    b078:      	cmp	x15, x14
    b07c:      	b.ge	0xb1fc <_stogir.stack.valid-frame-object-inputs?+0x46c>
    b080:      	lsl	x14, x15, #2
    b084:      	ldr	x20, [x0, #0x78]
    b088:      	add	x14, x14, x20
    b08c:      	ldr	w14, [x14]
    b090:      	sxtw	x14, w14
    b094:      	cmp	x14, #0x0
    b098:      	cset	w14, ge
    b09c:      	ubfx	x14, x14, #0, #8
    b0a0:      	b	0xb200 <_stogir.stack.valid-frame-object-inputs?+0x470>
    b0a4:      	cmp	x1, #0x0
    b0a8:      	b.eq	0xb0b4 <_stogir.stack.valid-frame-object-inputs?+0x324>
    b0ac:      	mov	x1, x11
    b0b0:      	b	0xb0b8 <_stogir.stack.valid-frame-object-inputs?+0x328>
    b0b4:      	movz	x1, #0x0, lsl #48
    b0b8:      	mov	sp, x9
    b0bc:      	cmp	x1, #0x0
    b0c0:      	b.eq	0xb11c <_stogir.stack.valid-frame-object-inputs?+0x38c>
    b0c4:      	sxtw	x1, w2
    b0c8:      	cmp	x1, #0x0
    b0cc:      	b.ge	0xb140 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    b0d0:      	lsr	w2, w2, #0
    b0d4:      	add	x8, x29, #0x10
    b0d8:      	mov	w1, w2
    b0dc:      	bl	0xb0dc <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000b0dc:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    b0e0:      	add	x16, x29, #0x10
    b0e4:      	ldr	w0, [x16]
    b0e8:      	lsr	x16, x0, #0
    b0ec:      	cmp	x16, #0x1
    b0f0:      	b.eq	0xb10c <_stogir.stack.valid-frame-object-inputs?+0x37c>
    b0f4:      	b.lo	0xb0fc <_stogir.stack.valid-frame-object-inputs?+0x36c>
    b0f8:      	b	0xb110 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b0fc:      	cmp	x16, #0x0
    b100:      	b.eq	0xb108 <_stogir.stack.valid-frame-object-inputs?+0x378>
    b104:      	b	0xb110 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b108:      	b	0xb148 <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    b10c:      	b	0xb114 <_stogir.stack.valid-frame-object-inputs?+0x384>
    b110:      	b	0xb210 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b114:      	movz	x0, #0x0, lsl #48
    b118:      	b	0xb15c <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    b11c:      	movz	x0, #0x0, lsl #48
    b120:      	sub	sp, x29, #0x0
    b124:      	ldr	x19, [sp, #0x30]
    b128:      	ldr	x20, [sp, #0x38]
    b12c:      	ldr	x21, [sp, #0x40]
    b130:      	ldr	x29, [sp]
    b134:      	ldr	x30, [sp, #0x8]
    b138:      	add	sp, sp, #0x50
    b13c:      	ret
    b140:      	movz	x0, #0x0, lsl #48
    b144:      	b	0xb120 <_stogir.stack.valid-frame-object-inputs?+0x390>
    b148:      	add	x16, x29, #0x10
    b14c:      	ldr	x0, [x16, #0x8]
    b150:      	cmp	x0, #0x0
    b154:      	cset	w0, gt
    b158:      	ubfx	x0, x0, #0, #8
    b15c:      	b	0xb144 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    b160:      	brk	#0
    b164:      	b	0xb160 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    b168:      	lsl	x13, x19, #4
    b16c:      	ldr	x14, [x0, #0x28]
    b170:      	add	x13, x13, x14
    b174:      	ldr	x13, [x13]
    b178:      	mov	x14, x13
    b17c:      	mov	x13, #0x1               ; =1
    b180:      	b	0xadf4 <_stogir.stack.valid-frame-object-inputs?+0x64>
    b184:      	movz	x14, #0x0, lsl #48
    b188:      	cmp	x14, #0x0
    b18c:      	b.eq	0xadec <_stogir.stack.valid-frame-object-inputs?+0x5c>
    b190:      	uxtb	w16, w13
    b194:      	cmp	w16, wzr
    b198:      	b.eq	0xb168 <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    b19c:      	lsl	x13, x15, #4
    b1a0:      	ldr	x14, [x0]
    b1a4:      	add	x13, x13, x14
    b1a8:      	ldr	x13, [x13]
    b1ac:      	b	0xb178 <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    b1b0:      	movz	x14, #0x0, lsl #48
    b1b4:      	b	0xb188 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b1b8:      	ldr	x20, [x7, #0x8]
    b1bc:      	ldr	x21, [x8, #0x8]
    b1c0:      	cmp	x20, x21
    b1c4:      	b.ne	0xb184 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    b1c8:      	cmp	x14, x20
    b1cc:      	b.gt	0xb1f4 <_stogir.stack.valid-frame-object-inputs?+0x464>
    b1d0:      	lsl	x14, x19, #2
    b1d4:      	ldr	x20, [x0, #0x50]
    b1d8:      	add	x14, x14, x20
    b1dc:      	ldr	w14, [x14]
    b1e0:      	sxtw	x14, w14
    b1e4:      	cmp	x14, #0x0
    b1e8:      	cset	w14, gt
    b1ec:      	ubfx	x14, x14, #0, #8
    b1f0:      	b	0xb1f8 <_stogir.stack.valid-frame-object-inputs?+0x468>
    b1f4:      	movz	x14, #0x0, lsl #48
    b1f8:      	b	0xb188 <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b1fc:      	movz	x14, #0x0, lsl #48
    b200:      	b	0xb1b4 <_stogir.stack.valid-frame-object-inputs?+0x424>
    b204:      	ldr	w12, [x10, #0x4]
    b208:      	sxtw	x12, w12
    b20c:      	b	0xae44 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    b210:      	brk	#0
    b214:      	b	0xb210 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b218:      	brk	#0
    b21c:      	b	0xb218 <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000b220 <_stogir.stack.validate-scope-inputs>:
    b220:      	sxtw	x1, w1
    b224:      	cmp	x1, #0x53
    b228:      	cset	w5, eq
    b22c:      	uxtb	w16, w5
    b230:      	cmp	w16, wzr
    b234:      	b.ne	0xb268 <_stogir.stack.validate-scope-inputs+0x48>
    b238:      	cmp	x1, #0x54
    b23c:      	b.eq	0xb268 <_stogir.stack.validate-scope-inputs+0x48>
    b240:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b240:  ARM64_RELOC_PAGE21	l_stogir.448
    b244:      	ldr	x16, [x16]
		000000000000b244:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    b248:      	orr	x0, x16, xzr
    b24c:      	mov	x1, x0
    b250:      	mov	x0, #0x1                ; =1
    b254:      	mov	x2, #0x22               ; =34
    b258:      	str	x0, [x8]
    b25c:      	str	x1, [x8, #0x8]
    b260:      	str	x2, [x8, #0x10]
    b264:      	ret
    b268:      	uxtb	w16, w5
    b26c:      	cmp	w16, wzr
    b270:      	mov	x16, #0x6               ; =6
    b274:      	movz	x17, #0x0, lsl #48
    b278:      	csel	x1, x16, x17, ne
    b27c:      	sxtw	x2, w2
    b280:      	lsr	w1, w1, #0
    b284:      	sxtw	x1, w1
    b288:      	cmp	x2, x1
    b28c:      	b.ne	0xb240 <_stogir.stack.validate-scope-inputs+0x20>
    b290:      	sxtw	x3, w3
    b294:      	cmp	x3, #0x0
    b298:      	cset	w1, gt
    b29c:      	movz	x16, #0x0, lsl #48
    b2a0:      	sub	x2, x16, x3
    b2a4:      	sub	x6, x2, #0x1
    b2a8:      	uxtb	w16, w1
    b2ac:      	cmp	w16, wzr
    b2b0:      	b.eq	0xb398 <_stogir.stack.validate-scope-inputs+0x178>
    b2b4:      	ldr	x2, [x0, #0x8]
    b2b8:      	cmp	x3, x2
    b2bc:      	b.ge	0xb390 <_stogir.stack.validate-scope-inputs+0x170>
    b2c0:      	add	x2, x0, #0x78
    b2c4:      	ldr	x2, [x2, #0x8]
    b2c8:      	cmp	x3, x2
    b2cc:      	b.ge	0xb440 <_stogir.stack.validate-scope-inputs+0x220>
    b2d0:      	lsl	x2, x3, #2
    b2d4:      	ldr	x7, [x0, #0x78]
    b2d8:      	add	x2, x2, x7
    b2dc:      	ldr	w2, [x2]
    b2e0:      	sxtw	x2, w2
    b2e4:      	cmp	x2, #0x0
    b2e8:      	cset	w2, ge
    b2ec:      	ubfx	x2, x2, #0, #8
    b2f0:      	b	0xb444 <_stogir.stack.validate-scope-inputs+0x224>
    b2f4:      	movz	x1, #0x0, lsl #48
    b2f8:      	movz	x2, #0x0, lsl #48
    b2fc:      	lsr	w1, w1, #0
    b300:      	lsr	x16, x1, #0
    b304:      	cmp	x16, #0x1
    b308:      	b.eq	0xb324 <_stogir.stack.validate-scope-inputs+0x104>
    b30c:      	b.lo	0xb314 <_stogir.stack.validate-scope-inputs+0xf4>
    b310:      	b	0xb328 <_stogir.stack.validate-scope-inputs+0x108>
    b314:      	cmp	x16, #0x0
    b318:      	b.eq	0xb320 <_stogir.stack.validate-scope-inputs+0x100>
    b31c:      	b	0xb328 <_stogir.stack.validate-scope-inputs+0x108>
    b320:      	b	0xb32c <_stogir.stack.validate-scope-inputs+0x10c>
    b324:      	b	0xb3e4 <_stogir.stack.validate-scope-inputs+0x1c4>
    b328:      	b	0xb614 <_stogir.stack.validate-scope-inputs+0x3f4>
    b32c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b32c:  ARM64_RELOC_PAGE21	l_stogir.449
    b330:      	ldr	x16, [x16]
		000000000000b330:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    b334:      	orr	x0, x16, xzr
    b338:      	mov	x1, x0
    b33c:      	mov	x0, #0x1                ; =1
    b340:      	mov	x2, #0x1b               ; =27
    b344:      	b	0xb258 <_stogir.stack.validate-scope-inputs+0x38>
    b348:      	lsl	x1, x6, #4
    b34c:      	ldr	x2, [x0, #0x28]
    b350:      	add	x1, x1, x2
    b354:      	ldr	x1, [x1]
    b358:      	mov	x2, x1
    b35c:      	mov	x1, #0x1                ; =1
    b360:      	b	0xb2fc <_stogir.stack.validate-scope-inputs+0xdc>
    b364:      	movz	x2, #0x0, lsl #48
    b368:      	cmp	x2, #0x0
    b36c:      	b.eq	0xb2f4 <_stogir.stack.validate-scope-inputs+0xd4>
    b370:      	uxtb	w16, w1
    b374:      	cmp	w16, wzr
    b378:      	b.eq	0xb348 <_stogir.stack.validate-scope-inputs+0x128>
    b37c:      	lsl	x1, x3, #4
    b380:      	ldr	x2, [x0]
    b384:      	add	x1, x1, x2
    b388:      	ldr	x1, [x1]
    b38c:      	b	0xb358 <_stogir.stack.validate-scope-inputs+0x138>
    b390:      	movz	x2, #0x0, lsl #48
    b394:      	b	0xb368 <_stogir.stack.validate-scope-inputs+0x148>
    b398:      	cmp	x3, #0x0
    b39c:      	b.ge	0xb364 <_stogir.stack.validate-scope-inputs+0x144>
    b3a0:      	add	x7, x0, #0x28
    b3a4:      	add	x9, x0, #0x50
    b3a8:      	ldr	x7, [x7, #0x8]
    b3ac:      	ldr	x9, [x9, #0x8]
    b3b0:      	cmp	x7, x9
    b3b4:      	b.ne	0xb438 <_stogir.stack.validate-scope-inputs+0x218>
    b3b8:      	cmp	x2, x7
    b3bc:      	b.gt	0xb448 <_stogir.stack.validate-scope-inputs+0x228>
    b3c0:      	lsl	x2, x6, #2
    b3c4:      	ldr	x7, [x0, #0x50]
    b3c8:      	add	x2, x2, x7
    b3cc:      	ldr	w2, [x2]
    b3d0:      	sxtw	x2, w2
    b3d4:      	cmp	x2, #0x0
    b3d8:      	cset	w2, gt
    b3dc:      	ubfx	x2, x2, #0, #8
    b3e0:      	b	0xb44c <_stogir.stack.validate-scope-inputs+0x22c>
    b3e4:      	cmp	x3, #0x0
    b3e8:      	b.le	0xb41c <_stogir.stack.validate-scope-inputs+0x1fc>
    b3ec:      	uxtb	w2, w2
    b3f0:      	cmp	x2, #0x83
    b3f4:      	cset	w1, lt
    b3f8:      	uxtb	w16, w1
    b3fc:      	cmp	w16, wzr
    b400:      	b.eq	0xb450 <_stogir.stack.validate-scope-inputs+0x230>
    b404:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b404:  ARM64_RELOC_PAGE21	l_stogir.450
    b408:      	ldr	x16, [x16]
		000000000000b408:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b40c:      	orr	x3, x16, xzr
    b410:      	add	x3, x2, x3
    b414:      	ldrb	w3, [x3]
    b418:      	b	0xb454 <_stogir.stack.validate-scope-inputs+0x234>
    b41c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b41c:  ARM64_RELOC_PAGE21	l_stogir.451
    b420:      	ldr	x16, [x16]
		000000000000b420:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    b424:      	orr	x0, x16, xzr
    b428:      	mov	x1, x0
    b42c:      	mov	x0, #0x1                ; =1
    b430:      	mov	x2, #0x1b               ; =27
    b434:      	b	0xb344 <_stogir.stack.validate-scope-inputs+0x124>
    b438:      	movz	x2, #0x0, lsl #48
    b43c:      	b	0xb368 <_stogir.stack.validate-scope-inputs+0x148>
    b440:      	movz	x2, #0x0, lsl #48
    b444:      	b	0xb394 <_stogir.stack.validate-scope-inputs+0x174>
    b448:      	movz	x2, #0x0, lsl #48
    b44c:      	b	0xb43c <_stogir.stack.validate-scope-inputs+0x21c>
    b450:      	movz	x3, #0x0, lsl #48
    b454:      	uxtb	w3, w3
    b458:      	and	x3, x3, #0x1
    b45c:      	uxtb	w3, w3
    b460:      	cmp	x3, #0x0
    b464:      	b.eq	0xb41c <_stogir.stack.validate-scope-inputs+0x1fc>
    b468:      	uxtb	w16, w1
    b46c:      	cmp	w16, wzr
    b470:      	b.eq	0xb48c <_stogir.stack.validate-scope-inputs+0x26c>
    b474:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b474:  ARM64_RELOC_PAGE21	l_stogir.450
    b478:      	ldr	x16, [x16]
		000000000000b478:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b47c:      	orr	x1, x16, xzr
    b480:      	add	x1, x2, x1
    b484:      	ldrb	w1, [x1]
    b488:      	b	0xb490 <_stogir.stack.validate-scope-inputs+0x270>
    b48c:      	movz	x1, #0x0, lsl #48
    b490:      	uxtb	w1, w1
    b494:      	and	x1, x1, #0x4
    b498:      	uxtb	w1, w1
    b49c:      	cmp	x1, #0x0
    b4a0:      	b.ne	0xb41c <_stogir.stack.validate-scope-inputs+0x1fc>
    b4a4:      	uxtb	w16, w5
    b4a8:      	cmp	w16, wzr
    b4ac:      	b.eq	0xb4c0 <_stogir.stack.validate-scope-inputs+0x2a0>
    b4b0:      	movz	x0, #0x0, lsl #48
    b4b4:      	mov	x1, #0x8                ; =8
    b4b8:      	movz	x2, #0x0, lsl #48
    b4bc:      	b	0xb434 <_stogir.stack.validate-scope-inputs+0x214>
    b4c0:      	sxtw	x4, w4
    b4c4:      	cmp	x4, #0x0
    b4c8:      	cset	w1, gt
    b4cc:      	movz	x16, #0x0, lsl #48
    b4d0:      	sub	x2, x16, x4
    b4d4:      	sub	x3, x2, #0x1
    b4d8:      	uxtb	w16, w1
    b4dc:      	cmp	w16, wzr
    b4e0:      	b.eq	0xb5c8 <_stogir.stack.validate-scope-inputs+0x3a8>
    b4e4:      	ldr	x2, [x0, #0x8]
    b4e8:      	cmp	x4, x2
    b4ec:      	b.ge	0xb5c0 <_stogir.stack.validate-scope-inputs+0x3a0>
    b4f0:      	add	x2, x0, #0x78
    b4f4:      	ldr	x2, [x2, #0x8]
    b4f8:      	cmp	x4, x2
    b4fc:      	b.ge	0xb66c <_stogir.stack.validate-scope-inputs+0x44c>
    b500:      	lsl	x2, x4, #2
    b504:      	ldr	x5, [x0, #0x78]
    b508:      	add	x2, x2, x5
    b50c:      	ldr	w2, [x2]
    b510:      	sxtw	x2, w2
    b514:      	cmp	x2, #0x0
    b518:      	cset	w2, ge
    b51c:      	ubfx	x2, x2, #0, #8
    b520:      	b	0xb670 <_stogir.stack.validate-scope-inputs+0x450>
    b524:      	movz	x0, #0x0, lsl #48
    b528:      	movz	x1, #0x0, lsl #48
    b52c:      	lsr	w0, w0, #0
    b530:      	lsr	x16, x0, #0
    b534:      	cmp	x16, #0x1
    b538:      	b.eq	0xb554 <_stogir.stack.validate-scope-inputs+0x334>
    b53c:      	b.lo	0xb544 <_stogir.stack.validate-scope-inputs+0x324>
    b540:      	b	0xb558 <_stogir.stack.validate-scope-inputs+0x338>
    b544:      	cmp	x16, #0x0
    b548:      	b.eq	0xb550 <_stogir.stack.validate-scope-inputs+0x330>
    b54c:      	b	0xb558 <_stogir.stack.validate-scope-inputs+0x338>
    b550:      	b	0xb55c <_stogir.stack.validate-scope-inputs+0x33c>
    b554:      	b	0xb61c <_stogir.stack.validate-scope-inputs+0x3fc>
    b558:      	b	0xb67c <_stogir.stack.validate-scope-inputs+0x45c>
    b55c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b55c:  ARM64_RELOC_PAGE21	l_stogir.452
    b560:      	ldr	x16, [x16]
		000000000000b560:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    b564:      	orr	x0, x16, xzr
    b568:      	mov	x1, x0
    b56c:      	mov	x0, #0x1                ; =1
    b570:      	mov	x2, #0x1b               ; =27
    b574:      	b	0xb4bc <_stogir.stack.validate-scope-inputs+0x29c>
    b578:      	lsl	x1, x3, #4
    b57c:      	ldr	x0, [x0, #0x28]
    b580:      	add	x0, x1, x0
    b584:      	ldr	x0, [x0]
    b588:      	mov	x1, x0
    b58c:      	mov	x0, #0x1                ; =1
    b590:      	b	0xb52c <_stogir.stack.validate-scope-inputs+0x30c>
    b594:      	movz	x2, #0x0, lsl #48
    b598:      	cmp	x2, #0x0
    b59c:      	b.eq	0xb524 <_stogir.stack.validate-scope-inputs+0x304>
    b5a0:      	uxtb	w16, w1
    b5a4:      	cmp	w16, wzr
    b5a8:      	b.eq	0xb578 <_stogir.stack.validate-scope-inputs+0x358>
    b5ac:      	lsl	x1, x4, #4
    b5b0:      	ldr	x0, [x0]
    b5b4:      	add	x0, x1, x0
    b5b8:      	ldr	x0, [x0]
    b5bc:      	b	0xb588 <_stogir.stack.validate-scope-inputs+0x368>
    b5c0:      	movz	x2, #0x0, lsl #48
    b5c4:      	b	0xb598 <_stogir.stack.validate-scope-inputs+0x378>
    b5c8:      	cmp	x4, #0x0
    b5cc:      	b.ge	0xb594 <_stogir.stack.validate-scope-inputs+0x374>
    b5d0:      	add	x5, x0, #0x28
    b5d4:      	add	x6, x0, #0x50
    b5d8:      	ldr	x5, [x5, #0x8]
    b5dc:      	ldr	x6, [x6, #0x8]
    b5e0:      	cmp	x5, x6
    b5e4:      	b.ne	0xb664 <_stogir.stack.validate-scope-inputs+0x444>
    b5e8:      	cmp	x2, x5
    b5ec:      	b.gt	0xb674 <_stogir.stack.validate-scope-inputs+0x454>
    b5f0:      	lsl	x2, x3, #2
    b5f4:      	ldr	x5, [x0, #0x50]
    b5f8:      	add	x2, x2, x5
    b5fc:      	ldr	w2, [x2]
    b600:      	sxtw	x2, w2
    b604:      	cmp	x2, #0x0
    b608:      	cset	w2, gt
    b60c:      	ubfx	x2, x2, #0, #8
    b610:      	b	0xb678 <_stogir.stack.validate-scope-inputs+0x458>
    b614:      	brk	#0
    b618:      	b	0xb614 <_stogir.stack.validate-scope-inputs+0x3f4>
    b61c:      	lsr	w0, w1, #0
    b620:      	ubfx	x0, x0, #8, #8
    b624:      	cmp	x0, #0x6
    b628:      	b.ne	0xb648 <_stogir.stack.validate-scope-inputs+0x428>
    b62c:      	uxtb	w1, w1
    b630:      	cmp	x1, #0x48
    b634:      	b.eq	0xb648 <_stogir.stack.validate-scope-inputs+0x428>
    b638:      	movz	x0, #0x0, lsl #48
    b63c:      	mov	x1, #0x8                ; =8
    b640:      	movz	x2, #0x0, lsl #48
    b644:      	b	0xb660 <_stogir.stack.validate-scope-inputs+0x440>
    b648:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b648:  ARM64_RELOC_PAGE21	l_stogir.453
    b64c:      	ldr	x16, [x16]
		000000000000b64c:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    b650:      	orr	x0, x16, xzr
    b654:      	mov	x1, x0
    b658:      	mov	x0, #0x1                ; =1
    b65c:      	mov	x2, #0x29               ; =41
    b660:      	b	0xb574 <_stogir.stack.validate-scope-inputs+0x354>
    b664:      	movz	x2, #0x0, lsl #48
    b668:      	b	0xb598 <_stogir.stack.validate-scope-inputs+0x378>
    b66c:      	movz	x2, #0x0, lsl #48
    b670:      	b	0xb5c4 <_stogir.stack.validate-scope-inputs+0x3a4>
    b674:      	movz	x2, #0x0, lsl #48
    b678:      	b	0xb668 <_stogir.stack.validate-scope-inputs+0x448>
    b67c:      	brk	#0
    b680:      	b	0xb67c <_stogir.stack.validate-scope-inputs+0x45c>

000000000000b684 <_stogir.stack.validate-inputs>:
    b684:      	sub	sp, sp, #0x110
    b688:      	str	x29, [sp]
    b68c:      	str	x30, [sp, #0x8]
    b690:      	mov	x29, sp
    b694:      	str	x19, [sp, #0xb8]
    b698:      	str	x20, [sp, #0xc0]
    b69c:      	str	x21, [sp, #0xc8]
    b6a0:      	str	x22, [sp, #0xd0]
    b6a4:      	str	x23, [sp, #0xd8]
    b6a8:      	str	x24, [sp, #0xe0]
    b6ac:      	str	x25, [sp, #0xe8]
    b6b0:      	str	x26, [sp, #0xf0]
    b6b4:      	str	x27, [sp, #0xf8]
    b6b8:      	str	x28, [sp, #0x100]
    b6bc:      	sxtw	x1, w1
    b6c0:      	cmp	x1, #0x51
    b6c4:      	cset	w19, eq
    b6c8:      	uxtb	w16, w19
    b6cc:      	cmp	w16, wzr
    b6d0:      	b.ne	0xb740 <_stogir.stack.validate-inputs+0xbc>
    b6d4:      	cmp	x1, #0x52
    b6d8:      	b.eq	0xb740 <_stogir.stack.validate-inputs+0xbc>
    b6dc:      	str	x8, [sp, #0x90]
    b6e0:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b6e0:  ARM64_RELOC_PAGE21	l_stogir.454
    b6e4:      	ldr	x16, [x16]
		000000000000b6e4:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b6e8:      	orr	x0, x16, xzr
    b6ec:      	mov	x1, x0
    b6f0:      	mov	x0, #0x1                ; =1
    b6f4:      	mov	x2, #0x29               ; =41
    b6f8:      	ldr	x3, [sp, #0x90]
    b6fc:      	str	x0, [x3]
    b700:      	str	x1, [x3, #0x8]
    b704:      	str	x2, [x3, #0x10]
    b708:      	ldr	x19, [sp, #0xb8]
    b70c:      	ldr	x20, [sp, #0xc0]
    b710:      	ldr	x21, [sp, #0xc8]
    b714:      	ldr	x22, [sp, #0xd0]
    b718:      	ldr	x23, [sp, #0xd8]
    b71c:      	ldr	x24, [sp, #0xe0]
    b720:      	ldr	x25, [sp, #0xe8]
    b724:      	ldr	x26, [sp, #0xf0]
    b728:      	ldr	x27, [sp, #0xf8]
    b72c:      	ldr	x28, [sp, #0x100]
    b730:      	ldr	x29, [sp]
    b734:      	ldr	x30, [sp, #0x8]
    b738:      	add	sp, sp, #0x110
    b73c:      	ret
    b740:      	uxtb	w16, w19
    b744:      	cmp	w16, wzr
    b748:      	mov	x16, #0x6               ; =6
    b74c:      	movz	x17, #0x0, lsl #48
    b750:      	csel	x1, x16, x17, ne
    b754:      	sxtw	x2, w2
    b758:      	lsr	w1, w1, #0
    b75c:      	sxtw	x1, w1
    b760:      	cmp	x2, x1
    b764:      	b.ne	0xbcc4 <_stogir.stack.validate-inputs+0x640>
    b768:      	sxtw	x20, w5
    b76c:      	uxtb	w16, w19
    b770:      	cmp	w16, wzr
    b774:      	b.eq	0xb7a0 <_stogir.stack.validate-inputs+0x11c>
    b778:      	cmp	x20, #0x0
    b77c:      	b.eq	0xb7a0 <_stogir.stack.validate-inputs+0x11c>
    b780:      	cmp	x20, #0x0
    b784:      	b.le	0xb878 <_stogir.stack.validate-inputs+0x1f4>
    b788:      	sub	x1, x20, #0x1
    b78c:      	and	x1, x1, x20
    b790:      	cmp	x1, #0x0
    b794:      	cset	w1, eq
    b798:      	ubfx	x1, x1, #0, #8
    b79c:      	b	0xb87c <_stogir.stack.validate-inputs+0x1f8>
    b7a0:      	lsr	w3, w3, #0
    b7a4:      	mov	w1, w3
    b7a8:      	mov	x21, x8
    b7ac:      	add	x8, sp, #0x10
    b7b0:      	mov	x22, x0
    b7b4:      	mov	w23, w3
    b7b8:      	mov	w24, w4
    b7bc:      	bl	0xb7bc <_stogir.stack.validate-inputs+0x138>
		000000000000b7bc:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b7c0:      	add	x16, sp, #0x10
    b7c4:      	ldr	w0, [x16]
    b7c8:      	lsr	x16, x0, #0
    b7cc:      	cmp	x16, #0x1
    b7d0:      	b.eq	0xb7ec <_stogir.stack.validate-inputs+0x168>
    b7d4:      	b.lo	0xb7dc <_stogir.stack.validate-inputs+0x158>
    b7d8:      	b	0xb7f0 <_stogir.stack.validate-inputs+0x16c>
    b7dc:      	cmp	x16, #0x0
    b7e0:      	b.eq	0xb7e8 <_stogir.stack.validate-inputs+0x164>
    b7e4:      	b	0xb7f0 <_stogir.stack.validate-inputs+0x16c>
    b7e8:      	b	0xb7f4 <_stogir.stack.validate-inputs+0x170>
    b7ec:      	b	0xb814 <_stogir.stack.validate-inputs+0x190>
    b7f0:      	b	0xba3c <_stogir.stack.validate-inputs+0x3b8>
    b7f4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b7f4:  ARM64_RELOC_PAGE21	l_stogir.455
    b7f8:      	ldr	x16, [x16]
		000000000000b7f8:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b7fc:      	orr	x0, x16, xzr
    b800:      	str	x21, [sp, #0x90]
    b804:      	mov	x1, x0
    b808:      	mov	x0, #0x1                ; =1
    b80c:      	mov	x2, #0x1f               ; =31
    b810:      	b	0xb6f8 <_stogir.stack.validate-inputs+0x74>
    b814:      	sxtw	x23, w23
    b818:      	add	x16, sp, #0x10
    b81c:      	ldr	x0, [x16, #0x8]
    b820:      	cmp	x23, #0x0
    b824:      	b.gt	0xb848 <_stogir.stack.validate-inputs+0x1c4>
    b828:      	str	x21, [sp, #0x90]
    b82c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b82c:  ARM64_RELOC_PAGE21	l_stogir.456
    b830:      	ldr	x16, [x16]
		000000000000b830:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b834:      	orr	x0, x16, xzr
    b838:      	mov	x1, x0
    b83c:      	mov	x0, #0x1                ; =1
    b840:      	mov	x2, #0x1f               ; =31
    b844:      	b	0xb810 <_stogir.stack.validate-inputs+0x18c>
    b848:      	uxtb	w0, w0
    b84c:      	cmp	x0, #0x83
    b850:      	cset	w1, lt
    b854:      	uxtb	w16, w1
    b858:      	cmp	w16, wzr
    b85c:      	b.eq	0xb88c <_stogir.stack.validate-inputs+0x208>
    b860:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b860:  ARM64_RELOC_PAGE21	l_stogir.457
    b864:      	ldr	x16, [x16]
		000000000000b864:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b868:      	orr	x2, x16, xzr
    b86c:      	add	x2, x0, x2
    b870:      	ldrb	w2, [x2]
    b874:      	b	0xb890 <_stogir.stack.validate-inputs+0x20c>
    b878:      	movz	x1, #0x0, lsl #48
    b87c:      	cmp	x1, #0x0
    b880:      	b.ne	0xb7a0 <_stogir.stack.validate-inputs+0x11c>
    b884:      	str	x8, [sp, #0x90]
    b888:      	b	0xb6e0 <_stogir.stack.validate-inputs+0x5c>
    b88c:      	movz	x2, #0x0, lsl #48
    b890:      	uxtb	w2, w2
    b894:      	and	x2, x2, #0x1
    b898:      	uxtb	w2, w2
    b89c:      	cmp	x2, #0x0
    b8a0:      	b.eq	0xbccc <_stogir.stack.validate-inputs+0x648>
    b8a4:      	uxtb	w16, w1
    b8a8:      	cmp	w16, wzr
    b8ac:      	b.eq	0xb8c8 <_stogir.stack.validate-inputs+0x244>
    b8b0:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b8b0:  ARM64_RELOC_PAGE21	l_stogir.457
    b8b4:      	ldr	x16, [x16]
		000000000000b8b4:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b8b8:      	orr	x1, x16, xzr
    b8bc:      	add	x0, x0, x1
    b8c0:      	ldrb	w0, [x0]
    b8c4:      	b	0xb8cc <_stogir.stack.validate-inputs+0x248>
    b8c8:      	movz	x0, #0x0, lsl #48
    b8cc:      	uxtb	w0, w0
    b8d0:      	and	x0, x0, #0x4
    b8d4:      	uxtb	w0, w0
    b8d8:      	cmp	x0, #0x0
    b8dc:      	b.ne	0xbcd4 <_stogir.stack.validate-inputs+0x650>
    b8e0:      	lsr	w24, w24, #0
    b8e4:      	add	x8, sp, #0x40
    b8e8:      	mov	x0, x22
    b8ec:      	mov	w1, w24
    b8f0:      	bl	0xb8f0 <_stogir.stack.validate-inputs+0x26c>
		000000000000b8f0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b8f4:      	add	x16, sp, #0x40
    b8f8:      	ldr	w0, [x16]
    b8fc:      	lsr	x16, x0, #0
    b900:      	cmp	x16, #0x1
    b904:      	b.eq	0xb920 <_stogir.stack.validate-inputs+0x29c>
    b908:      	b.lo	0xb910 <_stogir.stack.validate-inputs+0x28c>
    b90c:      	b	0xb924 <_stogir.stack.validate-inputs+0x2a0>
    b910:      	cmp	x16, #0x0
    b914:      	b.eq	0xb91c <_stogir.stack.validate-inputs+0x298>
    b918:      	b	0xb924 <_stogir.stack.validate-inputs+0x2a0>
    b91c:      	b	0xb928 <_stogir.stack.validate-inputs+0x2a4>
    b920:      	b	0xb948 <_stogir.stack.validate-inputs+0x2c4>
    b924:      	b	0xbbcc <_stogir.stack.validate-inputs+0x548>
    b928:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000b928:  ARM64_RELOC_PAGE21	l_stogir.458
    b92c:      	ldr	x16, [x16]
		000000000000b92c:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    b930:      	orr	x0, x16, xzr
    b934:      	str	x21, [sp, #0x90]
    b938:      	mov	x1, x0
    b93c:      	mov	x0, #0x1                ; =1
    b940:      	mov	x2, #0x18               ; =24
    b944:      	b	0xb844 <_stogir.stack.validate-inputs+0x1c0>
    b948:      	add	x16, sp, #0x40
    b94c:      	ldr	x0, [x16, #0x8]
    b950:      	lsr	w1, w0, #0
    b954:      	ubfx	x1, x1, #8, #8
    b958:      	cmp	x1, #0x1
    b95c:      	b.lt	0xbcdc <_stogir.stack.validate-inputs+0x658>
    b960:      	cmp	x1, #0xb
    b964:      	b.gt	0xbce4 <_stogir.stack.validate-inputs+0x660>
    b968:      	uxtb	w0, w0
    b96c:      	cmp	x0, #0x48
    b970:      	b.eq	0xbcec <_stogir.stack.validate-inputs+0x668>
    b974:      	sxtw	x0, w24
    b978:      	cmp	x1, #0x0
    b97c:      	cset	w23, eq
    b980:      	cmp	x1, #0x1
    b984:      	cset	w25, eq
    b988:      	cmp	x1, #0x2
    b98c:      	cset	w26, eq
    b990:      	cmp	x1, #0x7
    b994:      	cset	w27, eq
    b998:      	cmp	x1, #0x8
    b99c:      	cset	w28, eq
    b9a0:      	cmp	x1, #0x3
    b9a4:      	cset	w2, eq
    b9a8:      	cmp	x1, #0x9
    b9ac:      	cset	w3, eq
    b9b0:      	cmp	x1, #0x4
    b9b4:      	cset	w4, eq
    b9b8:      	cmp	x1, #0xa
    b9bc:      	cset	w5, eq
    b9c0:      	cmp	x1, #0xd
    b9c4:      	cset	w6, eq
    b9c8:      	cmp	x1, #0x5
    b9cc:      	cset	w7, eq
    b9d0:      	cmp	x1, #0xb
    b9d4:      	cset	w8, eq
    b9d8:      	cmp	x1, #0xc
    b9dc:      	cset	w9, eq
    b9e0:      	cmp	x1, #0x6
    b9e4:      	cset	w1, eq
    b9e8:      	uxtb	w16, w1
    b9ec:      	cmp	w16, wzr
    b9f0:      	mov	x16, #0x8               ; =8
    b9f4:      	movn	x17, #0x0, lsl #48
    b9f8:      	csel	x1, x16, x17, ne
    b9fc:      	cmp	x0, #0x0
    ba00:      	b.ge	0xbcf4 <_stogir.stack.validate-inputs+0x670>
    ba04:      	uxtb	w16, w19
    ba08:      	cmp	w16, wzr
    ba0c:      	b.eq	0xbb30 <_stogir.stack.validate-inputs+0x4ac>
    ba10:      	cmp	x20, #0x10
    ba14:      	b.le	0xbb30 <_stogir.stack.validate-inputs+0x4ac>
    ba18:      	mov	x0, x20
    ba1c:      	b	0xbb34 <_stogir.stack.validate-inputs+0x4b0>
    ba20:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000ba20:  ARM64_RELOC_PAGE21	l_stogir.459
    ba24:      	ldr	x16, [x16]
		000000000000ba24:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    ba28:      	orr	x0, x16, xzr
    ba2c:      	mov	x1, x0
    ba30:      	mov	x0, #0x1                ; =1
    ba34:      	mov	x2, #0x29               ; =41
    ba38:      	b	0xb944 <_stogir.stack.validate-inputs+0x2c0>
    ba3c:      	brk	#0
    ba40:      	b	0xba3c <_stogir.stack.validate-inputs+0x3b8>
    ba44:      	mov	x0, #0x1                ; =1
    ba48:      	lsr	w0, w0, #0
    ba4c:      	sxtw	x0, w0
    ba50:      	and	x0, x0, #0xffffffff
    ba54:      	mov	x1, x0
    ba58:      	movz	x0, #0x0, lsl #48
    ba5c:      	movz	x2, #0x0, lsl #48
    ba60:      	b	0xba38 <_stogir.stack.validate-inputs+0x3b4>
    ba64:      	uxtb	w16, w23
    ba68:      	cmp	w16, wzr
    ba6c:      	b.eq	0xba98 <_stogir.stack.validate-inputs+0x414>
    ba70:      	movz	x0, #0x0, lsl #48
    ba74:      	b	0xba48 <_stogir.stack.validate-inputs+0x3c4>
    ba78:      	mov	x0, #0x1                ; =1
    ba7c:      	lsr	w0, w0, #0
    ba80:      	sxtw	x0, w0
    ba84:      	and	x0, x0, #0xffffffff
    ba88:      	mov	x1, x0
    ba8c:      	movz	x0, #0x0, lsl #48
    ba90:      	movz	x2, #0x0, lsl #48
    ba94:      	b	0xba60 <_stogir.stack.validate-inputs+0x3dc>
    ba98:      	uxtb	w16, w25
    ba9c:      	cmp	w16, wzr
    baa0:      	b.ne	0xba44 <_stogir.stack.validate-inputs+0x3c0>
    baa4:      	uxtb	w16, w26
    baa8:      	cmp	w16, wzr
    baac:      	b.ne	0xba44 <_stogir.stack.validate-inputs+0x3c0>
    bab0:      	uxtb	w16, w27
    bab4:      	cmp	w16, wzr
    bab8:      	b.ne	0xba44 <_stogir.stack.validate-inputs+0x3c0>
    babc:      	uxtb	w16, w28
    bac0:      	cmp	w16, wzr
    bac4:      	b.ne	0xba44 <_stogir.stack.validate-inputs+0x3c0>
    bac8:      	uxtb	w16, w19
    bacc:      	cmp	w16, wzr
    bad0:      	b.ne	0xbc8c <_stogir.stack.validate-inputs+0x608>
    bad4:      	uxtb	w16, w20
    bad8:      	cmp	w16, wzr
    badc:      	b.ne	0xbc8c <_stogir.stack.validate-inputs+0x608>
    bae0:      	uxtb	w16, w22
    bae4:      	cmp	w16, wzr
    bae8:      	b.ne	0xbca4 <_stogir.stack.validate-inputs+0x620>
    baec:      	uxtb	w16, w24
    baf0:      	cmp	w16, wzr
    baf4:      	b.ne	0xbca4 <_stogir.stack.validate-inputs+0x620>
    baf8:      	uxtb	w16, w21
    bafc:      	cmp	w16, wzr
    bb00:      	b.ne	0xbca4 <_stogir.stack.validate-inputs+0x620>
    bb04:      	uxtb	w16, w0
    bb08:      	cmp	w16, wzr
    bb0c:      	b.ne	0xbcb4 <_stogir.stack.validate-inputs+0x630>
    bb10:      	uxtb	w16, w1
    bb14:      	cmp	w16, wzr
    bb18:      	b.ne	0xbcb4 <_stogir.stack.validate-inputs+0x630>
    bb1c:      	uxtb	w16, w2
    bb20:      	cmp	w16, wzr
    bb24:      	b.ne	0xbcb4 <_stogir.stack.validate-inputs+0x630>
    bb28:      	ldr	x0, [sp, #0xb0]
    bb2c:      	b	0xbcb8 <_stogir.stack.validate-inputs+0x634>
    bb30:      	mov	x0, #0x10               ; =16
    bb34:      	lsr	w24, w24, #0
    bb38:      	mov	w19, w2
    bb3c:      	mov	x2, x0
    bb40:      	mov	x0, x22
    bb44:      	mov	w20, w3
    bb48:      	mov	w22, w4
    bb4c:      	str	w7, [sp, #0x98]
    bb50:      	str	w8, [sp, #0xa0]
    bb54:      	add	x8, sp, #0x70
    bb58:      	str	w9, [sp, #0xa8]
    bb5c:      	str	x1, [sp, #0xb0]
    bb60:      	mov	w1, w24
    bb64:      	mov	w24, w5
    bb68:      	str	x21, [sp, #0x90]
    bb6c:      	mov	w21, w6
    bb70:      	bl	0xbb70 <_stogir.stack.validate-inputs+0x4ec>
		000000000000bb70:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    bb74:      	add	x16, sp, #0x70
    bb78:      	ldr	w0, [x16]
    bb7c:      	lsr	x16, x0, #0
    bb80:      	cmp	x16, #0x1
    bb84:      	b.eq	0xbba0 <_stogir.stack.validate-inputs+0x51c>
    bb88:      	b.lo	0xbb90 <_stogir.stack.validate-inputs+0x50c>
    bb8c:      	b	0xbba4 <_stogir.stack.validate-inputs+0x520>
    bb90:      	cmp	x16, #0x0
    bb94:      	b.eq	0xbb9c <_stogir.stack.validate-inputs+0x518>
    bb98:      	b	0xbba4 <_stogir.stack.validate-inputs+0x520>
    bb9c:      	b	0xbbd4 <_stogir.stack.validate-inputs+0x550>
    bba0:      	b	0xbba8 <_stogir.stack.validate-inputs+0x524>
    bba4:      	b	0xbc9c <_stogir.stack.validate-inputs+0x618>
    bba8:      	add	x16, sp, #0x70
    bbac:      	orr	x0, x16, xzr
    bbb0:      	add	x0, x0, #0x8
    bbb4:      	add	x16, sp, #0x70
    bbb8:      	ldr	x1, [x16, #0x8]
    bbbc:      	ldr	x0, [x0, #0x8]
    bbc0:      	mov	x2, x0
    bbc4:      	mov	x0, #0x1                ; =1
    bbc8:      	b	0xba94 <_stogir.stack.validate-inputs+0x410>
    bbcc:      	brk	#0
    bbd0:      	b	0xbbcc <_stogir.stack.validate-inputs+0x548>
    bbd4:      	uxtb	w16, w23
    bbd8:      	cmp	w16, wzr
    bbdc:      	b.eq	0xbbe8 <_stogir.stack.validate-inputs+0x564>
    bbe0:      	movz	x0, #0x0, lsl #48
    bbe4:      	b	0xba7c <_stogir.stack.validate-inputs+0x3f8>
    bbe8:      	uxtb	w16, w25
    bbec:      	cmp	w16, wzr
    bbf0:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x3f4>
    bbf4:      	uxtb	w16, w26
    bbf8:      	cmp	w16, wzr
    bbfc:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x3f4>
    bc00:      	uxtb	w16, w27
    bc04:      	cmp	w16, wzr
    bc08:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x3f4>
    bc0c:      	uxtb	w16, w28
    bc10:      	cmp	w16, wzr
    bc14:      	b.ne	0xba78 <_stogir.stack.validate-inputs+0x3f4>
    bc18:      	uxtb	w16, w19
    bc1c:      	cmp	w16, wzr
    bc20:      	b.ne	0xbc94 <_stogir.stack.validate-inputs+0x610>
    bc24:      	uxtb	w16, w20
    bc28:      	cmp	w16, wzr
    bc2c:      	b.ne	0xbc94 <_stogir.stack.validate-inputs+0x610>
    bc30:      	uxtb	w16, w22
    bc34:      	cmp	w16, wzr
    bc38:      	b.ne	0xbcac <_stogir.stack.validate-inputs+0x628>
    bc3c:      	uxtb	w16, w24
    bc40:      	cmp	w16, wzr
    bc44:      	b.ne	0xbcac <_stogir.stack.validate-inputs+0x628>
    bc48:      	uxtb	w16, w21
    bc4c:      	cmp	w16, wzr
    bc50:      	b.ne	0xbcac <_stogir.stack.validate-inputs+0x628>
    bc54:      	ldr	w0, [sp, #0x98]
    bc58:      	uxtb	w16, w0
    bc5c:      	cmp	w16, wzr
    bc60:      	b.ne	0xbcbc <_stogir.stack.validate-inputs+0x638>
    bc64:      	ldr	w1, [sp, #0xa0]
    bc68:      	uxtb	w16, w1
    bc6c:      	cmp	w16, wzr
    bc70:      	b.ne	0xbcbc <_stogir.stack.validate-inputs+0x638>
    bc74:      	ldr	w2, [sp, #0xa8]
    bc78:      	uxtb	w16, w2
    bc7c:      	cmp	w16, wzr
    bc80:      	b.ne	0xbcbc <_stogir.stack.validate-inputs+0x638>
    bc84:      	ldr	x0, [sp, #0xb0]
    bc88:      	b	0xbcc0 <_stogir.stack.validate-inputs+0x63c>
    bc8c:      	mov	x0, #0x2                ; =2
    bc90:      	b	0xba48 <_stogir.stack.validate-inputs+0x3c4>
    bc94:      	mov	x0, #0x2                ; =2
    bc98:      	b	0xba7c <_stogir.stack.validate-inputs+0x3f8>
    bc9c:      	brk	#0
    bca0:      	b	0xbc9c <_stogir.stack.validate-inputs+0x618>
    bca4:      	mov	x0, #0x4                ; =4
    bca8:      	b	0xbc90 <_stogir.stack.validate-inputs+0x60c>
    bcac:      	mov	x0, #0x4                ; =4
    bcb0:      	b	0xbc98 <_stogir.stack.validate-inputs+0x614>
    bcb4:      	mov	x0, #0x8                ; =8
    bcb8:      	b	0xbca8 <_stogir.stack.validate-inputs+0x624>
    bcbc:      	mov	x0, #0x8                ; =8
    bcc0:      	b	0xbcb0 <_stogir.stack.validate-inputs+0x62c>
    bcc4:      	str	x8, [sp, #0x90]
    bcc8:      	b	0xb6e0 <_stogir.stack.validate-inputs+0x5c>
    bccc:      	str	x21, [sp, #0x90]
    bcd0:      	b	0xb82c <_stogir.stack.validate-inputs+0x1a8>
    bcd4:      	str	x21, [sp, #0x90]
    bcd8:      	b	0xb82c <_stogir.stack.validate-inputs+0x1a8>
    bcdc:      	str	x21, [sp, #0x90]
    bce0:      	b	0xba20 <_stogir.stack.validate-inputs+0x39c>
    bce4:      	str	x21, [sp, #0x90]
    bce8:      	b	0xba20 <_stogir.stack.validate-inputs+0x39c>
    bcec:      	str	x21, [sp, #0x90]
    bcf0:      	b	0xba20 <_stogir.stack.validate-inputs+0x39c>
    bcf4:      	str	x21, [sp, #0x90]
    bcf8:      	str	x1, [sp, #0xb0]
    bcfc:      	mov	w19, w2
    bd00:      	mov	w20, w3
    bd04:      	mov	w22, w4
    bd08:      	mov	w24, w5
    bd0c:      	mov	w21, w6
    bd10:      	mov	w0, w7
    bd14:      	mov	w1, w8
    bd18:      	mov	w2, w9
    bd1c:      	b	0xba64 <_stogir.stack.validate-inputs+0x3e0>

000000000000bd20 <_stogir.locals.shape>:
    bd20:      	sub	sp, sp, #0x40
    bd24:      	str	x29, [sp]
    bd28:      	str	x30, [sp, #0x8]
    bd2c:      	mov	x29, sp
    bd30:      	str	x19, [sp, #0x20]
    bd34:      	str	x20, [sp, #0x28]
    bd38:      	str	x21, [sp, #0x30]
    bd3c:      	str	x22, [sp, #0x38]
    bd40:      	sxtw	x19, w1
    bd44:      	lsl	x20, x19, #2
    bd48:      	cmp	x19, #0x0
    bd4c:      	cset	w1, gt
    bd50:      	movz	x16, #0x0, lsl #48
    bd54:      	sub	x3, x16, x19
    bd58:      	sub	x4, x3, #0x1
    bd5c:      	uxtb	w16, w1
    bd60:      	cmp	w16, wzr
    bd64:      	b.eq	0xbda4 <_stogir.locals.shape+0x84>
    bd68:      	ldr	x3, [x0, #0x8]
    bd6c:      	cmp	x19, x3
    bd70:      	b.ge	0xbe14 <_stogir.locals.shape+0xf4>
    bd74:      	add	x3, x0, #0x78
    bd78:      	ldr	x3, [x3, #0x8]
    bd7c:      	cmp	x19, x3
    bd80:      	b.ge	0xbfe8 <_stogir.locals.shape+0x2c8>
    bd84:      	ldr	x3, [x0, #0x78]
    bd88:      	add	x3, x20, x3
    bd8c:      	ldr	w3, [x3]
    bd90:      	sxtw	x3, w3
    bd94:      	cmp	x3, #0x0
    bd98:      	cset	w3, ge
    bd9c:      	ubfx	x3, x3, #0, #8
    bda0:      	b	0xbfec <_stogir.locals.shape+0x2cc>
    bda4:      	cmp	x19, #0x0
    bda8:      	b.ge	0xbe1c <_stogir.locals.shape+0xfc>
    bdac:      	add	x5, x0, #0x28
    bdb0:      	add	x6, x0, #0x50
    bdb4:      	ldr	x5, [x5, #0x8]
    bdb8:      	ldr	x6, [x6, #0x8]
    bdbc:      	cmp	x5, x6
    bdc0:      	b.ne	0xbdf0 <_stogir.locals.shape+0xd0>
    bdc4:      	cmp	x3, x5
    bdc8:      	b.gt	0xc058 <_stogir.locals.shape+0x338>
    bdcc:      	lsl	x3, x4, #2
    bdd0:      	ldr	x5, [x0, #0x50]
    bdd4:      	add	x3, x3, x5
    bdd8:      	ldr	w3, [x3]
    bddc:      	sxtw	x3, w3
    bde0:      	cmp	x3, #0x0
    bde4:      	cset	w3, gt
    bde8:      	ubfx	x3, x3, #0, #8
    bdec:      	b	0xc05c <_stogir.locals.shape+0x33c>
    bdf0:      	movz	x3, #0x0, lsl #48
    bdf4:      	b	0xbe20 <_stogir.locals.shape+0x100>
    bdf8:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000bdf8:  ARM64_RELOC_PAGE21	l_stogir.460
    bdfc:      	ldr	x16, [x16]
		000000000000bdfc:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    be00:      	orr	x0, x16, xzr
    be04:      	mov	x1, x0
    be08:      	mov	x0, #0x1                ; =1
    be0c:      	mov	x2, #0x1c               ; =28
    be10:      	b	0xbee0 <_stogir.locals.shape+0x1c0>
    be14:      	movz	x3, #0x0, lsl #48
    be18:      	b	0xbe20 <_stogir.locals.shape+0x100>
    be1c:      	movz	x3, #0x0, lsl #48
    be20:      	cmp	x3, #0x0
    be24:      	b.eq	0xbe88 <_stogir.locals.shape+0x168>
    be28:      	uxtb	w16, w1
    be2c:      	cmp	w16, wzr
    be30:      	b.eq	0xbe58 <_stogir.locals.shape+0x138>
    be34:      	lsl	x1, x19, #4
    be38:      	ldr	x3, [x0]
    be3c:      	add	x1, x1, x3
    be40:      	ldr	x3, [x1]
    be44:      	ldr	x1, [x1, #0x8]
    be48:      	fmov	d31, x1
    be4c:      	mov	x1, x3
    be50:      	fmov	x3, d31
    be54:      	b	0xbe78 <_stogir.locals.shape+0x158>
    be58:      	lsl	x1, x4, #4
    be5c:      	ldr	x3, [x0, #0x28]
    be60:      	add	x1, x1, x3
    be64:      	ldr	x3, [x1]
    be68:      	ldr	x1, [x1, #0x8]
    be6c:      	fmov	d31, x1
    be70:      	mov	x1, x3
    be74:      	fmov	x3, d31
    be78:      	mov	x4, x3
    be7c:      	mov	x3, x1
    be80:      	mov	x1, #0x1                ; =1
    be84:      	b	0xbe94 <_stogir.locals.shape+0x174>
    be88:      	movz	x1, #0x0, lsl #48
    be8c:      	movz	x3, #0x0, lsl #48
    be90:      	movz	x4, #0x0, lsl #48
    be94:      	lsr	w1, w1, #0
    be98:      	lsr	x16, x1, #0
    be9c:      	cmp	x16, #0x1
    bea0:      	b.eq	0xbebc <_stogir.locals.shape+0x19c>
    bea4:      	b.lo	0xbeac <_stogir.locals.shape+0x18c>
    bea8:      	b	0xbec0 <_stogir.locals.shape+0x1a0>
    beac:      	cmp	x16, #0x0
    beb0:      	b.eq	0xbeb8 <_stogir.locals.shape+0x198>
    beb4:      	b	0xbec0 <_stogir.locals.shape+0x1a0>
    beb8:      	b	0xbec4 <_stogir.locals.shape+0x1a4>
    bebc:      	b	0xbf0c <_stogir.locals.shape+0x1ec>
    bec0:      	b	0xc0ac <_stogir.locals.shape+0x38c>
    bec4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x270>
		000000000000bec4:  ARM64_RELOC_PAGE21	l_stogir.461
    bec8:      	ldr	x16, [x16]
		000000000000bec8:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    becc:      	orr	x0, x16, xzr
    bed0:      	mov	x21, x8
    bed4:      	mov	x1, x0
    bed8:      	mov	x0, #0x1                ; =1
    bedc:      	mov	x2, #0x16               ; =22
    bee0:      	str	x0, [x21]
    bee4:      	str	x1, [x21, #0x8]
    bee8:      	str	x2, [x21, #0x10]
    beec:      	ldr	x19, [sp, #0x20]
    bef0:      	ldr	x20, [sp, #0x28]
    bef4:      	ldr	x21, [sp, #0x30]
    bef8:      	ldr	x22, [sp, #0x38]
    befc:      	ldr	x29, [sp]
    bf00:      	ldr	x30, [sp, #0x8]
    bf04:      	add	sp, sp, #0x40
    bf08:      	ret
    bf0c:      	lsr	w2, w2, #0
    bf10:      	lsr	w1, w3, #0
    bf14:      	add	x16, sp, #0x10
    bf18:      	str	x3, [x16]
    bf1c:      	add	x16, sp, #0x10
    bf20:      	str	x4, [x16, #0x8]
    bf24:      	ubfx	x1, x1, #8, #8
    bf28:      	lsr	w1, w1, #0
    bf2c:      	mov	x21, x8
    bf30:      	mov	x22, x0
    bf34:      	mov	w0, w1
    bf38:      	mov	w1, w2
    bf3c:      	bl	0xbf3c <_stogir.locals.shape+0x21c>
		000000000000bf3c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    bf40:      	lsr	w0, w0, #0
    bf44:      	add	x16, sp, #0x10
    bf48:      	ldr	w1, [x16, #0xc]
    bf4c:      	sxtw	x0, w0
    bf50:      	sxtw	x1, w1
    bf54:      	cmp	x1, #0x0
    bf58:      	b.ne	0xbf60 <_stogir.locals.shape+0x240>
    bf5c:      	mov	x1, x0
    bf60:      	add	x16, sp, #0x10
    bf64:      	ldr	w2, [x16, #0x8]
    bf68:      	sxtw	x2, w2
    bf6c:      	cmp	x2, #0x0
    bf70:      	cset	w3, eq
    bf74:      	ubfx	x3, x3, #0, #8
    bf78:      	cmp	x2, #0x0
    bf7c:      	b.le	0xbff0 <_stogir.locals.shape+0x2d0>
    bf80:      	cmp	x2, #0x0
    bf84:      	b.le	0xc068 <_stogir.locals.shape+0x348>
    bf88:      	add	x4, x22, #0x110
    bf8c:      	add	x5, x4, #0x28
    bf90:      	ldr	x5, [x5, #0x8]
    bf94:      	cmp	x2, x5
    bf98:      	b.gt	0xc068 <_stogir.locals.shape+0x348>
    bf9c:      	sub	x2, x2, #0x1
    bfa0:      	mov	x17, #0x18              ; =24
    bfa4:      	mul	x2, x2, x17
    bfa8:      	ldr	x5, [x4, #0x28]
    bfac:      	add	x2, x2, x5
    bfb0:      	ldr	x5, [x2]
    bfb4:      	ldr	x2, [x2, #0x8]
    bfb8:      	ldr	x4, [x4, #0x8]
    bfbc:      	cmp	x5, #0x0
    bfc0:      	b.lt	0xc0a4 <_stogir.locals.shape+0x384>
    bfc4:      	cmp	x5, x4
    bfc8:      	b.gt	0xc0a4 <_stogir.locals.shape+0x384>
    bfcc:      	cmp	x2, #0x0
    bfd0:      	b.lt	0xc0a4 <_stogir.locals.shape+0x384>
    bfd4:      	sub	x4, x4, x5
    bfd8:      	cmp	x2, x4
    bfdc:      	b.gt	0xc0a4 <_stogir.locals.shape+0x384>
    bfe0:      	mov	x2, #0x1                ; =1
    bfe4:      	b	0xc0a8 <_stogir.locals.shape+0x388>
    bfe8:      	movz	x3, #0x0, lsl #48
    bfec:      	b	0xbe18 <_stogir.locals.shape+0xf8>
    bff0:      	mov	x2, x3
    bff4:      	cmp	x19, #0x0
    bff8:      	b.le	0xbdf8 <_stogir.locals.shape+0xd8>
    bffc:      	add	x16, sp, #0x10
    c000:      	ldr	w3, [x16]
    c004:      	uxtb	w3, w3
    c008:      	cmp	x3, #0x48
    c00c:      	b.ne	0xbdf8 <_stogir.locals.shape+0xd8>
    c010:      	ldr	x3, [x22, #0x78]
    c014:      	add	x3, x20, x3
    c018:      	ldr	w3, [x3]
    c01c:      	sxtw	x3, w3
    c020:      	cmp	x3, #0x3
    c024:      	b.ne	0xbdf8 <_stogir.locals.shape+0xd8>
    c028:      	cmp	x0, #0x0
    c02c:      	b.le	0xbdf8 <_stogir.locals.shape+0xd8>
    c030:      	cmp	x2, #0x0
    c034:      	b.eq	0xbdf8 <_stogir.locals.shape+0xd8>
    c038:      	cmp	x1, #0x0
    c03c:      	b.le	0xc0b4 <_stogir.locals.shape+0x394>
    c040:      	sub	x2, x1, #0x1
    c044:      	and	x2, x2, x1
    c048:      	cmp	x2, #0x0
    c04c:      	cset	w2, eq
    c050:      	ubfx	x2, x2, #0, #8
    c054:      	b	0xc0b8 <_stogir.locals.shape+0x398>
    c058:      	movz	x3, #0x0, lsl #48
    c05c:      	b	0xbdf4 <_stogir.locals.shape+0xd4>
    c060:      	mov	x2, #0x1                ; =1
    c064:      	b	0xbff4 <_stogir.locals.shape+0x2d4>
    c068:      	movz	x2, #0x0, lsl #48
    c06c:      	lsr	w2, w2, #0
    c070:      	lsr	x16, x2, #0
    c074:      	cmp	x16, #0x1
    c078:      	b.eq	0xc094 <_stogir.locals.shape+0x374>
    c07c:      	b.lo	0xc084 <_stogir.locals.shape+0x364>
    c080:      	b	0xc098 <_stogir.locals.shape+0x378>
    c084:      	cmp	x16, #0x0
    c088:      	b.eq	0xc090 <_stogir.locals.shape+0x370>
    c08c:      	b	0xc098 <_stogir.locals.shape+0x378>
    c090:      	b	0xc09c <_stogir.locals.shape+0x37c>
    c094:      	b	0xc060 <_stogir.locals.shape+0x340>
    c098:      	b	0xc194 <_stogir.locals.shape+0x474>
    c09c:      	mov	x2, x3
    c0a0:      	b	0xc064 <_stogir.locals.shape+0x344>
    c0a4:      	movz	x2, #0x0, lsl #48
    c0a8:      	b	0xc06c <_stogir.locals.shape+0x34c>
    c0ac:      	brk	#0
    c0b0:      	b	0xc0ac <_stogir.locals.shape+0x38c>
    c0b4:      	movz	x2, #0x0, lsl #48
    c0b8:      	cmp	x2, #0x0
    c0bc:      	b.eq	0xbdf8 <_stogir.locals.shape+0xd8>
    c0c0:      	add	x16, sp, #0x10
    c0c4:      	ldr	w2, [x16, #0x4]
    c0c8:      	sxtw	x2, w2
    c0cc:      	cmp	x2, #0x0
    c0d0:      	cset	w3, gt
    c0d4:      	movz	x16, #0x0, lsl #48
    c0d8:      	sub	x4, x16, x2
    c0dc:      	sub	x5, x4, #0x1
    c0e0:      	uxtb	w16, w3
    c0e4:      	cmp	w16, wzr
    c0e8:      	b.eq	0xc148 <_stogir.locals.shape+0x428>
    c0ec:      	ldr	x4, [x22, #0x8]
    c0f0:      	cmp	x2, x4
    c0f4:      	b.ge	0xc19c <_stogir.locals.shape+0x47c>
    c0f8:      	add	x4, x22, #0x78
    c0fc:      	ldr	x4, [x4, #0x8]
    c100:      	cmp	x2, x4
    c104:      	b.ge	0xc280 <_stogir.locals.shape+0x560>
    c108:      	lsl	x4, x2, #2
    c10c:      	ldr	x6, [x22, #0x78]
    c110:      	add	x4, x4, x6
    c114:      	ldr	w4, [x4]
    c118:      	sxtw	x4, w4
    c11c:      	cmp	x4, #0x0
    c120:      	cset	w4, ge
    c124:      	ubfx	x4, x4, #0, #8
    c128:      	b	0xc284 <_stogir.locals.shape+0x564>
    c12c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c12c:  ARM64_RELOC_PAGE21	l_stogir.462
    c130:      	ldr	x16, [x16]
		000000000000c130:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    c134:      	orr	x0, x16, xzr
    c138:      	mov	x1, x0
    c13c:      	mov	x0, #0x1                ; =1
    c140:      	mov	x2, #0x2c               ; =44
    c144:      	b	0xbe10 <_stogir.locals.shape+0xf0>
    c148:      	cmp	x2, #0x0
    c14c:      	b.ge	0xc1a4 <_stogir.locals.shape+0x484>
    c150:      	add	x6, x22, #0x28
    c154:      	add	x7, x22, #0x50
    c158:      	ldr	x6, [x6, #0x8]
    c15c:      	ldr	x7, [x7, #0x8]
    c160:      	cmp	x6, x7
    c164:      	b.ne	0xc278 <_stogir.locals.shape+0x558>
    c168:      	cmp	x4, x6
    c16c:      	b.gt	0xc288 <_stogir.locals.shape+0x568>
    c170:      	lsl	x4, x5, #2
    c174:      	ldr	x6, [x22, #0x50]
    c178:      	add	x4, x4, x6
    c17c:      	ldr	w4, [x4]
    c180:      	sxtw	x4, w4
    c184:      	cmp	x4, #0x0
    c188:      	cset	w4, gt
    c18c:      	ubfx	x4, x4, #0, #8
    c190:      	b	0xc28c <_stogir.locals.shape+0x56c>
    c194:      	brk	#0
    c198:      	b	0xc194 <_stogir.locals.shape+0x474>
    c19c:      	movz	x4, #0x0, lsl #48
    c1a0:      	b	0xc1a8 <_stogir.locals.shape+0x488>
    c1a4:      	movz	x4, #0x0, lsl #48
    c1a8:      	cmp	x4, #0x0
    c1ac:      	b.eq	0xc1ec <_stogir.locals.shape+0x4cc>
    c1b0:      	uxtb	w16, w3
    c1b4:      	cmp	w16, wzr
    c1b8:      	b.eq	0xc1d0 <_stogir.locals.shape+0x4b0>
    c1bc:      	lsl	x2, x2, #4
    c1c0:      	ldr	x3, [x22]
    c1c4:      	add	x2, x2, x3
    c1c8:      	ldr	x2, [x2]
    c1cc:      	b	0xc1e0 <_stogir.locals.shape+0x4c0>
    c1d0:      	lsl	x2, x5, #4
    c1d4:      	ldr	x3, [x22, #0x28]
    c1d8:      	add	x2, x2, x3
    c1dc:      	ldr	x2, [x2]
    c1e0:      	mov	x3, x2
    c1e4:      	mov	x2, #0x1                ; =1
    c1e8:      	b	0xc1f4 <_stogir.locals.shape+0x4d4>
    c1ec:      	movz	x2, #0x0, lsl #48
    c1f0:      	movz	x3, #0x0, lsl #48
    c1f4:      	lsr	w2, w2, #0
    c1f8:      	lsr	x16, x2, #0
    c1fc:      	cmp	x16, #0x1
    c200:      	b.eq	0xc21c <_stogir.locals.shape+0x4fc>
    c204:      	b.lo	0xc20c <_stogir.locals.shape+0x4ec>
    c208:      	b	0xc220 <_stogir.locals.shape+0x500>
    c20c:      	cmp	x16, #0x0
    c210:      	b.eq	0xc218 <_stogir.locals.shape+0x4f8>
    c214:      	b	0xc220 <_stogir.locals.shape+0x500>
    c218:      	b	0xc224 <_stogir.locals.shape+0x504>
    c21c:      	b	0xc240 <_stogir.locals.shape+0x520>
    c220:      	b	0xc2b8 <_stogir.locals.shape+0x598>
    c224:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c224:  ARM64_RELOC_PAGE21	l_stogir.463
    c228:      	ldr	x16, [x16]
		000000000000c228:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    c22c:      	orr	x0, x16, xzr
    c230:      	mov	x1, x0
    c234:      	mov	x0, #0x1                ; =1
    c238:      	mov	x2, #0x1d               ; =29
    c23c:      	b	0xc144 <_stogir.locals.shape+0x424>
    c240:      	add	x16, sp, #0x10
    c244:      	ldr	w2, [x16, #0x4]
    c248:      	sxtw	x2, w2
    c24c:      	cmp	x2, #0x0
    c250:      	b.le	0xc12c <_stogir.locals.shape+0x40c>
    c254:      	uxtb	w3, w3
    c258:      	cmp	x3, #0x83
    c25c:      	b.ge	0xc290 <_stogir.locals.shape+0x570>
    c260:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c260:  ARM64_RELOC_PAGE21	l_stogir.464
    c264:      	ldr	x16, [x16]
		000000000000c264:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    c268:      	orr	x2, x16, xzr
    c26c:      	add	x2, x3, x2
    c270:      	ldrb	w2, [x2]
    c274:      	b	0xc294 <_stogir.locals.shape+0x574>
    c278:      	movz	x4, #0x0, lsl #48
    c27c:      	b	0xc1a8 <_stogir.locals.shape+0x488>
    c280:      	movz	x4, #0x0, lsl #48
    c284:      	b	0xc1a0 <_stogir.locals.shape+0x480>
    c288:      	movz	x4, #0x0, lsl #48
    c28c:      	b	0xc27c <_stogir.locals.shape+0x55c>
    c290:      	movz	x2, #0x0, lsl #48
    c294:      	uxtb	w2, w2
    c298:      	and	x2, x2, #0x2
    c29c:      	uxtb	w2, w2
    c2a0:      	cmp	x2, #0x0
    c2a4:      	b.eq	0xc12c <_stogir.locals.shape+0x40c>
    c2a8:      	mov	x2, x1
    c2ac:      	mov	x1, x0
    c2b0:      	movz	x0, #0x0, lsl #48
    c2b4:      	b	0xc144 <_stogir.locals.shape+0x424>
    c2b8:      	brk	#0
    c2bc:      	b	0xc2b8 <_stogir.locals.shape+0x598>

000000000000c2c0 <_stogir.conversion.policy>:
    c2c0:      	sub	sp, sp, #0x70
    c2c4:      	str	x29, [sp]
    c2c8:      	str	x30, [sp, #0x8]
    c2cc:      	mov	x29, sp
    c2d0:      	str	x19, [sp, #0x20]
    c2d4:      	str	x20, [sp, #0x28]
    c2d8:      	str	x21, [sp, #0x30]
    c2dc:      	str	x22, [sp, #0x38]
    c2e0:      	str	x23, [sp, #0x40]
    c2e4:      	str	x24, [sp, #0x48]
    c2e8:      	str	x25, [sp, #0x50]
    c2ec:      	str	x26, [sp, #0x58]
    c2f0:      	str	x27, [sp, #0x60]
    c2f4:      	str	x28, [sp, #0x68]
    c2f8:      	sxtw	x19, w0
    c2fc:      	sxtw	x20, w1
    c300:      	sxtw	x21, w2
    c304:      	cmp	x19, #0x24
    c308:      	b.ne	0xc358 <_stogir.conversion.policy+0x98>
    c30c:      	cmp	x20, #0xf
    c310:      	b.le	0xc574 <_stogir.conversion.policy+0x2b4>
    c314:      	cmp	x20, #0x80
    c318:      	b.ge	0xc574 <_stogir.conversion.policy+0x2b4>
    c31c:      	and	x0, x20, #0xf
    c320:      	lsr	w0, w0, #0
    c324:      	sxtw	x0, w0
    c328:      	cmp	x0, #0x1
    c32c:      	b.lt	0xc574 <_stogir.conversion.policy+0x2b4>
    c330:      	and	x0, x20, #0xf
    c334:      	lsr	w0, w0, #0
    c338:      	sxtw	x0, w0
    c33c:      	cmp	x0, #0xd
    c340:      	b.gt	0xc574 <_stogir.conversion.policy+0x2b4>
    c344:      	mov	x0, #0x1                ; =1
    c348:      	b	0xc350 <_stogir.conversion.policy+0x90>
    c34c:      	movz	x0, #0x0, lsl #48
    c350:      	mov	x22, x0
    c354:      	b	0xc35c <_stogir.conversion.policy+0x9c>
    c358:      	movz	x22, #0x0, lsl #48
    c35c:      	sxtw	x23, w3
    c360:      	cmp	x20, #0xd
    c364:      	cset	w24, eq
    c368:      	cmp	x20, #0xc
    c36c:      	cset	w25, eq
    c370:      	cmp	x23, #0x4
    c374:      	cset	w26, eq
    c378:      	cmp	x23, #0x8
    c37c:      	cset	w27, eq
    c380:      	cmp	x22, #0x0
    c384:      	b.eq	0xc868 <_stogir.conversion.policy+0x5a8>
    c388:      	lsr	w1, w1, #0
    c38c:      	lsr	w3, w3, #0
    c390:      	mov	w0, w1
    c394:      	mov	w1, w3
    c398:      	str	x8, [sp, #0x18]
    c39c:      	mov	w28, w3
    c3a0:      	str	x23, [sp, #0x10]
    c3a4:      	mov	w23, w2
    c3a8:      	bl	0xc3a8 <_stogir.conversion.policy+0xe8>
		000000000000c3a8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c3ac:      	lsr	w0, w0, #0
    c3b0:      	sxtw	x0, w0
    c3b4:      	b	0xc3c4 <_stogir.conversion.policy+0x104>
    c3b8:      	mov	x0, #0x1                ; =1
    c3bc:      	lsr	w0, w0, #0
    c3c0:      	sxtw	x0, w0
    c3c4:      	cmp	x21, #0xd
    c3c8:      	cset	w1, eq
    c3cc:      	cmp	x21, #0xc
    c3d0:      	cset	w2, eq
    c3d4:      	cmp	x22, #0x0
    c3d8:      	b.eq	0xc87c <_stogir.conversion.policy+0x5bc>
    c3dc:      	lsr	w23, w23, #0
    c3e0:      	lsr	w28, w28, #0
    c3e4:      	mov	x22, x0
    c3e8:      	mov	w0, w23
    c3ec:      	mov	w23, w1
    c3f0:      	mov	w1, w28
    c3f4:      	mov	w28, w2
    c3f8:      	bl	0xc3f8 <_stogir.conversion.policy+0x138>
		000000000000c3f8:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c3fc:      	lsr	w0, w0, #0
    c400:      	sxtw	x0, w0
    c404:      	b	0xc414 <_stogir.conversion.policy+0x154>
    c408:      	mov	x0, #0x1                ; =1
    c40c:      	lsr	w0, w0, #0
    c410:      	sxtw	x0, w0
    c414:      	cmp	x19, #0x21
    c418:      	b.lt	0xc4f4 <_stogir.conversion.policy+0x234>
    c41c:      	cmp	x19, #0x27
    c420:      	b.gt	0xc4f4 <_stogir.conversion.policy+0x234>
    c424:      	lsl	x1, x22, #3
    c428:      	lsr	w1, w1, #0
    c42c:      	sxtw	x1, w1
    c430:      	cmp	x1, #0x0
    c434:      	b.le	0xc4f4 <_stogir.conversion.policy+0x234>
    c438:      	lsl	x0, x0, #3
    c43c:      	lsr	w0, w0, #0
    c440:      	sxtw	x0, w0
    c444:      	cmp	x0, #0x0
    c448:      	b.le	0xc4f4 <_stogir.conversion.policy+0x234>
    c44c:      	cmp	x19, #0x26
    c450:      	cset	w2, eq
    c454:      	cmp	x20, #0x1
    c458:      	cset	w3, ge
    c45c:      	cmp	x20, #0xb
    c460:      	cset	w4, le
    c464:      	cmp	x21, #0x1
    c468:      	cset	w5, ge
    c46c:      	cmp	x21, #0xb
    c470:      	cset	w6, le
    c474:      	cmp	x19, #0x25
    c478:      	b.lt	0xc708 <_stogir.conversion.policy+0x448>
    c47c:      	ubfx	x23, x23, #0, #8
    c480:      	cmp	x19, #0x25
    c484:      	b.ne	0xc778 <_stogir.conversion.policy+0x4b8>
    c488:      	uxtb	w16, w3
    c48c:      	cmp	w16, wzr
    c490:      	b.eq	0xc770 <_stogir.conversion.policy+0x4b0>
    c494:      	uxtb	w16, w4
    c498:      	cmp	w16, wzr
    c49c:      	b.eq	0xc770 <_stogir.conversion.policy+0x4b0>
    c4a0:      	uxtb	w16, w28
    c4a4:      	cmp	w16, wzr
    c4a8:      	b.eq	0xc7ec <_stogir.conversion.policy+0x52c>
    c4ac:      	mov	x3, #0x1                ; =1
    c4b0:      	b	0xc7f0 <_stogir.conversion.policy+0x530>
    c4b4:      	uxtb	w16, w26
    c4b8:      	cmp	w16, wzr
    c4bc:      	b.ne	0xc554 <_stogir.conversion.policy+0x294>
    c4c0:      	uxtb	w16, w27
    c4c4:      	cmp	w16, wzr
    c4c8:      	b.ne	0xc554 <_stogir.conversion.policy+0x294>
    c4cc:      	movn	x0, #0x0, lsl #48
    c4d0:      	b	0xc40c <_stogir.conversion.policy+0x14c>
    c4d4:      	uxtb	w16, w26
    c4d8:      	cmp	w16, wzr
    c4dc:      	b.ne	0xc564 <_stogir.conversion.policy+0x2a4>
    c4e0:      	uxtb	w16, w27
    c4e4:      	cmp	w16, wzr
    c4e8:      	b.ne	0xc564 <_stogir.conversion.policy+0x2a4>
    c4ec:      	movn	x0, #0x0, lsl #48
    c4f0:      	b	0xc3bc <_stogir.conversion.policy+0xfc>
    c4f4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c4f4:  ARM64_RELOC_PAGE21	l_stogir.465
    c4f8:      	ldr	x16, [x16]
		000000000000c4f8:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    c4fc:      	orr	x0, x16, xzr
    c500:      	mov	x1, x0
    c504:      	mov	x0, #0x1                ; =1
    c508:      	mov	x2, #0x22               ; =34
    c50c:      	ldr	x3, [sp, #0x18]
    c510:      	str	x0, [x3]
    c514:      	str	x1, [x3, #0x8]
    c518:      	str	x2, [x3, #0x10]
    c51c:      	ldr	x19, [sp, #0x20]
    c520:      	ldr	x20, [sp, #0x28]
    c524:      	ldr	x21, [sp, #0x30]
    c528:      	ldr	x22, [sp, #0x38]
    c52c:      	ldr	x23, [sp, #0x40]
    c530:      	ldr	x24, [sp, #0x48]
    c534:      	ldr	x25, [sp, #0x50]
    c538:      	ldr	x26, [sp, #0x58]
    c53c:      	ldr	x27, [sp, #0x60]
    c540:      	ldr	x28, [sp, #0x68]
    c544:      	ldr	x29, [sp]
    c548:      	ldr	x30, [sp, #0x8]
    c54c:      	add	sp, sp, #0x70
    c550:      	ret
    c554:      	cmp	x21, #0x0
    c558:      	b.ne	0xc5bc <_stogir.conversion.policy+0x2fc>
    c55c:      	movz	x0, #0x0, lsl #48
    c560:      	b	0xc40c <_stogir.conversion.policy+0x14c>
    c564:      	cmp	x20, #0x0
    c568:      	b.ne	0xc634 <_stogir.conversion.policy+0x374>
    c56c:      	movz	x0, #0x0, lsl #48
    c570:      	b	0xc3bc <_stogir.conversion.policy+0xfc>
    c574:      	cmp	x21, #0xf
    c578:      	b.le	0xc34c <_stogir.conversion.policy+0x8c>
    c57c:      	cmp	x21, #0x80
    c580:      	b.ge	0xc5b4 <_stogir.conversion.policy+0x2f4>
    c584:      	and	x0, x21, #0xf
    c588:      	lsr	w0, w0, #0
    c58c:      	sxtw	x0, w0
    c590:      	cmp	x0, #0x1
    c594:      	b.lt	0xc6ac <_stogir.conversion.policy+0x3ec>
    c598:      	and	x0, x21, #0xf
    c59c:      	lsr	w0, w0, #0
    c5a0:      	sxtw	x0, w0
    c5a4:      	cmp	x0, #0xd
    c5a8:      	cset	w0, le
    c5ac:      	ubfx	x0, x0, #0, #8
    c5b0:      	b	0xc6b0 <_stogir.conversion.policy+0x3f0>
    c5b4:      	movz	x0, #0x0, lsl #48
    c5b8:      	b	0xc350 <_stogir.conversion.policy+0x90>
    c5bc:      	cmp	x21, #0x1
    c5c0:      	b.eq	0xc408 <_stogir.conversion.policy+0x148>
    c5c4:      	cmp	x21, #0x2
    c5c8:      	b.eq	0xc408 <_stogir.conversion.policy+0x148>
    c5cc:      	cmp	x21, #0x7
    c5d0:      	b.eq	0xc408 <_stogir.conversion.policy+0x148>
    c5d4:      	cmp	x21, #0x8
    c5d8:      	b.eq	0xc408 <_stogir.conversion.policy+0x148>
    c5dc:      	cmp	x21, #0x3
    c5e0:      	b.eq	0xc7a4 <_stogir.conversion.policy+0x4e4>
    c5e4:      	cmp	x21, #0x9
    c5e8:      	b.eq	0xc7a4 <_stogir.conversion.policy+0x4e4>
    c5ec:      	cmp	x21, #0x4
    c5f0:      	b.eq	0xc814 <_stogir.conversion.policy+0x554>
    c5f4:      	cmp	x21, #0xa
    c5f8:      	b.eq	0xc814 <_stogir.conversion.policy+0x554>
    c5fc:      	uxtb	w16, w23
    c600:      	cmp	w16, wzr
    c604:      	b.ne	0xc814 <_stogir.conversion.policy+0x554>
    c608:      	cmp	x21, #0x5
    c60c:      	b.eq	0xc848 <_stogir.conversion.policy+0x588>
    c610:      	cmp	x21, #0xb
    c614:      	b.eq	0xc848 <_stogir.conversion.policy+0x588>
    c618:      	uxtb	w16, w28
    c61c:      	cmp	w16, wzr
    c620:      	b.ne	0xc848 <_stogir.conversion.policy+0x588>
    c624:      	cmp	x21, #0x6
    c628:      	b.ne	0xc858 <_stogir.conversion.policy+0x598>
    c62c:      	ldr	x0, [sp, #0x10]
    c630:      	b	0xc85c <_stogir.conversion.policy+0x59c>
    c634:      	cmp	x20, #0x1
    c638:      	b.eq	0xc3b8 <_stogir.conversion.policy+0xf8>
    c63c:      	cmp	x20, #0x2
    c640:      	b.eq	0xc3b8 <_stogir.conversion.policy+0xf8>
    c644:      	cmp	x20, #0x7
    c648:      	b.eq	0xc3b8 <_stogir.conversion.policy+0xf8>
    c64c:      	cmp	x20, #0x8
    c650:      	b.eq	0xc3b8 <_stogir.conversion.policy+0xf8>
    c654:      	cmp	x20, #0x3
    c658:      	b.eq	0xc7ac <_stogir.conversion.policy+0x4ec>
    c65c:      	cmp	x20, #0x9
    c660:      	b.eq	0xc7ac <_stogir.conversion.policy+0x4ec>
    c664:      	cmp	x20, #0x4
    c668:      	b.eq	0xc81c <_stogir.conversion.policy+0x55c>
    c66c:      	cmp	x20, #0xa
    c670:      	b.eq	0xc81c <_stogir.conversion.policy+0x55c>
    c674:      	uxtb	w16, w24
    c678:      	cmp	w16, wzr
    c67c:      	b.ne	0xc81c <_stogir.conversion.policy+0x55c>
    c680:      	cmp	x20, #0x5
    c684:      	b.eq	0xc850 <_stogir.conversion.policy+0x590>
    c688:      	cmp	x20, #0xb
    c68c:      	b.eq	0xc850 <_stogir.conversion.policy+0x590>
    c690:      	uxtb	w16, w25
    c694:      	cmp	w16, wzr
    c698:      	b.ne	0xc850 <_stogir.conversion.policy+0x590>
    c69c:      	cmp	x20, #0x6
    c6a0:      	b.ne	0xc860 <_stogir.conversion.policy+0x5a0>
    c6a4:      	ldr	x0, [sp, #0x10]
    c6a8:      	b	0xc864 <_stogir.conversion.policy+0x5a4>
    c6ac:      	movz	x0, #0x0, lsl #48
    c6b0:      	b	0xc5b8 <_stogir.conversion.policy+0x2f8>
    c6b4:      	mov	x3, #0x1                ; =1
    c6b8:      	cmp	x3, #0x0
    c6bc:      	b.ne	0xc4f4 <_stogir.conversion.policy+0x234>
    c6c0:      	cmp	x19, #0x23
    c6c4:      	b.eq	0xc6d8 <_stogir.conversion.policy+0x418>
    c6c8:      	uxtb	w16, w2
    c6cc:      	cmp	w16, wzr
    c6d0:      	b.ne	0xc6d8 <_stogir.conversion.policy+0x418>
    c6d4:      	mov	x0, x1
    c6d8:      	and	x0, x0, #0xffffffff
    c6dc:      	mov	x1, x0
    c6e0:      	movz	x0, #0x0, lsl #48
    c6e4:      	movz	x2, #0x0, lsl #48
    c6e8:      	b	0xc50c <_stogir.conversion.policy+0x24c>
    c6ec:      	movz	x3, #0x0, lsl #48
    c6f0:      	cmp	x3, #0x0
    c6f4:      	cset	w3, ne
    c6f8:      	uxtb	w16, w3
    c6fc:      	cmp	w16, wzr
    c700:      	cset	x3, eq
    c704:      	b	0xc6b8 <_stogir.conversion.policy+0x3f8>
    c708:      	cmp	x19, #0x24
    c70c:      	b.ne	0xc728 <_stogir.conversion.policy+0x468>
    c710:      	cmp	x1, x0
    c714:      	cset	w3, eq
    c718:      	uxtb	w16, w3
    c71c:      	cmp	w16, wzr
    c720:      	cset	x3, eq
    c724:      	b	0xc6b8 <_stogir.conversion.policy+0x3f8>
    c728:      	uxtb	w16, w3
    c72c:      	cmp	w16, wzr
    c730:      	b.eq	0xc6b4 <_stogir.conversion.policy+0x3f4>
    c734:      	uxtb	w16, w4
    c738:      	cmp	w16, wzr
    c73c:      	b.eq	0xc6b4 <_stogir.conversion.policy+0x3f4>
    c740:      	uxtb	w16, w5
    c744:      	cmp	w16, wzr
    c748:      	b.eq	0xc7e4 <_stogir.conversion.policy+0x524>
    c74c:      	uxtb	w16, w6
    c750:      	cmp	w16, wzr
    c754:      	b.eq	0xc7e4 <_stogir.conversion.policy+0x524>
    c758:      	cmp	x19, #0x23
    c75c:      	b.ne	0xc838 <_stogir.conversion.policy+0x578>
    c760:      	cmp	x0, x1
    c764:      	cset	w3, ge
    c768:      	ubfx	x3, x3, #0, #8
    c76c:      	b	0xc844 <_stogir.conversion.policy+0x584>
    c770:      	movz	x3, #0x0, lsl #48
    c774:      	b	0xc6f0 <_stogir.conversion.policy+0x430>
    c778:      	uxtb	w16, w2
    c77c:      	cmp	w16, wzr
    c780:      	b.eq	0xc7bc <_stogir.conversion.policy+0x4fc>
    c784:      	uxtb	w16, w25
    c788:      	cmp	w16, wzr
    c78c:      	b.ne	0xc7fc <_stogir.conversion.policy+0x53c>
    c790:      	uxtb	w16, w24
    c794:      	cmp	w16, wzr
    c798:      	b.ne	0xc7fc <_stogir.conversion.policy+0x53c>
    c79c:      	movz	x3, #0x0, lsl #48
    c7a0:      	b	0xc7b8 <_stogir.conversion.policy+0x4f8>
    c7a4:      	mov	x0, #0x2                ; =2
    c7a8:      	b	0xc40c <_stogir.conversion.policy+0x14c>
    c7ac:      	mov	x0, #0x2                ; =2
    c7b0:      	b	0xc3bc <_stogir.conversion.policy+0xfc>
    c7b4:      	movz	x3, #0x0, lsl #48
    c7b8:      	b	0xc6f0 <_stogir.conversion.policy+0x430>
    c7bc:      	cmp	x19, #0x27
    c7c0:      	b.ne	0xc6ec <_stogir.conversion.policy+0x42c>
    c7c4:      	uxtb	w16, w25
    c7c8:      	cmp	w16, wzr
    c7cc:      	b.ne	0xc824 <_stogir.conversion.policy+0x564>
    c7d0:      	uxtb	w16, w24
    c7d4:      	cmp	w16, wzr
    c7d8:      	b.ne	0xc824 <_stogir.conversion.policy+0x564>
    c7dc:      	movz	x3, #0x0, lsl #48
    c7e0:      	b	0xc7f8 <_stogir.conversion.policy+0x538>
    c7e4:      	mov	x3, #0x1                ; =1
    c7e8:      	b	0xc6b8 <_stogir.conversion.policy+0x3f8>
    c7ec:      	mov	x3, x23
    c7f0:      	b	0xc774 <_stogir.conversion.policy+0x4b4>
    c7f4:      	mov	x3, x23
    c7f8:      	b	0xc6f0 <_stogir.conversion.policy+0x430>
    c7fc:      	uxtb	w16, w5
    c800:      	cmp	w16, wzr
    c804:      	b.eq	0xc7b4 <_stogir.conversion.policy+0x4f4>
    c808:      	ubfx	x6, x6, #0, #8
    c80c:      	mov	x3, x6
    c810:      	b	0xc7b8 <_stogir.conversion.policy+0x4f8>
    c814:      	mov	x0, #0x4                ; =4
    c818:      	b	0xc7a8 <_stogir.conversion.policy+0x4e8>
    c81c:      	mov	x0, #0x4                ; =4
    c820:      	b	0xc7b0 <_stogir.conversion.policy+0x4f0>
    c824:      	uxtb	w16, w28
    c828:      	cmp	w16, wzr
    c82c:      	b.eq	0xc7f4 <_stogir.conversion.policy+0x534>
    c830:      	mov	x3, #0x1                ; =1
    c834:      	b	0xc7f8 <_stogir.conversion.policy+0x538>
    c838:      	cmp	x0, x1
    c83c:      	cset	w3, le
    c840:      	ubfx	x3, x3, #0, #8
    c844:      	b	0xc7e8 <_stogir.conversion.policy+0x528>
    c848:      	mov	x0, #0x8                ; =8
    c84c:      	b	0xc818 <_stogir.conversion.policy+0x558>
    c850:      	mov	x0, #0x8                ; =8
    c854:      	b	0xc820 <_stogir.conversion.policy+0x560>
    c858:      	movn	x0, #0x0, lsl #48
    c85c:      	b	0xc84c <_stogir.conversion.policy+0x58c>
    c860:      	movn	x0, #0x0, lsl #48
    c864:      	b	0xc854 <_stogir.conversion.policy+0x594>
    c868:      	str	x8, [sp, #0x18]
    c86c:      	mov	w28, w3
    c870:      	str	x23, [sp, #0x10]
    c874:      	mov	w23, w2
    c878:      	b	0xc4d4 <_stogir.conversion.policy+0x214>
    c87c:      	mov	x22, x0
    c880:      	mov	w23, w1
    c884:      	mov	w28, w2
    c888:      	b	0xc4b4 <_stogir.conversion.policy+0x1f4>

000000000000c88c <_stogir.conditional.operands>:
    c88c:      	sub	sp, sp, #0x70
    c890:      	str	x29, [sp]
    c894:      	str	x30, [sp, #0x8]
    c898:      	mov	x29, sp
    c89c:      	str	x19, [sp, #0x30]
    c8a0:      	str	x20, [sp, #0x38]
    c8a4:      	str	x21, [sp, #0x40]
    c8a8:      	str	x22, [sp, #0x48]
    c8ac:      	str	x23, [sp, #0x50]
    c8b0:      	str	x24, [sp, #0x58]
    c8b4:      	str	x25, [sp, #0x60]
    c8b8:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c8b8:  ARM64_RELOC_PAGE21	l_stogir.466
    c8bc:      	ldr	x16, [x16]
		000000000000c8bc:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    c8c0:      	orr	x19, x16, xzr
    c8c4:      	sxtw	x20, w1
    c8c8:      	cmp	x20, #0x0
    c8cc:      	b.ne	0xc9b0 <_stogir.conditional.operands+0x124>
    c8d0:      	mov	x21, x8
    c8d4:      	mov	x22, x0
    c8d8:      	mov	w23, w2
    c8dc:      	mov	w24, w3
    c8e0:      	mov	w25, w4
    c8e4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000c8e4:  ARM64_RELOC_PAGE21	l_stogir.467
    c8e8:      	ldr	x16, [x16]
		000000000000c8e8:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    c8ec:      	orr	x0, x16, xzr
    c8f0:      	mov	x1, #0x2b               ; =43
    c8f4:      	sxtw	x23, w23
    c8f8:      	cmp	x23, #0x0
    c8fc:      	cset	w2, gt
    c900:      	movz	x16, #0x0, lsl #48
    c904:      	sub	x3, x16, x23
    c908:      	sub	x4, x3, #0x1
    c90c:      	uxtb	w16, w2
    c910:      	cmp	w16, wzr
    c914:      	b.eq	0xc964 <_stogir.conditional.operands+0xd8>
    c918:      	ldr	x3, [x22, #0x8]
    c91c:      	cmp	x23, x3
    c920:      	b.ge	0xc9f4 <_stogir.conditional.operands+0x168>
    c924:      	add	x3, x22, #0x78
    c928:      	ldr	x3, [x3, #0x8]
    c92c:      	cmp	x23, x3
    c930:      	b.ge	0xcdf8 <_stogir.conditional.operands+0x56c>
    c934:      	lsl	x3, x23, #2
    c938:      	ldr	x5, [x22, #0x78]
    c93c:      	add	x3, x3, x5
    c940:      	ldr	w3, [x3]
    c944:      	sxtw	x3, w3
    c948:      	cmp	x3, #0x0
    c94c:      	cset	w3, ge
    c950:      	ubfx	x3, x3, #0, #8
    c954:      	fmov	d31, x0
    c958:      	mov	x0, x3
    c95c:      	fmov	x3, d31
    c960:      	b	0xce00 <_stogir.conditional.operands+0x574>
    c964:      	cmp	x23, #0x0
    c968:      	b.ge	0xca04 <_stogir.conditional.operands+0x178>
    c96c:      	add	x5, x22, #0x28
    c970:      	add	x6, x22, #0x50
    c974:      	ldr	x5, [x5, #0x8]
    c978:      	ldr	x6, [x6, #0x8]
    c97c:      	cmp	x5, x6
    c980:      	b.ne	0xc9e4 <_stogir.conditional.operands+0x158>
    c984:      	cmp	x3, x5
    c988:      	b.gt	0xce58 <_stogir.conditional.operands+0x5cc>
    c98c:      	lsl	x3, x4, #2
    c990:      	ldr	x5, [x22, #0x50]
    c994:      	add	x3, x3, x5
    c998:      	ldr	w3, [x3]
    c99c:      	sxtw	x3, w3
    c9a0:      	cmp	x3, #0x0
    c9a4:      	cset	w3, gt
    c9a8:      	ubfx	x3, x3, #0, #8
    c9ac:      	b	0xce5c <_stogir.conditional.operands+0x5d0>
    c9b0:      	lsr	w1, w1, #0
    c9b4:      	mov	x21, x8
    c9b8:      	mov	x22, x0
    c9bc:      	mov	w0, w1
    c9c0:      	mov	w23, w2
    c9c4:      	mov	w24, w3
    c9c8:      	mov	w25, w4
    c9cc:      	bl	0xc9cc <_stogir.conditional.operands+0x140>
		000000000000c9cc:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    c9d0:      	cmp	x0, #0x0
    c9d4:      	b.eq	0xc8e4 <_stogir.conditional.operands+0x58>
    c9d8:      	mov	x0, x19
    c9dc:      	movz	x1, #0x0, lsl #48
    c9e0:      	b	0xc8f4 <_stogir.conditional.operands+0x68>
    c9e4:      	movz	x3, #0x0, lsl #48
    c9e8:      	b	0xca08 <_stogir.conditional.operands+0x17c>
    c9ec:      	movz	x7, #0x0, lsl #48
    c9f0:      	b	0xcac8 <_stogir.conditional.operands+0x23c>
    c9f4:      	mov	x3, x1
    c9f8:      	mov	x1, x0
    c9fc:      	movz	x0, #0x0, lsl #48
    ca00:      	b	0xca18 <_stogir.conditional.operands+0x18c>
    ca04:      	movz	x3, #0x0, lsl #48
    ca08:      	fmov	d31, x0
    ca0c:      	mov	x0, x3
    ca10:      	mov	x3, x1
    ca14:      	fmov	x1, d31
    ca18:      	cmp	x0, #0x0
    ca1c:      	b.eq	0xca60 <_stogir.conditional.operands+0x1d4>
    ca20:      	uxtb	w16, w2
    ca24:      	cmp	w16, wzr
    ca28:      	b.eq	0xca40 <_stogir.conditional.operands+0x1b4>
    ca2c:      	lsl	x0, x23, #4
    ca30:      	ldr	x2, [x22]
    ca34:      	add	x0, x0, x2
    ca38:      	ldr	x0, [x0]
    ca3c:      	b	0xca50 <_stogir.conditional.operands+0x1c4>
    ca40:      	lsl	x0, x4, #4
    ca44:      	ldr	x2, [x22, #0x28]
    ca48:      	add	x0, x0, x2
    ca4c:      	ldr	x0, [x0]
    ca50:      	mov	x2, x1
    ca54:      	mov	x1, x0
    ca58:      	mov	x0, #0x1                ; =1
    ca5c:      	b	0xca6c <_stogir.conditional.operands+0x1e0>
    ca60:      	mov	x2, x1
    ca64:      	movz	x0, #0x0, lsl #48
    ca68:      	movz	x1, #0x0, lsl #48
    ca6c:      	lsr	w0, w0, #0
    ca70:      	lsr	x16, x0, #0
    ca74:      	cmp	x16, #0x1
    ca78:      	b.eq	0xca94 <_stogir.conditional.operands+0x208>
    ca7c:      	b.lo	0xca84 <_stogir.conditional.operands+0x1f8>
    ca80:      	b	0xca98 <_stogir.conditional.operands+0x20c>
    ca84:      	cmp	x16, #0x0
    ca88:      	b.eq	0xca90 <_stogir.conditional.operands+0x204>
    ca8c:      	b	0xca98 <_stogir.conditional.operands+0x20c>
    ca90:      	b	0xca9c <_stogir.conditional.operands+0x210>
    ca94:      	b	0xcddc <_stogir.conditional.operands+0x550>
    ca98:      	b	0xce88 <_stogir.conditional.operands+0x5fc>
    ca9c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000ca9c:  ARM64_RELOC_PAGE21	l_stogir.468
    caa0:      	ldr	x16, [x16]
		000000000000caa0:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    caa4:      	orr	x0, x16, xzr
    caa8:      	mov	x1, #0x16               ; =22
    caac:      	b	0xcad4 <_stogir.conditional.operands+0x248>
    cab0:      	movz	x7, #0x0, lsl #48
    cab4:      	fmov	d31, x6
    cab8:      	mov	x6, x7
    cabc:      	fmov	x7, d31
    cac0:      	b	0xcb28 <_stogir.conditional.operands+0x29c>
    cac4:      	movz	x7, #0x0, lsl #48
    cac8:      	b	0xcb30 <_stogir.conditional.operands+0x2a4>
    cacc:      	mov	x0, x1
    cad0:      	mov	x1, x2
    cad4:      	add	x16, sp, #0x20
    cad8:      	orr	x2, x16, xzr
    cadc:      	lsr	w24, w24, #0
    cae0:      	lsr	w25, w25, #0
    cae4:      	add	x3, x22, #0x78
    cae8:      	add	x4, x22, #0x28
    caec:      	add	x5, x22, #0x50
    caf0:      	add	x16, sp, #0x10
    caf4:      	str	w24, [x16]
    caf8:      	add	x16, sp, #0x10
    cafc:      	str	w25, [x16, #0x4]
    cb00:      	add	x16, sp, #0x10
    cb04:      	ldr	x6, [x16]
    cb08:      	add	x16, sp, #0x20
    cb0c:      	str	x6, [x16]
    cb10:      	mov	x6, x1
    cb14:      	mov	x1, x0
    cb18:      	movz	x0, #0x0, lsl #48
    cb1c:      	b	0xcc10 <_stogir.conditional.operands+0x384>
    cb20:      	mov	x7, x6
    cb24:      	movz	x6, #0x0, lsl #48
    cb28:      	b	0xcb3c <_stogir.conditional.operands+0x2b0>
    cb2c:      	movz	x7, #0x0, lsl #48
    cb30:      	fmov	d31, x6
    cb34:      	mov	x6, x7
    cb38:      	fmov	x7, d31
    cb3c:      	cmp	x6, #0x0
    cb40:      	b.eq	0xcb84 <_stogir.conditional.operands+0x2f8>
    cb44:      	uxtb	w16, w0
    cb48:      	cmp	w16, wzr
    cb4c:      	b.eq	0xcb64 <_stogir.conditional.operands+0x2d8>
    cb50:      	lsl	x0, x1, #4
    cb54:      	ldr	x1, [x22]
    cb58:      	add	x0, x0, x1
    cb5c:      	ldr	x0, [x0]
    cb60:      	b	0xcb74 <_stogir.conditional.operands+0x2e8>
    cb64:      	lsl	x0, x8, #4
    cb68:      	ldr	x1, [x22, #0x28]
    cb6c:      	add	x0, x0, x1
    cb70:      	ldr	x0, [x0]
    cb74:      	mov	x1, x0
    cb78:      	mov	x6, x7
    cb7c:      	mov	x0, #0x1                ; =1
    cb80:      	b	0xcb90 <_stogir.conditional.operands+0x304>
    cb84:      	mov	x6, x7
    cb88:      	movz	x0, #0x0, lsl #48
    cb8c:      	movz	x1, #0x0, lsl #48
    cb90:      	lsr	w0, w0, #0
    cb94:      	lsr	x16, x0, #0
    cb98:      	cmp	x16, #0x1
    cb9c:      	b.eq	0xcbb8 <_stogir.conditional.operands+0x32c>
    cba0:      	b.lo	0xcba8 <_stogir.conditional.operands+0x31c>
    cba4:      	b	0xcbbc <_stogir.conditional.operands+0x330>
    cba8:      	cmp	x16, #0x0
    cbac:      	b.eq	0xcbb4 <_stogir.conditional.operands+0x328>
    cbb0:      	b	0xcbbc <_stogir.conditional.operands+0x330>
    cbb4:      	b	0xcbc0 <_stogir.conditional.operands+0x334>
    cbb8:      	b	0xcdac <_stogir.conditional.operands+0x520>
    cbbc:      	b	0xce80 <_stogir.conditional.operands+0x5f4>
    cbc0:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000cbc0:  ARM64_RELOC_PAGE21	l_stogir.469
    cbc4:      	ldr	x16, [x16]
		000000000000cbc4:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    cbc8:      	orr	x0, x16, xzr
    cbcc:      	mov	x1, x0
    cbd0:      	mov	x0, x6
    cbd4:      	mov	x6, #0x10               ; =16
    cbd8:      	b	0xcc10 <_stogir.conditional.operands+0x384>
    cbdc:      	and	x0, x20, #0xffffffff
    cbe0:      	mov	x1, x0
    cbe4:      	movz	x0, #0x0, lsl #48
    cbe8:      	movz	x2, #0x0, lsl #48
    cbec:      	b	0xcd30 <_stogir.conditional.operands+0x4a4>
    cbf0:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000cbf0:  ARM64_RELOC_PAGE21	l_stogir.470
    cbf4:      	ldr	x16, [x16]
		000000000000cbf4:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    cbf8:      	orr	x0, x16, xzr
    cbfc:      	mov	x1, #0x21               ; =33
    cc00:      	fmov	d31, x0
    cc04:      	mov	x0, x6
    cc08:      	mov	x6, x1
    cc0c:      	fmov	x1, d31
    cc10:      	cmp	x0, #0x2
    cc14:      	b.ge	0xcc48 <_stogir.conditional.operands+0x3bc>
    cc18:      	add	x7, x0, #0x1
    cc1c:      	lsl	x0, x0, #2
    cc20:      	add	x0, x0, x2
    cc24:      	ldr	w0, [x0]
    cc28:      	sxtw	x0, w0
    cc2c:      	and	x0, x0, #0xffffffff
    cc30:      	mov	x23, x1
    cc34:      	mov	x1, x0
    cc38:      	mov	x24, x6
    cc3c:      	mov	x6, x7
    cc40:      	mov	x0, #0x1                ; =1
    cc44:      	b	0xcc5c <_stogir.conditional.operands+0x3d0>
    cc48:      	mov	x23, x1
    cc4c:      	mov	x24, x6
    cc50:      	mov	x6, x0
    cc54:      	movz	x0, #0x0, lsl #48
    cc58:      	movz	x1, #0x0, lsl #48
    cc5c:      	lsr	w0, w0, #0
    cc60:      	lsr	x16, x0, #0
    cc64:      	cmp	x16, #0x1
    cc68:      	b.eq	0xcc84 <_stogir.conditional.operands+0x3f8>
    cc6c:      	b.lo	0xcc74 <_stogir.conditional.operands+0x3e8>
    cc70:      	b	0xcc88 <_stogir.conditional.operands+0x3fc>
    cc74:      	cmp	x16, #0x0
    cc78:      	b.eq	0xcc80 <_stogir.conditional.operands+0x3f4>
    cc7c:      	b	0xcc88 <_stogir.conditional.operands+0x3fc>
    cc80:      	b	0xccf0 <_stogir.conditional.operands+0x464>
    cc84:      	b	0xcc8c <_stogir.conditional.operands+0x400>
    cc88:      	b	0xce78 <_stogir.conditional.operands+0x5ec>
    cc8c:      	lsr	w1, w1, #0
    cc90:      	sxtw	x1, w1
    cc94:      	cmp	x1, #0x0
    cc98:      	cset	w0, gt
    cc9c:      	movz	x16, #0x0, lsl #48
    cca0:      	sub	x7, x16, x1
    cca4:      	sub	x8, x7, #0x1
    cca8:      	uxtb	w16, w0
    ccac:      	cmp	w16, wzr
    ccb0:      	b.eq	0xcd68 <_stogir.conditional.operands+0x4dc>
    ccb4:      	ldr	x7, [x22, #0x8]
    ccb8:      	cmp	x1, x7
    ccbc:      	b.ge	0xcb20 <_stogir.conditional.operands+0x294>
    ccc0:      	ldr	x7, [x3, #0x8]
    ccc4:      	cmp	x1, x7
    ccc8:      	b.ge	0xcab0 <_stogir.conditional.operands+0x224>
    cccc:      	lsl	x7, x1, #2
    ccd0:      	ldr	x9, [x22, #0x78]
    ccd4:      	add	x7, x7, x9
    ccd8:      	ldr	w7, [x7]
    ccdc:      	sxtw	x7, w7
    cce0:      	cmp	x7, #0x0
    cce4:      	cset	w7, ge
    cce8:      	ubfx	x7, x7, #0, #8
    ccec:      	b	0xcab4 <_stogir.conditional.operands+0x228>
    ccf0:      	cmp	x24, #0x0
    ccf4:      	b.ne	0xcd24 <_stogir.conditional.operands+0x498>
    ccf8:      	cmp	x24, #0x0
    ccfc:      	b.eq	0xcbdc <_stogir.conditional.operands+0x350>
    cd00:      	lsr	x0, x24, #0
    cd04:      	mov	x1, x19
    cd08:      	mov	x2, x0
    cd0c:      	mov	x0, x23
    cd10:      	bl	0xcd10 <_stogir.conditional.operands+0x484>
		000000000000cd10:  ARM64_RELOC_BRANCH26	_memcmp
    cd14:      	lsr	w0, w0, #0
    cd18:      	sxtw	x0, w0
    cd1c:      	cmp	x0, #0x0
    cd20:      	b.eq	0xcbdc <_stogir.conditional.operands+0x350>
    cd24:      	mov	x1, x23
    cd28:      	mov	x2, x24
    cd2c:      	mov	x0, #0x1                ; =1
    cd30:      	str	x0, [x21]
    cd34:      	str	x1, [x21, #0x8]
    cd38:      	str	x2, [x21, #0x10]
    cd3c:      	ldr	x19, [sp, #0x30]
    cd40:      	ldr	x20, [sp, #0x38]
    cd44:      	ldr	x21, [sp, #0x40]
    cd48:      	ldr	x22, [sp, #0x48]
    cd4c:      	ldr	x23, [sp, #0x50]
    cd50:      	ldr	x24, [sp, #0x58]
    cd54:      	ldr	x25, [sp, #0x60]
    cd58:      	ldr	x29, [sp]
    cd5c:      	ldr	x30, [sp, #0x8]
    cd60:      	add	sp, sp, #0x70
    cd64:      	ret
    cd68:      	cmp	x1, #0x0
    cd6c:      	b.ge	0xcb2c <_stogir.conditional.operands+0x2a0>
    cd70:      	ldr	x9, [x4, #0x8]
    cd74:      	ldr	x10, [x5, #0x8]
    cd78:      	cmp	x9, x10
    cd7c:      	b.ne	0xcac4 <_stogir.conditional.operands+0x238>
    cd80:      	cmp	x7, x9
    cd84:      	b.gt	0xc9ec <_stogir.conditional.operands+0x160>
    cd88:      	lsl	x7, x8, #2
    cd8c:      	ldr	x9, [x22, #0x50]
    cd90:      	add	x7, x7, x9
    cd94:      	ldr	w7, [x7]
    cd98:      	sxtw	x7, w7
    cd9c:      	cmp	x7, #0x0
    cda0:      	cset	w7, gt
    cda4:      	ubfx	x7, x7, #0, #8
    cda8:      	b	0xc9f0 <_stogir.conditional.operands+0x164>
    cdac:      	uxtb	w0, w1
    cdb0:      	cmp	x0, #0x48
    cdb4:      	b.eq	0xcbf0 <_stogir.conditional.operands+0x364>
    cdb8:      	cmp	x0, #0x46
    cdbc:      	b.eq	0xcbf0 <_stogir.conditional.operands+0x364>
    cdc0:      	lsr	w1, w1, #0
    cdc4:      	ubfx	x0, x1, #8, #8
    cdc8:      	cmp	x0, x20
    cdcc:      	b.ne	0xcbf0 <_stogir.conditional.operands+0x364>
    cdd0:      	mov	x0, x23
    cdd4:      	mov	x1, x24
    cdd8:      	b	0xcc00 <_stogir.conditional.operands+0x374>
    cddc:      	uxtb	w0, w1
    cde0:      	cmp	x0, #0x48
    cde4:      	b.ne	0xce48 <_stogir.conditional.operands+0x5bc>
    cde8:      	mov	x1, x2
    cdec:      	mov	x2, x3
    cdf0:      	mov	x0, #0x1                ; =1
    cdf4:      	b	0xce2c <_stogir.conditional.operands+0x5a0>
    cdf8:      	mov	x3, x0
    cdfc:      	movz	x0, #0x0, lsl #48
    ce00:      	fmov	d31, x1
    ce04:      	mov	x1, x3
    ce08:      	fmov	x3, d31
    ce0c:      	b	0xca00 <_stogir.conditional.operands+0x174>
    ce10:      	cmp	x0, #0xd
    ce14:      	cset	w0, le
    ce18:      	uxtb	w16, w0
    ce1c:      	cmp	w16, wzr
    ce20:      	cset	x0, eq
    ce24:      	mov	x1, x2
    ce28:      	mov	x2, x3
    ce2c:      	cmp	x0, #0x0
    ce30:      	b.eq	0xcacc <_stogir.conditional.operands+0x240>
    ce34:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000ce34:  ARM64_RELOC_PAGE21	l_stogir.471
    ce38:      	ldr	x16, [x16]
		000000000000ce38:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    ce3c:      	orr	x0, x16, xzr
    ce40:      	mov	x1, #0x2a               ; =42
    ce44:      	b	0xcad4 <_stogir.conditional.operands+0x248>
    ce48:      	cmp	x0, #0x46
    ce4c:      	b.ne	0xce60 <_stogir.conditional.operands+0x5d4>
    ce50:      	mov	x0, #0x1                ; =1
    ce54:      	b	0xce24 <_stogir.conditional.operands+0x598>
    ce58:      	movz	x3, #0x0, lsl #48
    ce5c:      	b	0xc9e8 <_stogir.conditional.operands+0x15c>
    ce60:      	lsr	w1, w1, #0
    ce64:      	ubfx	x0, x1, #8, #8
    ce68:      	cmp	x0, #0x0
    ce6c:      	b.ne	0xce10 <_stogir.conditional.operands+0x584>
    ce70:      	mov	x0, #0x1                ; =1
    ce74:      	b	0xce24 <_stogir.conditional.operands+0x598>
    ce78:      	brk	#0
    ce7c:      	b	0xce78 <_stogir.conditional.operands+0x5ec>
    ce80:      	brk	#0
    ce84:      	b	0xce80 <_stogir.conditional.operands+0x5f4>
    ce88:      	brk	#0
    ce8c:      	b	0xce88 <_stogir.conditional.operands+0x5fc>

000000000000ce90 <_stogir.floating.unary?>:
    ce90:      	sxtw	x0, w0
    ce94:      	cmp	x0, #0x1f
    ce98:      	b.ne	0xcea4 <_stogir.floating.unary?+0x14>
    ce9c:      	mov	x0, #0x1                ; =1
    cea0:      	b	0xceb0 <_stogir.floating.unary?+0x20>
    cea4:      	cmp	x0, #0x20
    cea8:      	cset	w0, eq
    ceac:      	ubfx	x0, x0, #0, #8
    ceb0:      	ret

000000000000ceb4 <_stogir.floating.comparison?>:
    ceb4:      	sxtw	x0, w0
    ceb8:      	cmp	x0, #0xe
    cebc:      	b.lt	0xced0 <_stogir.floating.comparison?+0x1c>
    cec0:      	cmp	x0, #0x19
    cec4:      	cset	w0, le
    cec8:      	ubfx	x0, x0, #0, #8
    cecc:      	b	0xced4 <_stogir.floating.comparison?+0x20>
    ced0:      	movz	x0, #0x0, lsl #48
    ced4:      	ret

000000000000ced8 <_stogir.floating.operands>:
    ced8:      	sub	sp, sp, #0x90
    cedc:      	str	x29, [sp]
    cee0:      	str	x30, [sp, #0x8]
    cee4:      	mov	x29, sp
    cee8:      	str	x19, [sp, #0x60]
    ceec:      	str	x20, [sp, #0x68]
    cef0:      	str	x21, [sp, #0x70]
    cef4:      	str	x22, [sp, #0x78]
    cef8:      	str	x23, [sp, #0x80]
    cefc:      	str	x24, [sp, #0x88]
    cf00:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000cf00:  ARM64_RELOC_PAGE21	l_stogir.472
    cf04:      	ldr	x16, [x16]
		000000000000cf04:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    cf08:      	orr	x19, x16, xzr
    cf0c:      	sxtw	x1, w1
    cf10:      	sxtw	x20, w2
    cf14:      	cmp	x1, #0x1f
    cf18:      	cset	w2, eq
    cf1c:      	cmp	x1, #0x20
    cf20:      	cset	w6, eq
    cf24:      	cmp	x1, #0xe
    cf28:      	b.lt	0xcf64 <_stogir.floating.operands+0x8c>
    cf2c:      	cmp	x1, #0x19
    cf30:      	b.gt	0xcf64 <_stogir.floating.operands+0x8c>
    cf34:      	cmp	x20, #0xc
    cf38:      	b.ne	0xcf44 <_stogir.floating.operands+0x6c>
    cf3c:      	mov	x7, #0x1                ; =1
    cf40:      	b	0xcf50 <_stogir.floating.operands+0x78>
    cf44:      	cmp	x20, #0xd
    cf48:      	cset	w7, eq
    cf4c:      	ubfx	x7, x7, #0, #8
    cf50:      	cmp	x7, #0x0
    cf54:      	b.eq	0xcf9c <_stogir.floating.operands+0xc4>
    cf58:      	mov	x7, x19
    cf5c:      	movz	x9, #0x0, lsl #48
    cf60:      	b	0xcfac <_stogir.floating.operands+0xd4>
    cf64:      	uxtb	w16, w2
    cf68:      	cmp	w16, wzr
    cf6c:      	b.ne	0xcf34 <_stogir.floating.operands+0x5c>
    cf70:      	uxtb	w16, w6
    cf74:      	cmp	w16, wzr
    cf78:      	b.ne	0xcf34 <_stogir.floating.operands+0x5c>
    cf7c:      	cmp	x1, #0x1a
    cf80:      	b.lt	0xcf8c <_stogir.floating.operands+0xb4>
    cf84:      	cmp	x1, #0x1d
    cf88:      	b.le	0xcf34 <_stogir.floating.operands+0x5c>
    cf8c:      	cmp	x1, #0x3a
    cf90:      	b.eq	0xcf34 <_stogir.floating.operands+0x5c>
    cf94:      	cmp	x1, #0x3b
    cf98:      	b.eq	0xcf34 <_stogir.floating.operands+0x5c>
    cf9c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x2e0>
		000000000000cf9c:  ARM64_RELOC_PAGE21	l_stogir.473
    cfa0:      	ldr	x16, [x16]
		000000000000cfa0:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    cfa4:      	orr	x7, x16, xzr
    cfa8:      	mov	x9, #0x22               ; =34
    cfac:      	lsr	w3, w3, #0
    cfb0:      	add	x16, sp, #0x10
    cfb4:      	str	w3, [x16]
    cfb8:      	uxtb	w16, w2
    cfbc:      	cmp	w16, wzr
    cfc0:      	b.eq	0xcfd0 <_stogir.floating.operands+0xf8>
    cfc4:      	mov	x6, x7
    cfc8:      	mov	x2, #0x1                ; =1
    cfcc:      	b	0xcfdc <_stogir.floating.operands+0x104>
    cfd0:      	ubfx	x6, x6, #0, #8
    cfd4:      	mov	x2, x6
    cfd8:      	mov	x6, x7
    cfdc:      	cmp	x2, #0x0
    cfe0:      	b.eq	0xd01c <_stogir.floating.operands+0x144>
    cfe4:      	sxtw	x3, w3
    cfe8:      	mov	x2, x3
    cfec:      	mov	x3, x6
    cff0:      	b	0xd028 <_stogir.floating.operands+0x150>
    cff4:      	mov	x0, x1
    cff8:      	mov	x1, x2
    cffc:      	b	0xd158 <_stogir.floating.operands+0x280>
    d000:      	movz	x13, #0x0, lsl #48
    d004:      	fmov	d31, x9
    d008:      	mov	x9, x13
    d00c:      	fmov	x13, d31
    d010:      	b	0xd068 <_stogir.floating.operands+0x190>
    d014:      	movz	x13, #0x0, lsl #48
    d018:      	b	0xd070 <_stogir.floating.operands+0x198>
    d01c:      	sxtw	x4, w4
    d020:      	mov	x2, x4
    d024:      	mov	x3, x6
    d028:      	add	x16, sp, #0x20
    d02c:      	orr	x4, x16, xzr
    d030:      	add	x6, x0, #0x78
    d034:      	add	x7, x0, #0x28
    d038:      	add	x10, x0, #0x50
    d03c:      	lsr	w2, w2, #0
    d040:      	add	x16, sp, #0x10
    d044:      	str	w2, [x16, #0x4]
    d048:      	add	x16, sp, #0x10
    d04c:      	ldr	x2, [x16]
    d050:      	add	x16, sp, #0x20
    d054:      	str	x2, [x16]
    d058:      	movz	x2, #0x0, lsl #48
    d05c:      	b	0xd184 <_stogir.floating.operands+0x2ac>
    d060:      	mov	x13, x9
    d064:      	movz	x9, #0x0, lsl #48
    d068:      	b	0xd07c <_stogir.floating.operands+0x1a4>
    d06c:      	movz	x13, #0x0, lsl #48
    d070:      	fmov	d31, x9
    d074:      	mov	x9, x13
    d078:      	fmov	x13, d31
    d07c:      	cmp	x9, #0x0
    d080:      	b.eq	0xd0c4 <_stogir.floating.operands+0x1ec>
    d084:      	uxtb	w16, w2
    d088:      	cmp	w16, wzr
    d08c:      	b.eq	0xd0a4 <_stogir.floating.operands+0x1cc>
    d090:      	lsl	x2, x3, #4
    d094:      	ldr	x3, [x0]
    d098:      	add	x2, x2, x3
    d09c:      	ldr	x2, [x2]
    d0a0:      	b	0xd0b4 <_stogir.floating.operands+0x1dc>
    d0a4:      	lsl	x2, x14, #4
    d0a8:      	ldr	x3, [x0, #0x28]
    d0ac:      	add	x2, x2, x3
    d0b0:      	ldr	x2, [x2]
    d0b4:      	mov	x3, x2
    d0b8:      	mov	x9, x13
    d0bc:      	mov	x2, #0x1                ; =1
    d0c0:      	b	0xd0d0 <_stogir.floating.operands+0x1f8>
    d0c4:      	mov	x9, x13
    d0c8:      	movz	x2, #0x0, lsl #48
    d0cc:      	movz	x3, #0x0, lsl #48
    d0d0:      	lsr	w2, w2, #0
    d0d4:      	lsr	x16, x2, #0
    d0d8:      	cmp	x16, #0x1
    d0dc:      	b.eq	0xd0f8 <_stogir.floating.operands+0x220>
    d0e0:      	b.lo	0xd0e8 <_stogir.floating.operands+0x210>
    d0e4:      	b	0xd0fc <_stogir.floating.operands+0x224>
    d0e8:      	cmp	x16, #0x0
    d0ec:      	b.eq	0xd0f4 <_stogir.floating.operands+0x21c>
    d0f0:      	b	0xd0fc <_stogir.floating.operands+0x224>
    d0f4:      	b	0xd100 <_stogir.floating.operands+0x228>
    d0f8:      	b	0xd36c <_stogir.floating.operands+0x494>
    d0fc:      	b	0xd4a4 <_stogir.floating.operands+0x5cc>
    d100:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d100:  ARM64_RELOC_PAGE21	l_stogir.474
    d104:      	ldr	x16, [x16]
		000000000000d104:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    d108:      	orr	x2, x16, xzr
    d10c:      	mov	x3, x2
    d110:      	mov	x2, x9
    d114:      	mov	x9, #0x18               ; =24
    d118:      	b	0xd184 <_stogir.floating.operands+0x2ac>
    d11c:      	and	x0, x20, #0xffffffff
    d120:      	mov	x1, x0
    d124:      	movz	x0, #0x0, lsl #48
    d128:      	movz	x2, #0x0, lsl #48
    d12c:      	b	0xd2f4 <_stogir.floating.operands+0x41c>
    d130:      	mov	x22, x3
    d134:      	mov	x23, x4
    d138:      	mov	x1, #0x1                ; =1
    d13c:      	cmp	x1, #0x0
    d140:      	b.eq	0xd388 <_stogir.floating.operands+0x4b0>
    d144:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d144:  ARM64_RELOC_PAGE21	l_stogir.475
    d148:      	ldr	x16, [x16]
		000000000000d148:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    d14c:      	orr	x0, x16, xzr
    d150:      	mov	x24, x8
    d154:      	mov	x1, #0x21               ; =33
    d158:      	mov	x21, x0
    d15c:      	mov	x22, x1
    d160:      	b	0xd2b4 <_stogir.floating.operands+0x3dc>
    d164:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d164:  ARM64_RELOC_PAGE21	l_stogir.476
    d168:      	ldr	x16, [x16]
		000000000000d168:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    d16c:      	orr	x2, x16, xzr
    d170:      	mov	x3, #0x1e               ; =30
    d174:      	fmov	d31, x2
    d178:      	mov	x2, x9
    d17c:      	mov	x9, x3
    d180:      	fmov	x3, d31
    d184:      	cmp	x2, #0x2
    d188:      	b.ge	0xd1bc <_stogir.floating.operands+0x2e4>
    d18c:      	add	x11, x2, #0x1
    d190:      	lsl	x2, x2, #2
    d194:      	add	x2, x2, x4
    d198:      	ldr	w2, [x2]
    d19c:      	sxtw	x2, w2
    d1a0:      	and	x2, x2, #0xffffffff
    d1a4:      	mov	x12, x9
    d1a8:      	mov	x9, x11
    d1ac:      	mov	x11, x3
    d1b0:      	mov	x3, x2
    d1b4:      	mov	x2, #0x1                ; =1
    d1b8:      	b	0xd1d0 <_stogir.floating.operands+0x2f8>
    d1bc:      	mov	x11, x3
    d1c0:      	mov	x12, x9
    d1c4:      	mov	x9, x2
    d1c8:      	movz	x2, #0x0, lsl #48
    d1cc:      	movz	x3, #0x0, lsl #48
    d1d0:      	lsr	w2, w2, #0
    d1d4:      	lsr	x16, x2, #0
    d1d8:      	cmp	x16, #0x1
    d1dc:      	b.eq	0xd1f8 <_stogir.floating.operands+0x320>
    d1e0:      	b.lo	0xd1e8 <_stogir.floating.operands+0x310>
    d1e4:      	b	0xd1fc <_stogir.floating.operands+0x324>
    d1e8:      	cmp	x16, #0x0
    d1ec:      	b.eq	0xd1f4 <_stogir.floating.operands+0x31c>
    d1f0:      	b	0xd1fc <_stogir.floating.operands+0x324>
    d1f4:      	b	0xd264 <_stogir.floating.operands+0x38c>
    d1f8:      	b	0xd200 <_stogir.floating.operands+0x328>
    d1fc:      	b	0xd458 <_stogir.floating.operands+0x580>
    d200:      	lsr	w3, w3, #0
    d204:      	sxtw	x3, w3
    d208:      	cmp	x3, #0x0
    d20c:      	cset	w2, gt
    d210:      	movz	x16, #0x0, lsl #48
    d214:      	sub	x13, x16, x3
    d218:      	sub	x14, x13, #0x1
    d21c:      	uxtb	w16, w2
    d220:      	cmp	w16, wzr
    d224:      	b.eq	0xd328 <_stogir.floating.operands+0x450>
    d228:      	ldr	x13, [x0, #0x8]
    d22c:      	cmp	x3, x13
    d230:      	b.ge	0xd060 <_stogir.floating.operands+0x188>
    d234:      	ldr	x13, [x6, #0x8]
    d238:      	cmp	x3, x13
    d23c:      	b.ge	0xd000 <_stogir.floating.operands+0x128>
    d240:      	lsl	x13, x3, #2
    d244:      	ldr	x15, [x0, #0x78]
    d248:      	add	x13, x13, x15
    d24c:      	ldr	w13, [x13]
    d250:      	sxtw	x13, w13
    d254:      	cmp	x13, #0x0
    d258:      	cset	w13, ge
    d25c:      	ubfx	x13, x13, #0, #8
    d260:      	b	0xd004 <_stogir.floating.operands+0x12c>
    d264:      	sxtw	x21, w5
    d268:      	cmp	x21, #0x0
    d26c:      	b.ne	0xd280 <_stogir.floating.operands+0x3a8>
    d270:      	mov	x3, x11
    d274:      	mov	x4, x12
    d278:      	movz	x2, #0x0, lsl #48
    d27c:      	b	0xd28c <_stogir.floating.operands+0x3b4>
    d280:      	mov	x3, x11
    d284:      	mov	x4, x12
    d288:      	mov	x2, #0x1                ; =1
    d28c:      	cmp	x2, #0x0
    d290:      	b.eq	0xd4b4 <_stogir.floating.operands+0x5dc>
    d294:      	cmp	x1, #0x1d
    d298:      	b.ne	0xd130 <_stogir.floating.operands+0x258>
    d29c:      	mov	x22, x3
    d2a0:      	mov	x23, x4
    d2a4:      	movz	x1, #0x0, lsl #48
    d2a8:      	b	0xd13c <_stogir.floating.operands+0x264>
    d2ac:      	mov	x21, x3
    d2b0:      	mov	x22, x4
    d2b4:      	cmp	x22, #0x0
    d2b8:      	b.ne	0xd2e8 <_stogir.floating.operands+0x410>
    d2bc:      	cmp	x22, #0x0
    d2c0:      	b.eq	0xd11c <_stogir.floating.operands+0x244>
    d2c4:      	lsr	x0, x22, #0
    d2c8:      	mov	x1, x19
    d2cc:      	mov	x2, x0
    d2d0:      	mov	x0, x21
    d2d4:      	bl	0xd2d4 <_stogir.floating.operands+0x3fc>
		000000000000d2d4:  ARM64_RELOC_BRANCH26	_memcmp
    d2d8:      	lsr	w0, w0, #0
    d2dc:      	sxtw	x0, w0
    d2e0:      	cmp	x0, #0x0
    d2e4:      	b.eq	0xd11c <_stogir.floating.operands+0x244>
    d2e8:      	mov	x1, x21
    d2ec:      	mov	x2, x22
    d2f0:      	mov	x0, #0x1                ; =1
    d2f4:      	str	x0, [x24]
    d2f8:      	str	x1, [x24, #0x8]
    d2fc:      	str	x2, [x24, #0x10]
    d300:      	ldr	x19, [sp, #0x60]
    d304:      	ldr	x20, [sp, #0x68]
    d308:      	ldr	x21, [sp, #0x70]
    d30c:      	ldr	x22, [sp, #0x78]
    d310:      	ldr	x23, [sp, #0x80]
    d314:      	ldr	x24, [sp, #0x88]
    d318:      	ldr	x29, [sp]
    d31c:      	ldr	x30, [sp, #0x8]
    d320:      	add	sp, sp, #0x90
    d324:      	ret
    d328:      	cmp	x3, #0x0
    d32c:      	b.ge	0xd06c <_stogir.floating.operands+0x194>
    d330:      	ldr	x15, [x7, #0x8]
    d334:      	ldr	x21, [x10, #0x8]
    d338:      	cmp	x15, x21
    d33c:      	b.ne	0xd014 <_stogir.floating.operands+0x13c>
    d340:      	cmp	x13, x15
    d344:      	b.gt	0xd3e4 <_stogir.floating.operands+0x50c>
    d348:      	lsl	x13, x14, #2
    d34c:      	ldr	x15, [x0, #0x50]
    d350:      	add	x13, x13, x15
    d354:      	ldr	w13, [x13]
    d358:      	sxtw	x13, w13
    d35c:      	cmp	x13, #0x0
    d360:      	cset	w13, gt
    d364:      	ubfx	x13, x13, #0, #8
    d368:      	b	0xd3e8 <_stogir.floating.operands+0x510>
    d36c:      	lsr	w3, w3, #0
    d370:      	ubfx	x2, x3, #8, #8
    d374:      	cmp	x2, x20
    d378:      	b.ne	0xd164 <_stogir.floating.operands+0x28c>
    d37c:      	mov	x2, x11
    d380:      	mov	x3, x12
    d384:      	b	0xd174 <_stogir.floating.operands+0x29c>
    d388:      	lsr	w5, w5, #0
    d38c:      	mov	w1, w5
    d390:      	mov	x24, x8
    d394:      	add	x8, sp, #0x30
    d398:      	bl	0xd398 <_stogir.floating.operands+0x4c0>
		000000000000d398:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d39c:      	add	x16, sp, #0x30
    d3a0:      	ldr	w0, [x16]
    d3a4:      	lsr	x16, x0, #0
    d3a8:      	cmp	x16, #0x1
    d3ac:      	b.eq	0xd3c8 <_stogir.floating.operands+0x4f0>
    d3b0:      	b.lo	0xd3b8 <_stogir.floating.operands+0x4e0>
    d3b4:      	b	0xd3cc <_stogir.floating.operands+0x4f4>
    d3b8:      	cmp	x16, #0x0
    d3bc:      	b.eq	0xd3c4 <_stogir.floating.operands+0x4ec>
    d3c0:      	b	0xd3cc <_stogir.floating.operands+0x4f4>
    d3c4:      	b	0xd3d0 <_stogir.floating.operands+0x4f8>
    d3c8:      	b	0xd3ec <_stogir.floating.operands+0x514>
    d3cc:      	b	0xd4ac <_stogir.floating.operands+0x5d4>
    d3d0:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d3d0:  ARM64_RELOC_PAGE21	l_stogir.477
    d3d4:      	ldr	x16, [x16]
		000000000000d3d4:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    d3d8:      	orr	x0, x16, xzr
    d3dc:      	mov	x1, #0x16               ; =22
    d3e0:      	b	0xcffc <_stogir.floating.operands+0x124>
    d3e4:      	movz	x13, #0x0, lsl #48
    d3e8:      	b	0xd018 <_stogir.floating.operands+0x140>
    d3ec:      	add	x16, sp, #0x30
    d3f0:      	ldr	x0, [x16, #0x8]
    d3f4:      	cmp	x21, #0x0
    d3f8:      	b.ge	0xd434 <_stogir.floating.operands+0x55c>
    d3fc:      	mov	x1, x22
    d400:      	mov	x2, x23
    d404:      	mov	x0, #0x1                ; =1
    d408:      	b	0xd418 <_stogir.floating.operands+0x540>
    d40c:      	movz	x0, #0x0, lsl #48
    d410:      	mov	x1, x22
    d414:      	mov	x2, x23
    d418:      	cmp	x0, #0x0
    d41c:      	b.eq	0xcff4 <_stogir.floating.operands+0x11c>
    d420:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d420:  ARM64_RELOC_PAGE21	l_stogir.478
    d424:      	ldr	x16, [x16]
		000000000000d424:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    d428:      	orr	x0, x16, xzr
    d42c:      	mov	x1, #0x2d               ; =45
    d430:      	b	0xcffc <_stogir.floating.operands+0x124>
    d434:      	uxtb	w0, w0
    d438:      	cmp	x0, #0x83
    d43c:      	b.ge	0xd460 <_stogir.floating.operands+0x588>
    d440:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d440:  ARM64_RELOC_PAGE21	l_stogir.479
    d444:      	ldr	x16, [x16]
		000000000000d444:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    d448:      	orr	x1, x16, xzr
    d44c:      	add	x1, x0, x1
    d450:      	ldrb	w1, [x1]
    d454:      	b	0xd464 <_stogir.floating.operands+0x58c>
    d458:      	brk	#0
    d45c:      	b	0xd458 <_stogir.floating.operands+0x580>
    d460:      	movz	x1, #0x0, lsl #48
    d464:      	uxtb	w1, w1
    d468:      	and	x1, x1, #0x2
    d46c:      	uxtb	w1, w1
    d470:      	cmp	x1, #0x0
    d474:      	cset	w1, eq
    d478:      	uxtb	w16, w1
    d47c:      	cmp	w16, wzr
    d480:      	cset	x1, eq
    d484:      	cmp	x1, #0x0
    d488:      	b.ne	0xd40c <_stogir.floating.operands+0x534>
    d48c:      	cmp	x0, #0x65
    d490:      	b.eq	0xd40c <_stogir.floating.operands+0x534>
    d494:      	cmp	x0, #0x66
    d498:      	b.eq	0xd40c <_stogir.floating.operands+0x534>
    d49c:      	mov	x0, #0x1                ; =1
    d4a0:      	b	0xd410 <_stogir.floating.operands+0x538>
    d4a4:      	brk	#0
    d4a8:      	b	0xd4a4 <_stogir.floating.operands+0x5cc>
    d4ac:      	brk	#0
    d4b0:      	b	0xd4ac <_stogir.floating.operands+0x5d4>
    d4b4:      	mov	x24, x8
    d4b8:      	b	0xd2ac <_stogir.floating.operands+0x3d4>

000000000000d4bc <_stogir.types.signed?>:
    d4bc:      	sxtw	x0, w0
    d4c0:      	cmp	x0, #0x7
    d4c4:      	b.lt	0xd4d8 <_stogir.types.signed?+0x1c>
    d4c8:      	cmp	x0, #0xb
    d4cc:      	cset	w0, le
    d4d0:      	ubfx	x0, x0, #0, #8
    d4d4:      	b	0xd4dc <_stogir.types.signed?+0x20>
    d4d8:      	movz	x0, #0x0, lsl #48
    d4dc:      	ret

000000000000d4e0 <_stogir.integer-binary.logical?>:
    d4e0:      	sxtw	x0, w0
    d4e4:      	cmp	x0, #0x2e
    d4e8:      	b.ne	0xd504 <_stogir.integer-binary.logical?+0x24>
    d4ec:      	mov	x0, #0x1                ; =1
    d4f0:      	b	0xd500 <_stogir.integer-binary.logical?+0x20>
    d4f4:      	cmp	x0, #0x30
    d4f8:      	cset	w0, eq
    d4fc:      	ubfx	x0, x0, #0, #8
    d500:      	ret
    d504:      	cmp	x0, #0x2f
    d508:      	b.ne	0xd4f4 <_stogir.integer-binary.logical?+0x14>
    d50c:      	mov	x0, #0x1                ; =1
    d510:      	b	0xd500 <_stogir.integer-binary.logical?+0x20>

000000000000d514 <_inherent$slice$data__i8>:
    d514:      	ret

000000000000d518 <_inherent$slice$data__u32>:
    d518:      	ret

000000000000d51c <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    d51c:      	sub	sp, sp, #0x10
    d520:      	mov	x1, sp
    d524:      	ldr	x2, [x0]
    d528:      	ldr	x0, [x0, #0x8]
    d52c:      	str	x2, [x1]
    d530:      	str	x0, [x1, #0x8]
    d534:      	ldr	x0, [sp]
    d538:      	ldr	x1, [sp, #0x8]
    d53c:      	add	sp, sp, #0x10
    d540:      	ret

000000000000d544 <_inherent$slice$at__stogir.node.Node>:
    d544:      	lsl	x1, x2, #4
    d548:      	add	x0, x1, x0
    d54c:      	ret

000000000000d550 <_inherent$slice$new__u8>:
    d550:      	sub	sp, sp, #0x10
    d554:      	mov	x2, sp
    d558:      	str	x0, [x2]
    d55c:      	str	x1, [x2, #0x8]
    d560:      	ldr	x0, [sp]
    d564:      	ldr	x1, [sp, #0x8]
    d568:      	add	sp, sp, #0x10
    d56c:      	ret

000000000000d570 <_stogir.vector-lanes.operands>:
    d570:      	sub	sp, sp, #0x120
    d574:      	str	x29, [sp]
    d578:      	str	x30, [sp, #0x8]
    d57c:      	mov	x29, sp
    d580:      	str	x19, [sp, #0xc8]
    d584:      	str	x20, [sp, #0xd0]
    d588:      	str	x21, [sp, #0xd8]
    d58c:      	str	x22, [sp, #0xe0]
    d590:      	str	x23, [sp, #0xe8]
    d594:      	str	x24, [sp, #0xf0]
    d598:      	str	x25, [sp, #0xf8]
    d59c:      	str	x26, [sp, #0x100]
    d5a0:      	str	x27, [sp, #0x108]
    d5a4:      	str	x28, [sp, #0x110]
    d5a8:      	sxtw	x4, w4
    d5ac:      	cmp	x4, #0x0
    d5b0:      	cset	w7, gt
    d5b4:      	movz	x16, #0x0, lsl #48
    d5b8:      	sub	x9, x16, x4
    d5bc:      	sub	x10, x9, #0x1
    d5c0:      	uxtb	w16, w7
    d5c4:      	cmp	w16, wzr
    d5c8:      	b.eq	0xd60c <_stogir.vector-lanes.operands+0x9c>
    d5cc:      	ldr	x9, [x0, #0x8]
    d5d0:      	cmp	x4, x9
    d5d4:      	b.ge	0xd6c0 <_stogir.vector-lanes.operands+0x150>
    d5d8:      	add	x9, x0, #0x78
    d5dc:      	ldr	x9, [x9, #0x8]
    d5e0:      	cmp	x4, x9
    d5e4:      	b.ge	0xd7d0 <_stogir.vector-lanes.operands+0x260>
    d5e8:      	lsl	x9, x4, #2
    d5ec:      	ldr	x11, [x0, #0x78]
    d5f0:      	add	x9, x9, x11
    d5f4:      	ldr	w9, [x9]
    d5f8:      	sxtw	x9, w9
    d5fc:      	cmp	x9, #0x0
    d600:      	cset	w9, ge
    d604:      	ubfx	x9, x9, #0, #8
    d608:      	b	0xd7d4 <_stogir.vector-lanes.operands+0x264>
    d60c:      	cmp	x4, #0x0
    d610:      	b.ge	0xd6c8 <_stogir.vector-lanes.operands+0x158>
    d614:      	add	x11, x0, #0x28
    d618:      	add	x12, x0, #0x50
    d61c:      	ldr	x11, [x11, #0x8]
    d620:      	ldr	x12, [x12, #0x8]
    d624:      	cmp	x11, x12
    d628:      	b.ne	0xd658 <_stogir.vector-lanes.operands+0xe8>
    d62c:      	cmp	x9, x11
    d630:      	b.gt	0xd94c <_stogir.vector-lanes.operands+0x3dc>
    d634:      	lsl	x9, x10, #2
    d638:      	ldr	x11, [x0, #0x50]
    d63c:      	add	x9, x9, x11
    d640:      	ldr	w9, [x9]
    d644:      	sxtw	x9, w9
    d648:      	cmp	x9, #0x0
    d64c:      	cset	w9, gt
    d650:      	ubfx	x9, x9, #0, #8
    d654:      	b	0xd950 <_stogir.vector-lanes.operands+0x3e0>
    d658:      	movz	x9, #0x0, lsl #48
    d65c:      	b	0xd6cc <_stogir.vector-lanes.operands+0x15c>
    d660:      	mov	x0, x1
    d664:      	mov	x1, x23
    d668:      	str	x21, [sp, #0x98]
    d66c:      	str	x19, [sp, #0xa0]
    d670:      	str	x22, [sp, #0x88]
    d674:      	mov	x19, x0
    d678:      	mov	x20, x1
    d67c:      	cmp	x20, #0x0
    d680:      	b.ne	0xd6b0 <_stogir.vector-lanes.operands+0x140>
    d684:      	cmp	x20, #0x0
    d688:      	b.eq	0xd954 <_stogir.vector-lanes.operands+0x3e4>
    d68c:      	lsr	x0, x20, #0
    d690:      	ldr	x1, [sp, #0x88]
    d694:      	mov	x2, x0
    d698:      	mov	x0, x19
    d69c:      	bl	0xd69c <_stogir.vector-lanes.operands+0x12c>
		000000000000d69c:  ARM64_RELOC_BRANCH26	_memcmp
    d6a0:      	lsr	w0, w0, #0
    d6a4:      	sxtw	x0, w0
    d6a8:      	cmp	x0, #0x0
    d6ac:      	b.eq	0xd954 <_stogir.vector-lanes.operands+0x3e4>
    d6b0:      	mov	x1, x19
    d6b4:      	mov	x2, x20
    d6b8:      	mov	x0, #0x1                ; =1
    d6bc:      	b	0xd764 <_stogir.vector-lanes.operands+0x1f4>
    d6c0:      	movz	x9, #0x0, lsl #48
    d6c4:      	b	0xd6cc <_stogir.vector-lanes.operands+0x15c>
    d6c8:      	movz	x9, #0x0, lsl #48
    d6cc:      	cmp	x9, #0x0
    d6d0:      	b.eq	0xd710 <_stogir.vector-lanes.operands+0x1a0>
    d6d4:      	uxtb	w16, w7
    d6d8:      	cmp	w16, wzr
    d6dc:      	b.eq	0xd6f4 <_stogir.vector-lanes.operands+0x184>
    d6e0:      	lsl	x4, x4, #4
    d6e4:      	ldr	x7, [x0]
    d6e8:      	add	x4, x4, x7
    d6ec:      	ldr	x4, [x4]
    d6f0:      	b	0xd704 <_stogir.vector-lanes.operands+0x194>
    d6f4:      	lsl	x4, x10, #4
    d6f8:      	ldr	x7, [x0, #0x28]
    d6fc:      	add	x4, x4, x7
    d700:      	ldr	x4, [x4]
    d704:      	mov	x7, x4
    d708:      	mov	x4, #0x1                ; =1
    d70c:      	b	0xd718 <_stogir.vector-lanes.operands+0x1a8>
    d710:      	movz	x4, #0x0, lsl #48
    d714:      	movz	x7, #0x0, lsl #48
    d718:      	lsr	w4, w4, #0
    d71c:      	lsr	x16, x4, #0
    d720:      	cmp	x16, #0x1
    d724:      	b.eq	0xd740 <_stogir.vector-lanes.operands+0x1d0>
    d728:      	b.lo	0xd730 <_stogir.vector-lanes.operands+0x1c0>
    d72c:      	b	0xd744 <_stogir.vector-lanes.operands+0x1d4>
    d730:      	cmp	x16, #0x0
    d734:      	b.eq	0xd73c <_stogir.vector-lanes.operands+0x1cc>
    d738:      	b	0xd744 <_stogir.vector-lanes.operands+0x1d4>
    d73c:      	b	0xd748 <_stogir.vector-lanes.operands+0x1d8>
    d740:      	b	0xd7ac <_stogir.vector-lanes.operands+0x23c>
    d744:      	b	0xdd78 <_stogir.vector-lanes.operands+0x808>
    d748:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d748:  ARM64_RELOC_PAGE21	l_stogir.480
    d74c:      	ldr	x16, [x16]
		000000000000d74c:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    d750:      	orr	x0, x16, xzr
    d754:      	str	x8, [sp, #0xa0]
    d758:      	mov	x1, x0
    d75c:      	mov	x0, #0x1                ; =1
    d760:      	mov	x2, #0x1b               ; =27
    d764:      	ldr	x3, [sp, #0xa0]
    d768:      	str	x0, [x3]
    d76c:      	str	x1, [x3, #0x8]
    d770:      	str	x2, [x3, #0x10]
    d774:      	ldr	x19, [sp, #0xc8]
    d778:      	ldr	x20, [sp, #0xd0]
    d77c:      	ldr	x21, [sp, #0xd8]
    d780:      	ldr	x22, [sp, #0xe0]
    d784:      	ldr	x23, [sp, #0xe8]
    d788:      	ldr	x24, [sp, #0xf0]
    d78c:      	ldr	x25, [sp, #0xf8]
    d790:      	ldr	x26, [sp, #0x100]
    d794:      	ldr	x27, [sp, #0x108]
    d798:      	ldr	x28, [sp, #0x110]
    d79c:      	ldr	x29, [sp]
    d7a0:      	ldr	x30, [sp, #0x8]
    d7a4:      	add	sp, sp, #0x120
    d7a8:      	ret
    d7ac:      	sxtw	x19, w1
    d7b0:      	sxtw	x1, w2
    d7b4:      	lsr	w4, w7, #0
    d7b8:      	ubfx	x4, x4, #8, #8
    d7bc:      	orr	x20, x4, xzr
    d7c0:      	cmp	x19, #0x3d
    d7c4:      	b.ne	0xd7d8 <_stogir.vector-lanes.operands+0x268>
    d7c8:      	mov	x21, x20
    d7cc:      	b	0xd7dc <_stogir.vector-lanes.operands+0x26c>
    d7d0:      	movz	x9, #0x0, lsl #48
    d7d4:      	b	0xd6c4 <_stogir.vector-lanes.operands+0x154>
    d7d8:      	mov	x21, x1
    d7dc:      	cmp	x19, #0x3d
    d7e0:      	b.eq	0xd7e8 <_stogir.vector-lanes.operands+0x278>
    d7e4:      	mov	x1, x20
    d7e8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d7e8:  ARM64_RELOC_PAGE21	l_stogir.481
    d7ec:      	ldr	x16, [x16]
		000000000000d7ec:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    d7f0:      	orr	x22, x16, xzr
    d7f4:      	lsr	w23, w21, #0
    d7f8:      	sxtw	x24, w23
    d7fc:      	cmp	x24, #0xf
    d800:      	cset	w25, gt
    d804:      	cmp	x24, #0x80
    d808:      	cset	w26, lt
    d80c:      	and	x4, x24, #0xf
    d810:      	lsr	w4, w4, #0
    d814:      	sxtw	x4, w4
    d818:      	cmp	x4, #0x1
    d81c:      	cset	w27, ge
    d820:      	cmp	x4, #0xd
    d824:      	cset	w28, le
    d828:      	cmp	x19, #0x3d
    d82c:      	b.lt	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d830:      	cmp	x19, #0x3f
    d834:      	b.gt	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d838:      	uxtb	w16, w25
    d83c:      	cmp	w16, wzr
    d840:      	b.eq	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d844:      	uxtb	w16, w26
    d848:      	cmp	w16, wzr
    d84c:      	b.eq	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d850:      	uxtb	w16, w27
    d854:      	cmp	w16, wzr
    d858:      	b.eq	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d85c:      	uxtb	w16, w28
    d860:      	cmp	w16, wzr
    d864:      	b.eq	0xd87c <_stogir.vector-lanes.operands+0x30c>
    d868:      	sxtw	x4, w3
    d86c:      	cmp	x4, #0x4
    d870:      	b.eq	0xde78 <_stogir.vector-lanes.operands+0x908>
    d874:      	cmp	x4, #0x8
    d878:      	b.eq	0xde78 <_stogir.vector-lanes.operands+0x908>
    d87c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d87c:  ARM64_RELOC_PAGE21	l_stogir.482
    d880:      	ldr	x16, [x16]
		000000000000d880:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    d884:      	orr	x4, x16, xzr
    d888:      	mov	x7, #0x36               ; =54
    d88c:      	sxtw	x9, w5
    d890:      	sxtw	x10, w6
    d894:      	cmp	x10, #0x0
    d898:      	cset	w10, eq
    d89c:      	cmp	x19, #0x3f
    d8a0:      	b.ne	0xdec4 <_stogir.vector-lanes.operands+0x954>
    d8a4:      	lsr	w1, w1, #0
    d8a8:      	lsr	w3, w3, #0
    d8ac:      	mov	w0, w23
    d8b0:      	mov	w2, w3
    d8b4:      	mov	x19, x8
    d8b8:      	mov	x20, x4
    d8bc:      	mov	x23, x7
    d8c0:      	mov	x24, x9
    d8c4:      	mov	w25, w10
    d8c8:      	bl	0xd8c8 <_stogir.vector-lanes.operands+0x358>
		000000000000d8c8:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d8cc:      	cmp	x0, #0x0
    d8d0:      	b.eq	0xd9c0 <_stogir.vector-lanes.operands+0x450>
    d8d4:      	mov	x1, x20
    d8d8:      	movz	x0, #0x0, lsl #48
    d8dc:      	b	0xd9c8 <_stogir.vector-lanes.operands+0x458>
    d8e0:      	cmp	x19, #0x3d
    d8e4:      	b.ne	0xded4 <_stogir.vector-lanes.operands+0x964>
    d8e8:      	lsr	w2, w2, #0
    d8ec:      	lsr	w3, w3, #0
    d8f0:      	str	x0, [sp, #0x80]
    d8f4:      	mov	w0, w23
    d8f8:      	str	w3, [sp, #0xb8]
    d8fc:      	str	x1, [sp, #0xa0]
    d900:      	mov	w1, w2
    d904:      	mov	w2, w3
    d908:      	str	x4, [sp, #0xa8]
    d90c:      	str	x7, [sp, #0xb0]
    d910:      	str	w9, [sp, #0xc0]
    d914:      	str	x22, [sp, #0x88]
    d918:      	mov	x22, x8
    d91c:      	str	w23, [sp, #0x90]
    d920:      	mov	w23, w5
    d924:      	str	x21, [sp, #0x98]
    d928:      	mov	w21, w6
    d92c:      	bl	0xd92c <_stogir.vector-lanes.operands+0x3bc>
		000000000000d92c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    d930:      	cmp	x0, #0x0
    d934:      	b.ne	0xd9d8 <_stogir.vector-lanes.operands+0x468>
    d938:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d938:  ARM64_RELOC_PAGE21	l_stogir.483
    d93c:      	ldr	x16, [x16]
		000000000000d93c:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    d940:      	orr	x0, x16, xzr
    d944:      	mov	x1, #0x26               ; =38
    d948:      	b	0xd9e0 <_stogir.vector-lanes.operands+0x470>
    d94c:      	movz	x9, #0x0, lsl #48
    d950:      	b	0xd65c <_stogir.vector-lanes.operands+0xec>
    d954:      	ldr	x0, [sp, #0x98]
    d958:      	and	x0, x0, #0xffffffff
    d95c:      	mov	x1, x0
    d960:      	movz	x0, #0x0, lsl #48
    d964:      	movz	x2, #0x0, lsl #48
    d968:      	b	0xd6bc <_stogir.vector-lanes.operands+0x14c>
    d96c:      	ldr	w0, [sp, #0xc0]
    d970:      	uxtb	w16, w0
    d974:      	cmp	w16, wzr
    d978:      	b.eq	0xdc7c <_stogir.vector-lanes.operands+0x70c>
    d97c:      	mov	x0, x20
    d980:      	mov	x1, x22
    d984:      	mov	x19, x0
    d988:      	mov	x20, x1
    d98c:      	b	0xd67c <_stogir.vector-lanes.operands+0x10c>
    d990:      	cmp	x24, #0x0
    d994:      	b.ne	0xdb6c <_stogir.vector-lanes.operands+0x5fc>
    d998:      	uxtb	w16, w25
    d99c:      	cmp	w16, wzr
    d9a0:      	cset	x0, eq
    d9a4:      	cmp	x0, #0x0
    d9a8:      	b.eq	0xd660 <_stogir.vector-lanes.operands+0xf0>
    d9ac:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000d9ac:  ARM64_RELOC_PAGE21	l_stogir.484
    d9b0:      	ldr	x16, [x16]
		000000000000d9b0:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    d9b4:      	orr	x0, x16, xzr
    d9b8:      	mov	x1, #0x24               ; =36
    d9bc:      	b	0xd668 <_stogir.vector-lanes.operands+0xf8>
    d9c0:      	mov	x1, x20
    d9c4:      	mov	x0, #0x1                ; =1
    d9c8:      	cmp	x0, #0x0
    d9cc:      	b.eq	0xd990 <_stogir.vector-lanes.operands+0x420>
    d9d0:      	mov	x0, #0x1                ; =1
    d9d4:      	b	0xd9a4 <_stogir.vector-lanes.operands+0x434>
    d9d8:      	ldr	x0, [sp, #0xa8]
    d9dc:      	ldr	x1, [sp, #0xb0]
    d9e0:      	cmp	x19, #0x3e
    d9e4:      	b.ne	0xda14 <_stogir.vector-lanes.operands+0x4a4>
    d9e8:      	cmp	x20, x24
    d9ec:      	b.ne	0xd9fc <_stogir.vector-lanes.operands+0x48c>
    d9f0:      	mov	x2, x0
    d9f4:      	movz	x0, #0x0, lsl #48
    d9f8:      	b	0xda04 <_stogir.vector-lanes.operands+0x494>
    d9fc:      	mov	x2, x0
    da00:      	mov	x0, #0x1                ; =1
    da04:      	fmov	d31, x1
    da08:      	mov	x1, x2
    da0c:      	fmov	x2, d31
    da10:      	b	0xda20 <_stogir.vector-lanes.operands+0x4b0>
    da14:      	mov	x2, x1
    da18:      	mov	x1, x0
    da1c:      	movz	x0, #0x0, lsl #48
    da20:      	cmp	x0, #0x0
    da24:      	b.eq	0xda40 <_stogir.vector-lanes.operands+0x4d0>
    da28:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000da28:  ARM64_RELOC_PAGE21	l_stogir.485
    da2c:      	ldr	x16, [x16]
		000000000000da2c:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    da30:      	orr	x0, x16, xzr
    da34:      	mov	x20, x0
    da38:      	mov	x0, #0x27               ; =39
    da3c:      	b	0xda48 <_stogir.vector-lanes.operands+0x4d8>
    da40:      	mov	x20, x1
    da44:      	mov	x0, x2
    da48:      	lsr	w23, w23, #0
    da4c:      	add	x8, sp, #0x10
    da50:      	mov	w1, w23
    da54:      	mov	x23, x0
    da58:      	ldr	x0, [sp, #0x80]
    da5c:      	bl	0xda5c <_stogir.vector-lanes.operands+0x4ec>
		000000000000da5c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    da60:      	add	x16, sp, #0x10
    da64:      	ldr	w0, [x16]
    da68:      	lsr	x16, x0, #0
    da6c:      	cmp	x16, #0x1
    da70:      	b.eq	0xda8c <_stogir.vector-lanes.operands+0x51c>
    da74:      	b.lo	0xda7c <_stogir.vector-lanes.operands+0x50c>
    da78:      	b	0xda90 <_stogir.vector-lanes.operands+0x520>
    da7c:      	cmp	x16, #0x0
    da80:      	b.eq	0xda88 <_stogir.vector-lanes.operands+0x518>
    da84:      	b	0xda90 <_stogir.vector-lanes.operands+0x520>
    da88:      	b	0xda94 <_stogir.vector-lanes.operands+0x524>
    da8c:      	b	0xdb0c <_stogir.vector-lanes.operands+0x59c>
    da90:      	b	0xdeb4 <_stogir.vector-lanes.operands+0x944>
    da94:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000da94:  ARM64_RELOC_PAGE21	l_stogir.486
    da98:      	ldr	x16, [x16]
		000000000000da98:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    da9c:      	orr	x0, x16, xzr
    daa0:      	mov	x20, x0
    daa4:      	mov	x22, #0x19              ; =25
    daa8:      	cmp	x19, #0x3e
    daac:      	b.ne	0xd96c <_stogir.vector-lanes.operands+0x3fc>
    dab0:      	lsr	w21, w21, #0
    dab4:      	add	x8, sp, #0x50
    dab8:      	ldr	x0, [sp, #0x80]
    dabc:      	mov	w1, w21
    dac0:      	bl	0xdac0 <_stogir.vector-lanes.operands+0x550>
		000000000000dac0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    dac4:      	add	x16, sp, #0x50
    dac8:      	ldr	w0, [x16]
    dacc:      	lsr	x16, x0, #0
    dad0:      	cmp	x16, #0x1
    dad4:      	b.eq	0xdaf0 <_stogir.vector-lanes.operands+0x580>
    dad8:      	b.lo	0xdae0 <_stogir.vector-lanes.operands+0x570>
    dadc:      	b	0xdaf4 <_stogir.vector-lanes.operands+0x584>
    dae0:      	cmp	x16, #0x0
    dae4:      	b.eq	0xdaec <_stogir.vector-lanes.operands+0x57c>
    dae8:      	b	0xdaf4 <_stogir.vector-lanes.operands+0x584>
    daec:      	b	0xdaf8 <_stogir.vector-lanes.operands+0x588>
    daf0:      	b	0xdc90 <_stogir.vector-lanes.operands+0x720>
    daf4:      	b	0xdebc <_stogir.vector-lanes.operands+0x94c>
    daf8:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000daf8:  ARM64_RELOC_PAGE21	l_stogir.487
    dafc:      	ldr	x16, [x16]
		000000000000dafc:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    db00:      	orr	x0, x16, xzr
    db04:      	mov	x1, #0x20               ; =32
    db08:      	b	0xdb7c <_stogir.vector-lanes.operands+0x60c>
    db0c:      	add	x16, sp, #0x10
    db10:      	orr	x0, x16, xzr
    db14:      	add	x0, x0, #0x8
    db18:      	add	x16, sp, #0x10
    db1c:      	ldr	x1, [x16, #0x8]
    db20:      	add	x16, sp, #0x40
    db24:      	str	x1, [x16]
    db28:      	lsr	w1, w1, #0
    db2c:      	ldr	x0, [x0, #0x8]
    db30:      	add	x16, sp, #0x40
    db34:      	str	x0, [x16, #0x8]
    db38:      	ubfx	x0, x1, #8, #8
    db3c:      	cmp	x0, #0x1
    db40:      	b.lt	0xdb80 <_stogir.vector-lanes.operands+0x610>
    db44:      	cmp	x0, #0xb
    db48:      	cset	w0, le
    db4c:      	ubfx	x0, x0, #0, #8
    db50:      	mov	x1, x20
    db54:      	b	0xdb88 <_stogir.vector-lanes.operands+0x618>
    db58:      	mov	x0, x1
    db5c:      	mov	x1, x2
    db60:      	mov	x20, x0
    db64:      	mov	x22, x1
    db68:      	b	0xdaa8 <_stogir.vector-lanes.operands+0x538>
    db6c:      	mov	x0, #0x1                ; =1
    db70:      	b	0xd9a4 <_stogir.vector-lanes.operands+0x434>
    db74:      	mov	x0, x1
    db78:      	mov	x1, x22
    db7c:      	b	0xd984 <_stogir.vector-lanes.operands+0x414>
    db80:      	mov	x1, x20
    db84:      	movz	x0, #0x0, lsl #48
    db88:      	cmp	x0, #0x0
    db8c:      	b.eq	0xdb98 <_stogir.vector-lanes.operands+0x628>
    db90:      	movz	x0, #0x0, lsl #48
    db94:      	b	0xdb9c <_stogir.vector-lanes.operands+0x62c>
    db98:      	mov	x0, #0x1                ; =1
    db9c:      	cmp	x0, #0x0
    dba0:      	b.eq	0xdc4c <_stogir.vector-lanes.operands+0x6dc>
    dba4:      	mov	x0, #0x1                ; =1
    dba8:      	b	0xdbd4 <_stogir.vector-lanes.operands+0x664>
    dbac:      	cmp	x0, #0x46
    dbb0:      	cset	w0, eq
    dbb4:      	uxtb	w16, w0
    dbb8:      	cmp	w16, wzr
    dbbc:      	cset	x0, eq
    dbc0:      	cmp	x0, #0x0
    dbc4:      	cset	w0, ne
    dbc8:      	uxtb	w16, w0
    dbcc:      	cmp	w16, wzr
    dbd0:      	cset	x0, eq
    dbd4:      	cmp	x0, #0x0
    dbd8:      	b.eq	0xdbf0 <_stogir.vector-lanes.operands+0x680>
    dbdc:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000dbdc:  ARM64_RELOC_PAGE21	l_stogir.488
    dbe0:      	ldr	x16, [x16]
		000000000000dbe0:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    dbe4:      	orr	x0, x16, xzr
    dbe8:      	mov	x1, #0x2b               ; =43
    dbec:      	b	0xdbf8 <_stogir.vector-lanes.operands+0x688>
    dbf0:      	mov	x0, x1
    dbf4:      	mov	x1, x23
    dbf8:      	cmp	x22, #0x0
    dbfc:      	b.ge	0xdc24 <_stogir.vector-lanes.operands+0x6b4>
    dc00:      	add	x16, sp, #0x40
    dc04:      	ldr	w2, [x16]
    dc08:      	uxtb	w3, w2
    dc0c:      	ubfx	x2, x2, #8, #8
    dc10:      	cmp	x3, x2
    dc14:      	b.ne	0xdcb0 <_stogir.vector-lanes.operands+0x740>
    dc18:      	mov	x2, x0
    dc1c:      	mov	x0, #0x1                ; =1
    dc20:      	b	0xdcc8 <_stogir.vector-lanes.operands+0x758>
    dc24:      	mov	x2, x1
    dc28:      	mov	x1, x0
    dc2c:      	movz	x0, #0x0, lsl #48
    dc30:      	cmp	x0, #0x0
    dc34:      	b.eq	0xdb58 <_stogir.vector-lanes.operands+0x5e8>
    dc38:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000dc38:  ARM64_RELOC_PAGE21	l_stogir.489
    dc3c:      	ldr	x16, [x16]
		000000000000dc3c:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    dc40:      	orr	x0, x16, xzr
    dc44:      	mov	x1, #0x28               ; =40
    dc48:      	b	0xdb60 <_stogir.vector-lanes.operands+0x5f0>
    dc4c:      	add	x16, sp, #0x40
    dc50:      	ldr	w0, [x16]
    dc54:      	uxtb	w0, w0
    dc58:      	cmp	x0, #0x48
    dc5c:      	b.ne	0xdbac <_stogir.vector-lanes.operands+0x63c>
    dc60:      	movz	x0, #0x0, lsl #48
    dc64:      	b	0xdbc0 <_stogir.vector-lanes.operands+0x650>
    dc68:      	fmov	d31, x1
    dc6c:      	mov	x1, x2
    dc70:      	fmov	x2, d31
    dc74:      	movz	x0, #0x0, lsl #48
    dc78:      	b	0xdc30 <_stogir.vector-lanes.operands+0x6c0>
    dc7c:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000dc7c:  ARM64_RELOC_PAGE21	l_stogir.490
    dc80:      	ldr	x16, [x16]
		000000000000dc80:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    dc84:      	orr	x0, x16, xzr
    dc88:      	mov	x1, #0x20               ; =32
    dc8c:      	b	0xd984 <_stogir.vector-lanes.operands+0x414>
    dc90:      	add	x16, sp, #0x50
    dc94:      	ldr	x0, [x16, #0x8]
    dc98:      	uxtb	w1, w0
    dc9c:      	cmp	x1, #0x48
    dca0:      	b.ne	0xddf4 <_stogir.vector-lanes.operands+0x884>
    dca4:      	mov	x2, x20
    dca8:      	movz	x1, #0x0, lsl #48
    dcac:      	b	0xde0c <_stogir.vector-lanes.operands+0x89c>
    dcb0:      	cmp	x3, #0x49
    dcb4:      	cset	w2, eq
    dcb8:      	ubfx	x2, x2, #0, #8
    dcbc:      	fmov	d31, x0
    dcc0:      	mov	x0, x2
    dcc4:      	fmov	x2, d31
    dcc8:      	cmp	x0, #0x0
    dccc:      	b.eq	0xdc68 <_stogir.vector-lanes.operands+0x6f8>
    dcd0:      	add	x16, sp, #0x40
    dcd4:      	ldr	w0, [x16, #0x8]
    dcd8:      	add	x16, sp, #0x40
    dcdc:      	ldr	w3, [x16, #0xc]
    dce0:      	uxtb	w16, w25
    dce4:      	cmp	w16, wzr
    dce8:      	b.eq	0xdd14 <_stogir.vector-lanes.operands+0x7a4>
    dcec:      	uxtb	w16, w26
    dcf0:      	cmp	w16, wzr
    dcf4:      	b.eq	0xde48 <_stogir.vector-lanes.operands+0x8d8>
    dcf8:      	uxtb	w16, w27
    dcfc:      	cmp	w16, wzr
    dd00:      	b.eq	0xde5c <_stogir.vector-lanes.operands+0x8ec>
    dd04:      	ubfx	x28, x28, #0, #8
    dd08:      	mov	x4, x2
    dd0c:      	mov	x2, x28
    dd10:      	b	0xde64 <_stogir.vector-lanes.operands+0x8f4>
    dd14:      	mov	x4, x1
    dd18:      	movz	x1, #0x0, lsl #48
    dd1c:      	cmp	x1, #0x0
    dd20:      	b.eq	0xde20 <_stogir.vector-lanes.operands+0x8b0>
    dd24:      	ubfx	x1, x24, #4, #32
    dd28:      	sxtw	x1, w1
    dd2c:      	sub	x1, x1, #0x1
    dd30:      	lsr	w1, w1, #0
    dd34:      	sxtw	x1, w1
    dd38:      	mov	x16, #0x1               ; =1
    dd3c:      	lsl	x1, x16, x1
    dd40:      	lsr	w1, w1, #0
    dd44:      	sxtw	x1, w1
    dd48:      	ubfx	x0, x0, #0, #32
    dd4c:      	ubfx	x3, x3, #0, #32
    dd50:      	lsl	x3, x3, #32
    dd54:      	orr	x0, x3, x0
    dd58:      	lsr	w1, w1, #0
    dd5c:      	sxtw	x1, w1
    dd60:      	cmp	x0, x1
    dd64:      	cset	w0, hs
    dd68:      	ubfx	x0, x0, #0, #8
    dd6c:      	mov	x1, x2
    dd70:      	mov	x2, x4
    dd74:      	b	0xdc78 <_stogir.vector-lanes.operands+0x708>
    dd78:      	brk	#0
    dd7c:      	b	0xdd78 <_stogir.vector-lanes.operands+0x808>
    dd80:      	ldr	w1, [sp, #0xb8]
    dd84:      	lsr	w1, w1, #0
    dd88:      	lsr	w0, w0, #0
    dd8c:      	ubfx	x0, x0, #8, #8
    dd90:      	lsr	w0, w0, #0
    dd94:      	mov	w2, w1
    dd98:      	mov	w1, w0
    dd9c:      	ldr	w0, [sp, #0x90]
    dda0:      	bl	0xdda0 <_stogir.vector-lanes.operands+0x830>
		000000000000dda0:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    dda4:      	cmp	x0, #0x0
    dda8:      	cset	w0, ne
    ddac:      	uxtb	w16, w0
    ddb0:      	cmp	w16, wzr
    ddb4:      	cset	x0, eq
    ddb8:      	mov	x1, x19
    ddbc:      	cmp	x0, #0x0
    ddc0:      	b.eq	0xdb74 <_stogir.vector-lanes.operands+0x604>
    ddc4:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000ddc4:  ARM64_RELOC_PAGE21	l_stogir.491
    ddc8:      	ldr	x16, [x16]
		000000000000ddc8:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    ddcc:      	orr	x0, x16, xzr
    ddd0:      	mov	x1, #0x27               ; =39
    ddd4:      	b	0xdb7c <_stogir.vector-lanes.operands+0x60c>
    ddd8:      	mov	x19, x2
    dddc:      	mov	x1, #0x1                ; =1
    dde0:      	cmp	x1, #0x0
    dde4:      	b.eq	0xdd80 <_stogir.vector-lanes.operands+0x810>
    dde8:      	mov	x1, x19
    ddec:      	mov	x0, #0x1                ; =1
    ddf0:      	b	0xddbc <_stogir.vector-lanes.operands+0x84c>
    ddf4:      	cmp	x1, #0x46
    ddf8:      	cset	w1, eq
    ddfc:      	uxtb	w16, w1
    de00:      	cmp	w16, wzr
    de04:      	cset	x1, eq
    de08:      	mov	x2, x20
    de0c:      	cmp	x1, #0x0
    de10:      	b.eq	0xddd8 <_stogir.vector-lanes.operands+0x868>
    de14:      	mov	x19, x2
    de18:      	movz	x1, #0x0, lsl #48
    de1c:      	b	0xdde0 <_stogir.vector-lanes.operands+0x870>
    de20:      	cmp	x24, #0x0
    de24:      	b.lt	0xde54 <_stogir.vector-lanes.operands+0x8e4>
    de28:      	cmp	x24, #0xd
    de2c:      	b.gt	0xde54 <_stogir.vector-lanes.operands+0x8e4>
    de30:      	cmp	x24, #0x0
    de34:      	cset	w1, eq
    de38:      	uxtb	w16, w1
    de3c:      	cmp	w16, wzr
    de40:      	cset	x1, eq
    de44:      	b	0xde58 <_stogir.vector-lanes.operands+0x8e8>
    de48:      	mov	x4, x1
    de4c:      	movz	x1, #0x0, lsl #48
    de50:      	b	0xdd1c <_stogir.vector-lanes.operands+0x7ac>
    de54:      	movn	x1, #0x0, lsl #48
    de58:      	b	0xdd48 <_stogir.vector-lanes.operands+0x7d8>
    de5c:      	mov	x4, x2
    de60:      	movz	x2, #0x0, lsl #48
    de64:      	fmov	d31, x1
    de68:      	mov	x1, x2
    de6c:      	mov	x2, x4
    de70:      	fmov	x4, d31
    de74:      	b	0xde50 <_stogir.vector-lanes.operands+0x8e0>
    de78:      	uxtb	w7, w7
    de7c:      	cmp	x7, #0x48
    de80:      	b.ne	0xde8c <_stogir.vector-lanes.operands+0x91c>
    de84:      	movz	x4, #0x0, lsl #48
    de88:      	b	0xdea0 <_stogir.vector-lanes.operands+0x930>
    de8c:      	cmp	x7, #0x46
    de90:      	cset	w4, eq
    de94:      	uxtb	w16, w4
    de98:      	cmp	w16, wzr
    de9c:      	cset	x4, eq
    dea0:      	cmp	x4, #0x0
    dea4:      	b.eq	0xd87c <_stogir.vector-lanes.operands+0x30c>
    dea8:      	mov	x4, x22
    deac:      	movz	x7, #0x0, lsl #48
    deb0:      	b	0xd88c <_stogir.vector-lanes.operands+0x31c>
    deb4:      	brk	#0
    deb8:      	b	0xdeb4 <_stogir.vector-lanes.operands+0x944>
    debc:      	brk	#0
    dec0:      	b	0xdebc <_stogir.vector-lanes.operands+0x94c>
    dec4:      	mov	x1, x8
    dec8:      	mov	x8, x9
    decc:      	mov	w9, w10
    ded0:      	b	0xd8e0 <_stogir.vector-lanes.operands+0x370>
    ded4:      	str	x21, [sp, #0x98]
    ded8:      	str	x1, [sp, #0xa0]
    dedc:      	str	x0, [sp, #0x80]
    dee0:      	str	w3, [sp, #0xb8]
    dee4:      	mov	w21, w6
    dee8:      	str	x22, [sp, #0x88]
    deec:      	mov	x22, x8
    def0:      	str	w23, [sp, #0x90]
    def4:      	mov	w23, w5
    def8:      	str	w9, [sp, #0xc0]
    defc:      	str	x4, [sp, #0xa8]
    df00:      	str	x7, [sp, #0xb0]
    df04:      	b	0xd9d8 <_stogir.vector-lanes.operands+0x468>

000000000000df08 <_stogir.vector-comparison.operation?>:
    df08:      	sxtw	x0, w0
    df0c:      	cmp	x0, #0xe
    df10:      	b.lt	0xdf24 <_stogir.vector-comparison.operation?+0x1c>
    df14:      	cmp	x0, #0x19
    df18:      	cset	w0, le
    df1c:      	ubfx	x0, x0, #0, #8
    df20:      	b	0xdf28 <_stogir.vector-comparison.operation?+0x20>
    df24:      	movz	x0, #0x0, lsl #48
    df28:      	ret

000000000000df2c <_stogir.vector-comparison.operands>:
    df2c:      	sub	sp, sp, #0xe0
    df30:      	str	x29, [sp]
    df34:      	str	x30, [sp, #0x8]
    df38:      	mov	x29, sp
    df3c:      	str	x19, [sp, #0x90]
    df40:      	str	x20, [sp, #0x98]
    df44:      	str	x21, [sp, #0xa0]
    df48:      	str	x22, [sp, #0xa8]
    df4c:      	str	x23, [sp, #0xb0]
    df50:      	str	x24, [sp, #0xb8]
    df54:      	str	x25, [sp, #0xc0]
    df58:      	str	x26, [sp, #0xc8]
    df5c:      	str	x27, [sp, #0xd0]
    df60:      	str	x28, [sp, #0xd8]
    df64:      	adrp	x16, 0xd000 <_stogir.floating.operands+0x128>
		000000000000df64:  ARM64_RELOC_PAGE21	l_stogir.492
    df68:      	ldr	x16, [x16]
		000000000000df68:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    df6c:      	orr	x19, x16, xzr
    df70:      	lsr	w4, w4, #0
    df74:      	mov	x20, x8
    df78:      	add	x8, sp, #0x10
    df7c:      	mov	x21, x0
    df80:      	mov	w22, w1
    df84:      	mov	w1, w4
    df88:      	mov	w23, w2
    df8c:      	mov	w24, w3
    df90:      	mov	w25, w5
    df94:      	bl	0xdf94 <_stogir.vector-comparison.operands+0x68>
		000000000000df94:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    df98:      	add	x16, sp, #0x10
    df9c:      	ldr	w0, [x16]
    dfa0:      	lsr	x16, x0, #0
    dfa4:      	cmp	x16, #0x1
    dfa8:      	b.eq	0xdfc4 <_stogir.vector-comparison.operands+0x98>
    dfac:      	b.lo	0xdfb4 <_stogir.vector-comparison.operands+0x88>
    dfb0:      	b	0xdfc8 <_stogir.vector-comparison.operands+0x9c>
    dfb4:      	cmp	x16, #0x0
    dfb8:      	b.eq	0xdfc0 <_stogir.vector-comparison.operands+0x94>
    dfbc:      	b	0xdfc8 <_stogir.vector-comparison.operands+0x9c>
    dfc0:      	b	0xdfcc <_stogir.vector-comparison.operands+0xa0>
    dfc4:      	b	0xe01c <_stogir.vector-comparison.operands+0xf0>
    dfc8:      	b	0xe1cc <_stogir.vector-comparison.operands+0x2a0>
    dfcc:      	mov	x1, x19
    dfd0:      	mov	x0, #0x1                ; =1
    dfd4:      	mov	x2, #0x21               ; =33
    dfd8:      	str	x0, [x20]
    dfdc:      	str	x1, [x20, #0x8]
    dfe0:      	str	x2, [x20, #0x10]
    dfe4:      	ldr	x19, [sp, #0x90]
    dfe8:      	ldr	x20, [sp, #0x98]
    dfec:      	ldr	x21, [sp, #0xa0]
    dff0:      	ldr	x22, [sp, #0xa8]
    dff4:      	ldr	x23, [sp, #0xb0]
    dff8:      	ldr	x24, [sp, #0xb8]
    dffc:      	ldr	x25, [sp, #0xc0]
    e000:      	ldr	x26, [sp, #0xc8]
    e004:      	ldr	x27, [sp, #0xd0]
    e008:      	ldr	x28, [sp, #0xd8]
    e00c:      	ldr	x29, [sp]
    e010:      	ldr	x30, [sp, #0x8]
    e014:      	add	sp, sp, #0xe0
    e018:      	ret
    e01c:      	lsr	w25, w25, #0
    e020:      	add	x16, sp, #0x10
    e024:      	ldr	x26, [x16, #0x8]
    e028:      	add	x8, sp, #0x40
    e02c:      	mov	x0, x21
    e030:      	mov	w1, w25
    e034:      	bl	0xe034 <_stogir.vector-comparison.operands+0x108>
		000000000000e034:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e038:      	add	x16, sp, #0x40
    e03c:      	ldr	w0, [x16]
    e040:      	lsr	x16, x0, #0
    e044:      	cmp	x16, #0x1
    e048:      	b.eq	0xe064 <_stogir.vector-comparison.operands+0x138>
    e04c:      	b.lo	0xe054 <_stogir.vector-comparison.operands+0x128>
    e050:      	b	0xe068 <_stogir.vector-comparison.operands+0x13c>
    e054:      	cmp	x16, #0x0
    e058:      	b.eq	0xe060 <_stogir.vector-comparison.operands+0x134>
    e05c:      	b	0xe068 <_stogir.vector-comparison.operands+0x13c>
    e060:      	b	0xe06c <_stogir.vector-comparison.operands+0x140>
    e064:      	b	0xe07c <_stogir.vector-comparison.operands+0x150>
    e068:      	b	0xe1d4 <_stogir.vector-comparison.operands+0x2a8>
    e06c:      	mov	x1, x19
    e070:      	mov	x0, #0x1                ; =1
    e074:      	mov	x2, #0x21               ; =33
    e078:      	b	0xdfd8 <_stogir.vector-comparison.operands+0xac>
    e07c:      	sxtw	x19, w24
    e080:      	cmp	x19, #0x4
    e084:      	cset	w21, eq
    e088:      	cmp	x19, #0x8
    e08c:      	cset	w25, eq
    e090:      	add	x16, sp, #0x40
    e094:      	ldr	x27, [x16, #0x8]
    e098:      	uxtb	w16, w21
    e09c:      	cmp	w16, wzr
    e0a0:      	b.ne	0xe0cc <_stogir.vector-comparison.operands+0x1a0>
    e0a4:      	uxtb	w16, w25
    e0a8:      	cmp	w16, wzr
    e0ac:      	b.ne	0xe0cc <_stogir.vector-comparison.operands+0x1a0>
    e0b0:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000e0b0:  ARM64_RELOC_PAGE21	l_stogir.493
    e0b4:      	ldr	x16, [x16]
		000000000000e0b4:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    e0b8:      	orr	x0, x16, xzr
    e0bc:      	mov	x1, x0
    e0c0:      	mov	x0, #0x1                ; =1
    e0c4:      	mov	x2, #0x33               ; =51
    e0c8:      	b	0xe078 <_stogir.vector-comparison.operands+0x14c>
    e0cc:      	lsr	w22, w22, #0
    e0d0:      	lsr	w0, w26, #0
    e0d4:      	ubfx	x28, x0, #8, #8
    e0d8:      	orr	x0, x28, xzr
    e0dc:      	lsr	w0, w0, #0
    e0e0:      	mov	w1, w0
    e0e4:      	fmov	s31, w0
    e0e8:      	mov	w0, w22
    e0ec:      	fmov	w22, s31
    e0f0:      	bl	0xe0f0 <_stogir.vector-comparison.operands+0x1c4>
		000000000000e0f0:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    e0f4:      	cmp	x0, #0x0
    e0f8:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e0fc:      	lsr	w0, w27, #0
    e100:      	ubfx	x0, x0, #8, #8
    e104:      	cmp	x28, x0
    e108:      	b.ne	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e10c:      	uxtb	w26, w26
    e110:      	cmp	x26, #0x48
    e114:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e118:      	cmp	x26, #0x46
    e11c:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e120:      	uxtb	w27, w27
    e124:      	cmp	x27, #0x48
    e128:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e12c:      	cmp	x27, #0x46
    e130:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e134:      	sxtw	x26, w23
    e138:      	cmp	x26, #0xf
    e13c:      	cset	w27, gt
    e140:      	uxtb	w16, w27
    e144:      	cmp	w16, wzr
    e148:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e14c:      	cmp	x26, #0x80
    e150:      	cset	w0, lt
    e154:      	uxtb	w16, w0
    e158:      	cmp	w16, wzr
    e15c:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e160:      	and	x1, x26, #0xf
    e164:      	lsr	w1, w1, #0
    e168:      	sxtw	x1, w1
    e16c:      	cmp	x1, #0x1
    e170:      	cset	w2, ge
    e174:      	uxtb	w16, w2
    e178:      	cmp	w16, wzr
    e17c:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e180:      	cmp	x1, #0xd
    e184:      	cset	w3, le
    e188:      	uxtb	w16, w3
    e18c:      	cmp	w16, wzr
    e190:      	b.eq	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e194:      	lsr	w23, w23, #0
    e198:      	str	x1, [sp, #0x78]
    e19c:      	str	x19, [sp, #0x70]
    e1a0:      	mov	w19, w0
    e1a4:      	mov	w0, w23
    e1a8:      	str	w22, [sp, #0x80]
    e1ac:      	mov	w22, w2
    e1b0:      	str	w23, [sp, #0x88]
    e1b4:      	mov	w23, w3
    e1b8:      	bl	0xe1b8 <_stogir.vector-comparison.operands+0x28c>
		000000000000e1b8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e1bc:      	cmp	x0, #0x0
    e1c0:      	b.eq	0xe1dc <_stogir.vector-comparison.operands+0x2b0>
    e1c4:      	ldr	x0, [sp, #0x78]
    e1c8:      	b	0xe1e0 <_stogir.vector-comparison.operands+0x2b4>
    e1cc:      	brk	#0
    e1d0:      	b	0xe1cc <_stogir.vector-comparison.operands+0x2a0>
    e1d4:      	brk	#0
    e1d8:      	b	0xe1d4 <_stogir.vector-comparison.operands+0x2a8>
    e1dc:      	movn	x0, #0x0, lsl #48
    e1e0:      	lsr	w0, w0, #0
    e1e4:      	sxtw	x0, w0
    e1e8:      	cmp	x0, #0x1
    e1ec:      	b.lt	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e1f0:      	cmp	x0, #0xb
    e1f4:      	b.gt	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e1f8:      	uxtb	w16, w27
    e1fc:      	cmp	w16, wzr
    e200:      	b.eq	0xe284 <_stogir.vector-comparison.operands+0x358>
    e204:      	uxtb	w16, w19
    e208:      	cmp	w16, wzr
    e20c:      	b.eq	0xe284 <_stogir.vector-comparison.operands+0x358>
    e210:      	uxtb	w16, w22
    e214:      	cmp	w16, wzr
    e218:      	b.eq	0xe284 <_stogir.vector-comparison.operands+0x358>
    e21c:      	uxtb	w16, w23
    e220:      	cmp	w16, wzr
    e224:      	b.eq	0xe284 <_stogir.vector-comparison.operands+0x358>
    e228:      	ubfx	x0, x26, #4, #32
    e22c:      	sxtw	x0, w0
    e230:      	sub	x0, x0, #0x1
    e234:      	lsr	w0, w0, #0
    e238:      	sxtw	x0, w0
    e23c:      	mov	x16, #0x1               ; =1
    e240:      	lsl	x0, x16, x0
    e244:      	lsr	w0, w0, #0
    e248:      	sxtw	x0, w0
    e24c:      	b	0xe2b0 <_stogir.vector-comparison.operands+0x384>
    e250:      	movn	x1, #0x0, lsl #48
    e254:      	lsr	w0, w0, #0
    e258:      	sxtw	x0, w0
    e25c:      	lsr	w1, w1, #0
    e260:      	sxtw	x1, w1
    e264:      	cmp	x0, x1
    e268:      	b.ne	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e26c:      	ldr	w0, [sp, #0x88]
    e270:      	bl	0xe270 <_stogir.vector-comparison.operands+0x344>
		000000000000e270:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e274:      	cmp	x0, #0x0
    e278:      	b.eq	0xe368 <_stogir.vector-comparison.operands+0x43c>
    e27c:      	ldr	x0, [sp, #0x78]
    e280:      	b	0xe36c <_stogir.vector-comparison.operands+0x440>
    e284:      	cmp	x26, #0x0
    e288:      	b.lt	0xe2ac <_stogir.vector-comparison.operands+0x380>
    e28c:      	cmp	x26, #0xd
    e290:      	b.gt	0xe2ac <_stogir.vector-comparison.operands+0x380>
    e294:      	cmp	x26, #0x0
    e298:      	cset	w0, eq
    e29c:      	uxtb	w16, w0
    e2a0:      	cmp	w16, wzr
    e2a4:      	cset	x0, eq
    e2a8:      	b	0xe2b0 <_stogir.vector-comparison.operands+0x384>
    e2ac:      	movn	x0, #0x0, lsl #48
    e2b0:      	and	x1, x28, #0xf
    e2b4:      	lsr	w1, w1, #0
    e2b8:      	sxtw	x19, w1
    e2bc:      	cmp	x28, #0xf
    e2c0:      	b.le	0xe304 <_stogir.vector-comparison.operands+0x3d8>
    e2c4:      	cmp	x28, #0x80
    e2c8:      	b.ge	0xe304 <_stogir.vector-comparison.operands+0x3d8>
    e2cc:      	cmp	x19, #0x1
    e2d0:      	b.lt	0xe304 <_stogir.vector-comparison.operands+0x3d8>
    e2d4:      	cmp	x19, #0xd
    e2d8:      	b.gt	0xe304 <_stogir.vector-comparison.operands+0x3d8>
    e2dc:      	ubfx	x1, x28, #4, #32
    e2e0:      	sxtw	x1, w1
    e2e4:      	sub	x1, x1, #0x1
    e2e8:      	lsr	w1, w1, #0
    e2ec:      	sxtw	x1, w1
    e2f0:      	mov	x16, #0x1               ; =1
    e2f4:      	lsl	x1, x16, x1
    e2f8:      	lsr	w1, w1, #0
    e2fc:      	sxtw	x1, w1
    e300:      	b	0xe254 <_stogir.vector-comparison.operands+0x328>
    e304:      	cmp	x28, #0xd
    e308:      	b.gt	0xe250 <_stogir.vector-comparison.operands+0x324>
    e30c:      	cmp	x28, #0x0
    e310:      	cset	w1, eq
    e314:      	uxtb	w16, w1
    e318:      	cmp	w16, wzr
    e31c:      	cset	x1, eq
    e320:      	b	0xe254 <_stogir.vector-comparison.operands+0x328>
    e324:      	movn	x0, #0x0, lsl #48
    e328:      	lsr	w24, w24, #0
    e32c:      	lsr	w21, w21, #0
    e330:      	sxtw	x21, w21
    e334:      	lsr	w0, w0, #0
    e338:      	lsr	w0, w0, #0
    e33c:      	mov	w1, w24
    e340:      	bl	0xe340 <_stogir.vector-comparison.operands+0x414>
		000000000000e340:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    e344:      	lsr	w0, w0, #0
    e348:      	sxtw	x0, w0
    e34c:      	cmp	x21, x0
    e350:      	b.ne	0xe0b0 <_stogir.vector-comparison.operands+0x184>
    e354:      	and	x0, x28, #0xffffffff
    e358:      	mov	x1, x0
    e35c:      	movz	x0, #0x0, lsl #48
    e360:      	movz	x2, #0x0, lsl #48
    e364:      	b	0xe0c8 <_stogir.vector-comparison.operands+0x19c>
    e368:      	movn	x0, #0x0, lsl #48
    e36c:      	uxtb	w16, w21
    e370:      	cmp	w16, wzr
    e374:      	b.ne	0xe3ac <_stogir.vector-comparison.operands+0x480>
    e378:      	uxtb	w16, w25
    e37c:      	cmp	w16, wzr
    e380:      	b.ne	0xe3ac <_stogir.vector-comparison.operands+0x480>
    e384:      	movn	x21, #0x0, lsl #48
    e388:      	b	0xe394 <_stogir.vector-comparison.operands+0x468>
    e38c:      	mov	x0, #0x1                ; =1
    e390:      	mov	x21, x0
    e394:      	ldr	w0, [sp, #0x80]
    e398:      	bl	0xe398 <_stogir.vector-comparison.operands+0x46c>
		000000000000e398:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e39c:      	cmp	x0, #0x0
    e3a0:      	b.eq	0xe324 <_stogir.vector-comparison.operands+0x3f8>
    e3a4:      	mov	x0, x19
    e3a8:      	b	0xe328 <_stogir.vector-comparison.operands+0x3fc>
    e3ac:      	lsr	w0, w0, #0
    e3b0:      	sxtw	x0, w0
    e3b4:      	cmp	x0, #0x0
    e3b8:      	b.ne	0xe3c4 <_stogir.vector-comparison.operands+0x498>
    e3bc:      	movz	x0, #0x0, lsl #48
    e3c0:      	b	0xe390 <_stogir.vector-comparison.operands+0x464>
    e3c4:      	cmp	x0, #0x1
    e3c8:      	b.eq	0xe38c <_stogir.vector-comparison.operands+0x460>
    e3cc:      	cmp	x0, #0x2
    e3d0:      	b.eq	0xe38c <_stogir.vector-comparison.operands+0x460>
    e3d4:      	cmp	x0, #0x7
    e3d8:      	b.eq	0xe38c <_stogir.vector-comparison.operands+0x460>
    e3dc:      	cmp	x0, #0x8
    e3e0:      	b.eq	0xe38c <_stogir.vector-comparison.operands+0x460>
    e3e4:      	cmp	x0, #0x3
    e3e8:      	b.eq	0xe434 <_stogir.vector-comparison.operands+0x508>
    e3ec:      	cmp	x0, #0x9
    e3f0:      	b.eq	0xe434 <_stogir.vector-comparison.operands+0x508>
    e3f4:      	cmp	x0, #0x4
    e3f8:      	b.eq	0xe43c <_stogir.vector-comparison.operands+0x510>
    e3fc:      	cmp	x0, #0xa
    e400:      	b.eq	0xe43c <_stogir.vector-comparison.operands+0x510>
    e404:      	cmp	x0, #0xd
    e408:      	b.eq	0xe43c <_stogir.vector-comparison.operands+0x510>
    e40c:      	cmp	x0, #0x5
    e410:      	b.eq	0xe444 <_stogir.vector-comparison.operands+0x518>
    e414:      	cmp	x0, #0xb
    e418:      	b.eq	0xe444 <_stogir.vector-comparison.operands+0x518>
    e41c:      	cmp	x0, #0xc
    e420:      	b.eq	0xe444 <_stogir.vector-comparison.operands+0x518>
    e424:      	cmp	x0, #0x6
    e428:      	b.ne	0xe44c <_stogir.vector-comparison.operands+0x520>
    e42c:      	ldr	x0, [sp, #0x70]
    e430:      	b	0xe450 <_stogir.vector-comparison.operands+0x524>
    e434:      	mov	x0, #0x2                ; =2
    e438:      	b	0xe390 <_stogir.vector-comparison.operands+0x464>
    e43c:      	mov	x0, #0x4                ; =4
    e440:      	b	0xe438 <_stogir.vector-comparison.operands+0x50c>
    e444:      	mov	x0, #0x8                ; =8
    e448:      	b	0xe440 <_stogir.vector-comparison.operands+0x514>
    e44c:      	movn	x0, #0x0, lsl #48
    e450:      	b	0xe448 <_stogir.vector-comparison.operands+0x51c>

000000000000e454 <_stogir.vector-arithmetic.operation?>:
    e454:      	sxtw	x0, w0
    e458:      	cmp	x0, #0x1f
    e45c:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e460:      	cmp	x0, #0x20
    e464:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e468:      	cmp	x0, #0x2d
    e46c:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e470:      	cmp	x0, #0x36
    e474:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e478:      	cmp	x0, #0x37
    e47c:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e480:      	cmp	x0, #0x38
    e484:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e488:      	cmp	x0, #0x39
    e48c:      	b.eq	0xe4b8 <_stogir.vector-arithmetic.operation?+0x64>
    e490:      	cmp	x0, #0x3a
    e494:      	b.eq	0xe4c0 <_stogir.vector-arithmetic.operation?+0x6c>
    e498:      	cmp	x0, #0x3b
    e49c:      	b.eq	0xe4c0 <_stogir.vector-arithmetic.operation?+0x6c>
    e4a0:      	cmp	x0, #0x31
    e4a4:      	b.lt	0xe4d8 <_stogir.vector-arithmetic.operation?+0x84>
    e4a8:      	cmp	x0, #0x35
    e4ac:      	b.gt	0xe4d8 <_stogir.vector-arithmetic.operation?+0x84>
    e4b0:      	mov	x0, #0x1                ; =1
    e4b4:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e4b8:      	mov	x0, #0x1                ; =1
    e4bc:      	ret
    e4c0:      	mov	x0, #0x1                ; =1
    e4c4:      	b	0xe4bc <_stogir.vector-arithmetic.operation?+0x68>
    e4c8:      	cmp	x0, #0x30
    e4cc:      	cset	w0, eq
    e4d0:      	ubfx	x0, x0, #0, #8
    e4d4:      	b	0xe4c4 <_stogir.vector-arithmetic.operation?+0x70>
    e4d8:      	cmp	x0, #0x1a
    e4dc:      	b.ne	0xe4e8 <_stogir.vector-arithmetic.operation?+0x94>
    e4e0:      	mov	x0, #0x1                ; =1
    e4e4:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e4e8:      	cmp	x0, #0x1b
    e4ec:      	b.ne	0xe4f8 <_stogir.vector-arithmetic.operation?+0xa4>
    e4f0:      	mov	x0, #0x1                ; =1
    e4f4:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e4f8:      	cmp	x0, #0x1c
    e4fc:      	b.ne	0xe508 <_stogir.vector-arithmetic.operation?+0xb4>
    e500:      	mov	x0, #0x1                ; =1
    e504:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e508:      	cmp	x0, #0x1d
    e50c:      	b.ne	0xe518 <_stogir.vector-arithmetic.operation?+0xc4>
    e510:      	mov	x0, #0x1                ; =1
    e514:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e518:      	cmp	x0, #0x1e
    e51c:      	b.ne	0xe528 <_stogir.vector-arithmetic.operation?+0xd4>
    e520:      	mov	x0, #0x1                ; =1
    e524:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e528:      	cmp	x0, #0x2e
    e52c:      	b.ne	0xe538 <_stogir.vector-arithmetic.operation?+0xe4>
    e530:      	mov	x0, #0x1                ; =1
    e534:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>
    e538:      	cmp	x0, #0x2f
    e53c:      	b.ne	0xe4c8 <_stogir.vector-arithmetic.operation?+0x74>
    e540:      	mov	x0, #0x1                ; =1
    e544:      	b	0xe4d4 <_stogir.vector-arithmetic.operation?+0x80>

000000000000e548 <_stogir.vector-arithmetic.unary?>:
    e548:      	sxtw	x0, w0
    e54c:      	cmp	x0, #0x1f
    e550:      	b.ne	0xe56c <_stogir.vector-arithmetic.unary?+0x24>
    e554:      	mov	x0, #0x1                ; =1
    e558:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>
    e55c:      	cmp	x0, #0x39
    e560:      	cset	w0, eq
    e564:      	ubfx	x0, x0, #0, #8
    e568:      	ret
    e56c:      	cmp	x0, #0x20
    e570:      	b.ne	0xe57c <_stogir.vector-arithmetic.unary?+0x34>
    e574:      	mov	x0, #0x1                ; =1
    e578:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>
    e57c:      	cmp	x0, #0x2d
    e580:      	b.ne	0xe58c <_stogir.vector-arithmetic.unary?+0x44>
    e584:      	mov	x0, #0x1                ; =1
    e588:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>
    e58c:      	cmp	x0, #0x36
    e590:      	b.ne	0xe59c <_stogir.vector-arithmetic.unary?+0x54>
    e594:      	mov	x0, #0x1                ; =1
    e598:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>
    e59c:      	cmp	x0, #0x37
    e5a0:      	b.ne	0xe5ac <_stogir.vector-arithmetic.unary?+0x64>
    e5a4:      	mov	x0, #0x1                ; =1
    e5a8:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>
    e5ac:      	cmp	x0, #0x38
    e5b0:      	b.ne	0xe55c <_stogir.vector-arithmetic.unary?+0x14>
    e5b4:      	mov	x0, #0x1                ; =1
    e5b8:      	b	0xe568 <_stogir.vector-arithmetic.unary?+0x20>

000000000000e5bc <_stogir.vector-arithmetic.operands>:
    e5bc:      	sub	sp, sp, #0xb0
    e5c0:      	str	x29, [sp]
    e5c4:      	str	x30, [sp, #0x8]
    e5c8:      	mov	x29, sp
    e5cc:      	str	x19, [sp, #0x58]
    e5d0:      	str	x20, [sp, #0x60]
    e5d4:      	str	x21, [sp, #0x68]
    e5d8:      	str	x22, [sp, #0x70]
    e5dc:      	str	x23, [sp, #0x78]
    e5e0:      	str	x24, [sp, #0x80]
    e5e4:      	str	x25, [sp, #0x88]
    e5e8:      	str	x26, [sp, #0x90]
    e5ec:      	str	x27, [sp, #0x98]
    e5f0:      	str	x28, [sp, #0xa0]
    e5f4:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000e5f4:  ARM64_RELOC_PAGE21	l_stogir.494
    e5f8:      	ldr	x16, [x16]
		000000000000e5f8:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    e5fc:      	orr	x19, x16, xzr
    e600:      	lsr	w1, w1, #0
    e604:      	lsr	w2, w2, #0
    e608:      	mov	x20, x8
    e60c:      	mov	x21, x0
    e610:      	mov	w0, w1
    e614:      	mov	w22, w1
    e618:      	mov	w1, w2
    e61c:      	mov	w23, w2
    e620:      	mov	w24, w3
    e624:      	mov	w25, w4
    e628:      	mov	w26, w5
    e62c:      	bl	0xe62c <_stogir.vector-arithmetic.operands+0x70>
		000000000000e62c:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    e630:      	cmp	x0, #0x0
    e634:      	b.eq	0xe644 <_stogir.vector-arithmetic.operands+0x88>
    e638:      	mov	x0, x19
    e63c:      	movz	x1, #0x0, lsl #48
    e640:      	b	0xe654 <_stogir.vector-arithmetic.operands+0x98>
    e644:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000e644:  ARM64_RELOC_PAGE21	l_stogir.495
    e648:      	ldr	x16, [x16]
		000000000000e648:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    e64c:      	orr	x0, x16, xzr
    e650:      	mov	x1, #0x37               ; =55
    e654:      	sxtw	x22, w22
    e658:      	sxtw	x23, w23
    e65c:      	sxtw	x24, w24
    e660:      	sxtw	x25, w25
    e664:      	add	x2, x21, #0x78
    e668:      	add	x3, x21, #0x28
    e66c:      	add	x4, x21, #0x50
    e670:      	cmp	x22, #0x31
    e674:      	cset	w5, ge
    e678:      	cmp	x22, #0x35
    e67c:      	cset	w6, le
    e680:      	cmp	x22, #0x1f
    e684:      	cset	w7, eq
    e688:      	cmp	x22, #0x20
    e68c:      	cset	w8, eq
    e690:      	cmp	x22, #0x2d
    e694:      	cset	w9, eq
    e698:      	cmp	x22, #0x36
    e69c:      	cset	w10, eq
    e6a0:      	cmp	x22, #0x37
    e6a4:      	cset	w11, eq
    e6a8:      	cmp	x22, #0x38
    e6ac:      	cset	w12, eq
    e6b0:      	cmp	x22, #0x39
    e6b4:      	cset	w13, eq
    e6b8:      	ubfx	x13, x13, #0, #8
    e6bc:      	mov	x14, x1
    e6c0:      	mov	x1, x0
    e6c4:      	movz	x0, #0x0, lsl #48
    e6c8:      	b	0xe7b0 <_stogir.vector-arithmetic.operands+0x1f4>
    e6cc:      	movz	x2, #0x0, lsl #48
    e6d0:      	b	0xe6e0 <_stogir.vector-arithmetic.operands+0x124>
    e6d4:      	movz	x2, #0x0, lsl #48
    e6d8:      	b	0xe6e8 <_stogir.vector-arithmetic.operands+0x12c>
    e6dc:      	movz	x2, #0x0, lsl #48
    e6e0:      	b	0xe6f4 <_stogir.vector-arithmetic.operands+0x138>
    e6e4:      	movz	x2, #0x0, lsl #48
    e6e8:      	str	x3, [sp, #0x50]
    e6ec:      	b	0xe6f4 <_stogir.vector-arithmetic.operands+0x138>
    e6f0:      	movz	x2, #0x0, lsl #48
    e6f4:      	cmp	x2, #0x0
    e6f8:      	b.eq	0xe738 <_stogir.vector-arithmetic.operands+0x17c>
    e6fc:      	uxtb	w16, w27
    e700:      	cmp	w16, wzr
    e704:      	b.eq	0xe71c <_stogir.vector-arithmetic.operands+0x160>
    e708:      	lsl	x1, x1, #4
    e70c:      	ldr	x2, [x21]
    e710:      	add	x1, x1, x2
    e714:      	ldr	x1, [x1]
    e718:      	b	0xe72c <_stogir.vector-arithmetic.operands+0x170>
    e71c:      	lsl	x1, x7, #4
    e720:      	ldr	x2, [x21, #0x28]
    e724:      	add	x1, x1, x2
    e728:      	ldr	x1, [x1]
    e72c:      	mov	x2, x1
    e730:      	mov	x1, #0x1                ; =1
    e734:      	b	0xe740 <_stogir.vector-arithmetic.operands+0x184>
    e738:      	movz	x1, #0x0, lsl #48
    e73c:      	movz	x2, #0x0, lsl #48
    e740:      	lsr	w1, w1, #0
    e744:      	lsr	x16, x1, #0
    e748:      	cmp	x16, #0x1
    e74c:      	b.eq	0xe768 <_stogir.vector-arithmetic.operands+0x1ac>
    e750:      	b.lo	0xe758 <_stogir.vector-arithmetic.operands+0x19c>
    e754:      	b	0xe76c <_stogir.vector-arithmetic.operands+0x1b0>
    e758:      	cmp	x16, #0x0
    e75c:      	b.eq	0xe764 <_stogir.vector-arithmetic.operands+0x1a8>
    e760:      	b	0xe76c <_stogir.vector-arithmetic.operands+0x1b0>
    e764:      	b	0xe770 <_stogir.vector-arithmetic.operands+0x1b4>
    e768:      	b	0xe8d8 <_stogir.vector-arithmetic.operands+0x31c>
    e76c:      	b	0xeb24 <_stogir.vector-arithmetic.operands+0x568>
    e770:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000e770:  ARM64_RELOC_PAGE21	l_stogir.496
    e774:      	ldr	x16, [x16]
		000000000000e774:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    e778:      	orr	x1, x16, xzr
    e77c:      	mov	x2, #0x21               ; =33
    e780:      	b	0xe794 <_stogir.vector-arithmetic.operands+0x1d8>
    e784:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000e784:  ARM64_RELOC_PAGE21	l_stogir.497
    e788:      	ldr	x16, [x16]
		000000000000e788:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    e78c:      	orr	x1, x16, xzr
    e790:      	mov	x2, #0x32               ; =50
    e794:      	add	x0, x0, #0x1
    e798:      	lsr	w0, w0, #0
    e79c:      	sxtw	x0, w0
    e7a0:      	ldr	w7, [sp, #0x40]
    e7a4:      	ldr	x3, [sp, #0x50]
    e7a8:      	mov	x14, x2
    e7ac:      	ldr	x2, [sp, #0x48]
    e7b0:      	uxtb	w16, w7
    e7b4:      	cmp	w16, wzr
    e7b8:      	b.eq	0xe80c <_stogir.vector-arithmetic.operands+0x250>
    e7bc:      	mov	x15, x14
    e7c0:      	mov	x14, x1
    e7c4:      	mov	x1, #0x1                ; =1
    e7c8:      	b	0xe7e0 <_stogir.vector-arithmetic.operands+0x224>
    e7cc:      	mov	x15, x13
    e7d0:      	fmov	d31, x1
    e7d4:      	mov	x1, x15
    e7d8:      	mov	x15, x14
    e7dc:      	fmov	x14, d31
    e7e0:      	cmp	x1, #0x0
    e7e4:      	b.eq	0xe7f0 <_stogir.vector-arithmetic.operands+0x234>
    e7e8:      	mov	x1, #0x1                ; =1
    e7ec:      	b	0xe7f4 <_stogir.vector-arithmetic.operands+0x238>
    e7f0:      	mov	x1, #0x2                ; =2
    e7f4:      	cmp	x0, x1
    e7f8:      	b.ge	0xe960 <_stogir.vector-arithmetic.operands+0x3a4>
    e7fc:      	cmp	x0, #0x0
    e800:      	b.ne	0xe820 <_stogir.vector-arithmetic.operands+0x264>
    e804:      	mov	x1, x24
    e808:      	b	0xe824 <_stogir.vector-arithmetic.operands+0x268>
    e80c:      	uxtb	w16, w8
    e810:      	cmp	w16, wzr
    e814:      	b.eq	0xe938 <_stogir.vector-arithmetic.operands+0x37c>
    e818:      	mov	x15, #0x1               ; =1
    e81c:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x214>
    e820:      	mov	x1, x25
    e824:      	lsr	w1, w1, #0
    e828:      	sxtw	x1, w1
    e82c:      	cmp	x1, #0x0
    e830:      	cset	w27, gt
    e834:      	movz	x16, #0x0, lsl #48
    e838:      	sub	x28, x16, x1
    e83c:      	str	w7, [sp, #0x40]
    e840:      	sub	x7, x28, #0x1
    e844:      	uxtb	w16, w27
    e848:      	cmp	w16, wzr
    e84c:      	b.eq	0xebe4 <_stogir.vector-arithmetic.operands+0x628>
    e850:      	ldr	x28, [x21, #0x8]
    e854:      	cmp	x1, x28
    e858:      	b.ge	0xebec <_stogir.vector-arithmetic.operands+0x630>
    e85c:      	ldr	x28, [x2, #0x8]
    e860:      	cmp	x1, x28
    e864:      	b.ge	0xebf4 <_stogir.vector-arithmetic.operands+0x638>
    e868:      	lsl	x28, x1, #2
    e86c:      	str	x2, [sp, #0x48]
    e870:      	ldr	x2, [x21, #0x78]
    e874:      	add	x2, x28, x2
    e878:      	ldr	w2, [x2]
    e87c:      	sxtw	x2, w2
    e880:      	cmp	x2, #0x0
    e884:      	cset	w2, ge
    e888:      	ubfx	x2, x2, #0, #8
    e88c:      	b	0xe6d8 <_stogir.vector-arithmetic.operands+0x11c>
    e890:      	cmp	x1, #0x0
    e894:      	b.ge	0xebfc <_stogir.vector-arithmetic.operands+0x640>
    e898:      	ldr	x2, [x3, #0x8]
    e89c:      	str	x3, [sp, #0x50]
    e8a0:      	ldr	x3, [x4, #0x8]
    e8a4:      	cmp	x2, x3
    e8a8:      	b.ne	0xe6dc <_stogir.vector-arithmetic.operands+0x120>
    e8ac:      	cmp	x28, x2
    e8b0:      	b.gt	0xe6cc <_stogir.vector-arithmetic.operands+0x110>
    e8b4:      	lsl	x2, x7, #2
    e8b8:      	ldr	x3, [x21, #0x50]
    e8bc:      	add	x2, x2, x3
    e8c0:      	ldr	w2, [x2]
    e8c4:      	sxtw	x2, w2
    e8c8:      	cmp	x2, #0x0
    e8cc:      	cset	w2, gt
    e8d0:      	ubfx	x2, x2, #0, #8
    e8d4:      	b	0xe6d0 <_stogir.vector-arithmetic.operands+0x114>
    e8d8:      	lsr	w1, w2, #0
    e8dc:      	ubfx	x1, x1, #8, #8
    e8e0:      	cmp	x1, x23
    e8e4:      	b.eq	0xe918 <_stogir.vector-arithmetic.operands+0x35c>
    e8e8:      	cmp	x0, #0x1
    e8ec:      	b.ne	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e8f0:      	uxtb	w16, w5
    e8f4:      	cmp	w16, wzr
    e8f8:      	b.eq	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e8fc:      	uxtb	w16, w6
    e900:      	cmp	w16, wzr
    e904:      	b.eq	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e908:      	cmp	x1, #0x1
    e90c:      	b.lt	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e910:      	cmp	x1, #0xb
    e914:      	b.gt	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e918:      	uxtb	w2, w2
    e91c:      	cmp	x2, #0x48
    e920:      	b.eq	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e924:      	cmp	x2, #0x46
    e928:      	b.eq	0xe784 <_stogir.vector-arithmetic.operands+0x1c8>
    e92c:      	mov	x1, x14
    e930:      	mov	x2, x15
    e934:      	b	0xe794 <_stogir.vector-arithmetic.operands+0x1d8>
    e938:      	uxtb	w16, w9
    e93c:      	cmp	w16, wzr
    e940:      	b.eq	0xe94c <_stogir.vector-arithmetic.operands+0x390>
    e944:      	mov	x15, #0x1               ; =1
    e948:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x214>
    e94c:      	uxtb	w16, w10
    e950:      	cmp	w16, wzr
    e954:      	b.eq	0xe97c <_stogir.vector-arithmetic.operands+0x3c0>
    e958:      	mov	x15, #0x1               ; =1
    e95c:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x214>
    e960:      	sxtw	x24, w26
    e964:      	cmp	x24, #0x0
    e968:      	b.ne	0xe990 <_stogir.vector-arithmetic.operands+0x3d4>
    e96c:      	mov	x1, x14
    e970:      	mov	x2, x15
    e974:      	movz	x0, #0x0, lsl #48
    e978:      	b	0xe99c <_stogir.vector-arithmetic.operands+0x3e0>
    e97c:      	uxtb	w16, w11
    e980:      	cmp	w16, wzr
    e984:      	b.eq	0xea84 <_stogir.vector-arithmetic.operands+0x4c8>
    e988:      	mov	x15, #0x1               ; =1
    e98c:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x214>
    e990:      	mov	x1, x14
    e994:      	mov	x2, x15
    e998:      	mov	x0, #0x1                ; =1
    e99c:      	cmp	x0, #0x0
    e9a0:      	b.eq	0xe9b4 <_stogir.vector-arithmetic.operands+0x3f8>
    e9a4:      	cmp	x22, #0x1d
    e9a8:      	b.ne	0xeaf4 <_stogir.vector-arithmetic.operands+0x538>
    e9ac:      	mov	x0, #0x1                ; =1
    e9b0:      	b	0xeb00 <_stogir.vector-arithmetic.operands+0x544>
    e9b4:      	mov	x21, x1
    e9b8:      	mov	x22, x2
    e9bc:      	cmp	x22, #0x0
    e9c0:      	b.ne	0xe9f0 <_stogir.vector-arithmetic.operands+0x434>
    e9c4:      	cmp	x22, #0x0
    e9c8:      	b.eq	0xea70 <_stogir.vector-arithmetic.operands+0x4b4>
    e9cc:      	lsr	x0, x22, #0
    e9d0:      	mov	x1, x19
    e9d4:      	mov	x2, x0
    e9d8:      	mov	x0, x21
    e9dc:      	bl	0xe9dc <_stogir.vector-arithmetic.operands+0x420>
		000000000000e9dc:  ARM64_RELOC_BRANCH26	_memcmp
    e9e0:      	lsr	w0, w0, #0
    e9e4:      	sxtw	x0, w0
    e9e8:      	cmp	x0, #0x0
    e9ec:      	b.eq	0xea70 <_stogir.vector-arithmetic.operands+0x4b4>
    e9f0:      	mov	x1, x21
    e9f4:      	mov	x2, x22
    e9f8:      	mov	x0, #0x1                ; =1
    e9fc:      	str	x0, [x20]
    ea00:      	str	x1, [x20, #0x8]
    ea04:      	str	x2, [x20, #0x10]
    ea08:      	ldr	x19, [sp, #0x58]
    ea0c:      	ldr	x20, [sp, #0x60]
    ea10:      	ldr	x21, [sp, #0x68]
    ea14:      	ldr	x22, [sp, #0x70]
    ea18:      	ldr	x23, [sp, #0x78]
    ea1c:      	ldr	x24, [sp, #0x80]
    ea20:      	ldr	x25, [sp, #0x88]
    ea24:      	ldr	x26, [sp, #0x90]
    ea28:      	ldr	x27, [sp, #0x98]
    ea2c:      	ldr	x28, [sp, #0xa0]
    ea30:      	ldr	x29, [sp]
    ea34:      	ldr	x30, [sp, #0x8]
    ea38:      	add	sp, sp, #0xb0
    ea3c:      	ret
    ea40:      	mov	x22, x1
    ea44:      	mov	x25, x2
    ea48:      	mov	x0, #0x1                ; =1
    ea4c:      	cmp	x0, #0x0
    ea50:      	b.eq	0xea98 <_stogir.vector-arithmetic.operands+0x4dc>
    ea54:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000ea54:  ARM64_RELOC_PAGE21	l_stogir.498
    ea58:      	ldr	x16, [x16]
		000000000000ea58:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    ea5c:      	orr	x0, x16, xzr
    ea60:      	mov	x1, #0x23               ; =35
    ea64:      	mov	x21, x0
    ea68:      	mov	x22, x1
    ea6c:      	b	0xe9bc <_stogir.vector-arithmetic.operands+0x400>
    ea70:      	and	x0, x23, #0xffffffff
    ea74:      	mov	x1, x0
    ea78:      	movz	x0, #0x0, lsl #48
    ea7c:      	movz	x2, #0x0, lsl #48
    ea80:      	b	0xe9fc <_stogir.vector-arithmetic.operands+0x440>
    ea84:      	uxtb	w16, w12
    ea88:      	cmp	w16, wzr
    ea8c:      	b.eq	0xe7cc <_stogir.vector-arithmetic.operands+0x210>
    ea90:      	mov	x15, #0x1               ; =1
    ea94:      	b	0xe7d0 <_stogir.vector-arithmetic.operands+0x214>
    ea98:      	lsr	w26, w26, #0
    ea9c:      	add	x8, sp, #0x10
    eaa0:      	mov	x0, x21
    eaa4:      	mov	w1, w26
    eaa8:      	bl	0xeaa8 <_stogir.vector-arithmetic.operands+0x4ec>
		000000000000eaa8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    eaac:      	add	x16, sp, #0x10
    eab0:      	ldr	w0, [x16]
    eab4:      	lsr	x16, x0, #0
    eab8:      	cmp	x16, #0x1
    eabc:      	b.eq	0xead8 <_stogir.vector-arithmetic.operands+0x51c>
    eac0:      	b.lo	0xeac8 <_stogir.vector-arithmetic.operands+0x50c>
    eac4:      	b	0xeadc <_stogir.vector-arithmetic.operands+0x520>
    eac8:      	cmp	x16, #0x0
    eacc:      	b.eq	0xead4 <_stogir.vector-arithmetic.operands+0x518>
    ead0:      	b	0xeadc <_stogir.vector-arithmetic.operands+0x520>
    ead4:      	b	0xeae0 <_stogir.vector-arithmetic.operands+0x524>
    ead8:      	b	0xeb2c <_stogir.vector-arithmetic.operands+0x570>
    eadc:      	b	0xebdc <_stogir.vector-arithmetic.operands+0x620>
    eae0:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000eae0:  ARM64_RELOC_PAGE21	l_stogir.499
    eae4:      	ldr	x16, [x16]
		000000000000eae4:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    eae8:      	orr	x0, x16, xzr
    eaec:      	mov	x1, #0x1d               ; =29
    eaf0:      	b	0xeb20 <_stogir.vector-arithmetic.operands+0x564>
    eaf4:      	cmp	x22, #0x1e
    eaf8:      	cset	w0, eq
    eafc:      	ubfx	x0, x0, #0, #8
    eb00:      	cmp	x0, #0x0
    eb04:      	b.eq	0xea40 <_stogir.vector-arithmetic.operands+0x484>
    eb08:      	mov	x22, x1
    eb0c:      	mov	x25, x2
    eb10:      	movz	x0, #0x0, lsl #48
    eb14:      	b	0xea4c <_stogir.vector-arithmetic.operands+0x490>
    eb18:      	mov	x0, x1
    eb1c:      	mov	x1, x2
    eb20:      	b	0xea64 <_stogir.vector-arithmetic.operands+0x4a8>
    eb24:      	brk	#0
    eb28:      	b	0xeb24 <_stogir.vector-arithmetic.operands+0x568>
    eb2c:      	add	x16, sp, #0x10
    eb30:      	ldr	x0, [x16, #0x8]
    eb34:      	cmp	x24, #0x0
    eb38:      	b.gt	0xeb74 <_stogir.vector-arithmetic.operands+0x5b8>
    eb3c:      	mov	x1, x22
    eb40:      	mov	x2, x25
    eb44:      	mov	x0, #0x1                ; =1
    eb48:      	b	0xeb58 <_stogir.vector-arithmetic.operands+0x59c>
    eb4c:      	movz	x0, #0x0, lsl #48
    eb50:      	mov	x1, x22
    eb54:      	mov	x2, x25
    eb58:      	cmp	x0, #0x0
    eb5c:      	b.eq	0xeb18 <_stogir.vector-arithmetic.operands+0x55c>
    eb60:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000eb60:  ARM64_RELOC_PAGE21	l_stogir.500
    eb64:      	ldr	x16, [x16]
		000000000000eb64:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    eb68:      	orr	x0, x16, xzr
    eb6c:      	mov	x1, #0x34               ; =52
    eb70:      	b	0xeb20 <_stogir.vector-arithmetic.operands+0x564>
    eb74:      	uxtb	w0, w0
    eb78:      	cmp	x0, #0x83
    eb7c:      	b.ge	0xeb98 <_stogir.vector-arithmetic.operands+0x5dc>
    eb80:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000eb80:  ARM64_RELOC_PAGE21	l_stogir.501
    eb84:      	ldr	x16, [x16]
		000000000000eb84:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    eb88:      	orr	x1, x16, xzr
    eb8c:      	add	x1, x0, x1
    eb90:      	ldrb	w1, [x1]
    eb94:      	b	0xeb9c <_stogir.vector-arithmetic.operands+0x5e0>
    eb98:      	movz	x1, #0x0, lsl #48
    eb9c:      	uxtb	w1, w1
    eba0:      	and	x1, x1, #0x2
    eba4:      	uxtb	w1, w1
    eba8:      	cmp	x1, #0x0
    ebac:      	cset	w1, eq
    ebb0:      	uxtb	w16, w1
    ebb4:      	cmp	w16, wzr
    ebb8:      	cset	x1, eq
    ebbc:      	cmp	x1, #0x0
    ebc0:      	b.ne	0xeb4c <_stogir.vector-arithmetic.operands+0x590>
    ebc4:      	cmp	x0, #0x65
    ebc8:      	b.eq	0xeb4c <_stogir.vector-arithmetic.operands+0x590>
    ebcc:      	cmp	x0, #0x66
    ebd0:      	b.eq	0xeb4c <_stogir.vector-arithmetic.operands+0x590>
    ebd4:      	mov	x0, #0x1                ; =1
    ebd8:      	b	0xeb50 <_stogir.vector-arithmetic.operands+0x594>
    ebdc:      	brk	#0
    ebe0:      	b	0xebdc <_stogir.vector-arithmetic.operands+0x620>
    ebe4:      	str	x2, [sp, #0x48]
    ebe8:      	b	0xe890 <_stogir.vector-arithmetic.operands+0x2d4>
    ebec:      	str	x2, [sp, #0x48]
    ebf0:      	b	0xe6e4 <_stogir.vector-arithmetic.operands+0x128>
    ebf4:      	str	x2, [sp, #0x48]
    ebf8:      	b	0xe6d4 <_stogir.vector-arithmetic.operands+0x118>
    ebfc:      	str	x3, [sp, #0x50]
    ec00:      	b	0xe6f0 <_stogir.vector-arithmetic.operands+0x134>

000000000000ec04 <_stogir.types.base-type>:
    ec04:      	sub	sp, sp, #0x20
    ec08:      	str	x29, [sp]
    ec0c:      	str	x30, [sp, #0x8]
    ec10:      	mov	x29, sp
    ec14:      	str	x19, [sp, #0x10]
    ec18:      	lsr	w0, w0, #0
    ec1c:      	mov	w19, w0
    ec20:      	bl	0xec20 <_stogir.types.base-type+0x1c>
		000000000000ec20:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ec24:      	cmp	x0, #0x0
    ec28:      	b.eq	0xec40 <_stogir.types.base-type+0x3c>
    ec2c:      	sxtw	x19, w19
    ec30:      	and	x0, x19, #0xf
    ec34:      	lsr	w0, w0, #0
    ec38:      	sxtw	x0, w0
    ec3c:      	b	0xec44 <_stogir.types.base-type+0x40>
    ec40:      	movn	x0, #0x0, lsl #48
    ec44:      	ldr	x19, [sp, #0x10]
    ec48:      	ldr	x29, [sp]
    ec4c:      	ldr	x30, [sp, #0x8]
    ec50:      	add	sp, sp, #0x20
    ec54:      	ret

000000000000ec58 <_stogir.types.lanes>:
    ec58:      	sxtw	x0, w0
    ec5c:      	cmp	x0, #0xf
    ec60:      	b.le	0xecb0 <_stogir.types.lanes+0x58>
    ec64:      	cmp	x0, #0x80
    ec68:      	b.ge	0xecb0 <_stogir.types.lanes+0x58>
    ec6c:      	and	x1, x0, #0xf
    ec70:      	lsr	w1, w1, #0
    ec74:      	sxtw	x1, w1
    ec78:      	cmp	x1, #0x1
    ec7c:      	b.lt	0xecb0 <_stogir.types.lanes+0x58>
    ec80:      	cmp	x1, #0xd
    ec84:      	b.gt	0xecb0 <_stogir.types.lanes+0x58>
    ec88:      	ubfx	x0, x0, #4, #32
    ec8c:      	sxtw	x0, w0
    ec90:      	sub	x0, x0, #0x1
    ec94:      	lsr	w0, w0, #0
    ec98:      	sxtw	x0, w0
    ec9c:      	mov	x16, #0x1               ; =1
    eca0:      	lsl	x0, x16, x0
    eca4:      	lsr	w0, w0, #0
    eca8:      	sxtw	x0, w0
    ecac:      	b	0xecdc <_stogir.types.lanes+0x84>
    ecb0:      	cmp	x0, #0x0
    ecb4:      	b.lt	0xecd8 <_stogir.types.lanes+0x80>
    ecb8:      	cmp	x0, #0xd
    ecbc:      	b.gt	0xecd8 <_stogir.types.lanes+0x80>
    ecc0:      	cmp	x0, #0x0
    ecc4:      	cset	w0, eq
    ecc8:      	uxtb	w16, w0
    eccc:      	cmp	w16, wzr
    ecd0:      	cset	x0, eq
    ecd4:      	b	0xecdc <_stogir.types.lanes+0x84>
    ecd8:      	movn	x0, #0x0, lsl #48
    ecdc:      	ret

000000000000ece0 <_coil.core.Get$slice$get__u8>:
    ece0:      	lsr	x1, x2, #0
    ece4:      	add	x0, x1, x0
    ece8:      	ldrb	w0, [x0]
    ecec:      	ret

000000000000ecf0 <_stogir.checked.valid-type?>:
    ecf0:      	sxtw	x0, w0
    ecf4:      	cmp	x0, #0x1
    ecf8:      	b.lt	0xed1c <_stogir.checked.valid-type?+0x2c>
    ecfc:      	cmp	x0, #0xb
    ed00:      	b.gt	0xed1c <_stogir.checked.valid-type?+0x2c>
    ed04:      	cmp	x0, #0x1
    ed08:      	cset	w0, eq
    ed0c:      	uxtb	w16, w0
    ed10:      	cmp	w16, wzr
    ed14:      	cset	x0, eq
    ed18:      	b	0xed20 <_stogir.checked.valid-type?+0x30>
    ed1c:      	movz	x0, #0x0, lsl #48
    ed20:      	ret

000000000000ed24 <_coil.core.Iterable$slice$iter__i32>:
    ed24:      	str	x0, [x8]
    ed28:      	str	x1, [x8, #0x8]
    ed2c:      	movz	x17, #0x0, lsl #48
    ed30:      	str	x17, [x8, #0x10]
    ed34:      	ret

000000000000ed38 <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    ed38:      	sub	sp, sp, #0x10
    ed3c:      	mov	x1, sp
    ed40:      	ldr	x2, [x0, #0x10]
    ed44:      	ldr	x3, [x0]
    ed48:      	ldr	x4, [x0, #0x8]
    ed4c:      	cmp	x2, x4
    ed50:      	b.ge	0xed7c <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    ed54:      	add	x4, x2, #0x1
    ed58:      	lsl	x2, x2, #2
    ed5c:      	add	x2, x2, x3
    ed60:      	str	x4, [x0, #0x10]
    ed64:      	ldr	w0, [x2]
    ed68:      	sxtw	x0, w0
    ed6c:      	and	x0, x0, #0xffffffff
    ed70:      	mov	x2, x0
    ed74:      	mov	x0, #0x1                ; =1
    ed78:      	b	0xed84 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    ed7c:      	movz	x0, #0x0, lsl #48
    ed80:      	movz	x2, #0x0, lsl #48
    ed84:      	str	x0, [x1]
    ed88:      	str	x2, [x1, #0x8]
    ed8c:      	ldr	x0, [sp]
    ed90:      	ldr	x1, [sp, #0x8]
    ed94:      	add	sp, sp, #0x10
    ed98:      	ret

000000000000ed9c <_stogir.terminal.previous-input>:
    ed9c:      	sxtw	x1, w1
    eda0:      	cmp	x1, #0x0
    eda4:      	b.ne	0xedc4 <_stogir.terminal.previous-input+0x28>
    eda8:      	movz	x0, #0x0, lsl #48
    edac:      	movz	x1, #0x0, lsl #48
    edb0:      	movz	x2, #0x0, lsl #48
    edb4:      	str	x0, [x8]
    edb8:      	str	x1, [x8, #0x8]
    edbc:      	str	x2, [x8, #0x10]
    edc0:      	ret
    edc4:      	cmp	x1, #0x0
    edc8:      	cset	w2, gt
    edcc:      	movz	x16, #0x0, lsl #48
    edd0:      	sub	x3, x16, x1
    edd4:      	sub	x4, x3, #0x1
    edd8:      	uxtb	w16, w2
    eddc:      	cmp	w16, wzr
    ede0:      	b.eq	0xee40 <_stogir.terminal.previous-input+0xa4>
    ede4:      	ldr	x3, [x0, #0x8]
    ede8:      	cmp	x1, x3
    edec:      	b.ge	0xee8c <_stogir.terminal.previous-input+0xf0>
    edf0:      	add	x3, x0, #0x78
    edf4:      	ldr	x3, [x3, #0x8]
    edf8:      	cmp	x1, x3
    edfc:      	b.ge	0xef64 <_stogir.terminal.previous-input+0x1c8>
    ee00:      	lsl	x3, x1, #2
    ee04:      	ldr	x5, [x0, #0x78]
    ee08:      	add	x3, x3, x5
    ee0c:      	ldr	w3, [x3]
    ee10:      	sxtw	x3, w3
    ee14:      	cmp	x3, #0x0
    ee18:      	cset	w3, ge
    ee1c:      	ubfx	x3, x3, #0, #8
    ee20:      	b	0xef68 <_stogir.terminal.previous-input+0x1cc>
    ee24:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000ee24:  ARM64_RELOC_PAGE21	l_stogir.502
    ee28:      	ldr	x16, [x16]
		000000000000ee28:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    ee2c:      	orr	x0, x16, xzr
    ee30:      	mov	x1, x0
    ee34:      	mov	x0, #0x1                ; =1
    ee38:      	mov	x2, #0x2e               ; =46
    ee3c:      	b	0xedb4 <_stogir.terminal.previous-input+0x18>
    ee40:      	cmp	x1, #0x0
    ee44:      	b.ge	0xee94 <_stogir.terminal.previous-input+0xf8>
    ee48:      	add	x5, x0, #0x28
    ee4c:      	add	x6, x0, #0x50
    ee50:      	ldr	x5, [x5, #0x8]
    ee54:      	ldr	x6, [x6, #0x8]
    ee58:      	cmp	x5, x6
    ee5c:      	b.ne	0xef5c <_stogir.terminal.previous-input+0x1c0>
    ee60:      	cmp	x3, x5
    ee64:      	b.gt	0xef6c <_stogir.terminal.previous-input+0x1d0>
    ee68:      	lsl	x3, x4, #2
    ee6c:      	ldr	x5, [x0, #0x50]
    ee70:      	add	x3, x3, x5
    ee74:      	ldr	w3, [x3]
    ee78:      	sxtw	x3, w3
    ee7c:      	cmp	x3, #0x0
    ee80:      	cset	w3, gt
    ee84:      	ubfx	x3, x3, #0, #8
    ee88:      	b	0xef70 <_stogir.terminal.previous-input+0x1d4>
    ee8c:      	movz	x3, #0x0, lsl #48
    ee90:      	b	0xee98 <_stogir.terminal.previous-input+0xfc>
    ee94:      	movz	x3, #0x0, lsl #48
    ee98:      	cmp	x3, #0x0
    ee9c:      	b.eq	0xeedc <_stogir.terminal.previous-input+0x140>
    eea0:      	uxtb	w16, w2
    eea4:      	cmp	w16, wzr
    eea8:      	b.eq	0xeec0 <_stogir.terminal.previous-input+0x124>
    eeac:      	lsl	x2, x1, #4
    eeb0:      	ldr	x0, [x0]
    eeb4:      	add	x0, x2, x0
    eeb8:      	ldr	x0, [x0]
    eebc:      	b	0xeed0 <_stogir.terminal.previous-input+0x134>
    eec0:      	lsl	x2, x4, #4
    eec4:      	ldr	x0, [x0, #0x28]
    eec8:      	add	x0, x2, x0
    eecc:      	ldr	x0, [x0]
    eed0:      	mov	x2, x0
    eed4:      	mov	x0, #0x1                ; =1
    eed8:      	b	0xeee4 <_stogir.terminal.previous-input+0x148>
    eedc:      	movz	x0, #0x0, lsl #48
    eee0:      	movz	x2, #0x0, lsl #48
    eee4:      	lsr	w0, w0, #0
    eee8:      	lsr	x16, x0, #0
    eeec:      	cmp	x16, #0x1
    eef0:      	b.eq	0xef0c <_stogir.terminal.previous-input+0x170>
    eef4:      	b.lo	0xeefc <_stogir.terminal.previous-input+0x160>
    eef8:      	b	0xef10 <_stogir.terminal.previous-input+0x174>
    eefc:      	cmp	x16, #0x0
    ef00:      	b.eq	0xef08 <_stogir.terminal.previous-input+0x16c>
    ef04:      	b	0xef10 <_stogir.terminal.previous-input+0x174>
    ef08:      	b	0xef14 <_stogir.terminal.previous-input+0x178>
    ef0c:      	b	0xef30 <_stogir.terminal.previous-input+0x194>
    ef10:      	b	0xefb4 <_stogir.terminal.previous-input+0x218>
    ef14:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000ef14:  ARM64_RELOC_PAGE21	l_stogir.503
    ef18:      	ldr	x16, [x16]
		000000000000ef18:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    ef1c:      	orr	x0, x16, xzr
    ef20:      	mov	x1, x0
    ef24:      	mov	x0, #0x1                ; =1
    ef28:      	mov	x2, #0x1d               ; =29
    ef2c:      	b	0xee3c <_stogir.terminal.previous-input+0xa0>
    ef30:      	cmp	x1, #0x0
    ef34:      	b.le	0xee24 <_stogir.terminal.previous-input+0x88>
    ef38:      	uxtb	w2, w2
    ef3c:      	cmp	x2, #0x83
    ef40:      	b.ge	0xef74 <_stogir.terminal.previous-input+0x1d8>
    ef44:      	adrp	x16, 0xe000 <_stogir.vector-comparison.operands+0xd4>
		000000000000ef44:  ARM64_RELOC_PAGE21	l_stogir.504
    ef48:      	ldr	x16, [x16]
		000000000000ef48:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    ef4c:      	orr	x0, x16, xzr
    ef50:      	add	x0, x2, x0
    ef54:      	ldrb	w0, [x0]
    ef58:      	b	0xef78 <_stogir.terminal.previous-input+0x1dc>
    ef5c:      	movz	x3, #0x0, lsl #48
    ef60:      	b	0xee98 <_stogir.terminal.previous-input+0xfc>
    ef64:      	movz	x3, #0x0, lsl #48
    ef68:      	b	0xee90 <_stogir.terminal.previous-input+0xf4>
    ef6c:      	movz	x3, #0x0, lsl #48
    ef70:      	b	0xef60 <_stogir.terminal.previous-input+0x1c4>
    ef74:      	movz	x0, #0x0, lsl #48
    ef78:      	uxtb	w0, w0
    ef7c:      	and	x0, x0, #0x8
    ef80:      	uxtb	w0, w0
    ef84:      	cmp	x0, #0x0
    ef88:      	cset	w0, eq
    ef8c:      	uxtb	w16, w0
    ef90:      	cmp	w16, wzr
    ef94:      	cset	x0, eq
    ef98:      	cmp	x0, #0x0
    ef9c:      	b.eq	0xee24 <_stogir.terminal.previous-input+0x88>
    efa0:      	and	x0, x1, #0xffffffff
    efa4:      	mov	x1, x0
    efa8:      	movz	x0, #0x0, lsl #48
    efac:      	movz	x2, #0x0, lsl #48
    efb0:      	b	0xee3c <_stogir.terminal.previous-input+0xa0>
    efb4:      	brk	#0
    efb8:      	b	0xefb4 <_stogir.terminal.previous-input+0x218>

000000000000efbc <_stogir.switch.selector-type>:
    efbc:      	sxtw	x1, w1
    efc0:      	cmp	x1, #0x0
    efc4:      	cset	w2, gt
    efc8:      	movz	x16, #0x0, lsl #48
    efcc:      	sub	x3, x16, x1
    efd0:      	sub	x4, x3, #0x1
    efd4:      	uxtb	w16, w2
    efd8:      	cmp	w16, wzr
    efdc:      	b.eq	0xf020 <_stogir.switch.selector-type+0x64>
    efe0:      	ldr	x3, [x0, #0x8]
    efe4:      	cmp	x1, x3
    efe8:      	b.ge	0xf074 <_stogir.switch.selector-type+0xb8>
    efec:      	add	x3, x0, #0x78
    eff0:      	ldr	x3, [x3, #0x8]
    eff4:      	cmp	x1, x3
    eff8:      	b.ge	0xf178 <_stogir.switch.selector-type+0x1bc>
    effc:      	lsl	x3, x1, #2
    f000:      	ldr	x5, [x0, #0x78]
    f004:      	add	x3, x3, x5
    f008:      	ldr	w3, [x3]
    f00c:      	sxtw	x3, w3
    f010:      	cmp	x3, #0x0
    f014:      	cset	w3, ge
    f018:      	ubfx	x3, x3, #0, #8
    f01c:      	b	0xf17c <_stogir.switch.selector-type+0x1c0>
    f020:      	cmp	x1, #0x0
    f024:      	b.ge	0xf07c <_stogir.switch.selector-type+0xc0>
    f028:      	add	x5, x0, #0x28
    f02c:      	add	x6, x0, #0x50
    f030:      	ldr	x5, [x5, #0x8]
    f034:      	ldr	x6, [x6, #0x8]
    f038:      	cmp	x5, x6
    f03c:      	b.ne	0xf06c <_stogir.switch.selector-type+0xb0>
    f040:      	cmp	x3, x5
    f044:      	b.gt	0xf180 <_stogir.switch.selector-type+0x1c4>
    f048:      	lsl	x3, x4, #2
    f04c:      	ldr	x5, [x0, #0x50]
    f050:      	add	x3, x3, x5
    f054:      	ldr	w3, [x3]
    f058:      	sxtw	x3, w3
    f05c:      	cmp	x3, #0x0
    f060:      	cset	w3, gt
    f064:      	ubfx	x3, x3, #0, #8
    f068:      	b	0xf184 <_stogir.switch.selector-type+0x1c8>
    f06c:      	movz	x3, #0x0, lsl #48
    f070:      	b	0xf080 <_stogir.switch.selector-type+0xc4>
    f074:      	movz	x3, #0x0, lsl #48
    f078:      	b	0xf080 <_stogir.switch.selector-type+0xc4>
    f07c:      	movz	x3, #0x0, lsl #48
    f080:      	cmp	x3, #0x0
    f084:      	b.eq	0xf0c4 <_stogir.switch.selector-type+0x108>
    f088:      	uxtb	w16, w2
    f08c:      	cmp	w16, wzr
    f090:      	b.eq	0xf0a8 <_stogir.switch.selector-type+0xec>
    f094:      	lsl	x1, x1, #4
    f098:      	ldr	x0, [x0]
    f09c:      	add	x0, x1, x0
    f0a0:      	ldr	x0, [x0]
    f0a4:      	b	0xf0b8 <_stogir.switch.selector-type+0xfc>
    f0a8:      	lsl	x1, x4, #4
    f0ac:      	ldr	x0, [x0, #0x28]
    f0b0:      	add	x0, x1, x0
    f0b4:      	ldr	x0, [x0]
    f0b8:      	mov	x1, x0
    f0bc:      	mov	x0, #0x1                ; =1
    f0c0:      	b	0xf0cc <_stogir.switch.selector-type+0x110>
    f0c4:      	movz	x0, #0x0, lsl #48
    f0c8:      	movz	x1, #0x0, lsl #48
    f0cc:      	lsr	w0, w0, #0
    f0d0:      	lsr	x16, x0, #0
    f0d4:      	cmp	x16, #0x1
    f0d8:      	b.eq	0xf0f4 <_stogir.switch.selector-type+0x138>
    f0dc:      	b.lo	0xf0e4 <_stogir.switch.selector-type+0x128>
    f0e0:      	b	0xf0f8 <_stogir.switch.selector-type+0x13c>
    f0e4:      	cmp	x16, #0x0
    f0e8:      	b.eq	0xf0f0 <_stogir.switch.selector-type+0x134>
    f0ec:      	b	0xf0f8 <_stogir.switch.selector-type+0x13c>
    f0f0:      	b	0xf0fc <_stogir.switch.selector-type+0x140>
    f0f4:      	b	0xf140 <_stogir.switch.selector-type+0x184>
    f0f8:      	b	0xf188 <_stogir.switch.selector-type+0x1cc>
    f0fc:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000f0fc:  ARM64_RELOC_PAGE21	l_stogir.505
    f100:      	ldr	x16, [x16]
		000000000000f100:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    f104:      	orr	x0, x16, xzr
    f108:      	mov	x1, x0
    f10c:      	mov	x0, #0x1                ; =1
    f110:      	mov	x2, #0x17               ; =23
    f114:      	b	0xf130 <_stogir.switch.selector-type+0x174>
    f118:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000f118:  ARM64_RELOC_PAGE21	l_stogir.506
    f11c:      	ldr	x16, [x16]
		000000000000f11c:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    f120:      	orr	x0, x16, xzr
    f124:      	mov	x1, x0
    f128:      	mov	x0, #0x1                ; =1
    f12c:      	mov	x2, #0x20               ; =32
    f130:      	str	x0, [x8]
    f134:      	str	x1, [x8, #0x8]
    f138:      	str	x2, [x8, #0x10]
    f13c:      	ret
    f140:      	lsr	w0, w1, #0
    f144:      	ubfx	x0, x0, #8, #8
    f148:      	cmp	x0, #0x1
    f14c:      	b.lt	0xf118 <_stogir.switch.selector-type+0x15c>
    f150:      	cmp	x0, #0xb
    f154:      	b.gt	0xf118 <_stogir.switch.selector-type+0x15c>
    f158:      	uxtb	w1, w1
    f15c:      	cmp	x1, #0x48
    f160:      	b.eq	0xf118 <_stogir.switch.selector-type+0x15c>
    f164:      	and	x0, x0, #0xffffffff
    f168:      	mov	x1, x0
    f16c:      	movz	x0, #0x0, lsl #48
    f170:      	movz	x2, #0x0, lsl #48
    f174:      	b	0xf130 <_stogir.switch.selector-type+0x174>
    f178:      	movz	x3, #0x0, lsl #48
    f17c:      	b	0xf078 <_stogir.switch.selector-type+0xbc>
    f180:      	movz	x3, #0x0, lsl #48
    f184:      	b	0xf070 <_stogir.switch.selector-type+0xb4>
    f188:      	brk	#0
    f18c:      	b	0xf188 <_stogir.switch.selector-type+0x1cc>

000000000000f190 <_stogir.switch.key>:
    f190:      	sub	sp, sp, #0x30
    f194:      	str	x19, [sp]
    f198:      	str	x20, [sp, #0x8]
    f19c:      	str	x21, [sp, #0x10]
    f1a0:      	str	x22, [sp, #0x18]
    f1a4:      	str	x23, [sp, #0x20]
    f1a8:      	sxtw	x2, w2
    f1ac:      	cmp	x2, #0x1
    f1b0:      	b.lt	0xf22c <_stogir.switch.key+0x9c>
    f1b4:      	cmp	x2, #0xb
    f1b8:      	cset	w3, le
    f1bc:      	uxtb	w16, w3
    f1c0:      	cmp	w16, wzr
    f1c4:      	b.eq	0xf22c <_stogir.switch.key+0x9c>
    f1c8:      	sxtw	x1, w1
    f1cc:      	cmp	x1, #0x0
    f1d0:      	cset	w4, gt
    f1d4:      	movz	x16, #0x0, lsl #48
    f1d8:      	sub	x5, x16, x1
    f1dc:      	sub	x6, x5, #0x1
    f1e0:      	uxtb	w16, w4
    f1e4:      	cmp	w16, wzr
    f1e8:      	b.eq	0xf2b0 <_stogir.switch.key+0x120>
    f1ec:      	ldr	x5, [x0, #0x8]
    f1f0:      	cmp	x1, x5
    f1f4:      	b.ge	0xf2fc <_stogir.switch.key+0x16c>
    f1f8:      	add	x5, x0, #0x78
    f1fc:      	ldr	x5, [x5, #0x8]
    f200:      	cmp	x1, x5
    f204:      	b.ge	0xf468 <_stogir.switch.key+0x2d8>
    f208:      	lsl	x5, x1, #2
    f20c:      	ldr	x7, [x0, #0x78]
    f210:      	add	x5, x5, x7
    f214:      	ldr	w5, [x5]
    f218:      	sxtw	x5, w5
    f21c:      	cmp	x5, #0x0
    f220:      	cset	w5, ge
    f224:      	ubfx	x5, x5, #0, #8
    f228:      	b	0xf46c <_stogir.switch.key+0x2dc>
    f22c:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000f22c:  ARM64_RELOC_PAGE21	l_stogir.507
    f230:      	ldr	x16, [x16]
		000000000000f230:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    f234:      	orr	x0, x16, xzr
    f238:      	mov	x1, x0
    f23c:      	mov	x0, #0x1                ; =1
    f240:      	mov	x2, #0x24               ; =36
    f244:      	str	x0, [x8]
    f248:      	str	x1, [x8, #0x8]
    f24c:      	str	x2, [x8, #0x10]
    f250:      	ldr	x19, [sp]
    f254:      	ldr	x20, [sp, #0x8]
    f258:      	ldr	x21, [sp, #0x10]
    f25c:      	ldr	x22, [sp, #0x18]
    f260:      	ldr	x23, [sp, #0x20]
    f264:      	add	sp, sp, #0x30
    f268:      	ret
    f26c:      	mov	x23, #0x1               ; =1
    f270:      	cmp	x1, #0x0
    f274:      	b.ge	0xf294 <_stogir.switch.key+0x104>
    f278:      	lsr	w1, w4, #0
    f27c:      	uxtb	w4, w4
    f280:      	ubfx	x1, x1, #8, #8
    f284:      	cmp	x4, x1
    f288:      	b.eq	0xf510 <_stogir.switch.key+0x380>
    f28c:      	cmp	x4, #0x49
    f290:      	b.eq	0xf510 <_stogir.switch.key+0x380>
    f294:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000f294:  ARM64_RELOC_PAGE21	l_stogir.508
    f298:      	ldr	x16, [x16]
		000000000000f298:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    f29c:      	orr	x0, x16, xzr
    f2a0:      	mov	x1, x0
    f2a4:      	mov	x0, #0x1                ; =1
    f2a8:      	mov	x2, #0x30               ; =48
    f2ac:      	b	0xf244 <_stogir.switch.key+0xb4>
    f2b0:      	cmp	x1, #0x0
    f2b4:      	b.ge	0xf304 <_stogir.switch.key+0x174>
    f2b8:      	add	x7, x0, #0x28
    f2bc:      	add	x9, x0, #0x50
    f2c0:      	ldr	x7, [x7, #0x8]
    f2c4:      	ldr	x9, [x9, #0x8]
    f2c8:      	cmp	x7, x9
    f2cc:      	b.ne	0xf460 <_stogir.switch.key+0x2d0>
    f2d0:      	cmp	x5, x7
    f2d4:      	b.gt	0xf508 <_stogir.switch.key+0x378>
    f2d8:      	lsl	x5, x6, #2
    f2dc:      	ldr	x7, [x0, #0x50]
    f2e0:      	add	x5, x5, x7
    f2e4:      	ldr	w5, [x5]
    f2e8:      	sxtw	x5, w5
    f2ec:      	cmp	x5, #0x0
    f2f0:      	cset	w5, gt
    f2f4:      	ubfx	x5, x5, #0, #8
    f2f8:      	b	0xf50c <_stogir.switch.key+0x37c>
    f2fc:      	movz	x5, #0x0, lsl #48
    f300:      	b	0xf308 <_stogir.switch.key+0x178>
    f304:      	movz	x5, #0x0, lsl #48
    f308:      	cmp	x5, #0x0
    f30c:      	b.eq	0xf370 <_stogir.switch.key+0x1e0>
    f310:      	uxtb	w16, w4
    f314:      	cmp	w16, wzr
    f318:      	b.eq	0xf340 <_stogir.switch.key+0x1b0>
    f31c:      	lsl	x4, x1, #4
    f320:      	ldr	x0, [x0]
    f324:      	add	x0, x4, x0
    f328:      	ldr	x4, [x0]
    f32c:      	ldr	x0, [x0, #0x8]
    f330:      	fmov	d31, x0
    f334:      	mov	x0, x4
    f338:      	fmov	x4, d31
    f33c:      	b	0xf360 <_stogir.switch.key+0x1d0>
    f340:      	lsl	x4, x6, #4
    f344:      	ldr	x0, [x0, #0x28]
    f348:      	add	x0, x4, x0
    f34c:      	ldr	x4, [x0]
    f350:      	ldr	x0, [x0, #0x8]
    f354:      	fmov	d31, x0
    f358:      	mov	x0, x4
    f35c:      	fmov	x4, d31
    f360:      	mov	x5, x4
    f364:      	mov	x4, x0
    f368:      	mov	x0, #0x1                ; =1
    f36c:      	b	0xf37c <_stogir.switch.key+0x1ec>
    f370:      	movz	x0, #0x0, lsl #48
    f374:      	movz	x4, #0x0, lsl #48
    f378:      	movz	x5, #0x0, lsl #48
    f37c:      	lsr	w0, w0, #0
    f380:      	lsr	x16, x0, #0
    f384:      	cmp	x16, #0x1
    f388:      	b.eq	0xf3a4 <_stogir.switch.key+0x214>
    f38c:      	b.lo	0xf394 <_stogir.switch.key+0x204>
    f390:      	b	0xf3a8 <_stogir.switch.key+0x218>
    f394:      	cmp	x16, #0x0
    f398:      	b.eq	0xf3a0 <_stogir.switch.key+0x210>
    f39c:      	b	0xf3a8 <_stogir.switch.key+0x218>
    f3a0:      	b	0xf3ac <_stogir.switch.key+0x21c>
    f3a4:      	b	0xf3c8 <_stogir.switch.key+0x238>
    f3a8:      	b	0xf5b4 <_stogir.switch.key+0x424>
    f3ac:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000f3ac:  ARM64_RELOC_PAGE21	l_stogir.509
    f3b0:      	ldr	x16, [x16]
		000000000000f3b0:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    f3b4:      	orr	x0, x16, xzr
    f3b8:      	mov	x1, x0
    f3bc:      	mov	x0, #0x1                ; =1
    f3c0:      	mov	x2, #0x1c               ; =28
    f3c4:      	b	0xf2ac <_stogir.switch.key+0x11c>
    f3c8:      	cmp	x2, #0x1
    f3cc:      	cset	w0, eq
    f3d0:      	cmp	x2, #0x0
    f3d4:      	cset	w6, eq
    f3d8:      	cmp	x2, #0x2
    f3dc:      	cset	w7, eq
    f3e0:      	cmp	x2, #0x7
    f3e4:      	cset	w9, eq
    f3e8:      	cmp	x2, #0x8
    f3ec:      	cset	w10, eq
    f3f0:      	cmp	x2, #0x3
    f3f4:      	cset	w11, eq
    f3f8:      	cmp	x2, #0x9
    f3fc:      	cset	w12, eq
    f400:      	cmp	x2, #0x4
    f404:      	cset	w13, eq
    f408:      	cmp	x2, #0xa
    f40c:      	cset	w14, eq
    f410:      	cmp	x2, #0xd
    f414:      	cset	w15, eq
    f418:      	cmp	x2, #0x5
    f41c:      	cset	w19, eq
    f420:      	cmp	x2, #0xb
    f424:      	cset	w20, eq
    f428:      	cmp	x2, #0xc
    f42c:      	cset	w21, eq
    f430:      	cmp	x2, #0x6
    f434:      	cset	w22, eq
    f438:      	uxtb	w16, w22
    f43c:      	cmp	w16, wzr
    f440:      	mov	x16, #0x8               ; =8
    f444:      	movn	x17, #0x0, lsl #48
    f448:      	csel	x22, x16, x17, ne
    f44c:      	uxtb	w16, w6
    f450:      	cmp	w16, wzr
    f454:      	b.eq	0xf470 <_stogir.switch.key+0x2e0>
    f458:      	movz	x23, #0x0, lsl #48
    f45c:      	b	0xf270 <_stogir.switch.key+0xe0>
    f460:      	movz	x5, #0x0, lsl #48
    f464:      	b	0xf308 <_stogir.switch.key+0x178>
    f468:      	movz	x5, #0x0, lsl #48
    f46c:      	b	0xf300 <_stogir.switch.key+0x170>
    f470:      	uxtb	w16, w0
    f474:      	cmp	w16, wzr
    f478:      	b.ne	0xf26c <_stogir.switch.key+0xdc>
    f47c:      	uxtb	w16, w7
    f480:      	cmp	w16, wzr
    f484:      	b.ne	0xf26c <_stogir.switch.key+0xdc>
    f488:      	uxtb	w16, w9
    f48c:      	cmp	w16, wzr
    f490:      	b.ne	0xf26c <_stogir.switch.key+0xdc>
    f494:      	uxtb	w16, w10
    f498:      	cmp	w16, wzr
    f49c:      	b.ne	0xf26c <_stogir.switch.key+0xdc>
    f4a0:      	uxtb	w16, w11
    f4a4:      	cmp	w16, wzr
    f4a8:      	b.ne	0xf5ac <_stogir.switch.key+0x41c>
    f4ac:      	uxtb	w16, w12
    f4b0:      	cmp	w16, wzr
    f4b4:      	b.ne	0xf5ac <_stogir.switch.key+0x41c>
    f4b8:      	uxtb	w16, w13
    f4bc:      	cmp	w16, wzr
    f4c0:      	b.ne	0xf684 <_stogir.switch.key+0x4f4>
    f4c4:      	uxtb	w16, w14
    f4c8:      	cmp	w16, wzr
    f4cc:      	b.ne	0xf684 <_stogir.switch.key+0x4f4>
    f4d0:      	uxtb	w16, w15
    f4d4:      	cmp	w16, wzr
    f4d8:      	b.ne	0xf684 <_stogir.switch.key+0x4f4>
    f4dc:      	uxtb	w16, w19
    f4e0:      	cmp	w16, wzr
    f4e4:      	b.ne	0xf68c <_stogir.switch.key+0x4fc>
    f4e8:      	uxtb	w16, w20
    f4ec:      	cmp	w16, wzr
    f4f0:      	b.ne	0xf68c <_stogir.switch.key+0x4fc>
    f4f4:      	uxtb	w16, w21
    f4f8:      	cmp	w16, wzr
    f4fc:      	b.ne	0xf68c <_stogir.switch.key+0x4fc>
    f500:      	mov	x23, x22
    f504:      	b	0xf690 <_stogir.switch.key+0x500>
    f508:      	movz	x5, #0x0, lsl #48
    f50c:      	b	0xf464 <_stogir.switch.key+0x2d4>
    f510:      	cmp	x1, x2
    f514:      	b.ne	0xf294 <_stogir.switch.key+0x104>
    f518:      	lsr	w23, w23, #0
    f51c:      	lsr	w1, w5, #0
    f520:      	sxtw	x23, w23
    f524:      	ubfx	x1, x1, #0, #32
    f528:      	lsr	x4, x5, #32
    f52c:      	lsl	x5, x23, #3
    f530:      	ubfx	x4, x4, #0, #32
    f534:      	lsr	w5, w5, #0
    f538:      	lsl	x4, x4, #32
    f53c:      	sxtw	x5, w5
    f540:      	orr	x1, x4, x1
    f544:      	cmp	x5, #0x40
    f548:      	b.ge	0xf558 <_stogir.switch.key+0x3c8>
    f54c:      	lsr	x4, x1, x5
    f550:      	cmp	x4, #0x0
    f554:      	b.ne	0xf294 <_stogir.switch.key+0x104>
    f558:      	uxtb	w16, w0
    f55c:      	cmp	w16, wzr
    f560:      	b.eq	0xf56c <_stogir.switch.key+0x3dc>
    f564:      	cmp	x1, #0x1
    f568:      	b.hi	0xf294 <_stogir.switch.key+0x104>
    f56c:      	cmp	x2, #0x7
    f570:      	b.lt	0xf594 <_stogir.switch.key+0x404>
    f574:      	uxtb	w16, w3
    f578:      	cmp	w16, wzr
    f57c:      	b.eq	0xf594 <_stogir.switch.key+0x404>
    f580:      	uxtb	w16, w6
    f584:      	cmp	w16, wzr
    f588:      	b.eq	0xf5ec <_stogir.switch.key+0x45c>
    f58c:      	movz	x0, #0x0, lsl #48
    f590:      	b	0xf5c0 <_stogir.switch.key+0x430>
    f594:      	movz	x0, #0x0, lsl #48
    f598:      	eor	x0, x0, x1
    f59c:      	mov	x1, x0
    f5a0:      	movz	x0, #0x0, lsl #48
    f5a4:      	movz	x2, #0x0, lsl #48
    f5a8:      	b	0xf2ac <_stogir.switch.key+0x11c>
    f5ac:      	mov	x23, #0x2               ; =2
    f5b0:      	b	0xf270 <_stogir.switch.key+0xe0>
    f5b4:      	brk	#0
    f5b8:      	b	0xf5b4 <_stogir.switch.key+0x424>
    f5bc:      	mov	x0, #0x1                ; =1
    f5c0:      	lsr	w0, w0, #0
    f5c4:      	sxtw	x0, w0
    f5c8:      	lsl	x0, x0, #3
    f5cc:      	lsr	w0, w0, #0
    f5d0:      	sxtw	x0, w0
    f5d4:      	sub	x0, x0, #0x1
    f5d8:      	lsr	w0, w0, #0
    f5dc:      	sxtw	x0, w0
    f5e0:      	mov	x16, #0x1               ; =1
    f5e4:      	lsl	x0, x16, x0
    f5e8:      	b	0xf598 <_stogir.switch.key+0x408>
    f5ec:      	uxtb	w16, w0
    f5f0:      	cmp	w16, wzr
    f5f4:      	b.ne	0xf5bc <_stogir.switch.key+0x42c>
    f5f8:      	uxtb	w16, w7
    f5fc:      	cmp	w16, wzr
    f600:      	b.ne	0xf5bc <_stogir.switch.key+0x42c>
    f604:      	uxtb	w16, w9
    f608:      	cmp	w16, wzr
    f60c:      	b.ne	0xf5bc <_stogir.switch.key+0x42c>
    f610:      	uxtb	w16, w10
    f614:      	cmp	w16, wzr
    f618:      	b.ne	0xf5bc <_stogir.switch.key+0x42c>
    f61c:      	uxtb	w16, w11
    f620:      	cmp	w16, wzr
    f624:      	b.ne	0xf694 <_stogir.switch.key+0x504>
    f628:      	uxtb	w16, w12
    f62c:      	cmp	w16, wzr
    f630:      	b.ne	0xf694 <_stogir.switch.key+0x504>
    f634:      	uxtb	w16, w13
    f638:      	cmp	w16, wzr
    f63c:      	b.ne	0xf69c <_stogir.switch.key+0x50c>
    f640:      	uxtb	w16, w14
    f644:      	cmp	w16, wzr
    f648:      	b.ne	0xf69c <_stogir.switch.key+0x50c>
    f64c:      	uxtb	w16, w15
    f650:      	cmp	w16, wzr
    f654:      	b.ne	0xf69c <_stogir.switch.key+0x50c>
    f658:      	uxtb	w16, w19
    f65c:      	cmp	w16, wzr
    f660:      	b.ne	0xf6a4 <_stogir.switch.key+0x514>
    f664:      	uxtb	w16, w20
    f668:      	cmp	w16, wzr
    f66c:      	b.ne	0xf6a4 <_stogir.switch.key+0x514>
    f670:      	uxtb	w16, w21
    f674:      	cmp	w16, wzr
    f678:      	b.ne	0xf6a4 <_stogir.switch.key+0x514>
    f67c:      	mov	x0, x22
    f680:      	b	0xf6a8 <_stogir.switch.key+0x518>
    f684:      	mov	x23, #0x4               ; =4
    f688:      	b	0xf5b0 <_stogir.switch.key+0x420>
    f68c:      	mov	x23, #0x8               ; =8
    f690:      	b	0xf688 <_stogir.switch.key+0x4f8>
    f694:      	mov	x0, #0x2                ; =2
    f698:      	b	0xf5c0 <_stogir.switch.key+0x430>
    f69c:      	mov	x0, #0x4                ; =4
    f6a0:      	b	0xf698 <_stogir.switch.key+0x508>
    f6a4:      	mov	x0, #0x8                ; =8
    f6a8:      	b	0xf6a0 <_stogir.switch.key+0x510>

000000000000f6ac <_stogir.stack.entry-allocation?>:
    f6ac:      	sub	sp, sp, #0x10
    f6b0:      	add	x2, x0, #0x78
    f6b4:      	add	x3, x0, #0x28
    f6b8:      	add	x4, x0, #0x50
    f6bc:      	add	x5, x0, #0x78
    f6c0:      	add	x6, x0, #0x28
    f6c4:      	add	x7, x0, #0x50
    f6c8:      	sxtw	x1, w1
    f6cc:      	mov	x9, x1
    f6d0:      	mov	x1, #0x1                ; =1
    f6d4:      	movz	x8, #0x0, lsl #48
    f6d8:      	b	0xf828 <_stogir.stack.entry-allocation?+0x17c>
    f6dc:      	movz	x12, #0x0, lsl #48
    f6e0:      	b	0xf758 <_stogir.stack.entry-allocation?+0xac>
    f6e4:      	movz	x10, #0x0, lsl #48
    f6e8:      	movz	x11, #0x0, lsl #48
    f6ec:      	lsr	w10, w10, #0
    f6f0:      	lsr	x16, x10, #0
    f6f4:      	cmp	x16, #0x1
    f6f8:      	b.eq	0xf714 <_stogir.stack.entry-allocation?+0x68>
    f6fc:      	b.lo	0xf704 <_stogir.stack.entry-allocation?+0x58>
    f700:      	b	0xf718 <_stogir.stack.entry-allocation?+0x6c>
    f704:      	cmp	x16, #0x0
    f708:      	b.eq	0xf710 <_stogir.stack.entry-allocation?+0x64>
    f70c:      	b	0xf718 <_stogir.stack.entry-allocation?+0x6c>
    f710:      	b	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f714:      	b	0xf71c <_stogir.stack.entry-allocation?+0x70>
    f718:      	b	0xfa74 <_stogir.stack.entry-allocation?+0x3c8>
    f71c:      	uxtb	w10, w11
    f720:      	lsr	w11, w11, #0
    f724:      	ubfx	x11, x11, #8, #8
    f728:      	cmp	x10, x11
    f72c:      	b.eq	0xfa64 <_stogir.stack.entry-allocation?+0x3b8>
    f730:      	cmp	x10, #0x49
    f734:      	b.eq	0xfa64 <_stogir.stack.entry-allocation?+0x3b8>
    f738:      	movz	x1, #0x0, lsl #48
    f73c:      	fmov	d31, x8
    f740:      	mov	x8, x9
    f744:      	fmov	x9, d31
    f748:      	b	0xf914 <_stogir.stack.entry-allocation?+0x268>
    f74c:      	movz	x12, #0x0, lsl #48
    f750:      	b	0xf760 <_stogir.stack.entry-allocation?+0xb4>
    f754:      	movz	x12, #0x0, lsl #48
    f758:      	b	0xf768 <_stogir.stack.entry-allocation?+0xbc>
    f75c:      	movz	x12, #0x0, lsl #48
    f760:      	b	0xf768 <_stogir.stack.entry-allocation?+0xbc>
    f764:      	movz	x12, #0x0, lsl #48
    f768:      	cmp	x12, #0x0
    f76c:      	b.eq	0xf7d0 <_stogir.stack.entry-allocation?+0x124>
    f770:      	uxtb	w16, w11
    f774:      	cmp	w16, wzr
    f778:      	b.eq	0xf7a0 <_stogir.stack.entry-allocation?+0xf4>
    f77c:      	lsl	x10, x10, #4
    f780:      	ldr	x11, [x0]
    f784:      	add	x10, x10, x11
    f788:      	ldr	x11, [x10]
    f78c:      	ldr	x10, [x10, #0x8]
    f790:      	fmov	d31, x10
    f794:      	mov	x10, x11
    f798:      	fmov	x11, d31
    f79c:      	b	0xf7c0 <_stogir.stack.entry-allocation?+0x114>
    f7a0:      	lsl	x10, x13, #4
    f7a4:      	ldr	x11, [x0, #0x28]
    f7a8:      	add	x10, x10, x11
    f7ac:      	ldr	x11, [x10]
    f7b0:      	ldr	x10, [x10, #0x8]
    f7b4:      	fmov	d31, x10
    f7b8:      	mov	x10, x11
    f7bc:      	fmov	x11, d31
    f7c0:      	mov	x12, x11
    f7c4:      	mov	x11, x10
    f7c8:      	mov	x10, #0x1               ; =1
    f7cc:      	b	0xf7dc <_stogir.stack.entry-allocation?+0x130>
    f7d0:      	movz	x10, #0x0, lsl #48
    f7d4:      	movz	x11, #0x0, lsl #48
    f7d8:      	movz	x12, #0x0, lsl #48
    f7dc:      	lsr	w10, w10, #0
    f7e0:      	lsr	x16, x10, #0
    f7e4:      	cmp	x16, #0x1
    f7e8:      	b.eq	0xf804 <_stogir.stack.entry-allocation?+0x158>
    f7ec:      	b.lo	0xf7f4 <_stogir.stack.entry-allocation?+0x148>
    f7f0:      	b	0xf808 <_stogir.stack.entry-allocation?+0x15c>
    f7f4:      	cmp	x16, #0x0
    f7f8:      	b.eq	0xf800 <_stogir.stack.entry-allocation?+0x154>
    f7fc:      	b	0xf808 <_stogir.stack.entry-allocation?+0x15c>
    f800:      	b	0xf80c <_stogir.stack.entry-allocation?+0x160>
    f804:      	b	0xf8e0 <_stogir.stack.entry-allocation?+0x234>
    f808:      	b	0xf9c0 <_stogir.stack.entry-allocation?+0x314>
    f80c:      	fmov	d31, x8
    f810:      	mov	x8, x9
    f814:      	fmov	x9, d31
    f818:      	movz	x1, #0x0, lsl #48
    f81c:      	fmov	d31, x8
    f820:      	mov	x8, x9
    f824:      	fmov	x9, d31
    f828:      	cmp	x1, #0x0
    f82c:      	b.eq	0xf9a4 <_stogir.stack.entry-allocation?+0x2f8>
    f830:      	cmp	x8, #0x0
    f834:      	b.ne	0xf9a4 <_stogir.stack.entry-allocation?+0x2f8>
    f838:      	lsr	w10, w9, #0
    f83c:      	sxtw	x10, w10
    f840:      	cmp	x10, #0x0
    f844:      	cset	w11, gt
    f848:      	movz	x16, #0x0, lsl #48
    f84c:      	sub	x12, x16, x10
    f850:      	sub	x13, x12, #0x1
    f854:      	uxtb	w16, w11
    f858:      	cmp	w16, wzr
    f85c:      	b.eq	0xf89c <_stogir.stack.entry-allocation?+0x1f0>
    f860:      	ldr	x12, [x0, #0x8]
    f864:      	cmp	x10, x12
    f868:      	b.ge	0xf75c <_stogir.stack.entry-allocation?+0xb0>
    f86c:      	ldr	x12, [x2, #0x8]
    f870:      	cmp	x10, x12
    f874:      	b.ge	0xf74c <_stogir.stack.entry-allocation?+0xa0>
    f878:      	lsl	x12, x10, #2
    f87c:      	ldr	x14, [x0, #0x78]
    f880:      	add	x12, x12, x14
    f884:      	ldr	w12, [x12]
    f888:      	sxtw	x12, w12
    f88c:      	cmp	x12, #0x0
    f890:      	cset	w12, ge
    f894:      	ubfx	x12, x12, #0, #8
    f898:      	b	0xf750 <_stogir.stack.entry-allocation?+0xa4>
    f89c:      	cmp	x10, #0x0
    f8a0:      	b.ge	0xf764 <_stogir.stack.entry-allocation?+0xb8>
    f8a4:      	ldr	x14, [x3, #0x8]
    f8a8:      	ldr	x15, [x4, #0x8]
    f8ac:      	cmp	x14, x15
    f8b0:      	b.ne	0xf754 <_stogir.stack.entry-allocation?+0xa8>
    f8b4:      	cmp	x12, x14
    f8b8:      	b.gt	0xf6dc <_stogir.stack.entry-allocation?+0x30>
    f8bc:      	lsl	x12, x13, #2
    f8c0:      	ldr	x14, [x0, #0x50]
    f8c4:      	add	x12, x12, x14
    f8c8:      	ldr	w12, [x12]
    f8cc:      	sxtw	x12, w12
    f8d0:      	cmp	x12, #0x0
    f8d4:      	cset	w12, gt
    f8d8:      	ubfx	x12, x12, #0, #8
    f8dc:      	b	0xf6e0 <_stogir.stack.entry-allocation?+0x34>
    f8e0:      	uxtb	w10, w11
    f8e4:      	asr	x13, x11, #32
    f8e8:      	mov	x16, sp
    f8ec:      	str	x11, [x16]
    f8f0:      	mov	x16, sp
    f8f4:      	str	x12, [x16, #0x8]
    f8f8:      	cmp	x10, #0x68
    f8fc:      	b.ne	0xf918 <_stogir.stack.entry-allocation?+0x26c>
    f900:      	cmp	x13, #0x0
    f904:      	cset	w1, eq
    f908:      	ubfx	x1, x1, #0, #8
    f90c:      	mov	x8, x9
    f910:      	mov	x9, #0x1                ; =1
    f914:      	b	0xf81c <_stogir.stack.entry-allocation?+0x170>
    f918:      	cmp	x9, #0x0
    f91c:      	b.le	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f920:      	cmp	x10, #0x51
    f924:      	b.ne	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f928:      	cmp	x13, #0x0
    f92c:      	b.le	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f930:      	cmp	x13, x9
    f934:      	b.ge	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f938:      	lsr	w12, w12, #0
    f93c:      	sxtw	x12, w12
    f940:      	cmp	x12, #0x0
    f944:      	b.ge	0xf738 <_stogir.stack.entry-allocation?+0x8c>
    f948:      	cmp	x12, #0x0
    f94c:      	cset	w10, gt
    f950:      	movz	x16, #0x0, lsl #48
    f954:      	sub	x11, x16, x12
    f958:      	sub	x13, x11, #0x1
    f95c:      	uxtb	w16, w10
    f960:      	cmp	w16, wzr
    f964:      	b.eq	0xfa18 <_stogir.stack.entry-allocation?+0x36c>
    f968:      	ldr	x11, [x0, #0x8]
    f96c:      	cmp	x12, x11
    f970:      	b.ge	0xfa10 <_stogir.stack.entry-allocation?+0x364>
    f974:      	ldr	x11, [x5, #0x8]
    f978:      	cmp	x12, x11
    f97c:      	b.ge	0xfa5c <_stogir.stack.entry-allocation?+0x3b0>
    f980:      	lsl	x11, x12, #2
    f984:      	ldr	x14, [x0, #0x78]
    f988:      	add	x11, x11, x14
    f98c:      	ldr	w11, [x11]
    f990:      	sxtw	x11, w11
    f994:      	cmp	x11, #0x0
    f998:      	cset	w11, ge
    f99c:      	ubfx	x11, x11, #0, #8
    f9a0:      	b	0xfa60 <_stogir.stack.entry-allocation?+0x3b4>
    f9a4:      	cmp	x1, #0x0
    f9a8:      	b.eq	0xf9b4 <_stogir.stack.entry-allocation?+0x308>
    f9ac:      	mov	x0, x8
    f9b0:      	b	0xf9b8 <_stogir.stack.entry-allocation?+0x30c>
    f9b4:      	movz	x0, #0x0, lsl #48
    f9b8:      	add	sp, sp, #0x10
    f9bc:      	ret
    f9c0:      	brk	#0
    f9c4:      	b	0xf9c0 <_stogir.stack.entry-allocation?+0x314>
    f9c8:      	lsl	x10, x13, #4
    f9cc:      	ldr	x11, [x0, #0x28]
    f9d0:      	add	x10, x10, x11
    f9d4:      	ldr	x10, [x10]
    f9d8:      	mov	x11, x10
    f9dc:      	mov	x10, #0x1               ; =1
    f9e0:      	b	0xf6ec <_stogir.stack.entry-allocation?+0x40>
    f9e4:      	movz	x11, #0x0, lsl #48
    f9e8:      	cmp	x11, #0x0
    f9ec:      	b.eq	0xf6e4 <_stogir.stack.entry-allocation?+0x38>
    f9f0:      	uxtb	w16, w10
    f9f4:      	cmp	w16, wzr
    f9f8:      	b.eq	0xf9c8 <_stogir.stack.entry-allocation?+0x31c>
    f9fc:      	lsl	x10, x12, #4
    fa00:      	ldr	x11, [x0]
    fa04:      	add	x10, x10, x11
    fa08:      	ldr	x10, [x10]
    fa0c:      	b	0xf9d8 <_stogir.stack.entry-allocation?+0x32c>
    fa10:      	movz	x11, #0x0, lsl #48
    fa14:      	b	0xf9e8 <_stogir.stack.entry-allocation?+0x33c>
    fa18:      	ldr	x14, [x6, #0x8]
    fa1c:      	ldr	x15, [x7, #0x8]
    fa20:      	cmp	x14, x15
    fa24:      	b.ne	0xf9e4 <_stogir.stack.entry-allocation?+0x338>
    fa28:      	cmp	x11, x14
    fa2c:      	b.gt	0xfa54 <_stogir.stack.entry-allocation?+0x3a8>
    fa30:      	lsl	x11, x13, #2
    fa34:      	ldr	x14, [x0, #0x50]
    fa38:      	add	x11, x11, x14
    fa3c:      	ldr	w11, [x11]
    fa40:      	sxtw	x11, w11
    fa44:      	cmp	x11, #0x0
    fa48:      	cset	w11, gt
    fa4c:      	ubfx	x11, x11, #0, #8
    fa50:      	b	0xfa58 <_stogir.stack.entry-allocation?+0x3ac>
    fa54:      	movz	x11, #0x0, lsl #48
    fa58:      	b	0xf9e8 <_stogir.stack.entry-allocation?+0x33c>
    fa5c:      	movz	x11, #0x0, lsl #48
    fa60:      	b	0xfa14 <_stogir.stack.entry-allocation?+0x368>
    fa64:      	mov	x16, sp
    fa68:      	ldr	w9, [x16, #0x4]
    fa6c:      	sxtw	x9, w9
    fa70:      	b	0xf73c <_stogir.stack.entry-allocation?+0x90>
    fa74:      	brk	#0
    fa78:      	b	0xfa74 <_stogir.stack.entry-allocation?+0x3c8>

000000000000fa7c <_stogir.stack.constant-size>:
    fa7c:      	sub	sp, sp, #0x10
    fa80:      	str	x29, [sp]
    fa84:      	str	x30, [sp, #0x8]
    fa88:      	mov	x29, sp
    fa8c:      	mov	x2, sp
    fa90:      	sxtw	x1, w1
    fa94:      	sub	sp, sp, #0x10
    fa98:      	mov	x3, sp
    fa9c:      	cmp	x1, #0x0
    faa0:      	cset	w4, gt
    faa4:      	movz	x16, #0x0, lsl #48
    faa8:      	sub	x5, x16, x1
    faac:      	sub	x6, x5, #0x1
    fab0:      	uxtb	w16, w4
    fab4:      	cmp	w16, wzr
    fab8:      	b.eq	0xfafc <_stogir.stack.constant-size+0x80>
    fabc:      	ldr	x5, [x0, #0x8]
    fac0:      	cmp	x1, x5
    fac4:      	b.ge	0xfb50 <_stogir.stack.constant-size+0xd4>
    fac8:      	add	x5, x0, #0x78
    facc:      	ldr	x5, [x5, #0x8]
    fad0:      	cmp	x1, x5
    fad4:      	b.ge	0xfcc4 <_stogir.stack.constant-size+0x248>
    fad8:      	lsl	x5, x1, #2
    fadc:      	ldr	x7, [x0, #0x78]
    fae0:      	add	x5, x5, x7
    fae4:      	ldr	w5, [x5]
    fae8:      	sxtw	x5, w5
    faec:      	cmp	x5, #0x0
    faf0:      	cset	w5, ge
    faf4:      	ubfx	x5, x5, #0, #8
    faf8:      	b	0xfcc8 <_stogir.stack.constant-size+0x24c>
    fafc:      	cmp	x1, #0x0
    fb00:      	b.ge	0xfb58 <_stogir.stack.constant-size+0xdc>
    fb04:      	add	x7, x0, #0x28
    fb08:      	add	x9, x0, #0x50
    fb0c:      	ldr	x7, [x7, #0x8]
    fb10:      	ldr	x9, [x9, #0x8]
    fb14:      	cmp	x7, x9
    fb18:      	b.ne	0xfb48 <_stogir.stack.constant-size+0xcc>
    fb1c:      	cmp	x5, x7
    fb20:      	b.gt	0xfd4c <_stogir.stack.constant-size+0x2d0>
    fb24:      	lsl	x5, x6, #2
    fb28:      	ldr	x7, [x0, #0x50]
    fb2c:      	add	x5, x5, x7
    fb30:      	ldr	w5, [x5]
    fb34:      	sxtw	x5, w5
    fb38:      	cmp	x5, #0x0
    fb3c:      	cset	w5, gt
    fb40:      	ubfx	x5, x5, #0, #8
    fb44:      	b	0xfd50 <_stogir.stack.constant-size+0x2d4>
    fb48:      	movz	x5, #0x0, lsl #48
    fb4c:      	b	0xfb5c <_stogir.stack.constant-size+0xe0>
    fb50:      	movz	x5, #0x0, lsl #48
    fb54:      	b	0xfb5c <_stogir.stack.constant-size+0xe0>
    fb58:      	movz	x5, #0x0, lsl #48
    fb5c:      	cmp	x5, #0x0
    fb60:      	b.eq	0xfbc4 <_stogir.stack.constant-size+0x148>
    fb64:      	uxtb	w16, w4
    fb68:      	cmp	w16, wzr
    fb6c:      	b.eq	0xfb94 <_stogir.stack.constant-size+0x118>
    fb70:      	lsl	x4, x1, #4
    fb74:      	ldr	x0, [x0]
    fb78:      	add	x0, x4, x0
    fb7c:      	ldr	x4, [x0]
    fb80:      	ldr	x0, [x0, #0x8]
    fb84:      	fmov	d31, x0
    fb88:      	mov	x0, x4
    fb8c:      	fmov	x4, d31
    fb90:      	b	0xfbb4 <_stogir.stack.constant-size+0x138>
    fb94:      	lsl	x4, x6, #4
    fb98:      	ldr	x0, [x0, #0x28]
    fb9c:      	add	x0, x4, x0
    fba0:      	ldr	x4, [x0]
    fba4:      	ldr	x0, [x0, #0x8]
    fba8:      	fmov	d31, x0
    fbac:      	mov	x0, x4
    fbb0:      	fmov	x4, d31
    fbb4:      	mov	x5, x4
    fbb8:      	mov	x4, x0
    fbbc:      	mov	x0, #0x1                ; =1
    fbc0:      	b	0xfbd0 <_stogir.stack.constant-size+0x154>
    fbc4:      	movz	x0, #0x0, lsl #48
    fbc8:      	movz	x4, #0x0, lsl #48
    fbcc:      	movz	x5, #0x0, lsl #48
    fbd0:      	lsr	w0, w0, #0
    fbd4:      	lsr	x16, x0, #0
    fbd8:      	cmp	x16, #0x1
    fbdc:      	b.eq	0xfbf8 <_stogir.stack.constant-size+0x17c>
    fbe0:      	b.lo	0xfbe8 <_stogir.stack.constant-size+0x16c>
    fbe4:      	b	0xfbfc <_stogir.stack.constant-size+0x180>
    fbe8:      	cmp	x16, #0x0
    fbec:      	b.eq	0xfbf4 <_stogir.stack.constant-size+0x178>
    fbf0:      	b	0xfbfc <_stogir.stack.constant-size+0x180>
    fbf4:      	b	0xfc00 <_stogir.stack.constant-size+0x184>
    fbf8:      	b	0xfca4 <_stogir.stack.constant-size+0x228>
    fbfc:      	b	0xfe04 <_stogir.stack.constant-size+0x388>
    fc00:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000fc00:  ARM64_RELOC_PAGE21	l_stogir.510
    fc04:      	ldr	x16, [x16]
		000000000000fc04:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    fc08:      	orr	x0, x16, xzr
    fc0c:      	mov	x1, x0
    fc10:      	mov	x0, #0x1                ; =1
    fc14:      	mov	x3, #0x18               ; =24
    fc18:      	b	0xfc80 <_stogir.stack.constant-size+0x204>
    fc1c:      	mov	x4, #0x1                ; =1
    fc20:      	ldr	w5, [x3, #0x8]
    fc24:      	ldr	w6, [x3, #0xc]
    fc28:      	cmp	x1, #0x0
    fc2c:      	b.ge	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fc30:      	cmp	x0, #0x1
    fc34:      	b.lt	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fc38:      	cmp	x0, #0xb
    fc3c:      	cset	w1, le
    fc40:      	uxtb	w16, w1
    fc44:      	cmp	w16, wzr
    fc48:      	b.eq	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fc4c:      	ldr	w3, [x3]
    fc50:      	uxtb	w7, w3
    fc54:      	ubfx	x3, x3, #8, #8
    fc58:      	cmp	x7, x3
    fc5c:      	b.eq	0xfd54 <_stogir.stack.constant-size+0x2d8>
    fc60:      	cmp	x7, #0x49
    fc64:      	b.eq	0xfd54 <_stogir.stack.constant-size+0x2d8>
    fc68:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000fc68:  ARM64_RELOC_PAGE21	l_stogir.511
    fc6c:      	ldr	x16, [x16]
		000000000000fc6c:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    fc70:      	orr	x0, x16, xzr
    fc74:      	mov	x1, x0
    fc78:      	mov	x0, #0x1                ; =1
    fc7c:      	mov	x3, #0x30               ; =48
    fc80:      	mov	sp, x2
    fc84:      	str	x0, [x8]
    fc88:      	str	x1, [x8, #0x8]
    fc8c:      	str	x3, [x8, #0x10]
    fc90:      	sub	sp, x29, #0x0
    fc94:      	ldr	x29, [sp]
    fc98:      	ldr	x30, [sp, #0x8]
    fc9c:      	add	sp, sp, #0x10
    fca0:      	ret
    fca4:      	lsr	w0, w4, #0
    fca8:      	str	x4, [x3]
    fcac:      	str	x5, [x3, #0x8]
    fcb0:      	ubfx	x0, x0, #8, #8
    fcb4:      	cmp	x0, #0x0
    fcb8:      	b.ne	0xfccc <_stogir.stack.constant-size+0x250>
    fcbc:      	movz	x4, #0x0, lsl #48
    fcc0:      	b	0xfc20 <_stogir.stack.constant-size+0x1a4>
    fcc4:      	movz	x5, #0x0, lsl #48
    fcc8:      	b	0xfb54 <_stogir.stack.constant-size+0xd8>
    fccc:      	cmp	x0, #0x1
    fcd0:      	b.eq	0xfc1c <_stogir.stack.constant-size+0x1a0>
    fcd4:      	cmp	x0, #0x2
    fcd8:      	b.eq	0xfc1c <_stogir.stack.constant-size+0x1a0>
    fcdc:      	cmp	x0, #0x7
    fce0:      	b.eq	0xfc1c <_stogir.stack.constant-size+0x1a0>
    fce4:      	cmp	x0, #0x8
    fce8:      	b.eq	0xfc1c <_stogir.stack.constant-size+0x1a0>
    fcec:      	cmp	x0, #0x3
    fcf0:      	b.eq	0xfdfc <_stogir.stack.constant-size+0x380>
    fcf4:      	cmp	x0, #0x9
    fcf8:      	b.eq	0xfdfc <_stogir.stack.constant-size+0x380>
    fcfc:      	cmp	x0, #0x4
    fd00:      	b.eq	0xfe0c <_stogir.stack.constant-size+0x390>
    fd04:      	cmp	x0, #0xa
    fd08:      	b.eq	0xfe0c <_stogir.stack.constant-size+0x390>
    fd0c:      	cmp	x0, #0xd
    fd10:      	b.eq	0xfe0c <_stogir.stack.constant-size+0x390>
    fd14:      	cmp	x0, #0x5
    fd18:      	b.eq	0xfe14 <_stogir.stack.constant-size+0x398>
    fd1c:      	cmp	x0, #0xb
    fd20:      	b.eq	0xfe14 <_stogir.stack.constant-size+0x398>
    fd24:      	cmp	x0, #0xc
    fd28:      	b.eq	0xfe14 <_stogir.stack.constant-size+0x398>
    fd2c:      	cmp	x0, #0x6
    fd30:      	cset	w4, eq
    fd34:      	uxtb	w16, w4
    fd38:      	cmp	w16, wzr
    fd3c:      	mov	x16, #0x8               ; =8
    fd40:      	movn	x17, #0x0, lsl #48
    fd44:      	csel	x4, x16, x17, ne
    fd48:      	b	0xfe18 <_stogir.stack.constant-size+0x39c>
    fd4c:      	movz	x5, #0x0, lsl #48
    fd50:      	b	0xfb4c <_stogir.stack.constant-size+0xd0>
    fd54:      	lsr	w4, w4, #0
    fd58:      	sxtw	x4, w4
    fd5c:      	cmp	x4, #0x0
    fd60:      	b.le	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fd64:      	ubfx	x5, x5, #0, #32
    fd68:      	ubfx	x6, x6, #0, #32
    fd6c:      	lsl	x3, x6, #32
    fd70:      	orr	x3, x3, x5
    fd74:      	cmp	x4, #0x8
    fd78:      	b.ge	0xfd94 <_stogir.stack.constant-size+0x318>
    fd7c:      	lsl	x5, x4, #3
    fd80:      	lsr	w5, w5, #0
    fd84:      	sxtw	x5, w5
    fd88:      	lsr	x5, x3, x5
    fd8c:      	cmp	x5, #0x0
    fd90:      	b.ne	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fd94:      	cmp	x0, #0x7
    fd98:      	b.lt	0xfdd4 <_stogir.stack.constant-size+0x358>
    fd9c:      	uxtb	w16, w1
    fda0:      	cmp	w16, wzr
    fda4:      	b.eq	0xfdd4 <_stogir.stack.constant-size+0x358>
    fda8:      	lsl	x0, x4, #3
    fdac:      	lsr	w0, w0, #0
    fdb0:      	sxtw	x0, w0
    fdb4:      	sub	x0, x0, #0x1
    fdb8:      	lsr	w0, w0, #0
    fdbc:      	sxtw	x0, w0
    fdc0:      	mov	x16, #0x1               ; =1
    fdc4:      	lsl	x0, x16, x0
    fdc8:      	and	x0, x0, x3
    fdcc:      	cmp	x0, #0x0
    fdd0:      	b.ne	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fdd4:      	mov	x17, #-0x10             ; =-16
    fdd8:      	movk	x17, #0x7fff, lsl #48
    fddc:      	cmp	x3, x17
    fde0:      	b.hi	0xfc68 <_stogir.stack.constant-size+0x1ec>
    fde4:      	add	x0, x3, #0xf
    fde8:      	and	x0, x0, #0xfffffffffffffff0
    fdec:      	mov	x1, x0
    fdf0:      	movz	x0, #0x0, lsl #48
    fdf4:      	movz	x3, #0x0, lsl #48
    fdf8:      	b	0xfc80 <_stogir.stack.constant-size+0x204>
    fdfc:      	mov	x4, #0x2                ; =2
    fe00:      	b	0xfc20 <_stogir.stack.constant-size+0x1a4>
    fe04:      	brk	#0
    fe08:      	b	0xfe04 <_stogir.stack.constant-size+0x388>
    fe0c:      	mov	x4, #0x4                ; =4
    fe10:      	b	0xfe00 <_stogir.stack.constant-size+0x384>
    fe14:      	mov	x4, #0x8                ; =8
    fe18:      	b	0xfe10 <_stogir.stack.constant-size+0x394>

000000000000fe1c <_stogir.frame.valid-alignment?>:
    fe1c:      	cmp	x0, #0x0
    fe20:      	b.le	0xfe3c <_stogir.frame.valid-alignment?+0x20>
    fe24:      	sub	x1, x0, #0x1
    fe28:      	and	x0, x1, x0
    fe2c:      	cmp	x0, #0x0
    fe30:      	cset	w0, eq
    fe34:      	ubfx	x0, x0, #0, #8
    fe38:      	b	0xfe40 <_stogir.frame.valid-alignment?+0x24>
    fe3c:      	movz	x0, #0x0, lsl #48
    fe40:      	ret

000000000000fe44 <_stogir.stack.constant-size-aligned>:
    fe44:      	sub	sp, sp, #0x10
    fe48:      	cmp	x2, #0x10
    fe4c:      	b.lt	0xfecc <_stogir.stack.constant-size-aligned+0x88>
    fe50:      	cmp	x2, #0x0
    fe54:      	b.le	0xfecc <_stogir.stack.constant-size-aligned+0x88>
    fe58:      	sub	x3, x2, #0x1
    fe5c:      	and	x3, x3, x2
    fe60:      	cmp	x3, #0x0
    fe64:      	b.ne	0xfecc <_stogir.stack.constant-size-aligned+0x88>
    fe68:      	sxtw	x1, w1
    fe6c:      	cmp	x1, #0x0
    fe70:      	cset	w3, gt
    fe74:      	movz	x16, #0x0, lsl #48
    fe78:      	sub	x4, x16, x1
    fe7c:      	sub	x5, x4, #0x1
    fe80:      	uxtb	w16, w3
    fe84:      	cmp	w16, wzr
    fe88:      	b.eq	0xff6c <_stogir.stack.constant-size-aligned+0x128>
    fe8c:      	ldr	x4, [x0, #0x8]
    fe90:      	cmp	x1, x4
    fe94:      	b.ge	0xffb8 <_stogir.stack.constant-size-aligned+0x174>
    fe98:      	add	x4, x0, #0x78
    fe9c:      	ldr	x4, [x4, #0x8]
    fea0:      	cmp	x1, x4
    fea4:      	b.ge	0x100b4 <_stogir.stack.constant-size-aligned+0x270>
    fea8:      	lsl	x4, x1, #2
    feac:      	ldr	x6, [x0, #0x78]
    feb0:      	add	x4, x4, x6
    feb4:      	ldr	w4, [x4]
    feb8:      	sxtw	x4, w4
    febc:      	cmp	x4, #0x0
    fec0:      	cset	w4, ge
    fec4:      	ubfx	x4, x4, #0, #8
    fec8:      	b	0x100b8 <_stogir.stack.constant-size-aligned+0x274>
    fecc:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000fecc:  ARM64_RELOC_PAGE21	l_stogir.512
    fed0:      	ldr	x16, [x16]
		000000000000fed0:  ARM64_RELOC_PAGEOFF12	l_stogir.512
    fed4:      	orr	x0, x16, xzr
    fed8:      	mov	x1, x0
    fedc:      	mov	x0, #0x1                ; =1
    fee0:      	mov	x2, #0x20               ; =32
    fee4:      	str	x0, [x8]
    fee8:      	str	x1, [x8, #0x8]
    feec:      	str	x2, [x8, #0x10]
    fef0:      	add	sp, sp, #0x10
    fef4:      	ret
    fef8:      	mov	x3, #0x1                ; =1
    fefc:      	mov	x16, sp
    ff00:      	ldr	w4, [x16, #0x8]
    ff04:      	mov	x16, sp
    ff08:      	ldr	w5, [x16, #0xc]
    ff0c:      	cmp	x1, #0x0
    ff10:      	b.ge	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
    ff14:      	cmp	x0, #0x1
    ff18:      	b.lt	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
    ff1c:      	cmp	x0, #0xb
    ff20:      	cset	w1, le
    ff24:      	uxtb	w16, w1
    ff28:      	cmp	w16, wzr
    ff2c:      	b.eq	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
    ff30:      	mov	x16, sp
    ff34:      	ldr	w6, [x16]
    ff38:      	uxtb	w7, w6
    ff3c:      	ubfx	x6, x6, #8, #8
    ff40:      	cmp	x7, x6
    ff44:      	b.eq	0x10144 <_stogir.stack.constant-size-aligned+0x300>
    ff48:      	cmp	x7, #0x49
    ff4c:      	b.eq	0x10144 <_stogir.stack.constant-size-aligned+0x300>
    ff50:      	adrp	x16, 0xf000 <_stogir.switch.selector-type+0x44>
		000000000000ff50:  ARM64_RELOC_PAGE21	l_stogir.513
    ff54:      	ldr	x16, [x16]
		000000000000ff54:  ARM64_RELOC_PAGEOFF12	l_stogir.513
    ff58:      	orr	x0, x16, xzr
    ff5c:      	mov	x1, x0
    ff60:      	mov	x0, #0x1                ; =1
    ff64:      	mov	x2, #0x30               ; =48
    ff68:      	b	0xfee4 <_stogir.stack.constant-size-aligned+0xa0>
    ff6c:      	cmp	x1, #0x0
    ff70:      	b.ge	0xffc0 <_stogir.stack.constant-size-aligned+0x17c>
    ff74:      	add	x6, x0, #0x28
    ff78:      	add	x7, x0, #0x50
    ff7c:      	ldr	x6, [x6, #0x8]
    ff80:      	ldr	x7, [x7, #0x8]
    ff84:      	cmp	x6, x7
    ff88:      	b.ne	0x100ac <_stogir.stack.constant-size-aligned+0x268>
    ff8c:      	cmp	x4, x6
    ff90:      	b.gt	0x1013c <_stogir.stack.constant-size-aligned+0x2f8>
    ff94:      	lsl	x4, x5, #2
    ff98:      	ldr	x6, [x0, #0x50]
    ff9c:      	add	x4, x4, x6
    ffa0:      	ldr	w4, [x4]
    ffa4:      	sxtw	x4, w4
    ffa8:      	cmp	x4, #0x0
    ffac:      	cset	w4, gt
    ffb0:      	ubfx	x4, x4, #0, #8
    ffb4:      	b	0x10140 <_stogir.stack.constant-size-aligned+0x2fc>
    ffb8:      	movz	x4, #0x0, lsl #48
    ffbc:      	b	0xffc4 <_stogir.stack.constant-size-aligned+0x180>
    ffc0:      	movz	x4, #0x0, lsl #48
    ffc4:      	cmp	x4, #0x0
    ffc8:      	b.eq	0x1002c <_stogir.stack.constant-size-aligned+0x1e8>
    ffcc:      	uxtb	w16, w3
    ffd0:      	cmp	w16, wzr
    ffd4:      	b.eq	0xfffc <_stogir.stack.constant-size-aligned+0x1b8>
    ffd8:      	lsl	x3, x1, #4
    ffdc:      	ldr	x0, [x0]
    ffe0:      	add	x0, x3, x0
    ffe4:      	ldr	x3, [x0]
    ffe8:      	ldr	x0, [x0, #0x8]
    ffec:      	fmov	d31, x0
    fff0:      	mov	x0, x3
    fff4:      	fmov	x3, d31
    fff8:      	b	0x1001c <_stogir.stack.constant-size-aligned+0x1d8>
    fffc:      	lsl	x3, x5, #4
   10000:      	ldr	x0, [x0, #0x28]
   10004:      	add	x0, x3, x0
   10008:      	ldr	x3, [x0]
   1000c:      	ldr	x0, [x0, #0x8]
   10010:      	fmov	d31, x0
   10014:      	mov	x0, x3
   10018:      	fmov	x3, d31
   1001c:      	mov	x4, x3
   10020:      	mov	x3, x0
   10024:      	mov	x0, #0x1                ; =1
   10028:      	b	0x10038 <_stogir.stack.constant-size-aligned+0x1f4>
   1002c:      	movz	x0, #0x0, lsl #48
   10030:      	movz	x3, #0x0, lsl #48
   10034:      	movz	x4, #0x0, lsl #48
   10038:      	lsr	w0, w0, #0
   1003c:      	lsr	x16, x0, #0
   10040:      	cmp	x16, #0x1
   10044:      	b.eq	0x10060 <_stogir.stack.constant-size-aligned+0x21c>
   10048:      	b.lo	0x10050 <_stogir.stack.constant-size-aligned+0x20c>
   1004c:      	b	0x10064 <_stogir.stack.constant-size-aligned+0x220>
   10050:      	cmp	x16, #0x0
   10054:      	b.eq	0x1005c <_stogir.stack.constant-size-aligned+0x218>
   10058:      	b	0x10064 <_stogir.stack.constant-size-aligned+0x220>
   1005c:      	b	0x10068 <_stogir.stack.constant-size-aligned+0x224>
   10060:      	b	0x10084 <_stogir.stack.constant-size-aligned+0x240>
   10064:      	b	0x10204 <_stogir.stack.constant-size-aligned+0x3c0>
   10068:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x1bc>
		0000000000010068:  ARM64_RELOC_PAGE21	l_stogir.514
   1006c:      	ldr	x16, [x16]
		000000000001006c:  ARM64_RELOC_PAGEOFF12	l_stogir.514
   10070:      	orr	x0, x16, xzr
   10074:      	mov	x1, x0
   10078:      	mov	x0, #0x1                ; =1
   1007c:      	mov	x2, #0x18               ; =24
   10080:      	b	0xff68 <_stogir.stack.constant-size-aligned+0x124>
   10084:      	lsr	w0, w3, #0
   10088:      	mov	x16, sp
   1008c:      	str	x3, [x16]
   10090:      	mov	x16, sp
   10094:      	str	x4, [x16, #0x8]
   10098:      	ubfx	x0, x0, #8, #8
   1009c:      	cmp	x0, #0x0
   100a0:      	b.ne	0x100bc <_stogir.stack.constant-size-aligned+0x278>
   100a4:      	movz	x3, #0x0, lsl #48
   100a8:      	b	0xfefc <_stogir.stack.constant-size-aligned+0xb8>
   100ac:      	movz	x4, #0x0, lsl #48
   100b0:      	b	0xffc4 <_stogir.stack.constant-size-aligned+0x180>
   100b4:      	movz	x4, #0x0, lsl #48
   100b8:      	b	0xffbc <_stogir.stack.constant-size-aligned+0x178>
   100bc:      	cmp	x0, #0x1
   100c0:      	b.eq	0xfef8 <_stogir.stack.constant-size-aligned+0xb4>
   100c4:      	cmp	x0, #0x2
   100c8:      	b.eq	0xfef8 <_stogir.stack.constant-size-aligned+0xb4>
   100cc:      	cmp	x0, #0x7
   100d0:      	b.eq	0xfef8 <_stogir.stack.constant-size-aligned+0xb4>
   100d4:      	cmp	x0, #0x8
   100d8:      	b.eq	0xfef8 <_stogir.stack.constant-size-aligned+0xb4>
   100dc:      	cmp	x0, #0x3
   100e0:      	b.eq	0x101fc <_stogir.stack.constant-size-aligned+0x3b8>
   100e4:      	cmp	x0, #0x9
   100e8:      	b.eq	0x101fc <_stogir.stack.constant-size-aligned+0x3b8>
   100ec:      	cmp	x0, #0x4
   100f0:      	b.eq	0x1020c <_stogir.stack.constant-size-aligned+0x3c8>
   100f4:      	cmp	x0, #0xa
   100f8:      	b.eq	0x1020c <_stogir.stack.constant-size-aligned+0x3c8>
   100fc:      	cmp	x0, #0xd
   10100:      	b.eq	0x1020c <_stogir.stack.constant-size-aligned+0x3c8>
   10104:      	cmp	x0, #0x5
   10108:      	b.eq	0x10214 <_stogir.stack.constant-size-aligned+0x3d0>
   1010c:      	cmp	x0, #0xb
   10110:      	b.eq	0x10214 <_stogir.stack.constant-size-aligned+0x3d0>
   10114:      	cmp	x0, #0xc
   10118:      	b.eq	0x10214 <_stogir.stack.constant-size-aligned+0x3d0>
   1011c:      	cmp	x0, #0x6
   10120:      	cset	w3, eq
   10124:      	uxtb	w16, w3
   10128:      	cmp	w16, wzr
   1012c:      	mov	x16, #0x8               ; =8
   10130:      	movn	x17, #0x0, lsl #48
   10134:      	csel	x3, x16, x17, ne
   10138:      	b	0x10218 <_stogir.stack.constant-size-aligned+0x3d4>
   1013c:      	movz	x4, #0x0, lsl #48
   10140:      	b	0x100b0 <_stogir.stack.constant-size-aligned+0x26c>
   10144:      	lsr	w3, w3, #0
   10148:      	sxtw	x3, w3
   1014c:      	cmp	x3, #0x0
   10150:      	b.le	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
   10154:      	ubfx	x4, x4, #0, #32
   10158:      	ubfx	x5, x5, #0, #32
   1015c:      	lsl	x5, x5, #32
   10160:      	orr	x4, x5, x4
   10164:      	cmp	x3, #0x8
   10168:      	b.ge	0x10184 <_stogir.stack.constant-size-aligned+0x340>
   1016c:      	lsl	x5, x3, #3
   10170:      	lsr	w5, w5, #0
   10174:      	sxtw	x5, w5
   10178:      	lsr	x5, x4, x5
   1017c:      	cmp	x5, #0x0
   10180:      	b.ne	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
   10184:      	cmp	x0, #0x7
   10188:      	b.lt	0x101c4 <_stogir.stack.constant-size-aligned+0x380>
   1018c:      	uxtb	w16, w1
   10190:      	cmp	w16, wzr
   10194:      	b.eq	0x101c4 <_stogir.stack.constant-size-aligned+0x380>
   10198:      	lsl	x0, x3, #3
   1019c:      	lsr	w0, w0, #0
   101a0:      	sxtw	x0, w0
   101a4:      	sub	x0, x0, #0x1
   101a8:      	lsr	w0, w0, #0
   101ac:      	sxtw	x0, w0
   101b0:      	mov	x16, #0x1               ; =1
   101b4:      	lsl	x0, x16, x0
   101b8:      	and	x0, x0, x4
   101bc:      	cmp	x0, #0x0
   101c0:      	b.ne	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
   101c4:      	sub	x0, x2, #0x1
   101c8:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
   101cc:      	sub	x0, x16, x0
   101d0:      	cmp	x4, x0
   101d4:      	b.hi	0xff50 <_stogir.stack.constant-size-aligned+0x10c>
   101d8:      	sub	x0, x2, #0x1
   101dc:      	movz	x16, #0x0, lsl #48
   101e0:      	sub	x1, x16, x2
   101e4:      	add	x0, x0, x4
   101e8:      	and	x0, x1, x0
   101ec:      	mov	x1, x0
   101f0:      	movz	x0, #0x0, lsl #48
   101f4:      	movz	x2, #0x0, lsl #48
   101f8:      	b	0xff68 <_stogir.stack.constant-size-aligned+0x124>
   101fc:      	mov	x3, #0x2                ; =2
   10200:      	b	0xfefc <_stogir.stack.constant-size-aligned+0xb8>
   10204:      	brk	#0
   10208:      	b	0x10204 <_stogir.stack.constant-size-aligned+0x3c0>
   1020c:      	mov	x3, #0x4                ; =4
   10210:      	b	0x10200 <_stogir.stack.constant-size-aligned+0x3bc>
   10214:      	mov	x3, #0x8                ; =8
   10218:      	b	0x10210 <_stogir.stack.constant-size-aligned+0x3cc>

000000000001021c <_stogir.numeric-conversion.operation?>:
   1021c:      	sxtw	x0, w0
   10220:      	cmp	x0, #0x25
   10224:      	b.lt	0x10238 <_stogir.numeric-conversion.operation?+0x1c>
   10228:      	cmp	x0, #0x27
   1022c:      	cset	w0, le
   10230:      	ubfx	x0, x0, #0, #8
   10234:      	b	0x1023c <_stogir.numeric-conversion.operation?+0x20>
   10238:      	movz	x0, #0x0, lsl #48
   1023c:      	ret

0000000000010240 <_stogir.numeric-conversion.valid-types?>:
   10240:      	sxtw	x0, w0
   10244:      	sxtw	x1, w1
   10248:      	sxtw	x2, w2
   1024c:      	cmp	x2, #0xc
   10250:      	cset	w3, eq
   10254:      	cmp	x2, #0xd
   10258:      	cset	w4, eq
   1025c:      	ubfx	x4, x4, #0, #8
   10260:      	cmp	x0, #0x25
   10264:      	b.ne	0x1028c <_stogir.numeric-conversion.valid-types?+0x4c>
   10268:      	cmp	x1, #0x1
   1026c:      	b.lt	0x102f4 <_stogir.numeric-conversion.valid-types?+0xb4>
   10270:      	cmp	x1, #0xb
   10274:      	b.gt	0x102f4 <_stogir.numeric-conversion.valid-types?+0xb4>
   10278:      	uxtb	w16, w3
   1027c:      	cmp	w16, wzr
   10280:      	b.eq	0x10304 <_stogir.numeric-conversion.valid-types?+0xc4>
   10284:      	mov	x0, #0x1                ; =1
   10288:      	b	0x10308 <_stogir.numeric-conversion.valid-types?+0xc8>
   1028c:      	cmp	x1, #0xc
   10290:      	cset	w5, eq
   10294:      	cmp	x1, #0xd
   10298:      	cset	w1, eq
   1029c:      	cmp	x0, #0x26
   102a0:      	b.ne	0x102c4 <_stogir.numeric-conversion.valid-types?+0x84>
   102a4:      	uxtb	w16, w5
   102a8:      	cmp	w16, wzr
   102ac:      	b.ne	0x10314 <_stogir.numeric-conversion.valid-types?+0xd4>
   102b0:      	uxtb	w16, w1
   102b4:      	cmp	w16, wzr
   102b8:      	b.ne	0x10314 <_stogir.numeric-conversion.valid-types?+0xd4>
   102bc:      	movz	x0, #0x0, lsl #48
   102c0:      	b	0x102f0 <_stogir.numeric-conversion.valid-types?+0xb0>
   102c4:      	cmp	x0, #0x27
   102c8:      	b.ne	0x102fc <_stogir.numeric-conversion.valid-types?+0xbc>
   102cc:      	uxtb	w16, w5
   102d0:      	cmp	w16, wzr
   102d4:      	b.ne	0x1032c <_stogir.numeric-conversion.valid-types?+0xec>
   102d8:      	uxtb	w16, w1
   102dc:      	cmp	w16, wzr
   102e0:      	b.ne	0x1032c <_stogir.numeric-conversion.valid-types?+0xec>
   102e4:      	movz	x0, #0x0, lsl #48
   102e8:      	b	0x10310 <_stogir.numeric-conversion.valid-types?+0xd0>
   102ec:      	movz	x0, #0x0, lsl #48
   102f0:      	b	0x10300 <_stogir.numeric-conversion.valid-types?+0xc0>
   102f4:      	movz	x0, #0x0, lsl #48
   102f8:      	b	0x10300 <_stogir.numeric-conversion.valid-types?+0xc0>
   102fc:      	movz	x0, #0x0, lsl #48
   10300:      	ret
   10304:      	mov	x0, x4
   10308:      	b	0x102f8 <_stogir.numeric-conversion.valid-types?+0xb8>
   1030c:      	mov	x0, x4
   10310:      	b	0x10300 <_stogir.numeric-conversion.valid-types?+0xc0>
   10314:      	cmp	x2, #0x1
   10318:      	b.lt	0x102ec <_stogir.numeric-conversion.valid-types?+0xac>
   1031c:      	cmp	x2, #0xb
   10320:      	cset	w0, le
   10324:      	ubfx	x0, x0, #0, #8
   10328:      	b	0x102f0 <_stogir.numeric-conversion.valid-types?+0xb0>
   1032c:      	uxtb	w16, w3
   10330:      	cmp	w16, wzr
   10334:      	b.eq	0x1030c <_stogir.numeric-conversion.valid-types?+0xcc>
   10338:      	mov	x0, #0x1                ; =1
   1033c:      	b	0x10310 <_stogir.numeric-conversion.valid-types?+0xd0>

0000000000010340 <_inherent$slice$new__stogir.node.Node>:
   10340:      	sub	sp, sp, #0x10
   10344:      	mov	x2, sp
   10348:      	str	x0, [x2]
   1034c:      	str	x1, [x2, #0x8]
   10350:      	ldr	x0, [sp]
   10354:      	ldr	x1, [sp, #0x8]
   10358:      	add	sp, sp, #0x10
   1035c:      	ret

0000000000010360 <_inherent$slice$data__stogir.node.Node>:
   10360:      	ret

0000000000010364 <_coil.slice.element-ref__stogir.node.Node>:
   10364:      	ret

0000000000010368 <_stogir.vector-lanes.ordinary?>:
   10368:      	ldr	w0, [x0]
   1036c:      	uxtb	w0, w0
   10370:      	cmp	x0, #0x48
   10374:      	b.ne	0x10380 <_stogir.vector-lanes.ordinary?+0x18>
   10378:      	movz	x0, #0x0, lsl #48
   1037c:      	b	0x10394 <_stogir.vector-lanes.ordinary?+0x2c>
   10380:      	cmp	x0, #0x46
   10384:      	cset	w0, eq
   10388:      	uxtb	w16, w0
   1038c:      	cmp	w16, wzr
   10390:      	cset	x0, eq
   10394:      	ret

0000000000010398 <_stogir.vector-lanes.compatible?>:
   10398:      	sub	sp, sp, #0x30
   1039c:      	str	x29, [sp]
   103a0:      	str	x30, [sp, #0x8]
   103a4:      	mov	x29, sp
   103a8:      	str	x19, [sp, #0x10]
   103ac:      	str	x20, [sp, #0x18]
   103b0:      	str	x21, [sp, #0x20]
   103b4:      	lsr	w3, w0, #0
   103b8:      	sxtw	x19, w0
   103bc:      	mov	w0, w3
   103c0:      	mov	w20, w1
   103c4:      	mov	w21, w2
   103c8:      	bl	0x103c8 <_stogir.vector-lanes.compatible?+0x30>
		00000000000103c8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   103cc:      	and	x1, x19, #0xf
   103d0:      	lsr	w1, w1, #0
   103d4:      	sxtw	x1, w1
   103d8:      	cmp	x0, #0x0
   103dc:      	b.eq	0x103e8 <_stogir.vector-lanes.compatible?+0x50>
   103e0:      	mov	x0, x1
   103e4:      	b	0x103ec <_stogir.vector-lanes.compatible?+0x54>
   103e8:      	movn	x0, #0x0, lsl #48
   103ec:      	cmp	x19, #0xf
   103f0:      	b.le	0x10440 <_stogir.vector-lanes.compatible?+0xa8>
   103f4:      	cmp	x19, #0x80
   103f8:      	b.ge	0x10440 <_stogir.vector-lanes.compatible?+0xa8>
   103fc:      	cmp	x1, #0x1
   10400:      	b.lt	0x10440 <_stogir.vector-lanes.compatible?+0xa8>
   10404:      	cmp	x1, #0xd
   10408:      	b.gt	0x10440 <_stogir.vector-lanes.compatible?+0xa8>
   1040c:      	sxtw	x21, w21
   10410:      	cmp	x21, #0x4
   10414:      	cset	w1, eq
   10418:      	cmp	x21, #0x8
   1041c:      	cset	w2, eq
   10420:      	uxtb	w16, w1
   10424:      	cmp	w16, wzr
   10428:      	b.ne	0x10468 <_stogir.vector-lanes.compatible?+0xd0>
   1042c:      	uxtb	w16, w2
   10430:      	cmp	w16, wzr
   10434:      	b.ne	0x10468 <_stogir.vector-lanes.compatible?+0xd0>
   10438:      	movz	x0, #0x0, lsl #48
   1043c:      	b	0x10464 <_stogir.vector-lanes.compatible?+0xcc>
   10440:      	movz	x0, #0x0, lsl #48
   10444:      	ldr	x19, [sp, #0x10]
   10448:      	ldr	x20, [sp, #0x18]
   1044c:      	ldr	x21, [sp, #0x20]
   10450:      	ldr	x29, [sp]
   10454:      	ldr	x30, [sp, #0x8]
   10458:      	add	sp, sp, #0x30
   1045c:      	ret
   10460:      	movz	x0, #0x0, lsl #48
   10464:      	b	0x10444 <_stogir.vector-lanes.compatible?+0xac>
   10468:      	sxtw	x20, w20
   1046c:      	cmp	x20, #0x0
   10470:      	b.lt	0x10460 <_stogir.vector-lanes.compatible?+0xc8>
   10474:      	cmp	x20, #0xd
   10478:      	b.gt	0x10460 <_stogir.vector-lanes.compatible?+0xc8>
   1047c:      	cmp	x20, #0x0
   10480:      	b.le	0x1049c <_stogir.vector-lanes.compatible?+0x104>
   10484:      	lsr	w0, w0, #0
   10488:      	sxtw	x0, w0
   1048c:      	cmp	x0, x20
   10490:      	b.ne	0x104a4 <_stogir.vector-lanes.compatible?+0x10c>
   10494:      	mov	x0, #0x1                ; =1
   10498:      	b	0x104a0 <_stogir.vector-lanes.compatible?+0x108>
   1049c:      	movz	x0, #0x0, lsl #48
   104a0:      	b	0x10464 <_stogir.vector-lanes.compatible?+0xcc>
   104a4:      	cmp	x0, #0x1
   104a8:      	b.lt	0x104e4 <_stogir.vector-lanes.compatible?+0x14c>
   104ac:      	cmp	x0, #0xb
   104b0:      	b.gt	0x104e4 <_stogir.vector-lanes.compatible?+0x14c>
   104b4:      	cmp	x20, #0x1
   104b8:      	b.lt	0x104ec <_stogir.vector-lanes.compatible?+0x154>
   104bc:      	cmp	x20, #0xb
   104c0:      	b.gt	0x104ec <_stogir.vector-lanes.compatible?+0x154>
   104c4:      	uxtb	w16, w1
   104c8:      	cmp	w16, wzr
   104cc:      	b.ne	0x10518 <_stogir.vector-lanes.compatible?+0x180>
   104d0:      	uxtb	w16, w2
   104d4:      	cmp	w16, wzr
   104d8:      	b.ne	0x10518 <_stogir.vector-lanes.compatible?+0x180>
   104dc:      	movn	x0, #0x0, lsl #48
   104e0:      	b	0x1052c <_stogir.vector-lanes.compatible?+0x194>
   104e4:      	movz	x0, #0x0, lsl #48
   104e8:      	b	0x10498 <_stogir.vector-lanes.compatible?+0x100>
   104ec:      	movz	x0, #0x0, lsl #48
   104f0:      	b	0x104e8 <_stogir.vector-lanes.compatible?+0x150>
   104f4:      	mov	x1, #0x1                ; =1
   104f8:      	lsr	w0, w0, #0
   104fc:      	sxtw	x0, w0
   10500:      	lsr	w1, w1, #0
   10504:      	sxtw	x1, w1
   10508:      	cmp	x0, x1
   1050c:      	cset	w0, eq
   10510:      	ubfx	x0, x0, #0, #8
   10514:      	b	0x104f0 <_stogir.vector-lanes.compatible?+0x158>
   10518:      	cmp	x0, #0x0
   1051c:      	b.ne	0x105cc <_stogir.vector-lanes.compatible?+0x234>
   10520:      	movz	x0, #0x0, lsl #48
   10524:      	b	0x1052c <_stogir.vector-lanes.compatible?+0x194>
   10528:      	mov	x0, #0x1                ; =1
   1052c:      	uxtb	w16, w1
   10530:      	cmp	w16, wzr
   10534:      	b.ne	0x1054c <_stogir.vector-lanes.compatible?+0x1b4>
   10538:      	uxtb	w16, w2
   1053c:      	cmp	w16, wzr
   10540:      	b.ne	0x1054c <_stogir.vector-lanes.compatible?+0x1b4>
   10544:      	movn	x1, #0x0, lsl #48
   10548:      	b	0x104f8 <_stogir.vector-lanes.compatible?+0x160>
   1054c:      	cmp	x20, #0x0
   10550:      	b.ne	0x1055c <_stogir.vector-lanes.compatible?+0x1c4>
   10554:      	movz	x1, #0x0, lsl #48
   10558:      	b	0x104f8 <_stogir.vector-lanes.compatible?+0x160>
   1055c:      	cmp	x20, #0x1
   10560:      	b.eq	0x104f4 <_stogir.vector-lanes.compatible?+0x15c>
   10564:      	cmp	x20, #0x2
   10568:      	b.eq	0x104f4 <_stogir.vector-lanes.compatible?+0x15c>
   1056c:      	cmp	x20, #0x7
   10570:      	b.eq	0x104f4 <_stogir.vector-lanes.compatible?+0x15c>
   10574:      	cmp	x20, #0x8
   10578:      	b.eq	0x104f4 <_stogir.vector-lanes.compatible?+0x15c>
   1057c:      	cmp	x20, #0x3
   10580:      	b.eq	0x1063c <_stogir.vector-lanes.compatible?+0x2a4>
   10584:      	cmp	x20, #0x9
   10588:      	b.eq	0x1063c <_stogir.vector-lanes.compatible?+0x2a4>
   1058c:      	cmp	x20, #0x4
   10590:      	b.eq	0x1064c <_stogir.vector-lanes.compatible?+0x2b4>
   10594:      	cmp	x20, #0xa
   10598:      	b.eq	0x1064c <_stogir.vector-lanes.compatible?+0x2b4>
   1059c:      	cmp	x20, #0xd
   105a0:      	b.eq	0x1064c <_stogir.vector-lanes.compatible?+0x2b4>
   105a4:      	cmp	x20, #0x5
   105a8:      	b.eq	0x1065c <_stogir.vector-lanes.compatible?+0x2c4>
   105ac:      	cmp	x20, #0xb
   105b0:      	b.eq	0x1065c <_stogir.vector-lanes.compatible?+0x2c4>
   105b4:      	cmp	x20, #0xc
   105b8:      	b.eq	0x1065c <_stogir.vector-lanes.compatible?+0x2c4>
   105bc:      	cmp	x20, #0x6
   105c0:      	b.ne	0x1066c <_stogir.vector-lanes.compatible?+0x2d4>
   105c4:      	mov	x1, x21
   105c8:      	b	0x10670 <_stogir.vector-lanes.compatible?+0x2d8>
   105cc:      	cmp	x0, #0x1
   105d0:      	b.eq	0x10528 <_stogir.vector-lanes.compatible?+0x190>
   105d4:      	cmp	x0, #0x2
   105d8:      	b.eq	0x10528 <_stogir.vector-lanes.compatible?+0x190>
   105dc:      	cmp	x0, #0x7
   105e0:      	b.eq	0x10528 <_stogir.vector-lanes.compatible?+0x190>
   105e4:      	cmp	x0, #0x8
   105e8:      	b.eq	0x10528 <_stogir.vector-lanes.compatible?+0x190>
   105ec:      	cmp	x0, #0x3
   105f0:      	b.eq	0x10644 <_stogir.vector-lanes.compatible?+0x2ac>
   105f4:      	cmp	x0, #0x9
   105f8:      	b.eq	0x10644 <_stogir.vector-lanes.compatible?+0x2ac>
   105fc:      	cmp	x0, #0x4
   10600:      	b.eq	0x10654 <_stogir.vector-lanes.compatible?+0x2bc>
   10604:      	cmp	x0, #0xa
   10608:      	b.eq	0x10654 <_stogir.vector-lanes.compatible?+0x2bc>
   1060c:      	cmp	x0, #0xd
   10610:      	b.eq	0x10654 <_stogir.vector-lanes.compatible?+0x2bc>
   10614:      	cmp	x0, #0x5
   10618:      	b.eq	0x10664 <_stogir.vector-lanes.compatible?+0x2cc>
   1061c:      	cmp	x0, #0xb
   10620:      	b.eq	0x10664 <_stogir.vector-lanes.compatible?+0x2cc>
   10624:      	cmp	x0, #0xc
   10628:      	b.eq	0x10664 <_stogir.vector-lanes.compatible?+0x2cc>
   1062c:      	cmp	x0, #0x6
   10630:      	b.ne	0x10674 <_stogir.vector-lanes.compatible?+0x2dc>
   10634:      	mov	x0, x21
   10638:      	b	0x10678 <_stogir.vector-lanes.compatible?+0x2e0>
   1063c:      	mov	x1, #0x2                ; =2
   10640:      	b	0x104f8 <_stogir.vector-lanes.compatible?+0x160>
   10644:      	mov	x0, #0x2                ; =2
   10648:      	b	0x1052c <_stogir.vector-lanes.compatible?+0x194>
   1064c:      	mov	x1, #0x4                ; =4
   10650:      	b	0x10640 <_stogir.vector-lanes.compatible?+0x2a8>
   10654:      	mov	x0, #0x4                ; =4
   10658:      	b	0x10648 <_stogir.vector-lanes.compatible?+0x2b0>
   1065c:      	mov	x1, #0x8                ; =8
   10660:      	b	0x10650 <_stogir.vector-lanes.compatible?+0x2b8>
   10664:      	mov	x0, #0x8                ; =8
   10668:      	b	0x10658 <_stogir.vector-lanes.compatible?+0x2c0>
   1066c:      	movn	x1, #0x0, lsl #48
   10670:      	b	0x10660 <_stogir.vector-lanes.compatible?+0x2c8>
   10674:      	movn	x0, #0x0, lsl #48
   10678:      	b	0x10668 <_stogir.vector-lanes.compatible?+0x2d0>

000000000001067c <_stogir.symbols.numeric?>:
   1067c:      	ldr	w0, [x0]
   10680:      	uxtb	w1, w0
   10684:      	ubfx	x0, x0, #8, #8
   10688:      	cmp	x1, x0
   1068c:      	b.ne	0x10698 <_stogir.symbols.numeric?+0x1c>
   10690:      	mov	x0, #0x1                ; =1
   10694:      	b	0x106a4 <_stogir.symbols.numeric?+0x28>
   10698:      	cmp	x1, #0x49
   1069c:      	cset	w0, eq
   106a0:      	ubfx	x0, x0, #0, #8
   106a4:      	ret

00000000000106a8 <_stogir.node.constant-bits>:
   106a8:      	ldr	w1, [x0, #0x8]
   106ac:      	ubfx	x1, x1, #0, #32
   106b0:      	ldr	w0, [x0, #0xc]
   106b4:      	ubfx	x0, x0, #0, #32
   106b8:      	lsl	x0, x0, #32
   106bc:      	orr	x0, x0, x1
   106c0:      	ret

00000000000106c4 <_stogir.vector-comparison.valid-type?>:
   106c4:      	sub	sp, sp, #0x30
   106c8:      	str	x29, [sp]
   106cc:      	str	x30, [sp, #0x8]
   106d0:      	mov	x29, sp
   106d4:      	str	x19, [sp, #0x10]
   106d8:      	str	x20, [sp, #0x18]
   106dc:      	str	x21, [sp, #0x20]
   106e0:      	sxtw	x19, w0
   106e4:      	cmp	x19, #0xe
   106e8:      	b.lt	0x10740 <_stogir.vector-comparison.valid-type?+0x7c>
   106ec:      	cmp	x19, #0x19
   106f0:      	b.gt	0x10740 <_stogir.vector-comparison.valid-type?+0x7c>
   106f4:      	sxtw	x0, w1
   106f8:      	cmp	x0, #0xf
   106fc:      	b.le	0x10760 <_stogir.vector-comparison.valid-type?+0x9c>
   10700:      	cmp	x0, #0x80
   10704:      	b.ge	0x10760 <_stogir.vector-comparison.valid-type?+0x9c>
   10708:      	and	x0, x0, #0xf
   1070c:      	lsr	w0, w0, #0
   10710:      	sxtw	x20, w0
   10714:      	cmp	x20, #0x1
   10718:      	b.lt	0x10760 <_stogir.vector-comparison.valid-type?+0x9c>
   1071c:      	cmp	x20, #0xd
   10720:      	b.gt	0x10760 <_stogir.vector-comparison.valid-type?+0x9c>
   10724:      	lsr	w21, w1, #0
   10728:      	mov	w0, w21
   1072c:      	bl	0x1072c <_stogir.vector-comparison.valid-type?+0x68>
		000000000001072c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10730:      	cmp	x0, #0x0
   10734:      	b.eq	0x10770 <_stogir.vector-comparison.valid-type?+0xac>
   10738:      	mov	x0, x20
   1073c:      	b	0x10774 <_stogir.vector-comparison.valid-type?+0xb0>
   10740:      	movz	x0, #0x0, lsl #48
   10744:      	ldr	x19, [sp, #0x10]
   10748:      	ldr	x20, [sp, #0x18]
   1074c:      	ldr	x21, [sp, #0x20]
   10750:      	ldr	x29, [sp]
   10754:      	ldr	x30, [sp, #0x8]
   10758:      	add	sp, sp, #0x30
   1075c:      	ret
   10760:      	movz	x0, #0x0, lsl #48
   10764:      	b	0x10744 <_stogir.vector-comparison.valid-type?+0x80>
   10768:      	mov	x0, #0x1                ; =1
   1076c:      	b	0x10764 <_stogir.vector-comparison.valid-type?+0xa0>
   10770:      	movn	x0, #0x0, lsl #48
   10774:      	lsr	w0, w0, #0
   10778:      	sxtw	x0, w0
   1077c:      	cmp	x0, #0xc
   10780:      	b.eq	0x10768 <_stogir.vector-comparison.valid-type?+0xa4>
   10784:      	cmp	x0, #0xd
   10788:      	b.eq	0x10768 <_stogir.vector-comparison.valid-type?+0xa4>
   1078c:      	mov	w0, w21
   10790:      	bl	0x10790 <_stogir.vector-comparison.valid-type?+0xcc>
		0000000000010790:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10794:      	cmp	x0, #0x0
   10798:      	b.eq	0x107ac <_stogir.vector-comparison.valid-type?+0xe8>
   1079c:      	mov	x0, x20
   107a0:      	b	0x107b0 <_stogir.vector-comparison.valid-type?+0xec>
   107a4:      	movz	x0, #0x0, lsl #48
   107a8:      	b	0x1076c <_stogir.vector-comparison.valid-type?+0xa8>
   107ac:      	movn	x0, #0x0, lsl #48
   107b0:      	lsr	w0, w0, #0
   107b4:      	sxtw	x0, w0
   107b8:      	cmp	x0, #0x1
   107bc:      	b.lt	0x107a4 <_stogir.vector-comparison.valid-type?+0xe0>
   107c0:      	cmp	x0, #0xb
   107c4:      	b.gt	0x107a4 <_stogir.vector-comparison.valid-type?+0xe0>
   107c8:      	cmp	x19, #0x17
   107cc:      	cset	w0, le
   107d0:      	ubfx	x0, x0, #0, #8
   107d4:      	b	0x107a8 <_stogir.vector-comparison.valid-type?+0xe4>

00000000000107d8 <_stogir.vector-arithmetic.extrema?>:
   107d8:      	sxtw	x0, w0
   107dc:      	cmp	x0, #0x3a
   107e0:      	b.ne	0x107ec <_stogir.vector-arithmetic.extrema?+0x14>
   107e4:      	mov	x0, #0x1                ; =1
   107e8:      	b	0x107f8 <_stogir.vector-arithmetic.extrema?+0x20>
   107ec:      	cmp	x0, #0x3b
   107f0:      	cset	w0, eq
   107f4:      	ubfx	x0, x0, #0, #8
   107f8:      	ret

00000000000107fc <_stogir.vector-arithmetic.shift?>:
   107fc:      	sxtw	x0, w0
   10800:      	cmp	x0, #0x31
   10804:      	b.lt	0x10818 <_stogir.vector-arithmetic.shift?+0x1c>
   10808:      	cmp	x0, #0x35
   1080c:      	cset	w0, le
   10810:      	ubfx	x0, x0, #0, #8
   10814:      	b	0x1081c <_stogir.vector-arithmetic.shift?+0x20>
   10818:      	movz	x0, #0x0, lsl #48
   1081c:      	ret

0000000000010820 <_stogir.vector-arithmetic.valid-type?>:
   10820:      	sub	sp, sp, #0x40
   10824:      	str	x29, [sp]
   10828:      	str	x30, [sp, #0x8]
   1082c:      	mov	x29, sp
   10830:      	str	x19, [sp, #0x10]
   10834:      	str	x20, [sp, #0x18]
   10838:      	str	x21, [sp, #0x20]
   1083c:      	str	x22, [sp, #0x28]
   10840:      	str	x23, [sp, #0x30]
   10844:      	lsr	w2, w1, #0
   10848:      	sxtw	x19, w1
   1084c:      	mov	w20, w0
   10850:      	mov	w0, w2
   10854:      	bl	0x10854 <_stogir.vector-arithmetic.valid-type?+0x34>
		0000000000010854:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10858:      	and	x1, x19, #0xf
   1085c:      	lsr	w1, w1, #0
   10860:      	sxtw	x1, w1
   10864:      	cmp	x0, #0x0
   10868:      	b.eq	0x10874 <_stogir.vector-arithmetic.valid-type?+0x54>
   1086c:      	mov	x0, x1
   10870:      	b	0x10878 <_stogir.vector-arithmetic.valid-type?+0x58>
   10874:      	movn	x0, #0x0, lsl #48
   10878:      	cmp	x19, #0xf
   1087c:      	b.le	0x10a5c <_stogir.vector-arithmetic.valid-type?+0x23c>
   10880:      	cmp	x19, #0x80
   10884:      	b.ge	0x10a5c <_stogir.vector-arithmetic.valid-type?+0x23c>
   10888:      	cmp	x1, #0x1
   1088c:      	b.lt	0x10a5c <_stogir.vector-arithmetic.valid-type?+0x23c>
   10890:      	cmp	x1, #0xd
   10894:      	b.gt	0x10a5c <_stogir.vector-arithmetic.valid-type?+0x23c>
   10898:      	sxtw	x1, w20
   1089c:      	cmp	x1, #0x1f
   108a0:      	cset	w19, eq
   108a4:      	cmp	x1, #0x20
   108a8:      	cset	w21, eq
   108ac:      	cmp	x1, #0x2e
   108b0:      	cset	w2, eq
   108b4:      	cmp	x1, #0x2f
   108b8:      	cset	w3, eq
   108bc:      	cmp	x1, #0x30
   108c0:      	cset	w4, eq
   108c4:      	cmp	x1, #0x1e
   108c8:      	cset	w5, eq
   108cc:      	cmp	x1, #0x31
   108d0:      	cset	w6, ge
   108d4:      	cmp	x1, #0x35
   108d8:      	cset	w7, le
   108dc:      	cmp	x1, #0x3a
   108e0:      	cset	w8, eq
   108e4:      	cmp	x1, #0x3b
   108e8:      	cset	w9, eq
   108ec:      	cmp	x1, #0x2d
   108f0:      	cset	w10, eq
   108f4:      	cmp	x1, #0x36
   108f8:      	cset	w11, eq
   108fc:      	cmp	x1, #0x37
   10900:      	cset	w12, eq
   10904:      	cmp	x1, #0x38
   10908:      	cset	w13, eq
   1090c:      	cmp	x1, #0x39
   10910:      	cset	w14, eq
   10914:      	uxtb	w16, w19
   10918:      	cmp	w16, wzr
   1091c:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10920:      	uxtb	w16, w21
   10924:      	cmp	w16, wzr
   10928:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   1092c:      	uxtb	w16, w10
   10930:      	cmp	w16, wzr
   10934:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10938:      	uxtb	w16, w11
   1093c:      	cmp	w16, wzr
   10940:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10944:      	uxtb	w16, w12
   10948:      	cmp	w16, wzr
   1094c:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10950:      	uxtb	w16, w13
   10954:      	cmp	w16, wzr
   10958:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   1095c:      	uxtb	w16, w14
   10960:      	cmp	w16, wzr
   10964:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10968:      	uxtb	w16, w8
   1096c:      	cmp	w16, wzr
   10970:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10974:      	uxtb	w16, w9
   10978:      	cmp	w16, wzr
   1097c:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10980:      	uxtb	w16, w6
   10984:      	cmp	w16, wzr
   10988:      	b.eq	0x10b84 <_stogir.vector-arithmetic.valid-type?+0x364>
   1098c:      	uxtb	w16, w7
   10990:      	cmp	w16, wzr
   10994:      	b.eq	0x10b84 <_stogir.vector-arithmetic.valid-type?+0x364>
   10998:      	lsr	w0, w0, #0
   1099c:      	sxtw	x1, w0
   109a0:      	cmp	x1, #0xc
   109a4:      	cset	w22, eq
   109a8:      	cmp	x1, #0xd
   109ac:      	cset	w23, eq
   109b0:      	uxtb	w16, w19
   109b4:      	cmp	w16, wzr
   109b8:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109bc:      	uxtb	w16, w21
   109c0:      	cmp	w16, wzr
   109c4:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109c8:      	uxtb	w16, w10
   109cc:      	cmp	w16, wzr
   109d0:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109d4:      	uxtb	w16, w11
   109d8:      	cmp	w16, wzr
   109dc:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109e0:      	uxtb	w16, w12
   109e4:      	cmp	w16, wzr
   109e8:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109ec:      	uxtb	w16, w13
   109f0:      	cmp	w16, wzr
   109f4:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   109f8:      	uxtb	w16, w14
   109fc:      	cmp	w16, wzr
   10a00:      	b.ne	0x10a90 <_stogir.vector-arithmetic.valid-type?+0x270>
   10a04:      	cmp	x1, #0x1
   10a08:      	cset	w0, eq
   10a0c:      	cmp	x1, #0x1
   10a10:      	cset	w10, ge
   10a14:      	cmp	x1, #0xb
   10a18:      	cset	w1, le
   10a1c:      	uxtb	w16, w6
   10a20:      	cmp	w16, wzr
   10a24:      	b.eq	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10a28:      	uxtb	w16, w7
   10a2c:      	cmp	w16, wzr
   10a30:      	b.eq	0x10af0 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10a34:      	uxtb	w16, w10
   10a38:      	cmp	w16, wzr
   10a3c:      	b.eq	0x10b7c <_stogir.vector-arithmetic.valid-type?+0x35c>
   10a40:      	uxtb	w16, w1
   10a44:      	cmp	w16, wzr
   10a48:      	b.eq	0x10b7c <_stogir.vector-arithmetic.valid-type?+0x35c>
   10a4c:      	uxtb	w16, w0
   10a50:      	cmp	w16, wzr
   10a54:      	cset	x0, eq
   10a58:      	b	0x10b80 <_stogir.vector-arithmetic.valid-type?+0x360>
   10a5c:      	movz	x0, #0x0, lsl #48
   10a60:      	ldr	x19, [sp, #0x10]
   10a64:      	ldr	x20, [sp, #0x18]
   10a68:      	ldr	x21, [sp, #0x20]
   10a6c:      	ldr	x22, [sp, #0x28]
   10a70:      	ldr	x23, [sp, #0x30]
   10a74:      	ldr	x29, [sp]
   10a78:      	ldr	x30, [sp, #0x8]
   10a7c:      	add	sp, sp, #0x40
   10a80:      	ret
   10a84:      	ubfx	x21, x21, #0, #8
   10a88:      	mov	x0, x21
   10a8c:      	b	0x10a60 <_stogir.vector-arithmetic.valid-type?+0x240>
   10a90:      	lsr	w20, w20, #0
   10a94:      	lsr	w0, w0, #0
   10a98:      	mov	w1, w0
   10a9c:      	mov	w0, w20
   10aa0:      	bl	0x10aa0 <_stogir.vector-arithmetic.valid-type?+0x280>
		0000000000010aa0:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   10aa4:      	cmp	x0, #0x0
   10aa8:      	b.eq	0x10ab4 <_stogir.vector-arithmetic.valid-type?+0x294>
   10aac:      	mov	x0, #0x1                ; =1
   10ab0:      	b	0x10a8c <_stogir.vector-arithmetic.valid-type?+0x26c>
   10ab4:      	uxtb	w16, w22
   10ab8:      	cmp	w16, wzr
   10abc:      	b.ne	0x10ad4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10ac0:      	uxtb	w16, w23
   10ac4:      	cmp	w16, wzr
   10ac8:      	b.ne	0x10ad4 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10acc:      	movz	x0, #0x0, lsl #48
   10ad0:      	b	0x10a8c <_stogir.vector-arithmetic.valid-type?+0x26c>
   10ad4:      	uxtb	w16, w19
   10ad8:      	cmp	w16, wzr
   10adc:      	b.eq	0x10a84 <_stogir.vector-arithmetic.valid-type?+0x264>
   10ae0:      	mov	x0, #0x1                ; =1
   10ae4:      	b	0x10a8c <_stogir.vector-arithmetic.valid-type?+0x26c>
   10ae8:      	movz	x0, #0x0, lsl #48
   10aec:      	b	0x10a8c <_stogir.vector-arithmetic.valid-type?+0x26c>
   10af0:      	uxtb	w16, w2
   10af4:      	cmp	w16, wzr
   10af8:      	b.ne	0x10b64 <_stogir.vector-arithmetic.valid-type?+0x344>
   10afc:      	uxtb	w16, w3
   10b00:      	cmp	w16, wzr
   10b04:      	b.ne	0x10b64 <_stogir.vector-arithmetic.valid-type?+0x344>
   10b08:      	uxtb	w16, w4
   10b0c:      	cmp	w16, wzr
   10b10:      	b.ne	0x10b64 <_stogir.vector-arithmetic.valid-type?+0x344>
   10b14:      	uxtb	w16, w22
   10b18:      	cmp	w16, wzr
   10b1c:      	b.ne	0x10bdc <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10b20:      	uxtb	w16, w23
   10b24:      	cmp	w16, wzr
   10b28:      	b.ne	0x10bdc <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10b2c:      	uxtb	w16, w10
   10b30:      	cmp	w16, wzr
   10b34:      	b.eq	0x10bec <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10b38:      	uxtb	w16, w1
   10b3c:      	cmp	w16, wzr
   10b40:      	b.eq	0x10bec <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10b44:      	uxtb	w16, w0
   10b48:      	cmp	w16, wzr
   10b4c:      	b.eq	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x3d4>
   10b50:      	uxtb	w16, w8
   10b54:      	cmp	w16, wzr
   10b58:      	b.eq	0x10bfc <_stogir.vector-arithmetic.valid-type?+0x3dc>
   10b5c:      	mov	x0, #0x1                ; =1
   10b60:      	b	0x10c04 <_stogir.vector-arithmetic.valid-type?+0x3e4>
   10b64:      	uxtb	w16, w10
   10b68:      	cmp	w16, wzr
   10b6c:      	b.eq	0x10ae8 <_stogir.vector-arithmetic.valid-type?+0x2c8>
   10b70:      	ubfx	x1, x1, #0, #8
   10b74:      	mov	x0, x1
   10b78:      	b	0x10aec <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10b7c:      	movz	x0, #0x0, lsl #48
   10b80:      	b	0x10aec <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10b84:      	cmp	x1, #0x1a
   10b88:      	b.eq	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10b8c:      	cmp	x1, #0x1b
   10b90:      	b.eq	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10b94:      	cmp	x1, #0x1c
   10b98:      	b.eq	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10b9c:      	cmp	x1, #0x1d
   10ba0:      	b.eq	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10ba4:      	uxtb	w16, w5
   10ba8:      	cmp	w16, wzr
   10bac:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10bb0:      	uxtb	w16, w2
   10bb4:      	cmp	w16, wzr
   10bb8:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10bbc:      	uxtb	w16, w3
   10bc0:      	cmp	w16, wzr
   10bc4:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10bc8:      	uxtb	w16, w4
   10bcc:      	cmp	w16, wzr
   10bd0:      	b.ne	0x10998 <_stogir.vector-arithmetic.valid-type?+0x178>
   10bd4:      	movz	x0, #0x0, lsl #48
   10bd8:      	b	0x10a8c <_stogir.vector-arithmetic.valid-type?+0x26c>
   10bdc:      	uxtb	w16, w5
   10be0:      	cmp	w16, wzr
   10be4:      	cset	x0, eq
   10be8:      	b	0x10aec <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10bec:      	movz	x0, #0x0, lsl #48
   10bf0:      	b	0x10be8 <_stogir.vector-arithmetic.valid-type?+0x3c8>
   10bf4:      	mov	x0, #0x1                ; =1
   10bf8:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x3d0>
   10bfc:      	ubfx	x9, x9, #0, #8
   10c00:      	mov	x0, x9
   10c04:      	b	0x10bf8 <_stogir.vector-arithmetic.valid-type?+0x3d8>

0000000000010c08 <_coil.core.Len$slice$len__i32>:
   10c08:      	mov	x0, x1
   10c0c:      	ret

0000000000010c10 <_inherent$slice$data__i32>:
   10c10:      	ret

0000000000010c14 <_stogir.opcode.terminator?>:
   10c14:      	sxtw	x0, w0
   10c18:      	cmp	x0, #0x0
   10c1c:      	b.lt	0x10c44 <_stogir.opcode.terminator?+0x30>
   10c20:      	cmp	x0, #0x83
   10c24:      	b.ge	0x10c44 <_stogir.opcode.terminator?+0x30>
   10c28:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x1bc>
		0000000000010c28:  ARM64_RELOC_PAGE21	l_stogir.515
   10c2c:      	ldr	x16, [x16]
		0000000000010c2c:  ARM64_RELOC_PAGEOFF12	l_stogir.515
   10c30:      	orr	x1, x16, xzr
   10c34:      	lsr	x0, x0, #0
   10c38:      	add	x0, x0, x1
   10c3c:      	ldrb	w0, [x0]
   10c40:      	b	0x10c48 <_stogir.opcode.terminator?+0x34>
   10c44:      	movz	x0, #0x0, lsl #48
   10c48:      	uxtb	w0, w0
   10c4c:      	and	x0, x0, #0x8
   10c50:      	uxtb	w0, w0
   10c54:      	cmp	x0, #0x0
   10c58:      	cset	w0, eq
   10c5c:      	uxtb	w16, w0
   10c60:      	cmp	w16, wzr
   10c64:      	cset	x0, eq
   10c68:      	ret

0000000000010c6c <_stogir.switch.sign-mask>:
   10c6c:      	sxtw	x0, w0
   10c70:      	cmp	x0, #0x7
   10c74:      	b.lt	0x10c90 <_stogir.switch.sign-mask+0x24>
   10c78:      	cmp	x0, #0xb
   10c7c:      	b.gt	0x10c90 <_stogir.switch.sign-mask+0x24>
   10c80:      	cmp	x0, #0x0
   10c84:      	b.ne	0x10cc8 <_stogir.switch.sign-mask+0x5c>
   10c88:      	movz	x0, #0x0, lsl #48
   10c8c:      	b	0x10c9c <_stogir.switch.sign-mask+0x30>
   10c90:      	movz	x0, #0x0, lsl #48
   10c94:      	ret
   10c98:      	mov	x0, #0x1                ; =1
   10c9c:      	lsr	w0, w0, #0
   10ca0:      	sxtw	x0, w0
   10ca4:      	lsl	x0, x0, #3
   10ca8:      	lsr	w0, w0, #0
   10cac:      	sxtw	x0, w0
   10cb0:      	sub	x0, x0, #0x1
   10cb4:      	lsr	w0, w0, #0
   10cb8:      	sxtw	x0, w0
   10cbc:      	mov	x16, #0x1               ; =1
   10cc0:      	lsl	x0, x16, x0
   10cc4:      	b	0x10c94 <_stogir.switch.sign-mask+0x28>
   10cc8:      	cmp	x0, #0x1
   10ccc:      	b.eq	0x10c98 <_stogir.switch.sign-mask+0x2c>
   10cd0:      	cmp	x0, #0x2
   10cd4:      	b.eq	0x10c98 <_stogir.switch.sign-mask+0x2c>
   10cd8:      	cmp	x0, #0x7
   10cdc:      	b.eq	0x10c98 <_stogir.switch.sign-mask+0x2c>
   10ce0:      	cmp	x0, #0x8
   10ce4:      	b.eq	0x10c98 <_stogir.switch.sign-mask+0x2c>
   10ce8:      	cmp	x0, #0x3
   10cec:      	b.eq	0x10d48 <_stogir.switch.sign-mask+0xdc>
   10cf0:      	cmp	x0, #0x9
   10cf4:      	b.eq	0x10d48 <_stogir.switch.sign-mask+0xdc>
   10cf8:      	cmp	x0, #0x4
   10cfc:      	b.eq	0x10d50 <_stogir.switch.sign-mask+0xe4>
   10d00:      	cmp	x0, #0xa
   10d04:      	b.eq	0x10d50 <_stogir.switch.sign-mask+0xe4>
   10d08:      	cmp	x0, #0xd
   10d0c:      	b.eq	0x10d50 <_stogir.switch.sign-mask+0xe4>
   10d10:      	cmp	x0, #0x5
   10d14:      	b.eq	0x10d58 <_stogir.switch.sign-mask+0xec>
   10d18:      	cmp	x0, #0xb
   10d1c:      	b.eq	0x10d58 <_stogir.switch.sign-mask+0xec>
   10d20:      	cmp	x0, #0xc
   10d24:      	b.eq	0x10d58 <_stogir.switch.sign-mask+0xec>
   10d28:      	cmp	x0, #0x6
   10d2c:      	cset	w0, eq
   10d30:      	uxtb	w16, w0
   10d34:      	cmp	w16, wzr
   10d38:      	mov	x16, #0x8               ; =8
   10d3c:      	movn	x17, #0x0, lsl #48
   10d40:      	csel	x0, x16, x17, ne
   10d44:      	b	0x10d5c <_stogir.switch.sign-mask+0xf0>
   10d48:      	mov	x0, #0x2                ; =2
   10d4c:      	b	0x10c9c <_stogir.switch.sign-mask+0x30>
   10d50:      	mov	x0, #0x4                ; =4
   10d54:      	b	0x10d4c <_stogir.switch.sign-mask+0xe0>
   10d58:      	mov	x0, #0x8                ; =8
   10d5c:      	b	0x10d54 <_stogir.switch.sign-mask+0xe8>
