
/Users/jimmyhmiller/Documents/Code/projects/coil-stogir/.worktrees/symbol-cast-placement/build/hot-code-audit/before-verify.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <_gap_verify_graph>:
       0:      	sub	sp, sp, #0x1e0
       4:      	str	x29, [sp]
       8:      	str	x30, [sp, #0x8]
       c:      	mov	x29, sp
      10:      	str	x19, [sp, #0x1d0]
      14:      	add	x8, sp, #0x10
      18:      	mov	x19, x0
      1c:      	mov	x1, #0x8                ; =8
      20:      	bl	0x20 <_gap_verify_graph+0x20>
		0000000000000020:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target
      24:      	add	x16, sp, #0x10
      28:      	ldr	w0, [x16]
      2c:      	lsr	x16, x0, #0
      30:      	cmp	x16, #0x1
      34:      	b.eq	0x50 <_gap_verify_graph+0x50>
      38:      	b.lo	0x40 <_gap_verify_graph+0x40>
      3c:      	b	0x54 <_gap_verify_graph+0x54>
      40:      	cmp	x16, #0x0
      44:      	b.eq	0x4c <_gap_verify_graph+0x4c>
      48:      	b	0x54 <_gap_verify_graph+0x54>
      4c:      	b	0x60 <_gap_verify_graph+0x60>
      50:      	b	0x58 <_gap_verify_graph+0x58>
      54:      	b	0xa8 <_gap_verify_graph+0xa8>
      58:      	movn	x0, #0x0, lsl #48
      5c:      	b	0x94 <_gap_verify_graph+0x94>
      60:      	movz	x0, #0x0, lsl #48
      64:      	b	0x84 <_gap_verify_graph+0x84>
      68:      	add	x1, x0, #0x8
      6c:      	add	x16, sp, #0x30
      70:      	add	x2, x16, x0
      74:      	add	x0, x19, x0
      78:      	ldr	x0, [x0]
      7c:      	str	x0, [x2]
      80:      	mov	x0, x1
      84:      	cmp	x0, #0x1a0
      88:      	b.lo	0x68 <_gap_verify_graph+0x68>
      8c:      	add	x16, sp, #0x30
      90:      	ldr	x0, [x16, #0x8]
      94:      	ldr	x19, [sp, #0x1d0]
      98:      	ldr	x29, [sp]
      9c:      	ldr	x30, [sp, #0x8]
      a0:      	add	sp, sp, #0x1e0
      a4:      	ret
      a8:      	brk	#0
      ac:      	b	0xa8 <_gap_verify_graph+0xa8>

00000000000000b0 <_stogir.verify.integer-operations-target>:
      b0:      	sub	sp, sp, #0x70
      b4:      	str	x29, [sp]
      b8:      	str	x30, [sp, #0x8]
      bc:      	mov	x29, sp
      c0:      	str	x19, [sp, #0x50]
      c4:      	str	x20, [sp, #0x58]
      c8:      	str	x21, [sp, #0x60]
      cc:      	mov	x19, x8
      d0:      	add	x8, sp, #0x10
      d4:      	mov	x20, x0
      d8:      	mov	w21, w1
      dc:      	bl	0xdc <_stogir.verify.integer-operations-target+0x2c>
		00000000000000dc:  ARM64_RELOC_BRANCH26	_stogir.verify.structure
      e0:      	add	x16, sp, #0x10
      e4:      	ldr	w0, [x16]
      e8:      	lsr	x16, x0, #0
      ec:      	cmp	x16, #0x1
      f0:      	b.eq	0x10c <_stogir.verify.integer-operations-target+0x5c>
      f4:      	b.lo	0xfc <_stogir.verify.integer-operations-target+0x4c>
      f8:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
      fc:      	cmp	x16, #0x0
     100:      	b.eq	0x108 <_stogir.verify.integer-operations-target+0x58>
     104:      	b	0x110 <_stogir.verify.integer-operations-target+0x60>
     108:      	b	0x138 <_stogir.verify.integer-operations-target+0x88>
     10c:      	b	0x114 <_stogir.verify.integer-operations-target+0x64>
     110:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>
     114:      	add	x16, sp, #0x10
     118:      	orr	x0, x16, xzr
     11c:      	add	x0, x0, #0x8
     120:      	add	x16, sp, #0x10
     124:      	ldr	x1, [x16, #0x8]
     128:      	ldr	x0, [x0, #0x8]
     12c:      	mov	x2, x0
     130:      	mov	x0, #0x1                ; =1
     134:      	b	0x164 <_stogir.verify.integer-operations-target+0xb4>
     138:      	lsr	w21, w21, #0
     13c:      	add	x8, sp, #0x30
     140:      	mov	x0, x20
     144:      	mov	w1, w21
     148:      	bl	0x148 <_stogir.verify.integer-operations-target+0x98>
		0000000000000148:  ARM64_RELOC_BRANCH26	_stogir.verify.integer-operations-target-structured
     14c:      	add	x16, sp, #0x30
     150:      	ldr	x0, [x16]
     154:      	add	x16, sp, #0x30
     158:      	ldr	x1, [x16, #0x8]
     15c:      	add	x16, sp, #0x30
     160:      	ldr	x2, [x16, #0x10]
     164:      	str	x0, [x19]
     168:      	str	x1, [x19, #0x8]
     16c:      	str	x2, [x19, #0x10]
     170:      	ldr	x19, [sp, #0x50]
     174:      	ldr	x20, [sp, #0x58]
     178:      	ldr	x21, [sp, #0x60]
     17c:      	ldr	x29, [sp]
     180:      	ldr	x30, [sp, #0x8]
     184:      	add	sp, sp, #0x70
     188:      	ret
     18c:      	brk	#0
     190:      	b	0x18c <_stogir.verify.integer-operations-target+0xdc>

0000000000000194 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.node.Node>:
     194:      	ldr	x0, [x0, #0x8]
     198:      	ret
     19c:      	udf	#0x0

00000000000001a0 <_stogir.verify.structure>:
     1a0:      	sub	sp, sp, #0x180
     1a4:      	str	x29, [sp, #0x10]
     1a8:      	str	x30, [sp, #0x18]
     1ac:      	add	x29, sp, #0x10
     1b0:      	str	x19, [sp, #0x130]
     1b4:      	str	x20, [sp, #0x138]
     1b8:      	str	x21, [sp, #0x140]
     1bc:      	str	x22, [sp, #0x148]
     1c0:      	str	x23, [sp, #0x150]
     1c4:      	str	x24, [sp, #0x158]
     1c8:      	str	x25, [sp, #0x160]
     1cc:      	str	x26, [sp, #0x168]
     1d0:      	str	x27, [sp, #0x170]
     1d4:      	str	x28, [sp, #0x178]
     1d8:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000001d8:  ARM64_RELOC_PAGE21	l_stogir.304
     1dc:      	ldr	x16, [x16]
		00000000000001dc:  ARM64_RELOC_PAGEOFF12	l_stogir.304
     1e0:      	orr	x19, x16, xzr
     1e4:      	add	x1, x0, #0x78
     1e8:      	ldr	x20, [x0, #0x8]
     1ec:      	mov	x21, x8
     1f0:      	mov	x22, x0
     1f4:      	mov	x0, x1
     1f8:      	bl	0x1f8 <_stogir.verify.structure+0x58>
		00000000000001f8:  ARM64_RELOC_BRANCH26	_coil.core.Len$coil.arraylist.ArrayList$len__i32
     1fc:      	cmp	x20, x0
     200:      	b.ne	0x55c <_stogir.verify.structure+0x3bc>
     204:      	mov	x0, x19
     208:      	movz	x1, #0x0, lsl #48
     20c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000020c:  ARM64_RELOC_PAGE21	l_stogir.305
     210:      	ldr	x16, [x16]
		0000000000000210:  ARM64_RELOC_PAGEOFF12	l_stogir.305
     214:      	orr	x20, x16, xzr
     218:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000218:  ARM64_RELOC_PAGE21	l_stogir.306
     21c:      	ldr	x16, [x16]
		000000000000021c:  ARM64_RELOC_PAGEOFF12	l_stogir.306
     220:      	orr	x23, x16, xzr
     224:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000224:  ARM64_RELOC_PAGE21	l_stogir.307
     228:      	ldr	x16, [x16]
		0000000000000228:  ARM64_RELOC_PAGEOFF12	l_stogir.307
     22c:      	orr	x24, x16, xzr
     230:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000230:  ARM64_RELOC_PAGE21	l_stogir.308
     234:      	ldr	x16, [x16]
		0000000000000234:  ARM64_RELOC_PAGEOFF12	l_stogir.308
     238:      	orr	x25, x16, xzr
     23c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000023c:  ARM64_RELOC_PAGE21	l_stogir.309
     240:      	ldr	x16, [x16]
		0000000000000240:  ARM64_RELOC_PAGEOFF12	l_stogir.309
     244:      	orr	x26, x16, xzr
     248:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000248:  ARM64_RELOC_PAGE21	l_stogir.310
     24c:      	ldr	x16, [x16]
		000000000000024c:  ARM64_RELOC_PAGEOFF12	l_stogir.310
     250:      	orr	x27, x16, xzr
     254:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000254:  ARM64_RELOC_PAGE21	l_stogir.311
     258:      	ldr	x16, [x16]
		0000000000000258:  ARM64_RELOC_PAGEOFF12	l_stogir.311
     25c:      	orr	x28, x16, xzr
     260:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000260:  ARM64_RELOC_PAGE21	l_stogir.312
     264:      	ldr	x16, [x16]
		0000000000000264:  ARM64_RELOC_PAGEOFF12	l_stogir.312
     268:      	orr	x2, x16, xzr
     26c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000026c:  ARM64_RELOC_PAGE21	l_stogir.313
     270:      	ldr	x16, [x16]
		0000000000000270:  ARM64_RELOC_PAGEOFF12	l_stogir.313
     274:      	orr	x3, x16, xzr
     278:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000278:  ARM64_RELOC_PAGE21	l_stogir.314
     27c:      	ldr	x16, [x16]
		000000000000027c:  ARM64_RELOC_PAGEOFF12	l_stogir.314
     280:      	orr	x4, x16, xzr
     284:      	add	x5, x22, #0x110
     288:      	add	x6, x22, #0x78
     28c:      	add	x7, x22, #0x28
     290:      	add	x8, x22, #0x50
     294:      	add	x9, x22, #0x78
     298:      	add	x10, x22, #0x28
     29c:      	add	x11, x22, #0x50
     2a0:      	add	x12, x5, #0x28
     2a4:      	mov	x13, x0
     2a8:      	mov	x14, x1
     2ac:      	mov	x0, #0x1                ; =1
     2b0:      	movz	x1, #0x0, lsl #48
     2b4:      	b	0x348 <_stogir.verify.structure+0x1a8>
     2b8:      	mov	x1, x19
     2bc:      	ldr	x2, [sp, #0x58]
     2c0:      	mov	x3, #0x16               ; =22
     2c4:      	b	0x2f0 <_stogir.verify.structure+0x150>
     2c8:      	mov	x0, x21
     2cc:      	str	x19, [sp, #0xc8]
     2d0:      	ldr	x19, [sp, #0x90]
     2d4:      	str	x28, [sp, #0xd0]
     2d8:      	mov	x21, x20
     2dc:      	str	x23, [sp, #0xb0]
     2e0:      	str	x24, [sp, #0xa8]
     2e4:      	mov	x1, x19
     2e8:      	ldr	x2, [sp, #0x50]
     2ec:      	mov	x3, #0x23               ; =35
     2f0:      	ldr	x19, [sp, #0x48]
     2f4:      	ldr	x20, [sp, #0x50]
     2f8:      	ldr	x23, [sp, #0x58]
     2fc:      	ldr	x24, [sp, #0x60]
     300:      	ldr	x28, [sp, #0x80]
     304:      	ldr	x4, [sp, #0x40]
     308:      	ldr	x5, [sp, #0xc8]
     30c:      	ldr	x12, [sp, #0xd0]
     310:      	mov	x6, x21
     314:      	ldr	x21, [sp, #0x88]
     318:      	ldr	x7, [sp, #0xb0]
     31c:      	ldr	x8, [sp, #0xa8]
     320:      	mov	x9, x25
     324:      	ldr	x25, [sp, #0x68]
     328:      	mov	x10, x26
     32c:      	ldr	x26, [sp, #0x70]
     330:      	mov	x11, x27
     334:      	ldr	x27, [sp, #0x78]
     338:      	mov	x13, x2
     33c:      	ldr	x2, [sp, #0x30]
     340:      	mov	x14, x3
     344:      	ldr	x3, [sp, #0x38]
     348:      	str	x2, [sp, #0x30]
     34c:      	mov	x2, x19
     350:      	str	x3, [sp, #0x38]
     354:      	str	x4, [sp, #0x40]
     358:      	str	x1, [sp, #0x90]
     35c:      	mov	x1, x14
     360:      	str	x13, [sp, #0x98]
     364:      	str	x14, [sp, #0xa0]
     368:      	str	x19, [sp, #0x48]
     36c:      	mov	x19, x5
     370:      	str	x20, [sp, #0x50]
     374:      	mov	x20, x6
     378:      	str	x23, [sp, #0x58]
     37c:      	mov	x23, x7
     380:      	str	x24, [sp, #0x60]
     384:      	mov	x24, x8
     388:      	str	x25, [sp, #0x68]
     38c:      	mov	x25, x9
     390:      	str	x26, [sp, #0x70]
     394:      	mov	x26, x10
     398:      	str	x27, [sp, #0x78]
     39c:      	mov	x27, x11
     3a0:      	str	x28, [sp, #0x80]
     3a4:      	mov	x28, x12
     3a8:      	str	x21, [sp, #0x88]
     3ac:      	mov	x21, x0
     3b0:      	mov	x0, x13
     3b4:      	movz	x3, #0x0, lsl #48
     3b8:      	bl	0x3b8 <_stogir.verify.structure+0x218>
		00000000000003b8:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     3bc:      	cmp	x0, #0x0
     3c0:      	b.eq	0xd58 <_stogir.verify.structure+0xbb8>
     3c4:      	ldr	x0, [x22, #0x8]
     3c8:      	cmp	x21, x0
     3cc:      	b.ge	0xd60 <_stogir.verify.structure+0xbc0>
     3d0:      	lsl	x0, x21, #4
     3d4:      	lsl	x1, x21, #2
     3d8:      	ldr	x2, [x22]
     3dc:      	add	x0, x0, x2
     3e0:      	ldr	x0, [x0]
     3e4:      	ldr	x2, [x22, #0x78]
     3e8:      	add	x1, x1, x2
     3ec:      	ldr	w1, [x1]
     3f0:      	sxtw	x1, w1
     3f4:      	cmp	x1, #0x0
     3f8:      	b.lt	0x2c8 <_stogir.verify.structure+0x128>
     3fc:      	mov	x17, #0xffff            ; =65535
     400:      	cmp	x1, x17
     404:      	b.gt	0xd68 <_stogir.verify.structure+0xbc8>
     408:      	uxtb	w2, w0
     40c:      	orr	x3, x2, xzr
     410:      	lsr	w3, w3, #0
     414:      	str	w3, [sp, #0xc0]
     418:      	str	x24, [sp, #0xa8]
     41c:      	mov	x24, x0
     420:      	mov	w0, w3
     424:      	str	x23, [sp, #0xb0]
     428:      	mov	x23, x1
     42c:      	str	x20, [sp, #0xb8]
     430:      	mov	w20, w2
     434:      	bl	0x434 <_stogir.verify.structure+0x294>
		0000000000000434:  ARM64_RELOC_BRANCH26	_stogir.opcode.valid?
     438:      	cmp	x0, #0x0
     43c:      	b.eq	0xd88 <_stogir.verify.structure+0xbe8>
     440:      	lsr	w24, w24, #0
     444:      	ubfx	x0, x24, #8, #8
     448:      	orr	x1, x0, xzr
     44c:      	lsr	w1, w1, #0
     450:      	str	x19, [sp, #0xc8]
     454:      	mov	w19, w0
     458:      	mov	w0, w1
     45c:      	bl	0x45c <_stogir.verify.structure+0x2bc>
		000000000000045c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
     460:      	cmp	x0, #0x0
     464:      	b.eq	0xda0 <_stogir.verify.structure+0xc00>
     468:      	ldr	w0, [sp, #0xc0]
     46c:      	bl	0x46c <_stogir.verify.structure+0x2cc>
		000000000000046c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     470:      	lsr	w0, w0, #0
     474:      	sxtw	x0, w0
     478:      	cmp	x0, #0x0
     47c:      	b.lt	0xb0c <_stogir.verify.structure+0x96c>
     480:      	ldr	w0, [sp, #0xc0]
     484:      	bl	0x484 <_stogir.verify.structure+0x2e4>
		0000000000000484:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-slots
     488:      	lsr	w0, w0, #0
     48c:      	sxtw	x0, w0
     490:      	cmp	x23, x0
     494:      	b.eq	0xb0c <_stogir.verify.structure+0x96c>
     498:      	str	x28, [sp, #0xd0]
     49c:      	mov	x0, x21
     4a0:      	ldr	x21, [sp, #0xb8]
     4a4:      	ldr	x1, [sp, #0x90]
     4a8:      	ldr	x2, [sp, #0x60]
     4ac:      	mov	x3, #0x23               ; =35
     4b0:      	b	0x558 <_stogir.verify.structure+0x3b8>
     4b4:      	ldr	x0, [sp, #0x98]
     4b8:      	ldr	x1, [sp, #0xa0]
     4bc:      	ldr	x2, [sp, #0x48]
     4c0:      	movz	x3, #0x0, lsl #48
     4c4:      	bl	0x4c4 <_stogir.verify.structure+0x324>
		00000000000004c4:  ARM64_RELOC_BRANCH26	_coil.core.Eq$slice<u8>$=
     4c8:      	cmp	x0, #0x0
     4cc:      	b.eq	0x4e4 <_stogir.verify.structure+0x344>
     4d0:      	and	x0, x19, #0xffffffff
     4d4:      	mov	x1, x0
     4d8:      	movz	x0, #0x0, lsl #48
     4dc:      	movz	x2, #0x0, lsl #48
     4e0:      	b	0x4f0 <_stogir.verify.structure+0x350>
     4e4:      	ldr	x1, [sp, #0x98]
     4e8:      	ldr	x2, [sp, #0xa0]
     4ec:      	mov	x0, #0x1                ; =1
     4f0:      	ldr	x3, [sp, #0x88]
     4f4:      	str	x0, [x3]
     4f8:      	str	x1, [x3, #0x8]
     4fc:      	str	x2, [x3, #0x10]
     500:      	ldr	x19, [sp, #0x130]
     504:      	ldr	x20, [sp, #0x138]
     508:      	ldr	x21, [sp, #0x140]
     50c:      	ldr	x22, [sp, #0x148]
     510:      	ldr	x23, [sp, #0x150]
     514:      	ldr	x24, [sp, #0x158]
     518:      	ldr	x25, [sp, #0x160]
     51c:      	ldr	x26, [sp, #0x168]
     520:      	ldr	x27, [sp, #0x170]
     524:      	ldr	x28, [sp, #0x178]
     528:      	ldr	x29, [sp, #0x10]
     52c:      	ldr	x30, [sp, #0x18]
     530:      	add	sp, sp, #0x180
     534:      	ret
     538:      	ldr	x0, [sp, #0x118]
     53c:      	add	x0, x24, x0
     540:      	ldr	x19, [sp, #0x90]
     544:      	add	x1, x19, #0x1
     548:      	lsr	w1, w1, #0
     54c:      	sxtw	x1, w1
     550:      	ldr	x2, [sp, #0x100]
     554:      	ldr	x3, [sp, #0x108]
     558:      	b	0x2c4 <_stogir.verify.structure+0x124>
     55c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000055c:  ARM64_RELOC_PAGE21	l_stogir.315
     560:      	ldr	x16, [x16]
		0000000000000560:  ARM64_RELOC_PAGEOFF12	l_stogir.315
     564:      	orr	x0, x16, xzr
     568:      	mov	x1, #0x2c               ; =44
     56c:      	b	0x20c <_stogir.verify.structure+0x6c>
     570:      	mov	x11, x9
     574:      	movz	x9, #0x0, lsl #48
     578:      	cmp	x9, #0x0
     57c:      	b.eq	0xdb4 <_stogir.verify.structure+0xc14>
     580:      	cmp	x0, #0x0
     584:      	b.eq	0xbe8 <_stogir.verify.structure+0xa48>
     588:      	ldr	x21, [sp, #0xb8]
     58c:      	ldr	x0, [sp, #0xb0]
     590:      	ldr	x4, [sp, #0xa8]
     594:      	mov	x3, x7
     598:      	mov	x5, x11
     59c:      	b	0xb74 <_stogir.verify.structure+0x9d4>
     5a0:      	mov	x0, x1
     5a4:      	ldr	x1, [sp, #0x120]
     5a8:      	b	0x5b4 <_stogir.verify.structure+0x414>
     5ac:      	mov	x0, x11
     5b0:      	ldr	x1, [sp, #0x120]
     5b4:      	b	0x6c4 <_stogir.verify.structure+0x524>
     5b8:      	lsr	x3, x2, #0
     5bc:      	str	x1, [sp, #0xf0]
     5c0:      	str	x2, [sp, #0xf8]
     5c4:      	mov	x2, x3
     5c8:      	str	w28, [sp, #0xe8]
     5cc:      	mov	x28, x0
     5d0:      	mov	x0, x1
     5d4:      	ldr	x1, [sp, #0x48]
     5d8:      	bl	0x5d8 <_stogir.verify.structure+0x438>
		00000000000005d8:  ARM64_RELOC_BRANCH26	_memcmp
     5dc:      	lsr	w0, w0, #0
     5e0:      	sxtw	x0, w0
     5e4:      	cmp	x0, #0x0
     5e8:      	cset	w0, eq
     5ec:      	ubfx	x0, x0, #0, #8
     5f0:      	ldr	x1, [sp, #0xf0]
     5f4:      	ldr	x2, [sp, #0xf8]
     5f8:      	b	0x608 <_stogir.verify.structure+0x468>
     5fc:      	ldr	x1, [sp, #0xf0]
     600:      	ldr	x2, [sp, #0xf8]
     604:      	movz	x0, #0x0, lsl #48
     608:      	cmp	x0, #0x0
     60c:      	b.eq	0x620 <_stogir.verify.structure+0x480>
     610:      	cmp	x28, x23
     614:      	cset	w0, le
     618:      	ubfx	x0, x0, #0, #8
     61c:      	b	0x624 <_stogir.verify.structure+0x484>
     620:      	movz	x0, #0x0, lsl #48
     624:      	cmp	x0, #0x0
     628:      	b.eq	0xdc8 <_stogir.verify.structure+0xc28>
     62c:      	lsr	w0, w28, #0
     630:      	str	x1, [sp, #0x100]
     634:      	mov	w1, w0
     638:      	str	x2, [sp, #0x108]
     63c:      	str	x23, [sp, #0x110]
     640:      	mov	w23, w0
     644:      	ldr	w0, [sp, #0xc0]
     648:      	bl	0x648 <_stogir.verify.structure+0x4a8>
		0000000000000648:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     64c:      	add	x16, sp, #0x20
     650:      	str	x16, [sp]
     654:      	ldr	w1, [sp, #0xe8]
     658:      	mov	w2, w23
     65c:      	str	x21, [sp, #0x118]
     660:      	mov	x21, x0
     664:      	mov	x0, x22
     668:      	bl	0x668 <_stogir.verify.structure+0x4c8>
		0000000000000668:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
     66c:      	ldr	x16, [sp]
     670:      	str	x0, [x16]
     674:      	str	x1, [x16, #0x8]
     678:      	add	x16, sp, #0x20
     67c:      	ldr	x0, [x16]
     680:      	add	x16, sp, #0x20
     684:      	ldr	x1, [x16, #0x8]
     688:      	lsr	w0, w0, #0
     68c:      	lsr	x16, x0, #0
     690:      	cmp	x16, #0x1
     694:      	b.eq	0x6b0 <_stogir.verify.structure+0x510>
     698:      	b.lo	0x6a0 <_stogir.verify.structure+0x500>
     69c:      	b	0x6b4 <_stogir.verify.structure+0x514>
     6a0:      	cmp	x16, #0x0
     6a4:      	b.eq	0x6ac <_stogir.verify.structure+0x50c>
     6a8:      	b	0x6b4 <_stogir.verify.structure+0x514>
     6ac:      	b	0x6b8 <_stogir.verify.structure+0x518>
     6b0:      	b	0x718 <_stogir.verify.structure+0x578>
     6b4:      	b	0xcf0 <_stogir.verify.structure+0xb50>
     6b8:      	ldr	x21, [sp, #0xb8]
     6bc:      	ldr	x0, [sp, #0x80]
     6c0:      	mov	x1, #0x17               ; =23
     6c4:      	add	x2, x28, #0x1
     6c8:      	lsr	w2, w2, #0
     6cc:      	sxtw	x2, w2
     6d0:      	ldr	x23, [sp, #0x110]
     6d4:      	ldr	w28, [sp, #0xe8]
     6d8:      	str	x21, [sp, #0xb8]
     6dc:      	ldr	x21, [sp, #0x118]
     6e0:      	fmov	d31, x0
     6e4:      	mov	x0, x2
     6e8:      	mov	x2, x1
     6ec:      	fmov	x1, d31
     6f0:      	cmp	x2, #0x0
     6f4:      	b.ne	0xddc <_stogir.verify.structure+0xc3c>
     6f8:      	cmp	x2, #0x0
     6fc:      	b.ne	0x5b8 <_stogir.verify.structure+0x418>
     700:      	str	w28, [sp, #0xe8]
     704:      	mov	x28, x0
     708:      	str	x1, [sp, #0xf0]
     70c:      	str	x2, [sp, #0xf8]
     710:      	mov	x0, #0x1                ; =1
     714:      	b	0x5f0 <_stogir.verify.structure+0x450>
     718:      	lsr	w21, w21, #0
     71c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000071c:  ARM64_RELOC_PAGE21	l_stogir.316
     720:      	ldr	x16, [x16]
		0000000000000720:  ARM64_RELOC_PAGEOFF12	l_stogir.316
     724:      	ldr	w0, [x16]
     728:      	orr	x2, x21, xzr
     72c:      	cmp	x2, x0
     730:      	b.ne	0x73c <_stogir.verify.structure+0x59c>
     734:      	mov	x0, #0x1                ; =1
     738:      	b	0x754 <_stogir.verify.structure+0x5b4>
     73c:      	adrp	x16, 0x0 <_gap_verify_graph>
		000000000000073c:  ARM64_RELOC_PAGE21	l_stogir.317
     740:      	ldr	x16, [x16]
		0000000000000740:  ARM64_RELOC_PAGEOFF12	l_stogir.317
     744:      	ldr	w0, [x16]
     748:      	cmp	x2, x0
     74c:      	cset	w0, eq
     750:      	ubfx	x0, x0, #0, #8
     754:      	lsr	w1, w1, #0
     758:      	sxtw	x1, w1
     75c:      	cmp	x1, #0x0
     760:      	cset	w3, gt
     764:      	lsl	x4, x1, #2
     768:      	cmp	x1, #0x0
     76c:      	cset	w5, lt
     770:      	movz	x16, #0x0, lsl #48
     774:      	sub	x6, x16, x1
     778:      	sub	x7, x6, #0x1
     77c:      	lsl	x8, x7, #2
     780:      	cmp	x0, #0x0
     784:      	b.eq	0x7cc <_stogir.verify.structure+0x62c>
     788:      	uxtb	w16, w3
     78c:      	cmp	w16, wzr
     790:      	b.eq	0xa4c <_stogir.verify.structure+0x8ac>
     794:      	ldr	x9, [x22, #0x8]
     798:      	cmp	x1, x9
     79c:      	b.ge	0xa90 <_stogir.verify.structure+0x8f0>
     7a0:      	ldr	x9, [x25, #0x8]
     7a4:      	cmp	x1, x9
     7a8:      	b.ge	0xc4c <_stogir.verify.structure+0xaac>
     7ac:      	ldr	x9, [x22, #0x78]
     7b0:      	add	x9, x4, x9
     7b4:      	ldr	w9, [x9]
     7b8:      	sxtw	x9, w9
     7bc:      	cmp	x9, #0x0
     7c0:      	cset	w9, ge
     7c4:      	ubfx	x9, x9, #0, #8
     7c8:      	b	0xc50 <_stogir.verify.structure+0xab0>
     7cc:      	ldr	x9, [sp, #0x100]
     7d0:      	ldr	x10, [sp, #0x108]
     7d4:      	movz	x7, #0x0, lsl #48
     7d8:      	b	0x7f0 <_stogir.verify.structure+0x650>
     7dc:      	ldr	x7, [sp, #0x100]
     7e0:      	ldr	x10, [sp, #0x108]
     7e4:      	fmov	d31, x7
     7e8:      	mov	x7, x9
     7ec:      	fmov	x9, d31
     7f0:      	adrp	x16, 0x0 <_gap_verify_graph>
		00000000000007f0:  ARM64_RELOC_PAGE21	l_stogir.318
     7f4:      	ldr	x16, [x16]
		00000000000007f4:  ARM64_RELOC_PAGEOFF12	l_stogir.318
     7f8:      	ldr	w11, [x16]
     7fc:      	cmp	x2, x11
     800:      	b.ne	0xdf0 <_stogir.verify.structure+0xc50>
     804:      	cmp	x1, #0x0
     808:      	b.gt	0x9ec <_stogir.verify.structure+0x84c>
     80c:      	ldr	x12, [sp, #0xc8]
     810:      	ldr	x2, [sp, #0xd0]
     814:      	mov	x11, x9
     818:      	movz	x9, #0x0, lsl #48
     81c:      	lsr	w9, w9, #0
     820:      	lsr	x16, x9, #0
     824:      	cmp	x16, #0x1
     828:      	b.eq	0x844 <_stogir.verify.structure+0x6a4>
     82c:      	b.lo	0x834 <_stogir.verify.structure+0x694>
     830:      	b	0x848 <_stogir.verify.structure+0x6a8>
     834:      	cmp	x16, #0x0
     838:      	b.eq	0x840 <_stogir.verify.structure+0x6a0>
     83c:      	b	0x848 <_stogir.verify.structure+0x6a8>
     840:      	b	0x84c <_stogir.verify.structure+0x6ac>
     844:      	b	0x858 <_stogir.verify.structure+0x6b8>
     848:      	b	0xd50 <_stogir.verify.structure+0xbb0>
     84c:      	ldr	x9, [sp, #0x38]
     850:      	mov	x10, #0x21              ; =33
     854:      	b	0x85c <_stogir.verify.structure+0x6bc>
     858:      	mov	x9, x11
     85c:      	cmp	x21, #0xf
     860:      	b.hs	0x570 <_stogir.verify.structure+0x3d0>
     864:      	mov	x16, #0x1               ; =1
     868:      	lsl	x11, x16, x21
     86c:      	lsr	w11, w11, #0
     870:      	mov	x17, #0x5e1c            ; =24092
     874:      	and	x11, x11, x17
     878:      	lsr	w11, w11, #0
     87c:      	cmp	x11, #0x0
     880:      	cset	w11, eq
     884:      	uxtb	w16, w11
     888:      	cmp	w16, wzr
     88c:      	cset	x11, eq
     890:      	fmov	d31, x9
     894:      	mov	x9, x11
     898:      	fmov	x11, d31
     89c:      	b	0x578 <_stogir.verify.structure+0x3d8>
     8a0:      	lsr	w0, w21, #0
     8a4:      	lsr	w28, w0, #0
     8a8:      	cmp	x20, #0x78
     8ac:      	cset	w20, eq
     8b0:      	cmp	x19, #0x0
     8b4:      	cset	w19, eq
     8b8:      	mov	x2, x1
     8bc:      	ldr	x1, [sp, #0xd8]
     8c0:      	mov	x0, #0x1                ; =1
     8c4:      	b	0x6f0 <_stogir.verify.structure+0x550>
     8c8:      	ldr	x0, [sp, #0x78]
     8cc:      	mov	x1, #0x1b               ; =27
     8d0:      	b	0x964 <_stogir.verify.structure+0x7c4>
     8d4:      	lsr	x3, x2, #0
     8d8:      	str	x1, [sp, #0xd8]
     8dc:      	str	x2, [sp, #0xe0]
     8e0:      	mov	x2, x3
     8e4:      	str	x28, [sp, #0xd0]
     8e8:      	mov	x28, x0
     8ec:      	mov	x0, x1
     8f0:      	ldr	x1, [sp, #0x48]
     8f4:      	bl	0x8f4 <_stogir.verify.structure+0x754>
		00000000000008f4:  ARM64_RELOC_BRANCH26	_memcmp
     8f8:      	lsr	w0, w0, #0
     8fc:      	sxtw	x0, w0
     900:      	cmp	x0, #0x0
     904:      	cset	w0, eq
     908:      	ubfx	x0, x0, #0, #8
     90c:      	ldr	x1, [sp, #0xe0]
     910:      	b	0x91c <_stogir.verify.structure+0x77c>
     914:      	ldr	x1, [sp, #0xe0]
     918:      	movz	x0, #0x0, lsl #48
     91c:      	cmp	x0, #0x0
     920:      	b.eq	0x934 <_stogir.verify.structure+0x794>
     924:      	cmp	x28, x24
     928:      	cset	w0, lt
     92c:      	ubfx	x0, x0, #0, #8
     930:      	b	0x938 <_stogir.verify.structure+0x798>
     934:      	movz	x0, #0x0, lsl #48
     938:      	cmp	x0, #0x0
     93c:      	b.eq	0x8a0 <_stogir.verify.structure+0x700>
     940:      	add	x0, x28, x21
     944:      	ldr	x2, [x22, #0x78]
     948:      	lsl	x0, x0, #2
     94c:      	add	x0, x0, x2
     950:      	ldr	w0, [x0]
     954:      	sxtw	x0, w0
     958:      	cmn	x0, #0x1
     95c:      	b.ne	0x8c8 <_stogir.verify.structure+0x728>
     960:      	ldr	x0, [sp, #0xd8]
     964:      	add	x2, x28, #0x1
     968:      	ldr	x28, [sp, #0xd0]
     96c:      	fmov	d31, x0
     970:      	mov	x0, x2
     974:      	mov	x2, x1
     978:      	fmov	x1, d31
     97c:      	cmp	x2, #0x0
     980:      	b.ne	0xdfc <_stogir.verify.structure+0xc5c>
     984:      	cmp	x2, #0x0
     988:      	b.ne	0x8d4 <_stogir.verify.structure+0x734>
     98c:      	str	x28, [sp, #0xd0]
     990:      	mov	x28, x0
     994:      	str	x1, [sp, #0xd8]
     998:      	str	x2, [sp, #0xe0]
     99c:      	mov	x0, #0x1                ; =1
     9a0:      	b	0x90c <_stogir.verify.structure+0x76c>
     9a4:      	ldr	x0, [sp, #0x98]
     9a8:      	ldr	x1, [sp, #0xa0]
     9ac:      	add	x2, x23, #0x4
     9b0:      	ldr	x3, [x22, #0x8]
     9b4:      	asr	x16, x2, #63
     9b8:      	lsr	x16, x16, #62
     9bc:      	add	x2, x2, x16
     9c0:      	asr	x2, x2, #2
     9c4:      	orr	x24, x2, xzr
     9c8:      	add	x2, x24, x21
     9cc:      	cmp	x2, x3
     9d0:      	b.le	0x9dc <_stogir.verify.structure+0x83c>
     9d4:      	ldr	x0, [sp, #0x70]
     9d8:      	mov	x1, #0x15               ; =21
     9dc:      	mov	x2, x1
     9e0:      	mov	x1, x0
     9e4:      	mov	x0, #0x1                ; =1
     9e8:      	b	0x97c <_stogir.verify.structure+0x7dc>
     9ec:      	ldr	x2, [sp, #0xd0]
     9f0:      	ldr	x11, [x2, #0x8]
     9f4:      	cmp	x1, x11
     9f8:      	b.gt	0xe10 <_stogir.verify.structure+0xc70>
     9fc:      	sub	x11, x1, #0x1
     a00:      	ldr	x12, [sp, #0xc8]
     a04:      	ldr	x13, [x12, #0x28]
     a08:      	mov	x17, #0x18              ; =24
     a0c:      	mul	x11, x11, x17
     a10:      	add	x11, x11, x13
     a14:      	ldr	x13, [x11]
     a18:      	ldr	x11, [x11, #0x8]
     a1c:      	ldr	x14, [x12, #0x8]
     a20:      	cmp	x13, #0x0
     a24:      	b.lt	0xc30 <_stogir.verify.structure+0xa90>
     a28:      	cmp	x13, x14
     a2c:      	b.gt	0xc30 <_stogir.verify.structure+0xa90>
     a30:      	cmp	x11, #0x0
     a34:      	b.lt	0xc30 <_stogir.verify.structure+0xa90>
     a38:      	sub	x13, x14, x13
     a3c:      	cmp	x11, x13
     a40:      	b.gt	0xc30 <_stogir.verify.structure+0xa90>
     a44:      	mov	x11, #0x1               ; =1
     a48:      	b	0xc34 <_stogir.verify.structure+0xa94>
     a4c:      	uxtb	w16, w5
     a50:      	cmp	w16, wzr
     a54:      	b.eq	0xa98 <_stogir.verify.structure+0x8f8>
     a58:      	ldr	x9, [x26, #0x8]
     a5c:      	ldr	x10, [x27, #0x8]
     a60:      	cmp	x9, x10
     a64:      	b.ne	0xc44 <_stogir.verify.structure+0xaa4>
     a68:      	cmp	x6, x9
     a6c:      	b.gt	0xcbc <_stogir.verify.structure+0xb1c>
     a70:      	ldr	x9, [x22, #0x50]
     a74:      	add	x9, x8, x9
     a78:      	ldr	w9, [x9]
     a7c:      	sxtw	x9, w9
     a80:      	cmp	x9, #0x0
     a84:      	cset	w9, gt
     a88:      	ubfx	x9, x9, #0, #8
     a8c:      	b	0xcc0 <_stogir.verify.structure+0xb20>
     a90:      	movz	x9, #0x0, lsl #48
     a94:      	b	0xa9c <_stogir.verify.structure+0x8fc>
     a98:      	movz	x9, #0x0, lsl #48
     a9c:      	cmp	x9, #0x0
     aa0:      	b.eq	0xad0 <_stogir.verify.structure+0x930>
     aa4:      	uxtb	w16, w3
     aa8:      	cmp	w16, wzr
     aac:      	b.eq	0xac0 <_stogir.verify.structure+0x920>
     ab0:      	lsl	x7, x1, #4
     ab4:      	ldr	x9, [x22]
     ab8:      	add	x7, x7, x9
     abc:      	b	0xacc <_stogir.verify.structure+0x92c>
     ac0:      	lsl	x7, x7, #4
     ac4:      	ldr	x9, [x22, #0x28]
     ac8:      	add	x7, x7, x9
     acc:      	b	0xad4 <_stogir.verify.structure+0x934>
     ad0:      	movz	x7, #0x0, lsl #48
     ad4:      	cmp	x7, #0x0
     ad8:      	cset	w9, eq
     adc:      	uxtb	w16, w9
     ae0:      	cmp	w16, wzr
     ae4:      	cset	x9, eq
     ae8:      	cmp	x9, #0x0
     aec:      	b.eq	0x7dc <_stogir.verify.structure+0x63c>
     af0:      	ldr	w7, [x7]
     af4:      	uxtb	w7, w7
     af8:      	cmp	x7, #0x48
     afc:      	b.ne	0x7dc <_stogir.verify.structure+0x63c>
     b00:      	ldr	x7, [sp, #0x30]
     b04:      	mov	x10, #0x25              ; =37
     b08:      	b	0x7e4 <_stogir.verify.structure+0x644>
     b0c:      	ldr	w0, [sp, #0xc0]
     b10:      	bl	0xb10 <_stogir.verify.structure+0x970>
		0000000000000b10:  ARM64_RELOC_BRANCH26	_stogir.opcode.input-count
     b14:      	lsr	w0, w0, #0
     b18:      	sxtw	x0, w0
     b1c:      	cmn	x0, #0x1
     b20:      	b.ne	0x9a4 <_stogir.verify.structure+0x804>
     b24:      	ubfx	x0, x24, #16, #16
     b28:      	cmp	x23, x0
     b2c:      	b.eq	0x9a4 <_stogir.verify.structure+0x804>
     b30:      	ldr	x0, [sp, #0x68]
     b34:      	mov	x1, #0x24               ; =36
     b38:      	b	0x9ac <_stogir.verify.structure+0x80c>
     b3c:      	mov	x0, #0x1                ; =1
     b40:      	cmp	x0, #0x0
     b44:      	b.eq	0x5a0 <_stogir.verify.structure+0x400>
     b48:      	ldr	x0, [sp, #0x40]
     b4c:      	mov	x1, #0x1a               ; =26
     b50:      	b	0x5a8 <_stogir.verify.structure+0x408>
     b54:      	movz	x0, #0x0, lsl #48
     b58:      	ldr	x1, [sp, #0x128]
     b5c:      	cmp	x0, #0x0
     b60:      	b.eq	0xb3c <_stogir.verify.structure+0x99c>
     b64:      	movz	x0, #0x0, lsl #48
     b68:      	b	0xb40 <_stogir.verify.structure+0x9a0>
     b6c:      	movz	x3, #0x0, lsl #48
     b70:      	mov	x5, x11
     b74:      	cmp	x3, #0x0
     b78:      	b.eq	0xb9c <_stogir.verify.structure+0x9fc>
     b7c:      	str	x12, [sp, #0xc8]
     b80:      	str	x2, [sp, #0xd0]
     b84:      	str	x0, [sp, #0xb0]
     b88:      	str	x4, [sp, #0xa8]
     b8c:      	str	x10, [sp, #0x120]
     b90:      	mov	x1, x5
     b94:      	mov	x0, #0x1                ; =1
     b98:      	b	0xb5c <_stogir.verify.structure+0x9bc>
     b9c:      	cmp	x1, #0x0
     ba0:      	b.ne	0xe18 <_stogir.verify.structure+0xc78>
     ba4:      	mov	w1, w23
     ba8:      	str	x2, [sp, #0xd0]
     bac:      	str	x12, [sp, #0xc8]
     bb0:      	str	x10, [sp, #0x120]
     bb4:      	str	x0, [sp, #0xb0]
     bb8:      	ldr	w0, [sp, #0xc0]
     bbc:      	str	x4, [sp, #0xa8]
     bc0:      	str	x5, [sp, #0x128]
     bc4:      	bl	0xbc4 <_stogir.verify.structure+0xa24>
		0000000000000bc4:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
     bc8:      	lsr	w0, w0, #0
     bcc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000bcc:  ARM64_RELOC_PAGE21	l_stogir.319
     bd0:      	ldr	x16, [x16]
		0000000000000bd0:  ARM64_RELOC_PAGEOFF12	l_stogir.319
     bd4:      	ldr	w1, [x16]
     bd8:      	cmp	x0, x1
     bdc:      	b.ne	0xcc4 <_stogir.verify.structure+0xb24>
     be0:      	mov	x0, #0x1                ; =1
     be4:      	b	0xc58 <_stogir.verify.structure+0xab8>
     be8:      	uxtb	w16, w3
     bec:      	cmp	w16, wzr
     bf0:      	b.eq	0xe34 <_stogir.verify.structure+0xc94>
     bf4:      	ldr	x0, [x22, #0x8]
     bf8:      	cmp	x1, x0
     bfc:      	b.ge	0xe3c <_stogir.verify.structure+0xc9c>
     c00:      	ldr	x21, [sp, #0xb8]
     c04:      	ldr	x0, [x21, #0x8]
     c08:      	cmp	x1, x0
     c0c:      	b.ge	0xce8 <_stogir.verify.structure+0xb48>
     c10:      	ldr	x0, [x22, #0x78]
     c14:      	add	x0, x4, x0
     c18:      	ldr	w0, [x0]
     c1c:      	sxtw	x0, w0
     c20:      	cmp	x0, #0x0
     c24:      	cset	w0, ge
     c28:      	ubfx	x0, x0, #0, #8
     c2c:      	b	0xcec <_stogir.verify.structure+0xb4c>
     c30:      	movz	x11, #0x0, lsl #48
     c34:      	fmov	d31, x9
     c38:      	mov	x9, x11
     c3c:      	fmov	x11, d31
     c40:      	b	0x81c <_stogir.verify.structure+0x67c>
     c44:      	movz	x9, #0x0, lsl #48
     c48:      	b	0xa9c <_stogir.verify.structure+0x8fc>
     c4c:      	movz	x9, #0x0, lsl #48
     c50:      	b	0xa94 <_stogir.verify.structure+0x8f4>
     c54:      	movz	x0, #0x0, lsl #48
     c58:      	b	0xb58 <_stogir.verify.structure+0x9b8>
     c5c:      	movz	x0, #0x0, lsl #48
     c60:      	ldr	x4, [sp, #0xa8]
     c64:      	mov	x3, x0
     c68:      	ldr	x0, [sp, #0xb0]
     c6c:      	b	0xb70 <_stogir.verify.structure+0x9d0>
     c70:      	uxtb	w16, w5
     c74:      	cmp	w16, wzr
     c78:      	b.eq	0xe44 <_stogir.verify.structure+0xca4>
     c7c:      	ldr	x0, [sp, #0xb0]
     c80:      	ldr	x3, [x0, #0x8]
     c84:      	ldr	x4, [sp, #0xa8]
     c88:      	ldr	x5, [x4, #0x8]
     c8c:      	cmp	x3, x5
     c90:      	b.ne	0xce0 <_stogir.verify.structure+0xb40>
     c94:      	cmp	x6, x3
     c98:      	b.gt	0xd14 <_stogir.verify.structure+0xb74>
     c9c:      	ldr	x3, [x22, #0x50]
     ca0:      	add	x3, x8, x3
     ca4:      	ldr	w3, [x3]
     ca8:      	sxtw	x3, w3
     cac:      	cmp	x3, #0x0
     cb0:      	cset	w3, gt
     cb4:      	ubfx	x3, x3, #0, #8
     cb8:      	b	0xd18 <_stogir.verify.structure+0xb78>
     cbc:      	movz	x9, #0x0, lsl #48
     cc0:      	b	0xc48 <_stogir.verify.structure+0xaa8>
     cc4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cc4:  ARM64_RELOC_PAGE21	l_stogir.320
     cc8:      	ldr	x16, [x16]
		0000000000000cc8:  ARM64_RELOC_PAGEOFF12	l_stogir.320
     ccc:      	ldr	w1, [x16]
     cd0:      	cmp	x0, x1
     cd4:      	b.ne	0xcf8 <_stogir.verify.structure+0xb58>
     cd8:      	mov	x0, #0x1                ; =1
     cdc:      	b	0xc58 <_stogir.verify.structure+0xab8>
     ce0:      	movz	x3, #0x0, lsl #48
     ce4:      	b	0xb70 <_stogir.verify.structure+0x9d0>
     ce8:      	movz	x0, #0x0, lsl #48
     cec:      	b	0xc60 <_stogir.verify.structure+0xac0>
     cf0:      	brk	#0
     cf4:      	b	0xcf0 <_stogir.verify.structure+0xb50>
     cf8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000cf8:  ARM64_RELOC_PAGE21	l_stogir.321
     cfc:      	ldr	x16, [x16]
		0000000000000cfc:  ARM64_RELOC_PAGEOFF12	l_stogir.321
     d00:      	ldr	w1, [x16]
     d04:      	cmp	x0, x1
     d08:      	b.ne	0xd1c <_stogir.verify.structure+0xb7c>
     d0c:      	mov	x0, #0x1                ; =1
     d10:      	b	0xc58 <_stogir.verify.structure+0xab8>
     d14:      	movz	x3, #0x0, lsl #48
     d18:      	b	0xce4 <_stogir.verify.structure+0xb44>
     d1c:      	uxtb	w16, w20
     d20:      	cmp	w16, wzr
     d24:      	b.eq	0xc54 <_stogir.verify.structure+0xab4>
     d28:      	uxtb	w16, w19
     d2c:      	cmp	w16, wzr
     d30:      	b.eq	0xd48 <_stogir.verify.structure+0xba8>
     d34:      	sxtw	x23, w23
     d38:      	cmp	x23, #0x2
     d3c:      	cset	w0, eq
     d40:      	ubfx	x0, x0, #0, #8
     d44:      	b	0xd4c <_stogir.verify.structure+0xbac>
     d48:      	movz	x0, #0x0, lsl #48
     d4c:      	b	0xc58 <_stogir.verify.structure+0xab8>
     d50:      	brk	#0
     d54:      	b	0xd50 <_stogir.verify.structure+0xbb0>
     d58:      	ldr	x19, [sp, #0x90]
     d5c:      	b	0x4b4 <_stogir.verify.structure+0x314>
     d60:      	ldr	x19, [sp, #0x90]
     d64:      	b	0x4b4 <_stogir.verify.structure+0x314>
     d68:      	mov	x0, x21
     d6c:      	str	x19, [sp, #0xc8]
     d70:      	ldr	x19, [sp, #0x90]
     d74:      	str	x28, [sp, #0xd0]
     d78:      	mov	x21, x20
     d7c:      	str	x23, [sp, #0xb0]
     d80:      	str	x24, [sp, #0xa8]
     d84:      	b	0x2e4 <_stogir.verify.structure+0x144>
     d88:      	mov	x0, x21
     d8c:      	str	x19, [sp, #0xc8]
     d90:      	ldr	x19, [sp, #0x90]
     d94:      	str	x28, [sp, #0xd0]
     d98:      	ldr	x21, [sp, #0xb8]
     d9c:      	b	0x2b8 <_stogir.verify.structure+0x118>
     da0:      	mov	x0, x21
     da4:      	ldr	x19, [sp, #0x90]
     da8:      	str	x28, [sp, #0xd0]
     dac:      	ldr	x21, [sp, #0xb8]
     db0:      	b	0x2b8 <_stogir.verify.structure+0x118>
     db4:      	str	x12, [sp, #0xc8]
     db8:      	str	x2, [sp, #0xd0]
     dbc:      	ldr	x21, [sp, #0xb8]
     dc0:      	str	x10, [sp, #0x120]
     dc4:      	b	0x5ac <_stogir.verify.structure+0x40c>
     dc8:      	str	x21, [sp, #0x118]
     dcc:      	ldr	x21, [sp, #0xb8]
     dd0:      	str	x1, [sp, #0x100]
     dd4:      	str	x2, [sp, #0x108]
     dd8:      	b	0x538 <_stogir.verify.structure+0x398>
     ddc:      	str	w28, [sp, #0xe8]
     de0:      	mov	x28, x0
     de4:      	str	x1, [sp, #0xf0]
     de8:      	str	x2, [sp, #0xf8]
     dec:      	b	0x5fc <_stogir.verify.structure+0x45c>
     df0:      	ldr	x12, [sp, #0xc8]
     df4:      	ldr	x2, [sp, #0xd0]
     df8:      	b	0x85c <_stogir.verify.structure+0x6bc>
     dfc:      	str	x28, [sp, #0xd0]
     e00:      	mov	x28, x0
     e04:      	str	x1, [sp, #0xd8]
     e08:      	str	x2, [sp, #0xe0]
     e0c:      	b	0x914 <_stogir.verify.structure+0x774>
     e10:      	ldr	x12, [sp, #0xc8]
     e14:      	b	0x814 <_stogir.verify.structure+0x674>
     e18:      	str	x12, [sp, #0xc8]
     e1c:      	str	x2, [sp, #0xd0]
     e20:      	str	x0, [sp, #0xb0]
     e24:      	str	x4, [sp, #0xa8]
     e28:      	str	x5, [sp, #0x128]
     e2c:      	str	x10, [sp, #0x120]
     e30:      	b	0xb54 <_stogir.verify.structure+0x9b4>
     e34:      	ldr	x21, [sp, #0xb8]
     e38:      	b	0xc70 <_stogir.verify.structure+0xad0>
     e3c:      	ldr	x21, [sp, #0xb8]
     e40:      	b	0xc5c <_stogir.verify.structure+0xabc>
     e44:      	ldr	x0, [sp, #0xb0]
     e48:      	ldr	x4, [sp, #0xa8]
     e4c:      	b	0xb6c <_stogir.verify.structure+0x9cc>

0000000000000e50 <_stogir.verify.integer-operations-target-structured>:
     e50:      	sub	sp, sp, #0x470
     e54:      	str	x29, [sp, #0x10]
     e58:      	str	x30, [sp, #0x18]
     e5c:      	add	x29, sp, #0x10
     e60:      	str	x19, [sp, #0x420]
     e64:      	str	x20, [sp, #0x428]
     e68:      	str	x21, [sp, #0x430]
     e6c:      	str	x22, [sp, #0x438]
     e70:      	str	x23, [sp, #0x440]
     e74:      	str	x24, [sp, #0x448]
     e78:      	str	x25, [sp, #0x450]
     e7c:      	str	x26, [sp, #0x458]
     e80:      	str	x27, [sp, #0x460]
     e84:      	str	x28, [sp, #0x468]
     e88:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e88:  ARM64_RELOC_PAGE21	l_stogir.322
     e8c:      	ldr	x16, [x16]
		0000000000000e8c:  ARM64_RELOC_PAGEOFF12	l_stogir.322
     e90:      	orr	x2, x16, xzr
     e94:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000e94:  ARM64_RELOC_PAGE21	l_stogir.323
     e98:      	ldr	x16, [x16]
		0000000000000e98:  ARM64_RELOC_PAGEOFF12	l_stogir.323
     e9c:      	orr	x19, x16, xzr
     ea0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ea0:  ARM64_RELOC_PAGE21	l_stogir.324
     ea4:      	ldr	x16, [x16]
		0000000000000ea4:  ARM64_RELOC_PAGEOFF12	l_stogir.324
     ea8:      	orr	x20, x16, xzr
     eac:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000eac:  ARM64_RELOC_PAGE21	l_stogir.325
     eb0:      	ldr	x16, [x16]
		0000000000000eb0:  ARM64_RELOC_PAGEOFF12	l_stogir.325
     eb4:      	orr	x21, x16, xzr
     eb8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000eb8:  ARM64_RELOC_PAGE21	l_stogir.326
     ebc:      	ldr	x16, [x16]
		0000000000000ebc:  ARM64_RELOC_PAGEOFF12	l_stogir.326
     ec0:      	orr	x22, x16, xzr
     ec4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ec4:  ARM64_RELOC_PAGE21	l_stogir.327
     ec8:      	ldr	x16, [x16]
		0000000000000ec8:  ARM64_RELOC_PAGEOFF12	l_stogir.327
     ecc:      	orr	x23, x16, xzr
     ed0:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ed0:  ARM64_RELOC_PAGE21	l_stogir.328
     ed4:      	ldr	x16, [x16]
		0000000000000ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.328
     ed8:      	orr	x24, x16, xzr
     edc:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000edc:  ARM64_RELOC_PAGE21	l_stogir.329
     ee0:      	ldr	x16, [x16]
		0000000000000ee0:  ARM64_RELOC_PAGEOFF12	l_stogir.329
     ee4:      	orr	x25, x16, xzr
     ee8:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ee8:  ARM64_RELOC_PAGE21	l_stogir.330
     eec:      	ldr	x16, [x16]
		0000000000000eec:  ARM64_RELOC_PAGEOFF12	l_stogir.330
     ef0:      	orr	x26, x16, xzr
     ef4:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000ef4:  ARM64_RELOC_PAGE21	l_stogir.331
     ef8:      	ldr	x16, [x16]
		0000000000000ef8:  ARM64_RELOC_PAGEOFF12	l_stogir.331
     efc:      	orr	x27, x16, xzr
     f00:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000f00:  ARM64_RELOC_PAGE21	l_stogir.332
     f04:      	ldr	x16, [x16]
		0000000000000f04:  ARM64_RELOC_PAGEOFF12	l_stogir.332
     f08:      	orr	x28, x16, xzr
     f0c:      	adrp	x16, 0x0 <_gap_verify_graph>
		0000000000000f0c:  ARM64_RELOC_PAGE21	l_stogir.333
     f10:      	ldr	x16, [x16]
		0000000000000f10:  ARM64_RELOC_PAGEOFF12	l_stogir.333
     f14:      	orr	x3, x16, xzr
     f18:      	lsr	w4, w1, #0
     f1c:      	lsr	w5, w1, #0
     f20:      	lsr	w1, w1, #0
     f24:      	add	x16, sp, #0x20
     f28:      	orr	x6, x16, xzr
     f2c:      	add	x16, sp, #0x30
     f30:      	orr	x7, x16, xzr
     f34:      	add	x7, x7, #0x8
     f38:      	add	x16, sp, #0x50
     f3c:      	orr	x9, x16, xzr
     f40:      	add	x9, x9, #0x8
     f44:      	add	x16, sp, #0xe0
     f48:      	orr	x10, x16, xzr
     f4c:      	add	x10, x10, #0x8
     f50:      	add	x16, sp, #0x100
     f54:      	orr	x11, x16, xzr
     f58:      	add	x11, x11, #0x8
     f5c:      	add	x16, sp, #0x120
     f60:      	orr	x12, x16, xzr
     f64:      	add	x12, x12, #0x8
     f68:      	add	x16, sp, #0x140
     f6c:      	orr	x13, x16, xzr
     f70:      	add	x13, x13, #0x8
     f74:      	add	x16, sp, #0x160
     f78:      	orr	x14, x16, xzr
     f7c:      	add	x14, x14, #0x8
     f80:      	add	x16, sp, #0x180
     f84:      	orr	x15, x16, xzr
     f88:      	add	x15, x15, #0x8
     f8c:      	str	w1, [sp, #0x230]
     f90:      	add	x16, sp, #0x1a0
     f94:      	orr	x1, x16, xzr
     f98:      	add	x1, x1, #0x8
     f9c:      	str	x1, [sp, #0x238]
     fa0:      	add	x16, sp, #0x1f0
     fa4:      	orr	x1, x16, xzr
     fa8:      	add	x1, x1, #0x8
     fac:      	str	x19, [sp, #0x240]
     fb0:      	str	x20, [sp, #0x250]
     fb4:      	str	x2, [sp, #0x248]
     fb8:      	mov	x2, #0x1                ; =1
     fbc:      	movz	x19, #0x0, lsl #48
     fc0:      	movz	x20, #0x0, lsl #48
     fc4:      	str	x1, [sp, #0x258]
     fc8:      	cmp	x20, #0x0
     fcc:      	cset	w1, eq
     fd0:      	uxtb	w16, w1
     fd4:      	cmp	w16, wzr
     fd8:      	b.eq	0x2440 <_stogir.verify.integer-operations-target-structured+0x15f0>
     fdc:      	str	x3, [sp, #0x260]
     fe0:      	ldr	x3, [x0, #0x8]
     fe4:      	cmp	x2, x3
     fe8:      	b.ge	0x244c <_stogir.verify.integer-operations-target-structured+0x15fc>
     fec:      	lsl	x1, x2, #4
     ff0:      	lsl	x3, x2, #2
     ff4:      	str	w4, [sp, #0x268]
     ff8:      	ldr	x4, [x0]
     ffc:      	add	x1, x1, x4
    1000:      	ldr	x4, [x1]
    1004:      	str	x20, [sp, #0x270]
    1008:      	uxtb	w20, w4
    100c:      	ldr	x1, [x1, #0x8]
    1010:      	str	x21, [sp, #0x278]
    1014:      	orr	x21, x20, xzr
    1018:      	add	x16, sp, #0x20
    101c:      	str	x4, [x16]
    1020:      	add	x16, sp, #0x20
    1024:      	str	x1, [x16, #0x8]
    1028:      	ldr	x1, [x0, #0x78]
    102c:      	add	x1, x3, x1
    1030:      	ldr	w1, [x1]
    1034:      	cmp	x21, #0xe
    1038:      	b.lt	0x1a24 <_stogir.verify.integer-operations-target-structured+0xbd4>
    103c:      	cmp	x21, #0x17
    1040:      	cset	w3, le
    1044:      	ubfx	x3, x3, #0, #8
    1048:      	cmp	x21, #0x1a
    104c:      	b.lt	0x1a2c <_stogir.verify.integer-operations-target-structured+0xbdc>
    1050:      	cmp	x21, #0x1e
    1054:      	b.gt	0x1a2c <_stogir.verify.integer-operations-target-structured+0xbdc>
    1058:      	mov	x4, #0x1                ; =1
    105c:      	cmp	x21, #0x1f
    1060:      	b.ne	0x1a64 <_stogir.verify.integer-operations-target-structured+0xc14>
    1064:      	str	x0, [sp, #0x280]
    1068:      	mov	x0, #0x1                ; =1
    106c:      	str	x0, [sp, #0x288]
    1070:      	lsr	w0, w2, #0
    1074:      	lsr	w1, w1, #0
    1078:      	lsr	w0, w0, #0
    107c:      	str	x8, [sp, #0x2d8]
    1080:      	str	w5, [sp, #0x2a0]
    1084:      	str	x6, [sp, #0x2a8]
    1088:      	str	x15, [sp, #0x2e8]
    108c:      	str	x2, [sp, #0x2f0]
    1090:      	mov	x2, x6
    1094:      	str	w1, [sp, #0x2f8]
    1098:      	str	x3, [sp, #0x300]
    109c:      	mov	w3, w1
    10a0:      	mov	w1, w0
    10a4:      	str	x4, [sp, #0x308]
    10a8:      	str	w0, [sp, #0x310]
    10ac:      	ldr	x0, [sp, #0x280]
    10b0:      	str	x22, [sp, #0x290]
    10b4:      	mov	x22, x13
    10b8:      	str	x23, [sp, #0x298]
    10bc:      	ldr	x23, [sp, #0x260]
    10c0:      	str	x24, [sp, #0x2b0]
    10c4:      	mov	x24, x7
    10c8:      	str	x25, [sp, #0x2b8]
    10cc:      	mov	x25, x9
    10d0:      	str	x26, [sp, #0x2c0]
    10d4:      	mov	x26, x10
    10d8:      	str	x27, [sp, #0x2c8]
    10dc:      	mov	x27, x11
    10e0:      	str	x28, [sp, #0x2d0]
    10e4:      	mov	x28, x12
    10e8:      	str	w20, [sp, #0x2e0]
    10ec:      	mov	x20, x14
    10f0:      	bl	0x10f0 <_stogir.verify.integer-operations-target-structured+0x2a0>
		00000000000010f0:  ARM64_RELOC_BRANCH26	_stogir.verify.classifications
    10f4:      	uxtb	w1, w0
    10f8:      	cmp	x1, #0x0
    10fc:      	cset	w1, ne
    1100:      	cmp	x21, #0x3d
    1104:      	b.lt	0x1adc <_stogir.verify.integer-operations-target-structured+0xc8c>
    1108:      	cmp	x21, #0x3f
    110c:      	b.gt	0x1adc <_stogir.verify.integer-operations-target-structured+0xc8c>
    1110:      	add	x8, sp, #0x30
    1114:      	ldr	w2, [sp, #0x268]
    1118:      	str	x0, [sp, #0x318]
    111c:      	ldr	x0, [sp, #0x280]
    1120:      	str	x20, [sp, #0x320]
    1124:      	mov	w20, w1
    1128:      	ldr	w1, [sp, #0x310]
    112c:      	bl	0x112c <_stogir.verify.integer-operations-target-structured+0x2dc>
		000000000000112c:  ARM64_RELOC_BRANCH26	_stogir.vector.validate
    1130:      	add	x16, sp, #0x30
    1134:      	ldr	w0, [x16]
    1138:      	lsr	x16, x0, #0
    113c:      	cmp	x16, #0x1
    1140:      	b.eq	0x115c <_stogir.verify.integer-operations-target-structured+0x30c>
    1144:      	b.lo	0x114c <_stogir.verify.integer-operations-target-structured+0x2fc>
    1148:      	b	0x1160 <_stogir.verify.integer-operations-target-structured+0x310>
    114c:      	cmp	x16, #0x0
    1150:      	b.eq	0x1158 <_stogir.verify.integer-operations-target-structured+0x308>
    1154:      	b	0x1160 <_stogir.verify.integer-operations-target-structured+0x310>
    1158:      	b	0x1b00 <_stogir.verify.integer-operations-target-structured+0xcb0>
    115c:      	b	0x1164 <_stogir.verify.integer-operations-target-structured+0x314>
    1160:      	b	0x23c4 <_stogir.verify.integer-operations-target-structured+0x1574>
    1164:      	add	x16, sp, #0x30
    1168:      	ldr	x0, [x16, #0x8]
    116c:      	ldr	x1, [x24, #0x8]
    1170:      	mov	x2, x1
    1174:      	mov	x1, x0
    1178:      	mov	x0, x19
    117c:      	mov	x19, x0
    1180:      	mov	x0, x1
    1184:      	mov	x1, x2
    1188:      	cmp	x21, #0x44
    118c:      	b.ne	0x1b28 <_stogir.verify.integer-operations-target-structured+0xcd8>
    1190:      	uxtb	w16, w20
    1194:      	cmp	w16, wzr
    1198:      	b.eq	0x1b18 <_stogir.verify.integer-operations-target-structured+0xcc8>
    119c:      	mov	x2, x1
    11a0:      	mov	x1, x0
    11a4:      	movz	x0, #0x0, lsl #48
    11a8:      	cmp	x0, #0x0
    11ac:      	b.eq	0x2458 <_stogir.verify.integer-operations-target-structured+0x1608>
    11b0:      	add	x8, sp, #0x50
    11b4:      	ldr	x0, [sp, #0x280]
    11b8:      	str	x1, [sp, #0x328]
    11bc:      	ldr	w1, [sp, #0x310]
    11c0:      	str	x2, [sp, #0x330]
    11c4:      	bl	0x11c4 <_stogir.verify.integer-operations-target-structured+0x374>
		00000000000011c4:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    11c8:      	add	x16, sp, #0x50
    11cc:      	ldr	w0, [x16]
    11d0:      	lsr	x16, x0, #0
    11d4:      	cmp	x16, #0x1
    11d8:      	b.eq	0x11f4 <_stogir.verify.integer-operations-target-structured+0x3a4>
    11dc:      	b.lo	0x11e4 <_stogir.verify.integer-operations-target-structured+0x394>
    11e0:      	b	0x11f8 <_stogir.verify.integer-operations-target-structured+0x3a8>
    11e4:      	cmp	x16, #0x0
    11e8:      	b.eq	0x11f0 <_stogir.verify.integer-operations-target-structured+0x3a0>
    11ec:      	b	0x11f8 <_stogir.verify.integer-operations-target-structured+0x3a8>
    11f0:      	b	0x1b38 <_stogir.verify.integer-operations-target-structured+0xce8>
    11f4:      	b	0x11fc <_stogir.verify.integer-operations-target-structured+0x3ac>
    11f8:      	b	0x1b50 <_stogir.verify.integer-operations-target-structured+0xd00>
    11fc:      	add	x16, sp, #0x50
    1200:      	ldr	x0, [x16, #0x8]
    1204:      	ldr	x1, [x25, #0x8]
    1208:      	mov	x2, x1
    120c:      	mov	x1, x0
    1210:      	mov	x0, x19
    1214:      	mov	x19, x0
    1218:      	mov	x0, x1
    121c:      	mov	x1, x2
    1220:      	cmp	x21, #0x1d
    1224:      	b.ne	0x1b64 <_stogir.verify.integer-operations-target-structured+0xd14>
    1228:      	mov	x2, x1
    122c:      	mov	x1, x0
    1230:      	mov	x0, #0x1                ; =1
    1234:      	cmp	x0, #0x0
    1238:      	b.eq	0x1b8c <_stogir.verify.integer-operations-target-structured+0xd3c>
    123c:      	add	x16, sp, #0x20
    1240:      	ldr	w0, [x16, #0xc]
    1244:      	sxtw	x0, w0
    1248:      	cmp	x0, #0x0
    124c:      	b.ne	0x1b84 <_stogir.verify.integer-operations-target-structured+0xd34>
    1250:      	movz	x0, #0x0, lsl #48
    1254:      	cmp	x0, #0x0
    1258:      	b.eq	0x2464 <_stogir.verify.integer-operations-target-structured+0x1614>
    125c:      	add	x16, sp, #0x20
    1260:      	ldr	w0, [x16, #0xc]
    1264:      	lsr	w0, w0, #0
    1268:      	add	x8, sp, #0x70
    126c:      	str	x1, [sp, #0x338]
    1270:      	mov	w1, w0
    1274:      	ldr	x0, [sp, #0x280]
    1278:      	str	x2, [sp, #0x340]
    127c:      	bl	0x127c <_stogir.verify.integer-operations-target-structured+0x42c>
		000000000000127c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1280:      	add	x16, sp, #0x70
    1284:      	ldr	w0, [x16]
    1288:      	lsr	x16, x0, #0
    128c:      	cmp	x16, #0x1
    1290:      	b.eq	0x12ac <_stogir.verify.integer-operations-target-structured+0x45c>
    1294:      	b.lo	0x129c <_stogir.verify.integer-operations-target-structured+0x44c>
    1298:      	b	0x12b0 <_stogir.verify.integer-operations-target-structured+0x460>
    129c:      	cmp	x16, #0x0
    12a0:      	b.eq	0x12a8 <_stogir.verify.integer-operations-target-structured+0x458>
    12a4:      	b	0x12b0 <_stogir.verify.integer-operations-target-structured+0x460>
    12a8:      	b	0x12b4 <_stogir.verify.integer-operations-target-structured+0x464>
    12ac:      	b	0x1b94 <_stogir.verify.integer-operations-target-structured+0xd44>
    12b0:      	b	0x1c48 <_stogir.verify.integer-operations-target-structured+0xdf8>
    12b4:      	ldr	x0, [sp, #0x240]
    12b8:      	mov	x1, #0x16               ; =22
    12bc:      	cmp	x21, #0x29
    12c0:      	b.lt	0x1c5c <_stogir.verify.integer-operations-target-structured+0xe0c>
    12c4:      	cmp	x21, #0x2b
    12c8:      	cset	w2, le
    12cc:      	ubfx	x2, x2, #0, #8
    12d0:      	fmov	d31, x0
    12d4:      	mov	x0, x2
    12d8:      	mov	x2, x1
    12dc:      	fmov	x1, d31
    12e0:      	cmp	x21, #0x2c
    12e4:      	cset	w3, eq
    12e8:      	cmp	x0, #0x0
    12ec:      	b.eq	0x1c6c <_stogir.verify.integer-operations-target-structured+0xe1c>
    12f0:      	mov	x0, #0x1                ; =1
    12f4:      	cmp	x0, #0x0
    12f8:      	b.eq	0x2470 <_stogir.verify.integer-operations-target-structured+0x1620>
    12fc:      	uxtb	w16, w3
    1300:      	cmp	w16, wzr
    1304:      	b.eq	0x247c <_stogir.verify.integer-operations-target-structured+0x162c>
    1308:      	add	x8, sp, #0xa0
    130c:      	ldr	x0, [sp, #0x280]
    1310:      	str	x1, [sp, #0x348]
    1314:      	ldr	w1, [sp, #0x310]
    1318:      	str	x2, [sp, #0x350]
    131c:      	bl	0x131c <_stogir.verify.integer-operations-target-structured+0x4cc>
		000000000000131c:  ARM64_RELOC_BRANCH26	_stogir.checked.validate-projection
    1320:      	add	x16, sp, #0xa0
    1324:      	ldr	x0, [x16]
    1328:      	add	x16, sp, #0xa0
    132c:      	ldr	x1, [x16, #0x8]
    1330:      	add	x16, sp, #0xa0
    1334:      	ldr	x2, [x16, #0x10]
    1338:      	mov	x3, x1
    133c:      	ldr	x1, [sp, #0x350]
    1340:      	mov	x4, x2
    1344:      	mov	x2, x0
    1348:      	ldr	x0, [sp, #0x348]
    134c:      	lsr	w2, w2, #0
    1350:      	lsr	x16, x2, #0
    1354:      	cmp	x16, #0x1
    1358:      	b.eq	0x1374 <_stogir.verify.integer-operations-target-structured+0x524>
    135c:      	b.lo	0x1364 <_stogir.verify.integer-operations-target-structured+0x514>
    1360:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x528>
    1364:      	cmp	x16, #0x0
    1368:      	b.eq	0x1370 <_stogir.verify.integer-operations-target-structured+0x520>
    136c:      	b	0x1378 <_stogir.verify.integer-operations-target-structured+0x528>
    1370:      	b	0x1cb4 <_stogir.verify.integer-operations-target-structured+0xe64>
    1374:      	b	0x137c <_stogir.verify.integer-operations-target-structured+0x52c>
    1378:      	b	0x1cd4 <_stogir.verify.integer-operations-target-structured+0xe84>
    137c:      	mov	x0, x19
    1380:      	mov	x1, x3
    1384:      	mov	x2, x4
    1388:      	mov	x19, x0
    138c:      	mov	x0, x1
    1390:      	mov	x1, x2
    1394:      	cmp	x21, #0x7e
    1398:      	b.lt	0x1ce8 <_stogir.verify.integer-operations-target-structured+0xe98>
    139c:      	cmp	x21, #0x82
    13a0:      	cset	w2, le
    13a4:      	ubfx	x2, x2, #0, #8
    13a8:      	fmov	d31, x0
    13ac:      	mov	x0, x2
    13b0:      	mov	x2, x1
    13b4:      	fmov	x1, d31
    13b8:      	cmp	x0, #0x0
    13bc:      	b.eq	0x2488 <_stogir.verify.integer-operations-target-structured+0x1638>
    13c0:      	add	x8, sp, #0xe0
    13c4:      	ldr	x0, [sp, #0x280]
    13c8:      	str	x1, [sp, #0x358]
    13cc:      	ldr	w1, [sp, #0x310]
    13d0:      	str	x2, [sp, #0x360]
    13d4:      	bl	0x13d4 <_stogir.verify.integer-operations-target-structured+0x584>
		00000000000013d4:  ARM64_RELOC_BRANCH26	_stogir.atomic.validate
    13d8:      	add	x16, sp, #0xe0
    13dc:      	ldr	w0, [x16]
    13e0:      	lsr	x16, x0, #0
    13e4:      	cmp	x16, #0x1
    13e8:      	b.eq	0x1404 <_stogir.verify.integer-operations-target-structured+0x5b4>
    13ec:      	b.lo	0x13f4 <_stogir.verify.integer-operations-target-structured+0x5a4>
    13f0:      	b	0x1408 <_stogir.verify.integer-operations-target-structured+0x5b8>
    13f4:      	cmp	x16, #0x0
    13f8:      	b.eq	0x1400 <_stogir.verify.integer-operations-target-structured+0x5b0>
    13fc:      	b	0x1408 <_stogir.verify.integer-operations-target-structured+0x5b8>
    1400:      	b	0x1cf8 <_stogir.verify.integer-operations-target-structured+0xea8>
    1404:      	b	0x140c <_stogir.verify.integer-operations-target-structured+0x5bc>
    1408:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xec0>
    140c:      	add	x16, sp, #0xe0
    1410:      	ldr	x0, [x16, #0x8]
    1414:      	ldr	x1, [x26, #0x8]
    1418:      	mov	x2, x1
    141c:      	mov	x1, x0
    1420:      	mov	x0, x19
    1424:      	mov	x19, x0
    1428:      	mov	x0, x1
    142c:      	mov	x1, x2
    1430:      	cmp	x21, #0x60
    1434:      	b.ne	0x1d24 <_stogir.verify.integer-operations-target-structured+0xed4>
    1438:      	mov	x2, x1
    143c:      	mov	x1, x0
    1440:      	mov	x0, #0x1                ; =1
    1444:      	cmp	x0, #0x0
    1448:      	b.eq	0x2494 <_stogir.verify.integer-operations-target-structured+0x1644>
    144c:      	add	x8, sp, #0x100
    1450:      	ldr	x0, [sp, #0x280]
    1454:      	str	x1, [sp, #0x368]
    1458:      	ldr	w1, [sp, #0x310]
    145c:      	str	x2, [sp, #0x370]
    1460:      	bl	0x1460 <_stogir.verify.integer-operations-target-structured+0x610>
		0000000000001460:  ARM64_RELOC_BRANCH26	_stogir.terminal.validate
    1464:      	add	x16, sp, #0x100
    1468:      	ldr	w0, [x16]
    146c:      	lsr	x16, x0, #0
    1470:      	cmp	x16, #0x1
    1474:      	b.eq	0x1490 <_stogir.verify.integer-operations-target-structured+0x640>
    1478:      	b.lo	0x1480 <_stogir.verify.integer-operations-target-structured+0x630>
    147c:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x644>
    1480:      	cmp	x16, #0x0
    1484:      	b.eq	0x148c <_stogir.verify.integer-operations-target-structured+0x63c>
    1488:      	b	0x1494 <_stogir.verify.integer-operations-target-structured+0x644>
    148c:      	b	0x1d44 <_stogir.verify.integer-operations-target-structured+0xef4>
    1490:      	b	0x1498 <_stogir.verify.integer-operations-target-structured+0x648>
    1494:      	b	0x1d5c <_stogir.verify.integer-operations-target-structured+0xf0c>
    1498:      	add	x16, sp, #0x100
    149c:      	ldr	x0, [x16, #0x8]
    14a0:      	ldr	x1, [x27, #0x8]
    14a4:      	mov	x2, x1
    14a8:      	mov	x1, x0
    14ac:      	mov	x0, x19
    14b0:      	mov	x19, x0
    14b4:      	mov	x0, x1
    14b8:      	mov	x1, x2
    14bc:      	cmp	x21, #0x75
    14c0:      	b.ne	0x1d70 <_stogir.verify.integer-operations-target-structured+0xf20>
    14c4:      	mov	x2, x1
    14c8:      	mov	x1, x0
    14cc:      	mov	x0, #0x1                ; =1
    14d0:      	cmp	x0, #0x0
    14d4:      	b.eq	0x24a0 <_stogir.verify.integer-operations-target-structured+0x1650>
    14d8:      	add	x8, sp, #0x120
    14dc:      	ldr	x0, [sp, #0x280]
    14e0:      	str	x1, [sp, #0x378]
    14e4:      	ldr	w1, [sp, #0x310]
    14e8:      	str	x2, [sp, #0x380]
    14ec:      	bl	0x14ec <_stogir.verify.integer-operations-target-structured+0x69c>
		00000000000014ec:  ARM64_RELOC_BRANCH26	_stogir.switch.validate
    14f0:      	add	x16, sp, #0x120
    14f4:      	ldr	w0, [x16]
    14f8:      	lsr	x16, x0, #0
    14fc:      	cmp	x16, #0x1
    1500:      	b.eq	0x151c <_stogir.verify.integer-operations-target-structured+0x6cc>
    1504:      	b.lo	0x150c <_stogir.verify.integer-operations-target-structured+0x6bc>
    1508:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x6d0>
    150c:      	cmp	x16, #0x0
    1510:      	b.eq	0x1518 <_stogir.verify.integer-operations-target-structured+0x6c8>
    1514:      	b	0x1520 <_stogir.verify.integer-operations-target-structured+0x6d0>
    1518:      	b	0x1da0 <_stogir.verify.integer-operations-target-structured+0xf50>
    151c:      	b	0x1524 <_stogir.verify.integer-operations-target-structured+0x6d4>
    1520:      	b	0x1db8 <_stogir.verify.integer-operations-target-structured+0xf68>
    1524:      	add	x16, sp, #0x120
    1528:      	ldr	x0, [x16, #0x8]
    152c:      	ldr	x1, [x28, #0x8]
    1530:      	mov	x2, x1
    1534:      	mov	x1, x0
    1538:      	mov	x0, x19
    153c:      	mov	x19, x0
    1540:      	mov	x0, x1
    1544:      	mov	x1, x2
    1548:      	cmp	x21, #0x42
    154c:      	b.ne	0x1dcc <_stogir.verify.integer-operations-target-structured+0xf7c>
    1550:      	mov	x2, x1
    1554:      	mov	x1, x0
    1558:      	mov	x0, #0x1                ; =1
    155c:      	cmp	x0, #0x0
    1560:      	b.eq	0x24ac <_stogir.verify.integer-operations-target-structured+0x165c>
    1564:      	add	x8, sp, #0x140
    1568:      	ldr	x0, [sp, #0x280]
    156c:      	str	x1, [sp, #0x388]
    1570:      	ldr	w1, [sp, #0x310]
    1574:      	str	x2, [sp, #0x390]
    1578:      	bl	0x1578 <_stogir.verify.integer-operations-target-structured+0x728>
		0000000000001578:  ARM64_RELOC_BRANCH26	_stogir.stack.validate
    157c:      	add	x16, sp, #0x140
    1580:      	ldr	w0, [x16]
    1584:      	lsr	x16, x0, #0
    1588:      	cmp	x16, #0x1
    158c:      	b.eq	0x15a8 <_stogir.verify.integer-operations-target-structured+0x758>
    1590:      	b.lo	0x1598 <_stogir.verify.integer-operations-target-structured+0x748>
    1594:      	b	0x15ac <_stogir.verify.integer-operations-target-structured+0x75c>
    1598:      	cmp	x16, #0x0
    159c:      	b.eq	0x15a4 <_stogir.verify.integer-operations-target-structured+0x754>
    15a0:      	b	0x15ac <_stogir.verify.integer-operations-target-structured+0x75c>
    15a4:      	b	0x1e1c <_stogir.verify.integer-operations-target-structured+0xfcc>
    15a8:      	b	0x15b0 <_stogir.verify.integer-operations-target-structured+0x760>
    15ac:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0xfe4>
    15b0:      	add	x16, sp, #0x140
    15b4:      	ldr	x0, [x16, #0x8]
    15b8:      	ldr	x1, [x22, #0x8]
    15bc:      	mov	x2, x1
    15c0:      	mov	x1, x0
    15c4:      	mov	x0, x19
    15c8:      	mov	x19, x0
    15cc:      	mov	x0, x1
    15d0:      	mov	x1, x2
    15d4:      	cmp	x21, #0x41
    15d8:      	b.ne	0x1e48 <_stogir.verify.integer-operations-target-structured+0xff8>
    15dc:      	mov	x2, x1
    15e0:      	mov	x1, x0
    15e4:      	mov	x0, #0x1                ; =1
    15e8:      	cmp	x0, #0x0
    15ec:      	b.eq	0x24b8 <_stogir.verify.integer-operations-target-structured+0x1668>
    15f0:      	add	x8, sp, #0x160
    15f4:      	ldr	x0, [sp, #0x280]
    15f8:      	str	x1, [sp, #0x398]
    15fc:      	ldr	w1, [sp, #0x310]
    1600:      	str	x2, [sp, #0x3a0]
    1604:      	ldr	w2, [sp, #0x2a0]
    1608:      	bl	0x1608 <_stogir.verify.integer-operations-target-structured+0x7b8>
		0000000000001608:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    160c:      	add	x16, sp, #0x160
    1610:      	ldr	w0, [x16]
    1614:      	lsr	x16, x0, #0
    1618:      	cmp	x16, #0x1
    161c:      	b.eq	0x163c <_stogir.verify.integer-operations-target-structured+0x7ec>
    1620:      	b.lo	0x1628 <_stogir.verify.integer-operations-target-structured+0x7d8>
    1624:      	b	0x1640 <_stogir.verify.integer-operations-target-structured+0x7f0>
    1628:      	cmp	x16, #0x0
    162c:      	b.eq	0x1634 <_stogir.verify.integer-operations-target-structured+0x7e4>
    1630:      	b	0x1640 <_stogir.verify.integer-operations-target-structured+0x7f0>
    1634:      	ldr	x1, [sp, #0x320]
    1638:      	b	0x1e88 <_stogir.verify.integer-operations-target-structured+0x1038>
    163c:      	b	0x1644 <_stogir.verify.integer-operations-target-structured+0x7f4>
    1640:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x1050>
    1644:      	add	x16, sp, #0x160
    1648:      	ldr	x0, [x16, #0x8]
    164c:      	ldr	x1, [sp, #0x320]
    1650:      	ldr	x2, [x1, #0x8]
    1654:      	mov	x3, x2
    1658:      	mov	x2, x0
    165c:      	mov	x0, x19
    1660:      	mov	x19, x0
    1664:      	mov	x0, x2
    1668:      	mov	x2, x3
    166c:      	cmp	x21, #0x21
    1670:      	b.lt	0x1eb4 <_stogir.verify.integer-operations-target-structured+0x1064>
    1674:      	cmp	x21, #0x27
    1678:      	cset	w3, le
    167c:      	ubfx	x3, x3, #0, #8
    1680:      	fmov	d31, x0
    1684:      	mov	x0, x3
    1688:      	mov	x3, x2
    168c:      	fmov	x2, d31
    1690:      	cmp	x0, #0x0
    1694:      	b.eq	0x24c8 <_stogir.verify.integer-operations-target-structured+0x1678>
    1698:      	add	x8, sp, #0x180
    169c:      	ldr	x0, [sp, #0x280]
    16a0:      	str	x1, [sp, #0x320]
    16a4:      	ldr	w1, [sp, #0x310]
    16a8:      	str	x2, [sp, #0x3a8]
    16ac:      	ldr	w2, [sp, #0x230]
    16b0:      	str	x3, [sp, #0x3b0]
    16b4:      	bl	0x16b4 <_stogir.verify.integer-operations-target-structured+0x864>
		00000000000016b4:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    16b8:      	add	x16, sp, #0x180
    16bc:      	ldr	w0, [x16]
    16c0:      	lsr	x16, x0, #0
    16c4:      	cmp	x16, #0x1
    16c8:      	b.eq	0x16e8 <_stogir.verify.integer-operations-target-structured+0x898>
    16cc:      	b.lo	0x16d4 <_stogir.verify.integer-operations-target-structured+0x884>
    16d0:      	b	0x16ec <_stogir.verify.integer-operations-target-structured+0x89c>
    16d4:      	cmp	x16, #0x0
    16d8:      	b.eq	0x16e0 <_stogir.verify.integer-operations-target-structured+0x890>
    16dc:      	b	0x16ec <_stogir.verify.integer-operations-target-structured+0x89c>
    16e0:      	ldr	x1, [sp, #0x2e8]
    16e4:      	b	0x1ec4 <_stogir.verify.integer-operations-target-structured+0x1074>
    16e8:      	b	0x16f0 <_stogir.verify.integer-operations-target-structured+0x8a0>
    16ec:      	b	0x1edc <_stogir.verify.integer-operations-target-structured+0x108c>
    16f0:      	add	x16, sp, #0x180
    16f4:      	ldr	x0, [x16, #0x8]
    16f8:      	ldr	x1, [sp, #0x2e8]
    16fc:      	ldr	x2, [x1, #0x8]
    1700:      	mov	x3, x2
    1704:      	mov	x2, x0
    1708:      	mov	x0, x19
    170c:      	mov	x19, x0
    1710:      	mov	x0, x2
    1714:      	mov	x2, x3
    1718:      	cmp	x21, #0x3c
    171c:      	b.ne	0x24dc <_stogir.verify.integer-operations-target-structured+0x168c>
    1720:      	add	x8, sp, #0x1a0
    1724:      	str	x1, [sp, #0x2e8]
    1728:      	ldr	w1, [sp, #0x310]
    172c:      	str	x0, [sp, #0x3b8]
    1730:      	ldr	x0, [sp, #0x280]
    1734:      	str	x2, [sp, #0x3c0]
    1738:      	bl	0x1738 <_stogir.verify.integer-operations-target-structured+0x8e8>
		0000000000001738:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    173c:      	add	x16, sp, #0x1a0
    1740:      	ldr	w0, [x16]
    1744:      	lsr	x16, x0, #0
    1748:      	cmp	x16, #0x1
    174c:      	b.eq	0x176c <_stogir.verify.integer-operations-target-structured+0x91c>
    1750:      	b.lo	0x1758 <_stogir.verify.integer-operations-target-structured+0x908>
    1754:      	b	0x1770 <_stogir.verify.integer-operations-target-structured+0x920>
    1758:      	cmp	x16, #0x0
    175c:      	b.eq	0x1764 <_stogir.verify.integer-operations-target-structured+0x914>
    1760:      	b	0x1770 <_stogir.verify.integer-operations-target-structured+0x920>
    1764:      	ldr	x1, [sp, #0x238]
    1768:      	b	0x1ef0 <_stogir.verify.integer-operations-target-structured+0x10a0>
    176c:      	b	0x1774 <_stogir.verify.integer-operations-target-structured+0x924>
    1770:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1774:      	add	x16, sp, #0x1a0
    1778:      	ldr	x0, [x16, #0x8]
    177c:      	ldr	x1, [sp, #0x238]
    1780:      	ldr	x2, [x1, #0x8]
    1784:      	mov	x3, x2
    1788:      	mov	x2, x0
    178c:      	mov	x0, x19
    1790:      	mov	x19, x0
    1794:      	mov	x0, x2
    1798:      	mov	x2, x3
    179c:      	cmp	x21, #0x78
    17a0:      	b.ne	0x24f0 <_stogir.verify.integer-operations-target-structured+0x16a0>
    17a4:      	add	x16, sp, #0x20
    17a8:      	ldr	w3, [x16]
    17ac:      	ubfx	x3, x3, #8, #8
    17b0:      	cmp	x3, #0x0
    17b4:      	b.ne	0x1f38 <_stogir.verify.integer-operations-target-structured+0x10e8>
    17b8:      	add	x16, sp, #0x20
    17bc:      	ldr	w3, [x16, #0x8]
    17c0:      	sxtw	x3, w3
    17c4:      	cmp	x3, #0x0
    17c8:      	b.ne	0x1f1c <_stogir.verify.integer-operations-target-structured+0x10cc>
    17cc:      	mov	x3, x2
    17d0:      	mov	x2, x0
    17d4:      	movz	x0, #0x0, lsl #48
    17d8:      	cmp	x0, #0x0
    17dc:      	b.eq	0x1f2c <_stogir.verify.integer-operations-target-structured+0x10dc>
    17e0:      	ldr	x0, [sp, #0x278]
    17e4:      	mov	x2, #0x1f               ; =31
    17e8:      	str	x1, [sp, #0x238]
    17ec:      	mov	x1, x2
    17f0:      	add	x2, x19, #0x1
    17f4:      	lsr	w2, w2, #0
    17f8:      	sxtw	x2, w2
    17fc:      	mov	x19, x2
    1800:      	ldr	x2, [sp, #0x318]
    1804:      	uxth	w2, w2
    1808:      	mov	w17, #0x8               ; =8
    180c:      	uxth	w16, w2
    1810:      	ubfx	w17, w17, #0, #4
    1814:      	lsr	w2, w16, w17
    1818:      	uxth	w2, w2
    181c:      	uxtb	w2, w2
    1820:      	cmp	x2, #0x0
    1824:      	b.eq	0x2500 <_stogir.verify.integer-operations-target-structured+0x16b0>
    1828:      	add	x8, sp, #0x1f0
    182c:      	str	x0, [sp, #0x3d8]
    1830:      	ldr	x0, [sp, #0x280]
    1834:      	str	x1, [sp, #0x3e0]
    1838:      	ldr	w1, [sp, #0x310]
    183c:      	str	x22, [sp, #0x3e8]
    1840:      	mov	x22, x2
    1844:      	bl	0x1844 <_stogir.verify.integer-operations-target-structured+0x9f4>
		0000000000001844:  ARM64_RELOC_BRANCH26	_stogir.floating.validate
    1848:      	add	x16, sp, #0x1f0
    184c:      	ldr	w0, [x16]
    1850:      	lsr	x16, x0, #0
    1854:      	cmp	x16, #0x1
    1858:      	b.eq	0x1878 <_stogir.verify.integer-operations-target-structured+0xa28>
    185c:      	b.lo	0x1864 <_stogir.verify.integer-operations-target-structured+0xa14>
    1860:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xa2c>
    1864:      	cmp	x16, #0x0
    1868:      	b.eq	0x1870 <_stogir.verify.integer-operations-target-structured+0xa20>
    186c:      	b	0x187c <_stogir.verify.integer-operations-target-structured+0xa2c>
    1870:      	ldr	x1, [sp, #0x258]
    1874:      	b	0x1ff0 <_stogir.verify.integer-operations-target-structured+0x11a0>
    1878:      	b	0x1880 <_stogir.verify.integer-operations-target-structured+0xa30>
    187c:      	b	0x2008 <_stogir.verify.integer-operations-target-structured+0x11b8>
    1880:      	add	x16, sp, #0x1f0
    1884:      	ldr	x0, [x16, #0x8]
    1888:      	ldr	x1, [sp, #0x258]
    188c:      	ldr	x2, [x1, #0x8]
    1890:      	mov	x3, x2
    1894:      	mov	x2, x0
    1898:      	mov	x0, x19
    189c:      	mov	x19, x0
    18a0:      	mov	x0, x2
    18a4:      	mov	x2, x3
    18a8:      	uxtb	w16, w20
    18ac:      	cmp	w16, wzr
    18b0:      	b.eq	0x201c <_stogir.verify.integer-operations-target-structured+0x11cc>
    18b4:      	mov	x3, x2
    18b8:      	mov	x2, x0
    18bc:      	movz	x0, #0x0, lsl #48
    18c0:      	cmp	x0, #0x0
    18c4:      	b.eq	0x2518 <_stogir.verify.integer-operations-target-structured+0x16c8>
    18c8:      	cmp	x22, #0x0
    18cc:      	b.eq	0x202c <_stogir.verify.integer-operations-target-structured+0x11dc>
    18d0:      	movz	x0, #0x0, lsl #48
    18d4:      	cmp	x0, #0x0
    18d8:      	b.eq	0x2524 <_stogir.verify.integer-operations-target-structured+0x16d4>
    18dc:      	ldr	x20, [sp, #0x300]
    18e0:      	cmp	x20, #0x0
    18e4:      	b.eq	0x2034 <_stogir.verify.integer-operations-target-structured+0x11e4>
    18e8:      	ldr	x22, [sp, #0x308]
    18ec:      	mov	x0, #0x1                ; =1
    18f0:      	cmp	x0, #0x0
    18f4:      	b.eq	0x2530 <_stogir.verify.integer-operations-target-structured+0x16e0>
    18f8:      	add	x16, sp, #0x210
    18fc:      	str	x16, [sp]
    1900:      	ldr	x0, [sp, #0x280]
    1904:      	str	x1, [sp, #0x258]
    1908:      	ldr	w1, [sp, #0x310]
    190c:      	str	x2, [sp, #0x3f0]
    1910:      	str	x3, [sp, #0x3f8]
    1914:      	mov	x2, #0x1                ; =1
    1918:      	bl	0x1918 <_stogir.verify.integer-operations-target-structured+0xac8>
		0000000000001918:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    191c:      	ldr	x16, [sp]
    1920:      	str	x0, [x16]
    1924:      	str	x1, [x16, #0x8]
    1928:      	add	x16, sp, #0x210
    192c:      	ldr	x0, [x16]
    1930:      	add	x16, sp, #0x210
    1934:      	ldr	x1, [x16, #0x8]
    1938:      	lsr	w0, w0, #0
    193c:      	lsr	x16, x0, #0
    1940:      	cmp	x16, #0x1
    1944:      	b.eq	0x1960 <_stogir.verify.integer-operations-target-structured+0xb10>
    1948:      	b.lo	0x1950 <_stogir.verify.integer-operations-target-structured+0xb00>
    194c:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xb14>
    1950:      	cmp	x16, #0x0
    1954:      	b.eq	0x195c <_stogir.verify.integer-operations-target-structured+0xb0c>
    1958:      	b	0x1964 <_stogir.verify.integer-operations-target-structured+0xb14>
    195c:      	b	0x1968 <_stogir.verify.integer-operations-target-structured+0xb18>
    1960:      	b	0x2060 <_stogir.verify.integer-operations-target-structured+0x1210>
    1964:      	b	0x23ac <_stogir.verify.integer-operations-target-structured+0x155c>
    1968:      	str	x23, [sp, #0x260]
    196c:      	ldr	x0, [sp, #0x2b0]
    1970:      	mov	x1, #0x17               ; =23
    1974:      	add	x2, x19, #0x1
    1978:      	lsr	w2, w2, #0
    197c:      	sxtw	x2, w2
    1980:      	fmov	d31, x0
    1984:      	mov	x0, x2
    1988:      	mov	x2, x1
    198c:      	fmov	x1, d31
    1990:      	ldr	w3, [sp, #0x2f8]
    1994:      	sxtw	x3, w3
    1998:      	add	x3, x3, #0x4
    199c:      	asr	x16, x3, #63
    19a0:      	lsr	x16, x16, #62
    19a4:      	add	x3, x3, x16
    19a8:      	asr	x3, x3, #2
    19ac:      	ldr	x4, [sp, #0x2f0]
    19b0:      	add	x3, x3, x4
    19b4:      	ldr	x8, [sp, #0x2d8]
    19b8:      	ldr	x6, [sp, #0x2a8]
    19bc:      	ldr	x21, [sp, #0x278]
    19c0:      	ldr	x22, [sp, #0x290]
    19c4:      	ldr	x23, [sp, #0x298]
    19c8:      	ldr	w4, [sp, #0x268]
    19cc:      	mov	x7, x24
    19d0:      	ldr	x24, [sp, #0x2b0]
    19d4:      	mov	x9, x25
    19d8:      	ldr	x25, [sp, #0x2b8]
    19dc:      	mov	x10, x26
    19e0:      	ldr	x26, [sp, #0x2c0]
    19e4:      	mov	x11, x27
    19e8:      	ldr	x27, [sp, #0x2c8]
    19ec:      	mov	x12, x28
    19f0:      	ldr	x28, [sp, #0x2d0]
    19f4:      	ldr	x13, [sp, #0x3e8]
    19f8:      	ldr	w5, [sp, #0x2a0]
    19fc:      	ldr	x14, [sp, #0x320]
    1a00:      	ldr	x15, [sp, #0x2e8]
    1a04:      	mov	x19, x0
    1a08:      	ldr	x0, [sp, #0x280]
    1a0c:      	str	x1, [sp, #0x248]
    1a10:      	ldr	x1, [sp, #0x258]
    1a14:      	mov	x20, x2
    1a18:      	mov	x2, x3
    1a1c:      	ldr	x3, [sp, #0x260]
    1a20:      	b	0xfc4 <_stogir.verify.integer-operations-target-structured+0x174>
    1a24:      	movz	x3, #0x0, lsl #48
    1a28:      	b	0x1048 <_stogir.verify.integer-operations-target-structured+0x1f8>
    1a2c:      	cmp	x21, #0x2e
    1a30:      	b.lt	0x1a44 <_stogir.verify.integer-operations-target-structured+0xbf4>
    1a34:      	cmp	x21, #0x35
    1a38:      	b.gt	0x1a44 <_stogir.verify.integer-operations-target-structured+0xbf4>
    1a3c:      	mov	x4, #0x1                ; =1
    1a40:      	b	0x105c <_stogir.verify.integer-operations-target-structured+0x20c>
    1a44:      	cmp	x21, #0x3a
    1a48:      	b.ne	0x1a54 <_stogir.verify.integer-operations-target-structured+0xc04>
    1a4c:      	mov	x4, #0x1                ; =1
    1a50:      	b	0x1a40 <_stogir.verify.integer-operations-target-structured+0xbf0>
    1a54:      	cmp	x21, #0x3b
    1a58:      	cset	w4, eq
    1a5c:      	ubfx	x4, x4, #0, #8
    1a60:      	b	0x1a50 <_stogir.verify.integer-operations-target-structured+0xc00>
    1a64:      	cmp	x21, #0x20
    1a68:      	b.ne	0x1a78 <_stogir.verify.integer-operations-target-structured+0xc28>
    1a6c:      	str	x0, [sp, #0x280]
    1a70:      	mov	x0, #0x1                ; =1
    1a74:      	b	0x106c <_stogir.verify.integer-operations-target-structured+0x21c>
    1a78:      	cmp	x21, #0x2d
    1a7c:      	b.ne	0x1a8c <_stogir.verify.integer-operations-target-structured+0xc3c>
    1a80:      	str	x0, [sp, #0x280]
    1a84:      	mov	x0, #0x1                ; =1
    1a88:      	b	0x1a74 <_stogir.verify.integer-operations-target-structured+0xc24>
    1a8c:      	cmp	x21, #0x36
    1a90:      	b.ne	0x1aa0 <_stogir.verify.integer-operations-target-structured+0xc50>
    1a94:      	str	x0, [sp, #0x280]
    1a98:      	mov	x0, #0x1                ; =1
    1a9c:      	b	0x1a88 <_stogir.verify.integer-operations-target-structured+0xc38>
    1aa0:      	cmp	x21, #0x37
    1aa4:      	b.ne	0x1ab4 <_stogir.verify.integer-operations-target-structured+0xc64>
    1aa8:      	str	x0, [sp, #0x280]
    1aac:      	mov	x0, #0x1                ; =1
    1ab0:      	b	0x1a9c <_stogir.verify.integer-operations-target-structured+0xc4c>
    1ab4:      	cmp	x21, #0x38
    1ab8:      	b.ne	0x1ac8 <_stogir.verify.integer-operations-target-structured+0xc78>
    1abc:      	str	x0, [sp, #0x280]
    1ac0:      	mov	x0, #0x1                ; =1
    1ac4:      	b	0x1ab0 <_stogir.verify.integer-operations-target-structured+0xc60>
    1ac8:      	str	x0, [sp, #0x280]
    1acc:      	cmp	x21, #0x39
    1ad0:      	cset	w0, eq
    1ad4:      	ubfx	x0, x0, #0, #8
    1ad8:      	b	0x1ac4 <_stogir.verify.integer-operations-target-structured+0xc74>
    1adc:      	uxtb	w16, w1
    1ae0:      	cmp	w16, wzr
    1ae4:      	b.ne	0x1110 <_stogir.verify.integer-operations-target-structured+0x2c0>
    1ae8:      	str	x0, [sp, #0x318]
    1aec:      	str	x20, [sp, #0x320]
    1af0:      	mov	w20, w1
    1af4:      	ldr	x0, [sp, #0x248]
    1af8:      	ldr	x1, [sp, #0x270]
    1afc:      	b	0x1188 <_stogir.verify.integer-operations-target-structured+0x338>
    1b00:      	add	x0, x19, #0x1
    1b04:      	lsr	w0, w0, #0
    1b08:      	sxtw	x0, w0
    1b0c:      	ldr	x1, [sp, #0x248]
    1b10:      	ldr	x2, [sp, #0x270]
    1b14:      	b	0x117c <_stogir.verify.integer-operations-target-structured+0x32c>
    1b18:      	mov	x2, x1
    1b1c:      	mov	x1, x0
    1b20:      	mov	x0, #0x1                ; =1
    1b24:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x358>
    1b28:      	mov	x2, x1
    1b2c:      	mov	x1, x0
    1b30:      	movz	x0, #0x0, lsl #48
    1b34:      	b	0x11a8 <_stogir.verify.integer-operations-target-structured+0x358>
    1b38:      	add	x0, x19, #0x1
    1b3c:      	lsr	w0, w0, #0
    1b40:      	sxtw	x0, w0
    1b44:      	ldr	x1, [sp, #0x328]
    1b48:      	ldr	x2, [sp, #0x330]
    1b4c:      	b	0x1214 <_stogir.verify.integer-operations-target-structured+0x3c4>
    1b50:      	brk	#0
    1b54:      	b	0x1b50 <_stogir.verify.integer-operations-target-structured+0xd00>
    1b58:      	ldr	x0, [sp, #0x328]
    1b5c:      	ldr	x1, [sp, #0x330]
    1b60:      	b	0x1220 <_stogir.verify.integer-operations-target-structured+0x3d0>
    1b64:      	cmp	x21, #0x1e
    1b68:      	cset	w2, eq
    1b6c:      	ubfx	x2, x2, #0, #8
    1b70:      	fmov	d31, x0
    1b74:      	mov	x0, x2
    1b78:      	mov	x2, x1
    1b7c:      	fmov	x1, d31
    1b80:      	b	0x1234 <_stogir.verify.integer-operations-target-structured+0x3e4>
    1b84:      	mov	x0, #0x1                ; =1
    1b88:      	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x404>
    1b8c:      	movz	x0, #0x0, lsl #48
    1b90:      	b	0x1254 <_stogir.verify.integer-operations-target-structured+0x404>
    1b94:      	add	x16, sp, #0x70
    1b98:      	ldr	x0, [x16, #0x8]
    1b9c:      	add	x16, sp, #0x20
    1ba0:      	ldr	w1, [x16, #0xc]
    1ba4:      	sxtw	x1, w1
    1ba8:      	cmp	x1, #0x0
    1bac:      	b.ge	0x1bd0 <_stogir.verify.integer-operations-target-structured+0xd80>
    1bb0:      	ldr	x1, [sp, #0x338]
    1bb4:      	ldr	x2, [sp, #0x340]
    1bb8:      	mov	x0, #0x1                ; =1
    1bbc:      	cmp	x0, #0x0
    1bc0:      	b.eq	0x1c3c <_stogir.verify.integer-operations-target-structured+0xdec>
    1bc4:      	ldr	x0, [sp, #0x250]
    1bc8:      	mov	x1, #0x2d               ; =45
    1bcc:      	b	0x12bc <_stogir.verify.integer-operations-target-structured+0x46c>
    1bd0:      	uxtb	w0, w0
    1bd4:      	cmp	x0, #0x83
    1bd8:      	b.ge	0x1c2c <_stogir.verify.integer-operations-target-structured+0xddc>
    1bdc:      	add	x1, x0, x23
    1be0:      	ldrb	w1, [x1]
    1be4:      	uxtb	w1, w1
    1be8:      	and	x1, x1, #0x2
    1bec:      	uxtb	w1, w1
    1bf0:      	cmp	x1, #0x0
    1bf4:      	cset	w1, eq
    1bf8:      	uxtb	w16, w1
    1bfc:      	cmp	w16, wzr
    1c00:      	cset	x1, eq
    1c04:      	cmp	x1, #0x0
    1c08:      	b.ne	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c0c:      	cmp	x0, #0x65
    1c10:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c14:      	cmp	x0, #0x66
    1c18:      	b.eq	0x1c34 <_stogir.verify.integer-operations-target-structured+0xde4>
    1c1c:      	mov	x0, #0x1                ; =1
    1c20:      	ldr	x1, [sp, #0x338]
    1c24:      	ldr	x2, [sp, #0x340]
    1c28:      	b	0x1bbc <_stogir.verify.integer-operations-target-structured+0xd6c>
    1c2c:      	movz	x1, #0x0, lsl #48
    1c30:      	b	0x1be4 <_stogir.verify.integer-operations-target-structured+0xd94>
    1c34:      	movz	x0, #0x0, lsl #48
    1c38:      	b	0x1c20 <_stogir.verify.integer-operations-target-structured+0xdd0>
    1c3c:      	mov	x0, x1
    1c40:      	mov	x1, x2
    1c44:      	b	0x1bcc <_stogir.verify.integer-operations-target-structured+0xd7c>
    1c48:      	brk	#0
    1c4c:      	b	0x1c48 <_stogir.verify.integer-operations-target-structured+0xdf8>
    1c50:      	ldr	x0, [sp, #0x338]
    1c54:      	ldr	x1, [sp, #0x340]
    1c58:      	b	0x12bc <_stogir.verify.integer-operations-target-structured+0x46c>
    1c5c:      	mov	x2, x1
    1c60:      	mov	x1, x0
    1c64:      	movz	x0, #0x0, lsl #48
    1c68:      	b	0x12e0 <_stogir.verify.integer-operations-target-structured+0x490>
    1c6c:      	ubfx	x0, x3, #0, #8
    1c70:      	b	0x12f4 <_stogir.verify.integer-operations-target-structured+0x4a4>
    1c74:      	add	x8, sp, #0xc0
    1c78:      	ldr	x0, [sp, #0x280]
    1c7c:      	ldr	w1, [sp, #0x310]
    1c80:      	bl	0x1c80 <_stogir.verify.integer-operations-target-structured+0xe30>
		0000000000001c80:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    1c84:      	add	x16, sp, #0xc0
    1c88:      	ldr	x0, [x16]
    1c8c:      	add	x16, sp, #0xc0
    1c90:      	ldr	x1, [x16, #0x8]
    1c94:      	add	x16, sp, #0xc0
    1c98:      	ldr	x2, [x16, #0x10]
    1c9c:      	mov	x3, x1
    1ca0:      	ldr	x1, [sp, #0x350]
    1ca4:      	mov	x4, x2
    1ca8:      	mov	x2, x0
    1cac:      	ldr	x0, [sp, #0x348]
    1cb0:      	b	0x134c <_stogir.verify.integer-operations-target-structured+0x4fc>
    1cb4:      	add	x2, x19, #0x1
    1cb8:      	lsr	w2, w2, #0
    1cbc:      	sxtw	x2, w2
    1cc0:      	fmov	d31, x0
    1cc4:      	mov	x0, x2
    1cc8:      	mov	x2, x1
    1ccc:      	fmov	x1, d31
    1cd0:      	b	0x1388 <_stogir.verify.integer-operations-target-structured+0x538>
    1cd4:      	brk	#0
    1cd8:      	b	0x1cd4 <_stogir.verify.integer-operations-target-structured+0xe84>
    1cdc:      	ldr	x0, [sp, #0x348]
    1ce0:      	ldr	x1, [sp, #0x350]
    1ce4:      	b	0x1394 <_stogir.verify.integer-operations-target-structured+0x544>
    1ce8:      	mov	x2, x1
    1cec:      	mov	x1, x0
    1cf0:      	movz	x0, #0x0, lsl #48
    1cf4:      	b	0x13b8 <_stogir.verify.integer-operations-target-structured+0x568>
    1cf8:      	add	x0, x19, #0x1
    1cfc:      	lsr	w0, w0, #0
    1d00:      	sxtw	x0, w0
    1d04:      	ldr	x1, [sp, #0x358]
    1d08:      	ldr	x2, [sp, #0x360]
    1d0c:      	b	0x1424 <_stogir.verify.integer-operations-target-structured+0x5d4>
    1d10:      	brk	#0
    1d14:      	b	0x1d10 <_stogir.verify.integer-operations-target-structured+0xec0>
    1d18:      	ldr	x0, [sp, #0x358]
    1d1c:      	ldr	x1, [sp, #0x360]
    1d20:      	b	0x1430 <_stogir.verify.integer-operations-target-structured+0x5e0>
    1d24:      	cmp	x21, #0x79
    1d28:      	cset	w2, eq
    1d2c:      	ubfx	x2, x2, #0, #8
    1d30:      	fmov	d31, x0
    1d34:      	mov	x0, x2
    1d38:      	mov	x2, x1
    1d3c:      	fmov	x1, d31
    1d40:      	b	0x1444 <_stogir.verify.integer-operations-target-structured+0x5f4>
    1d44:      	add	x0, x19, #0x1
    1d48:      	lsr	w0, w0, #0
    1d4c:      	sxtw	x0, w0
    1d50:      	ldr	x1, [sp, #0x368]
    1d54:      	ldr	x2, [sp, #0x370]
    1d58:      	b	0x14b0 <_stogir.verify.integer-operations-target-structured+0x660>
    1d5c:      	brk	#0
    1d60:      	b	0x1d5c <_stogir.verify.integer-operations-target-structured+0xf0c>
    1d64:      	ldr	x0, [sp, #0x368]
    1d68:      	ldr	x1, [sp, #0x370]
    1d6c:      	b	0x14bc <_stogir.verify.integer-operations-target-structured+0x66c>
    1d70:      	cmp	x21, #0x6d
    1d74:      	b.lt	0x1d98 <_stogir.verify.integer-operations-target-structured+0xf48>
    1d78:      	cmp	x21, #0x6f
    1d7c:      	cset	w2, le
    1d80:      	ubfx	x2, x2, #0, #8
    1d84:      	fmov	d31, x0
    1d88:      	mov	x0, x2
    1d8c:      	mov	x2, x1
    1d90:      	fmov	x1, d31
    1d94:      	b	0x14d0 <_stogir.verify.integer-operations-target-structured+0x680>
    1d98:      	movz	x2, #0x0, lsl #48
    1d9c:      	b	0x1d84 <_stogir.verify.integer-operations-target-structured+0xf34>
    1da0:      	add	x0, x19, #0x1
    1da4:      	lsr	w0, w0, #0
    1da8:      	sxtw	x0, w0
    1dac:      	ldr	x1, [sp, #0x378]
    1db0:      	ldr	x2, [sp, #0x380]
    1db4:      	b	0x153c <_stogir.verify.integer-operations-target-structured+0x6ec>
    1db8:      	brk	#0
    1dbc:      	b	0x1db8 <_stogir.verify.integer-operations-target-structured+0xf68>
    1dc0:      	ldr	x0, [sp, #0x378]
    1dc4:      	ldr	x1, [sp, #0x380]
    1dc8:      	b	0x1548 <_stogir.verify.integer-operations-target-structured+0x6f8>
    1dcc:      	cmp	x21, #0x51
    1dd0:      	b.ne	0x1dec <_stogir.verify.integer-operations-target-structured+0xf9c>
    1dd4:      	mov	x2, #0x1                ; =1
    1dd8:      	fmov	d31, x0
    1ddc:      	mov	x0, x2
    1de0:      	mov	x2, x1
    1de4:      	fmov	x1, d31
    1de8:      	b	0x155c <_stogir.verify.integer-operations-target-structured+0x70c>
    1dec:      	cmp	x21, #0x52
    1df0:      	b.ne	0x1dfc <_stogir.verify.integer-operations-target-structured+0xfac>
    1df4:      	mov	x2, #0x1                ; =1
    1df8:      	b	0x1dd8 <_stogir.verify.integer-operations-target-structured+0xf88>
    1dfc:      	cmp	x21, #0x53
    1e00:      	b.ne	0x1e0c <_stogir.verify.integer-operations-target-structured+0xfbc>
    1e04:      	mov	x2, #0x1                ; =1
    1e08:      	b	0x1df8 <_stogir.verify.integer-operations-target-structured+0xfa8>
    1e0c:      	cmp	x21, #0x54
    1e10:      	cset	w2, eq
    1e14:      	ubfx	x2, x2, #0, #8
    1e18:      	b	0x1e08 <_stogir.verify.integer-operations-target-structured+0xfb8>
    1e1c:      	add	x0, x19, #0x1
    1e20:      	lsr	w0, w0, #0
    1e24:      	sxtw	x0, w0
    1e28:      	ldr	x1, [sp, #0x388]
    1e2c:      	ldr	x2, [sp, #0x390]
    1e30:      	b	0x15c8 <_stogir.verify.integer-operations-target-structured+0x778>
    1e34:      	brk	#0
    1e38:      	b	0x1e34 <_stogir.verify.integer-operations-target-structured+0xfe4>
    1e3c:      	ldr	x0, [sp, #0x388]
    1e40:      	ldr	x1, [sp, #0x390]
    1e44:      	b	0x15d4 <_stogir.verify.integer-operations-target-structured+0x784>
    1e48:      	cmp	x21, #0x48
    1e4c:      	b.ne	0x1e68 <_stogir.verify.integer-operations-target-structured+0x1018>
    1e50:      	mov	x2, #0x1                ; =1
    1e54:      	fmov	d31, x0
    1e58:      	mov	x0, x2
    1e5c:      	mov	x2, x1
    1e60:      	fmov	x1, d31
    1e64:      	b	0x15e8 <_stogir.verify.integer-operations-target-structured+0x798>
    1e68:      	cmp	x21, #0x55
    1e6c:      	b.lt	0x1e80 <_stogir.verify.integer-operations-target-structured+0x1030>
    1e70:      	cmp	x21, #0x58
    1e74:      	cset	w2, le
    1e78:      	ubfx	x2, x2, #0, #8
    1e7c:      	b	0x1e54 <_stogir.verify.integer-operations-target-structured+0x1004>
    1e80:      	movz	x2, #0x0, lsl #48
    1e84:      	b	0x1e7c <_stogir.verify.integer-operations-target-structured+0x102c>
    1e88:      	add	x0, x19, #0x1
    1e8c:      	lsr	w0, w0, #0
    1e90:      	sxtw	x0, w0
    1e94:      	ldr	x2, [sp, #0x398]
    1e98:      	ldr	x3, [sp, #0x3a0]
    1e9c:      	b	0x1660 <_stogir.verify.integer-operations-target-structured+0x810>
    1ea0:      	brk	#0
    1ea4:      	b	0x1ea0 <_stogir.verify.integer-operations-target-structured+0x1050>
    1ea8:      	ldr	x0, [sp, #0x398]
    1eac:      	ldr	x2, [sp, #0x3a0]
    1eb0:      	b	0x166c <_stogir.verify.integer-operations-target-structured+0x81c>
    1eb4:      	mov	x3, x2
    1eb8:      	mov	x2, x0
    1ebc:      	movz	x0, #0x0, lsl #48
    1ec0:      	b	0x1690 <_stogir.verify.integer-operations-target-structured+0x840>
    1ec4:      	add	x0, x19, #0x1
    1ec8:      	lsr	w0, w0, #0
    1ecc:      	sxtw	x0, w0
    1ed0:      	ldr	x2, [sp, #0x3a8]
    1ed4:      	ldr	x3, [sp, #0x3b0]
    1ed8:      	b	0x170c <_stogir.verify.integer-operations-target-structured+0x8bc>
    1edc:      	brk	#0
    1ee0:      	b	0x1edc <_stogir.verify.integer-operations-target-structured+0x108c>
    1ee4:      	ldr	x0, [sp, #0x3a8]
    1ee8:      	ldr	x2, [sp, #0x3b0]
    1eec:      	b	0x1718 <_stogir.verify.integer-operations-target-structured+0x8c8>
    1ef0:      	add	x0, x19, #0x1
    1ef4:      	lsr	w0, w0, #0
    1ef8:      	sxtw	x0, w0
    1efc:      	ldr	x2, [sp, #0x3b8]
    1f00:      	ldr	x3, [sp, #0x3c0]
    1f04:      	b	0x1790 <_stogir.verify.integer-operations-target-structured+0x940>
    1f08:      	brk	#0
    1f0c:      	b	0x1f08 <_stogir.verify.integer-operations-target-structured+0x10b8>
    1f10:      	ldr	x0, [sp, #0x3b8]
    1f14:      	ldr	x2, [sp, #0x3c0]
    1f18:      	b	0x179c <_stogir.verify.integer-operations-target-structured+0x94c>
    1f1c:      	mov	x3, x2
    1f20:      	mov	x2, x0
    1f24:      	mov	x0, #0x1                ; =1
    1f28:      	b	0x17d8 <_stogir.verify.integer-operations-target-structured+0x988>
    1f2c:      	mov	x0, x2
    1f30:      	mov	x2, x3
    1f34:      	b	0x17e8 <_stogir.verify.integer-operations-target-structured+0x998>
    1f38:      	add	x16, sp, #0x20
    1f3c:      	ldr	w3, [x16, #0x8]
    1f40:      	lsr	w3, w3, #0
    1f44:      	add	x8, sp, #0x1c0
    1f48:      	str	x1, [sp, #0x238]
    1f4c:      	mov	w1, w3
    1f50:      	str	x0, [sp, #0x3c8]
    1f54:      	ldr	x0, [sp, #0x280]
    1f58:      	str	x2, [sp, #0x3d0]
    1f5c:      	bl	0x1f5c <_stogir.verify.integer-operations-target-structured+0x110c>
		0000000000001f5c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    1f60:      	add	x16, sp, #0x1c0
    1f64:      	ldr	w0, [x16]
    1f68:      	lsr	x16, x0, #0
    1f6c:      	cmp	x16, #0x1
    1f70:      	b.eq	0x1f8c <_stogir.verify.integer-operations-target-structured+0x113c>
    1f74:      	b.lo	0x1f7c <_stogir.verify.integer-operations-target-structured+0x112c>
    1f78:      	b	0x1f90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1f7c:      	cmp	x16, #0x0
    1f80:      	b.eq	0x1f88 <_stogir.verify.integer-operations-target-structured+0x1138>
    1f84:      	b	0x1f90 <_stogir.verify.integer-operations-target-structured+0x1140>
    1f88:      	b	0x1f94 <_stogir.verify.integer-operations-target-structured+0x1144>
    1f8c:      	b	0x1fa0 <_stogir.verify.integer-operations-target-structured+0x1150>
    1f90:      	b	0x1fdc <_stogir.verify.integer-operations-target-structured+0x118c>
    1f94:      	ldr	x0, [sp, #0x290]
    1f98:      	mov	x1, #0x14               ; =20
    1f9c:      	b	0x17f0 <_stogir.verify.integer-operations-target-structured+0x9a0>
    1fa0:      	add	x16, sp, #0x1c0
    1fa4:      	ldr	x0, [x16, #0x8]
    1fa8:      	add	x16, sp, #0x20
    1fac:      	ldr	w1, [x16]
    1fb0:      	lsr	w0, w0, #0
    1fb4:      	ubfx	x1, x1, #8, #8
    1fb8:      	ubfx	x0, x0, #8, #8
    1fbc:      	cmp	x0, x1
    1fc0:      	b.ne	0x1fd0 <_stogir.verify.integer-operations-target-structured+0x1180>
    1fc4:      	ldr	x0, [sp, #0x3c8]
    1fc8:      	ldr	x1, [sp, #0x3d0]
    1fcc:      	b	0x1f9c <_stogir.verify.integer-operations-target-structured+0x114c>
    1fd0:      	ldr	x0, [sp, #0x298]
    1fd4:      	mov	x1, #0x1a               ; =26
    1fd8:      	b	0x1fcc <_stogir.verify.integer-operations-target-structured+0x117c>
    1fdc:      	brk	#0
    1fe0:      	b	0x1fdc <_stogir.verify.integer-operations-target-structured+0x118c>
    1fe4:      	ldr	x0, [sp, #0x3c8]
    1fe8:      	ldr	x1, [sp, #0x3d0]
    1fec:      	b	0x1800 <_stogir.verify.integer-operations-target-structured+0x9b0>
    1ff0:      	add	x0, x19, #0x1
    1ff4:      	lsr	w0, w0, #0
    1ff8:      	sxtw	x0, w0
    1ffc:      	ldr	x2, [sp, #0x3d8]
    2000:      	ldr	x3, [sp, #0x3e0]
    2004:      	b	0x189c <_stogir.verify.integer-operations-target-structured+0xa4c>
    2008:      	brk	#0
    200c:      	b	0x2008 <_stogir.verify.integer-operations-target-structured+0x11b8>
    2010:      	ldr	x0, [sp, #0x3d8]
    2014:      	ldr	x2, [sp, #0x3e0]
    2018:      	b	0x18a8 <_stogir.verify.integer-operations-target-structured+0xa58>
    201c:      	mov	x3, x2
    2020:      	mov	x2, x0
    2024:      	mov	x0, #0x1                ; =1
    2028:      	b	0x18c0 <_stogir.verify.integer-operations-target-structured+0xa70>
    202c:      	mov	x0, #0x1                ; =1
    2030:      	b	0x18d4 <_stogir.verify.integer-operations-target-structured+0xa84>
    2034:      	ldr	x22, [sp, #0x308]
    2038:      	cmp	x22, #0x0
    203c:      	b.eq	0x2048 <_stogir.verify.integer-operations-target-structured+0x11f8>
    2040:      	mov	x0, #0x1                ; =1
    2044:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2048:      	ldr	x0, [sp, #0x288]
    204c:      	b	0x2044 <_stogir.verify.integer-operations-target-structured+0x11f4>
    2050:      	movz	x0, #0x0, lsl #48
    2054:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2058:      	movz	x0, #0x0, lsl #48
    205c:      	b	0x18f0 <_stogir.verify.integer-operations-target-structured+0xaa0>
    2060:      	lsr	w1, w1, #0
    2064:      	lsr	w1, w1, #0
    2068:      	ldr	x0, [sp, #0x280]
    206c:      	bl	0x206c <_stogir.verify.integer-operations-target-structured+0x121c>
		000000000000206c:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2070:      	cmp	x0, #0x0
    2074:      	b.ne	0x2088 <_stogir.verify.integer-operations-target-structured+0x1238>
    2078:      	str	x23, [sp, #0x260]
    207c:      	ldr	x0, [sp, #0x2b0]
    2080:      	mov	x1, #0x17               ; =23
    2084:      	b	0x1974 <_stogir.verify.integer-operations-target-structured+0xb24>
    2088:      	ldr	w0, [x0]
    208c:      	add	x16, sp, #0x20
    2090:      	ldr	w1, [x16]
    2094:      	ubfx	x0, x0, #8, #8
    2098:      	orr	x2, x0, xzr
    209c:      	ubfx	x1, x1, #8, #8
    20a0:      	cmp	x1, #0x6
    20a4:      	b.ne	0x2210 <_stogir.verify.integer-operations-target-structured+0x13c0>
    20a8:      	cmp	x2, #0x6
    20ac:      	b.ne	0x2200 <_stogir.verify.integer-operations-target-structured+0x13b0>
    20b0:      	cmp	x21, #0x1a
    20b4:      	b.ne	0x21e8 <_stogir.verify.integer-operations-target-structured+0x1398>
    20b8:      	ldr	x3, [sp, #0x3f0]
    20bc:      	ldr	x4, [sp, #0x3f8]
    20c0:      	mov	x1, #0x1                ; =1
    20c4:      	mov	x21, x1
    20c8:      	mov	x1, x3
    20cc:      	mov	x3, x4
    20d0:      	cmp	x2, #0x1
    20d4:      	b.lt	0x2220 <_stogir.verify.integer-operations-target-structured+0x13d0>
    20d8:      	cmp	x2, #0xb
    20dc:      	cset	w4, le
    20e0:      	ubfx	x4, x4, #0, #8
    20e4:      	fmov	d31, x1
    20e8:      	mov	x1, x4
    20ec:      	mov	x4, x3
    20f0:      	fmov	x3, d31
    20f4:      	cmp	x1, #0x0
    20f8:      	b.eq	0x2230 <_stogir.verify.integer-operations-target-structured+0x13e0>
    20fc:      	movz	x1, #0x0, lsl #48
    2100:      	cmp	x1, #0x0
    2104:      	b.eq	0x2238 <_stogir.verify.integer-operations-target-structured+0x13e8>
    2108:      	str	x23, [sp, #0x260]
    210c:      	mov	x23, x2
    2110:      	mov	x1, x3
    2114:      	mov	x2, x4
    2118:      	mov	x0, #0x1                ; =1
    211c:      	cmp	x0, #0x0
    2120:      	b.eq	0x22c4 <_stogir.verify.integer-operations-target-structured+0x1474>
    2124:      	ldr	x0, [sp, #0x2b8]
    2128:      	mov	x1, #0x1c               ; =28
    212c:      	add	x16, sp, #0x20
    2130:      	ldr	w2, [x16]
    2134:      	cmp	x20, #0x0
    2138:      	b.eq	0x22d0 <_stogir.verify.integer-operations-target-structured+0x1480>
    213c:      	mov	x3, x0
    2140:      	mov	x0, #0x1                ; =1
    2144:      	lsr	w0, w0, #0
    2148:      	ubfx	x2, x2, #8, #8
    214c:      	sxtw	x0, w0
    2150:      	cmp	x2, x0
    2154:      	b.ne	0x22dc <_stogir.verify.integer-operations-target-structured+0x148c>
    2158:      	mov	x0, x3
    215c:      	cmp	x20, #0x0
    2160:      	b.eq	0x22e8 <_stogir.verify.integer-operations-target-structured+0x1498>
    2164:      	mov	x20, x0
    2168:      	mov	x0, #0x1                ; =1
    216c:      	cmp	x0, #0x0
    2170:      	b.eq	0x2544 <_stogir.verify.integer-operations-target-structured+0x16f4>
    2174:      	add	x16, sp, #0x220
    2178:      	str	x16, [sp]
    217c:      	ldr	x0, [sp, #0x280]
    2180:      	mov	x22, x1
    2184:      	ldr	w1, [sp, #0x310]
    2188:      	mov	x2, #0x2                ; =2
    218c:      	bl	0x218c <_stogir.verify.integer-operations-target-structured+0x133c>
		000000000000218c:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    2190:      	ldr	x16, [sp]
    2194:      	str	x0, [x16]
    2198:      	str	x1, [x16, #0x8]
    219c:      	add	x16, sp, #0x220
    21a0:      	ldr	x0, [x16]
    21a4:      	add	x16, sp, #0x220
    21a8:      	ldr	x1, [x16, #0x8]
    21ac:      	lsr	w0, w0, #0
    21b0:      	lsr	x16, x0, #0
    21b4:      	cmp	x16, #0x1
    21b8:      	b.eq	0x21d4 <_stogir.verify.integer-operations-target-structured+0x1384>
    21bc:      	b.lo	0x21c4 <_stogir.verify.integer-operations-target-structured+0x1374>
    21c0:      	b	0x21d8 <_stogir.verify.integer-operations-target-structured+0x1388>
    21c4:      	cmp	x16, #0x0
    21c8:      	b.eq	0x21d0 <_stogir.verify.integer-operations-target-structured+0x1380>
    21cc:      	b	0x21d8 <_stogir.verify.integer-operations-target-structured+0x1388>
    21d0:      	b	0x21dc <_stogir.verify.integer-operations-target-structured+0x138c>
    21d4:      	b	0x22f4 <_stogir.verify.integer-operations-target-structured+0x14a4>
    21d8:      	b	0x2398 <_stogir.verify.integer-operations-target-structured+0x1548>
    21dc:      	ldr	x0, [sp, #0x2c8]
    21e0:      	mov	x1, #0x1d               ; =29
    21e4:      	b	0x2084 <_stogir.verify.integer-operations-target-structured+0x1234>
    21e8:      	cmp	x21, #0x1b
    21ec:      	cset	w1, eq
    21f0:      	ubfx	x1, x1, #0, #8
    21f4:      	ldr	x3, [sp, #0x3f0]
    21f8:      	ldr	x4, [sp, #0x3f8]
    21fc:      	b	0x20c4 <_stogir.verify.integer-operations-target-structured+0x1274>
    2200:      	ldr	x3, [sp, #0x3f0]
    2204:      	ldr	x4, [sp, #0x3f8]
    2208:      	movz	x1, #0x0, lsl #48
    220c:      	b	0x20c4 <_stogir.verify.integer-operations-target-structured+0x1274>
    2210:      	ldr	x1, [sp, #0x3f0]
    2214:      	ldr	x3, [sp, #0x3f8]
    2218:      	movz	x21, #0x0, lsl #48
    221c:      	b	0x20d0 <_stogir.verify.integer-operations-target-structured+0x1280>
    2220:      	mov	x4, x3
    2224:      	mov	x3, x1
    2228:      	movz	x1, #0x0, lsl #48
    222c:      	b	0x20f4 <_stogir.verify.integer-operations-target-structured+0x12a4>
    2230:      	mov	x1, #0x1                ; =1
    2234:      	b	0x2100 <_stogir.verify.integer-operations-target-structured+0x12b0>
    2238:      	ldr	w1, [sp, #0x2e0]
    223c:      	lsr	w1, w1, #0
    2240:      	lsr	w0, w0, #0
    2244:      	ldr	x5, [sp, #0x288]
    2248:      	cmp	x5, #0x0
    224c:      	b.eq	0x254c <_stogir.verify.integer-operations-target-structured+0x16fc>
    2250:      	str	x3, [sp, #0x400]
    2254:      	str	x4, [sp, #0x408]
    2258:      	str	w1, [sp, #0x410]
    225c:      	str	w0, [sp, #0x418]
    2260:      	str	x23, [sp, #0x260]
    2264:      	mov	x23, x2
    2268:      	fmov	s31, w0
    226c:      	mov	w0, w1
    2270:      	fmov	w1, s31
    2274:      	bl	0x2274 <_stogir.verify.integer-operations-target-structured+0x1424>
		0000000000002274:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
    2278:      	cmp	x0, #0x0
    227c:      	b.ne	0x2290 <_stogir.verify.integer-operations-target-structured+0x1440>
    2280:      	mov	x0, #0x1                ; =1
    2284:      	ldr	x1, [sp, #0x400]
    2288:      	ldr	x2, [sp, #0x408]
    228c:      	b	0x211c <_stogir.verify.integer-operations-target-structured+0x12cc>
    2290:      	cmp	x22, #0x0
    2294:      	b.eq	0x22bc <_stogir.verify.integer-operations-target-structured+0x146c>
    2298:      	ldr	w0, [sp, #0x410]
    229c:      	ldr	w1, [sp, #0x418]
    22a0:      	bl	0x22a0 <_stogir.verify.integer-operations-target-structured+0x1450>
		00000000000022a0:  ARM64_RELOC_BRANCH26	_stogir.integer-binary.valid-type?
    22a4:      	cmp	x0, #0x0
    22a8:      	cset	w0, ne
    22ac:      	uxtb	w16, w0
    22b0:      	cmp	w16, wzr
    22b4:      	cset	x0, eq
    22b8:      	b	0x2284 <_stogir.verify.integer-operations-target-structured+0x1434>
    22bc:      	movz	x0, #0x0, lsl #48
    22c0:      	b	0x22b8 <_stogir.verify.integer-operations-target-structured+0x1468>
    22c4:      	mov	x0, x1
    22c8:      	mov	x1, x2
    22cc:      	b	0x212c <_stogir.verify.integer-operations-target-structured+0x12dc>
    22d0:      	mov	x3, x0
    22d4:      	mov	x0, x23
    22d8:      	b	0x2144 <_stogir.verify.integer-operations-target-structured+0x12f4>
    22dc:      	ldr	x0, [sp, #0x2c0]
    22e0:      	mov	x1, #0x26               ; =38
    22e4:      	b	0x215c <_stogir.verify.integer-operations-target-structured+0x130c>
    22e8:      	mov	x20, x0
    22ec:      	mov	x0, x22
    22f0:      	b	0x216c <_stogir.verify.integer-operations-target-structured+0x131c>
    22f4:      	lsr	w1, w1, #0
    22f8:      	lsr	w1, w1, #0
    22fc:      	ldr	x0, [sp, #0x280]
    2300:      	bl	0x2300 <_stogir.verify.integer-operations-target-structured+0x14b0>
		0000000000002300:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2304:      	cmp	x0, #0x0
    2308:      	b.ne	0x2318 <_stogir.verify.integer-operations-target-structured+0x14c8>
    230c:      	ldr	x0, [sp, #0x2c8]
    2310:      	mov	x1, #0x1d               ; =29
    2314:      	b	0x21e4 <_stogir.verify.integer-operations-target-structured+0x1394>
    2318:      	ldr	w0, [x0]
    231c:      	ubfx	x0, x0, #8, #8
    2320:      	cmp	x23, x0
    2324:      	b.ne	0x2350 <_stogir.verify.integer-operations-target-structured+0x1500>
    2328:      	mov	x1, x20
    232c:      	mov	x0, #0x1                ; =1
    2330:      	cmp	x0, #0x0
    2334:      	b.eq	0x2384 <_stogir.verify.integer-operations-target-structured+0x1534>
    2338:      	movz	x0, #0x0, lsl #48
    233c:      	cmp	x0, #0x0
    2340:      	b.eq	0x238c <_stogir.verify.integer-operations-target-structured+0x153c>
    2344:      	ldr	x0, [sp, #0x2d0]
    2348:      	mov	x1, #0x1d               ; =29
    234c:      	b	0x2314 <_stogir.verify.integer-operations-target-structured+0x14c4>
    2350:      	cmp	x21, #0x0
    2354:      	b.eq	0x237c <_stogir.verify.integer-operations-target-structured+0x152c>
    2358:      	cmp	x0, #0x5
    235c:      	b.ne	0x236c <_stogir.verify.integer-operations-target-structured+0x151c>
    2360:      	mov	x0, #0x1                ; =1
    2364:      	mov	x1, x20
    2368:      	b	0x2330 <_stogir.verify.integer-operations-target-structured+0x14e0>
    236c:      	cmp	x0, #0xb
    2370:      	cset	w0, eq
    2374:      	ubfx	x0, x0, #0, #8
    2378:      	b	0x2364 <_stogir.verify.integer-operations-target-structured+0x1514>
    237c:      	movz	x0, #0x0, lsl #48
    2380:      	b	0x2364 <_stogir.verify.integer-operations-target-structured+0x1514>
    2384:      	mov	x0, #0x1                ; =1
    2388:      	b	0x233c <_stogir.verify.integer-operations-target-structured+0x14ec>
    238c:      	mov	x0, x1
    2390:      	mov	x1, x22
    2394:      	b	0x234c <_stogir.verify.integer-operations-target-structured+0x14fc>
    2398:      	brk	#0
    239c:      	b	0x2398 <_stogir.verify.integer-operations-target-structured+0x1548>
    23a0:      	mov	x0, x20
    23a4:      	mov	x1, x22
    23a8:      	b	0x21e4 <_stogir.verify.integer-operations-target-structured+0x1394>
    23ac:      	brk	#0
    23b0:      	b	0x23ac <_stogir.verify.integer-operations-target-structured+0x155c>
    23b4:      	mov	x0, x19
    23b8:      	ldr	x1, [sp, #0x3f0]
    23bc:      	ldr	x2, [sp, #0x3f8]
    23c0:      	b	0x1990 <_stogir.verify.integer-operations-target-structured+0xb40>
    23c4:      	brk	#0
    23c8:      	b	0x23c4 <_stogir.verify.integer-operations-target-structured+0x1574>
    23cc:      	uxtb	w16, w1
    23d0:      	cmp	w16, wzr
    23d4:      	b.eq	0x2430 <_stogir.verify.integer-operations-target-structured+0x15e0>
    23d8:      	and	x0, x19, #0xffffffff
    23dc:      	mov	x1, x0
    23e0:      	movz	x0, #0x0, lsl #48
    23e4:      	movz	x2, #0x0, lsl #48
    23e8:      	ldr	x3, [sp, #0x2d8]
    23ec:      	str	x0, [x3]
    23f0:      	str	x1, [x3, #0x8]
    23f4:      	str	x2, [x3, #0x10]
    23f8:      	ldr	x19, [sp, #0x420]
    23fc:      	ldr	x20, [sp, #0x428]
    2400:      	ldr	x21, [sp, #0x430]
    2404:      	ldr	x22, [sp, #0x438]
    2408:      	ldr	x23, [sp, #0x440]
    240c:      	ldr	x24, [sp, #0x448]
    2410:      	ldr	x25, [sp, #0x450]
    2414:      	ldr	x26, [sp, #0x458]
    2418:      	ldr	x27, [sp, #0x460]
    241c:      	ldr	x28, [sp, #0x468]
    2420:      	ldr	x29, [sp, #0x10]
    2424:      	ldr	x30, [sp, #0x18]
    2428:      	add	sp, sp, #0x470
    242c:      	ret
    2430:      	ldr	x1, [sp, #0x248]
    2434:      	ldr	x2, [sp, #0x270]
    2438:      	mov	x0, #0x1                ; =1
    243c:      	b	0x23e8 <_stogir.verify.integer-operations-target-structured+0x1598>
    2440:      	str	x8, [sp, #0x2d8]
    2444:      	str	x20, [sp, #0x270]
    2448:      	b	0x23cc <_stogir.verify.integer-operations-target-structured+0x157c>
    244c:      	str	x8, [sp, #0x2d8]
    2450:      	str	x20, [sp, #0x270]
    2454:      	b	0x23cc <_stogir.verify.integer-operations-target-structured+0x157c>
    2458:      	str	x1, [sp, #0x328]
    245c:      	str	x2, [sp, #0x330]
    2460:      	b	0x1b58 <_stogir.verify.integer-operations-target-structured+0xd08>
    2464:      	str	x1, [sp, #0x338]
    2468:      	str	x2, [sp, #0x340]
    246c:      	b	0x1c50 <_stogir.verify.integer-operations-target-structured+0xe00>
    2470:      	str	x1, [sp, #0x348]
    2474:      	str	x2, [sp, #0x350]
    2478:      	b	0x1cdc <_stogir.verify.integer-operations-target-structured+0xe8c>
    247c:      	str	x1, [sp, #0x348]
    2480:      	str	x2, [sp, #0x350]
    2484:      	b	0x1c74 <_stogir.verify.integer-operations-target-structured+0xe24>
    2488:      	str	x1, [sp, #0x358]
    248c:      	str	x2, [sp, #0x360]
    2490:      	b	0x1d18 <_stogir.verify.integer-operations-target-structured+0xec8>
    2494:      	str	x1, [sp, #0x368]
    2498:      	str	x2, [sp, #0x370]
    249c:      	b	0x1d64 <_stogir.verify.integer-operations-target-structured+0xf14>
    24a0:      	str	x1, [sp, #0x378]
    24a4:      	str	x2, [sp, #0x380]
    24a8:      	b	0x1dc0 <_stogir.verify.integer-operations-target-structured+0xf70>
    24ac:      	str	x1, [sp, #0x388]
    24b0:      	str	x2, [sp, #0x390]
    24b4:      	b	0x1e3c <_stogir.verify.integer-operations-target-structured+0xfec>
    24b8:      	str	x1, [sp, #0x398]
    24bc:      	ldr	x1, [sp, #0x320]
    24c0:      	str	x2, [sp, #0x3a0]
    24c4:      	b	0x1ea8 <_stogir.verify.integer-operations-target-structured+0x1058>
    24c8:      	str	x1, [sp, #0x320]
    24cc:      	ldr	x1, [sp, #0x2e8]
    24d0:      	str	x2, [sp, #0x3a8]
    24d4:      	str	x3, [sp, #0x3b0]
    24d8:      	b	0x1ee4 <_stogir.verify.integer-operations-target-structured+0x1094>
    24dc:      	str	x1, [sp, #0x2e8]
    24e0:      	ldr	x1, [sp, #0x238]
    24e4:      	str	x0, [sp, #0x3b8]
    24e8:      	str	x2, [sp, #0x3c0]
    24ec:      	b	0x1f10 <_stogir.verify.integer-operations-target-structured+0x10c0>
    24f0:      	str	x1, [sp, #0x238]
    24f4:      	str	x0, [sp, #0x3c8]
    24f8:      	str	x2, [sp, #0x3d0]
    24fc:      	b	0x1fe4 <_stogir.verify.integer-operations-target-structured+0x1194>
    2500:      	str	x22, [sp, #0x3e8]
    2504:      	mov	x22, x2
    2508:      	str	x0, [sp, #0x3d8]
    250c:      	str	x1, [sp, #0x3e0]
    2510:      	ldr	x1, [sp, #0x258]
    2514:      	b	0x2010 <_stogir.verify.integer-operations-target-structured+0x11c0>
    2518:      	ldr	x20, [sp, #0x300]
    251c:      	ldr	x22, [sp, #0x308]
    2520:      	b	0x2058 <_stogir.verify.integer-operations-target-structured+0x1208>
    2524:      	ldr	x20, [sp, #0x300]
    2528:      	ldr	x22, [sp, #0x308]
    252c:      	b	0x2050 <_stogir.verify.integer-operations-target-structured+0x1200>
    2530:      	str	x1, [sp, #0x258]
    2534:      	str	x23, [sp, #0x260]
    2538:      	str	x2, [sp, #0x3f0]
    253c:      	str	x3, [sp, #0x3f8]
    2540:      	b	0x23b4 <_stogir.verify.integer-operations-target-structured+0x1564>
    2544:      	mov	x22, x1
    2548:      	b	0x23a0 <_stogir.verify.integer-operations-target-structured+0x1550>
    254c:      	str	w1, [sp, #0x410]
    2550:      	str	w0, [sp, #0x418]
    2554:      	str	x23, [sp, #0x260]
    2558:      	mov	x23, x2
    255c:      	str	x3, [sp, #0x400]
    2560:      	str	x4, [sp, #0x408]
    2564:      	b	0x2290 <_stogir.verify.integer-operations-target-structured+0x1440>

0000000000002568 <_coil.core.Len$coil.arraylist.ArrayList$len__i32>:
    2568:      	ldr	x0, [x0, #0x8]
    256c:      	ret

0000000000002570 <_coil.core.Eq$slice<u8>$=>:
    2570:      	sub	sp, sp, #0x10
    2574:      	str	x29, [sp]
    2578:      	str	x30, [sp, #0x8]
    257c:      	mov	x29, sp
    2580:      	cmp	x1, x3
    2584:      	b.ne	0x25c4 <_coil.core.Eq$slice<u8>$=+0x54>
    2588:      	cmp	x1, #0x0
    258c:      	b.ne	0x2598 <_coil.core.Eq$slice<u8>$=+0x28>
    2590:      	mov	x0, #0x1                ; =1
    2594:      	b	0x25c0 <_coil.core.Eq$slice<u8>$=+0x50>
    2598:      	lsr	x1, x1, #0
    259c:      	fmov	d31, x1
    25a0:      	mov	x1, x2
    25a4:      	fmov	x2, d31
    25a8:      	bl	0x25a8 <_coil.core.Eq$slice<u8>$=+0x38>
		00000000000025a8:  ARM64_RELOC_BRANCH26	_memcmp
    25ac:      	lsr	w0, w0, #0
    25b0:      	sxtw	x0, w0
    25b4:      	cmp	x0, #0x0
    25b8:      	cset	w0, eq
    25bc:      	ubfx	x0, x0, #0, #8
    25c0:      	b	0x25c8 <_coil.core.Eq$slice<u8>$=+0x58>
    25c4:      	movz	x0, #0x0, lsl #48
    25c8:      	ldr	x29, [sp]
    25cc:      	ldr	x30, [sp, #0x8]
    25d0:      	add	sp, sp, #0x10
    25d4:      	ret

00000000000025d8 <_stogir.node.opcode>:
    25d8:      	ldr	w0, [x0]
    25dc:      	uxtb	w0, w0
    25e0:      	ret

00000000000025e4 <_stogir.opcode.valid?>:
    25e4:      	sxtw	x0, w0
    25e8:      	cmp	x0, #0x0
    25ec:      	b.lt	0x2600 <_stogir.opcode.valid?+0x1c>
    25f0:      	cmp	x0, #0x83
    25f4:      	cset	w0, lt
    25f8:      	ubfx	x0, x0, #0, #8
    25fc:      	b	0x2604 <_stogir.opcode.valid?+0x20>
    2600:      	movz	x0, #0x0, lsl #48
    2604:      	ret

0000000000002608 <_stogir.node.type-id>:
    2608:      	ldr	w0, [x0]
    260c:      	ubfx	x0, x0, #8, #8
    2610:      	ret

0000000000002614 <_stogir.types.valid?>:
    2614:      	sxtw	x0, w0
    2618:      	cmp	x0, #0x0
    261c:      	b.lt	0x2630 <_stogir.types.valid?+0x1c>
    2620:      	cmp	x0, #0xd
    2624:      	b.gt	0x2630 <_stogir.types.valid?+0x1c>
    2628:      	mov	x0, #0x1                ; =1
    262c:      	ret
    2630:      	cmp	x0, #0xf
    2634:      	b.le	0x266c <_stogir.types.valid?+0x58>
    2638:      	cmp	x0, #0x80
    263c:      	b.ge	0x2664 <_stogir.types.valid?+0x50>
    2640:      	and	x0, x0, #0xf
    2644:      	lsr	w0, w0, #0
    2648:      	sxtw	x0, w0
    264c:      	cmp	x0, #0x1
    2650:      	b.lt	0x2674 <_stogir.types.valid?+0x60>
    2654:      	cmp	x0, #0xd
    2658:      	cset	w0, le
    265c:      	ubfx	x0, x0, #0, #8
    2660:      	b	0x2678 <_stogir.types.valid?+0x64>
    2664:      	movz	x0, #0x0, lsl #48
    2668:      	b	0x2670 <_stogir.types.valid?+0x5c>
    266c:      	movz	x0, #0x0, lsl #48
    2670:      	ret
    2674:      	movz	x0, #0x0, lsl #48
    2678:      	b	0x2668 <_stogir.types.valid?+0x54>

000000000000267c <_stogir.opcode.operand-slots>:
    267c:      	sxtw	x0, w0
    2680:      	cmp	x0, #0x0
    2684:      	b.lt	0x26b0 <_stogir.opcode.operand-slots+0x34>
    2688:      	cmp	x0, #0x83
    268c:      	b.ge	0x26b0 <_stogir.opcode.operand-slots+0x34>
    2690:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002690:  ARM64_RELOC_PAGE21	l_stogir.334
    2694:      	ldr	x16, [x16]
		0000000000002694:  ARM64_RELOC_PAGEOFF12	l_stogir.334
    2698:      	orr	x1, x16, xzr
    269c:      	lsr	x0, x0, #0
    26a0:      	add	x0, x0, x1
    26a4:      	ldrsb	w0, [x0]
    26a8:      	sxtb	x0, w0
    26ac:      	b	0x26b4 <_stogir.opcode.operand-slots+0x38>
    26b0:      	mov	x0, #-0x2               ; =-2
    26b4:      	ret

00000000000026b8 <_stogir.opcode.input-count>:
    26b8:      	sxtw	x0, w0
    26bc:      	cmp	x0, #0x0
    26c0:      	b.lt	0x26ec <_stogir.opcode.input-count+0x34>
    26c4:      	cmp	x0, #0x83
    26c8:      	b.ge	0x26ec <_stogir.opcode.input-count+0x34>
    26cc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		00000000000026cc:  ARM64_RELOC_PAGE21	l_stogir.335
    26d0:      	ldr	x16, [x16]
		00000000000026d0:  ARM64_RELOC_PAGEOFF12	l_stogir.335
    26d4:      	orr	x1, x16, xzr
    26d8:      	lsr	x0, x0, #0
    26dc:      	add	x0, x0, x1
    26e0:      	ldrsb	w0, [x0]
    26e4:      	sxtb	x0, w0
    26e8:      	b	0x26f0 <_stogir.opcode.input-count+0x38>
    26ec:      	mov	x0, #-0x2               ; =-2
    26f0:      	ret

00000000000026f4 <_stogir.node.auxiliary>:
    26f4:      	ldr	w0, [x0]
    26f8:      	ubfx	x0, x0, #16, #16
    26fc:      	ret

0000000000002700 <_stogir.opcode.operand-code>:
    2700:      	sxtw	x0, w0
    2704:      	cmp	x0, #0x0
    2708:      	b.lt	0x2748 <_stogir.opcode.operand-code+0x48>
    270c:      	cmp	x0, #0x83
    2710:      	b.ge	0x2748 <_stogir.opcode.operand-code+0x48>
    2714:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002714:  ARM64_RELOC_PAGE21	l_stogir.336
    2718:      	ldr	x16, [x16]
		0000000000002718:  ARM64_RELOC_PAGEOFF12	l_stogir.336
    271c:      	orr	x2, x16, xzr
    2720:      	lsl	x0, x0, #2
    2724:      	sxtw	x1, w1
    2728:      	add	x0, x0, x2
    272c:      	ldr	w0, [x0]
    2730:      	cmp	x1, #0x0
    2734:      	b.le	0x277c <_stogir.opcode.operand-code+0x7c>
    2738:      	cmp	x1, #0x4
    273c:      	b.le	0x2750 <_stogir.opcode.operand-code+0x50>
    2740:      	mov	x1, #0x4                ; =4
    2744:      	b	0x275c <_stogir.opcode.operand-code+0x5c>
    2748:      	movz	x0, #0x0, lsl #48
    274c:      	ret
    2750:      	sub	x1, x1, #0x1
    2754:      	lsr	w1, w1, #0
    2758:      	sxtw	x1, w1
    275c:      	lsl	x1, x1, #2
    2760:      	lsr	w1, w1, #0
    2764:      	ubfx	x1, x1, #0, #32
    2768:      	lsr	x0, x0, x1
    276c:      	lsr	w0, w0, #0
    2770:      	and	x0, x0, #0xf
    2774:      	lsr	w0, w0, #0
    2778:      	b	0x2780 <_stogir.opcode.operand-code+0x80>
    277c:      	movz	x0, #0x0, lsl #48
    2780:      	ret

0000000000002784 <_stogir.graph.operand>:
    2784:      	sub	sp, sp, #0x10
    2788:      	mov	x3, sp
    278c:      	sxtw	x1, w1
    2790:      	cmp	x1, #0x0
    2794:      	b.le	0x27d8 <_stogir.graph.operand+0x54>
    2798:      	lsl	x4, x1, #2
    279c:      	ldr	x5, [x0, #0x8]
    27a0:      	cmp	x1, x5
    27a4:      	b.ge	0x280c <_stogir.graph.operand+0x88>
    27a8:      	add	x5, x0, #0x78
    27ac:      	ldr	x5, [x5, #0x8]
    27b0:      	cmp	x1, x5
    27b4:      	b.ge	0x2804 <_stogir.graph.operand+0x80>
    27b8:      	ldr	x5, [x0, #0x78]
    27bc:      	add	x5, x4, x5
    27c0:      	ldr	w5, [x5]
    27c4:      	sxtw	x5, w5
    27c8:      	cmp	x5, #0x0
    27cc:      	cset	w5, ge
    27d0:      	ubfx	x5, x5, #0, #8
    27d4:      	b	0x2808 <_stogir.graph.operand+0x84>
    27d8:      	movz	x0, #0x0, lsl #48
    27dc:      	movz	x1, #0x0, lsl #48
    27e0:      	str	x0, [x3]
    27e4:      	str	x1, [x3, #0x8]
    27e8:      	ldr	x0, [sp]
    27ec:      	ldr	x1, [sp, #0x8]
    27f0:      	add	sp, sp, #0x10
    27f4:      	ret
    27f8:      	movz	x0, #0x0, lsl #48
    27fc:      	movz	x1, #0x0, lsl #48
    2800:      	b	0x27e0 <_stogir.graph.operand+0x5c>
    2804:      	movz	x5, #0x0, lsl #48
    2808:      	b	0x2810 <_stogir.graph.operand+0x8c>
    280c:      	movz	x5, #0x0, lsl #48
    2810:      	cmp	x5, #0x0
    2814:      	b.eq	0x27d8 <_stogir.graph.operand+0x54>
    2818:      	sxtw	x2, w2
    281c:      	cmp	x2, #0x1
    2820:      	b.lt	0x27f8 <_stogir.graph.operand+0x74>
    2824:      	ldr	x5, [x0, #0x78]
    2828:      	add	x4, x4, x5
    282c:      	ldr	w4, [x4]
    2830:      	sxtw	x4, w4
    2834:      	cmp	x2, x4
    2838:      	b.gt	0x27f8 <_stogir.graph.operand+0x74>
    283c:      	asr	x16, x2, #63
    2840:      	lsr	x16, x16, #62
    2844:      	add	x4, x2, x16
    2848:      	asr	x4, x4, #2
    284c:      	asr	x16, x2, #63
    2850:      	lsr	x16, x16, #62
    2854:      	add	x2, x2, x16
    2858:      	and	x2, x2, #0x3
    285c:      	sub	x2, x2, x16
    2860:      	ldr	x0, [x0]
    2864:      	add	x1, x4, x1
    2868:      	lsl	x2, x2, #2
    286c:      	lsl	x1, x1, #4
    2870:      	add	x0, x1, x0
    2874:      	add	x0, x2, x0
    2878:      	ldr	w0, [x0]
    287c:      	sxtw	x0, w0
    2880:      	and	x0, x0, #0xffffffff
    2884:      	mov	x1, x0
    2888:      	mov	x0, #0x1                ; =1
    288c:      	b	0x2800 <_stogir.graph.operand+0x7c>

0000000000002890 <_stogir.graph.borrow-node>:
    2890:      	sxtw	x1, w1
    2894:      	cmp	x1, #0x0
    2898:      	cset	w2, gt
    289c:      	movz	x16, #0x0, lsl #48
    28a0:      	sub	x3, x16, x1
    28a4:      	sub	x4, x3, #0x1
    28a8:      	uxtb	w16, w2
    28ac:      	cmp	w16, wzr
    28b0:      	b.eq	0x28f4 <_stogir.graph.borrow-node+0x64>
    28b4:      	ldr	x3, [x0, #0x8]
    28b8:      	cmp	x1, x3
    28bc:      	b.ge	0x2948 <_stogir.graph.borrow-node+0xb8>
    28c0:      	add	x3, x0, #0x78
    28c4:      	ldr	x3, [x3, #0x8]
    28c8:      	cmp	x1, x3
    28cc:      	b.ge	0x2990 <_stogir.graph.borrow-node+0x100>
    28d0:      	lsl	x3, x1, #2
    28d4:      	ldr	x5, [x0, #0x78]
    28d8:      	add	x3, x3, x5
    28dc:      	ldr	w3, [x3]
    28e0:      	sxtw	x3, w3
    28e4:      	cmp	x3, #0x0
    28e8:      	cset	w3, ge
    28ec:      	ubfx	x3, x3, #0, #8
    28f0:      	b	0x2994 <_stogir.graph.borrow-node+0x104>
    28f4:      	cmp	x1, #0x0
    28f8:      	b.ge	0x2950 <_stogir.graph.borrow-node+0xc0>
    28fc:      	add	x5, x0, #0x28
    2900:      	add	x6, x0, #0x50
    2904:      	ldr	x5, [x5, #0x8]
    2908:      	ldr	x6, [x6, #0x8]
    290c:      	cmp	x5, x6
    2910:      	b.ne	0x2940 <_stogir.graph.borrow-node+0xb0>
    2914:      	cmp	x3, x5
    2918:      	b.gt	0x2998 <_stogir.graph.borrow-node+0x108>
    291c:      	lsl	x3, x4, #2
    2920:      	ldr	x5, [x0, #0x50]
    2924:      	add	x3, x3, x5
    2928:      	ldr	w3, [x3]
    292c:      	sxtw	x3, w3
    2930:      	cmp	x3, #0x0
    2934:      	cset	w3, gt
    2938:      	ubfx	x3, x3, #0, #8
    293c:      	b	0x299c <_stogir.graph.borrow-node+0x10c>
    2940:      	movz	x3, #0x0, lsl #48
    2944:      	b	0x2954 <_stogir.graph.borrow-node+0xc4>
    2948:      	movz	x3, #0x0, lsl #48
    294c:      	b	0x2954 <_stogir.graph.borrow-node+0xc4>
    2950:      	movz	x3, #0x0, lsl #48
    2954:      	cmp	x3, #0x0
    2958:      	b.eq	0x2988 <_stogir.graph.borrow-node+0xf8>
    295c:      	uxtb	w16, w2
    2960:      	cmp	w16, wzr
    2964:      	b.eq	0x2978 <_stogir.graph.borrow-node+0xe8>
    2968:      	lsl	x1, x1, #4
    296c:      	ldr	x0, [x0]
    2970:      	add	x0, x1, x0
    2974:      	b	0x2984 <_stogir.graph.borrow-node+0xf4>
    2978:      	lsl	x1, x4, #4
    297c:      	ldr	x0, [x0, #0x28]
    2980:      	add	x0, x1, x0
    2984:      	b	0x298c <_stogir.graph.borrow-node+0xfc>
    2988:      	movz	x0, #0x0, lsl #48
    298c:      	ret
    2990:      	movz	x3, #0x0, lsl #48
    2994:      	b	0x294c <_stogir.graph.borrow-node+0xbc>
    2998:      	movz	x3, #0x0, lsl #48
    299c:      	b	0x2944 <_stogir.graph.borrow-node+0xb4>

00000000000029a0 <_stogir.strings.lookup>:
    29a0:      	sxtw	x1, w1
    29a4:      	cmp	x1, #0x0
    29a8:      	b.le	0x2a24 <_stogir.strings.lookup+0x84>
    29ac:      	add	x2, x0, #0x28
    29b0:      	ldr	x2, [x2, #0x8]
    29b4:      	cmp	x1, x2
    29b8:      	b.gt	0x2a24 <_stogir.strings.lookup+0x84>
    29bc:      	sub	x1, x1, #0x1
    29c0:      	mov	x17, #0x18              ; =24
    29c4:      	mul	x1, x1, x17
    29c8:      	ldr	x2, [x0, #0x28]
    29cc:      	add	x1, x1, x2
    29d0:      	ldr	x2, [x1]
    29d4:      	ldr	x1, [x1, #0x8]
    29d8:      	ldr	x3, [x0, #0x8]
    29dc:      	cmp	x2, #0x0
    29e0:      	b.lt	0x2a40 <_stogir.strings.lookup+0xa0>
    29e4:      	cmp	x2, x3
    29e8:      	b.gt	0x2a40 <_stogir.strings.lookup+0xa0>
    29ec:      	cmp	x1, #0x0
    29f0:      	b.lt	0x2a40 <_stogir.strings.lookup+0xa0>
    29f4:      	sub	x3, x3, x2
    29f8:      	cmp	x1, x3
    29fc:      	b.gt	0x2a40 <_stogir.strings.lookup+0xa0>
    2a00:      	add	x1, x1, x2
    2a04:      	lsr	x3, x2, #0
    2a08:      	sub	x1, x1, x2
    2a0c:      	ldr	x0, [x0]
    2a10:      	add	x0, x3, x0
    2a14:      	mov	x2, x1
    2a18:      	mov	x1, x0
    2a1c:      	mov	x0, #0x1                ; =1
    2a20:      	b	0x2a4c <_stogir.strings.lookup+0xac>
    2a24:      	movz	x0, #0x0, lsl #48
    2a28:      	movz	x1, #0x0, lsl #48
    2a2c:      	movz	x2, #0x0, lsl #48
    2a30:      	str	x0, [x8]
    2a34:      	str	x1, [x8, #0x8]
    2a38:      	str	x2, [x8, #0x10]
    2a3c:      	ret
    2a40:      	movz	x0, #0x0, lsl #48
    2a44:      	movz	x1, #0x0, lsl #48
    2a48:      	movz	x2, #0x0, lsl #48
    2a4c:      	b	0x2a30 <_stogir.strings.lookup+0x90>

0000000000002a50 <_stogir.uses.edge-code?>:
    2a50:      	ubfx	x0, x0, #0, #32
    2a54:      	cmp	x0, #0xf
    2a58:      	b.hs	0x2a8c <_stogir.uses.edge-code?+0x3c>
    2a5c:      	mov	x16, #0x1               ; =1
    2a60:      	lsl	x0, x16, x0
    2a64:      	lsr	w0, w0, #0
    2a68:      	mov	x17, #0x5e1c            ; =24092
    2a6c:      	and	x0, x0, x17
    2a70:      	lsr	w0, w0, #0
    2a74:      	cmp	x0, #0x0
    2a78:      	cset	w0, eq
    2a7c:      	uxtb	w16, w0
    2a80:      	cmp	w16, wzr
    2a84:      	cset	x0, eq
    2a88:      	b	0x2a90 <_stogir.uses.edge-code?+0x40>
    2a8c:      	movz	x0, #0x0, lsl #48
    2a90:      	ret

0000000000002a94 <_stogir.graph.contains?>:
    2a94:      	sxtw	x1, w1
    2a98:      	cmp	x1, #0x0
    2a9c:      	b.le	0x2ae0 <_stogir.graph.contains?+0x4c>
    2aa0:      	ldr	x2, [x0, #0x8]
    2aa4:      	cmp	x1, x2
    2aa8:      	b.ge	0x2b40 <_stogir.graph.contains?+0xac>
    2aac:      	add	x2, x0, #0x78
    2ab0:      	ldr	x2, [x2, #0x8]
    2ab4:      	cmp	x1, x2
    2ab8:      	b.ge	0x2b50 <_stogir.graph.contains?+0xbc>
    2abc:      	lsl	x1, x1, #2
    2ac0:      	ldr	x0, [x0, #0x78]
    2ac4:      	add	x0, x1, x0
    2ac8:      	ldr	w0, [x0]
    2acc:      	sxtw	x0, w0
    2ad0:      	cmp	x0, #0x0
    2ad4:      	cset	w0, ge
    2ad8:      	ubfx	x0, x0, #0, #8
    2adc:      	b	0x2b54 <_stogir.graph.contains?+0xc0>
    2ae0:      	cmp	x1, #0x0
    2ae4:      	b.ge	0x2b48 <_stogir.graph.contains?+0xb4>
    2ae8:      	add	x2, x0, #0x28
    2aec:      	add	x3, x0, #0x50
    2af0:      	ldr	x2, [x2, #0x8]
    2af4:      	ldr	x3, [x3, #0x8]
    2af8:      	cmp	x2, x3
    2afc:      	b.ne	0x2b60 <_stogir.graph.contains?+0xcc>
    2b00:      	movz	x16, #0x0, lsl #48
    2b04:      	sub	x3, x16, x1
    2b08:      	cmp	x3, x2
    2b0c:      	b.gt	0x2b58 <_stogir.graph.contains?+0xc4>
    2b10:      	movz	x16, #0x0, lsl #48
    2b14:      	sub	x1, x16, x1
    2b18:      	sub	x1, x1, #0x1
    2b1c:      	lsl	x1, x1, #2
    2b20:      	ldr	x0, [x0, #0x50]
    2b24:      	add	x0, x1, x0
    2b28:      	ldr	w0, [x0]
    2b2c:      	sxtw	x0, w0
    2b30:      	cmp	x0, #0x0
    2b34:      	cset	w0, gt
    2b38:      	ubfx	x0, x0, #0, #8
    2b3c:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b40:      	movz	x0, #0x0, lsl #48
    2b44:      	b	0x2b54 <_stogir.graph.contains?+0xc0>
    2b48:      	movz	x0, #0x0, lsl #48
    2b4c:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b50:      	movz	x0, #0x0, lsl #48
    2b54:      	b	0x2b5c <_stogir.graph.contains?+0xc8>
    2b58:      	movz	x0, #0x0, lsl #48
    2b5c:      	ret
    2b60:      	movz	x0, #0x0, lsl #48
    2b64:      	b	0x2b5c <_stogir.graph.contains?+0xc8>

0000000000002b68 <_stogir.opcode.optional-reference?>:
    2b68:      	sub	sp, sp, #0x30
    2b6c:      	str	x29, [sp]
    2b70:      	str	x30, [sp, #0x8]
    2b74:      	mov	x29, sp
    2b78:      	str	x19, [sp, #0x10]
    2b7c:      	str	x20, [sp, #0x18]
    2b80:      	str	x21, [sp, #0x20]
    2b84:      	lsr	w0, w0, #0
    2b88:      	lsr	w2, w2, #0
    2b8c:      	mov	w19, w0
    2b90:      	mov	w20, w1
    2b94:      	mov	w1, w2
    2b98:      	mov	w21, w2
    2b9c:      	bl	0x2b9c <_stogir.opcode.optional-reference?+0x34>
		0000000000002b9c:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    2ba0:      	lsr	w0, w0, #0
    2ba4:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002ba4:  ARM64_RELOC_PAGE21	l_stogir.337
    2ba8:      	ldr	x16, [x16]
		0000000000002ba8:  ARM64_RELOC_PAGEOFF12	l_stogir.337
    2bac:      	ldr	w1, [x16]
    2bb0:      	cmp	x0, x1
    2bb4:      	b.ne	0x2be0 <_stogir.opcode.optional-reference?+0x78>
    2bb8:      	mov	x0, #0x1                ; =1
    2bbc:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2bc0:      	movz	x0, #0x0, lsl #48
    2bc4:      	ldr	x19, [sp, #0x10]
    2bc8:      	ldr	x20, [sp, #0x18]
    2bcc:      	ldr	x21, [sp, #0x20]
    2bd0:      	ldr	x29, [sp]
    2bd4:      	ldr	x30, [sp, #0x8]
    2bd8:      	add	sp, sp, #0x30
    2bdc:      	ret
    2be0:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002be0:  ARM64_RELOC_PAGE21	l_stogir.338
    2be4:      	ldr	x16, [x16]
		0000000000002be4:  ARM64_RELOC_PAGEOFF12	l_stogir.338
    2be8:      	ldr	w1, [x16]
    2bec:      	cmp	x0, x1
    2bf0:      	b.ne	0x2bfc <_stogir.opcode.optional-reference?+0x94>
    2bf4:      	mov	x0, #0x1                ; =1
    2bf8:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2bfc:      	adrp	x16, 0x2000 <_stogir.verify.integer-operations-target-structured+0x11b0>
		0000000000002bfc:  ARM64_RELOC_PAGE21	l_stogir.339
    2c00:      	ldr	x16, [x16]
		0000000000002c00:  ARM64_RELOC_PAGEOFF12	l_stogir.339
    2c04:      	ldr	w1, [x16]
    2c08:      	cmp	x0, x1
    2c0c:      	b.ne	0x2c18 <_stogir.opcode.optional-reference?+0xb0>
    2c10:      	mov	x0, #0x1                ; =1
    2c14:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2c18:      	sxtw	x19, w19
    2c1c:      	cmp	x19, #0x78
    2c20:      	b.ne	0x2c44 <_stogir.opcode.optional-reference?+0xdc>
    2c24:      	sxtw	x20, w20
    2c28:      	cmp	x20, #0x0
    2c2c:      	b.ne	0x2bc0 <_stogir.opcode.optional-reference?+0x58>
    2c30:      	sxtw	x21, w21
    2c34:      	cmp	x21, #0x2
    2c38:      	cset	w0, eq
    2c3c:      	ubfx	x0, x0, #0, #8
    2c40:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>
    2c44:      	movz	x0, #0x0, lsl #48
    2c48:      	b	0x2bc4 <_stogir.opcode.optional-reference?+0x5c>

0000000000002c4c <_stogir.integer-binary.operation?>:
    2c4c:      	sxtw	x0, w0
    2c50:      	cmp	x0, #0x1a
    2c54:      	b.lt	0x2c68 <_stogir.integer-binary.operation?+0x1c>
    2c58:      	cmp	x0, #0x1e
    2c5c:      	b.gt	0x2c68 <_stogir.integer-binary.operation?+0x1c>
    2c60:      	mov	x0, #0x1                ; =1
    2c64:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c68:      	cmp	x0, #0x2e
    2c6c:      	b.lt	0x2c80 <_stogir.integer-binary.operation?+0x34>
    2c70:      	cmp	x0, #0x35
    2c74:      	b.gt	0x2c80 <_stogir.integer-binary.operation?+0x34>
    2c78:      	mov	x0, #0x1                ; =1
    2c7c:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c80:      	cmp	x0, #0x3a
    2c84:      	b.ne	0x2c90 <_stogir.integer-binary.operation?+0x44>
    2c88:      	mov	x0, #0x1                ; =1
    2c8c:      	b	0x2c9c <_stogir.integer-binary.operation?+0x50>
    2c90:      	cmp	x0, #0x3b
    2c94:      	cset	w0, eq
    2c98:      	ubfx	x0, x0, #0, #8
    2c9c:      	ret

0000000000002ca0 <_stogir.integer-unary.operation?>:
    2ca0:      	sxtw	x0, w0
    2ca4:      	cmp	x0, #0x1f
    2ca8:      	b.ne	0x2cc4 <_stogir.integer-unary.operation?+0x24>
    2cac:      	mov	x0, #0x1                ; =1
    2cb0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cb4:      	cmp	x0, #0x39
    2cb8:      	cset	w0, eq
    2cbc:      	ubfx	x0, x0, #0, #8
    2cc0:      	ret
    2cc4:      	cmp	x0, #0x20
    2cc8:      	b.ne	0x2cd4 <_stogir.integer-unary.operation?+0x34>
    2ccc:      	mov	x0, #0x1                ; =1
    2cd0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cd4:      	cmp	x0, #0x2d
    2cd8:      	b.ne	0x2ce4 <_stogir.integer-unary.operation?+0x44>
    2cdc:      	mov	x0, #0x1                ; =1
    2ce0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2ce4:      	cmp	x0, #0x36
    2ce8:      	b.ne	0x2cf4 <_stogir.integer-unary.operation?+0x54>
    2cec:      	mov	x0, #0x1                ; =1
    2cf0:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2cf4:      	cmp	x0, #0x37
    2cf8:      	b.ne	0x2d04 <_stogir.integer-unary.operation?+0x64>
    2cfc:      	mov	x0, #0x1                ; =1
    2d00:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>
    2d04:      	cmp	x0, #0x38
    2d08:      	b.ne	0x2cb4 <_stogir.integer-unary.operation?+0x14>
    2d0c:      	mov	x0, #0x1                ; =1
    2d10:      	b	0x2cc0 <_stogir.integer-unary.operation?+0x20>

0000000000002d14 <_stogir.verify.classifications>:
    2d14:      	sub	sp, sp, #0xc0
    2d18:      	str	x29, [sp]
    2d1c:      	str	x30, [sp, #0x8]
    2d20:      	mov	x29, sp
    2d24:      	str	x19, [sp, #0x70]
    2d28:      	str	x20, [sp, #0x78]
    2d2c:      	str	x21, [sp, #0x80]
    2d30:      	str	x22, [sp, #0x88]
    2d34:      	str	x23, [sp, #0x90]
    2d38:      	str	x24, [sp, #0x98]
    2d3c:      	str	x25, [sp, #0xa0]
    2d40:      	str	x26, [sp, #0xa8]
    2d44:      	str	x27, [sp, #0xb0]
    2d48:      	str	x28, [sp, #0xb8]
    2d4c:      	ldr	w4, [x2]
    2d50:      	orr	x5, x4, xzr
    2d54:      	ubfx	x5, x5, #8, #8
    2d58:      	orr	x19, x5, xzr
    2d5c:      	cmp	x19, #0xf
    2d60:      	b.le	0x2d9c <_stogir.verify.classifications+0x88>
    2d64:      	cmp	x19, #0x80
    2d68:      	b.ge	0x2d90 <_stogir.verify.classifications+0x7c>
    2d6c:      	and	x5, x19, #0xf
    2d70:      	lsr	w5, w5, #0
    2d74:      	sxtw	x5, w5
    2d78:      	cmp	x5, #0x1
    2d7c:      	b.lt	0x335c <_stogir.verify.classifications+0x648>
    2d80:      	cmp	x5, #0xd
    2d84:      	cset	w5, le
    2d88:      	ubfx	x5, x5, #0, #8
    2d8c:      	b	0x3360 <_stogir.verify.classifications+0x64c>
    2d90:      	movz	x5, #0x0, lsl #48
    2d94:      	mov	x20, x5
    2d98:      	b	0x2da0 <_stogir.verify.classifications+0x8c>
    2d9c:      	movz	x20, #0x0, lsl #48
    2da0:      	uxtb	w21, w4
    2da4:      	orr	x4, x21, xzr
    2da8:      	lsr	w22, w4, #0
    2dac:      	mov	x23, x0
    2db0:      	mov	w0, w22
    2db4:      	mov	w24, w1
    2db8:      	mov	x25, x2
    2dbc:      	mov	w26, w3
    2dc0:      	bl	0x2dc0 <_stogir.verify.classifications+0xac>
		0000000000002dc0:  ARM64_RELOC_BRANCH26	_stogir.floating.operation?
    2dc4:      	cmp	x0, #0x0
    2dc8:      	b.eq	0x2de8 <_stogir.verify.classifications+0xd4>
    2dcc:      	cmp	x20, #0x0
    2dd0:      	cset	w0, ne
    2dd4:      	uxtb	w16, w0
    2dd8:      	cmp	w16, wzr
    2ddc:      	cset	x0, eq
    2de0:      	mov	x27, x0
    2de4:      	b	0x2dec <_stogir.verify.classifications+0xd8>
    2de8:      	movz	x27, #0x0, lsl #48
    2dec:      	cmp	x27, #0x0
    2df0:      	cset	w28, ne
    2df4:      	uxtb	w16, w28
    2df8:      	cmp	w16, wzr
    2dfc:      	b.eq	0x2e30 <_stogir.verify.classifications+0x11c>
    2e00:      	ldr	w0, [x25, #0x4]
    2e04:      	lsr	w0, w0, #0
    2e08:      	mov	w1, w0
    2e0c:      	mov	x0, x23
    2e10:      	bl	0x2e10 <_stogir.verify.classifications+0xfc>
		0000000000002e10:  ARM64_RELOC_BRANCH26	_stogir.graph.borrow-node
    2e14:      	cmp	x0, #0x0
    2e18:      	b.ne	0x2e24 <_stogir.verify.classifications+0x110>
    2e1c:      	movn	x0, #0x0, lsl #48
    2e20:      	b	0x2e2c <_stogir.verify.classifications+0x118>
    2e24:      	ldr	w0, [x0]
    2e28:      	ubfx	x0, x0, #8, #8
    2e2c:      	b	0x2e34 <_stogir.verify.classifications+0x120>
    2e30:      	movn	x0, #0x0, lsl #48
    2e34:      	lsr	w0, w0, #0
    2e38:      	sxtw	x0, w0
    2e3c:      	cmp	x0, #0xf
    2e40:      	cset	w1, gt
    2e44:      	cmp	x0, #0x80
    2e48:      	cset	w2, lt
    2e4c:      	and	x3, x0, #0xf
    2e50:      	lsr	w3, w3, #0
    2e54:      	sxtw	x3, w3
    2e58:      	cmp	x3, #0x1
    2e5c:      	cset	w4, ge
    2e60:      	cmp	x3, #0xd
    2e64:      	cset	w3, le
    2e68:      	cmp	x27, #0x0
    2e6c:      	b.eq	0x2ec4 <_stogir.verify.classifications+0x1b0>
    2e70:      	uxtb	w16, w1
    2e74:      	cmp	w16, wzr
    2e78:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e7c:      	uxtb	w16, w2
    2e80:      	cmp	w16, wzr
    2e84:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e88:      	uxtb	w16, w4
    2e8c:      	cmp	w16, wzr
    2e90:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2e94:      	uxtb	w16, w3
    2e98:      	cmp	w16, wzr
    2e9c:      	b.eq	0x3364 <_stogir.verify.classifications+0x650>
    2ea0:      	movz	x0, #0x0, lsl #48
    2ea4:      	b	0x2eac <_stogir.verify.classifications+0x198>
    2ea8:      	mov	x0, #0x1                ; =1
    2eac:      	mov	x19, x0
    2eb0:      	b	0x2ec8 <_stogir.verify.classifications+0x1b4>
    2eb4:      	movz	x3, #0x0, lsl #48
    2eb8:      	b	0x2f04 <_stogir.verify.classifications+0x1f0>
    2ebc:      	movz	x0, #0x0, lsl #48
    2ec0:      	b	0x2f0c <_stogir.verify.classifications+0x1f8>
    2ec4:      	movz	x19, #0x0, lsl #48
    2ec8:      	sxtw	x26, w26
    2ecc:      	ubfx	x21, x3, #0, #8
    2ed0:      	add	x27, x23, #0x78
    2ed4:      	add	x0, x23, #0x28
    2ed8:      	add	x3, x23, #0x50
    2edc:      	sxtw	x24, w24
    2ee0:      	add	x5, x23, #0x78
    2ee4:      	cmp	x24, #0x0
    2ee8:      	cset	w6, le
    2eec:      	lsl	x7, x24, #2
    2ef0:      	mov	x8, #0x1                ; =1
    2ef4:      	b	0x2ffc <_stogir.verify.classifications+0x2e8>
    2ef8:      	movz	x3, #0x0, lsl #48
    2efc:      	b	0x2f24 <_stogir.verify.classifications+0x210>
    2f00:      	movz	x3, #0x0, lsl #48
    2f04:      	b	0x2f34 <_stogir.verify.classifications+0x220>
    2f08:      	movz	x0, #0x0, lsl #48
    2f0c:      	ldr	x5, [sp, #0x58]
    2f10:      	ldr	x6, [sp, #0x50]
    2f14:      	ldr	x8, [sp, #0x48]
    2f18:      	ldr	x1, [sp, #0x60]
    2f1c:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    2f20:      	movz	x3, #0x0, lsl #48
    2f24:      	ldr	x6, [sp, #0x50]
    2f28:      	ldr	x8, [sp, #0x48]
    2f2c:      	b	0x2f34 <_stogir.verify.classifications+0x220>
    2f30:      	movz	x3, #0x0, lsl #48
    2f34:      	cmp	x3, #0x0
    2f38:      	b.eq	0x2f68 <_stogir.verify.classifications+0x254>
    2f3c:      	uxtb	w16, w2
    2f40:      	cmp	w16, wzr
    2f44:      	b.eq	0x2f58 <_stogir.verify.classifications+0x244>
    2f48:      	lsl	x0, x0, #4
    2f4c:      	ldr	x2, [x23]
    2f50:      	add	x0, x0, x2
    2f54:      	b	0x2f64 <_stogir.verify.classifications+0x250>
    2f58:      	lsl	x0, x4, #4
    2f5c:      	ldr	x2, [x23, #0x28]
    2f60:      	add	x0, x0, x2
    2f64:      	b	0x2f6c <_stogir.verify.classifications+0x258>
    2f68:      	movz	x0, #0x0, lsl #48
    2f6c:      	cmp	x0, #0x0
    2f70:      	b.eq	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f74:      	ldr	w0, [x0]
    2f78:      	ubfx	x0, x0, #8, #8
    2f7c:      	cmp	x0, #0xf
    2f80:      	b.le	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f84:      	cmp	x0, #0x80
    2f88:      	b.ge	0x2fb0 <_stogir.verify.classifications+0x29c>
    2f8c:      	and	x0, x0, #0xf
    2f90:      	lsr	w0, w0, #0
    2f94:      	sxtw	x0, w0
    2f98:      	cmp	x0, #0x1
    2f9c:      	b.lt	0x2fb0 <_stogir.verify.classifications+0x29c>
    2fa0:      	cmp	x0, #0xd
    2fa4:      	b.gt	0x2fb0 <_stogir.verify.classifications+0x29c>
    2fa8:      	mov	x0, #0x1                ; =1
    2fac:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    2fb0:      	ldr	x0, [sp, #0x40]
    2fb4:      	add	x2, x27, #0x1
    2fb8:      	lsr	w2, w2, #0
    2fbc:      	sxtw	x2, w2
    2fc0:      	mov	w4, w26
    2fc4:      	ldr	x26, [sp, #0x30]
    2fc8:      	mov	x27, x5
    2fcc:      	mov	x3, x8
    2fd0:      	mov	x7, x1
    2fd4:      	mov	w1, w21
    2fd8:      	ldr	x21, [sp, #0x20]
    2fdc:      	mov	x5, x20
    2fe0:      	mov	x20, x0
    2fe4:      	mov	x0, x6
    2fe8:      	mov	w6, w19
    2fec:      	ldr	x19, [sp, #0x38]
    2ff0:      	mov	x8, x2
    2ff4:      	mov	w2, w22
    2ff8:      	ldr	w22, [sp, #0x28]
    2ffc:      	cmp	x20, #0x0
    3000:      	b.ne	0x33c8 <_stogir.verify.classifications+0x6b4>
    3004:      	cmp	x8, x26
    3008:      	b.gt	0x33d4 <_stogir.verify.classifications+0x6c0>
    300c:      	lsr	w9, w8, #0
    3010:      	str	x0, [sp, #0x50]
    3014:      	mov	w0, w22
    3018:      	str	x3, [sp, #0x48]
    301c:      	str	x7, [sp, #0x60]
    3020:      	str	w9, [sp, #0x68]
    3024:      	str	x21, [sp, #0x20]
    3028:      	mov	w21, w1
    302c:      	mov	w1, w9
    3030:      	str	w22, [sp, #0x28]
    3034:      	mov	w22, w2
    3038:      	str	x26, [sp, #0x30]
    303c:      	mov	w26, w4
    3040:      	str	x19, [sp, #0x38]
    3044:      	mov	w19, w6
    3048:      	str	x20, [sp, #0x40]
    304c:      	mov	x20, x5
    3050:      	str	x27, [sp, #0x58]
    3054:      	mov	x27, x8
    3058:      	bl	0x3058 <_stogir.verify.classifications+0x344>
		0000000000003058:  ARM64_RELOC_BRANCH26	_stogir.opcode.operand-code
    305c:      	lsr	w0, w0, #0
    3060:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003060:  ARM64_RELOC_PAGE21	l_stogir.340
    3064:      	ldr	x16, [x16]
		0000000000003064:  ARM64_RELOC_PAGEOFF12	l_stogir.340
    3068:      	ldr	w1, [x16]
    306c:      	cmp	x0, x1
    3070:      	b.eq	0x30a0 <_stogir.verify.classifications+0x38c>
    3074:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003074:  ARM64_RELOC_PAGE21	l_stogir.341
    3078:      	ldr	x16, [x16]
		0000000000003078:  ARM64_RELOC_PAGEOFF12	l_stogir.341
    307c:      	ldr	w1, [x16]
    3080:      	cmp	x0, x1
    3084:      	b.eq	0x30a0 <_stogir.verify.classifications+0x38c>
    3088:      	ldr	x5, [sp, #0x58]
    308c:      	ldr	x6, [sp, #0x50]
    3090:      	ldr	x8, [sp, #0x48]
    3094:      	ldr	x1, [sp, #0x60]
    3098:      	ldr	x0, [sp, #0x40]
    309c:      	b	0x2fb4 <_stogir.verify.classifications+0x2a0>
    30a0:      	cmp	x27, #0x1
    30a4:      	b.ne	0x30e0 <_stogir.verify.classifications+0x3cc>
    30a8:      	uxtb	w16, w28
    30ac:      	cmp	w16, wzr
    30b0:      	b.eq	0x30e0 <_stogir.verify.classifications+0x3cc>
    30b4:      	uxtb	w16, w21
    30b8:      	cmp	w16, wzr
    30bc:      	b.eq	0x2f08 <_stogir.verify.classifications+0x1f4>
    30c0:      	uxtb	w16, w22
    30c4:      	cmp	w16, wzr
    30c8:      	b.eq	0x2ebc <_stogir.verify.classifications+0x1a8>
    30cc:      	uxtb	w16, w26
    30d0:      	cmp	w16, wzr
    30d4:      	b.eq	0x3294 <_stogir.verify.classifications+0x580>
    30d8:      	ldr	x0, [sp, #0x20]
    30dc:      	b	0x3298 <_stogir.verify.classifications+0x584>
    30e0:      	cmp	x27, #0x1
    30e4:      	b.ne	0x315c <_stogir.verify.classifications+0x448>
    30e8:      	ldr	w0, [x25, #0x4]
    30ec:      	sxtw	x0, w0
    30f0:      	ldr	x1, [sp, #0x60]
    30f4:      	lsr	w0, w0, #0
    30f8:      	sxtw	x0, w0
    30fc:      	cmp	x0, #0x0
    3100:      	cset	w2, gt
    3104:      	movz	x16, #0x0, lsl #48
    3108:      	sub	x3, x16, x0
    310c:      	sub	x4, x3, #0x1
    3110:      	uxtb	w16, w2
    3114:      	cmp	w16, wzr
    3118:      	b.eq	0x33e0 <_stogir.verify.classifications+0x6cc>
    311c:      	ldr	x3, [x23, #0x8]
    3120:      	cmp	x0, x3
    3124:      	b.ge	0x33e8 <_stogir.verify.classifications+0x6d4>
    3128:      	ldr	x5, [sp, #0x58]
    312c:      	ldr	x3, [x5, #0x8]
    3130:      	cmp	x0, x3
    3134:      	b.ge	0x2ef8 <_stogir.verify.classifications+0x1e4>
    3138:      	lsl	x3, x0, #2
    313c:      	ldr	x6, [x23, #0x78]
    3140:      	add	x3, x3, x6
    3144:      	ldr	w3, [x3]
    3148:      	sxtw	x3, w3
    314c:      	cmp	x3, #0x0
    3150:      	cset	w3, ge
    3154:      	ubfx	x3, x3, #0, #8
    3158:      	b	0x2efc <_stogir.verify.classifications+0x1e8>
    315c:      	cmp	x27, #0x2
    3160:      	b.ne	0x31c0 <_stogir.verify.classifications+0x4ac>
    3164:      	ldr	w0, [x25, #0x8]
    3168:      	sxtw	x0, w0
    316c:      	ldr	x1, [sp, #0x60]
    3170:      	b	0x30f4 <_stogir.verify.classifications+0x3e0>
    3174:      	cmp	x0, #0x0
    3178:      	b.ge	0x33f0 <_stogir.verify.classifications+0x6dc>
    317c:      	ldr	x6, [sp, #0x50]
    3180:      	ldr	x7, [x6, #0x8]
    3184:      	ldr	x8, [sp, #0x48]
    3188:      	ldr	x9, [x8, #0x8]
    318c:      	cmp	x7, x9
    3190:      	b.ne	0x2f00 <_stogir.verify.classifications+0x1ec>
    3194:      	cmp	x3, x7
    3198:      	b.gt	0x2eb4 <_stogir.verify.classifications+0x1a0>
    319c:      	lsl	x3, x4, #2
    31a0:      	ldr	x7, [x23, #0x50]
    31a4:      	add	x3, x3, x7
    31a8:      	ldr	w3, [x3]
    31ac:      	sxtw	x3, w3
    31b0:      	cmp	x3, #0x0
    31b4:      	cset	w3, gt
    31b8:      	ubfx	x3, x3, #0, #8
    31bc:      	b	0x2eb8 <_stogir.verify.classifications+0x1a4>
    31c0:      	cmp	x27, #0x3
    31c4:      	b.ne	0x3244 <_stogir.verify.classifications+0x530>
    31c8:      	ldr	w0, [x25, #0xc]
    31cc:      	sxtw	x0, w0
    31d0:      	ldr	x1, [sp, #0x60]
    31d4:      	b	0x3170 <_stogir.verify.classifications+0x45c>
    31d8:      	ldr	x0, [sp, #0x40]
    31dc:      	uxtb	w0, w0
    31e0:      	ldr	x1, [sp, #0x38]
    31e4:      	uxtb	w1, w1
    31e8:      	add	x16, sp, #0x10
    31ec:      	movz	w17, #0x0, lsl #16
    31f0:      	strh	w17, [x16]
    31f4:      	add	x16, sp, #0x10
    31f8:      	strb	w0, [x16]
    31fc:      	add	x16, sp, #0x10
    3200:      	strb	w1, [x16, #0x1]
    3204:      	add	x16, sp, #0x10
    3208:      	ldrh	w0, [x16]
    320c:      	ldr	x19, [sp, #0x70]
    3210:      	ldr	x20, [sp, #0x78]
    3214:      	ldr	x21, [sp, #0x80]
    3218:      	ldr	x22, [sp, #0x88]
    321c:      	ldr	x23, [sp, #0x90]
    3220:      	ldr	x24, [sp, #0x98]
    3224:      	ldr	x25, [sp, #0xa0]
    3228:      	ldr	x26, [sp, #0xa8]
    322c:      	ldr	x27, [sp, #0xb0]
    3230:      	ldr	x28, [sp, #0xb8]
    3234:      	ldr	x29, [sp]
    3238:      	ldr	x30, [sp, #0x8]
    323c:      	add	sp, sp, #0xc0
    3240:      	ret
    3244:      	uxtb	w16, w19
    3248:      	cmp	w16, wzr
    324c:      	b.eq	0x32ac <_stogir.verify.classifications+0x598>
    3250:      	ldr	x1, [sp, #0x60]
    3254:      	movz	x0, #0x0, lsl #48
    3258:      	movz	x2, #0x0, lsl #48
    325c:      	lsr	w0, w0, #0
    3260:      	lsr	x16, x0, #0
    3264:      	cmp	x16, #0x1
    3268:      	b.eq	0x3284 <_stogir.verify.classifications+0x570>
    326c:      	b.lo	0x3274 <_stogir.verify.classifications+0x560>
    3270:      	b	0x3288 <_stogir.verify.classifications+0x574>
    3274:      	cmp	x16, #0x0
    3278:      	b.eq	0x3280 <_stogir.verify.classifications+0x56c>
    327c:      	b	0x3288 <_stogir.verify.classifications+0x574>
    3280:      	b	0x328c <_stogir.verify.classifications+0x578>
    3284:      	b	0x329c <_stogir.verify.classifications+0x588>
    3288:      	b	0x33c0 <_stogir.verify.classifications+0x6ac>
    328c:      	movz	x0, #0x0, lsl #48
    3290:      	b	0x32a8 <_stogir.verify.classifications+0x594>
    3294:      	movz	x0, #0x0, lsl #48
    3298:      	b	0x2ec0 <_stogir.verify.classifications+0x1ac>
    329c:      	lsr	w2, w2, #0
    32a0:      	sxtw	x2, w2
    32a4:      	mov	x0, x2
    32a8:      	b	0x31d4 <_stogir.verify.classifications+0x4c0>
    32ac:      	ldr	x0, [x23, #0x8]
    32b0:      	cmp	x24, x0
    32b4:      	b.ge	0x33fc <_stogir.verify.classifications+0x6e8>
    32b8:      	ldr	x0, [x20, #0x8]
    32bc:      	cmp	x24, x0
    32c0:      	b.ge	0x3404 <_stogir.verify.classifications+0x6f0>
    32c4:      	ldr	x0, [x23, #0x78]
    32c8:      	ldr	x1, [sp, #0x60]
    32cc:      	add	x0, x1, x0
    32d0:      	ldr	w0, [x0]
    32d4:      	sxtw	x0, w0
    32d8:      	cmp	x0, #0x0
    32dc:      	b.lt	0x3254 <_stogir.verify.classifications+0x540>
    32e0:      	ldr	w0, [sp, #0x68]
    32e4:      	sxtw	x0, w0
    32e8:      	cmp	x0, #0x1
    32ec:      	b.lt	0x33a4 <_stogir.verify.classifications+0x690>
    32f0:      	ldr	x2, [x23, #0x78]
    32f4:      	add	x2, x1, x2
    32f8:      	ldr	w2, [x2]
    32fc:      	sxtw	x2, w2
    3300:      	cmp	x0, x2
    3304:      	b.gt	0x33a4 <_stogir.verify.classifications+0x690>
    3308:      	ldr	x2, [x23]
    330c:      	asr	x16, x0, #63
    3310:      	lsr	x16, x16, #62
    3314:      	add	x3, x0, x16
    3318:      	asr	x3, x3, #2
    331c:      	asr	x16, x0, #63
    3320:      	lsr	x16, x16, #62
    3324:      	add	x0, x0, x16
    3328:      	and	x0, x0, #0x3
    332c:      	sub	x0, x0, x16
    3330:      	add	x3, x3, x24
    3334:      	lsl	x0, x0, #2
    3338:      	lsl	x3, x3, #4
    333c:      	add	x2, x3, x2
    3340:      	add	x0, x0, x2
    3344:      	ldr	w0, [x0]
    3348:      	sxtw	x0, w0
    334c:      	and	x0, x0, #0xffffffff
    3350:      	mov	x2, x0
    3354:      	mov	x0, #0x1                ; =1
    3358:      	b	0x33ac <_stogir.verify.classifications+0x698>
    335c:      	movz	x5, #0x0, lsl #48
    3360:      	b	0x2d94 <_stogir.verify.classifications+0x80>
    3364:      	cmp	x21, #0x18
    3368:      	b.ne	0x3374 <_stogir.verify.classifications+0x660>
    336c:      	mov	x0, #0x1                ; =1
    3370:      	b	0x2eac <_stogir.verify.classifications+0x198>
    3374:      	cmp	x21, #0x19
    3378:      	b.ne	0x3384 <_stogir.verify.classifications+0x670>
    337c:      	mov	x0, #0x1                ; =1
    3380:      	b	0x2eac <_stogir.verify.classifications+0x198>
    3384:      	cmp	x19, #0xc
    3388:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x194>
    338c:      	cmp	x19, #0xd
    3390:      	b.eq	0x2ea8 <_stogir.verify.classifications+0x194>
    3394:      	cmp	x0, #0xc
    3398:      	b.ne	0x33b0 <_stogir.verify.classifications+0x69c>
    339c:      	mov	x0, #0x1                ; =1
    33a0:      	b	0x33bc <_stogir.verify.classifications+0x6a8>
    33a4:      	movz	x0, #0x0, lsl #48
    33a8:      	movz	x2, #0x0, lsl #48
    33ac:      	b	0x325c <_stogir.verify.classifications+0x548>
    33b0:      	cmp	x0, #0xd
    33b4:      	cset	w0, eq
    33b8:      	ubfx	x0, x0, #0, #8
    33bc:      	b	0x2eac <_stogir.verify.classifications+0x198>
    33c0:      	brk	#0
    33c4:      	b	0x33c0 <_stogir.verify.classifications+0x6ac>
    33c8:      	str	x19, [sp, #0x38]
    33cc:      	str	x20, [sp, #0x40]
    33d0:      	b	0x31d8 <_stogir.verify.classifications+0x4c4>
    33d4:      	str	x19, [sp, #0x38]
    33d8:      	str	x20, [sp, #0x40]
    33dc:      	b	0x31d8 <_stogir.verify.classifications+0x4c4>
    33e0:      	ldr	x5, [sp, #0x58]
    33e4:      	b	0x3174 <_stogir.verify.classifications+0x460>
    33e8:      	ldr	x5, [sp, #0x58]
    33ec:      	b	0x2f20 <_stogir.verify.classifications+0x20c>
    33f0:      	ldr	x6, [sp, #0x50]
    33f4:      	ldr	x8, [sp, #0x48]
    33f8:      	b	0x2f30 <_stogir.verify.classifications+0x21c>
    33fc:      	ldr	x1, [sp, #0x60]
    3400:      	b	0x3254 <_stogir.verify.classifications+0x540>
    3404:      	ldr	x1, [sp, #0x60]
    3408:      	b	0x3254 <_stogir.verify.classifications+0x540>

000000000000340c <_stogir.vector-lanes.operation?>:
    340c:      	sxtw	x0, w0
    3410:      	cmp	x0, #0x3d
    3414:      	b.lt	0x3428 <_stogir.vector-lanes.operation?+0x1c>
    3418:      	cmp	x0, #0x3f
    341c:      	cset	w0, le
    3420:      	ubfx	x0, x0, #0, #8
    3424:      	b	0x342c <_stogir.vector-lanes.operation?+0x20>
    3428:      	movz	x0, #0x0, lsl #48
    342c:      	ret

0000000000003430 <_stogir.vector.validate>:
    3430:      	sub	sp, sp, #0x210
    3434:      	str	x29, [sp]
    3438:      	str	x30, [sp, #0x8]
    343c:      	mov	x29, sp
    3440:      	str	x19, [sp, #0x1c0]
    3444:      	str	x20, [sp, #0x1c8]
    3448:      	str	x21, [sp, #0x1d0]
    344c:      	str	x22, [sp, #0x1d8]
    3450:      	str	x23, [sp, #0x1e0]
    3454:      	str	x24, [sp, #0x1e8]
    3458:      	str	x25, [sp, #0x1f0]
    345c:      	str	x26, [sp, #0x1f8]
    3460:      	str	x27, [sp, #0x200]
    3464:      	str	x28, [sp, #0x208]
    3468:      	lsr	w19, w1, #0
    346c:      	mov	x20, x8
    3470:      	add	x8, sp, #0x10
    3474:      	mov	x21, x0
    3478:      	mov	w22, w1
    347c:      	mov	w1, w19
    3480:      	mov	w23, w2
    3484:      	bl	0x3484 <_stogir.vector.validate+0x54>
		0000000000003484:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3488:      	add	x16, sp, #0x10
    348c:      	ldr	w0, [x16]
    3490:      	lsr	x16, x0, #0
    3494:      	cmp	x16, #0x1
    3498:      	b.eq	0x34b4 <_stogir.vector.validate+0x84>
    349c:      	b.lo	0x34a4 <_stogir.vector.validate+0x74>
    34a0:      	b	0x34b8 <_stogir.vector.validate+0x88>
    34a4:      	cmp	x16, #0x0
    34a8:      	b.eq	0x34b0 <_stogir.vector.validate+0x80>
    34ac:      	b	0x34b8 <_stogir.vector.validate+0x88>
    34b0:      	b	0x34bc <_stogir.vector.validate+0x8c>
    34b4:      	b	0x3554 <_stogir.vector.validate+0x124>
    34b8:      	b	0x377c <_stogir.vector.validate+0x34c>
    34bc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		00000000000034bc:  ARM64_RELOC_PAGE21	l_stogir.342
    34c0:      	ldr	x16, [x16]
		00000000000034c0:  ARM64_RELOC_PAGEOFF12	l_stogir.342
    34c4:      	orr	x0, x16, xzr
    34c8:      	str	x20, [sp, #0x1a8]
    34cc:      	mov	x1, x0
    34d0:      	mov	x0, #0x1                ; =1
    34d4:      	mov	x2, #0x1a               ; =26
    34d8:      	b	0x350c <_stogir.vector.validate+0xdc>
    34dc:      	lsr	w23, w23, #0
    34e0:      	add	x8, sp, #0x70
    34e4:      	mov	x0, x21
    34e8:      	ldr	w1, [sp, #0x1a0]
    34ec:      	mov	w2, w23
    34f0:      	bl	0x34f0 <_stogir.vector.validate+0xc0>
		00000000000034f0:  ARM64_RELOC_BRANCH26	_stogir.conversion.validate
    34f4:      	add	x16, sp, #0x70
    34f8:      	ldr	x0, [x16]
    34fc:      	add	x16, sp, #0x70
    3500:      	ldr	x1, [x16, #0x8]
    3504:      	add	x16, sp, #0x70
    3508:      	ldr	x2, [x16, #0x10]
    350c:      	ldr	x3, [sp, #0x1a8]
    3510:      	str	x0, [x3]
    3514:      	str	x1, [x3, #0x8]
    3518:      	str	x2, [x3, #0x10]
    351c:      	ldr	x19, [sp, #0x1c0]
    3520:      	ldr	x20, [sp, #0x1c8]
    3524:      	ldr	x21, [sp, #0x1d0]
    3528:      	ldr	x22, [sp, #0x1d8]
    352c:      	ldr	x23, [sp, #0x1e0]
    3530:      	ldr	x24, [sp, #0x1e8]
    3534:      	ldr	x25, [sp, #0x1f0]
    3538:      	ldr	x26, [sp, #0x1f8]
    353c:      	ldr	x27, [sp, #0x200]
    3540:      	ldr	x28, [sp, #0x208]
    3544:      	ldr	x29, [sp]
    3548:      	ldr	x30, [sp, #0x8]
    354c:      	add	sp, sp, #0x210
    3550:      	ret
    3554:      	sxtw	x22, w22
    3558:      	add	x16, sp, #0x10
    355c:      	orr	x0, x16, xzr
    3560:      	cmp	x22, #0x0
    3564:      	cset	w24, le
    3568:      	add	x0, x0, #0x8
    356c:      	add	x16, sp, #0x10
    3570:      	ldr	x1, [x16, #0x8]
    3574:      	add	x16, sp, #0x40
    3578:      	str	x1, [x16]
    357c:      	ldr	x0, [x0, #0x8]
    3580:      	add	x16, sp, #0x40
    3584:      	str	x0, [x16, #0x8]
    3588:      	uxtb	w16, w24
    358c:      	cmp	w16, wzr
    3590:      	b.eq	0x35b4 <_stogir.vector.validate+0x184>
    3594:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003594:  ARM64_RELOC_PAGE21	l_stogir.343
    3598:      	ldr	x16, [x16]
		0000000000003598:  ARM64_RELOC_PAGEOFF12	l_stogir.343
    359c:      	orr	x0, x16, xzr
    35a0:      	str	x20, [sp, #0x1a8]
    35a4:      	mov	x1, x0
    35a8:      	mov	x0, #0x1                ; =1
    35ac:      	mov	x2, #0x3b               ; =59
    35b0:      	b	0x350c <_stogir.vector.validate+0xdc>
    35b4:      	lsl	x25, x22, #2
    35b8:      	add	x16, sp, #0x40
    35bc:      	ldr	w26, [x16]
    35c0:      	uxtb	w0, w26
    35c4:      	ldr	x1, [x21, #0x78]
    35c8:      	orr	x27, x0, xzr
    35cc:      	cmp	x27, #0x44
    35d0:      	cset	w0, eq
    35d4:      	add	x1, x25, x1
    35d8:      	ldr	w28, [x1]
    35dc:      	cmp	x27, #0x24
    35e0:      	b.ne	0x3624 <_stogir.vector.validate+0x1f4>
    35e4:      	str	x20, [sp, #0x1a8]
    35e8:      	str	w19, [sp, #0x1a0]
    35ec:      	uxtb	w16, w0
    35f0:      	cmp	w16, wzr
    35f4:      	b.eq	0x34dc <_stogir.vector.validate+0xac>
    35f8:      	add	x8, sp, #0x50
    35fc:      	mov	x0, x21
    3600:      	ldr	w1, [sp, #0x1a0]
    3604:      	bl	0x3604 <_stogir.vector.validate+0x1d4>
		0000000000003604:  ARM64_RELOC_BRANCH26	_stogir.copy.validate
    3608:      	add	x16, sp, #0x50
    360c:      	ldr	x0, [x16]
    3610:      	add	x16, sp, #0x50
    3614:      	ldr	x1, [x16, #0x8]
    3618:      	add	x16, sp, #0x50
    361c:      	ldr	x2, [x16, #0x10]
    3620:      	b	0x350c <_stogir.vector.validate+0xdc>
    3624:      	uxtb	w16, w0
    3628:      	cmp	w16, wzr
    362c:      	b.ne	0x3ee4 <_stogir.vector.validate+0xab4>
    3630:      	cmp	x27, #0x3c
    3634:      	b.ne	0x36e8 <_stogir.vector.validate+0x2b8>
    3638:      	add	x8, sp, #0x90
    363c:      	mov	x0, x21
    3640:      	mov	w1, w19
    3644:      	bl	0x3644 <_stogir.vector.validate+0x214>
		0000000000003644:  ARM64_RELOC_BRANCH26	_stogir.conditional.validate
    3648:      	add	x16, sp, #0x90
    364c:      	ldr	x0, [x16]
    3650:      	add	x16, sp, #0x90
    3654:      	ldr	x1, [x16, #0x8]
    3658:      	add	x16, sp, #0x90
    365c:      	ldr	x2, [x16, #0x10]
    3660:      	str	x20, [sp, #0x1a8]
    3664:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3668:      	cmp	x27, #0x41
    366c:      	cset	w0, eq
    3670:      	cmp	x27, #0x48
    3674:      	cset	w1, eq
    3678:      	cmp	x27, #0x55
    367c:      	cset	w2, ge
    3680:      	cmp	x27, #0x58
    3684:      	cset	w3, le
    3688:      	cmp	x27, #0x47
    368c:      	b.ne	0x3784 <_stogir.vector.validate+0x354>
    3690:      	str	x20, [sp, #0x1a8]
    3694:      	str	w19, [sp, #0x1a0]
    3698:      	mov	w19, w0
    369c:      	mov	w20, w1
    36a0:      	str	w2, [sp, #0x1b0]
    36a4:      	str	w3, [sp, #0x1b8]
    36a8:      	mov	x0, x21
    36ac:      	ldr	w1, [sp, #0x1a0]
    36b0:      	bl	0x36b0 <_stogir.vector.validate+0x280>
		00000000000036b0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    36b4:      	cmp	x0, #0x0
    36b8:      	b.eq	0x37a8 <_stogir.vector.validate+0x378>
    36bc:      	add	x8, sp, #0xf0
    36c0:      	mov	x0, x21
    36c4:      	ldr	w1, [sp, #0x1a0]
    36c8:      	bl	0x36c8 <_stogir.vector.validate+0x298>
		00000000000036c8:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.validate
    36cc:      	add	x16, sp, #0xf0
    36d0:      	ldr	x0, [x16]
    36d4:      	add	x16, sp, #0xf0
    36d8:      	ldr	x1, [x16, #0x8]
    36dc:      	add	x16, sp, #0xf0
    36e0:      	ldr	x2, [x16, #0x10]
    36e4:      	b	0x350c <_stogir.vector.validate+0xdc>
    36e8:      	cmp	x27, #0x3d
    36ec:      	b.lt	0x3730 <_stogir.vector.validate+0x300>
    36f0:      	cmp	x27, #0x3f
    36f4:      	b.gt	0x3730 <_stogir.vector.validate+0x300>
    36f8:      	lsr	w23, w23, #0
    36fc:      	add	x8, sp, #0xb0
    3700:      	mov	x0, x21
    3704:      	mov	w1, w19
    3708:      	mov	w2, w23
    370c:      	bl	0x370c <_stogir.vector.validate+0x2dc>
		000000000000370c:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.validate
    3710:      	add	x16, sp, #0xb0
    3714:      	ldr	x0, [x16]
    3718:      	add	x16, sp, #0xb0
    371c:      	ldr	x1, [x16, #0x8]
    3720:      	add	x16, sp, #0xb0
    3724:      	ldr	x2, [x16, #0x10]
    3728:      	str	x20, [sp, #0x1a8]
    372c:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3730:      	mov	x0, x21
    3734:      	mov	w1, w19
    3738:      	bl	0x3738 <_stogir.vector.validate+0x308>
		0000000000003738:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.node?
    373c:      	cmp	x0, #0x0
    3740:      	b.eq	0x3668 <_stogir.vector.validate+0x238>
    3744:      	lsr	w23, w23, #0
    3748:      	add	x8, sp, #0xd0
    374c:      	mov	x0, x21
    3750:      	mov	w1, w19
    3754:      	mov	w2, w23
    3758:      	bl	0x3758 <_stogir.vector.validate+0x328>
		0000000000003758:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.validate
    375c:      	add	x16, sp, #0xd0
    3760:      	ldr	x0, [x16]
    3764:      	add	x16, sp, #0xd0
    3768:      	ldr	x1, [x16, #0x8]
    376c:      	add	x16, sp, #0xd0
    3770:      	ldr	x2, [x16, #0x10]
    3774:      	str	x20, [sp, #0x1a8]
    3778:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    377c:      	brk	#0
    3780:      	b	0x377c <_stogir.vector.validate+0x34c>
    3784:      	cmp	x27, #0x4f
    3788:      	b.ne	0x3824 <_stogir.vector.validate+0x3f4>
    378c:      	str	x20, [sp, #0x1a8]
    3790:      	str	w19, [sp, #0x1a0]
    3794:      	mov	w19, w0
    3798:      	mov	w20, w1
    379c:      	str	w2, [sp, #0x1b0]
    37a0:      	str	w3, [sp, #0x1b8]
    37a4:      	b	0x36a8 <_stogir.vector.validate+0x278>
    37a8:      	uxtb	w16, w19
    37ac:      	cmp	w16, wzr
    37b0:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37b4:      	uxtb	w16, w20
    37b8:      	cmp	w16, wzr
    37bc:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37c0:      	ldr	w0, [sp, #0x1b0]
    37c4:      	uxtb	w16, w0
    37c8:      	cmp	w16, wzr
    37cc:      	b.eq	0x37e0 <_stogir.vector.validate+0x3b0>
    37d0:      	ldr	w0, [sp, #0x1b8]
    37d4:      	uxtb	w16, w0
    37d8:      	cmp	w16, wzr
    37dc:      	b.ne	0x37f0 <_stogir.vector.validate+0x3c0>
    37e0:      	movz	x0, #0x0, lsl #48
    37e4:      	movz	x1, #0x0, lsl #48
    37e8:      	movz	x2, #0x0, lsl #48
    37ec:      	b	0x3820 <_stogir.vector.validate+0x3f0>
    37f0:      	lsr	w23, w23, #0
    37f4:      	add	x8, sp, #0x110
    37f8:      	mov	x0, x21
    37fc:      	ldr	w1, [sp, #0x1a0]
    3800:      	mov	w2, w23
    3804:      	bl	0x3804 <_stogir.vector.validate+0x3d4>
		0000000000003804:  ARM64_RELOC_BRANCH26	_stogir.locals.validate
    3808:      	add	x16, sp, #0x110
    380c:      	ldr	x0, [x16]
    3810:      	add	x16, sp, #0x110
    3814:      	ldr	x1, [x16, #0x8]
    3818:      	add	x16, sp, #0x110
    381c:      	ldr	x2, [x16, #0x10]
    3820:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3824:      	cmp	x27, #0x50
    3828:      	b.eq	0x3ef0 <_stogir.vector.validate+0xac0>
    382c:      	cmp	x27, #0x78
    3830:      	b.ne	0x3850 <_stogir.vector.validate+0x420>
    3834:      	str	x20, [sp, #0x1a8]
    3838:      	str	w19, [sp, #0x1a0]
    383c:      	mov	w19, w0
    3840:      	mov	w20, w1
    3844:      	str	w2, [sp, #0x1b0]
    3848:      	str	w3, [sp, #0x1b8]
    384c:      	b	0x36a8 <_stogir.vector.validate+0x278>
    3850:      	uxtb	w16, w0
    3854:      	cmp	w16, wzr
    3858:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    385c:      	uxtb	w16, w1
    3860:      	cmp	w16, wzr
    3864:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    3868:      	uxtb	w16, w2
    386c:      	cmp	w16, wzr
    3870:      	b.eq	0x3880 <_stogir.vector.validate+0x450>
    3874:      	uxtb	w16, w3
    3878:      	cmp	w16, wzr
    387c:      	b.ne	0x3938 <_stogir.vector.validate+0x508>
    3880:      	str	w2, [sp, #0x1b0]
    3884:      	str	w3, [sp, #0x1b8]
    3888:      	str	w19, [sp, #0x1a0]
    388c:      	str	x20, [sp, #0x1a8]
    3890:      	mov	w20, w1
    3894:      	mov	w1, w19
    3898:      	mov	w19, w0
    389c:      	mov	x0, x21
    38a0:      	bl	0x38a0 <_stogir.vector.validate+0x470>
		00000000000038a0:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    38a4:      	cmp	x0, #0x0
    38a8:      	b.ne	0x36a8 <_stogir.vector.validate+0x278>
    38ac:      	sxtw	x28, w28
    38b0:      	ubfx	x0, x26, #8, #8
    38b4:      	orr	x1, x0, xzr
    38b8:      	lsr	w19, w1, #0
    38bc:      	cmp	x27, #0x5b
    38c0:      	b.eq	0x3970 <_stogir.vector.validate+0x540>
    38c4:      	cmp	x27, #0x5c
    38c8:      	b.eq	0x3970 <_stogir.vector.validate+0x540>
    38cc:      	orr	x20, x0, xzr
    38d0:      	cmp	x27, #0x5d
    38d4:      	b.eq	0x39e8 <_stogir.vector.validate+0x5b8>
    38d8:      	cmp	x27, #0x5e
    38dc:      	b.eq	0x39e8 <_stogir.vector.validate+0x5b8>
    38e0:      	cmp	x27, #0x43
    38e4:      	b.ne	0x3a64 <_stogir.vector.validate+0x634>
    38e8:      	mov	w0, w19
    38ec:      	bl	0x38ec <_stogir.vector.validate+0x4bc>
		00000000000038ec:  ARM64_RELOC_BRANCH26	_stogir.types.vector?
    38f0:      	cmp	x0, #0x0
    38f4:      	b.eq	0x3d98 <_stogir.vector.validate+0x968>
    38f8:      	lsr	w23, w23, #0
    38fc:      	mov	w0, w19
    3900:      	mov	w1, w23
    3904:      	bl	0x3904 <_stogir.vector.validate+0x4d4>
		0000000000003904:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3908:      	lsr	w0, w0, #0
    390c:      	sxtw	x0, w0
    3910:      	cmp	x0, #0x0
    3914:      	b.le	0x3d98 <_stogir.vector.validate+0x968>
    3918:      	cmp	x28, #0x3
    391c:      	b.lt	0x3d98 <_stogir.vector.validate+0x968>
    3920:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003920:  ARM64_RELOC_PAGE21	l_stogir.344
    3924:      	ldr	x16, [x16]
		0000000000003924:  ARM64_RELOC_PAGEOFF12	l_stogir.344
    3928:      	orr	x0, x16, xzr
    392c:      	mov	x26, x0
    3930:      	movz	x27, #0x0, lsl #48
    3934:      	b	0x3dac <_stogir.vector.validate+0x97c>
    3938:      	str	x20, [sp, #0x1a8]
    393c:      	str	w19, [sp, #0x1a0]
    3940:      	mov	w19, w0
    3944:      	mov	w20, w1
    3948:      	str	w2, [sp, #0x1b0]
    394c:      	str	w3, [sp, #0x1b8]
    3950:      	b	0x36a8 <_stogir.vector.validate+0x278>
    3954:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003954:  ARM64_RELOC_PAGE21	l_stogir.345
    3958:      	ldr	x16, [x16]
		0000000000003958:  ARM64_RELOC_PAGEOFF12	l_stogir.345
    395c:      	orr	x0, x16, xzr
    3960:      	mov	x1, x0
    3964:      	mov	x0, #0x1                ; =1
    3968:      	mov	x2, #0x19               ; =25
    396c:      	b	0x36e4 <_stogir.vector.validate+0x2b4>
    3970:      	cmp	x28, #0x2
    3974:      	b.ne	0x3954 <_stogir.vector.validate+0x524>
    3978:      	lsr	w23, w23, #0
    397c:      	add	x16, sp, #0x40
    3980:      	ldr	w0, [x16, #0x4]
    3984:      	add	x16, sp, #0x40
    3988:      	ldr	w1, [x16, #0x8]
    398c:      	lsr	w0, w0, #0
    3990:      	lsr	w1, w1, #0
    3994:      	add	x8, sp, #0x130
    3998:      	mov	w2, w23
    399c:      	mov	w3, w0
    39a0:      	mov	x0, x21
    39a4:      	mov	w4, w1
    39a8:      	mov	w1, w19
    39ac:      	bl	0x39ac <_stogir.vector.validate+0x57c>
		00000000000039ac:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    39b0:      	add	x16, sp, #0x130
    39b4:      	ldr	x0, [x16]
    39b8:      	add	x16, sp, #0x130
    39bc:      	ldr	x1, [x16, #0x8]
    39c0:      	add	x16, sp, #0x130
    39c4:      	ldr	x2, [x16, #0x10]
    39c8:      	b	0x396c <_stogir.vector.validate+0x53c>
    39cc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		00000000000039cc:  ARM64_RELOC_PAGE21	l_stogir.346
    39d0:      	ldr	x16, [x16]
		00000000000039d0:  ARM64_RELOC_PAGEOFF12	l_stogir.346
    39d4:      	orr	x0, x16, xzr
    39d8:      	mov	x1, x0
    39dc:      	mov	x0, #0x1                ; =1
    39e0:      	mov	x2, #0x1a               ; =26
    39e4:      	b	0x396c <_stogir.vector.validate+0x53c>
    39e8:      	cmp	x28, #0x3
    39ec:      	b.ne	0x39cc <_stogir.vector.validate+0x59c>
    39f0:      	cmp	x20, #0x0
    39f4:      	b.ne	0x39cc <_stogir.vector.validate+0x59c>
    39f8:      	lsr	w23, w23, #0
    39fc:      	add	x16, sp, #0x40
    3a00:      	ldr	w0, [x16, #0x4]
    3a04:      	add	x16, sp, #0x40
    3a08:      	ldr	w1, [x16, #0x8]
    3a0c:      	lsr	w0, w0, #0
    3a10:      	add	x16, sp, #0x40
    3a14:      	ldr	w2, [x16, #0xc]
    3a18:      	lsr	w1, w1, #0
    3a1c:      	lsr	w2, w2, #0
    3a20:      	add	x8, sp, #0x150
    3a24:      	mov	w3, w1
    3a28:      	mov	w1, w23
    3a2c:      	mov	w4, w2
    3a30:      	mov	w2, w0
    3a34:      	mov	x0, x21
    3a38:      	bl	0x3a38 <_stogir.vector.validate+0x608>
		0000000000003a38:  ARM64_RELOC_BRANCH26	_stogir.vector.store-inputs
    3a3c:      	add	x16, sp, #0x150
    3a40:      	ldr	x0, [x16]
    3a44:      	add	x16, sp, #0x150
    3a48:      	ldr	x1, [x16, #0x8]
    3a4c:      	add	x16, sp, #0x150
    3a50:      	ldr	x2, [x16, #0x10]
    3a54:      	b	0x39e4 <_stogir.vector.validate+0x5b4>
    3a58:      	mov	x2, x8
    3a5c:      	mov	x0, #0x1                ; =1
    3a60:      	b	0x39e4 <_stogir.vector.validate+0x5b4>
    3a64:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a64:  ARM64_RELOC_PAGE21	l_stogir.347
    3a68:      	ldr	x16, [x16]
		0000000000003a68:  ARM64_RELOC_PAGEOFF12	l_stogir.347
    3a6c:      	orr	x0, x16, xzr
    3a70:      	mov	x1, x0
    3a74:      	mov	x0, #0x1                ; =1
    3a78:      	mov	x2, #0x28               ; =40
    3a7c:      	b	0x3a60 <_stogir.vector.validate+0x630>
    3a80:      	mov	x0, x1
    3a84:      	mov	x1, x27
    3a88:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a88:  ARM64_RELOC_PAGE21	l_stogir.348
    3a8c:      	ldr	x16, [x16]
		0000000000003a8c:  ARM64_RELOC_PAGEOFF12	l_stogir.348
    3a90:      	orr	x2, x16, xzr
    3a94:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003a94:  ARM64_RELOC_PAGE21	l_stogir.349
    3a98:      	ldr	x16, [x16]
		0000000000003a98:  ARM64_RELOC_PAGEOFF12	l_stogir.349
    3a9c:      	orr	x3, x16, xzr
    3aa0:      	add	x4, x21, #0x78
    3aa4:      	add	x5, x21, #0x28
    3aa8:      	add	x6, x21, #0x50
    3aac:      	add	x7, x21, #0x78
    3ab0:      	mov	x8, x1
    3ab4:      	mov	x1, x0
    3ab8:      	mov	x0, #0x2                ; =2
    3abc:      	b	0x3b34 <_stogir.vector.validate+0x704>
    3ac0:      	lsr	w10, w10, #0
    3ac4:      	ubfx	x9, x10, #8, #8
    3ac8:      	cmp	x9, x20
    3acc:      	b.eq	0x3ad8 <_stogir.vector.validate+0x6a8>
    3ad0:      	mov	x1, x3
    3ad4:      	mov	x8, #0x1e               ; =30
    3ad8:      	b	0x3b28 <_stogir.vector.validate+0x6f8>
    3adc:      	movz	x9, #0x0, lsl #48
    3ae0:      	movz	x10, #0x0, lsl #48
    3ae4:      	b	0x3af0 <_stogir.vector.validate+0x6c0>
    3ae8:      	movz	x9, #0x0, lsl #48
    3aec:      	movz	x10, #0x0, lsl #48
    3af0:      	lsr	w9, w9, #0
    3af4:      	lsr	x16, x9, #0
    3af8:      	cmp	x16, #0x1
    3afc:      	b.eq	0x3b18 <_stogir.vector.validate+0x6e8>
    3b00:      	b.lo	0x3b08 <_stogir.vector.validate+0x6d8>
    3b04:      	b	0x3b1c <_stogir.vector.validate+0x6ec>
    3b08:      	cmp	x16, #0x0
    3b0c:      	b.eq	0x3b14 <_stogir.vector.validate+0x6e4>
    3b10:      	b	0x3b1c <_stogir.vector.validate+0x6ec>
    3b14:      	b	0x3b20 <_stogir.vector.validate+0x6f0>
    3b18:      	b	0x3b94 <_stogir.vector.validate+0x764>
    3b1c:      	b	0x3ecc <_stogir.vector.validate+0xa9c>
    3b20:      	mov	x1, x2
    3b24:      	mov	x8, #0x18               ; =24
    3b28:      	add	x0, x0, #0x1
    3b2c:      	lsr	w0, w0, #0
    3b30:      	sxtw	x0, w0
    3b34:      	cmp	x8, #0x0
    3b38:      	cset	w9, eq
    3b3c:      	uxtb	w16, w9
    3b40:      	cmp	w16, wzr
    3b44:      	b.eq	0x3ccc <_stogir.vector.validate+0x89c>
    3b48:      	cmp	x0, x28
    3b4c:      	b.gt	0x3ccc <_stogir.vector.validate+0x89c>
    3b50:      	uxtb	w16, w24
    3b54:      	cmp	w16, wzr
    3b58:      	b.ne	0x3ae8 <_stogir.vector.validate+0x6b8>
    3b5c:      	ldr	x9, [x21, #0x8]
    3b60:      	cmp	x22, x9
    3b64:      	b.ge	0x3c00 <_stogir.vector.validate+0x7d0>
    3b68:      	ldr	x9, [x7, #0x8]
    3b6c:      	cmp	x22, x9
    3b70:      	b.ge	0x3bf8 <_stogir.vector.validate+0x7c8>
    3b74:      	ldr	x9, [x21, #0x78]
    3b78:      	add	x9, x25, x9
    3b7c:      	ldr	w9, [x9]
    3b80:      	sxtw	x9, w9
    3b84:      	cmp	x9, #0x0
    3b88:      	cset	w9, ge
    3b8c:      	ubfx	x9, x9, #0, #8
    3b90:      	b	0x3bfc <_stogir.vector.validate+0x7cc>
    3b94:      	lsr	w10, w10, #0
    3b98:      	sxtw	x10, w10
    3b9c:      	cmp	x10, #0x0
    3ba0:      	cset	w9, gt
    3ba4:      	movz	x16, #0x0, lsl #48
    3ba8:      	sub	x11, x16, x10
    3bac:      	sub	x12, x11, #0x1
    3bb0:      	uxtb	w16, w9
    3bb4:      	cmp	w16, wzr
    3bb8:      	b.eq	0x3c88 <_stogir.vector.validate+0x858>
    3bbc:      	ldr	x11, [x21, #0x8]
    3bc0:      	cmp	x10, x11
    3bc4:      	b.ge	0x3d04 <_stogir.vector.validate+0x8d4>
    3bc8:      	ldr	x11, [x4, #0x8]
    3bcc:      	cmp	x10, x11
    3bd0:      	b.ge	0x3e18 <_stogir.vector.validate+0x9e8>
    3bd4:      	lsl	x11, x10, #2
    3bd8:      	ldr	x13, [x21, #0x78]
    3bdc:      	add	x11, x11, x13
    3be0:      	ldr	w11, [x11]
    3be4:      	sxtw	x11, w11
    3be8:      	cmp	x11, #0x0
    3bec:      	cset	w11, ge
    3bf0:      	ubfx	x11, x11, #0, #8
    3bf4:      	b	0x3e1c <_stogir.vector.validate+0x9ec>
    3bf8:      	movz	x9, #0x0, lsl #48
    3bfc:      	b	0x3c04 <_stogir.vector.validate+0x7d4>
    3c00:      	movz	x9, #0x0, lsl #48
    3c04:      	cmp	x9, #0x0
    3c08:      	b.eq	0x3ae8 <_stogir.vector.validate+0x6b8>
    3c0c:      	lsr	w9, w0, #0
    3c10:      	sxtw	x9, w9
    3c14:      	cmp	x9, #0x1
    3c18:      	b.lt	0x3adc <_stogir.vector.validate+0x6ac>
    3c1c:      	ldr	x10, [x21, #0x78]
    3c20:      	add	x10, x25, x10
    3c24:      	ldr	w10, [x10]
    3c28:      	sxtw	x10, w10
    3c2c:      	cmp	x9, x10
    3c30:      	b.gt	0x3adc <_stogir.vector.validate+0x6ac>
    3c34:      	ldr	x10, [x21]
    3c38:      	asr	x16, x9, #63
    3c3c:      	lsr	x16, x16, #62
    3c40:      	add	x11, x9, x16
    3c44:      	asr	x11, x11, #2
    3c48:      	asr	x16, x9, #63
    3c4c:      	lsr	x16, x16, #62
    3c50:      	add	x9, x9, x16
    3c54:      	and	x9, x9, #0x3
    3c58:      	sub	x9, x9, x16
    3c5c:      	add	x11, x11, x22
    3c60:      	lsl	x9, x9, #2
    3c64:      	lsl	x11, x11, #4
    3c68:      	add	x10, x11, x10
    3c6c:      	add	x9, x9, x10
    3c70:      	ldr	w9, [x9]
    3c74:      	sxtw	x9, w9
    3c78:      	and	x9, x9, #0xffffffff
    3c7c:      	mov	x10, x9
    3c80:      	mov	x9, #0x1                ; =1
    3c84:      	b	0x3ae4 <_stogir.vector.validate+0x6b4>
    3c88:      	cmp	x10, #0x0
    3c8c:      	b.ge	0x3d0c <_stogir.vector.validate+0x8dc>
    3c90:      	ldr	x13, [x5, #0x8]
    3c94:      	ldr	x14, [x6, #0x8]
    3c98:      	cmp	x13, x14
    3c9c:      	b.ne	0x3e10 <_stogir.vector.validate+0x9e0>
    3ca0:      	cmp	x11, x13
    3ca4:      	b.gt	0x3e48 <_stogir.vector.validate+0xa18>
    3ca8:      	lsl	x11, x12, #2
    3cac:      	ldr	x13, [x21, #0x50]
    3cb0:      	add	x11, x11, x13
    3cb4:      	ldr	w11, [x11]
    3cb8:      	sxtw	x11, w11
    3cbc:      	cmp	x11, #0x0
    3cc0:      	cset	w11, gt
    3cc4:      	ubfx	x11, x11, #0, #8
    3cc8:      	b	0x3e4c <_stogir.vector.validate+0xa1c>
    3ccc:      	uxtb	w16, w9
    3cd0:      	cmp	w16, wzr
    3cd4:      	b.eq	0x3a58 <_stogir.vector.validate+0x628>
    3cd8:      	lsr	w23, w23, #0
    3cdc:      	mov	w0, w19
    3ce0:      	mov	w1, w23
    3ce4:      	bl	0x3ce4 <_stogir.vector.validate+0x8b4>
		0000000000003ce4:  ARM64_RELOC_BRANCH26	_stogir.types.size
    3ce8:      	lsr	w0, w0, #0
    3cec:      	sxtw	x0, w0
    3cf0:      	and	x0, x0, #0xffffffff
    3cf4:      	mov	x1, x0
    3cf8:      	movz	x0, #0x0, lsl #48
    3cfc:      	movz	x2, #0x0, lsl #48
    3d00:      	b	0x3a60 <_stogir.vector.validate+0x630>
    3d04:      	movz	x11, #0x0, lsl #48
    3d08:      	b	0x3d10 <_stogir.vector.validate+0x8e0>
    3d0c:      	movz	x11, #0x0, lsl #48
    3d10:      	cmp	x11, #0x0
    3d14:      	b.eq	0x3d54 <_stogir.vector.validate+0x924>
    3d18:      	uxtb	w16, w9
    3d1c:      	cmp	w16, wzr
    3d20:      	b.eq	0x3d38 <_stogir.vector.validate+0x908>
    3d24:      	lsl	x9, x10, #4
    3d28:      	ldr	x10, [x21]
    3d2c:      	add	x9, x9, x10
    3d30:      	ldr	x9, [x9]
    3d34:      	b	0x3d48 <_stogir.vector.validate+0x918>
    3d38:      	lsl	x9, x12, #4
    3d3c:      	ldr	x10, [x21, #0x28]
    3d40:      	add	x9, x9, x10
    3d44:      	ldr	x9, [x9]
    3d48:      	mov	x10, x9
    3d4c:      	mov	x9, #0x1                ; =1
    3d50:      	b	0x3d5c <_stogir.vector.validate+0x92c>
    3d54:      	movz	x9, #0x0, lsl #48
    3d58:      	movz	x10, #0x0, lsl #48
    3d5c:      	lsr	w9, w9, #0
    3d60:      	lsr	x16, x9, #0
    3d64:      	cmp	x16, #0x1
    3d68:      	b.eq	0x3d84 <_stogir.vector.validate+0x954>
    3d6c:      	b.lo	0x3d74 <_stogir.vector.validate+0x944>
    3d70:      	b	0x3d88 <_stogir.vector.validate+0x958>
    3d74:      	cmp	x16, #0x0
    3d78:      	b.eq	0x3d80 <_stogir.vector.validate+0x950>
    3d7c:      	b	0x3d88 <_stogir.vector.validate+0x958>
    3d80:      	b	0x3d8c <_stogir.vector.validate+0x95c>
    3d84:      	b	0x3ac0 <_stogir.vector.validate+0x690>
    3d88:      	b	0x3ed4 <_stogir.vector.validate+0xaa4>
    3d8c:      	mov	x1, x2
    3d90:      	mov	x8, #0x18               ; =24
    3d94:      	b	0x3ad8 <_stogir.vector.validate+0x6a8>
    3d98:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003d98:  ARM64_RELOC_PAGE21	l_stogir.350
    3d9c:      	ldr	x16, [x16]
		0000000000003d9c:  ARM64_RELOC_PAGEOFF12	l_stogir.350
    3da0:      	orr	x0, x16, xzr
    3da4:      	mov	x26, x0
    3da8:      	mov	x27, #0x20              ; =32
    3dac:      	add	x16, sp, #0x40
    3db0:      	ldr	w0, [x16, #0x4]
    3db4:      	lsr	w0, w0, #0
    3db8:      	add	x8, sp, #0x170
    3dbc:      	mov	w1, w0
    3dc0:      	mov	x0, x21
    3dc4:      	bl	0x3dc4 <_stogir.vector.validate+0x994>
		0000000000003dc4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    3dc8:      	add	x16, sp, #0x170
    3dcc:      	ldr	w0, [x16]
    3dd0:      	lsr	x16, x0, #0
    3dd4:      	cmp	x16, #0x1
    3dd8:      	b.eq	0x3df4 <_stogir.vector.validate+0x9c4>
    3ddc:      	b.lo	0x3de4 <_stogir.vector.validate+0x9b4>
    3de0:      	b	0x3df8 <_stogir.vector.validate+0x9c8>
    3de4:      	cmp	x16, #0x0
    3de8:      	b.eq	0x3df0 <_stogir.vector.validate+0x9c0>
    3dec:      	b	0x3df8 <_stogir.vector.validate+0x9c8>
    3df0:      	b	0x3dfc <_stogir.vector.validate+0x9cc>
    3df4:      	b	0x3e20 <_stogir.vector.validate+0x9f0>
    3df8:      	b	0x3edc <_stogir.vector.validate+0xaac>
    3dfc:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003dfc:  ARM64_RELOC_PAGE21	l_stogir.351
    3e00:      	ldr	x16, [x16]
		0000000000003e00:  ARM64_RELOC_PAGEOFF12	l_stogir.351
    3e04:      	orr	x0, x16, xzr
    3e08:      	mov	x1, #0x19               ; =25
    3e0c:      	b	0x3a88 <_stogir.vector.validate+0x658>
    3e10:      	movz	x11, #0x0, lsl #48
    3e14:      	b	0x3d10 <_stogir.vector.validate+0x8e0>
    3e18:      	movz	x11, #0x0, lsl #48
    3e1c:      	b	0x3d08 <_stogir.vector.validate+0x8d8>
    3e20:      	add	x16, sp, #0x170
    3e24:      	ldr	x0, [x16, #0x8]
    3e28:      	add	x16, sp, #0x40
    3e2c:      	ldr	w1, [x16, #0x4]
    3e30:      	sxtw	x1, w1
    3e34:      	cmp	x1, #0x0
    3e38:      	b.gt	0x3eb0 <_stogir.vector.validate+0xa80>
    3e3c:      	mov	x1, x26
    3e40:      	mov	x0, #0x1                ; =1
    3e44:      	b	0x3e94 <_stogir.vector.validate+0xa64>
    3e48:      	movz	x11, #0x0, lsl #48
    3e4c:      	b	0x3e14 <_stogir.vector.validate+0x9e4>
    3e50:      	add	x16, sp, #0x40
    3e54:      	ldr	w0, [x16, #0x4]
    3e58:      	sxtw	x0, w0
    3e5c:      	ldr	x1, [x21, #0x78]
    3e60:      	lsl	x0, x0, #2
    3e64:      	add	x0, x0, x1
    3e68:      	ldr	w0, [x0]
    3e6c:      	sxtw	x0, w0
    3e70:      	add	x0, x0, #0x1
    3e74:      	lsr	w0, w0, #0
    3e78:      	sxtw	x0, w0
    3e7c:      	cmp	x28, x0
    3e80:      	cset	w0, eq
    3e84:      	uxtb	w16, w0
    3e88:      	cmp	w16, wzr
    3e8c:      	cset	x0, eq
    3e90:      	mov	x1, x26
    3e94:      	cmp	x0, #0x0
    3e98:      	b.eq	0x3a80 <_stogir.vector.validate+0x650>
    3e9c:      	adrp	x16, 0x3000 <_stogir.verify.classifications+0x2ec>
		0000000000003e9c:  ARM64_RELOC_PAGE21	l_stogir.352
    3ea0:      	ldr	x16, [x16]
		0000000000003ea0:  ARM64_RELOC_PAGEOFF12	l_stogir.352
    3ea4:      	orr	x0, x16, xzr
    3ea8:      	mov	x1, #0x19               ; =25
    3eac:      	b	0x3a88 <_stogir.vector.validate+0x658>
    3eb0:      	uxtb	w0, w0
    3eb4:      	cmp	x0, #0x70
    3eb8:      	b.eq	0x3e50 <_stogir.vector.validate+0xa20>
    3ebc:      	cmp	x0, #0x71
    3ec0:      	b.eq	0x3e50 <_stogir.vector.validate+0xa20>
    3ec4:      	mov	x0, #0x1                ; =1
    3ec8:      	b	0x3e90 <_stogir.vector.validate+0xa60>
    3ecc:      	brk	#0
    3ed0:      	b	0x3ecc <_stogir.vector.validate+0xa9c>
    3ed4:      	brk	#0
    3ed8:      	b	0x3ed4 <_stogir.vector.validate+0xaa4>
    3edc:      	brk	#0
    3ee0:      	b	0x3edc <_stogir.vector.validate+0xaac>
    3ee4:      	str	x20, [sp, #0x1a8]
    3ee8:      	str	w19, [sp, #0x1a0]
    3eec:      	b	0x35ec <_stogir.vector.validate+0x1bc>
    3ef0:      	str	x20, [sp, #0x1a8]
    3ef4:      	str	w19, [sp, #0x1a0]
    3ef8:      	mov	w19, w0
    3efc:      	mov	w20, w1
    3f00:      	str	w2, [sp, #0x1b0]
    3f04:      	str	w3, [sp, #0x1b8]
    3f08:      	b	0x36a8 <_stogir.vector.validate+0x278>

0000000000003f0c <_stogir.copy.validate>:
    3f0c:      	sub	sp, sp, #0x40
    3f10:      	str	x29, [sp]
    3f14:      	str	x30, [sp, #0x8]
    3f18:      	mov	x29, sp
    3f1c:      	str	x19, [sp, #0x20]
    3f20:      	str	x20, [sp, #0x28]
    3f24:      	str	x21, [sp, #0x30]
    3f28:      	sxtw	x1, w1
    3f2c:      	lsl	x2, x1, #2
    3f30:      	cmp	x1, #0x0
    3f34:      	cset	w3, gt
    3f38:      	movz	x16, #0x0, lsl #48
    3f3c:      	sub	x4, x16, x1
    3f40:      	sub	x5, x4, #0x1
    3f44:      	uxtb	w16, w3
    3f48:      	cmp	w16, wzr
    3f4c:      	b.eq	0x3f8c <_stogir.copy.validate+0x80>
    3f50:      	ldr	x4, [x0, #0x8]
    3f54:      	cmp	x1, x4
    3f58:      	b.ge	0x3fe0 <_stogir.copy.validate+0xd4>
    3f5c:      	add	x4, x0, #0x78
    3f60:      	ldr	x4, [x4, #0x8]
    3f64:      	cmp	x1, x4
    3f68:      	b.ge	0x410c <_stogir.copy.validate+0x200>
    3f6c:      	ldr	x4, [x0, #0x78]
    3f70:      	add	x4, x2, x4
    3f74:      	ldr	w4, [x4]
    3f78:      	sxtw	x4, w4
    3f7c:      	cmp	x4, #0x0
    3f80:      	cset	w4, ge
    3f84:      	ubfx	x4, x4, #0, #8
    3f88:      	b	0x4110 <_stogir.copy.validate+0x204>
    3f8c:      	cmp	x1, #0x0
    3f90:      	b.ge	0x3fe8 <_stogir.copy.validate+0xdc>
    3f94:      	add	x6, x0, #0x28
    3f98:      	add	x7, x0, #0x50
    3f9c:      	ldr	x6, [x6, #0x8]
    3fa0:      	ldr	x7, [x7, #0x8]
    3fa4:      	cmp	x6, x7
    3fa8:      	b.ne	0x3fd8 <_stogir.copy.validate+0xcc>
    3fac:      	cmp	x4, x6
    3fb0:      	b.gt	0x4154 <_stogir.copy.validate+0x248>
    3fb4:      	lsl	x4, x5, #2
    3fb8:      	ldr	x6, [x0, #0x50]
    3fbc:      	add	x4, x4, x6
    3fc0:      	ldr	w4, [x4]
    3fc4:      	sxtw	x4, w4
    3fc8:      	cmp	x4, #0x0
    3fcc:      	cset	w4, gt
    3fd0:      	ubfx	x4, x4, #0, #8
    3fd4:      	b	0x4158 <_stogir.copy.validate+0x24c>
    3fd8:      	movz	x4, #0x0, lsl #48
    3fdc:      	b	0x3fec <_stogir.copy.validate+0xe0>
    3fe0:      	movz	x4, #0x0, lsl #48
    3fe4:      	b	0x3fec <_stogir.copy.validate+0xe0>
    3fe8:      	movz	x4, #0x0, lsl #48
    3fec:      	cmp	x4, #0x0
    3ff0:      	b.eq	0x4054 <_stogir.copy.validate+0x148>
    3ff4:      	uxtb	w16, w3
    3ff8:      	cmp	w16, wzr
    3ffc:      	b.eq	0x4024 <_stogir.copy.validate+0x118>
    4000:      	lsl	x3, x1, #4
    4004:      	ldr	x4, [x0]
    4008:      	add	x3, x3, x4
    400c:      	ldr	x4, [x3]
    4010:      	ldr	x3, [x3, #0x8]
    4014:      	fmov	d31, x3
    4018:      	mov	x3, x4
    401c:      	fmov	x4, d31
    4020:      	b	0x4044 <_stogir.copy.validate+0x138>
    4024:      	lsl	x3, x5, #4
    4028:      	ldr	x4, [x0, #0x28]
    402c:      	add	x3, x3, x4
    4030:      	ldr	x4, [x3]
    4034:      	ldr	x3, [x3, #0x8]
    4038:      	fmov	d31, x3
    403c:      	mov	x3, x4
    4040:      	fmov	x4, d31
    4044:      	mov	x5, x4
    4048:      	mov	x4, x3
    404c:      	mov	x3, #0x1                ; =1
    4050:      	b	0x4060 <_stogir.copy.validate+0x154>
    4054:      	movz	x3, #0x0, lsl #48
    4058:      	movz	x4, #0x0, lsl #48
    405c:      	movz	x5, #0x0, lsl #48
    4060:      	lsr	w3, w3, #0
    4064:      	lsr	x16, x3, #0
    4068:      	cmp	x16, #0x1
    406c:      	b.eq	0x4088 <_stogir.copy.validate+0x17c>
    4070:      	b.lo	0x4078 <_stogir.copy.validate+0x16c>
    4074:      	b	0x408c <_stogir.copy.validate+0x180>
    4078:      	cmp	x16, #0x0
    407c:      	b.eq	0x4084 <_stogir.copy.validate+0x178>
    4080:      	b	0x408c <_stogir.copy.validate+0x180>
    4084:      	b	0x4090 <_stogir.copy.validate+0x184>
    4088:      	b	0x40d4 <_stogir.copy.validate+0x1c8>
    408c:      	b	0x41e4 <_stogir.copy.validate+0x2d8>
    4090:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004090:  ARM64_RELOC_PAGE21	l_stogir.353
    4094:      	ldr	x16, [x16]
		0000000000004094:  ARM64_RELOC_PAGEOFF12	l_stogir.353
    4098:      	orr	x0, x16, xzr
    409c:      	mov	x20, x8
    40a0:      	mov	x1, x0
    40a4:      	mov	x0, #0x1                ; =1
    40a8:      	mov	x2, #0x18               ; =24
    40ac:      	str	x0, [x20]
    40b0:      	str	x1, [x20, #0x8]
    40b4:      	str	x2, [x20, #0x10]
    40b8:      	ldr	x19, [sp, #0x20]
    40bc:      	ldr	x20, [sp, #0x28]
    40c0:      	ldr	x21, [sp, #0x30]
    40c4:      	ldr	x29, [sp]
    40c8:      	ldr	x30, [sp, #0x8]
    40cc:      	add	sp, sp, #0x40
    40d0:      	ret
    40d4:      	add	x16, sp, #0x10
    40d8:      	str	x4, [x16]
    40dc:      	add	x16, sp, #0x10
    40e0:      	str	x5, [x16, #0x8]
    40e4:      	cmp	x1, #0x0
    40e8:      	b.gt	0x4114 <_stogir.copy.validate+0x208>
    40ec:      	mov	x20, x8
    40f0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000040f0:  ARM64_RELOC_PAGE21	l_stogir.354
    40f4:      	ldr	x16, [x16]
		00000000000040f4:  ARM64_RELOC_PAGEOFF12	l_stogir.354
    40f8:      	orr	x0, x16, xzr
    40fc:      	mov	x1, x0
    4100:      	mov	x0, #0x1                ; =1
    4104:      	mov	x2, #0x21               ; =33
    4108:      	b	0x40ac <_stogir.copy.validate+0x1a0>
    410c:      	movz	x4, #0x0, lsl #48
    4110:      	b	0x3fe4 <_stogir.copy.validate+0xd8>
    4114:      	uxtb	w1, w4
    4118:      	cmp	x1, #0x44
    411c:      	b.ne	0x4348 <_stogir.copy.validate+0x43c>
    4120:      	ldr	x1, [x0, #0x78]
    4124:      	add	x1, x2, x1
    4128:      	ldr	w1, [x1]
    412c:      	sxtw	x1, w1
    4130:      	cmp	x1, #0x2
    4134:      	b.ne	0x4350 <_stogir.copy.validate+0x444>
    4138:      	lsr	w4, w4, #0
    413c:      	ubfx	x1, x4, #8, #8
    4140:      	orr	x19, x1, xzr
    4144:      	cmp	x19, #0x0
    4148:      	b.ne	0x415c <_stogir.copy.validate+0x250>
    414c:      	mov	x20, x8
    4150:      	b	0x40f0 <_stogir.copy.validate+0x1e4>
    4154:      	movz	x4, #0x0, lsl #48
    4158:      	b	0x3fdc <_stogir.copy.validate+0xd0>
    415c:      	lsr	w1, w1, #0
    4160:      	mov	x20, x8
    4164:      	mov	x21, x0
    4168:      	mov	w0, w1
    416c:      	bl	0x416c <_stogir.copy.validate+0x260>
		000000000000416c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    4170:      	cmp	x0, #0x0
    4174:      	b.eq	0x40f0 <_stogir.copy.validate+0x1e4>
    4178:      	add	x16, sp, #0x10
    417c:      	ldr	w0, [x16, #0x4]
    4180:      	sxtw	x0, w0
    4184:      	cmp	x0, #0x0
    4188:      	cset	w1, gt
    418c:      	movz	x16, #0x0, lsl #48
    4190:      	sub	x2, x16, x0
    4194:      	sub	x3, x2, #0x1
    4198:      	uxtb	w16, w1
    419c:      	cmp	w16, wzr
    41a0:      	b.eq	0x4208 <_stogir.copy.validate+0x2fc>
    41a4:      	ldr	x2, [x21, #0x8]
    41a8:      	cmp	x0, x2
    41ac:      	b.ge	0x4254 <_stogir.copy.validate+0x348>
    41b0:      	add	x2, x21, #0x78
    41b4:      	ldr	x2, [x2, #0x8]
    41b8:      	cmp	x0, x2
    41bc:      	b.ge	0x4330 <_stogir.copy.validate+0x424>
    41c0:      	lsl	x2, x0, #2
    41c4:      	ldr	x4, [x21, #0x78]
    41c8:      	add	x2, x2, x4
    41cc:      	ldr	w2, [x2]
    41d0:      	sxtw	x2, w2
    41d4:      	cmp	x2, #0x0
    41d8:      	cset	w2, ge
    41dc:      	ubfx	x2, x2, #0, #8
    41e0:      	b	0x4334 <_stogir.copy.validate+0x428>
    41e4:      	brk	#0
    41e8:      	b	0x41e4 <_stogir.copy.validate+0x2d8>
    41ec:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000041ec:  ARM64_RELOC_PAGE21	l_stogir.355
    41f0:      	ldr	x16, [x16]
		00000000000041f0:  ARM64_RELOC_PAGEOFF12	l_stogir.355
    41f4:      	orr	x0, x16, xzr
    41f8:      	mov	x1, x0
    41fc:      	mov	x0, #0x1                ; =1
    4200:      	mov	x2, #0x20               ; =32
    4204:      	b	0x4108 <_stogir.copy.validate+0x1fc>
    4208:      	cmp	x0, #0x0
    420c:      	b.ge	0x425c <_stogir.copy.validate+0x350>
    4210:      	add	x4, x21, #0x28
    4214:      	add	x5, x21, #0x50
    4218:      	ldr	x4, [x4, #0x8]
    421c:      	ldr	x5, [x5, #0x8]
    4220:      	cmp	x4, x5
    4224:      	b.ne	0x4328 <_stogir.copy.validate+0x41c>
    4228:      	cmp	x2, x4
    422c:      	b.gt	0x4338 <_stogir.copy.validate+0x42c>
    4230:      	lsl	x2, x3, #2
    4234:      	ldr	x4, [x21, #0x50]
    4238:      	add	x2, x2, x4
    423c:      	ldr	w2, [x2]
    4240:      	sxtw	x2, w2
    4244:      	cmp	x2, #0x0
    4248:      	cset	w2, gt
    424c:      	ubfx	x2, x2, #0, #8
    4250:      	b	0x433c <_stogir.copy.validate+0x430>
    4254:      	movz	x2, #0x0, lsl #48
    4258:      	b	0x4260 <_stogir.copy.validate+0x354>
    425c:      	movz	x2, #0x0, lsl #48
    4260:      	cmp	x2, #0x0
    4264:      	b.eq	0x42a4 <_stogir.copy.validate+0x398>
    4268:      	uxtb	w16, w1
    426c:      	cmp	w16, wzr
    4270:      	b.eq	0x4288 <_stogir.copy.validate+0x37c>
    4274:      	lsl	x0, x0, #4
    4278:      	ldr	x1, [x21]
    427c:      	add	x0, x0, x1
    4280:      	ldr	x0, [x0]
    4284:      	b	0x4298 <_stogir.copy.validate+0x38c>
    4288:      	lsl	x0, x3, #4
    428c:      	ldr	x1, [x21, #0x28]
    4290:      	add	x0, x0, x1
    4294:      	ldr	x0, [x0]
    4298:      	mov	x1, x0
    429c:      	mov	x0, #0x1                ; =1
    42a0:      	b	0x42ac <_stogir.copy.validate+0x3a0>
    42a4:      	movz	x0, #0x0, lsl #48
    42a8:      	movz	x1, #0x0, lsl #48
    42ac:      	lsr	w0, w0, #0
    42b0:      	lsr	x16, x0, #0
    42b4:      	cmp	x16, #0x1
    42b8:      	b.eq	0x42d4 <_stogir.copy.validate+0x3c8>
    42bc:      	b.lo	0x42c4 <_stogir.copy.validate+0x3b8>
    42c0:      	b	0x42d8 <_stogir.copy.validate+0x3cc>
    42c4:      	cmp	x16, #0x0
    42c8:      	b.eq	0x42d0 <_stogir.copy.validate+0x3c4>
    42cc:      	b	0x42d8 <_stogir.copy.validate+0x3cc>
    42d0:      	b	0x42dc <_stogir.copy.validate+0x3d0>
    42d4:      	b	0x42f8 <_stogir.copy.validate+0x3ec>
    42d8:      	b	0x4340 <_stogir.copy.validate+0x434>
    42dc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000042dc:  ARM64_RELOC_PAGE21	l_stogir.356
    42e0:      	ldr	x16, [x16]
		00000000000042e0:  ARM64_RELOC_PAGEOFF12	l_stogir.356
    42e4:      	orr	x0, x16, xzr
    42e8:      	mov	x1, x0
    42ec:      	mov	x0, #0x1                ; =1
    42f0:      	mov	x2, #0x13               ; =19
    42f4:      	b	0x4204 <_stogir.copy.validate+0x2f8>
    42f8:      	lsr	w1, w1, #0
    42fc:      	add	x16, sp, #0x10
    4300:      	ldr	w0, [x16]
    4304:      	ubfx	x1, x1, #8, #8
    4308:      	ubfx	x0, x0, #8, #8
    430c:      	cmp	x1, x0
    4310:      	b.ne	0x41ec <_stogir.copy.validate+0x2e0>
    4314:      	and	x0, x19, #0xffffffff
    4318:      	mov	x1, x0
    431c:      	movz	x0, #0x0, lsl #48
    4320:      	movz	x2, #0x0, lsl #48
    4324:      	b	0x4204 <_stogir.copy.validate+0x2f8>
    4328:      	movz	x2, #0x0, lsl #48
    432c:      	b	0x4260 <_stogir.copy.validate+0x354>
    4330:      	movz	x2, #0x0, lsl #48
    4334:      	b	0x4258 <_stogir.copy.validate+0x34c>
    4338:      	movz	x2, #0x0, lsl #48
    433c:      	b	0x432c <_stogir.copy.validate+0x420>
    4340:      	brk	#0
    4344:      	b	0x4340 <_stogir.copy.validate+0x434>
    4348:      	mov	x20, x8
    434c:      	b	0x40f0 <_stogir.copy.validate+0x1e4>
    4350:      	mov	x20, x8
    4354:      	b	0x40f0 <_stogir.copy.validate+0x1e4>

0000000000004358 <_stogir.graph.lookup>:
    4358:      	sxtw	x1, w1
    435c:      	cmp	x1, #0x0
    4360:      	cset	w2, gt
    4364:      	movz	x16, #0x0, lsl #48
    4368:      	sub	x3, x16, x1
    436c:      	sub	x4, x3, #0x1
    4370:      	uxtb	w16, w2
    4374:      	cmp	w16, wzr
    4378:      	b.eq	0x43bc <_stogir.graph.lookup+0x64>
    437c:      	ldr	x3, [x0, #0x8]
    4380:      	cmp	x1, x3
    4384:      	b.ge	0x4410 <_stogir.graph.lookup+0xb8>
    4388:      	add	x3, x0, #0x78
    438c:      	ldr	x3, [x3, #0x8]
    4390:      	cmp	x1, x3
    4394:      	b.ge	0x44b0 <_stogir.graph.lookup+0x158>
    4398:      	lsl	x3, x1, #2
    439c:      	ldr	x5, [x0, #0x78]
    43a0:      	add	x3, x3, x5
    43a4:      	ldr	w3, [x3]
    43a8:      	sxtw	x3, w3
    43ac:      	cmp	x3, #0x0
    43b0:      	cset	w3, ge
    43b4:      	ubfx	x3, x3, #0, #8
    43b8:      	b	0x44b4 <_stogir.graph.lookup+0x15c>
    43bc:      	cmp	x1, #0x0
    43c0:      	b.ge	0x4418 <_stogir.graph.lookup+0xc0>
    43c4:      	add	x5, x0, #0x28
    43c8:      	add	x6, x0, #0x50
    43cc:      	ldr	x5, [x5, #0x8]
    43d0:      	ldr	x6, [x6, #0x8]
    43d4:      	cmp	x5, x6
    43d8:      	b.ne	0x4408 <_stogir.graph.lookup+0xb0>
    43dc:      	cmp	x3, x5
    43e0:      	b.gt	0x44b8 <_stogir.graph.lookup+0x160>
    43e4:      	lsl	x3, x4, #2
    43e8:      	ldr	x5, [x0, #0x50]
    43ec:      	add	x3, x3, x5
    43f0:      	ldr	w3, [x3]
    43f4:      	sxtw	x3, w3
    43f8:      	cmp	x3, #0x0
    43fc:      	cset	w3, gt
    4400:      	ubfx	x3, x3, #0, #8
    4404:      	b	0x44bc <_stogir.graph.lookup+0x164>
    4408:      	movz	x3, #0x0, lsl #48
    440c:      	b	0x441c <_stogir.graph.lookup+0xc4>
    4410:      	movz	x3, #0x0, lsl #48
    4414:      	b	0x441c <_stogir.graph.lookup+0xc4>
    4418:      	movz	x3, #0x0, lsl #48
    441c:      	cmp	x3, #0x0
    4420:      	b.eq	0x4484 <_stogir.graph.lookup+0x12c>
    4424:      	uxtb	w16, w2
    4428:      	cmp	w16, wzr
    442c:      	b.eq	0x4454 <_stogir.graph.lookup+0xfc>
    4430:      	lsl	x1, x1, #4
    4434:      	ldr	x0, [x0]
    4438:      	add	x0, x1, x0
    443c:      	ldr	x1, [x0]
    4440:      	ldr	x0, [x0, #0x8]
    4444:      	fmov	d31, x0
    4448:      	mov	x0, x1
    444c:      	fmov	x1, d31
    4450:      	b	0x4474 <_stogir.graph.lookup+0x11c>
    4454:      	lsl	x1, x4, #4
    4458:      	ldr	x0, [x0, #0x28]
    445c:      	add	x0, x1, x0
    4460:      	ldr	x1, [x0]
    4464:      	ldr	x0, [x0, #0x8]
    4468:      	fmov	d31, x0
    446c:      	mov	x0, x1
    4470:      	fmov	x1, d31
    4474:      	mov	x2, x1
    4478:      	mov	x1, x0
    447c:      	mov	x0, #0x1                ; =1
    4480:      	b	0x4490 <_stogir.graph.lookup+0x138>
    4484:      	movz	x0, #0x0, lsl #48
    4488:      	movz	x1, #0x0, lsl #48
    448c:      	movz	x2, #0x0, lsl #48
    4490:      	str	x0, [x8]
    4494:      	str	x1, [x8, #0x8]
    4498:      	str	x2, [x8, #0x10]
    449c:      	movz	x17, #0x0, lsl #48
    44a0:      	str	x17, [x8, #0x18]
    44a4:      	movz	x17, #0x0, lsl #48
    44a8:      	str	x17, [x8, #0x20]
    44ac:      	ret
    44b0:      	movz	x3, #0x0, lsl #48
    44b4:      	b	0x4414 <_stogir.graph.lookup+0xbc>
    44b8:      	movz	x3, #0x0, lsl #48
    44bc:      	b	0x440c <_stogir.graph.lookup+0xb4>

00000000000044c0 <_stogir.opcode.block-start?>:
    44c0:      	sxtw	x0, w0
    44c4:      	cmp	x0, #0x0
    44c8:      	b.lt	0x44f0 <_stogir.opcode.block-start?+0x30>
    44cc:      	cmp	x0, #0x83
    44d0:      	b.ge	0x44f0 <_stogir.opcode.block-start?+0x30>
    44d4:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000044d4:  ARM64_RELOC_PAGE21	l_stogir.357
    44d8:      	ldr	x16, [x16]
		00000000000044d8:  ARM64_RELOC_PAGEOFF12	l_stogir.357
    44dc:      	orr	x1, x16, xzr
    44e0:      	lsr	x0, x0, #0
    44e4:      	add	x0, x0, x1
    44e8:      	ldrb	w0, [x0]
    44ec:      	b	0x44f4 <_stogir.opcode.block-start?+0x34>
    44f0:      	movz	x0, #0x0, lsl #48
    44f4:      	uxtb	w0, w0
    44f8:      	and	x0, x0, #0x2
    44fc:      	uxtb	w0, w0
    4500:      	cmp	x0, #0x0
    4504:      	cset	w0, eq
    4508:      	uxtb	w16, w0
    450c:      	cmp	w16, wzr
    4510:      	cset	x0, eq
    4514:      	ret

0000000000004518 <_stogir.checked.operation?>:
    4518:      	sxtw	x0, w0
    451c:      	cmp	x0, #0x29
    4520:      	b.lt	0x4534 <_stogir.checked.operation?+0x1c>
    4524:      	cmp	x0, #0x2b
    4528:      	cset	w0, le
    452c:      	ubfx	x0, x0, #0, #8
    4530:      	b	0x4538 <_stogir.checked.operation?+0x20>
    4534:      	movz	x0, #0x0, lsl #48
    4538:      	ret

000000000000453c <_stogir.checked.validate-projection>:
    453c:      	sub	sp, sp, #0x40
    4540:      	str	x29, [sp]
    4544:      	str	x30, [sp, #0x8]
    4548:      	mov	x29, sp
    454c:      	str	x19, [sp, #0x30]
    4550:      	sxtw	x1, w1
    4554:      	lsl	x2, x1, #2
    4558:      	cmp	x1, #0x0
    455c:      	cset	w3, gt
    4560:      	movz	x16, #0x0, lsl #48
    4564:      	sub	x4, x16, x1
    4568:      	sub	x5, x4, #0x1
    456c:      	uxtb	w16, w3
    4570:      	cmp	w16, wzr
    4574:      	b.eq	0x45b4 <_stogir.checked.validate-projection+0x78>
    4578:      	ldr	x4, [x0, #0x8]
    457c:      	cmp	x1, x4
    4580:      	b.ge	0x4608 <_stogir.checked.validate-projection+0xcc>
    4584:      	add	x4, x0, #0x78
    4588:      	ldr	x4, [x4, #0x8]
    458c:      	cmp	x1, x4
    4590:      	b.ge	0x46f4 <_stogir.checked.validate-projection+0x1b8>
    4594:      	ldr	x4, [x0, #0x78]
    4598:      	add	x4, x2, x4
    459c:      	ldr	w4, [x4]
    45a0:      	sxtw	x4, w4
    45a4:      	cmp	x4, #0x0
    45a8:      	cset	w4, ge
    45ac:      	ubfx	x4, x4, #0, #8
    45b0:      	b	0x46f8 <_stogir.checked.validate-projection+0x1bc>
    45b4:      	cmp	x1, #0x0
    45b8:      	b.ge	0x4610 <_stogir.checked.validate-projection+0xd4>
    45bc:      	add	x6, x0, #0x28
    45c0:      	add	x7, x0, #0x50
    45c4:      	ldr	x6, [x6, #0x8]
    45c8:      	ldr	x7, [x7, #0x8]
    45cc:      	cmp	x6, x7
    45d0:      	b.ne	0x4600 <_stogir.checked.validate-projection+0xc4>
    45d4:      	cmp	x4, x6
    45d8:      	b.gt	0x4760 <_stogir.checked.validate-projection+0x224>
    45dc:      	lsl	x4, x5, #2
    45e0:      	ldr	x6, [x0, #0x50]
    45e4:      	add	x4, x4, x6
    45e8:      	ldr	w4, [x4]
    45ec:      	sxtw	x4, w4
    45f0:      	cmp	x4, #0x0
    45f4:      	cset	w4, gt
    45f8:      	ubfx	x4, x4, #0, #8
    45fc:      	b	0x4764 <_stogir.checked.validate-projection+0x228>
    4600:      	movz	x4, #0x0, lsl #48
    4604:      	b	0x4614 <_stogir.checked.validate-projection+0xd8>
    4608:      	movz	x4, #0x0, lsl #48
    460c:      	b	0x4614 <_stogir.checked.validate-projection+0xd8>
    4610:      	movz	x4, #0x0, lsl #48
    4614:      	cmp	x4, #0x0
    4618:      	b.eq	0x4658 <_stogir.checked.validate-projection+0x11c>
    461c:      	uxtb	w16, w3
    4620:      	cmp	w16, wzr
    4624:      	b.eq	0x463c <_stogir.checked.validate-projection+0x100>
    4628:      	lsl	x3, x1, #4
    462c:      	ldr	x4, [x0]
    4630:      	add	x3, x3, x4
    4634:      	ldr	x3, [x3]
    4638:      	b	0x464c <_stogir.checked.validate-projection+0x110>
    463c:      	lsl	x3, x5, #4
    4640:      	ldr	x4, [x0, #0x28]
    4644:      	add	x3, x3, x4
    4648:      	ldr	x3, [x3]
    464c:      	mov	x4, x3
    4650:      	mov	x3, #0x1                ; =1
    4654:      	b	0x4660 <_stogir.checked.validate-projection+0x124>
    4658:      	movz	x3, #0x0, lsl #48
    465c:      	movz	x4, #0x0, lsl #48
    4660:      	lsr	w3, w3, #0
    4664:      	lsr	x16, x3, #0
    4668:      	cmp	x16, #0x1
    466c:      	b.eq	0x4688 <_stogir.checked.validate-projection+0x14c>
    4670:      	b.lo	0x4678 <_stogir.checked.validate-projection+0x13c>
    4674:      	b	0x468c <_stogir.checked.validate-projection+0x150>
    4678:      	cmp	x16, #0x0
    467c:      	b.eq	0x4684 <_stogir.checked.validate-projection+0x148>
    4680:      	b	0x468c <_stogir.checked.validate-projection+0x150>
    4684:      	b	0x4690 <_stogir.checked.validate-projection+0x154>
    4688:      	b	0x46b0 <_stogir.checked.validate-projection+0x174>
    468c:      	b	0x4768 <_stogir.checked.validate-projection+0x22c>
    4690:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004690:  ARM64_RELOC_PAGE21	l_stogir.358
    4694:      	ldr	x16, [x16]
		0000000000004694:  ARM64_RELOC_PAGEOFF12	l_stogir.358
    4698:      	orr	x0, x16, xzr
    469c:      	mov	x19, x8
    46a0:      	mov	x1, x0
    46a4:      	mov	x0, #0x1                ; =1
    46a8:      	mov	x2, #0x10               ; =16
    46ac:      	b	0x46d4 <_stogir.checked.validate-projection+0x198>
    46b0:      	cmp	x1, #0x0
    46b4:      	b.gt	0x46fc <_stogir.checked.validate-projection+0x1c0>
    46b8:      	mov	x19, x8
    46bc:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000046bc:  ARM64_RELOC_PAGE21	l_stogir.359
    46c0:      	ldr	x16, [x16]
		00000000000046c0:  ARM64_RELOC_PAGEOFF12	l_stogir.359
    46c4:      	orr	x0, x16, xzr
    46c8:      	mov	x1, x0
    46cc:      	mov	x0, #0x1                ; =1
    46d0:      	mov	x2, #0x1c               ; =28
    46d4:      	str	x0, [x19]
    46d8:      	str	x1, [x19, #0x8]
    46dc:      	str	x2, [x19, #0x10]
    46e0:      	ldr	x19, [sp, #0x30]
    46e4:      	ldr	x29, [sp]
    46e8:      	ldr	x30, [sp, #0x8]
    46ec:      	add	sp, sp, #0x40
    46f0:      	ret
    46f4:      	movz	x4, #0x0, lsl #48
    46f8:      	b	0x460c <_stogir.checked.validate-projection+0xd0>
    46fc:      	uxtb	w1, w4
    4700:      	cmp	x1, #0x2c
    4704:      	b.ne	0x4770 <_stogir.checked.validate-projection+0x234>
    4708:      	lsr	w1, w4, #0
    470c:      	ubfx	x1, x1, #8, #8
    4710:      	cmp	x1, #0x1
    4714:      	b.ne	0x4778 <_stogir.checked.validate-projection+0x23c>
    4718:      	ldr	x1, [x0, #0x78]
    471c:      	add	x1, x2, x1
    4720:      	ldr	w1, [x1]
    4724:      	sxtw	x1, w1
    4728:      	cmp	x1, #0x1
    472c:      	b.ne	0x4780 <_stogir.checked.validate-projection+0x244>
    4730:      	lsr	x1, x4, #32
    4734:      	lsr	w1, w1, #0
    4738:      	mov	x19, x8
    473c:      	add	x8, sp, #0x10
    4740:      	bl	0x4740 <_stogir.checked.validate-projection+0x204>
		0000000000004740:  ARM64_RELOC_BRANCH26	_stogir.checked.projection
    4744:      	add	x16, sp, #0x10
    4748:      	ldr	x0, [x16]
    474c:      	add	x16, sp, #0x10
    4750:      	ldr	x1, [x16, #0x8]
    4754:      	add	x16, sp, #0x10
    4758:      	ldr	x2, [x16, #0x10]
    475c:      	b	0x46d4 <_stogir.checked.validate-projection+0x198>
    4760:      	movz	x4, #0x0, lsl #48
    4764:      	b	0x4604 <_stogir.checked.validate-projection+0xc8>
    4768:      	brk	#0
    476c:      	b	0x4768 <_stogir.checked.validate-projection+0x22c>
    4770:      	mov	x19, x8
    4774:      	b	0x46bc <_stogir.checked.validate-projection+0x180>
    4778:      	mov	x19, x8
    477c:      	b	0x46bc <_stogir.checked.validate-projection+0x180>
    4780:      	mov	x19, x8
    4784:      	b	0x46bc <_stogir.checked.validate-projection+0x180>

0000000000004788 <_stogir.checked.validate>:
    4788:      	sub	sp, sp, #0x40
    478c:      	str	x29, [sp]
    4790:      	str	x30, [sp, #0x8]
    4794:      	mov	x29, sp
    4798:      	str	x19, [sp, #0x10]
    479c:      	str	x20, [sp, #0x18]
    47a0:      	str	x21, [sp, #0x20]
    47a4:      	str	x22, [sp, #0x28]
    47a8:      	str	x23, [sp, #0x30]
    47ac:      	sxtw	x1, w1
    47b0:      	lsl	x2, x1, #2
    47b4:      	cmp	x1, #0x0
    47b8:      	cset	w3, gt
    47bc:      	movz	x16, #0x0, lsl #48
    47c0:      	sub	x4, x16, x1
    47c4:      	sub	x5, x4, #0x1
    47c8:      	uxtb	w16, w3
    47cc:      	cmp	w16, wzr
    47d0:      	b.eq	0x4810 <_stogir.checked.validate+0x88>
    47d4:      	ldr	x4, [x0, #0x8]
    47d8:      	cmp	x1, x4
    47dc:      	b.ge	0x4864 <_stogir.checked.validate+0xdc>
    47e0:      	add	x4, x0, #0x78
    47e4:      	ldr	x4, [x4, #0x8]
    47e8:      	cmp	x1, x4
    47ec:      	b.ge	0x498c <_stogir.checked.validate+0x204>
    47f0:      	ldr	x4, [x0, #0x78]
    47f4:      	add	x4, x2, x4
    47f8:      	ldr	w4, [x4]
    47fc:      	sxtw	x4, w4
    4800:      	cmp	x4, #0x0
    4804:      	cset	w4, ge
    4808:      	ubfx	x4, x4, #0, #8
    480c:      	b	0x4990 <_stogir.checked.validate+0x208>
    4810:      	cmp	x1, #0x0
    4814:      	b.ge	0x486c <_stogir.checked.validate+0xe4>
    4818:      	add	x6, x0, #0x28
    481c:      	add	x7, x0, #0x50
    4820:      	ldr	x6, [x6, #0x8]
    4824:      	ldr	x7, [x7, #0x8]
    4828:      	cmp	x6, x7
    482c:      	b.ne	0x485c <_stogir.checked.validate+0xd4>
    4830:      	cmp	x4, x6
    4834:      	b.gt	0x4a10 <_stogir.checked.validate+0x288>
    4838:      	lsl	x4, x5, #2
    483c:      	ldr	x6, [x0, #0x50]
    4840:      	add	x4, x4, x6
    4844:      	ldr	w4, [x4]
    4848:      	sxtw	x4, w4
    484c:      	cmp	x4, #0x0
    4850:      	cset	w4, gt
    4854:      	ubfx	x4, x4, #0, #8
    4858:      	b	0x4a14 <_stogir.checked.validate+0x28c>
    485c:      	movz	x4, #0x0, lsl #48
    4860:      	b	0x4870 <_stogir.checked.validate+0xe8>
    4864:      	movz	x4, #0x0, lsl #48
    4868:      	b	0x4870 <_stogir.checked.validate+0xe8>
    486c:      	movz	x4, #0x0, lsl #48
    4870:      	cmp	x4, #0x0
    4874:      	b.eq	0x48d8 <_stogir.checked.validate+0x150>
    4878:      	uxtb	w16, w3
    487c:      	cmp	w16, wzr
    4880:      	b.eq	0x48a8 <_stogir.checked.validate+0x120>
    4884:      	lsl	x3, x1, #4
    4888:      	ldr	x4, [x0]
    488c:      	add	x3, x3, x4
    4890:      	ldr	x4, [x3]
    4894:      	ldr	x3, [x3, #0x8]
    4898:      	fmov	d31, x3
    489c:      	mov	x3, x4
    48a0:      	fmov	x4, d31
    48a4:      	b	0x48c8 <_stogir.checked.validate+0x140>
    48a8:      	lsl	x3, x5, #4
    48ac:      	ldr	x4, [x0, #0x28]
    48b0:      	add	x3, x3, x4
    48b4:      	ldr	x4, [x3]
    48b8:      	ldr	x3, [x3, #0x8]
    48bc:      	fmov	d31, x3
    48c0:      	mov	x3, x4
    48c4:      	fmov	x4, d31
    48c8:      	mov	x5, x4
    48cc:      	mov	x4, x3
    48d0:      	mov	x3, #0x1                ; =1
    48d4:      	b	0x48e4 <_stogir.checked.validate+0x15c>
    48d8:      	movz	x3, #0x0, lsl #48
    48dc:      	movz	x4, #0x0, lsl #48
    48e0:      	movz	x5, #0x0, lsl #48
    48e4:      	lsr	w3, w3, #0
    48e8:      	lsr	x16, x3, #0
    48ec:      	cmp	x16, #0x1
    48f0:      	b.eq	0x490c <_stogir.checked.validate+0x184>
    48f4:      	b.lo	0x48fc <_stogir.checked.validate+0x174>
    48f8:      	b	0x4910 <_stogir.checked.validate+0x188>
    48fc:      	cmp	x16, #0x0
    4900:      	b.eq	0x4908 <_stogir.checked.validate+0x180>
    4904:      	b	0x4910 <_stogir.checked.validate+0x188>
    4908:      	b	0x4914 <_stogir.checked.validate+0x18c>
    490c:      	b	0x4934 <_stogir.checked.validate+0x1ac>
    4910:      	b	0x4cc8 <_stogir.checked.validate+0x540>
    4914:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004914:  ARM64_RELOC_PAGE21	l_stogir.360
    4918:      	ldr	x16, [x16]
		0000000000004918:  ARM64_RELOC_PAGEOFF12	l_stogir.360
    491c:      	orr	x0, x16, xzr
    4920:      	mov	x23, x8
    4924:      	mov	x1, x0
    4928:      	mov	x0, #0x1                ; =1
    492c:      	mov	x2, #0x1a               ; =26
    4930:      	b	0x4958 <_stogir.checked.validate+0x1d0>
    4934:      	cmp	x1, #0x0
    4938:      	b.gt	0x4994 <_stogir.checked.validate+0x20c>
    493c:      	mov	x23, x8
    4940:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004940:  ARM64_RELOC_PAGE21	l_stogir.361
    4944:      	ldr	x16, [x16]
		0000000000004944:  ARM64_RELOC_PAGEOFF12	l_stogir.361
    4948:      	orr	x0, x16, xzr
    494c:      	mov	x1, x0
    4950:      	mov	x0, #0x1                ; =1
    4954:      	mov	x2, #0x26               ; =38
    4958:      	str	x0, [x23]
    495c:      	str	x1, [x23, #0x8]
    4960:      	str	x2, [x23, #0x10]
    4964:      	sub	sp, x29, #0x0
    4968:      	ldr	x19, [sp, #0x10]
    496c:      	ldr	x20, [sp, #0x18]
    4970:      	ldr	x21, [sp, #0x20]
    4974:      	ldr	x22, [sp, #0x28]
    4978:      	ldr	x23, [sp, #0x30]
    497c:      	ldr	x29, [sp]
    4980:      	ldr	x30, [sp, #0x8]
    4984:      	add	sp, sp, #0x40
    4988:      	ret
    498c:      	movz	x4, #0x0, lsl #48
    4990:      	b	0x4868 <_stogir.checked.validate+0xe0>
    4994:      	uxtb	w1, w4
    4998:      	cmp	x1, #0x29
    499c:      	b.lt	0x4ce8 <_stogir.checked.validate+0x560>
    49a0:      	cmp	x1, #0x2b
    49a4:      	b.gt	0x4cf0 <_stogir.checked.validate+0x568>
    49a8:      	ldr	x1, [x0, #0x78]
    49ac:      	add	x1, x2, x1
    49b0:      	ldr	w1, [x1]
    49b4:      	sxtw	x1, w1
    49b8:      	cmp	x1, #0x2
    49bc:      	b.ne	0x4cf8 <_stogir.checked.validate+0x570>
    49c0:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		00000000000049c0:  ARM64_RELOC_PAGE21	l_stogir.362
    49c4:      	ldr	x16, [x16]
		00000000000049c4:  ARM64_RELOC_PAGEOFF12	l_stogir.362
    49c8:      	orr	x1, x16, xzr
    49cc:      	lsr	w2, w4, #0
    49d0:      	mov	x19, sp
    49d4:      	sub	sp, sp, #0x10
    49d8:      	mov	x3, sp
    49dc:      	sub	sp, sp, #0x10
    49e0:      	mov	x6, sp
    49e4:      	ubfx	x2, x2, #8, #8
    49e8:      	orr	x20, x2, xzr
    49ec:      	cmp	x20, #0x1
    49f0:      	b.lt	0x4c50 <_stogir.checked.validate+0x4c8>
    49f4:      	cmp	x20, #0xb
    49f8:      	b.gt	0x4c50 <_stogir.checked.validate+0x4c8>
    49fc:      	cmp	x20, #0x1
    4a00:      	b.eq	0x4c50 <_stogir.checked.validate+0x4c8>
    4a04:      	mov	x2, x1
    4a08:      	movz	x7, #0x0, lsl #48
    4a0c:      	b	0x4c60 <_stogir.checked.validate+0x4d8>
    4a10:      	movz	x4, #0x0, lsl #48
    4a14:      	b	0x4860 <_stogir.checked.validate+0xd8>
    4a18:      	lsr	x0, x22, #0
    4a1c:      	mov	x2, x0
    4a20:      	mov	x0, x21
    4a24:      	mov	x23, x8
    4a28:      	bl	0x4a28 <_stogir.checked.validate+0x2a0>
		0000000000004a28:  ARM64_RELOC_BRANCH26	_memcmp
    4a2c:      	lsr	w0, w0, #0
    4a30:      	sxtw	x0, w0
    4a34:      	cmp	x0, #0x0
    4a38:      	b.eq	0x4b48 <_stogir.checked.validate+0x3c0>
    4a3c:      	mov	x1, x21
    4a40:      	mov	x2, x22
    4a44:      	mov	x0, #0x1                ; =1
    4a48:      	mov	sp, x19
    4a4c:      	b	0x4958 <_stogir.checked.validate+0x1d0>
    4a50:      	mov	x2, x11
    4a54:      	mov	x3, #0x28               ; =40
    4a58:      	mov	x21, x2
    4a5c:      	mov	x22, x3
    4a60:      	mov	x2, x4
    4a64:      	cmp	x2, #0x2
    4a68:      	b.ge	0x4a94 <_stogir.checked.validate+0x30c>
    4a6c:      	add	x3, x2, #0x1
    4a70:      	lsl	x2, x2, #2
    4a74:      	add	x2, x2, x9
    4a78:      	ldr	w2, [x2]
    4a7c:      	sxtw	x2, w2
    4a80:      	and	x2, x2, #0xffffffff
    4a84:      	mov	x4, x3
    4a88:      	mov	x3, x2
    4a8c:      	mov	x2, #0x1                ; =1
    4a90:      	b	0x4aa0 <_stogir.checked.validate+0x318>
    4a94:      	mov	x4, x2
    4a98:      	movz	x2, #0x0, lsl #48
    4a9c:      	movz	x3, #0x0, lsl #48
    4aa0:      	lsr	w2, w2, #0
    4aa4:      	lsr	x16, x2, #0
    4aa8:      	cmp	x16, #0x1
    4aac:      	b.eq	0x4ac8 <_stogir.checked.validate+0x340>
    4ab0:      	b.lo	0x4ab8 <_stogir.checked.validate+0x330>
    4ab4:      	b	0x4acc <_stogir.checked.validate+0x344>
    4ab8:      	cmp	x16, #0x0
    4abc:      	b.eq	0x4ac4 <_stogir.checked.validate+0x33c>
    4ac0:      	b	0x4acc <_stogir.checked.validate+0x344>
    4ac4:      	b	0x4b34 <_stogir.checked.validate+0x3ac>
    4ac8:      	b	0x4ad0 <_stogir.checked.validate+0x348>
    4acc:      	b	0x4cd8 <_stogir.checked.validate+0x550>
    4ad0:      	lsr	w3, w3, #0
    4ad4:      	sxtw	x3, w3
    4ad8:      	cmp	x3, #0x0
    4adc:      	cset	w2, gt
    4ae0:      	movz	x16, #0x0, lsl #48
    4ae4:      	sub	x5, x16, x3
    4ae8:      	sub	x6, x5, #0x1
    4aec:      	uxtb	w16, w2
    4af0:      	cmp	w16, wzr
    4af4:      	b.eq	0x4b5c <_stogir.checked.validate+0x3d4>
    4af8:      	ldr	x5, [x0, #0x8]
    4afc:      	cmp	x3, x5
    4b00:      	b.ge	0x4ba0 <_stogir.checked.validate+0x418>
    4b04:      	ldr	x5, [x12, #0x8]
    4b08:      	cmp	x3, x5
    4b0c:      	b.ge	0x4cc0 <_stogir.checked.validate+0x538>
    4b10:      	lsl	x5, x3, #2
    4b14:      	ldr	x7, [x0, #0x78]
    4b18:      	add	x5, x5, x7
    4b1c:      	ldr	w5, [x5]
    4b20:      	sxtw	x5, w5
    4b24:      	cmp	x5, #0x0
    4b28:      	cset	w5, ge
    4b2c:      	ubfx	x5, x5, #0, #8
    4b30:      	b	0x4cc4 <_stogir.checked.validate+0x53c>
    4b34:      	cmp	x22, #0x0
    4b38:      	b.ne	0x4d00 <_stogir.checked.validate+0x578>
    4b3c:      	cmp	x22, #0x0
    4b40:      	b.ne	0x4a18 <_stogir.checked.validate+0x290>
    4b44:      	mov	x23, x8
    4b48:      	and	x0, x20, #0xffffffff
    4b4c:      	mov	x1, x0
    4b50:      	movz	x0, #0x0, lsl #48
    4b54:      	movz	x2, #0x0, lsl #48
    4b58:      	b	0x4a48 <_stogir.checked.validate+0x2c0>
    4b5c:      	cmp	x3, #0x0
    4b60:      	b.ge	0x4ba8 <_stogir.checked.validate+0x420>
    4b64:      	ldr	x7, [x13, #0x8]
    4b68:      	ldr	x15, [x14, #0x8]
    4b6c:      	cmp	x7, x15
    4b70:      	b.ne	0x4cb8 <_stogir.checked.validate+0x530>
    4b74:      	cmp	x5, x7
    4b78:      	b.gt	0x4cd0 <_stogir.checked.validate+0x548>
    4b7c:      	lsl	x5, x6, #2
    4b80:      	ldr	x7, [x0, #0x50]
    4b84:      	add	x5, x5, x7
    4b88:      	ldr	w5, [x5]
    4b8c:      	sxtw	x5, w5
    4b90:      	cmp	x5, #0x0
    4b94:      	cset	w5, gt
    4b98:      	ubfx	x5, x5, #0, #8
    4b9c:      	b	0x4cd4 <_stogir.checked.validate+0x54c>
    4ba0:      	movz	x5, #0x0, lsl #48
    4ba4:      	b	0x4bac <_stogir.checked.validate+0x424>
    4ba8:      	movz	x5, #0x0, lsl #48
    4bac:      	cmp	x5, #0x0
    4bb0:      	b.eq	0x4bf0 <_stogir.checked.validate+0x468>
    4bb4:      	uxtb	w16, w2
    4bb8:      	cmp	w16, wzr
    4bbc:      	b.eq	0x4bd4 <_stogir.checked.validate+0x44c>
    4bc0:      	lsl	x2, x3, #4
    4bc4:      	ldr	x3, [x0]
    4bc8:      	add	x2, x2, x3
    4bcc:      	ldr	x2, [x2]
    4bd0:      	b	0x4be4 <_stogir.checked.validate+0x45c>
    4bd4:      	lsl	x2, x6, #4
    4bd8:      	ldr	x3, [x0, #0x28]
    4bdc:      	add	x2, x2, x3
    4be0:      	ldr	x2, [x2]
    4be4:      	mov	x3, x2
    4be8:      	mov	x2, #0x1                ; =1
    4bec:      	b	0x4bf8 <_stogir.checked.validate+0x470>
    4bf0:      	movz	x2, #0x0, lsl #48
    4bf4:      	movz	x3, #0x0, lsl #48
    4bf8:      	lsr	w2, w2, #0
    4bfc:      	lsr	x16, x2, #0
    4c00:      	cmp	x16, #0x1
    4c04:      	b.eq	0x4c20 <_stogir.checked.validate+0x498>
    4c08:      	b.lo	0x4c10 <_stogir.checked.validate+0x488>
    4c0c:      	b	0x4c24 <_stogir.checked.validate+0x49c>
    4c10:      	cmp	x16, #0x0
    4c14:      	b.eq	0x4c1c <_stogir.checked.validate+0x494>
    4c18:      	b	0x4c24 <_stogir.checked.validate+0x49c>
    4c1c:      	b	0x4c28 <_stogir.checked.validate+0x4a0>
    4c20:      	b	0x4c34 <_stogir.checked.validate+0x4ac>
    4c24:      	b	0x4ce0 <_stogir.checked.validate+0x558>
    4c28:      	mov	x2, x10
    4c2c:      	mov	x3, #0x22               ; =34
    4c30:      	b	0x4a58 <_stogir.checked.validate+0x2d0>
    4c34:      	lsr	w3, w3, #0
    4c38:      	ubfx	x2, x3, #8, #8
    4c3c:      	cmp	x2, x20
    4c40:      	b.ne	0x4a50 <_stogir.checked.validate+0x2c8>
    4c44:      	mov	x2, x21
    4c48:      	mov	x3, x22
    4c4c:      	b	0x4a58 <_stogir.checked.validate+0x2d0>
    4c50:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004c50:  ARM64_RELOC_PAGE21	l_stogir.363
    4c54:      	ldr	x16, [x16]
		0000000000004c54:  ARM64_RELOC_PAGEOFF12	l_stogir.363
    4c58:      	orr	x2, x16, xzr
    4c5c:      	mov	x7, #0x36               ; =54
    4c60:      	orr	x9, x6, xzr
    4c64:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004c64:  ARM64_RELOC_PAGE21	l_stogir.364
    4c68:      	ldr	x16, [x16]
		0000000000004c68:  ARM64_RELOC_PAGEOFF12	l_stogir.364
    4c6c:      	orr	x10, x16, xzr
    4c70:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004c70:  ARM64_RELOC_PAGE21	l_stogir.365
    4c74:      	ldr	x16, [x16]
		0000000000004c74:  ARM64_RELOC_PAGEOFF12	l_stogir.365
    4c78:      	orr	x11, x16, xzr
    4c7c:      	add	x12, x0, #0x78
    4c80:      	add	x13, x0, #0x28
    4c84:      	add	x14, x0, #0x50
    4c88:      	lsr	w5, w5, #0
    4c8c:      	lsr	x4, x4, #32
    4c90:      	lsr	w5, w5, #0
    4c94:      	lsr	w4, w4, #0
    4c98:      	str	w4, [x3]
    4c9c:      	str	w5, [x3, #0x4]
    4ca0:      	ldr	x3, [x3]
    4ca4:      	str	x3, [x6]
    4ca8:      	mov	x21, x2
    4cac:      	mov	x22, x7
    4cb0:      	movz	x2, #0x0, lsl #48
    4cb4:      	b	0x4a64 <_stogir.checked.validate+0x2dc>
    4cb8:      	movz	x5, #0x0, lsl #48
    4cbc:      	b	0x4bac <_stogir.checked.validate+0x424>
    4cc0:      	movz	x5, #0x0, lsl #48
    4cc4:      	b	0x4ba4 <_stogir.checked.validate+0x41c>
    4cc8:      	brk	#0
    4ccc:      	b	0x4cc8 <_stogir.checked.validate+0x540>
    4cd0:      	movz	x5, #0x0, lsl #48
    4cd4:      	b	0x4cbc <_stogir.checked.validate+0x534>
    4cd8:      	brk	#0
    4cdc:      	b	0x4cd8 <_stogir.checked.validate+0x550>
    4ce0:      	brk	#0
    4ce4:      	b	0x4ce0 <_stogir.checked.validate+0x558>
    4ce8:      	mov	x23, x8
    4cec:      	b	0x4940 <_stogir.checked.validate+0x1b8>
    4cf0:      	mov	x23, x8
    4cf4:      	b	0x4940 <_stogir.checked.validate+0x1b8>
    4cf8:      	mov	x23, x8
    4cfc:      	b	0x4940 <_stogir.checked.validate+0x1b8>
    4d00:      	mov	x23, x8
    4d04:      	b	0x4a3c <_stogir.checked.validate+0x2b4>

0000000000004d08 <_stogir.atomic.operation?>:
    4d08:      	sxtw	x0, w0
    4d0c:      	cmp	x0, #0x7e
    4d10:      	b.lt	0x4d24 <_stogir.atomic.operation?+0x1c>
    4d14:      	cmp	x0, #0x82
    4d18:      	cset	w0, le
    4d1c:      	ubfx	x0, x0, #0, #8
    4d20:      	b	0x4d28 <_stogir.atomic.operation?+0x20>
    4d24:      	movz	x0, #0x0, lsl #48
    4d28:      	ret

0000000000004d2c <_stogir.atomic.validate>:
    4d2c:      	sub	sp, sp, #0xf0
    4d30:      	str	x29, [sp, #0x10]
    4d34:      	str	x30, [sp, #0x18]
    4d38:      	add	x29, sp, #0x10
    4d3c:      	str	x19, [sp, #0xa0]
    4d40:      	str	x20, [sp, #0xa8]
    4d44:      	str	x21, [sp, #0xb0]
    4d48:      	str	x22, [sp, #0xb8]
    4d4c:      	str	x23, [sp, #0xc0]
    4d50:      	str	x24, [sp, #0xc8]
    4d54:      	str	x25, [sp, #0xd0]
    4d58:      	str	x26, [sp, #0xd8]
    4d5c:      	str	x27, [sp, #0xe0]
    4d60:      	str	x28, [sp, #0xe8]
    4d64:      	sxtw	x2, w1
    4d68:      	lsl	x3, x2, #2
    4d6c:      	cmp	x2, #0x0
    4d70:      	cset	w4, gt
    4d74:      	movz	x16, #0x0, lsl #48
    4d78:      	sub	x5, x16, x2
    4d7c:      	sub	x6, x5, #0x1
    4d80:      	uxtb	w16, w4
    4d84:      	cmp	w16, wzr
    4d88:      	b.eq	0x4dc8 <_stogir.atomic.validate+0x9c>
    4d8c:      	ldr	x5, [x0, #0x8]
    4d90:      	cmp	x2, x5
    4d94:      	b.ge	0x4e1c <_stogir.atomic.validate+0xf0>
    4d98:      	add	x5, x0, #0x78
    4d9c:      	ldr	x5, [x5, #0x8]
    4da0:      	cmp	x2, x5
    4da4:      	b.ge	0x4f94 <_stogir.atomic.validate+0x268>
    4da8:      	ldr	x5, [x0, #0x78]
    4dac:      	add	x5, x3, x5
    4db0:      	ldr	w5, [x5]
    4db4:      	sxtw	x5, w5
    4db8:      	cmp	x5, #0x0
    4dbc:      	cset	w5, ge
    4dc0:      	ubfx	x5, x5, #0, #8
    4dc4:      	b	0x4f98 <_stogir.atomic.validate+0x26c>
    4dc8:      	cmp	x2, #0x0
    4dcc:      	b.ge	0x4e24 <_stogir.atomic.validate+0xf8>
    4dd0:      	add	x7, x0, #0x28
    4dd4:      	add	x9, x0, #0x50
    4dd8:      	ldr	x7, [x7, #0x8]
    4ddc:      	ldr	x9, [x9, #0x8]
    4de0:      	cmp	x7, x9
    4de4:      	b.ne	0x4e14 <_stogir.atomic.validate+0xe8>
    4de8:      	cmp	x5, x7
    4dec:      	b.gt	0x5068 <_stogir.atomic.validate+0x33c>
    4df0:      	lsl	x5, x6, #2
    4df4:      	ldr	x7, [x0, #0x50]
    4df8:      	add	x5, x5, x7
    4dfc:      	ldr	w5, [x5]
    4e00:      	sxtw	x5, w5
    4e04:      	cmp	x5, #0x0
    4e08:      	cset	w5, gt
    4e0c:      	ubfx	x5, x5, #0, #8
    4e10:      	b	0x506c <_stogir.atomic.validate+0x340>
    4e14:      	movz	x5, #0x0, lsl #48
    4e18:      	b	0x4e28 <_stogir.atomic.validate+0xfc>
    4e1c:      	movz	x5, #0x0, lsl #48
    4e20:      	b	0x4e28 <_stogir.atomic.validate+0xfc>
    4e24:      	movz	x5, #0x0, lsl #48
    4e28:      	cmp	x5, #0x0
    4e2c:      	b.eq	0x4e8c <_stogir.atomic.validate+0x160>
    4e30:      	uxtb	w16, w4
    4e34:      	cmp	w16, wzr
    4e38:      	b.eq	0x4e60 <_stogir.atomic.validate+0x134>
    4e3c:      	lsl	x4, x2, #4
    4e40:      	ldr	x5, [x0]
    4e44:      	add	x4, x4, x5
    4e48:      	ldr	x5, [x4]
    4e4c:      	ldr	x4, [x4, #0x8]
    4e50:      	fmov	d31, x4
    4e54:      	mov	x4, x5
    4e58:      	fmov	x5, d31
    4e5c:      	b	0x4e80 <_stogir.atomic.validate+0x154>
    4e60:      	lsl	x4, x6, #4
    4e64:      	ldr	x5, [x0, #0x28]
    4e68:      	add	x4, x4, x5
    4e6c:      	ldr	x5, [x4]
    4e70:      	ldr	x4, [x4, #0x8]
    4e74:      	fmov	d31, x4
    4e78:      	mov	x4, x5
    4e7c:      	fmov	x5, d31
    4e80:      	mov	x19, x4
    4e84:      	mov	x4, #0x1                ; =1
    4e88:      	b	0x4e98 <_stogir.atomic.validate+0x16c>
    4e8c:      	movz	x4, #0x0, lsl #48
    4e90:      	movz	x19, #0x0, lsl #48
    4e94:      	movz	x5, #0x0, lsl #48
    4e98:      	lsr	w4, w4, #0
    4e9c:      	lsr	x16, x4, #0
    4ea0:      	cmp	x16, #0x1
    4ea4:      	b.eq	0x4ec0 <_stogir.atomic.validate+0x194>
    4ea8:      	b.lo	0x4eb0 <_stogir.atomic.validate+0x184>
    4eac:      	b	0x4ec4 <_stogir.atomic.validate+0x198>
    4eb0:      	cmp	x16, #0x0
    4eb4:      	b.eq	0x4ebc <_stogir.atomic.validate+0x190>
    4eb8:      	b	0x4ec4 <_stogir.atomic.validate+0x198>
    4ebc:      	b	0x4ec8 <_stogir.atomic.validate+0x19c>
    4ec0:      	b	0x4f28 <_stogir.atomic.validate+0x1fc>
    4ec4:      	b	0x569c <_stogir.atomic.validate+0x970>
    4ec8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004ec8:  ARM64_RELOC_PAGE21	l_stogir.366
    4ecc:      	ldr	x16, [x16]
		0000000000004ecc:  ARM64_RELOC_PAGEOFF12	l_stogir.366
    4ed0:      	orr	x0, x16, xzr
    4ed4:      	mov	x24, x8
    4ed8:      	mov	x1, x0
    4edc:      	mov	x0, #0x1                ; =1
    4ee0:      	mov	x2, #0x1a               ; =26
    4ee4:      	str	x0, [x24]
    4ee8:      	str	x1, [x24, #0x8]
    4eec:      	str	x2, [x24, #0x10]
    4ef0:      	ldr	x19, [sp, #0xa0]
    4ef4:      	ldr	x20, [sp, #0xa8]
    4ef8:      	ldr	x21, [sp, #0xb0]
    4efc:      	ldr	x22, [sp, #0xb8]
    4f00:      	ldr	x23, [sp, #0xc0]
    4f04:      	ldr	x24, [sp, #0xc8]
    4f08:      	ldr	x25, [sp, #0xd0]
    4f0c:      	ldr	x26, [sp, #0xd8]
    4f10:      	ldr	x27, [sp, #0xe0]
    4f14:      	ldr	x28, [sp, #0xe8]
    4f18:      	ldr	x29, [sp, #0x10]
    4f1c:      	ldr	x30, [sp, #0x18]
    4f20:      	add	sp, sp, #0xf0
    4f24:      	ret
    4f28:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004f28:  ARM64_RELOC_PAGE21	l_stogir.367
    4f2c:      	ldr	x16, [x16]
		0000000000004f2c:  ARM64_RELOC_PAGEOFF12	l_stogir.367
    4f30:      	orr	x20, x16, xzr
    4f34:      	uxtb	w4, w19
    4f38:      	add	x16, sp, #0x20
    4f3c:      	str	x19, [x16]
    4f40:      	orr	x21, x4, xzr
    4f44:      	add	x16, sp, #0x20
    4f48:      	str	x5, [x16, #0x8]
    4f4c:      	cmp	x2, #0x0
    4f50:      	b.le	0x4fe8 <_stogir.atomic.validate+0x2bc>
    4f54:      	cmp	x21, #0x7e
    4f58:      	b.lt	0x4fe8 <_stogir.atomic.validate+0x2bc>
    4f5c:      	cmp	x21, #0x82
    4f60:      	b.gt	0x4fe8 <_stogir.atomic.validate+0x2bc>
    4f64:      	ldr	x2, [x0, #0x78]
    4f68:      	add	x2, x3, x2
    4f6c:      	ldr	w2, [x2]
    4f70:      	cmp	x21, #0x83
    4f74:      	b.ge	0x55c8 <_stogir.atomic.validate+0x89c>
    4f78:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004f78:  ARM64_RELOC_PAGE21	l_stogir.368
    4f7c:      	ldr	x16, [x16]
		0000000000004f7c:  ARM64_RELOC_PAGEOFF12	l_stogir.368
    4f80:      	orr	x3, x16, xzr
    4f84:      	add	x3, x21, x3
    4f88:      	ldrsb	w3, [x3]
    4f8c:      	sxtb	x3, w3
    4f90:      	b	0x55cc <_stogir.atomic.validate+0x8a0>
    4f94:      	movz	x5, #0x0, lsl #48
    4f98:      	b	0x4e20 <_stogir.atomic.validate+0xf4>
    4f9c:      	mov	x19, x21
    4fa0:      	mov	x21, x23
    4fa4:      	cmp	x21, #0x0
    4fa8:      	b.ne	0x4fd8 <_stogir.atomic.validate+0x2ac>
    4fac:      	cmp	x21, #0x0
    4fb0:      	b.eq	0x5470 <_stogir.atomic.validate+0x744>
    4fb4:      	lsr	x0, x21, #0
    4fb8:      	mov	x1, x20
    4fbc:      	mov	x2, x0
    4fc0:      	mov	x0, x19
    4fc4:      	bl	0x4fc4 <_stogir.atomic.validate+0x298>
		0000000000004fc4:  ARM64_RELOC_BRANCH26	_memcmp
    4fc8:      	lsr	w0, w0, #0
    4fcc:      	sxtw	x0, w0
    4fd0:      	cmp	x0, #0x0
    4fd4:      	b.eq	0x5470 <_stogir.atomic.validate+0x744>
    4fd8:      	mov	x1, x19
    4fdc:      	mov	x2, x21
    4fe0:      	mov	x0, #0x1                ; =1
    4fe4:      	b	0x4ee4 <_stogir.atomic.validate+0x1b8>
    4fe8:      	adrp	x16, 0x4000 <_stogir.copy.validate+0xf4>
		0000000000004fe8:  ARM64_RELOC_PAGE21	l_stogir.369
    4fec:      	ldr	x16, [x16]
		0000000000004fec:  ARM64_RELOC_PAGEOFF12	l_stogir.369
    4ff0:      	orr	x2, x16, xzr
    4ff4:      	mov	x22, x2
    4ff8:      	mov	x23, #0x20              ; =32
    4ffc:      	add	x16, sp, #0x20
    5000:      	ldr	w2, [x16, #0x4]
    5004:      	lsr	w2, w2, #0
    5008:      	mov	x24, x8
    500c:      	add	x8, sp, #0x30
    5010:      	mov	x25, x0
    5014:      	mov	w26, w1
    5018:      	mov	w1, w2
    501c:      	bl	0x501c <_stogir.atomic.validate+0x2f0>
		000000000000501c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5020:      	add	x16, sp, #0x30
    5024:      	ldr	w0, [x16]
    5028:      	lsr	x16, x0, #0
    502c:      	cmp	x16, #0x1
    5030:      	b.eq	0x504c <_stogir.atomic.validate+0x320>
    5034:      	b.lo	0x503c <_stogir.atomic.validate+0x310>
    5038:      	b	0x5050 <_stogir.atomic.validate+0x324>
    503c:      	cmp	x16, #0x0
    5040:      	b.eq	0x5048 <_stogir.atomic.validate+0x31c>
    5044:      	b	0x5050 <_stogir.atomic.validate+0x324>
    5048:      	b	0x5054 <_stogir.atomic.validate+0x328>
    504c:      	b	0x5150 <_stogir.atomic.validate+0x424>
    5050:      	b	0x56d4 <_stogir.atomic.validate+0x9a8>
    5054:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005054:  ARM64_RELOC_PAGE21	l_stogir.370
    5058:      	ldr	x16, [x16]
		0000000000005058:  ARM64_RELOC_PAGEOFF12	l_stogir.370
    505c:      	orr	x0, x16, xzr
    5060:      	mov	x1, #0x16               ; =22
    5064:      	b	0x5078 <_stogir.atomic.validate+0x34c>
    5068:      	movz	x5, #0x0, lsl #48
    506c:      	b	0x4e18 <_stogir.atomic.validate+0xec>
    5070:      	mov	x0, x1
    5074:      	mov	x1, x2
    5078:      	cmp	x21, #0x82
    507c:      	cset	w22, eq
    5080:      	lsr	w19, w19, #0
    5084:      	ubfx	x2, x19, #8, #8
    5088:      	orr	x19, x2, xzr
    508c:      	cmp	x19, #0x0
    5090:      	cset	w23, eq
    5094:      	uxtb	w16, w22
    5098:      	cmp	w16, wzr
    509c:      	b.eq	0x50c4 <_stogir.atomic.validate+0x398>
    50a0:      	uxtb	w16, w23
    50a4:      	cmp	w16, wzr
    50a8:      	b.eq	0x52bc <_stogir.atomic.validate+0x590>
    50ac:      	mov	x2, x0
    50b0:      	movz	x0, #0x0, lsl #48
    50b4:      	b	0x52c4 <_stogir.atomic.validate+0x598>
    50b8:      	mov	x0, x2
    50bc:      	mov	x27, x1
    50c0:      	b	0x50c8 <_stogir.atomic.validate+0x39c>
    50c4:      	mov	x27, x1
    50c8:      	uxtb	w16, w22
    50cc:      	cmp	w16, wzr
    50d0:      	b.eq	0x50e0 <_stogir.atomic.validate+0x3b4>
    50d4:      	mov	x28, x0
    50d8:      	movz	x0, #0x0, lsl #48
    50dc:      	b	0x50e8 <_stogir.atomic.validate+0x3bc>
    50e0:      	mov	x28, x0
    50e4:      	mov	x0, #0x1                ; =1
    50e8:      	cmp	x0, #0x0
    50ec:      	b.eq	0x5120 <_stogir.atomic.validate+0x3f4>
    50f0:      	add	x16, sp, #0x20
    50f4:      	ldr	w0, [x16, #0x8]
    50f8:      	lsr	w0, w0, #0
    50fc:      	mov	w1, w0
    5100:      	mov	x0, x25
    5104:      	mov	x2, #0x6                ; =6
    5108:      	bl	0x5108 <_stogir.atomic.validate+0x3dc>
		0000000000005108:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    510c:      	cmp	x0, #0x0
    5110:      	b.eq	0x5270 <_stogir.atomic.validate+0x544>
    5114:      	mov	x1, x28
    5118:      	movz	x0, #0x0, lsl #48
    511c:      	b	0x5278 <_stogir.atomic.validate+0x54c>
    5120:      	mov	x0, x19
    5124:      	mov	x1, x28
    5128:      	mov	x2, x27
    512c:      	cmp	x21, #0x80
    5130:      	cset	w19, eq
    5134:      	uxtb	w16, w19
    5138:      	cmp	w16, wzr
    513c:      	b.eq	0x517c <_stogir.atomic.validate+0x450>
    5140:      	mov	x21, x1
    5144:      	mov	x23, x2
    5148:      	mov	x1, #0x1                ; =1
    514c:      	b	0x5194 <_stogir.atomic.validate+0x468>
    5150:      	add	x16, sp, #0x30
    5154:      	ldr	x0, [x16, #0x8]
    5158:      	add	x16, sp, #0x20
    515c:      	ldr	w1, [x16, #0x4]
    5160:      	sxtw	x1, w1
    5164:      	cmp	x1, #0x0
    5168:      	b.gt	0x5328 <_stogir.atomic.validate+0x5fc>
    516c:      	mov	x1, x22
    5170:      	mov	x2, x23
    5174:      	mov	x0, #0x1                ; =1
    5178:      	b	0x530c <_stogir.atomic.validate+0x5e0>
    517c:      	cmp	x21, #0x81
    5180:      	cset	w3, eq
    5184:      	ubfx	x3, x3, #0, #8
    5188:      	mov	x21, x1
    518c:      	mov	x1, x3
    5190:      	mov	x23, x2
    5194:      	lsr	w27, w0, #0
    5198:      	cmp	x1, #0x0
    519c:      	b.eq	0x4f9c <_stogir.atomic.validate+0x270>
    51a0:      	lsr	w26, w26, #0
    51a4:      	add	x16, sp, #0x90
    51a8:      	str	x16, [sp]
    51ac:      	mov	x0, x25
    51b0:      	mov	w1, w26
    51b4:      	mov	x2, #0x4                ; =4
    51b8:      	bl	0x51b8 <_stogir.atomic.validate+0x48c>
		00000000000051b8:  ARM64_RELOC_BRANCH26	_stogir.graph.operand
    51bc:      	ldr	x16, [sp]
    51c0:      	str	x0, [x16]
    51c4:      	str	x1, [x16, #0x8]
    51c8:      	add	x16, sp, #0x90
    51cc:      	ldr	x0, [x16]
    51d0:      	add	x16, sp, #0x90
    51d4:      	ldr	x1, [x16, #0x8]
    51d8:      	lsr	w0, w0, #0
    51dc:      	lsr	x16, x0, #0
    51e0:      	cmp	x16, #0x1
    51e4:      	b.eq	0x5200 <_stogir.atomic.validate+0x4d4>
    51e8:      	b.lo	0x51f0 <_stogir.atomic.validate+0x4c4>
    51ec:      	b	0x5204 <_stogir.atomic.validate+0x4d8>
    51f0:      	cmp	x16, #0x0
    51f4:      	b.eq	0x51fc <_stogir.atomic.validate+0x4d0>
    51f8:      	b	0x5204 <_stogir.atomic.validate+0x4d8>
    51fc:      	b	0x5208 <_stogir.atomic.validate+0x4dc>
    5200:      	b	0x5484 <_stogir.atomic.validate+0x758>
    5204:      	b	0x56e4 <_stogir.atomic.validate+0x9b8>
    5208:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005208:  ARM64_RELOC_PAGE21	l_stogir.371
    520c:      	ldr	x16, [x16]
		000000000000520c:  ARM64_RELOC_PAGEOFF12	l_stogir.371
    5210:      	orr	x0, x16, xzr
    5214:      	mov	x1, #0x1d               ; =29
    5218:      	b	0x5244 <_stogir.atomic.validate+0x518>
    521c:      	mov	x0, x1
    5220:      	mov	x1, x2
    5224:      	mov	x2, x1
    5228:      	mov	x1, x0
    522c:      	mov	x0, x19
    5230:      	b	0x512c <_stogir.atomic.validate+0x400>
    5234:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005234:  ARM64_RELOC_PAGE21	l_stogir.372
    5238:      	ldr	x16, [x16]
		0000000000005238:  ARM64_RELOC_PAGEOFF12	l_stogir.372
    523c:      	orr	x0, x16, xzr
    5240:      	mov	x1, #0x24               ; =36
    5244:      	mov	x19, x0
    5248:      	mov	x21, x1
    524c:      	b	0x4fa4 <_stogir.atomic.validate+0x278>
    5250:      	mov	x0, #0x1                ; =1
    5254:      	lsr	w0, w0, #0
    5258:      	sxtw	x0, w0
    525c:      	and	x0, x0, #0xffffffff
    5260:      	mov	x1, x0
    5264:      	movz	x0, #0x0, lsl #48
    5268:      	movz	x2, #0x0, lsl #48
    526c:      	b	0x4fe4 <_stogir.atomic.validate+0x2b8>
    5270:      	mov	x1, x28
    5274:      	mov	x0, #0x1                ; =1
    5278:      	cmp	x0, #0x0
    527c:      	b.eq	0x5294 <_stogir.atomic.validate+0x568>
    5280:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005280:  ARM64_RELOC_PAGE21	l_stogir.373
    5284:      	ldr	x16, [x16]
		0000000000005284:  ARM64_RELOC_PAGEOFF12	l_stogir.373
    5288:      	orr	x0, x16, xzr
    528c:      	mov	x1, #0x1b               ; =27
    5290:      	b	0x529c <_stogir.atomic.validate+0x570>
    5294:      	mov	x0, x1
    5298:      	mov	x1, x27
    529c:      	cmp	x21, #0x7f
    52a0:      	b.ne	0x538c <_stogir.atomic.validate+0x660>
    52a4:      	uxtb	w16, w23
    52a8:      	cmp	w16, wzr
    52ac:      	b.eq	0x54c4 <_stogir.atomic.validate+0x798>
    52b0:      	mov	x2, x0
    52b4:      	movz	x0, #0x0, lsl #48
    52b8:      	b	0x54cc <_stogir.atomic.validate+0x7a0>
    52bc:      	mov	x2, x0
    52c0:      	mov	x0, #0x1                ; =1
    52c4:      	cmp	x0, #0x0
    52c8:      	b.eq	0x50b8 <_stogir.atomic.validate+0x38c>
    52cc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000052cc:  ARM64_RELOC_PAGE21	l_stogir.374
    52d0:      	ldr	x16, [x16]
		00000000000052d0:  ARM64_RELOC_PAGEOFF12	l_stogir.374
    52d4:      	orr	x0, x16, xzr
    52d8:      	mov	x1, #0x19               ; =25
    52dc:      	b	0x50bc <_stogir.atomic.validate+0x390>
    52e0:      	mov	x1, x3
    52e4:      	movz	x0, #0x0, lsl #48
    52e8:      	uxtb	w0, w0
    52ec:      	and	x0, x0, #0x4
    52f0:      	uxtb	w0, w0
    52f4:      	cmp	x0, #0x0
    52f8:      	cset	w0, eq
    52fc:      	uxtb	w16, w0
    5300:      	cmp	w16, wzr
    5304:      	cset	x0, eq
    5308:      	mov	x2, x23
    530c:      	cmp	x0, #0x0
    5310:      	b.eq	0x5070 <_stogir.atomic.validate+0x344>
    5314:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005314:  ARM64_RELOC_PAGE21	l_stogir.375
    5318:      	ldr	x16, [x16]
		0000000000005318:  ARM64_RELOC_PAGEOFF12	l_stogir.375
    531c:      	orr	x0, x16, xzr
    5320:      	mov	x1, #0x16               ; =22
    5324:      	b	0x5078 <_stogir.atomic.validate+0x34c>
    5328:      	uxtb	w0, w0
    532c:      	cmp	x0, #0x83
    5330:      	cset	w1, lt
    5334:      	ubfx	x1, x1, #0, #8
    5338:      	cmp	x1, #0x0
    533c:      	cset	w1, ne
    5340:      	uxtb	w16, w1
    5344:      	cmp	w16, wzr
    5348:      	b.eq	0x55a4 <_stogir.atomic.validate+0x878>
    534c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		000000000000534c:  ARM64_RELOC_PAGE21	l_stogir.376
    5350:      	ldr	x16, [x16]
		0000000000005350:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    5354:      	orr	x2, x16, xzr
    5358:      	add	x2, x0, x2
    535c:      	ldrb	w2, [x2]
    5360:      	mov	x3, x22
    5364:      	b	0x55ac <_stogir.atomic.validate+0x880>
    5368:      	add	x16, sp, #0x60
    536c:      	ldr	x0, [x16, #0x8]
    5370:      	lsr	w0, w0, #0
    5374:      	ubfx	x0, x0, #8, #8
    5378:      	mov	x1, x23
    537c:      	mov	x2, x27
    5380:      	mov	x19, x0
    5384:      	mov	x0, x1
    5388:      	mov	x1, x2
    538c:      	cmp	x19, #0x2
    5390:      	b.ge	0x5438 <_stogir.atomic.validate+0x70c>
    5394:      	mov	x2, x1
    5398:      	mov	x1, x0
    539c:      	mov	x0, #0x1                ; =1
    53a0:      	b	0x5454 <_stogir.atomic.validate+0x728>
    53a4:      	mov	x1, x27
    53a8:      	mov	x2, x23
    53ac:      	movz	x0, #0x0, lsl #48
    53b0:      	cmp	x0, #0x0
    53b4:      	b.eq	0x521c <_stogir.atomic.validate+0x4f0>
    53b8:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000053b8:  ARM64_RELOC_PAGE21	l_stogir.377
    53bc:      	ldr	x16, [x16]
		00000000000053bc:  ARM64_RELOC_PAGEOFF12	l_stogir.377
    53c0:      	orr	x0, x16, xzr
    53c4:      	mov	x1, #0x22               ; =34
    53c8:      	b	0x5224 <_stogir.atomic.validate+0x4f8>
    53cc:      	mov	x1, x27
    53d0:      	mov	x0, #0x1                ; =1
    53d4:      	mov	x2, x23
    53d8:      	b	0x53b0 <_stogir.atomic.validate+0x684>
    53dc:      	mov	x27, x0
    53e0:      	mov	x0, #0x1                ; =1
    53e4:      	cmp	x0, #0x0
    53e8:      	b.eq	0x53a4 <_stogir.atomic.validate+0x678>
    53ec:      	lsr	w0, w19, #0
    53f0:      	add	x16, sp, #0x20
    53f4:      	ldr	w1, [x16, #0xc]
    53f8:      	lsr	w1, w1, #0
    53fc:      	mov	w2, w0
    5400:      	mov	x0, x25
    5404:      	bl	0x5404 <_stogir.atomic.validate+0x6d8>
		0000000000005404:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5408:      	cmp	x0, #0x0
    540c:      	b.eq	0x53cc <_stogir.atomic.validate+0x6a0>
    5410:      	mov	x1, x27
    5414:      	movz	x0, #0x0, lsl #48
    5418:      	b	0x53d4 <_stogir.atomic.validate+0x6a8>
    541c:      	mov	x0, x1
    5420:      	mov	x23, x2
    5424:      	cmp	x21, #0x7e
    5428:      	b.ne	0x53dc <_stogir.atomic.validate+0x6b0>
    542c:      	mov	x27, x0
    5430:      	movz	x0, #0x0, lsl #48
    5434:      	b	0x53e4 <_stogir.atomic.validate+0x6b8>
    5438:      	cmp	x19, #0x5
    543c:      	cset	w2, gt
    5440:      	ubfx	x2, x2, #0, #8
    5444:      	fmov	d31, x0
    5448:      	mov	x0, x2
    544c:      	mov	x2, x1
    5450:      	fmov	x1, d31
    5454:      	cmp	x0, #0x0
    5458:      	b.eq	0x541c <_stogir.atomic.validate+0x6f0>
    545c:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		000000000000545c:  ARM64_RELOC_PAGE21	l_stogir.378
    5460:      	ldr	x16, [x16]
		0000000000005460:  ARM64_RELOC_PAGEOFF12	l_stogir.378
    5464:      	orr	x0, x16, xzr
    5468:      	mov	x23, #0x25              ; =37
    546c:      	b	0x5424 <_stogir.atomic.validate+0x6f8>
    5470:      	uxtb	w16, w22
    5474:      	cmp	w16, wzr
    5478:      	b.eq	0x54b0 <_stogir.atomic.validate+0x784>
    547c:      	movz	x0, #0x0, lsl #48
    5480:      	b	0x525c <_stogir.atomic.validate+0x530>
    5484:      	lsr	w1, w1, #0
    5488:      	uxtb	w16, w19
    548c:      	cmp	w16, wzr
    5490:      	b.eq	0x55f8 <_stogir.atomic.validate+0x8cc>
    5494:      	sxtw	x1, w1
    5498:      	cmp	x1, #0x0
    549c:      	b.ge	0x56a4 <_stogir.atomic.validate+0x978>
    54a0:      	mov	x1, x21
    54a4:      	mov	x2, x23
    54a8:      	mov	x0, #0x1                ; =1
    54ac:      	b	0x56b8 <_stogir.atomic.validate+0x98c>
    54b0:      	sxtw	x27, w27
    54b4:      	cmp	x27, #0x0
    54b8:      	b.ne	0x561c <_stogir.atomic.validate+0x8f0>
    54bc:      	movz	x0, #0x0, lsl #48
    54c0:      	b	0x5254 <_stogir.atomic.validate+0x528>
    54c4:      	mov	x2, x0
    54c8:      	mov	x0, #0x1                ; =1
    54cc:      	cmp	x0, #0x0
    54d0:      	b.eq	0x54ec <_stogir.atomic.validate+0x7c0>
    54d4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000054d4:  ARM64_RELOC_PAGE21	l_stogir.379
    54d8:      	ldr	x16, [x16]
		00000000000054d8:  ARM64_RELOC_PAGEOFF12	l_stogir.379
    54dc:      	orr	x0, x16, xzr
    54e0:      	mov	x23, x0
    54e4:      	mov	x27, #0x19              ; =25
    54e8:      	b	0x54f4 <_stogir.atomic.validate+0x7c8>
    54ec:      	mov	x23, x2
    54f0:      	mov	x27, x1
    54f4:      	add	x16, sp, #0x20
    54f8:      	ldr	w0, [x16, #0xc]
    54fc:      	lsr	w0, w0, #0
    5500:      	add	x8, sp, #0x60
    5504:      	mov	w1, w0
    5508:      	mov	x0, x25
    550c:      	bl	0x550c <_stogir.atomic.validate+0x7e0>
		000000000000550c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    5510:      	add	x16, sp, #0x60
    5514:      	ldr	w0, [x16]
    5518:      	lsr	x16, x0, #0
    551c:      	cmp	x16, #0x1
    5520:      	b.eq	0x553c <_stogir.atomic.validate+0x810>
    5524:      	b.lo	0x552c <_stogir.atomic.validate+0x800>
    5528:      	b	0x5540 <_stogir.atomic.validate+0x814>
    552c:      	cmp	x16, #0x0
    5530:      	b.eq	0x5538 <_stogir.atomic.validate+0x80c>
    5534:      	b	0x5540 <_stogir.atomic.validate+0x814>
    5538:      	b	0x5544 <_stogir.atomic.validate+0x818>
    553c:      	b	0x5368 <_stogir.atomic.validate+0x63c>
    5540:      	b	0x56ec <_stogir.atomic.validate+0x9c0>
    5544:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005544:  ARM64_RELOC_PAGE21	l_stogir.380
    5548:      	ldr	x16, [x16]
		0000000000005548:  ARM64_RELOC_PAGEOFF12	l_stogir.380
    554c:      	orr	x0, x16, xzr
    5550:      	mov	x1, x0
    5554:      	mov	x0, x19
    5558:      	mov	x2, #0x1a               ; =26
    555c:      	b	0x5380 <_stogir.atomic.validate+0x654>
    5560:      	mov	x2, #0x1                ; =1
    5564:      	cmp	x2, #0x0
    5568:      	b.eq	0x557c <_stogir.atomic.validate+0x850>
    556c:      	mov	x1, x3
    5570:      	mov	x2, x23
    5574:      	mov	x0, #0x1                ; =1
    5578:      	b	0x530c <_stogir.atomic.validate+0x5e0>
    557c:      	uxtb	w16, w1
    5580:      	cmp	w16, wzr
    5584:      	b.eq	0x52e0 <_stogir.atomic.validate+0x5b4>
    5588:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005588:  ARM64_RELOC_PAGE21	l_stogir.376
    558c:      	ldr	x16, [x16]
		000000000000558c:  ARM64_RELOC_PAGEOFF12	l_stogir.376
    5590:      	orr	x1, x16, xzr
    5594:      	add	x0, x0, x1
    5598:      	ldrb	w0, [x0]
    559c:      	mov	x1, x3
    55a0:      	b	0x52e8 <_stogir.atomic.validate+0x5bc>
    55a4:      	mov	x3, x22
    55a8:      	movz	x2, #0x0, lsl #48
    55ac:      	uxtb	w2, w2
    55b0:      	and	x2, x2, #0x1
    55b4:      	uxtb	w2, w2
    55b8:      	cmp	x2, #0x0
    55bc:      	b.eq	0x5560 <_stogir.atomic.validate+0x834>
    55c0:      	movz	x2, #0x0, lsl #48
    55c4:      	b	0x5564 <_stogir.atomic.validate+0x838>
    55c8:      	mov	x3, #-0x2               ; =-2
    55cc:      	sxtw	x2, w2
    55d0:      	lsr	w3, w3, #0
    55d4:      	sxtw	x3, w3
    55d8:      	cmp	x2, x3
    55dc:      	b.ne	0x4fe8 <_stogir.atomic.validate+0x2bc>
    55e0:      	mov	x22, x20
    55e4:      	movz	x23, #0x0, lsl #48
    55e8:      	b	0x4ffc <_stogir.atomic.validate+0x2d0>
    55ec:      	mov	x0, x1
    55f0:      	mov	x1, x2
    55f4:      	b	0x5244 <_stogir.atomic.validate+0x518>
    55f8:      	lsr	w1, w1, #0
    55fc:      	mov	x0, x25
    5600:      	mov	w2, w27
    5604:      	bl	0x5604 <_stogir.atomic.validate+0x8d8>
		0000000000005604:  ARM64_RELOC_BRANCH26	_stogir.atomic.ordinary?
    5608:      	cmp	x0, #0x0
    560c:      	b.eq	0x5234 <_stogir.atomic.validate+0x508>
    5610:      	mov	x0, x21
    5614:      	mov	x1, x23
    5618:      	b	0x5244 <_stogir.atomic.validate+0x518>
    561c:      	cmp	x27, #0x1
    5620:      	b.eq	0x5250 <_stogir.atomic.validate+0x524>
    5624:      	cmp	x27, #0x2
    5628:      	b.eq	0x5250 <_stogir.atomic.validate+0x524>
    562c:      	cmp	x27, #0x7
    5630:      	b.eq	0x5250 <_stogir.atomic.validate+0x524>
    5634:      	cmp	x27, #0x8
    5638:      	b.eq	0x5250 <_stogir.atomic.validate+0x524>
    563c:      	cmp	x27, #0x3
    5640:      	b.eq	0x56dc <_stogir.atomic.validate+0x9b0>
    5644:      	cmp	x27, #0x9
    5648:      	b.eq	0x56dc <_stogir.atomic.validate+0x9b0>
    564c:      	cmp	x27, #0x4
    5650:      	b.eq	0x56f4 <_stogir.atomic.validate+0x9c8>
    5654:      	cmp	x27, #0xa
    5658:      	b.eq	0x56f4 <_stogir.atomic.validate+0x9c8>
    565c:      	cmp	x27, #0xd
    5660:      	b.eq	0x56f4 <_stogir.atomic.validate+0x9c8>
    5664:      	cmp	x27, #0x5
    5668:      	b.eq	0x56fc <_stogir.atomic.validate+0x9d0>
    566c:      	cmp	x27, #0xb
    5670:      	b.eq	0x56fc <_stogir.atomic.validate+0x9d0>
    5674:      	cmp	x27, #0xc
    5678:      	b.eq	0x56fc <_stogir.atomic.validate+0x9d0>
    567c:      	cmp	x27, #0x6
    5680:      	cset	w0, eq
    5684:      	uxtb	w16, w0
    5688:      	cmp	w16, wzr
    568c:      	mov	x16, #0x8               ; =8
    5690:      	movn	x17, #0x0, lsl #48
    5694:      	csel	x0, x16, x17, ne
    5698:      	b	0x5700 <_stogir.atomic.validate+0x9d4>
    569c:      	brk	#0
    56a0:      	b	0x569c <_stogir.atomic.validate+0x970>
    56a4:      	cmp	x1, #0x9
    56a8:      	cset	w0, gt
    56ac:      	ubfx	x0, x0, #0, #8
    56b0:      	mov	x1, x21
    56b4:      	mov	x2, x23
    56b8:      	cmp	x0, #0x0
    56bc:      	b.eq	0x55ec <_stogir.atomic.validate+0x8c0>
    56c0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000056c0:  ARM64_RELOC_PAGE21	l_stogir.381
    56c4:      	ldr	x16, [x16]
		00000000000056c4:  ARM64_RELOC_PAGEOFF12	l_stogir.381
    56c8:      	orr	x0, x16, xzr
    56cc:      	mov	x1, #0x1c               ; =28
    56d0:      	b	0x55f4 <_stogir.atomic.validate+0x8c8>
    56d4:      	brk	#0
    56d8:      	b	0x56d4 <_stogir.atomic.validate+0x9a8>
    56dc:      	mov	x0, #0x2                ; =2
    56e0:      	b	0x5254 <_stogir.atomic.validate+0x528>
    56e4:      	brk	#0
    56e8:      	b	0x56e4 <_stogir.atomic.validate+0x9b8>
    56ec:      	brk	#0
    56f0:      	b	0x56ec <_stogir.atomic.validate+0x9c0>
    56f4:      	mov	x0, #0x4                ; =4
    56f8:      	b	0x56e0 <_stogir.atomic.validate+0x9b4>
    56fc:      	mov	x0, #0x8                ; =8
    5700:      	b	0x56f8 <_stogir.atomic.validate+0x9cc>

0000000000005704 <_stogir.terminal.operation?>:
    5704:      	sxtw	x0, w0
    5708:      	cmp	x0, #0x60
    570c:      	b.ne	0x5718 <_stogir.terminal.operation?+0x14>
    5710:      	mov	x0, #0x1                ; =1
    5714:      	b	0x5724 <_stogir.terminal.operation?+0x20>
    5718:      	cmp	x0, #0x79
    571c:      	cset	w0, eq
    5720:      	ubfx	x0, x0, #0, #8
    5724:      	ret

0000000000005728 <_stogir.terminal.validate>:
    5728:      	sub	sp, sp, #0x50
    572c:      	str	x29, [sp]
    5730:      	str	x30, [sp, #0x8]
    5734:      	mov	x29, sp
    5738:      	str	x19, [sp, #0x40]
    573c:      	sxtw	x1, w1
    5740:      	lsl	x2, x1, #2
    5744:      	cmp	x1, #0x0
    5748:      	cset	w3, gt
    574c:      	movz	x16, #0x0, lsl #48
    5750:      	sub	x4, x16, x1
    5754:      	sub	x5, x4, #0x1
    5758:      	uxtb	w16, w3
    575c:      	cmp	w16, wzr
    5760:      	b.eq	0x57a0 <_stogir.terminal.validate+0x78>
    5764:      	ldr	x4, [x0, #0x8]
    5768:      	cmp	x1, x4
    576c:      	b.ge	0x57f4 <_stogir.terminal.validate+0xcc>
    5770:      	add	x4, x0, #0x78
    5774:      	ldr	x4, [x4, #0x8]
    5778:      	cmp	x1, x4
    577c:      	b.ge	0x5918 <_stogir.terminal.validate+0x1f0>
    5780:      	ldr	x4, [x0, #0x78]
    5784:      	add	x4, x2, x4
    5788:      	ldr	w4, [x4]
    578c:      	sxtw	x4, w4
    5790:      	cmp	x4, #0x0
    5794:      	cset	w4, ge
    5798:      	ubfx	x4, x4, #0, #8
    579c:      	b	0x591c <_stogir.terminal.validate+0x1f4>
    57a0:      	cmp	x1, #0x0
    57a4:      	b.ge	0x57fc <_stogir.terminal.validate+0xd4>
    57a8:      	add	x6, x0, #0x28
    57ac:      	add	x7, x0, #0x50
    57b0:      	ldr	x6, [x6, #0x8]
    57b4:      	ldr	x7, [x7, #0x8]
    57b8:      	cmp	x6, x7
    57bc:      	b.ne	0x57ec <_stogir.terminal.validate+0xc4>
    57c0:      	cmp	x4, x6
    57c4:      	b.gt	0x5958 <_stogir.terminal.validate+0x230>
    57c8:      	lsl	x4, x5, #2
    57cc:      	ldr	x6, [x0, #0x50]
    57d0:      	add	x4, x4, x6
    57d4:      	ldr	w4, [x4]
    57d8:      	sxtw	x4, w4
    57dc:      	cmp	x4, #0x0
    57e0:      	cset	w4, gt
    57e4:      	ubfx	x4, x4, #0, #8
    57e8:      	b	0x595c <_stogir.terminal.validate+0x234>
    57ec:      	movz	x4, #0x0, lsl #48
    57f0:      	b	0x5800 <_stogir.terminal.validate+0xd8>
    57f4:      	movz	x4, #0x0, lsl #48
    57f8:      	b	0x5800 <_stogir.terminal.validate+0xd8>
    57fc:      	movz	x4, #0x0, lsl #48
    5800:      	cmp	x4, #0x0
    5804:      	b.eq	0x5868 <_stogir.terminal.validate+0x140>
    5808:      	uxtb	w16, w3
    580c:      	cmp	w16, wzr
    5810:      	b.eq	0x5838 <_stogir.terminal.validate+0x110>
    5814:      	lsl	x3, x1, #4
    5818:      	ldr	x4, [x0]
    581c:      	add	x3, x3, x4
    5820:      	ldr	x4, [x3]
    5824:      	ldr	x3, [x3, #0x8]
    5828:      	fmov	d31, x3
    582c:      	mov	x3, x4
    5830:      	fmov	x4, d31
    5834:      	b	0x5858 <_stogir.terminal.validate+0x130>
    5838:      	lsl	x3, x5, #4
    583c:      	ldr	x4, [x0, #0x28]
    5840:      	add	x3, x3, x4
    5844:      	ldr	x4, [x3]
    5848:      	ldr	x3, [x3, #0x8]
    584c:      	fmov	d31, x3
    5850:      	mov	x3, x4
    5854:      	fmov	x4, d31
    5858:      	mov	x5, x4
    585c:      	mov	x4, x3
    5860:      	mov	x3, #0x1                ; =1
    5864:      	b	0x5874 <_stogir.terminal.validate+0x14c>
    5868:      	movz	x3, #0x0, lsl #48
    586c:      	movz	x4, #0x0, lsl #48
    5870:      	movz	x5, #0x0, lsl #48
    5874:      	lsr	w3, w3, #0
    5878:      	lsr	x16, x3, #0
    587c:      	cmp	x16, #0x1
    5880:      	b.eq	0x589c <_stogir.terminal.validate+0x174>
    5884:      	b.lo	0x588c <_stogir.terminal.validate+0x164>
    5888:      	b	0x58a0 <_stogir.terminal.validate+0x178>
    588c:      	cmp	x16, #0x0
    5890:      	b.eq	0x5898 <_stogir.terminal.validate+0x170>
    5894:      	b	0x58a0 <_stogir.terminal.validate+0x178>
    5898:      	b	0x58a4 <_stogir.terminal.validate+0x17c>
    589c:      	b	0x58c4 <_stogir.terminal.validate+0x19c>
    58a0:      	b	0x5a34 <_stogir.terminal.validate+0x30c>
    58a4:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000058a4:  ARM64_RELOC_PAGE21	l_stogir.382
    58a8:      	ldr	x16, [x16]
		00000000000058a8:  ARM64_RELOC_PAGEOFF12	l_stogir.382
    58ac:      	orr	x0, x16, xzr
    58b0:      	mov	x19, x8
    58b4:      	mov	x1, x0
    58b8:      	mov	x0, #0x1                ; =1
    58bc:      	mov	x2, #0x21               ; =33
    58c0:      	b	0x58f8 <_stogir.terminal.validate+0x1d0>
    58c4:      	add	x16, sp, #0x10
    58c8:      	str	x4, [x16]
    58cc:      	add	x16, sp, #0x10
    58d0:      	str	x5, [x16, #0x8]
    58d4:      	cmp	x1, #0x0
    58d8:      	b.gt	0x5920 <_stogir.terminal.validate+0x1f8>
    58dc:      	mov	x19, x8
    58e0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		00000000000058e0:  ARM64_RELOC_PAGE21	l_stogir.383
    58e4:      	ldr	x16, [x16]
		00000000000058e4:  ARM64_RELOC_PAGEOFF12	l_stogir.383
    58e8:      	orr	x0, x16, xzr
    58ec:      	mov	x1, x0
    58f0:      	mov	x0, #0x1                ; =1
    58f4:      	mov	x2, #0x1b               ; =27
    58f8:      	str	x0, [x19]
    58fc:      	str	x1, [x19, #0x8]
    5900:      	str	x2, [x19, #0x10]
    5904:      	ldr	x19, [sp, #0x40]
    5908:      	ldr	x29, [sp]
    590c:      	ldr	x30, [sp, #0x8]
    5910:      	add	sp, sp, #0x50
    5914:      	ret
    5918:      	movz	x4, #0x0, lsl #48
    591c:      	b	0x57f8 <_stogir.terminal.validate+0xd0>
    5920:      	uxtb	w4, w4
    5924:      	orr	x1, x4, xzr
    5928:      	cmp	x1, #0x60
    592c:      	cset	w3, eq
    5930:      	cmp	x1, #0x79
    5934:      	cset	w1, eq
    5938:      	uxtb	w16, w3
    593c:      	cmp	w16, wzr
    5940:      	b.ne	0x5960 <_stogir.terminal.validate+0x238>
    5944:      	uxtb	w16, w1
    5948:      	cmp	w16, wzr
    594c:      	b.ne	0x5960 <_stogir.terminal.validate+0x238>
    5950:      	mov	x19, x8
    5954:      	b	0x58e0 <_stogir.terminal.validate+0x1b8>
    5958:      	movz	x4, #0x0, lsl #48
    595c:      	b	0x57f0 <_stogir.terminal.validate+0xc8>
    5960:      	add	x16, sp, #0x10
    5964:      	ldr	w5, [x16]
    5968:      	ubfx	x5, x5, #8, #8
    596c:      	cmp	x5, #0x0
    5970:      	b.ne	0x5a3c <_stogir.terminal.validate+0x314>
    5974:      	uxtb	w16, w3
    5978:      	cmp	w16, wzr
    597c:      	mov	x16, #0x1               ; =1
    5980:      	mov	x17, #0x3               ; =3
    5984:      	csel	x3, x16, x17, ne
    5988:      	lsr	w3, w3, #0
    598c:      	sxtw	x3, w3
    5990:      	ldr	x5, [x0, #0x78]
    5994:      	add	x2, x2, x5
    5998:      	ldr	w2, [x2]
    599c:      	sxtw	x2, w2
    59a0:      	cmp	x2, x3
    59a4:      	b.ne	0x5a44 <_stogir.terminal.validate+0x31c>
    59a8:      	uxtb	w16, w1
    59ac:      	cmp	w16, wzr
    59b0:      	b.eq	0x5a10 <_stogir.terminal.validate+0x2e8>
    59b4:      	add	x16, sp, #0x10
    59b8:      	ldr	w2, [x16, #0x8]
    59bc:      	sxtw	x2, w2
    59c0:      	cmp	x2, #0x0
    59c4:      	b.eq	0x5a10 <_stogir.terminal.validate+0x2e8>
    59c8:      	mov	x19, x8
    59cc:      	b	0x58e0 <_stogir.terminal.validate+0x1b8>
    59d0:      	movz	x1, #0x0, lsl #48
    59d4:      	lsr	w2, w2, #0
    59d8:      	lsr	w4, w4, #0
    59dc:      	lsr	w1, w1, #0
    59e0:      	mov	w3, w1
    59e4:      	mov	w1, w4
    59e8:      	mov	x19, x8
    59ec:      	add	x8, sp, #0x20
    59f0:      	bl	0x59f0 <_stogir.terminal.validate+0x2c8>
		00000000000059f0:  ARM64_RELOC_BRANCH26	_stogir.terminal.inputs
    59f4:      	add	x16, sp, #0x20
    59f8:      	ldr	x0, [x16]
    59fc:      	add	x16, sp, #0x20
    5a00:      	ldr	x1, [x16, #0x8]
    5a04:      	add	x16, sp, #0x20
    5a08:      	ldr	x2, [x16, #0x10]
    5a0c:      	b	0x58f8 <_stogir.terminal.validate+0x1d0>
    5a10:      	add	x16, sp, #0x10
    5a14:      	ldr	w2, [x16, #0x4]
    5a18:      	uxtb	w16, w1
    5a1c:      	cmp	w16, wzr
    5a20:      	b.eq	0x59d0 <_stogir.terminal.validate+0x2a8>
    5a24:      	add	x16, sp, #0x10
    5a28:      	ldr	w1, [x16, #0xc]
    5a2c:      	sxtw	x1, w1
    5a30:      	b	0x59d4 <_stogir.terminal.validate+0x2ac>
    5a34:      	brk	#0
    5a38:      	b	0x5a34 <_stogir.terminal.validate+0x30c>
    5a3c:      	mov	x19, x8
    5a40:      	b	0x58e0 <_stogir.terminal.validate+0x1b8>
    5a44:      	mov	x19, x8
    5a48:      	b	0x58e0 <_stogir.terminal.validate+0x1b8>

0000000000005a4c <_stogir.switch.operation?>:
    5a4c:      	sxtw	x0, w0
    5a50:      	cmp	x0, #0x75
    5a54:      	b.ne	0x5a68 <_stogir.switch.operation?+0x1c>
    5a58:      	mov	x0, #0x1                ; =1
    5a5c:      	b	0x5a64 <_stogir.switch.operation?+0x18>
    5a60:      	movz	x0, #0x0, lsl #48
    5a64:      	ret
    5a68:      	cmp	x0, #0x6d
    5a6c:      	b.lt	0x5a60 <_stogir.switch.operation?+0x14>
    5a70:      	cmp	x0, #0x6f
    5a74:      	cset	w0, le
    5a78:      	ubfx	x0, x0, #0, #8
    5a7c:      	b	0x5a64 <_stogir.switch.operation?+0x18>

0000000000005a80 <_stogir.switch.validate>:
    5a80:      	sub	sp, sp, #0x70
    5a84:      	str	x29, [sp]
    5a88:      	str	x30, [sp, #0x8]
    5a8c:      	mov	x29, sp
    5a90:      	str	x19, [sp, #0x60]
    5a94:      	sxtw	x1, w1
    5a98:      	lsl	x2, x1, #2
    5a9c:      	cmp	x1, #0x0
    5aa0:      	cset	w3, gt
    5aa4:      	movz	x16, #0x0, lsl #48
    5aa8:      	sub	x4, x16, x1
    5aac:      	sub	x5, x4, #0x1
    5ab0:      	uxtb	w16, w3
    5ab4:      	cmp	w16, wzr
    5ab8:      	b.eq	0x5af8 <_stogir.switch.validate+0x78>
    5abc:      	ldr	x4, [x0, #0x8]
    5ac0:      	cmp	x1, x4
    5ac4:      	b.ge	0x5b4c <_stogir.switch.validate+0xcc>
    5ac8:      	add	x4, x0, #0x78
    5acc:      	ldr	x4, [x4, #0x8]
    5ad0:      	cmp	x1, x4
    5ad4:      	b.ge	0x5c70 <_stogir.switch.validate+0x1f0>
    5ad8:      	ldr	x4, [x0, #0x78]
    5adc:      	add	x4, x2, x4
    5ae0:      	ldr	w4, [x4]
    5ae4:      	sxtw	x4, w4
    5ae8:      	cmp	x4, #0x0
    5aec:      	cset	w4, ge
    5af0:      	ubfx	x4, x4, #0, #8
    5af4:      	b	0x5c74 <_stogir.switch.validate+0x1f4>
    5af8:      	cmp	x1, #0x0
    5afc:      	b.ge	0x5b54 <_stogir.switch.validate+0xd4>
    5b00:      	add	x6, x0, #0x28
    5b04:      	add	x7, x0, #0x50
    5b08:      	ldr	x6, [x6, #0x8]
    5b0c:      	ldr	x7, [x7, #0x8]
    5b10:      	cmp	x6, x7
    5b14:      	b.ne	0x5b44 <_stogir.switch.validate+0xc4>
    5b18:      	cmp	x4, x6
    5b1c:      	b.gt	0x5cac <_stogir.switch.validate+0x22c>
    5b20:      	lsl	x4, x5, #2
    5b24:      	ldr	x6, [x0, #0x50]
    5b28:      	add	x4, x4, x6
    5b2c:      	ldr	w4, [x4]
    5b30:      	sxtw	x4, w4
    5b34:      	cmp	x4, #0x0
    5b38:      	cset	w4, gt
    5b3c:      	ubfx	x4, x4, #0, #8
    5b40:      	b	0x5cb0 <_stogir.switch.validate+0x230>
    5b44:      	movz	x4, #0x0, lsl #48
    5b48:      	b	0x5b58 <_stogir.switch.validate+0xd8>
    5b4c:      	movz	x4, #0x0, lsl #48
    5b50:      	b	0x5b58 <_stogir.switch.validate+0xd8>
    5b54:      	movz	x4, #0x0, lsl #48
    5b58:      	cmp	x4, #0x0
    5b5c:      	b.eq	0x5bc0 <_stogir.switch.validate+0x140>
    5b60:      	uxtb	w16, w3
    5b64:      	cmp	w16, wzr
    5b68:      	b.eq	0x5b90 <_stogir.switch.validate+0x110>
    5b6c:      	lsl	x3, x1, #4
    5b70:      	ldr	x4, [x0]
    5b74:      	add	x3, x3, x4
    5b78:      	ldr	x4, [x3]
    5b7c:      	ldr	x3, [x3, #0x8]
    5b80:      	fmov	d31, x3
    5b84:      	mov	x3, x4
    5b88:      	fmov	x4, d31
    5b8c:      	b	0x5bb0 <_stogir.switch.validate+0x130>
    5b90:      	lsl	x3, x5, #4
    5b94:      	ldr	x4, [x0, #0x28]
    5b98:      	add	x3, x3, x4
    5b9c:      	ldr	x4, [x3]
    5ba0:      	ldr	x3, [x3, #0x8]
    5ba4:      	fmov	d31, x3
    5ba8:      	mov	x3, x4
    5bac:      	fmov	x4, d31
    5bb0:      	mov	x5, x4
    5bb4:      	mov	x4, x3
    5bb8:      	mov	x3, #0x1                ; =1
    5bbc:      	b	0x5bcc <_stogir.switch.validate+0x14c>
    5bc0:      	movz	x3, #0x0, lsl #48
    5bc4:      	movz	x4, #0x0, lsl #48
    5bc8:      	movz	x5, #0x0, lsl #48
    5bcc:      	lsr	w3, w3, #0
    5bd0:      	lsr	x16, x3, #0
    5bd4:      	cmp	x16, #0x1
    5bd8:      	b.eq	0x5bf4 <_stogir.switch.validate+0x174>
    5bdc:      	b.lo	0x5be4 <_stogir.switch.validate+0x164>
    5be0:      	b	0x5bf8 <_stogir.switch.validate+0x178>
    5be4:      	cmp	x16, #0x0
    5be8:      	b.eq	0x5bf0 <_stogir.switch.validate+0x170>
    5bec:      	b	0x5bf8 <_stogir.switch.validate+0x178>
    5bf0:      	b	0x5bfc <_stogir.switch.validate+0x17c>
    5bf4:      	b	0x5c1c <_stogir.switch.validate+0x19c>
    5bf8:      	b	0x5db0 <_stogir.switch.validate+0x330>
    5bfc:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005bfc:  ARM64_RELOC_PAGE21	l_stogir.384
    5c00:      	ldr	x16, [x16]
		0000000000005c00:  ARM64_RELOC_PAGEOFF12	l_stogir.384
    5c04:      	orr	x0, x16, xzr
    5c08:      	mov	x19, x8
    5c0c:      	mov	x1, x0
    5c10:      	mov	x0, #0x1                ; =1
    5c14:      	mov	x2, #0x1a               ; =26
    5c18:      	b	0x5c50 <_stogir.switch.validate+0x1d0>
    5c1c:      	add	x16, sp, #0x10
    5c20:      	str	x4, [x16]
    5c24:      	add	x16, sp, #0x10
    5c28:      	str	x5, [x16, #0x8]
    5c2c:      	cmp	x1, #0x0
    5c30:      	b.gt	0x5c78 <_stogir.switch.validate+0x1f8>
    5c34:      	mov	x19, x8
    5c38:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005c38:  ARM64_RELOC_PAGE21	l_stogir.385
    5c3c:      	ldr	x16, [x16]
		0000000000005c3c:  ARM64_RELOC_PAGEOFF12	l_stogir.385
    5c40:      	orr	x0, x16, xzr
    5c44:      	mov	x1, x0
    5c48:      	mov	x0, #0x1                ; =1
    5c4c:      	mov	x2, #0x20               ; =32
    5c50:      	str	x0, [x19]
    5c54:      	str	x1, [x19, #0x8]
    5c58:      	str	x2, [x19, #0x10]
    5c5c:      	ldr	x19, [sp, #0x60]
    5c60:      	ldr	x29, [sp]
    5c64:      	ldr	x30, [sp, #0x8]
    5c68:      	add	sp, sp, #0x70
    5c6c:      	ret
    5c70:      	movz	x4, #0x0, lsl #48
    5c74:      	b	0x5b50 <_stogir.switch.validate+0xd0>
    5c78:      	uxtb	w4, w4
    5c7c:      	orr	x1, x4, xzr
    5c80:      	cmp	x1, #0x75
    5c84:      	cset	w3, eq
    5c88:      	uxtb	w16, w3
    5c8c:      	cmp	w16, wzr
    5c90:      	b.ne	0x5cb4 <_stogir.switch.validate+0x234>
    5c94:      	cmp	x1, #0x6d
    5c98:      	b.lt	0x5db8 <_stogir.switch.validate+0x338>
    5c9c:      	cmp	x1, #0x6f
    5ca0:      	b.le	0x5cb4 <_stogir.switch.validate+0x234>
    5ca4:      	mov	x19, x8
    5ca8:      	b	0x5c38 <_stogir.switch.validate+0x1b8>
    5cac:      	movz	x4, #0x0, lsl #48
    5cb0:      	b	0x5b48 <_stogir.switch.validate+0xc8>
    5cb4:      	add	x16, sp, #0x10
    5cb8:      	ldr	w5, [x16]
    5cbc:      	ubfx	x5, x5, #8, #8
    5cc0:      	cmp	x5, #0x0
    5cc4:      	b.ne	0x5dc0 <_stogir.switch.validate+0x340>
    5cc8:      	ldr	x5, [x0, #0x78]
    5ccc:      	add	x2, x2, x5
    5cd0:      	ldr	w2, [x2]
    5cd4:      	cmp	x1, #0x6d
    5cd8:      	b.eq	0x5d4c <_stogir.switch.validate+0x2cc>
    5cdc:      	cmp	x1, #0x6e
    5ce0:      	b.eq	0x5d4c <_stogir.switch.validate+0x2cc>
    5ce4:      	mov	x1, #0x2                ; =2
    5ce8:      	b	0x5d50 <_stogir.switch.validate+0x2d0>
    5cec:      	lsr	w4, w4, #0
    5cf0:      	add	x16, sp, #0x10
    5cf4:      	ldr	w1, [x16, #0x4]
    5cf8:      	add	x16, sp, #0x10
    5cfc:      	ldr	w2, [x16, #0x8]
    5d00:      	lsr	w1, w1, #0
    5d04:      	add	x16, sp, #0x10
    5d08:      	ldr	w3, [x16, #0xc]
    5d0c:      	lsr	w2, w2, #0
    5d10:      	lsr	w3, w3, #0
    5d14:      	add	x8, sp, #0x40
    5d18:      	fmov	s31, w1
    5d1c:      	mov	w1, w4
    5d20:      	mov	w4, w3
    5d24:      	mov	w3, w2
    5d28:      	fmov	w2, s31
    5d2c:      	bl	0x5d2c <_stogir.switch.validate+0x2ac>
		0000000000005d2c:  ARM64_RELOC_BRANCH26	_stogir.switch.case-inputs
    5d30:      	add	x16, sp, #0x40
    5d34:      	ldr	x0, [x16]
    5d38:      	add	x16, sp, #0x40
    5d3c:      	ldr	x1, [x16, #0x8]
    5d40:      	add	x16, sp, #0x40
    5d44:      	ldr	x2, [x16, #0x10]
    5d48:      	b	0x5c50 <_stogir.switch.validate+0x1d0>
    5d4c:      	mov	x1, #0x3                ; =3
    5d50:      	sxtw	x2, w2
    5d54:      	lsr	w1, w1, #0
    5d58:      	sxtw	x1, w1
    5d5c:      	cmp	x2, x1
    5d60:      	b.ne	0x5dc8 <_stogir.switch.validate+0x348>
    5d64:      	uxtb	w16, w3
    5d68:      	cmp	w16, wzr
    5d6c:      	b.eq	0x5dd0 <_stogir.switch.validate+0x350>
    5d70:      	add	x16, sp, #0x10
    5d74:      	ldr	w1, [x16, #0x4]
    5d78:      	add	x16, sp, #0x10
    5d7c:      	ldr	w2, [x16, #0x8]
    5d80:      	lsr	w1, w1, #0
    5d84:      	lsr	w2, w2, #0
    5d88:      	mov	x19, x8
    5d8c:      	add	x8, sp, #0x20
    5d90:      	bl	0x5d90 <_stogir.switch.validate+0x310>
		0000000000005d90:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    5d94:      	add	x16, sp, #0x20
    5d98:      	ldr	x0, [x16]
    5d9c:      	add	x16, sp, #0x20
    5da0:      	ldr	x1, [x16, #0x8]
    5da4:      	add	x16, sp, #0x20
    5da8:      	ldr	x2, [x16, #0x10]
    5dac:      	b	0x5d48 <_stogir.switch.validate+0x2c8>
    5db0:      	brk	#0
    5db4:      	b	0x5db0 <_stogir.switch.validate+0x330>
    5db8:      	mov	x19, x8
    5dbc:      	b	0x5c38 <_stogir.switch.validate+0x1b8>
    5dc0:      	mov	x19, x8
    5dc4:      	b	0x5c38 <_stogir.switch.validate+0x1b8>
    5dc8:      	mov	x19, x8
    5dcc:      	b	0x5c38 <_stogir.switch.validate+0x1b8>
    5dd0:      	mov	x19, x8
    5dd4:      	b	0x5cec <_stogir.switch.validate+0x26c>

0000000000005dd8 <_stogir.stack.operation?>:
    5dd8:      	sxtw	x0, w0
    5ddc:      	cmp	x0, #0x42
    5de0:      	b.ne	0x5dfc <_stogir.stack.operation?+0x24>
    5de4:      	mov	x0, #0x1                ; =1
    5de8:      	b	0x5df8 <_stogir.stack.operation?+0x20>
    5dec:      	cmp	x0, #0x54
    5df0:      	cset	w0, eq
    5df4:      	ubfx	x0, x0, #0, #8
    5df8:      	ret
    5dfc:      	cmp	x0, #0x51
    5e00:      	b.ne	0x5e0c <_stogir.stack.operation?+0x34>
    5e04:      	mov	x0, #0x1                ; =1
    5e08:      	b	0x5df8 <_stogir.stack.operation?+0x20>
    5e0c:      	cmp	x0, #0x52
    5e10:      	b.ne	0x5e1c <_stogir.stack.operation?+0x44>
    5e14:      	mov	x0, #0x1                ; =1
    5e18:      	b	0x5df8 <_stogir.stack.operation?+0x20>
    5e1c:      	cmp	x0, #0x53
    5e20:      	b.ne	0x5dec <_stogir.stack.operation?+0x14>
    5e24:      	mov	x0, #0x1                ; =1
    5e28:      	b	0x5df8 <_stogir.stack.operation?+0x20>

0000000000005e2c <_stogir.stack.validate>:
    5e2c:      	sub	sp, sp, #0x90
    5e30:      	str	x29, [sp]
    5e34:      	str	x30, [sp, #0x8]
    5e38:      	mov	x29, sp
    5e3c:      	str	x19, [sp, #0x60]
    5e40:      	str	x20, [sp, #0x68]
    5e44:      	str	x21, [sp, #0x70]
    5e48:      	str	x22, [sp, #0x78]
    5e4c:      	str	x23, [sp, #0x80]
    5e50:      	sxtw	x1, w1
    5e54:      	lsl	x2, x1, #2
    5e58:      	cmp	x1, #0x0
    5e5c:      	cset	w3, gt
    5e60:      	movz	x16, #0x0, lsl #48
    5e64:      	sub	x4, x16, x1
    5e68:      	cmp	x1, #0x0
    5e6c:      	cset	w5, lt
    5e70:      	sub	x6, x4, #0x1
    5e74:      	lsl	x7, x6, #2
    5e78:      	uxtb	w16, w3
    5e7c:      	cmp	w16, wzr
    5e80:      	b.eq	0x5ec0 <_stogir.stack.validate+0x94>
    5e84:      	ldr	x9, [x0, #0x8]
    5e88:      	cmp	x1, x9
    5e8c:      	b.ge	0x5f40 <_stogir.stack.validate+0x114>
    5e90:      	add	x9, x0, #0x78
    5e94:      	ldr	x9, [x9, #0x8]
    5e98:      	cmp	x1, x9
    5e9c:      	b.ge	0x60ac <_stogir.stack.validate+0x280>
    5ea0:      	ldr	x9, [x0, #0x78]
    5ea4:      	add	x9, x2, x9
    5ea8:      	ldr	w9, [x9]
    5eac:      	sxtw	x9, w9
    5eb0:      	cmp	x9, #0x0
    5eb4:      	cset	w9, ge
    5eb8:      	ubfx	x9, x9, #0, #8
    5ebc:      	b	0x60b0 <_stogir.stack.validate+0x284>
    5ec0:      	uxtb	w16, w5
    5ec4:      	cmp	w16, wzr
    5ec8:      	b.eq	0x5f48 <_stogir.stack.validate+0x11c>
    5ecc:      	add	x9, x0, #0x28
    5ed0:      	add	x10, x0, #0x50
    5ed4:      	ldr	x9, [x9, #0x8]
    5ed8:      	ldr	x10, [x10, #0x8]
    5edc:      	cmp	x9, x10
    5ee0:      	b.ne	0x5f0c <_stogir.stack.validate+0xe0>
    5ee4:      	cmp	x4, x9
    5ee8:      	b.gt	0x60b4 <_stogir.stack.validate+0x288>
    5eec:      	ldr	x9, [x0, #0x50]
    5ef0:      	add	x9, x7, x9
    5ef4:      	ldr	w9, [x9]
    5ef8:      	sxtw	x9, w9
    5efc:      	cmp	x9, #0x0
    5f00:      	cset	w9, gt
    5f04:      	ubfx	x9, x9, #0, #8
    5f08:      	b	0x60b8 <_stogir.stack.validate+0x28c>
    5f0c:      	movz	x9, #0x0, lsl #48
    5f10:      	b	0x5f4c <_stogir.stack.validate+0x120>
    5f14:      	uxtb	w16, w9
    5f18:      	cmp	w16, wzr
    5f1c:      	b.eq	0x60dc <_stogir.stack.validate+0x2b0>
    5f20:      	mov	x22, x8
    5f24:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005f24:  ARM64_RELOC_PAGE21	l_stogir.386
    5f28:      	ldr	x16, [x16]
		0000000000005f28:  ARM64_RELOC_PAGEOFF12	l_stogir.386
    5f2c:      	orr	x0, x16, xzr
    5f30:      	mov	x1, x0
    5f34:      	mov	x0, #0x1                ; =1
    5f38:      	mov	x2, #0x19               ; =25
    5f3c:      	b	0x600c <_stogir.stack.validate+0x1e0>
    5f40:      	movz	x9, #0x0, lsl #48
    5f44:      	b	0x5f4c <_stogir.stack.validate+0x120>
    5f48:      	movz	x9, #0x0, lsl #48
    5f4c:      	lsl	x10, x1, #4
    5f50:      	lsl	x6, x6, #4
    5f54:      	cmp	x9, #0x0
    5f58:      	b.eq	0x5fb4 <_stogir.stack.validate+0x188>
    5f5c:      	uxtb	w16, w3
    5f60:      	cmp	w16, wzr
    5f64:      	b.eq	0x5f88 <_stogir.stack.validate+0x15c>
    5f68:      	ldr	x9, [x0]
    5f6c:      	add	x9, x10, x9
    5f70:      	ldr	x11, [x9]
    5f74:      	ldr	x9, [x9, #0x8]
    5f78:      	fmov	d31, x9
    5f7c:      	mov	x9, x11
    5f80:      	fmov	x11, d31
    5f84:      	b	0x5fa4 <_stogir.stack.validate+0x178>
    5f88:      	ldr	x9, [x0, #0x28]
    5f8c:      	add	x9, x6, x9
    5f90:      	ldr	x11, [x9]
    5f94:      	ldr	x9, [x9, #0x8]
    5f98:      	fmov	d31, x9
    5f9c:      	mov	x9, x11
    5fa0:      	fmov	x11, d31
    5fa4:      	mov	x12, x11
    5fa8:      	mov	x11, x9
    5fac:      	mov	x9, #0x1                ; =1
    5fb0:      	b	0x5fc0 <_stogir.stack.validate+0x194>
    5fb4:      	movz	x9, #0x0, lsl #48
    5fb8:      	movz	x11, #0x0, lsl #48
    5fbc:      	movz	x12, #0x0, lsl #48
    5fc0:      	lsr	w9, w9, #0
    5fc4:      	lsr	x16, x9, #0
    5fc8:      	cmp	x16, #0x1
    5fcc:      	b.eq	0x5fe8 <_stogir.stack.validate+0x1bc>
    5fd0:      	b.lo	0x5fd8 <_stogir.stack.validate+0x1ac>
    5fd4:      	b	0x5fec <_stogir.stack.validate+0x1c0>
    5fd8:      	cmp	x16, #0x0
    5fdc:      	b.eq	0x5fe4 <_stogir.stack.validate+0x1b8>
    5fe0:      	b	0x5fec <_stogir.stack.validate+0x1c0>
    5fe4:      	b	0x5ff0 <_stogir.stack.validate+0x1c4>
    5fe8:      	b	0x603c <_stogir.stack.validate+0x210>
    5fec:      	b	0x6430 <_stogir.stack.validate+0x604>
    5ff0:      	adrp	x16, 0x5000 <_stogir.atomic.validate+0x2d4>
		0000000000005ff0:  ARM64_RELOC_PAGE21	l_stogir.387
    5ff4:      	ldr	x16, [x16]
		0000000000005ff4:  ARM64_RELOC_PAGEOFF12	l_stogir.387
    5ff8:      	orr	x0, x16, xzr
    5ffc:      	mov	x22, x8
    6000:      	mov	x1, x0
    6004:      	mov	x0, #0x1                ; =1
    6008:      	mov	x2, #0x19               ; =25
    600c:      	str	x0, [x22]
    6010:      	str	x1, [x22, #0x8]
    6014:      	str	x2, [x22, #0x10]
    6018:      	ldr	x19, [sp, #0x60]
    601c:      	ldr	x20, [sp, #0x68]
    6020:      	ldr	x21, [sp, #0x70]
    6024:      	ldr	x22, [sp, #0x78]
    6028:      	ldr	x23, [sp, #0x80]
    602c:      	ldr	x29, [sp]
    6030:      	ldr	x30, [sp, #0x8]
    6034:      	add	sp, sp, #0x90
    6038:      	ret
    603c:      	cmp	x1, #0x0
    6040:      	cset	w9, le
    6044:      	uxtb	w19, w11
    6048:      	add	x16, sp, #0x10
    604c:      	str	x11, [x16]
    6050:      	orr	x11, x19, xzr
    6054:      	add	x16, sp, #0x10
    6058:      	str	x12, [x16, #0x8]
    605c:      	cmp	x11, #0x42
    6060:      	b.ne	0x5f14 <_stogir.stack.validate+0xe8>
    6064:      	uxtb	w16, w3
    6068:      	cmp	w16, wzr
    606c:      	b.eq	0x6128 <_stogir.stack.validate+0x2fc>
    6070:      	ldr	x4, [x0, #0x8]
    6074:      	cmp	x1, x4
    6078:      	b.ge	0x6174 <_stogir.stack.validate+0x348>
    607c:      	add	x4, x0, #0x78
    6080:      	ldr	x4, [x4, #0x8]
    6084:      	cmp	x1, x4
    6088:      	b.ge	0x6268 <_stogir.stack.validate+0x43c>
    608c:      	ldr	x1, [x0, #0x78]
    6090:      	add	x1, x2, x1
    6094:      	ldr	w1, [x1]
    6098:      	sxtw	x1, w1
    609c:      	cmp	x1, #0x0
    60a0:      	cset	w1, ge
    60a4:      	ubfx	x1, x1, #0, #8
    60a8:      	b	0x626c <_stogir.stack.validate+0x440>
    60ac:      	movz	x9, #0x0, lsl #48
    60b0:      	b	0x5f44 <_stogir.stack.validate+0x118>
    60b4:      	movz	x9, #0x0, lsl #48
    60b8:      	b	0x5f10 <_stogir.stack.validate+0xe4>
    60bc:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		00000000000060bc:  ARM64_RELOC_PAGE21	l_stogir.388
    60c0:      	ldr	x16, [x16]
		00000000000060c0:  ARM64_RELOC_PAGEOFF12	l_stogir.388
    60c4:      	orr	x0, x16, xzr
    60c8:      	mov	x1, x0
    60cc:      	mov	x0, #0x1                ; =1
    60d0:      	mov	x2, #0x1e               ; =30
    60d4:      	mov	x22, x8
    60d8:      	b	0x5f3c <_stogir.stack.validate+0x110>
    60dc:      	cmp	x11, #0x51
    60e0:      	cset	w1, eq
    60e4:      	cmp	x11, #0x53
    60e8:      	cset	w20, eq
    60ec:      	cmp	x11, #0x54
    60f0:      	cset	w21, eq
    60f4:      	uxtb	w16, w1
    60f8:      	cmp	w16, wzr
    60fc:      	b.ne	0x6270 <_stogir.stack.validate+0x444>
    6100:      	cmp	x11, #0x52
    6104:      	b.eq	0x6270 <_stogir.stack.validate+0x444>
    6108:      	uxtb	w16, w20
    610c:      	cmp	w16, wzr
    6110:      	b.ne	0x6270 <_stogir.stack.validate+0x444>
    6114:      	uxtb	w16, w21
    6118:      	cmp	w16, wzr
    611c:      	b.ne	0x6270 <_stogir.stack.validate+0x444>
    6120:      	mov	x22, x8
    6124:      	b	0x5f24 <_stogir.stack.validate+0xf8>
    6128:      	uxtb	w16, w5
    612c:      	cmp	w16, wzr
    6130:      	b.eq	0x617c <_stogir.stack.validate+0x350>
    6134:      	add	x1, x0, #0x28
    6138:      	add	x5, x0, #0x50
    613c:      	ldr	x1, [x1, #0x8]
    6140:      	ldr	x5, [x5, #0x8]
    6144:      	cmp	x1, x5
    6148:      	b.ne	0x6260 <_stogir.stack.validate+0x434>
    614c:      	cmp	x4, x1
    6150:      	b.gt	0x63cc <_stogir.stack.validate+0x5a0>
    6154:      	ldr	x1, [x0, #0x50]
    6158:      	add	x1, x7, x1
    615c:      	ldr	w1, [x1]
    6160:      	sxtw	x1, w1
    6164:      	cmp	x1, #0x0
    6168:      	cset	w1, gt
    616c:      	ubfx	x1, x1, #0, #8
    6170:      	b	0x63d0 <_stogir.stack.validate+0x5a4>
    6174:      	movz	x1, #0x0, lsl #48
    6178:      	b	0x6180 <_stogir.stack.validate+0x354>
    617c:      	movz	x1, #0x0, lsl #48
    6180:      	cmp	x1, #0x0
    6184:      	b.eq	0x61bc <_stogir.stack.validate+0x390>
    6188:      	uxtb	w16, w3
    618c:      	cmp	w16, wzr
    6190:      	b.eq	0x61a4 <_stogir.stack.validate+0x378>
    6194:      	ldr	x1, [x0]
    6198:      	add	x1, x10, x1
    619c:      	ldr	x1, [x1]
    61a0:      	b	0x61b0 <_stogir.stack.validate+0x384>
    61a4:      	ldr	x1, [x0, #0x28]
    61a8:      	add	x1, x6, x1
    61ac:      	ldr	x1, [x1]
    61b0:      	mov	x3, x1
    61b4:      	mov	x1, #0x1                ; =1
    61b8:      	b	0x61c4 <_stogir.stack.validate+0x398>
    61bc:      	movz	x1, #0x0, lsl #48
    61c0:      	movz	x3, #0x0, lsl #48
    61c4:      	lsr	w1, w1, #0
    61c8:      	lsr	x16, x1, #0
    61cc:      	cmp	x16, #0x1
    61d0:      	b.eq	0x61ec <_stogir.stack.validate+0x3c0>
    61d4:      	b.lo	0x61dc <_stogir.stack.validate+0x3b0>
    61d8:      	b	0x61f0 <_stogir.stack.validate+0x3c4>
    61dc:      	cmp	x16, #0x0
    61e0:      	b.eq	0x61e8 <_stogir.stack.validate+0x3bc>
    61e4:      	b	0x61f0 <_stogir.stack.validate+0x3c4>
    61e8:      	b	0x61f4 <_stogir.stack.validate+0x3c8>
    61ec:      	b	0x6210 <_stogir.stack.validate+0x3e4>
    61f0:      	b	0x6438 <_stogir.stack.validate+0x60c>
    61f4:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		00000000000061f4:  ARM64_RELOC_PAGE21	l_stogir.389
    61f8:      	ldr	x16, [x16]
		00000000000061f8:  ARM64_RELOC_PAGEOFF12	l_stogir.389
    61fc:      	orr	x0, x16, xzr
    6200:      	mov	x1, x0
    6204:      	mov	x0, #0x1                ; =1
    6208:      	mov	x2, #0x21               ; =33
    620c:      	b	0x60d4 <_stogir.stack.validate+0x2a8>
    6210:      	uxtb	w16, w9
    6214:      	cmp	w16, wzr
    6218:      	b.ne	0x60bc <_stogir.stack.validate+0x290>
    621c:      	uxtb	w1, w3
    6220:      	cmp	x1, #0x42
    6224:      	b.ne	0x60bc <_stogir.stack.validate+0x290>
    6228:      	lsr	w3, w3, #0
    622c:      	ubfx	x1, x3, #8, #8
    6230:      	cmp	x1, #0x6
    6234:      	b.ne	0x60bc <_stogir.stack.validate+0x290>
    6238:      	ldr	x0, [x0, #0x78]
    623c:      	add	x0, x2, x0
    6240:      	ldr	w0, [x0]
    6244:      	sxtw	x0, w0
    6248:      	cmp	x0, #0x0
    624c:      	b.ne	0x60bc <_stogir.stack.validate+0x290>
    6250:      	movz	x0, #0x0, lsl #48
    6254:      	mov	x1, #0x8                ; =8
    6258:      	movz	x2, #0x0, lsl #48
    625c:      	b	0x60d4 <_stogir.stack.validate+0x2a8>
    6260:      	movz	x1, #0x0, lsl #48
    6264:      	b	0x6180 <_stogir.stack.validate+0x354>
    6268:      	movz	x1, #0x0, lsl #48
    626c:      	b	0x6178 <_stogir.stack.validate+0x34c>
    6270:      	ldr	x3, [x0, #0x78]
    6274:      	add	x2, x2, x3
    6278:      	ldr	w2, [x2]
    627c:      	uxtb	w16, w1
    6280:      	cmp	w16, wzr
    6284:      	b.eq	0x62f0 <_stogir.stack.validate+0x4c4>
    6288:      	mov	x1, #0x3                ; =3
    628c:      	b	0x6304 <_stogir.stack.validate+0x4d8>
    6290:      	add	x16, sp, #0x10
    6294:      	ldr	w0, [x16]
    6298:      	add	x16, sp, #0x10
    629c:      	ldr	w1, [x16, #0x4]
    62a0:      	add	x16, sp, #0x10
    62a4:      	ldr	w2, [x16, #0x8]
    62a8:      	lsr	w1, w1, #0
    62ac:      	ubfx	x0, x0, #8, #8
    62b0:      	lsr	w2, w2, #0
    62b4:      	lsr	w0, w0, #0
    62b8:      	add	x8, sp, #0x20
    62bc:      	mov	w3, w1
    62c0:      	mov	w1, w19
    62c4:      	mov	w4, w2
    62c8:      	mov	w2, w0
    62cc:      	mov	x0, x23
    62d0:      	bl	0x62d0 <_stogir.stack.validate+0x4a4>
		00000000000062d0:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-scope-inputs
    62d4:      	add	x16, sp, #0x20
    62d8:      	ldr	x0, [x16]
    62dc:      	add	x16, sp, #0x20
    62e0:      	ldr	x1, [x16, #0x8]
    62e4:      	add	x16, sp, #0x20
    62e8:      	ldr	x2, [x16, #0x10]
    62ec:      	b	0x5f3c <_stogir.stack.validate+0x110>
    62f0:      	uxtb	w16, w20
    62f4:      	cmp	w16, wzr
    62f8:      	mov	x16, #0x1               ; =1
    62fc:      	mov	x17, #0x2               ; =2
    6300:      	csel	x1, x16, x17, ne
    6304:      	sxtw	x2, w2
    6308:      	lsr	w1, w1, #0
    630c:      	sxtw	x1, w1
    6310:      	cmp	x2, x1
    6314:      	b.ne	0x6440 <_stogir.stack.validate+0x614>
    6318:      	add	x16, sp, #0x10
    631c:      	ldr	w1, [x16]
    6320:      	orr	x2, x1, xzr
    6324:      	ubfx	x2, x2, #16, #16
    6328:      	and	x3, x2, #0x8000
    632c:      	uxth	w3, w3
    6330:      	cmp	x3, #0x0
    6334:      	b.ne	0x63d4 <_stogir.stack.validate+0x5a8>
    6338:      	mov	x22, x8
    633c:      	mov	x23, x0
    6340:      	lsr	w19, w19, #0
    6344:      	uxtb	w16, w20
    6348:      	cmp	w16, wzr
    634c:      	b.ne	0x6290 <_stogir.stack.validate+0x464>
    6350:      	uxtb	w16, w21
    6354:      	cmp	w16, wzr
    6358:      	b.ne	0x6290 <_stogir.stack.validate+0x464>
    635c:      	add	x16, sp, #0x10
    6360:      	ldr	w0, [x16]
    6364:      	add	x16, sp, #0x10
    6368:      	ldr	w1, [x16, #0x4]
    636c:      	add	x16, sp, #0x10
    6370:      	ldr	w2, [x16, #0x8]
    6374:      	lsr	w1, w1, #0
    6378:      	ubfx	x0, x0, #8, #8
    637c:      	add	x16, sp, #0x10
    6380:      	ldr	w3, [x16, #0xc]
    6384:      	lsr	w2, w2, #0
    6388:      	lsr	w3, w3, #0
    638c:      	lsr	w0, w0, #0
    6390:      	add	x8, sp, #0x40
    6394:      	mov	w4, w2
    6398:      	mov	w2, w0
    639c:      	mov	x0, x23
    63a0:      	mov	w5, w3
    63a4:      	mov	w3, w1
    63a8:      	mov	w1, w19
    63ac:      	bl	0x63ac <_stogir.stack.validate+0x580>
		00000000000063ac:  ARM64_RELOC_BRANCH26	_stogir.stack.validate-inputs
    63b0:      	add	x16, sp, #0x40
    63b4:      	ldr	x0, [x16]
    63b8:      	add	x16, sp, #0x40
    63bc:      	ldr	x1, [x16, #0x8]
    63c0:      	add	x16, sp, #0x40
    63c4:      	ldr	x2, [x16, #0x10]
    63c8:      	b	0x62ec <_stogir.stack.validate+0x4c0>
    63cc:      	movz	x1, #0x0, lsl #48
    63d0:      	b	0x6264 <_stogir.stack.validate+0x438>
    63d4:      	uxtb	w1, w1
    63d8:      	cmp	x1, #0x51
    63dc:      	b.ne	0x6448 <_stogir.stack.validate+0x61c>
    63e0:      	cmp	x2, #0x8, lsl #12       ; =0x8000
    63e4:      	b.ne	0x6450 <_stogir.stack.validate+0x624>
    63e8:      	add	x16, sp, #0x10
    63ec:      	ldr	w1, [x16, #0x4]
    63f0:      	add	x16, sp, #0x10
    63f4:      	ldr	w2, [x16, #0x8]
    63f8:      	lsr	w1, w1, #0
    63fc:      	lsr	w2, w2, #0
    6400:      	mov	x22, x8
    6404:      	mov	x23, x0
    6408:      	bl	0x6408 <_stogir.stack.validate+0x5dc>
		0000000000006408:  ARM64_RELOC_BRANCH26	_stogir.stack.valid-frame-object-inputs?
    640c:      	cmp	x0, #0x0
    6410:      	b.ne	0x6340 <_stogir.stack.validate+0x514>
    6414:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006414:  ARM64_RELOC_PAGE21	l_stogir.390
    6418:      	ldr	x16, [x16]
		0000000000006418:  ARM64_RELOC_PAGEOFF12	l_stogir.390
    641c:      	orr	x0, x16, xzr
    6420:      	mov	x1, x0
    6424:      	mov	x0, #0x1                ; =1
    6428:      	mov	x2, #0x26               ; =38
    642c:      	b	0x62ec <_stogir.stack.validate+0x4c0>
    6430:      	brk	#0
    6434:      	b	0x6430 <_stogir.stack.validate+0x604>
    6438:      	brk	#0
    643c:      	b	0x6438 <_stogir.stack.validate+0x60c>
    6440:      	mov	x22, x8
    6444:      	b	0x5f24 <_stogir.stack.validate+0xf8>
    6448:      	mov	x22, x8
    644c:      	b	0x6414 <_stogir.stack.validate+0x5e8>
    6450:      	mov	x22, x8
    6454:      	b	0x6414 <_stogir.stack.validate+0x5e8>

0000000000006458 <_stogir.locals.operation?>:
    6458:      	sxtw	x0, w0
    645c:      	cmp	x0, #0x41
    6460:      	b.ne	0x6474 <_stogir.locals.operation?+0x1c>
    6464:      	mov	x0, #0x1                ; =1
    6468:      	b	0x6470 <_stogir.locals.operation?+0x18>
    646c:      	movz	x0, #0x0, lsl #48
    6470:      	ret
    6474:      	cmp	x0, #0x48
    6478:      	b.ne	0x6484 <_stogir.locals.operation?+0x2c>
    647c:      	mov	x0, #0x1                ; =1
    6480:      	b	0x6470 <_stogir.locals.operation?+0x18>
    6484:      	cmp	x0, #0x55
    6488:      	b.lt	0x646c <_stogir.locals.operation?+0x14>
    648c:      	cmp	x0, #0x58
    6490:      	cset	w0, le
    6494:      	ubfx	x0, x0, #0, #8
    6498:      	b	0x6470 <_stogir.locals.operation?+0x18>

000000000000649c <_stogir.locals.validate>:
    649c:      	sub	sp, sp, #0xb0
    64a0:      	str	x29, [sp]
    64a4:      	str	x30, [sp, #0x8]
    64a8:      	mov	x29, sp
    64ac:      	str	x19, [sp, #0x70]
    64b0:      	str	x20, [sp, #0x78]
    64b4:      	str	x21, [sp, #0x80]
    64b8:      	str	x22, [sp, #0x88]
    64bc:      	str	x23, [sp, #0x90]
    64c0:      	str	x24, [sp, #0x98]
    64c4:      	str	x25, [sp, #0xa0]
    64c8:      	sxtw	x1, w1
    64cc:      	lsl	x3, x1, #2
    64d0:      	cmp	x1, #0x0
    64d4:      	cset	w4, gt
    64d8:      	movz	x16, #0x0, lsl #48
    64dc:      	sub	x5, x16, x1
    64e0:      	sub	x6, x5, #0x1
    64e4:      	uxtb	w16, w4
    64e8:      	cmp	w16, wzr
    64ec:      	b.eq	0x652c <_stogir.locals.validate+0x90>
    64f0:      	ldr	x5, [x0, #0x8]
    64f4:      	cmp	x1, x5
    64f8:      	b.ge	0x65cc <_stogir.locals.validate+0x130>
    64fc:      	add	x5, x0, #0x78
    6500:      	ldr	x5, [x5, #0x8]
    6504:      	cmp	x1, x5
    6508:      	b.ge	0x66f4 <_stogir.locals.validate+0x258>
    650c:      	ldr	x5, [x0, #0x78]
    6510:      	add	x5, x3, x5
    6514:      	ldr	w5, [x5]
    6518:      	sxtw	x5, w5
    651c:      	cmp	x5, #0x0
    6520:      	cset	w5, ge
    6524:      	ubfx	x5, x5, #0, #8
    6528:      	b	0x66f8 <_stogir.locals.validate+0x25c>
    652c:      	cmp	x1, #0x0
    6530:      	b.ge	0x65d4 <_stogir.locals.validate+0x138>
    6534:      	add	x7, x0, #0x28
    6538:      	add	x9, x0, #0x50
    653c:      	ldr	x7, [x7, #0x8]
    6540:      	ldr	x9, [x9, #0x8]
    6544:      	cmp	x7, x9
    6548:      	b.ne	0x6578 <_stogir.locals.validate+0xdc>
    654c:      	cmp	x5, x7
    6550:      	b.gt	0x677c <_stogir.locals.validate+0x2e0>
    6554:      	lsl	x5, x6, #2
    6558:      	ldr	x7, [x0, #0x50]
    655c:      	add	x5, x5, x7
    6560:      	ldr	w5, [x5]
    6564:      	sxtw	x5, w5
    6568:      	cmp	x5, #0x0
    656c:      	cset	w5, gt
    6570:      	ubfx	x5, x5, #0, #8
    6574:      	b	0x6780 <_stogir.locals.validate+0x2e4>
    6578:      	movz	x5, #0x0, lsl #48
    657c:      	b	0x65d8 <_stogir.locals.validate+0x13c>
    6580:      	cmp	x5, #0x0
    6584:      	cset	w5, ne
    6588:      	uxtb	w16, w5
    658c:      	cmp	w16, wzr
    6590:      	mov	x16, #0x2               ; =2
    6594:      	mov	x17, #0x3               ; =3
    6598:      	csel	x5, x16, x17, ne
    659c:      	lsr	w5, w5, #0
    65a0:      	sxtw	x5, w5
    65a4:      	cmp	x1, #0x0
    65a8:      	b.gt	0x66fc <_stogir.locals.validate+0x260>
    65ac:      	mov	x23, x8
    65b0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		00000000000065b0:  ARM64_RELOC_PAGE21	l_stogir.391
    65b4:      	ldr	x16, [x16]
		00000000000065b4:  ARM64_RELOC_PAGEOFF12	l_stogir.391
    65b8:      	orr	x0, x16, xzr
    65bc:      	mov	x1, x0
    65c0:      	mov	x0, #0x1                ; =1
    65c4:      	mov	x2, #0x17               ; =23
    65c8:      	b	0x6698 <_stogir.locals.validate+0x1fc>
    65cc:      	movz	x5, #0x0, lsl #48
    65d0:      	b	0x65d8 <_stogir.locals.validate+0x13c>
    65d4:      	movz	x5, #0x0, lsl #48
    65d8:      	cmp	x5, #0x0
    65dc:      	b.eq	0x6640 <_stogir.locals.validate+0x1a4>
    65e0:      	uxtb	w16, w4
    65e4:      	cmp	w16, wzr
    65e8:      	b.eq	0x6610 <_stogir.locals.validate+0x174>
    65ec:      	lsl	x4, x1, #4
    65f0:      	ldr	x5, [x0]
    65f4:      	add	x4, x4, x5
    65f8:      	ldr	x5, [x4]
    65fc:      	ldr	x4, [x4, #0x8]
    6600:      	fmov	d31, x4
    6604:      	mov	x4, x5
    6608:      	fmov	x5, d31
    660c:      	b	0x6630 <_stogir.locals.validate+0x194>
    6610:      	lsl	x4, x6, #4
    6614:      	ldr	x5, [x0, #0x28]
    6618:      	add	x4, x4, x5
    661c:      	ldr	x5, [x4]
    6620:      	ldr	x4, [x4, #0x8]
    6624:      	fmov	d31, x4
    6628:      	mov	x4, x5
    662c:      	fmov	x5, d31
    6630:      	mov	x6, x5
    6634:      	mov	x5, x4
    6638:      	mov	x4, #0x1                ; =1
    663c:      	b	0x664c <_stogir.locals.validate+0x1b0>
    6640:      	movz	x4, #0x0, lsl #48
    6644:      	movz	x5, #0x0, lsl #48
    6648:      	movz	x6, #0x0, lsl #48
    664c:      	lsr	w4, w4, #0
    6650:      	lsr	x16, x4, #0
    6654:      	cmp	x16, #0x1
    6658:      	b.eq	0x6674 <_stogir.locals.validate+0x1d8>
    665c:      	b.lo	0x6664 <_stogir.locals.validate+0x1c8>
    6660:      	b	0x6678 <_stogir.locals.validate+0x1dc>
    6664:      	cmp	x16, #0x0
    6668:      	b.eq	0x6670 <_stogir.locals.validate+0x1d4>
    666c:      	b	0x6678 <_stogir.locals.validate+0x1dc>
    6670:      	b	0x667c <_stogir.locals.validate+0x1e0>
    6674:      	b	0x66d0 <_stogir.locals.validate+0x234>
    6678:      	b	0x68c0 <_stogir.locals.validate+0x424>
    667c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		000000000000667c:  ARM64_RELOC_PAGE21	l_stogir.392
    6680:      	ldr	x16, [x16]
		0000000000006680:  ARM64_RELOC_PAGEOFF12	l_stogir.392
    6684:      	orr	x0, x16, xzr
    6688:      	mov	x23, x8
    668c:      	mov	x1, x0
    6690:      	mov	x0, #0x1                ; =1
    6694:      	mov	x2, #0x17               ; =23
    6698:      	str	x0, [x23]
    669c:      	str	x1, [x23, #0x8]
    66a0:      	str	x2, [x23, #0x10]
    66a4:      	ldr	x19, [sp, #0x70]
    66a8:      	ldr	x20, [sp, #0x78]
    66ac:      	ldr	x21, [sp, #0x80]
    66b0:      	ldr	x22, [sp, #0x88]
    66b4:      	ldr	x23, [sp, #0x90]
    66b8:      	ldr	x24, [sp, #0x98]
    66bc:      	ldr	x25, [sp, #0xa0]
    66c0:      	ldr	x29, [sp]
    66c4:      	ldr	x30, [sp, #0x8]
    66c8:      	add	sp, sp, #0xb0
    66cc:      	ret
    66d0:      	uxtb	w4, w5
    66d4:      	add	x16, sp, #0x10
    66d8:      	str	x5, [x16]
    66dc:      	add	x16, sp, #0x10
    66e0:      	str	x6, [x16, #0x8]
    66e4:      	cmp	x4, #0x55
    66e8:      	b.ne	0x6760 <_stogir.locals.validate+0x2c4>
    66ec:      	mov	x5, #0x1                ; =1
    66f0:      	b	0x676c <_stogir.locals.validate+0x2d0>
    66f4:      	movz	x5, #0x0, lsl #48
    66f8:      	b	0x65d0 <_stogir.locals.validate+0x134>
    66fc:      	cmp	x4, #0x48
    6700:      	cset	w21, eq
    6704:      	uxtb	w16, w20
    6708:      	cmp	w16, wzr
    670c:      	b.ne	0x6784 <_stogir.locals.validate+0x2e8>
    6710:      	uxtb	w16, w21
    6714:      	cmp	w16, wzr
    6718:      	b.ne	0x6784 <_stogir.locals.validate+0x2e8>
    671c:      	cmp	x4, #0x55
    6720:      	b.lt	0x6c34 <_stogir.locals.validate+0x798>
    6724:      	cmp	x4, #0x58
    6728:      	b.le	0x6784 <_stogir.locals.validate+0x2e8>
    672c:      	mov	x23, x8
    6730:      	b	0x65b0 <_stogir.locals.validate+0x114>
    6734:      	cmp	x4, #0x58
    6738:      	cset	w6, eq
    673c:      	ubfx	x6, x6, #0, #8
    6740:      	mov	x19, x6
    6744:      	cmp	x4, #0x41
    6748:      	cset	w20, eq
    674c:      	uxtb	w16, w20
    6750:      	cmp	w16, wzr
    6754:      	b.eq	0x6580 <_stogir.locals.validate+0xe4>
    6758:      	mov	x5, #0x1                ; =1
    675c:      	b	0x65a4 <_stogir.locals.validate+0x108>
    6760:      	cmp	x4, #0x56
    6764:      	cset	w5, eq
    6768:      	ubfx	x5, x5, #0, #8
    676c:      	cmp	x4, #0x57
    6770:      	b.ne	0x6734 <_stogir.locals.validate+0x298>
    6774:      	mov	x19, #0x1               ; =1
    6778:      	b	0x6744 <_stogir.locals.validate+0x2a8>
    677c:      	movz	x5, #0x0, lsl #48
    6780:      	b	0x657c <_stogir.locals.validate+0xe0>
    6784:      	lsr	w5, w5, #0
    6788:      	sxtw	x5, w5
    678c:      	ldr	x4, [x0, #0x78]
    6790:      	add	x3, x3, x4
    6794:      	ldr	w3, [x3]
    6798:      	sxtw	x3, w3
    679c:      	cmp	x3, x5
    67a0:      	b.ne	0x6c3c <_stogir.locals.validate+0x7a0>
    67a4:      	uxtb	w16, w20
    67a8:      	cmp	w16, wzr
    67ac:      	b.ne	0x67cc <_stogir.locals.validate+0x330>
    67b0:      	uxtb	w16, w21
    67b4:      	cmp	w16, wzr
    67b8:      	b.ne	0x67cc <_stogir.locals.validate+0x330>
    67bc:      	add	x16, sp, #0x10
    67c0:      	ldr	w1, [x16, #0x8]
    67c4:      	sxtw	x1, w1
    67c8:      	b	0x67e4 <_stogir.locals.validate+0x348>
    67cc:      	uxtb	w16, w21
    67d0:      	cmp	w16, wzr
    67d4:      	b.ne	0x67e4 <_stogir.locals.validate+0x348>
    67d8:      	add	x16, sp, #0x10
    67dc:      	ldr	w1, [x16, #0x4]
    67e0:      	sxtw	x1, w1
    67e4:      	add	x16, sp, #0x20
    67e8:      	orr	x22, x16, xzr
    67ec:      	lsr	w2, w2, #0
    67f0:      	lsr	w1, w1, #0
    67f4:      	mov	x23, x8
    67f8:      	add	x8, sp, #0x20
    67fc:      	mov	x24, x0
    6800:      	mov	w25, w2
    6804:      	bl	0x6804 <_stogir.locals.validate+0x368>
		0000000000006804:  ARM64_RELOC_BRANCH26	_stogir.locals.shape
    6808:      	add	x16, sp, #0x20
    680c:      	ldr	w0, [x16]
    6810:      	lsr	x16, x0, #0
    6814:      	cmp	x16, #0x1
    6818:      	b.eq	0x6834 <_stogir.locals.validate+0x398>
    681c:      	b.lo	0x6824 <_stogir.locals.validate+0x388>
    6820:      	b	0x6838 <_stogir.locals.validate+0x39c>
    6824:      	cmp	x16, #0x0
    6828:      	b.eq	0x6830 <_stogir.locals.validate+0x394>
    682c:      	b	0x6838 <_stogir.locals.validate+0x39c>
    6830:      	b	0x6858 <_stogir.locals.validate+0x3bc>
    6834:      	b	0x683c <_stogir.locals.validate+0x3a0>
    6838:      	b	0x6ab8 <_stogir.locals.validate+0x61c>
    683c:      	add	x0, x22, #0x8
    6840:      	add	x16, sp, #0x20
    6844:      	ldr	x1, [x16, #0x8]
    6848:      	ldr	x0, [x0, #0x8]
    684c:      	mov	x2, x0
    6850:      	mov	x0, #0x1                ; =1
    6854:      	b	0x65c8 <_stogir.locals.validate+0x12c>
    6858:      	add	x16, sp, #0x20
    685c:      	ldr	x22, [x16, #0x8]
    6860:      	uxtb	w16, w21
    6864:      	cmp	w16, wzr
    6868:      	b.eq	0x6888 <_stogir.locals.validate+0x3ec>
    686c:      	lsr	w22, w22, #0
    6870:      	sxtw	x22, w22
    6874:      	and	x0, x22, #0xffffffff
    6878:      	mov	x1, x0
    687c:      	movz	x0, #0x0, lsl #48
    6880:      	movz	x2, #0x0, lsl #48
    6884:      	b	0x6854 <_stogir.locals.validate+0x3b8>
    6888:      	uxtb	w16, w20
    688c:      	cmp	w16, wzr
    6890:      	b.eq	0x68e4 <_stogir.locals.validate+0x448>
    6894:      	add	x16, sp, #0x10
    6898:      	ldr	w0, [x16]
    689c:      	ubfx	x0, x0, #8, #8
    68a0:      	cmp	x0, #0x6
    68a4:      	b.ne	0x68c8 <_stogir.locals.validate+0x42c>
    68a8:      	sxtw	x25, w25
    68ac:      	and	x0, x25, #0xffffffff
    68b0:      	mov	x1, x0
    68b4:      	movz	x0, #0x0, lsl #48
    68b8:      	movz	x2, #0x0, lsl #48
    68bc:      	b	0x68e0 <_stogir.locals.validate+0x444>
    68c0:      	brk	#0
    68c4:      	b	0x68c0 <_stogir.locals.validate+0x424>
    68c8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		00000000000068c8:  ARM64_RELOC_PAGE21	l_stogir.393
    68cc:      	ldr	x16, [x16]
		00000000000068cc:  ARM64_RELOC_PAGEOFF12	l_stogir.393
    68d0:      	orr	x0, x16, xzr
    68d4:      	mov	x1, x0
    68d8:      	mov	x0, #0x1                ; =1
    68dc:      	mov	x2, #0x21               ; =33
    68e0:      	b	0x6884 <_stogir.locals.validate+0x3e8>
    68e4:      	add	x16, sp, #0x10
    68e8:      	ldr	w0, [x16, #0x4]
    68ec:      	sxtw	x0, w0
    68f0:      	cmp	x0, #0x0
    68f4:      	cset	w1, gt
    68f8:      	movz	x16, #0x0, lsl #48
    68fc:      	sub	x2, x16, x0
    6900:      	sub	x3, x2, #0x1
    6904:      	uxtb	w16, w1
    6908:      	cmp	w16, wzr
    690c:      	b.eq	0x69f4 <_stogir.locals.validate+0x558>
    6910:      	ldr	x2, [x24, #0x8]
    6914:      	cmp	x0, x2
    6918:      	b.ge	0x69ec <_stogir.locals.validate+0x550>
    691c:      	add	x2, x24, #0x78
    6920:      	ldr	x2, [x2, #0x8]
    6924:      	cmp	x0, x2
    6928:      	b.ge	0x6aa8 <_stogir.locals.validate+0x60c>
    692c:      	lsl	x2, x0, #2
    6930:      	ldr	x4, [x24, #0x78]
    6934:      	add	x2, x2, x4
    6938:      	ldr	w2, [x2]
    693c:      	sxtw	x2, w2
    6940:      	cmp	x2, #0x0
    6944:      	cset	w2, ge
    6948:      	ubfx	x2, x2, #0, #8
    694c:      	b	0x6aac <_stogir.locals.validate+0x610>
    6950:      	movz	x0, #0x0, lsl #48
    6954:      	movz	x1, #0x0, lsl #48
    6958:      	lsr	w0, w0, #0
    695c:      	lsr	x16, x0, #0
    6960:      	cmp	x16, #0x1
    6964:      	b.eq	0x6980 <_stogir.locals.validate+0x4e4>
    6968:      	b.lo	0x6970 <_stogir.locals.validate+0x4d4>
    696c:      	b	0x6984 <_stogir.locals.validate+0x4e8>
    6970:      	cmp	x16, #0x0
    6974:      	b.eq	0x697c <_stogir.locals.validate+0x4e0>
    6978:      	b	0x6984 <_stogir.locals.validate+0x4e8>
    697c:      	b	0x6988 <_stogir.locals.validate+0x4ec>
    6980:      	b	0x6a40 <_stogir.locals.validate+0x5a4>
    6984:      	b	0x6c04 <_stogir.locals.validate+0x768>
    6988:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006988:  ARM64_RELOC_PAGE21	l_stogir.394
    698c:      	ldr	x16, [x16]
		000000000000698c:  ARM64_RELOC_PAGEOFF12	l_stogir.394
    6990:      	orr	x0, x16, xzr
    6994:      	mov	x1, x0
    6998:      	mov	x0, #0x1                ; =1
    699c:      	mov	x2, #0x1c               ; =28
    69a0:      	b	0x68e0 <_stogir.locals.validate+0x444>
    69a4:      	lsl	x0, x3, #4
    69a8:      	ldr	x1, [x24, #0x28]
    69ac:      	add	x0, x0, x1
    69b0:      	ldr	x0, [x0]
    69b4:      	mov	x1, x0
    69b8:      	mov	x0, #0x1                ; =1
    69bc:      	b	0x6958 <_stogir.locals.validate+0x4bc>
    69c0:      	movz	x2, #0x0, lsl #48
    69c4:      	cmp	x2, #0x0
    69c8:      	b.eq	0x6950 <_stogir.locals.validate+0x4b4>
    69cc:      	uxtb	w16, w1
    69d0:      	cmp	w16, wzr
    69d4:      	b.eq	0x69a4 <_stogir.locals.validate+0x508>
    69d8:      	lsl	x0, x0, #4
    69dc:      	ldr	x1, [x24]
    69e0:      	add	x0, x0, x1
    69e4:      	ldr	x0, [x0]
    69e8:      	b	0x69b4 <_stogir.locals.validate+0x518>
    69ec:      	movz	x2, #0x0, lsl #48
    69f0:      	b	0x69c4 <_stogir.locals.validate+0x528>
    69f4:      	cmp	x0, #0x0
    69f8:      	b.ge	0x69c0 <_stogir.locals.validate+0x524>
    69fc:      	add	x4, x24, #0x28
    6a00:      	add	x5, x24, #0x50
    6a04:      	ldr	x4, [x4, #0x8]
    6a08:      	ldr	x5, [x5, #0x8]
    6a0c:      	cmp	x4, x5
    6a10:      	b.ne	0x6aa0 <_stogir.locals.validate+0x604>
    6a14:      	cmp	x2, x4
    6a18:      	b.gt	0x6ab0 <_stogir.locals.validate+0x614>
    6a1c:      	lsl	x2, x3, #2
    6a20:      	ldr	x4, [x24, #0x50]
    6a24:      	add	x2, x2, x4
    6a28:      	ldr	w2, [x2]
    6a2c:      	sxtw	x2, w2
    6a30:      	cmp	x2, #0x0
    6a34:      	cset	w2, gt
    6a38:      	ubfx	x2, x2, #0, #8
    6a3c:      	b	0x6ab4 <_stogir.locals.validate+0x618>
    6a40:      	add	x16, sp, #0x10
    6a44:      	ldr	w0, [x16, #0x4]
    6a48:      	sxtw	x0, w0
    6a4c:      	cmp	x0, #0x0
    6a50:      	b.le	0x6a84 <_stogir.locals.validate+0x5e8>
    6a54:      	uxtb	w1, w1
    6a58:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006a58:  ARM64_RELOC_PAGE21	l_stogir.395
    6a5c:      	ldr	x16, [x16]
		0000000000006a5c:  ARM64_RELOC_PAGEOFF12	l_stogir.395
    6a60:      	orr	x0, x16, xzr
    6a64:      	cmp	x1, #0x83
    6a68:      	cset	w2, lt
    6a6c:      	add	x0, x1, x0
    6a70:      	uxtb	w16, w2
    6a74:      	cmp	w16, wzr
    6a78:      	b.eq	0x6ac0 <_stogir.locals.validate+0x624>
    6a7c:      	ldrb	w1, [x0]
    6a80:      	b	0x6ac4 <_stogir.locals.validate+0x628>
    6a84:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006a84:  ARM64_RELOC_PAGE21	l_stogir.396
    6a88:      	ldr	x16, [x16]
		0000000000006a88:  ARM64_RELOC_PAGEOFF12	l_stogir.396
    6a8c:      	orr	x0, x16, xzr
    6a90:      	mov	x1, x0
    6a94:      	mov	x0, #0x1                ; =1
    6a98:      	mov	x2, #0x1c               ; =28
    6a9c:      	b	0x69a0 <_stogir.locals.validate+0x504>
    6aa0:      	movz	x2, #0x0, lsl #48
    6aa4:      	b	0x69c4 <_stogir.locals.validate+0x528>
    6aa8:      	movz	x2, #0x0, lsl #48
    6aac:      	b	0x69f0 <_stogir.locals.validate+0x554>
    6ab0:      	movz	x2, #0x0, lsl #48
    6ab4:      	b	0x6aa4 <_stogir.locals.validate+0x608>
    6ab8:      	brk	#0
    6abc:      	b	0x6ab8 <_stogir.locals.validate+0x61c>
    6ac0:      	movz	x1, #0x0, lsl #48
    6ac4:      	uxtb	w1, w1
    6ac8:      	and	x1, x1, #0x1
    6acc:      	uxtb	w1, w1
    6ad0:      	cmp	x1, #0x0
    6ad4:      	b.eq	0x6a84 <_stogir.locals.validate+0x5e8>
    6ad8:      	uxtb	w16, w2
    6adc:      	cmp	w16, wzr
    6ae0:      	b.eq	0x6aec <_stogir.locals.validate+0x650>
    6ae4:      	ldrb	w0, [x0]
    6ae8:      	b	0x6af0 <_stogir.locals.validate+0x654>
    6aec:      	movz	x0, #0x0, lsl #48
    6af0:      	uxtb	w0, w0
    6af4:      	and	x0, x0, #0x4
    6af8:      	uxtb	w0, w0
    6afc:      	cmp	x0, #0x0
    6b00:      	b.ne	0x6a84 <_stogir.locals.validate+0x5e8>
    6b04:      	cmp	x19, #0x0
    6b08:      	b.eq	0x6ba8 <_stogir.locals.validate+0x70c>
    6b0c:      	add	x16, sp, #0x10
    6b10:      	ldr	w0, [x16, #0xc]
    6b14:      	lsr	w0, w0, #0
    6b18:      	add	x8, sp, #0x40
    6b1c:      	mov	w1, w0
    6b20:      	mov	x0, x24
    6b24:      	bl	0x6b24 <_stogir.locals.validate+0x688>
		0000000000006b24:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    6b28:      	add	x16, sp, #0x40
    6b2c:      	ldr	x0, [x16]
    6b30:      	add	x16, sp, #0x40
    6b34:      	ldr	x1, [x16, #0x8]
    6b38:      	mov	x20, x1
    6b3c:      	b	0x6bb8 <_stogir.locals.validate+0x71c>
    6b40:      	lsr	w25, w25, #0
    6b44:      	lsr	w0, w20, #0
    6b48:      	ubfx	x0, x0, #8, #8
    6b4c:      	lsr	w0, w0, #0
    6b50:      	mov	w1, w25
    6b54:      	bl	0x6b54 <_stogir.locals.validate+0x6b8>
		0000000000006b54:  ARM64_RELOC_BRANCH26	_stogir.types.size
    6b58:      	lsr	w0, w0, #0
    6b5c:      	sxtw	x0, w0
    6b60:      	cmp	x0, #0x0
    6b64:      	b.le	0x6b8c <_stogir.locals.validate+0x6f0>
    6b68:      	cmp	x0, x22
    6b6c:      	b.gt	0x6b8c <_stogir.locals.validate+0x6f0>
    6b70:      	cmp	x19, #0x0
    6b74:      	b.eq	0x6c0c <_stogir.locals.validate+0x770>
    6b78:      	add	x16, sp, #0x10
    6b7c:      	ldr	w1, [x16]
    6b80:      	ubfx	x1, x1, #8, #8
    6b84:      	cmp	x1, #0x0
    6b88:      	b.eq	0x6c0c <_stogir.locals.validate+0x770>
    6b8c:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006b8c:  ARM64_RELOC_PAGE21	l_stogir.397
    6b90:      	ldr	x16, [x16]
		0000000000006b90:  ARM64_RELOC_PAGEOFF12	l_stogir.397
    6b94:      	orr	x0, x16, xzr
    6b98:      	mov	x1, x0
    6b9c:      	mov	x0, #0x1                ; =1
    6ba0:      	mov	x2, #0x23               ; =35
    6ba4:      	b	0x6a9c <_stogir.locals.validate+0x600>
    6ba8:      	add	x16, sp, #0x10
    6bac:      	ldr	x0, [x16]
    6bb0:      	mov	x20, x0
    6bb4:      	mov	x0, #0x1                ; =1
    6bb8:      	lsr	w0, w0, #0
    6bbc:      	lsr	x16, x0, #0
    6bc0:      	cmp	x16, #0x1
    6bc4:      	b.eq	0x6be0 <_stogir.locals.validate+0x744>
    6bc8:      	b.lo	0x6bd0 <_stogir.locals.validate+0x734>
    6bcc:      	b	0x6be4 <_stogir.locals.validate+0x748>
    6bd0:      	cmp	x16, #0x0
    6bd4:      	b.eq	0x6bdc <_stogir.locals.validate+0x740>
    6bd8:      	b	0x6be4 <_stogir.locals.validate+0x748>
    6bdc:      	b	0x6be8 <_stogir.locals.validate+0x74c>
    6be0:      	b	0x6b40 <_stogir.locals.validate+0x6a4>
    6be4:      	b	0x6c2c <_stogir.locals.validate+0x790>
    6be8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006be8:  ARM64_RELOC_PAGE21	l_stogir.398
    6bec:      	ldr	x16, [x16]
		0000000000006bec:  ARM64_RELOC_PAGEOFF12	l_stogir.398
    6bf0:      	orr	x0, x16, xzr
    6bf4:      	mov	x1, x0
    6bf8:      	mov	x0, #0x1                ; =1
    6bfc:      	mov	x2, #0x19               ; =25
    6c00:      	b	0x6ba4 <_stogir.locals.validate+0x708>
    6c04:      	brk	#0
    6c08:      	b	0x6c04 <_stogir.locals.validate+0x768>
    6c0c:      	uxtb	w20, w20
    6c10:      	cmp	x20, #0x48
    6c14:      	b.eq	0x6b8c <_stogir.locals.validate+0x6f0>
    6c18:      	and	x0, x0, #0xffffffff
    6c1c:      	mov	x1, x0
    6c20:      	movz	x0, #0x0, lsl #48
    6c24:      	movz	x2, #0x0, lsl #48
    6c28:      	b	0x6ba4 <_stogir.locals.validate+0x708>
    6c2c:      	brk	#0
    6c30:      	b	0x6c2c <_stogir.locals.validate+0x790>
    6c34:      	mov	x23, x8
    6c38:      	b	0x65b0 <_stogir.locals.validate+0x114>
    6c3c:      	mov	x23, x8
    6c40:      	b	0x65b0 <_stogir.locals.validate+0x114>

0000000000006c44 <_stogir.conversion.operation?>:
    6c44:      	sxtw	x0, w0
    6c48:      	cmp	x0, #0x21
    6c4c:      	b.lt	0x6c60 <_stogir.conversion.operation?+0x1c>
    6c50:      	cmp	x0, #0x27
    6c54:      	cset	w0, le
    6c58:      	ubfx	x0, x0, #0, #8
    6c5c:      	b	0x6c64 <_stogir.conversion.operation?+0x20>
    6c60:      	movz	x0, #0x0, lsl #48
    6c64:      	ret

0000000000006c68 <_stogir.conversion.validate>:
    6c68:      	sub	sp, sp, #0x40
    6c6c:      	str	x29, [sp]
    6c70:      	str	x30, [sp, #0x8]
    6c74:      	mov	x29, sp
    6c78:      	str	x19, [sp, #0x30]
    6c7c:      	sxtw	x1, w1
    6c80:      	lsl	x3, x1, #2
    6c84:      	cmp	x1, #0x0
    6c88:      	cset	w4, gt
    6c8c:      	movz	x16, #0x0, lsl #48
    6c90:      	sub	x5, x16, x1
    6c94:      	sub	x6, x5, #0x1
    6c98:      	uxtb	w16, w4
    6c9c:      	cmp	w16, wzr
    6ca0:      	b.eq	0x6ce0 <_stogir.conversion.validate+0x78>
    6ca4:      	ldr	x5, [x0, #0x8]
    6ca8:      	cmp	x1, x5
    6cac:      	b.ge	0x6d34 <_stogir.conversion.validate+0xcc>
    6cb0:      	add	x5, x0, #0x78
    6cb4:      	ldr	x5, [x5, #0x8]
    6cb8:      	cmp	x1, x5
    6cbc:      	b.ge	0x6e20 <_stogir.conversion.validate+0x1b8>
    6cc0:      	ldr	x5, [x0, #0x78]
    6cc4:      	add	x5, x3, x5
    6cc8:      	ldr	w5, [x5]
    6ccc:      	sxtw	x5, w5
    6cd0:      	cmp	x5, #0x0
    6cd4:      	cset	w5, ge
    6cd8:      	ubfx	x5, x5, #0, #8
    6cdc:      	b	0x6e24 <_stogir.conversion.validate+0x1bc>
    6ce0:      	cmp	x1, #0x0
    6ce4:      	b.ge	0x6d3c <_stogir.conversion.validate+0xd4>
    6ce8:      	add	x7, x0, #0x28
    6cec:      	add	x9, x0, #0x50
    6cf0:      	ldr	x7, [x7, #0x8]
    6cf4:      	ldr	x9, [x9, #0x8]
    6cf8:      	cmp	x7, x9
    6cfc:      	b.ne	0x6d2c <_stogir.conversion.validate+0xc4>
    6d00:      	cmp	x5, x7
    6d04:      	b.gt	0x6eb8 <_stogir.conversion.validate+0x250>
    6d08:      	lsl	x5, x6, #2
    6d0c:      	ldr	x7, [x0, #0x50]
    6d10:      	add	x5, x5, x7
    6d14:      	ldr	w5, [x5]
    6d18:      	sxtw	x5, w5
    6d1c:      	cmp	x5, #0x0
    6d20:      	cset	w5, gt
    6d24:      	ubfx	x5, x5, #0, #8
    6d28:      	b	0x6ebc <_stogir.conversion.validate+0x254>
    6d2c:      	movz	x5, #0x0, lsl #48
    6d30:      	b	0x6d40 <_stogir.conversion.validate+0xd8>
    6d34:      	movz	x5, #0x0, lsl #48
    6d38:      	b	0x6d40 <_stogir.conversion.validate+0xd8>
    6d3c:      	movz	x5, #0x0, lsl #48
    6d40:      	cmp	x5, #0x0
    6d44:      	b.eq	0x6d84 <_stogir.conversion.validate+0x11c>
    6d48:      	uxtb	w16, w4
    6d4c:      	cmp	w16, wzr
    6d50:      	b.eq	0x6d68 <_stogir.conversion.validate+0x100>
    6d54:      	lsl	x4, x1, #4
    6d58:      	ldr	x5, [x0]
    6d5c:      	add	x4, x4, x5
    6d60:      	ldr	x4, [x4]
    6d64:      	b	0x6d78 <_stogir.conversion.validate+0x110>
    6d68:      	lsl	x4, x6, #4
    6d6c:      	ldr	x5, [x0, #0x28]
    6d70:      	add	x4, x4, x5
    6d74:      	ldr	x4, [x4]
    6d78:      	mov	x5, x4
    6d7c:      	mov	x4, #0x1                ; =1
    6d80:      	b	0x6d8c <_stogir.conversion.validate+0x124>
    6d84:      	movz	x4, #0x0, lsl #48
    6d88:      	movz	x5, #0x0, lsl #48
    6d8c:      	lsr	w4, w4, #0
    6d90:      	lsr	x16, x4, #0
    6d94:      	cmp	x16, #0x1
    6d98:      	b.eq	0x6db4 <_stogir.conversion.validate+0x14c>
    6d9c:      	b.lo	0x6da4 <_stogir.conversion.validate+0x13c>
    6da0:      	b	0x6db8 <_stogir.conversion.validate+0x150>
    6da4:      	cmp	x16, #0x0
    6da8:      	b.eq	0x6db0 <_stogir.conversion.validate+0x148>
    6dac:      	b	0x6db8 <_stogir.conversion.validate+0x150>
    6db0:      	b	0x6dbc <_stogir.conversion.validate+0x154>
    6db4:      	b	0x6df8 <_stogir.conversion.validate+0x190>
    6db8:      	b	0x6f38 <_stogir.conversion.validate+0x2d0>
    6dbc:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006dbc:  ARM64_RELOC_PAGE21	l_stogir.399
    6dc0:      	ldr	x16, [x16]
		0000000000006dc0:  ARM64_RELOC_PAGEOFF12	l_stogir.399
    6dc4:      	orr	x0, x16, xzr
    6dc8:      	mov	x19, x8
    6dcc:      	mov	x1, x0
    6dd0:      	mov	x0, #0x1                ; =1
    6dd4:      	mov	x2, #0x12               ; =18
    6dd8:      	str	x0, [x19]
    6ddc:      	str	x1, [x19, #0x8]
    6de0:      	str	x2, [x19, #0x10]
    6de4:      	ldr	x19, [sp, #0x30]
    6de8:      	ldr	x29, [sp]
    6dec:      	ldr	x30, [sp, #0x8]
    6df0:      	add	sp, sp, #0x40
    6df4:      	ret
    6df8:      	cmp	x1, #0x0
    6dfc:      	b.gt	0x6e28 <_stogir.conversion.validate+0x1c0>
    6e00:      	mov	x19, x8
    6e04:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006e04:  ARM64_RELOC_PAGE21	l_stogir.400
    6e08:      	ldr	x16, [x16]
		0000000000006e08:  ARM64_RELOC_PAGEOFF12	l_stogir.400
    6e0c:      	orr	x0, x16, xzr
    6e10:      	mov	x1, x0
    6e14:      	mov	x0, #0x1                ; =1
    6e18:      	mov	x2, #0x1e               ; =30
    6e1c:      	b	0x6dd8 <_stogir.conversion.validate+0x170>
    6e20:      	movz	x5, #0x0, lsl #48
    6e24:      	b	0x6d38 <_stogir.conversion.validate+0xd0>
    6e28:      	uxtb	w1, w5
    6e2c:      	orr	x4, x1, xzr
    6e30:      	cmp	x4, #0x21
    6e34:      	b.lt	0x706c <_stogir.conversion.validate+0x404>
    6e38:      	cmp	x4, #0x27
    6e3c:      	b.gt	0x7074 <_stogir.conversion.validate+0x40c>
    6e40:      	ldr	x4, [x0, #0x78]
    6e44:      	add	x3, x3, x4
    6e48:      	ldr	w3, [x3]
    6e4c:      	sxtw	x3, w3
    6e50:      	cmp	x3, #0x1
    6e54:      	b.ne	0x707c <_stogir.conversion.validate+0x414>
    6e58:      	asr	x3, x5, #32
    6e5c:      	cmp	x3, #0x0
    6e60:      	cset	w6, gt
    6e64:      	movz	x16, #0x0, lsl #48
    6e68:      	sub	x7, x16, x3
    6e6c:      	sub	x9, x7, #0x1
    6e70:      	uxtb	w16, w6
    6e74:      	cmp	w16, wzr
    6e78:      	b.eq	0x6eec <_stogir.conversion.validate+0x284>
    6e7c:      	ldr	x7, [x0, #0x8]
    6e80:      	cmp	x3, x7
    6e84:      	b.ge	0x6f40 <_stogir.conversion.validate+0x2d8>
    6e88:      	add	x7, x0, #0x78
    6e8c:      	ldr	x7, [x7, #0x8]
    6e90:      	cmp	x3, x7
    6e94:      	b.ge	0x6ff0 <_stogir.conversion.validate+0x388>
    6e98:      	lsl	x7, x3, #2
    6e9c:      	add	x4, x7, x4
    6ea0:      	ldr	w4, [x4]
    6ea4:      	sxtw	x4, w4
    6ea8:      	cmp	x4, #0x0
    6eac:      	cset	w4, ge
    6eb0:      	ubfx	x4, x4, #0, #8
    6eb4:      	b	0x6ff4 <_stogir.conversion.validate+0x38c>
    6eb8:      	movz	x5, #0x0, lsl #48
    6ebc:      	b	0x6d30 <_stogir.conversion.validate+0xc8>
    6ec0:      	uxtb	w0, w3
    6ec4:      	cmp	x0, #0x48
    6ec8:      	b.ne	0x6ff8 <_stogir.conversion.validate+0x390>
    6ecc:      	mov	x19, x8
    6ed0:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006ed0:  ARM64_RELOC_PAGE21	l_stogir.401
    6ed4:      	ldr	x16, [x16]
		0000000000006ed4:  ARM64_RELOC_PAGEOFF12	l_stogir.401
    6ed8:      	orr	x0, x16, xzr
    6edc:      	mov	x1, x0
    6ee0:      	mov	x0, #0x1                ; =1
    6ee4:      	mov	x2, #0x25               ; =37
    6ee8:      	b	0x6e1c <_stogir.conversion.validate+0x1b4>
    6eec:      	cmp	x3, #0x0
    6ef0:      	b.ge	0x6f48 <_stogir.conversion.validate+0x2e0>
    6ef4:      	add	x4, x0, #0x28
    6ef8:      	add	x10, x0, #0x50
    6efc:      	ldr	x4, [x4, #0x8]
    6f00:      	ldr	x10, [x10, #0x8]
    6f04:      	cmp	x4, x10
    6f08:      	b.ne	0x6fe8 <_stogir.conversion.validate+0x380>
    6f0c:      	cmp	x7, x4
    6f10:      	b.gt	0x705c <_stogir.conversion.validate+0x3f4>
    6f14:      	lsl	x4, x9, #2
    6f18:      	ldr	x7, [x0, #0x50]
    6f1c:      	add	x4, x4, x7
    6f20:      	ldr	w4, [x4]
    6f24:      	sxtw	x4, w4
    6f28:      	cmp	x4, #0x0
    6f2c:      	cset	w4, gt
    6f30:      	ubfx	x4, x4, #0, #8
    6f34:      	b	0x7060 <_stogir.conversion.validate+0x3f8>
    6f38:      	brk	#0
    6f3c:      	b	0x6f38 <_stogir.conversion.validate+0x2d0>
    6f40:      	movz	x4, #0x0, lsl #48
    6f44:      	b	0x6f4c <_stogir.conversion.validate+0x2e4>
    6f48:      	movz	x4, #0x0, lsl #48
    6f4c:      	cmp	x4, #0x0
    6f50:      	b.eq	0x6f90 <_stogir.conversion.validate+0x328>
    6f54:      	uxtb	w16, w6
    6f58:      	cmp	w16, wzr
    6f5c:      	b.eq	0x6f74 <_stogir.conversion.validate+0x30c>
    6f60:      	lsl	x3, x3, #4
    6f64:      	ldr	x0, [x0]
    6f68:      	add	x0, x3, x0
    6f6c:      	ldr	x0, [x0]
    6f70:      	b	0x6f84 <_stogir.conversion.validate+0x31c>
    6f74:      	lsl	x3, x9, #4
    6f78:      	ldr	x0, [x0, #0x28]
    6f7c:      	add	x0, x3, x0
    6f80:      	ldr	x0, [x0]
    6f84:      	mov	x3, x0
    6f88:      	mov	x0, #0x1                ; =1
    6f8c:      	b	0x6f98 <_stogir.conversion.validate+0x330>
    6f90:      	movz	x0, #0x0, lsl #48
    6f94:      	movz	x3, #0x0, lsl #48
    6f98:      	lsr	w0, w0, #0
    6f9c:      	lsr	x16, x0, #0
    6fa0:      	cmp	x16, #0x1
    6fa4:      	b.eq	0x6fc0 <_stogir.conversion.validate+0x358>
    6fa8:      	b.lo	0x6fb0 <_stogir.conversion.validate+0x348>
    6fac:      	b	0x6fc4 <_stogir.conversion.validate+0x35c>
    6fb0:      	cmp	x16, #0x0
    6fb4:      	b.eq	0x6fbc <_stogir.conversion.validate+0x354>
    6fb8:      	b	0x6fc4 <_stogir.conversion.validate+0x35c>
    6fbc:      	b	0x6fc8 <_stogir.conversion.validate+0x360>
    6fc0:      	b	0x6ec0 <_stogir.conversion.validate+0x258>
    6fc4:      	b	0x7064 <_stogir.conversion.validate+0x3fc>
    6fc8:      	adrp	x16, 0x6000 <_stogir.stack.validate+0x1d4>
		0000000000006fc8:  ARM64_RELOC_PAGE21	l_stogir.402
    6fcc:      	ldr	x16, [x16]
		0000000000006fcc:  ARM64_RELOC_PAGEOFF12	l_stogir.402
    6fd0:      	orr	x0, x16, xzr
    6fd4:      	mov	x19, x8
    6fd8:      	mov	x1, x0
    6fdc:      	mov	x0, #0x1                ; =1
    6fe0:      	mov	x2, #0x19               ; =25
    6fe4:      	b	0x6ee8 <_stogir.conversion.validate+0x280>
    6fe8:      	movz	x4, #0x0, lsl #48
    6fec:      	b	0x6f4c <_stogir.conversion.validate+0x2e4>
    6ff0:      	movz	x4, #0x0, lsl #48
    6ff4:      	b	0x6f44 <_stogir.conversion.validate+0x2dc>
    6ff8:      	cmp	x0, #0x46
    6ffc:      	b.eq	0x7084 <_stogir.conversion.validate+0x41c>
    7000:      	lsr	w2, w2, #0
    7004:      	lsr	w5, w5, #0
    7008:      	lsr	w3, w3, #0
    700c:      	lsr	w1, w1, #0
    7010:      	ubfx	x0, x5, #8, #8
    7014:      	ubfx	x3, x3, #8, #8
    7018:      	lsr	w0, w0, #0
    701c:      	lsr	w3, w3, #0
    7020:      	mov	x19, x8
    7024:      	add	x8, sp, #0x10
    7028:      	fmov	s31, w0
    702c:      	mov	w0, w1
    7030:      	mov	w1, w3
    7034:      	mov	w3, w2
    7038:      	fmov	w2, s31
    703c:      	bl	0x703c <_stogir.conversion.validate+0x3d4>
		000000000000703c:  ARM64_RELOC_BRANCH26	_stogir.conversion.policy
    7040:      	add	x16, sp, #0x10
    7044:      	ldr	x0, [x16]
    7048:      	add	x16, sp, #0x10
    704c:      	ldr	x1, [x16, #0x8]
    7050:      	add	x16, sp, #0x10
    7054:      	ldr	x2, [x16, #0x10]
    7058:      	b	0x6ee8 <_stogir.conversion.validate+0x280>
    705c:      	movz	x4, #0x0, lsl #48
    7060:      	b	0x6fec <_stogir.conversion.validate+0x384>
    7064:      	brk	#0
    7068:      	b	0x7064 <_stogir.conversion.validate+0x3fc>
    706c:      	mov	x19, x8
    7070:      	b	0x6e04 <_stogir.conversion.validate+0x19c>
    7074:      	mov	x19, x8
    7078:      	b	0x6e04 <_stogir.conversion.validate+0x19c>
    707c:      	mov	x19, x8
    7080:      	b	0x6e04 <_stogir.conversion.validate+0x19c>
    7084:      	mov	x19, x8
    7088:      	b	0x6ed0 <_stogir.conversion.validate+0x268>

000000000000708c <_stogir.conditional.validate>:
    708c:      	sub	sp, sp, #0x40
    7090:      	str	x29, [sp]
    7094:      	str	x30, [sp, #0x8]
    7098:      	mov	x29, sp
    709c:      	str	x19, [sp, #0x30]
    70a0:      	sxtw	x1, w1
    70a4:      	lsl	x2, x1, #2
    70a8:      	cmp	x1, #0x0
    70ac:      	cset	w3, gt
    70b0:      	movz	x16, #0x0, lsl #48
    70b4:      	sub	x4, x16, x1
    70b8:      	sub	x5, x4, #0x1
    70bc:      	uxtb	w16, w3
    70c0:      	cmp	w16, wzr
    70c4:      	b.eq	0x7104 <_stogir.conditional.validate+0x78>
    70c8:      	ldr	x4, [x0, #0x8]
    70cc:      	cmp	x1, x4
    70d0:      	b.ge	0x7158 <_stogir.conditional.validate+0xcc>
    70d4:      	add	x4, x0, #0x78
    70d8:      	ldr	x4, [x4, #0x8]
    70dc:      	cmp	x1, x4
    70e0:      	b.ge	0x726c <_stogir.conditional.validate+0x1e0>
    70e4:      	ldr	x4, [x0, #0x78]
    70e8:      	add	x4, x2, x4
    70ec:      	ldr	w4, [x4]
    70f0:      	sxtw	x4, w4
    70f4:      	cmp	x4, #0x0
    70f8:      	cset	w4, ge
    70fc:      	ubfx	x4, x4, #0, #8
    7100:      	b	0x7270 <_stogir.conditional.validate+0x1e4>
    7104:      	cmp	x1, #0x0
    7108:      	b.ge	0x7160 <_stogir.conditional.validate+0xd4>
    710c:      	add	x6, x0, #0x28
    7110:      	add	x7, x0, #0x50
    7114:      	ldr	x6, [x6, #0x8]
    7118:      	ldr	x7, [x7, #0x8]
    711c:      	cmp	x6, x7
    7120:      	b.ne	0x7150 <_stogir.conditional.validate+0xc4>
    7124:      	cmp	x4, x6
    7128:      	b.gt	0x72f4 <_stogir.conditional.validate+0x268>
    712c:      	lsl	x4, x5, #2
    7130:      	ldr	x6, [x0, #0x50]
    7134:      	add	x4, x4, x6
    7138:      	ldr	w4, [x4]
    713c:      	sxtw	x4, w4
    7140:      	cmp	x4, #0x0
    7144:      	cset	w4, gt
    7148:      	ubfx	x4, x4, #0, #8
    714c:      	b	0x72f8 <_stogir.conditional.validate+0x26c>
    7150:      	movz	x4, #0x0, lsl #48
    7154:      	b	0x7164 <_stogir.conditional.validate+0xd8>
    7158:      	movz	x4, #0x0, lsl #48
    715c:      	b	0x7164 <_stogir.conditional.validate+0xd8>
    7160:      	movz	x4, #0x0, lsl #48
    7164:      	cmp	x4, #0x0
    7168:      	b.eq	0x71cc <_stogir.conditional.validate+0x140>
    716c:      	uxtb	w16, w3
    7170:      	cmp	w16, wzr
    7174:      	b.eq	0x719c <_stogir.conditional.validate+0x110>
    7178:      	lsl	x3, x1, #4
    717c:      	ldr	x4, [x0]
    7180:      	add	x3, x3, x4
    7184:      	ldr	x4, [x3]
    7188:      	ldr	x3, [x3, #0x8]
    718c:      	fmov	d31, x3
    7190:      	mov	x3, x4
    7194:      	fmov	x4, d31
    7198:      	b	0x71bc <_stogir.conditional.validate+0x130>
    719c:      	lsl	x3, x5, #4
    71a0:      	ldr	x4, [x0, #0x28]
    71a4:      	add	x3, x3, x4
    71a8:      	ldr	x4, [x3]
    71ac:      	ldr	x3, [x3, #0x8]
    71b0:      	fmov	d31, x3
    71b4:      	mov	x3, x4
    71b8:      	fmov	x4, d31
    71bc:      	mov	x5, x4
    71c0:      	mov	x4, x3
    71c4:      	mov	x3, #0x1                ; =1
    71c8:      	b	0x71d8 <_stogir.conditional.validate+0x14c>
    71cc:      	movz	x3, #0x0, lsl #48
    71d0:      	movz	x4, #0x0, lsl #48
    71d4:      	movz	x5, #0x0, lsl #48
    71d8:      	lsr	w3, w3, #0
    71dc:      	lsr	x16, x3, #0
    71e0:      	cmp	x16, #0x1
    71e4:      	b.eq	0x7200 <_stogir.conditional.validate+0x174>
    71e8:      	b.lo	0x71f0 <_stogir.conditional.validate+0x164>
    71ec:      	b	0x7204 <_stogir.conditional.validate+0x178>
    71f0:      	cmp	x16, #0x0
    71f4:      	b.eq	0x71fc <_stogir.conditional.validate+0x170>
    71f8:      	b	0x7204 <_stogir.conditional.validate+0x178>
    71fc:      	b	0x7208 <_stogir.conditional.validate+0x17c>
    7200:      	b	0x7228 <_stogir.conditional.validate+0x19c>
    7204:      	b	0x72fc <_stogir.conditional.validate+0x270>
    7208:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007208:  ARM64_RELOC_PAGE21	l_stogir.403
    720c:      	ldr	x16, [x16]
		000000000000720c:  ARM64_RELOC_PAGEOFF12	l_stogir.403
    7210:      	orr	x0, x16, xzr
    7214:      	mov	x19, x8
    7218:      	mov	x1, x0
    721c:      	mov	x0, #0x1                ; =1
    7220:      	mov	x2, #0x18               ; =24
    7224:      	b	0x724c <_stogir.conditional.validate+0x1c0>
    7228:      	cmp	x1, #0x0
    722c:      	b.gt	0x7274 <_stogir.conditional.validate+0x1e8>
    7230:      	mov	x19, x8
    7234:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007234:  ARM64_RELOC_PAGE21	l_stogir.404
    7238:      	ldr	x16, [x16]
		0000000000007238:  ARM64_RELOC_PAGEOFF12	l_stogir.404
    723c:      	orr	x0, x16, xzr
    7240:      	mov	x1, x0
    7244:      	mov	x0, #0x1                ; =1
    7248:      	mov	x2, #0x18               ; =24
    724c:      	str	x0, [x19]
    7250:      	str	x1, [x19, #0x8]
    7254:      	str	x2, [x19, #0x10]
    7258:      	ldr	x19, [sp, #0x30]
    725c:      	ldr	x29, [sp]
    7260:      	ldr	x30, [sp, #0x8]
    7264:      	add	sp, sp, #0x40
    7268:      	ret
    726c:      	movz	x4, #0x0, lsl #48
    7270:      	b	0x715c <_stogir.conditional.validate+0xd0>
    7274:      	uxtb	w1, w4
    7278:      	cmp	x1, #0x3c
    727c:      	b.ne	0x7304 <_stogir.conditional.validate+0x278>
    7280:      	ldr	x1, [x0, #0x78]
    7284:      	add	x1, x2, x1
    7288:      	ldr	w1, [x1]
    728c:      	sxtw	x1, w1
    7290:      	cmp	x1, #0x3
    7294:      	b.ne	0x730c <_stogir.conditional.validate+0x280>
    7298:      	lsr	w1, w5, #0
    729c:      	lsr	w2, w4, #0
    72a0:      	lsr	x3, x4, #32
    72a4:      	lsr	w1, w1, #0
    72a8:      	lsr	x4, x5, #32
    72ac:      	lsr	w3, w3, #0
    72b0:      	lsr	w4, w4, #0
    72b4:      	ubfx	x2, x2, #8, #8
    72b8:      	lsr	w2, w2, #0
    72bc:      	mov	x19, x8
    72c0:      	add	x8, sp, #0x10
    72c4:      	fmov	s31, w1
    72c8:      	mov	w1, w2
    72cc:      	mov	w2, w3
    72d0:      	fmov	w3, s31
    72d4:      	bl	0x72d4 <_stogir.conditional.validate+0x248>
		00000000000072d4:  ARM64_RELOC_BRANCH26	_stogir.conditional.operands
    72d8:      	add	x16, sp, #0x10
    72dc:      	ldr	x0, [x16]
    72e0:      	add	x16, sp, #0x10
    72e4:      	ldr	x1, [x16, #0x8]
    72e8:      	add	x16, sp, #0x10
    72ec:      	ldr	x2, [x16, #0x10]
    72f0:      	b	0x724c <_stogir.conditional.validate+0x1c0>
    72f4:      	movz	x4, #0x0, lsl #48
    72f8:      	b	0x7154 <_stogir.conditional.validate+0xc8>
    72fc:      	brk	#0
    7300:      	b	0x72fc <_stogir.conditional.validate+0x270>
    7304:      	mov	x19, x8
    7308:      	b	0x7234 <_stogir.conditional.validate+0x1a8>
    730c:      	mov	x19, x8
    7310:      	b	0x7234 <_stogir.conditional.validate+0x1a8>

0000000000007314 <_stogir.floating.validate>:
    7314:      	sub	sp, sp, #0x50
    7318:      	str	x29, [sp]
    731c:      	str	x30, [sp, #0x8]
    7320:      	mov	x29, sp
    7324:      	str	x19, [sp, #0x40]
    7328:      	sxtw	x1, w1
    732c:      	lsl	x2, x1, #2
    7330:      	cmp	x1, #0x0
    7334:      	cset	w3, gt
    7338:      	movz	x16, #0x0, lsl #48
    733c:      	sub	x4, x16, x1
    7340:      	sub	x5, x4, #0x1
    7344:      	uxtb	w16, w3
    7348:      	cmp	w16, wzr
    734c:      	b.eq	0x738c <_stogir.floating.validate+0x78>
    7350:      	ldr	x4, [x0, #0x8]
    7354:      	cmp	x1, x4
    7358:      	b.ge	0x73e0 <_stogir.floating.validate+0xcc>
    735c:      	add	x4, x0, #0x78
    7360:      	ldr	x4, [x4, #0x8]
    7364:      	cmp	x1, x4
    7368:      	b.ge	0x7504 <_stogir.floating.validate+0x1f0>
    736c:      	ldr	x4, [x0, #0x78]
    7370:      	add	x4, x2, x4
    7374:      	ldr	w4, [x4]
    7378:      	sxtw	x4, w4
    737c:      	cmp	x4, #0x0
    7380:      	cset	w4, ge
    7384:      	ubfx	x4, x4, #0, #8
    7388:      	b	0x7508 <_stogir.floating.validate+0x1f4>
    738c:      	cmp	x1, #0x0
    7390:      	b.ge	0x73e8 <_stogir.floating.validate+0xd4>
    7394:      	add	x6, x0, #0x28
    7398:      	add	x7, x0, #0x50
    739c:      	ldr	x6, [x6, #0x8]
    73a0:      	ldr	x7, [x7, #0x8]
    73a4:      	cmp	x6, x7
    73a8:      	b.ne	0x73d8 <_stogir.floating.validate+0xc4>
    73ac:      	cmp	x4, x6
    73b0:      	b.gt	0x7590 <_stogir.floating.validate+0x27c>
    73b4:      	lsl	x4, x5, #2
    73b8:      	ldr	x6, [x0, #0x50]
    73bc:      	add	x4, x4, x6
    73c0:      	ldr	w4, [x4]
    73c4:      	sxtw	x4, w4
    73c8:      	cmp	x4, #0x0
    73cc:      	cset	w4, gt
    73d0:      	ubfx	x4, x4, #0, #8
    73d4:      	b	0x7594 <_stogir.floating.validate+0x280>
    73d8:      	movz	x4, #0x0, lsl #48
    73dc:      	b	0x73ec <_stogir.floating.validate+0xd8>
    73e0:      	movz	x4, #0x0, lsl #48
    73e4:      	b	0x73ec <_stogir.floating.validate+0xd8>
    73e8:      	movz	x4, #0x0, lsl #48
    73ec:      	cmp	x4, #0x0
    73f0:      	b.eq	0x7454 <_stogir.floating.validate+0x140>
    73f4:      	uxtb	w16, w3
    73f8:      	cmp	w16, wzr
    73fc:      	b.eq	0x7424 <_stogir.floating.validate+0x110>
    7400:      	lsl	x3, x1, #4
    7404:      	ldr	x4, [x0]
    7408:      	add	x3, x3, x4
    740c:      	ldr	x4, [x3]
    7410:      	ldr	x3, [x3, #0x8]
    7414:      	fmov	d31, x3
    7418:      	mov	x3, x4
    741c:      	fmov	x4, d31
    7420:      	b	0x7444 <_stogir.floating.validate+0x130>
    7424:      	lsl	x3, x5, #4
    7428:      	ldr	x4, [x0, #0x28]
    742c:      	add	x3, x3, x4
    7430:      	ldr	x4, [x3]
    7434:      	ldr	x3, [x3, #0x8]
    7438:      	fmov	d31, x3
    743c:      	mov	x3, x4
    7440:      	fmov	x4, d31
    7444:      	mov	x5, x4
    7448:      	mov	x4, x3
    744c:      	mov	x3, #0x1                ; =1
    7450:      	b	0x7460 <_stogir.floating.validate+0x14c>
    7454:      	movz	x3, #0x0, lsl #48
    7458:      	movz	x4, #0x0, lsl #48
    745c:      	movz	x5, #0x0, lsl #48
    7460:      	lsr	w3, w3, #0
    7464:      	lsr	x16, x3, #0
    7468:      	cmp	x16, #0x1
    746c:      	b.eq	0x7488 <_stogir.floating.validate+0x174>
    7470:      	b.lo	0x7478 <_stogir.floating.validate+0x164>
    7474:      	b	0x748c <_stogir.floating.validate+0x178>
    7478:      	cmp	x16, #0x0
    747c:      	b.eq	0x7484 <_stogir.floating.validate+0x170>
    7480:      	b	0x748c <_stogir.floating.validate+0x178>
    7484:      	b	0x7490 <_stogir.floating.validate+0x17c>
    7488:      	b	0x74cc <_stogir.floating.validate+0x1b8>
    748c:      	b	0x784c <_stogir.floating.validate+0x538>
    7490:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007490:  ARM64_RELOC_PAGE21	l_stogir.405
    7494:      	ldr	x16, [x16]
		0000000000007494:  ARM64_RELOC_PAGEOFF12	l_stogir.405
    7498:      	orr	x0, x16, xzr
    749c:      	mov	x19, x8
    74a0:      	mov	x1, x0
    74a4:      	mov	x0, #0x1                ; =1
    74a8:      	mov	x2, #0x1c               ; =28
    74ac:      	str	x0, [x19]
    74b0:      	str	x1, [x19, #0x8]
    74b4:      	str	x2, [x19, #0x10]
    74b8:      	ldr	x19, [sp, #0x40]
    74bc:      	ldr	x29, [sp]
    74c0:      	ldr	x30, [sp, #0x8]
    74c4:      	add	sp, sp, #0x50
    74c8:      	ret
    74cc:      	add	x16, sp, #0x10
    74d0:      	str	x4, [x16]
    74d4:      	add	x16, sp, #0x10
    74d8:      	str	x5, [x16, #0x8]
    74dc:      	cmp	x1, #0x0
    74e0:      	b.gt	0x750c <_stogir.floating.validate+0x1f8>
    74e4:      	mov	x19, x8
    74e8:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		00000000000074e8:  ARM64_RELOC_PAGE21	l_stogir.406
    74ec:      	ldr	x16, [x16]
		00000000000074ec:  ARM64_RELOC_PAGEOFF12	l_stogir.406
    74f0:      	orr	x0, x16, xzr
    74f4:      	mov	x1, x0
    74f8:      	mov	x0, #0x1                ; =1
    74fc:      	mov	x2, #0x1c               ; =28
    7500:      	b	0x74ac <_stogir.floating.validate+0x198>
    7504:      	movz	x4, #0x0, lsl #48
    7508:      	b	0x73e4 <_stogir.floating.validate+0xd0>
    750c:      	uxtb	w4, w4
    7510:      	orr	x1, x4, xzr
    7514:      	cmp	x1, #0xe
    7518:      	cset	w3, ge
    751c:      	cmp	x1, #0x19
    7520:      	cset	w5, le
    7524:      	cmp	x1, #0x1f
    7528:      	cset	w6, eq
    752c:      	cmp	x1, #0x20
    7530:      	cset	w7, eq
    7534:      	uxtb	w16, w3
    7538:      	cmp	w16, wzr
    753c:      	b.eq	0x7598 <_stogir.floating.validate+0x284>
    7540:      	uxtb	w16, w5
    7544:      	cmp	w16, wzr
    7548:      	b.eq	0x7598 <_stogir.floating.validate+0x284>
    754c:      	cmp	x1, #0x1d
    7550:      	cset	w1, eq
    7554:      	ldr	x9, [x0, #0x78]
    7558:      	add	x2, x2, x9
    755c:      	ldr	w2, [x2]
    7560:      	uxtb	w16, w6
    7564:      	cmp	w16, wzr
    7568:      	b.ne	0x75d8 <_stogir.floating.validate+0x2c4>
    756c:      	uxtb	w16, w7
    7570:      	cmp	w16, wzr
    7574:      	b.ne	0x75d8 <_stogir.floating.validate+0x2c4>
    7578:      	uxtb	w16, w1
    757c:      	cmp	w16, wzr
    7580:      	mov	x16, #0x3               ; =3
    7584:      	mov	x17, #0x2               ; =2
    7588:      	csel	x6, x16, x17, ne
    758c:      	b	0x75dc <_stogir.floating.validate+0x2c8>
    7590:      	movz	x4, #0x0, lsl #48
    7594:      	b	0x73dc <_stogir.floating.validate+0xc8>
    7598:      	uxtb	w16, w6
    759c:      	cmp	w16, wzr
    75a0:      	b.ne	0x754c <_stogir.floating.validate+0x238>
    75a4:      	uxtb	w16, w7
    75a8:      	cmp	w16, wzr
    75ac:      	b.ne	0x754c <_stogir.floating.validate+0x238>
    75b0:      	cmp	x1, #0x1a
    75b4:      	b.lt	0x75c0 <_stogir.floating.validate+0x2ac>
    75b8:      	cmp	x1, #0x1d
    75bc:      	b.le	0x754c <_stogir.floating.validate+0x238>
    75c0:      	cmp	x1, #0x3a
    75c4:      	b.eq	0x754c <_stogir.floating.validate+0x238>
    75c8:      	cmp	x1, #0x3b
    75cc:      	b.eq	0x754c <_stogir.floating.validate+0x238>
    75d0:      	mov	x19, x8
    75d4:      	b	0x74e8 <_stogir.floating.validate+0x1d4>
    75d8:      	mov	x6, #0x1                ; =1
    75dc:      	sxtw	x2, w2
    75e0:      	lsr	w6, w6, #0
    75e4:      	sxtw	x6, w6
    75e8:      	cmp	x2, x6
    75ec:      	b.ne	0x785c <_stogir.floating.validate+0x548>
    75f0:      	add	x16, sp, #0x10
    75f4:      	ldr	w2, [x16, #0x4]
    75f8:      	sxtw	x2, w2
    75fc:      	cmp	x2, #0x0
    7600:      	cset	w6, gt
    7604:      	movz	x16, #0x0, lsl #48
    7608:      	sub	x7, x16, x2
    760c:      	sub	x9, x7, #0x1
    7610:      	uxtb	w16, w6
    7614:      	cmp	w16, wzr
    7618:      	b.eq	0x7678 <_stogir.floating.validate+0x364>
    761c:      	ldr	x7, [x0, #0x8]
    7620:      	cmp	x2, x7
    7624:      	b.ge	0x76c4 <_stogir.floating.validate+0x3b0>
    7628:      	add	x7, x0, #0x78
    762c:      	ldr	x7, [x7, #0x8]
    7630:      	cmp	x2, x7
    7634:      	b.ge	0x77a4 <_stogir.floating.validate+0x490>
    7638:      	lsl	x7, x2, #2
    763c:      	ldr	x10, [x0, #0x78]
    7640:      	add	x7, x7, x10
    7644:      	ldr	w7, [x7]
    7648:      	sxtw	x7, w7
    764c:      	cmp	x7, #0x0
    7650:      	cset	w7, ge
    7654:      	ubfx	x7, x7, #0, #8
    7658:      	b	0x77a8 <_stogir.floating.validate+0x494>
    765c:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		000000000000765c:  ARM64_RELOC_PAGE21	l_stogir.407
    7660:      	ldr	x16, [x16]
		0000000000007660:  ARM64_RELOC_PAGEOFF12	l_stogir.407
    7664:      	orr	x0, x16, xzr
    7668:      	mov	x1, x0
    766c:      	mov	x0, #0x1                ; =1
    7670:      	mov	x2, #0x1d               ; =29
    7674:      	b	0x7500 <_stogir.floating.validate+0x1ec>
    7678:      	cmp	x2, #0x0
    767c:      	b.ge	0x76cc <_stogir.floating.validate+0x3b8>
    7680:      	add	x10, x0, #0x28
    7684:      	add	x11, x0, #0x50
    7688:      	ldr	x10, [x10, #0x8]
    768c:      	ldr	x11, [x11, #0x8]
    7690:      	cmp	x10, x11
    7694:      	b.ne	0x779c <_stogir.floating.validate+0x488>
    7698:      	cmp	x7, x10
    769c:      	b.gt	0x7844 <_stogir.floating.validate+0x530>
    76a0:      	lsl	x7, x9, #2
    76a4:      	ldr	x10, [x0, #0x50]
    76a8:      	add	x7, x7, x10
    76ac:      	ldr	w7, [x7]
    76b0:      	sxtw	x7, w7
    76b4:      	cmp	x7, #0x0
    76b8:      	cset	w7, gt
    76bc:      	ubfx	x7, x7, #0, #8
    76c0:      	b	0x7848 <_stogir.floating.validate+0x534>
    76c4:      	movz	x7, #0x0, lsl #48
    76c8:      	b	0x76d0 <_stogir.floating.validate+0x3bc>
    76cc:      	movz	x7, #0x0, lsl #48
    76d0:      	cmp	x7, #0x0
    76d4:      	b.eq	0x7714 <_stogir.floating.validate+0x400>
    76d8:      	uxtb	w16, w6
    76dc:      	cmp	w16, wzr
    76e0:      	b.eq	0x76f8 <_stogir.floating.validate+0x3e4>
    76e4:      	lsl	x2, x2, #4
    76e8:      	ldr	x6, [x0]
    76ec:      	add	x2, x2, x6
    76f0:      	ldr	x2, [x2]
    76f4:      	b	0x7708 <_stogir.floating.validate+0x3f4>
    76f8:      	lsl	x2, x9, #4
    76fc:      	ldr	x6, [x0, #0x28]
    7700:      	add	x2, x2, x6
    7704:      	ldr	x2, [x2]
    7708:      	mov	x6, x2
    770c:      	mov	x2, #0x1                ; =1
    7710:      	b	0x771c <_stogir.floating.validate+0x408>
    7714:      	movz	x2, #0x0, lsl #48
    7718:      	movz	x6, #0x0, lsl #48
    771c:      	lsr	w2, w2, #0
    7720:      	lsr	x16, x2, #0
    7724:      	cmp	x16, #0x1
    7728:      	b.eq	0x7744 <_stogir.floating.validate+0x430>
    772c:      	b.lo	0x7734 <_stogir.floating.validate+0x420>
    7730:      	b	0x7748 <_stogir.floating.validate+0x434>
    7734:      	cmp	x16, #0x0
    7738:      	b.eq	0x7740 <_stogir.floating.validate+0x42c>
    773c:      	b	0x7748 <_stogir.floating.validate+0x434>
    7740:      	b	0x774c <_stogir.floating.validate+0x438>
    7744:      	b	0x776c <_stogir.floating.validate+0x458>
    7748:      	b	0x7854 <_stogir.floating.validate+0x540>
    774c:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		000000000000774c:  ARM64_RELOC_PAGE21	l_stogir.408
    7750:      	ldr	x16, [x16]
		0000000000007750:  ARM64_RELOC_PAGEOFF12	l_stogir.408
    7754:      	orr	x0, x16, xzr
    7758:      	mov	x19, x8
    775c:      	mov	x1, x0
    7760:      	mov	x0, #0x1                ; =1
    7764:      	mov	x2, #0x18               ; =24
    7768:      	b	0x7674 <_stogir.floating.validate+0x360>
    776c:      	lsr	w6, w6, #0
    7770:      	add	x16, sp, #0x10
    7774:      	ldr	w2, [x16]
    7778:      	ubfx	x6, x6, #8, #8
    777c:      	uxtb	w16, w3
    7780:      	cmp	w16, wzr
    7784:      	b.eq	0x7800 <_stogir.floating.validate+0x4ec>
    7788:      	uxtb	w16, w5
    778c:      	cmp	w16, wzr
    7790:      	b.eq	0x7800 <_stogir.floating.validate+0x4ec>
    7794:      	mov	x3, #0x1                ; =1
    7798:      	b	0x7804 <_stogir.floating.validate+0x4f0>
    779c:      	movz	x7, #0x0, lsl #48
    77a0:      	b	0x76d0 <_stogir.floating.validate+0x3bc>
    77a4:      	movz	x7, #0x0, lsl #48
    77a8:      	b	0x76c8 <_stogir.floating.validate+0x3b4>
    77ac:      	movz	x1, #0x0, lsl #48
    77b0:      	lsr	w2, w2, #0
    77b4:      	lsr	w3, w3, #0
    77b8:      	lsr	w4, w4, #0
    77bc:      	lsr	w6, w6, #0
    77c0:      	lsr	w1, w1, #0
    77c4:      	mov	w5, w1
    77c8:      	mov	w1, w4
    77cc:      	mov	w4, w3
    77d0:      	mov	w3, w2
    77d4:      	mov	w2, w6
    77d8:      	mov	x19, x8
    77dc:      	add	x8, sp, #0x20
    77e0:      	bl	0x77e0 <_stogir.floating.validate+0x4cc>
		00000000000077e0:  ARM64_RELOC_BRANCH26	_stogir.floating.operands
    77e4:      	add	x16, sp, #0x20
    77e8:      	ldr	x0, [x16]
    77ec:      	add	x16, sp, #0x20
    77f0:      	ldr	x1, [x16, #0x8]
    77f4:      	add	x16, sp, #0x20
    77f8:      	ldr	x2, [x16, #0x10]
    77fc:      	b	0x7674 <_stogir.floating.validate+0x360>
    7800:      	orr	x3, x6, xzr
    7804:      	lsr	w3, w3, #0
    7808:      	ubfx	x2, x2, #8, #8
    780c:      	sxtw	x3, w3
    7810:      	cmp	x2, x3
    7814:      	b.ne	0x7864 <_stogir.floating.validate+0x550>
    7818:      	add	x16, sp, #0x10
    781c:      	ldr	w2, [x16, #0x4]
    7820:      	add	x16, sp, #0x10
    7824:      	ldr	w3, [x16, #0x8]
    7828:      	uxtb	w16, w1
    782c:      	cmp	w16, wzr
    7830:      	b.eq	0x77ac <_stogir.floating.validate+0x498>
    7834:      	add	x16, sp, #0x10
    7838:      	ldr	w1, [x16, #0xc]
    783c:      	sxtw	x1, w1
    7840:      	b	0x77b0 <_stogir.floating.validate+0x49c>
    7844:      	movz	x7, #0x0, lsl #48
    7848:      	b	0x77a0 <_stogir.floating.validate+0x48c>
    784c:      	brk	#0
    7850:      	b	0x784c <_stogir.floating.validate+0x538>
    7854:      	brk	#0
    7858:      	b	0x7854 <_stogir.floating.validate+0x540>
    785c:      	mov	x19, x8
    7860:      	b	0x74e8 <_stogir.floating.validate+0x1d4>
    7864:      	mov	x19, x8
    7868:      	b	0x765c <_stogir.floating.validate+0x348>

000000000000786c <_stogir.types.integer?>:
    786c:      	sxtw	x0, w0
    7870:      	cmp	x0, #0x1
    7874:      	b.lt	0x7888 <_stogir.types.integer?+0x1c>
    7878:      	cmp	x0, #0xb
    787c:      	cset	w0, le
    7880:      	ubfx	x0, x0, #0, #8
    7884:      	b	0x788c <_stogir.types.integer?+0x20>
    7888:      	movz	x0, #0x0, lsl #48
    788c:      	ret

0000000000007890 <_stogir.integer-unary.valid-type?>:
    7890:      	sxtw	x0, w0
    7894:      	cmp	x0, #0x2d
    7898:      	cset	w2, eq
    789c:      	cmp	x0, #0x1f
    78a0:      	cset	w3, eq
    78a4:      	cmp	x0, #0x20
    78a8:      	cset	w4, eq
    78ac:      	cmp	x0, #0x36
    78b0:      	cset	w5, eq
    78b4:      	uxtb	w16, w3
    78b8:      	cmp	w16, wzr
    78bc:      	b.ne	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78c0:      	uxtb	w16, w4
    78c4:      	cmp	w16, wzr
    78c8:      	b.ne	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78cc:      	uxtb	w16, w2
    78d0:      	cmp	w16, wzr
    78d4:      	b.ne	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78d8:      	uxtb	w16, w5
    78dc:      	cmp	w16, wzr
    78e0:      	b.ne	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78e4:      	cmp	x0, #0x37
    78e8:      	b.eq	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78ec:      	cmp	x0, #0x38
    78f0:      	b.eq	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78f4:      	cmp	x0, #0x39
    78f8:      	b.eq	0x7904 <_stogir.integer-unary.valid-type?+0x74>
    78fc:      	movz	x0, #0x0, lsl #48
    7900:      	b	0x793c <_stogir.integer-unary.valid-type?+0xac>
    7904:      	sxtw	x1, w1
    7908:      	cmp	x1, #0x1
    790c:      	b.lt	0x7938 <_stogir.integer-unary.valid-type?+0xa8>
    7910:      	cmp	x1, #0xb
    7914:      	cset	w0, le
    7918:      	uxtb	w16, w0
    791c:      	cmp	w16, wzr
    7920:      	b.eq	0x7938 <_stogir.integer-unary.valid-type?+0xa8>
    7924:      	uxtb	w16, w2
    7928:      	cmp	w16, wzr
    792c:      	b.eq	0x7948 <_stogir.integer-unary.valid-type?+0xb8>
    7930:      	mov	x0, #0x1                ; =1
    7934:      	b	0x7944 <_stogir.integer-unary.valid-type?+0xb4>
    7938:      	movz	x0, #0x0, lsl #48
    793c:      	ret
    7940:      	mov	x0, #0x1                ; =1
    7944:      	b	0x793c <_stogir.integer-unary.valid-type?+0xac>
    7948:      	cmp	x1, #0x1
    794c:      	b.ne	0x7958 <_stogir.integer-unary.valid-type?+0xc8>
    7950:      	movz	x0, #0x0, lsl #48
    7954:      	b	0x7944 <_stogir.integer-unary.valid-type?+0xb4>
    7958:      	cmp	x1, #0x6
    795c:      	cset	w2, eq
    7960:      	uxtb	w16, w3
    7964:      	cmp	w16, wzr
    7968:      	b.eq	0x797c <_stogir.integer-unary.valid-type?+0xec>
    796c:      	uxtb	w16, w2
    7970:      	cmp	w16, wzr
    7974:      	cset	x0, eq
    7978:      	b	0x7944 <_stogir.integer-unary.valid-type?+0xb4>
    797c:      	uxtb	w16, w4
    7980:      	cmp	w16, wzr
    7984:      	b.eq	0x79a0 <_stogir.integer-unary.valid-type?+0x110>
    7988:      	cmp	x1, #0x7
    798c:      	b.lt	0x7998 <_stogir.integer-unary.valid-type?+0x108>
    7990:      	ubfx	x0, x0, #0, #8
    7994:      	b	0x799c <_stogir.integer-unary.valid-type?+0x10c>
    7998:      	movz	x0, #0x0, lsl #48
    799c:      	b	0x7944 <_stogir.integer-unary.valid-type?+0xb4>
    79a0:      	uxtb	w16, w5
    79a4:      	cmp	w16, wzr
    79a8:      	b.eq	0x7940 <_stogir.integer-unary.valid-type?+0xb0>
    79ac:      	cmp	x1, #0x3
    79b0:      	b.ne	0x79cc <_stogir.integer-unary.valid-type?+0x13c>
    79b4:      	mov	x0, #0x1                ; =1
    79b8:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>
    79bc:      	cmp	x1, #0xb
    79c0:      	cset	w0, eq
    79c4:      	ubfx	x0, x0, #0, #8
    79c8:      	b	0x7944 <_stogir.integer-unary.valid-type?+0xb4>
    79cc:      	cmp	x1, #0x4
    79d0:      	b.ne	0x79dc <_stogir.integer-unary.valid-type?+0x14c>
    79d4:      	mov	x0, #0x1                ; =1
    79d8:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>
    79dc:      	cmp	x1, #0x5
    79e0:      	b.ne	0x79ec <_stogir.integer-unary.valid-type?+0x15c>
    79e4:      	mov	x0, #0x1                ; =1
    79e8:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>
    79ec:      	uxtb	w16, w2
    79f0:      	cmp	w16, wzr
    79f4:      	b.eq	0x7a00 <_stogir.integer-unary.valid-type?+0x170>
    79f8:      	mov	x0, #0x1                ; =1
    79fc:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>
    7a00:      	cmp	x1, #0x9
    7a04:      	b.ne	0x7a10 <_stogir.integer-unary.valid-type?+0x180>
    7a08:      	mov	x0, #0x1                ; =1
    7a0c:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>
    7a10:      	cmp	x1, #0xa
    7a14:      	b.ne	0x79bc <_stogir.integer-unary.valid-type?+0x12c>
    7a18:      	mov	x0, #0x1                ; =1
    7a1c:      	b	0x79c8 <_stogir.integer-unary.valid-type?+0x138>

0000000000007a20 <_stogir.integer-binary.valid-type?>:
    7a20:      	sxtw	x0, w0
    7a24:      	cmp	x0, #0x3a
    7a28:      	cset	w2, eq
    7a2c:      	cmp	x0, #0x3b
    7a30:      	cset	w3, eq
    7a34:      	cmp	x0, #0x1a
    7a38:      	b.lt	0x7a8c <_stogir.integer-binary.valid-type?+0x6c>
    7a3c:      	cmp	x0, #0x1e
    7a40:      	b.gt	0x7a8c <_stogir.integer-binary.valid-type?+0x6c>
    7a44:      	sxtw	x1, w1
    7a48:      	cmp	x1, #0x1
    7a4c:      	b.lt	0x7abc <_stogir.integer-binary.valid-type?+0x9c>
    7a50:      	cmp	x1, #0xb
    7a54:      	b.gt	0x7abc <_stogir.integer-binary.valid-type?+0x9c>
    7a58:      	cmp	x1, #0x1
    7a5c:      	b.ne	0x7ac4 <_stogir.integer-binary.valid-type?+0xa4>
    7a60:      	cmp	x0, #0x2e
    7a64:      	b.eq	0x7acc <_stogir.integer-binary.valid-type?+0xac>
    7a68:      	cmp	x0, #0x2f
    7a6c:      	b.eq	0x7acc <_stogir.integer-binary.valid-type?+0xac>
    7a70:      	cmp	x0, #0x30
    7a74:      	b.eq	0x7acc <_stogir.integer-binary.valid-type?+0xac>
    7a78:      	uxtb	w16, w2
    7a7c:      	cmp	w16, wzr
    7a80:      	b.eq	0x7ad4 <_stogir.integer-binary.valid-type?+0xb4>
    7a84:      	mov	x0, #0x1                ; =1
    7a88:      	b	0x7adc <_stogir.integer-binary.valid-type?+0xbc>
    7a8c:      	cmp	x0, #0x2e
    7a90:      	b.lt	0x7a9c <_stogir.integer-binary.valid-type?+0x7c>
    7a94:      	cmp	x0, #0x35
    7a98:      	b.le	0x7a44 <_stogir.integer-binary.valid-type?+0x24>
    7a9c:      	uxtb	w16, w2
    7aa0:      	cmp	w16, wzr
    7aa4:      	b.ne	0x7a44 <_stogir.integer-binary.valid-type?+0x24>
    7aa8:      	uxtb	w16, w3
    7aac:      	cmp	w16, wzr
    7ab0:      	b.ne	0x7a44 <_stogir.integer-binary.valid-type?+0x24>
    7ab4:      	movz	x0, #0x0, lsl #48
    7ab8:      	b	0x7ac0 <_stogir.integer-binary.valid-type?+0xa0>
    7abc:      	movz	x0, #0x0, lsl #48
    7ac0:      	ret
    7ac4:      	mov	x0, #0x1                ; =1
    7ac8:      	b	0x7ac0 <_stogir.integer-binary.valid-type?+0xa0>
    7acc:      	mov	x0, #0x1                ; =1
    7ad0:      	b	0x7ac8 <_stogir.integer-binary.valid-type?+0xa8>
    7ad4:      	ubfx	x3, x3, #0, #8
    7ad8:      	mov	x0, x3
    7adc:      	b	0x7ad0 <_stogir.integer-binary.valid-type?+0xb0>

0000000000007ae0 <_coil.core.Len$slice$len__u8>:
    7ae0:      	mov	x0, x1
    7ae4:      	ret

0000000000007ae8 <_inherent$slice$data__u8>:
    7ae8:      	ret

0000000000007aec <_coil.mem.eql__u8>:
    7aec:      	sub	sp, sp, #0x10
    7af0:      	str	x29, [sp]
    7af4:      	str	x30, [sp, #0x8]
    7af8:      	mov	x29, sp
    7afc:      	cmp	x2, #0x0
    7b00:      	b.ne	0x7b0c <_coil.mem.eql__u8+0x20>
    7b04:      	mov	x0, #0x1                ; =1
    7b08:      	b	0x7b28 <_coil.mem.eql__u8+0x3c>
    7b0c:      	lsr	x2, x2, #0
    7b10:      	bl	0x7b10 <_coil.mem.eql__u8+0x24>
		0000000000007b10:  ARM64_RELOC_BRANCH26	_memcmp
    7b14:      	lsr	w0, w0, #0
    7b18:      	sxtw	x0, w0
    7b1c:      	cmp	x0, #0x0
    7b20:      	cset	w0, eq
    7b24:      	ubfx	x0, x0, #0, #8
    7b28:      	ldr	x29, [sp]
    7b2c:      	ldr	x30, [sp, #0x8]
    7b30:      	add	sp, sp, #0x10
    7b34:      	ret

0000000000007b38 <_stogir.opcode.count>:
    7b38:      	mov	x0, #0x83               ; =131
    7b3c:      	ret

0000000000007b40 <_stogir.types.valid-scalar?>:
    7b40:      	sxtw	x0, w0
    7b44:      	cmp	x0, #0x0
    7b48:      	b.lt	0x7b5c <_stogir.types.valid-scalar?+0x1c>
    7b4c:      	cmp	x0, #0xd
    7b50:      	cset	w0, le
    7b54:      	ubfx	x0, x0, #0, #8
    7b58:      	b	0x7b60 <_stogir.types.valid-scalar?+0x20>
    7b5c:      	movz	x0, #0x0, lsl #48
    7b60:      	ret

0000000000007b64 <_stogir.types.vector?>:
    7b64:      	sxtw	x0, w0
    7b68:      	cmp	x0, #0xf
    7b6c:      	b.le	0x7ba8 <_stogir.types.vector?+0x44>
    7b70:      	cmp	x0, #0x80
    7b74:      	b.ge	0x7bb8 <_stogir.types.vector?+0x54>
    7b78:      	and	x1, x0, #0xf
    7b7c:      	lsr	w1, w1, #0
    7b80:      	sxtw	x1, w1
    7b84:      	cmp	x1, #0x1
    7b88:      	b.lt	0x7bb0 <_stogir.types.vector?+0x4c>
    7b8c:      	and	x0, x0, #0xf
    7b90:      	lsr	w0, w0, #0
    7b94:      	sxtw	x0, w0
    7b98:      	cmp	x0, #0xd
    7b9c:      	cset	w0, le
    7ba0:      	ubfx	x0, x0, #0, #8
    7ba4:      	b	0x7bb4 <_stogir.types.vector?+0x50>
    7ba8:      	movz	x0, #0x0, lsl #48
    7bac:      	b	0x7bb4 <_stogir.types.vector?+0x50>
    7bb0:      	movz	x0, #0x0, lsl #48
    7bb4:      	ret
    7bb8:      	movz	x0, #0x0, lsl #48
    7bbc:      	b	0x7bb4 <_stogir.types.vector?+0x50>

0000000000007bc0 <_coil.core.Get$slice$get__i8>:
    7bc0:      	lsr	x1, x2, #0
    7bc4:      	add	x0, x1, x0
    7bc8:      	ldrsb	w0, [x0]
    7bcc:      	sxtb	x0, w0
    7bd0:      	ret

0000000000007bd4 <_stogir.opcode.metadata>:
    7bd4:      	sub	sp, sp, #0x10
    7bd8:      	mov	x0, sp
    7bdc:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007bdc:  ARM64_RELOC_PAGE21	l_stogir.409
    7be0:      	ldr	x16, [x16]
		0000000000007be0:  ARM64_RELOC_PAGEOFF12	l_stogir.409
    7be4:      	orr	x1, x16, xzr
    7be8:      	str	x1, [x0]
    7bec:      	mov	x17, #0x83              ; =131
    7bf0:      	str	x17, [x0, #0x8]
    7bf4:      	ldr	x0, [sp]
    7bf8:      	ldr	x1, [sp, #0x8]
    7bfc:      	add	sp, sp, #0x10
    7c00:      	ret

0000000000007c04 <_coil.core.Get$slice$get__u32>:
    7c04:      	lsl	x1, x2, #2
    7c08:      	add	x0, x1, x0
    7c0c:      	ldr	w0, [x0]
    7c10:      	ret

0000000000007c14 <_stogir.opcode.operand-code-word>:
    7c14:      	sxtw	x1, w1
    7c18:      	cmp	x1, #0x0
    7c1c:      	b.le	0x7c30 <_stogir.opcode.operand-code-word+0x1c>
    7c20:      	cmp	x1, #0x4
    7c24:      	b.le	0x7c38 <_stogir.opcode.operand-code-word+0x24>
    7c28:      	mov	x1, #0x4                ; =4
    7c2c:      	b	0x7c44 <_stogir.opcode.operand-code-word+0x30>
    7c30:      	movz	x0, #0x0, lsl #48
    7c34:      	b	0x7c64 <_stogir.opcode.operand-code-word+0x50>
    7c38:      	sub	x1, x1, #0x1
    7c3c:      	lsr	w1, w1, #0
    7c40:      	sxtw	x1, w1
    7c44:      	ubfx	x0, x0, #0, #32
    7c48:      	lsl	x1, x1, #2
    7c4c:      	lsr	w1, w1, #0
    7c50:      	ubfx	x1, x1, #0, #32
    7c54:      	lsr	x0, x0, x1
    7c58:      	lsr	w0, w0, #0
    7c5c:      	and	x0, x0, #0xf
    7c60:      	lsr	w0, w0, #0
    7c64:      	ret

0000000000007c68 <_inherent$coil.arraylist.ArrayList$at__stogir.node.Node>:
    7c68:      	lsl	x1, x1, #4
    7c6c:      	ldr	x0, [x0]
    7c70:      	add	x0, x1, x0
    7c74:      	ret

0000000000007c78 <_coil.core.Len$coil.arraylist.ArrayList$len__stogir.strings.Entry>:
    7c78:      	ldr	x0, [x0, #0x8]
    7c7c:      	ret

0000000000007c80 <_coil.core.Len$coil.arraylist.ArrayList$len__u8>:
    7c80:      	ldr	x0, [x0, #0x8]
    7c84:      	ret

0000000000007c88 <_inherent$coil.arraylist.ArrayList$slice__u8>:
    7c88:      	sub	sp, sp, #0x10
    7c8c:      	mov	x1, sp
    7c90:      	ldr	x2, [x0]
    7c94:      	ldr	x0, [x0, #0x8]
    7c98:      	str	x2, [x1]
    7c9c:      	str	x0, [x1, #0x8]
    7ca0:      	ldr	x0, [sp]
    7ca4:      	ldr	x1, [sp, #0x8]
    7ca8:      	add	sp, sp, #0x10
    7cac:      	ret

0000000000007cb0 <_coil.slice.subslice__u8>:
    7cb0:      	sub	sp, sp, #0x10
    7cb4:      	mov	x1, sp
    7cb8:      	lsr	x4, x2, #0
    7cbc:      	sub	x2, x3, x2
    7cc0:      	add	x0, x4, x0
    7cc4:      	str	x0, [x1]
    7cc8:      	str	x2, [x1, #0x8]
    7ccc:      	ldr	x0, [sp]
    7cd0:      	ldr	x1, [sp, #0x8]
    7cd4:      	add	sp, sp, #0x10
    7cd8:      	ret

0000000000007cdc <_stogir.floating.operation?>:
    7cdc:      	sxtw	x0, w0
    7ce0:      	cmp	x0, #0xe
    7ce4:      	b.lt	0x7cf8 <_stogir.floating.operation?+0x1c>
    7ce8:      	cmp	x0, #0x19
    7cec:      	b.gt	0x7cf8 <_stogir.floating.operation?+0x1c>
    7cf0:      	mov	x0, #0x1                ; =1
    7cf4:      	b	0x7d24 <_stogir.floating.operation?+0x48>
    7cf8:      	cmp	x0, #0x1f
    7cfc:      	b.eq	0x7d20 <_stogir.floating.operation?+0x44>
    7d00:      	cmp	x0, #0x20
    7d04:      	b.eq	0x7d20 <_stogir.floating.operation?+0x44>
    7d08:      	cmp	x0, #0x1a
    7d0c:      	b.lt	0x7d38 <_stogir.floating.operation?+0x5c>
    7d10:      	cmp	x0, #0x1d
    7d14:      	b.gt	0x7d38 <_stogir.floating.operation?+0x5c>
    7d18:      	mov	x0, #0x1                ; =1
    7d1c:      	b	0x7d34 <_stogir.floating.operation?+0x58>
    7d20:      	mov	x0, #0x1                ; =1
    7d24:      	ret
    7d28:      	cmp	x0, #0x3b
    7d2c:      	cset	w0, eq
    7d30:      	ubfx	x0, x0, #0, #8
    7d34:      	b	0x7d24 <_stogir.floating.operation?+0x48>
    7d38:      	cmp	x0, #0x3a
    7d3c:      	b.ne	0x7d28 <_stogir.floating.operation?+0x4c>
    7d40:      	mov	x0, #0x1                ; =1
    7d44:      	b	0x7d34 <_stogir.floating.operation?+0x58>

0000000000007d48 <_stogir.types.floating?>:
    7d48:      	sxtw	x0, w0
    7d4c:      	cmp	x0, #0xc
    7d50:      	b.ne	0x7d5c <_stogir.types.floating?+0x14>
    7d54:      	mov	x0, #0x1                ; =1
    7d58:      	b	0x7d68 <_stogir.types.floating?+0x20>
    7d5c:      	cmp	x0, #0xd
    7d60:      	cset	w0, eq
    7d64:      	ubfx	x0, x0, #0, #8
    7d68:      	ret

0000000000007d6c <_stogir.vector-lanes.validate>:
    7d6c:      	sub	sp, sp, #0x50
    7d70:      	str	x29, [sp]
    7d74:      	str	x30, [sp, #0x8]
    7d78:      	mov	x29, sp
    7d7c:      	str	x19, [sp, #0x40]
    7d80:      	sxtw	x1, w1
    7d84:      	lsl	x3, x1, #2
    7d88:      	cmp	x1, #0x0
    7d8c:      	cset	w4, gt
    7d90:      	movz	x16, #0x0, lsl #48
    7d94:      	sub	x5, x16, x1
    7d98:      	sub	x6, x5, #0x1
    7d9c:      	uxtb	w16, w4
    7da0:      	cmp	w16, wzr
    7da4:      	b.eq	0x7de4 <_stogir.vector-lanes.validate+0x78>
    7da8:      	ldr	x5, [x0, #0x8]
    7dac:      	cmp	x1, x5
    7db0:      	b.ge	0x7e38 <_stogir.vector-lanes.validate+0xcc>
    7db4:      	add	x5, x0, #0x78
    7db8:      	ldr	x5, [x5, #0x8]
    7dbc:      	cmp	x1, x5
    7dc0:      	b.ge	0x7f5c <_stogir.vector-lanes.validate+0x1f0>
    7dc4:      	ldr	x5, [x0, #0x78]
    7dc8:      	add	x5, x3, x5
    7dcc:      	ldr	w5, [x5]
    7dd0:      	sxtw	x5, w5
    7dd4:      	cmp	x5, #0x0
    7dd8:      	cset	w5, ge
    7ddc:      	ubfx	x5, x5, #0, #8
    7de0:      	b	0x7f60 <_stogir.vector-lanes.validate+0x1f4>
    7de4:      	cmp	x1, #0x0
    7de8:      	b.ge	0x7e40 <_stogir.vector-lanes.validate+0xd4>
    7dec:      	add	x7, x0, #0x28
    7df0:      	add	x9, x0, #0x50
    7df4:      	ldr	x7, [x7, #0x8]
    7df8:      	ldr	x9, [x9, #0x8]
    7dfc:      	cmp	x7, x9
    7e00:      	b.ne	0x7e30 <_stogir.vector-lanes.validate+0xc4>
    7e04:      	cmp	x5, x7
    7e08:      	b.gt	0x7fa0 <_stogir.vector-lanes.validate+0x234>
    7e0c:      	lsl	x5, x6, #2
    7e10:      	ldr	x7, [x0, #0x50]
    7e14:      	add	x5, x5, x7
    7e18:      	ldr	w5, [x5]
    7e1c:      	sxtw	x5, w5
    7e20:      	cmp	x5, #0x0
    7e24:      	cset	w5, gt
    7e28:      	ubfx	x5, x5, #0, #8
    7e2c:      	b	0x7fa4 <_stogir.vector-lanes.validate+0x238>
    7e30:      	movz	x5, #0x0, lsl #48
    7e34:      	b	0x7e44 <_stogir.vector-lanes.validate+0xd8>
    7e38:      	movz	x5, #0x0, lsl #48
    7e3c:      	b	0x7e44 <_stogir.vector-lanes.validate+0xd8>
    7e40:      	movz	x5, #0x0, lsl #48
    7e44:      	cmp	x5, #0x0
    7e48:      	b.eq	0x7eac <_stogir.vector-lanes.validate+0x140>
    7e4c:      	uxtb	w16, w4
    7e50:      	cmp	w16, wzr
    7e54:      	b.eq	0x7e7c <_stogir.vector-lanes.validate+0x110>
    7e58:      	lsl	x4, x1, #4
    7e5c:      	ldr	x5, [x0]
    7e60:      	add	x4, x4, x5
    7e64:      	ldr	x5, [x4]
    7e68:      	ldr	x4, [x4, #0x8]
    7e6c:      	fmov	d31, x4
    7e70:      	mov	x4, x5
    7e74:      	fmov	x5, d31
    7e78:      	b	0x7e9c <_stogir.vector-lanes.validate+0x130>
    7e7c:      	lsl	x4, x6, #4
    7e80:      	ldr	x5, [x0, #0x28]
    7e84:      	add	x4, x4, x5
    7e88:      	ldr	x5, [x4]
    7e8c:      	ldr	x4, [x4, #0x8]
    7e90:      	fmov	d31, x4
    7e94:      	mov	x4, x5
    7e98:      	fmov	x5, d31
    7e9c:      	mov	x6, x5
    7ea0:      	mov	x5, x4
    7ea4:      	mov	x4, #0x1                ; =1
    7ea8:      	b	0x7eb8 <_stogir.vector-lanes.validate+0x14c>
    7eac:      	movz	x4, #0x0, lsl #48
    7eb0:      	movz	x5, #0x0, lsl #48
    7eb4:      	movz	x6, #0x0, lsl #48
    7eb8:      	lsr	w4, w4, #0
    7ebc:      	lsr	x16, x4, #0
    7ec0:      	cmp	x16, #0x1
    7ec4:      	b.eq	0x7ee0 <_stogir.vector-lanes.validate+0x174>
    7ec8:      	b.lo	0x7ed0 <_stogir.vector-lanes.validate+0x164>
    7ecc:      	b	0x7ee4 <_stogir.vector-lanes.validate+0x178>
    7ed0:      	cmp	x16, #0x0
    7ed4:      	b.eq	0x7edc <_stogir.vector-lanes.validate+0x170>
    7ed8:      	b	0x7ee4 <_stogir.vector-lanes.validate+0x178>
    7edc:      	b	0x7ee8 <_stogir.vector-lanes.validate+0x17c>
    7ee0:      	b	0x7f08 <_stogir.vector-lanes.validate+0x19c>
    7ee4:      	b	0x8084 <_stogir.vector-lanes.validate+0x318>
    7ee8:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007ee8:  ARM64_RELOC_PAGE21	l_stogir.410
    7eec:      	ldr	x16, [x16]
		0000000000007eec:  ARM64_RELOC_PAGEOFF12	l_stogir.410
    7ef0:      	orr	x0, x16, xzr
    7ef4:      	mov	x19, x8
    7ef8:      	mov	x1, x0
    7efc:      	mov	x0, #0x1                ; =1
    7f00:      	mov	x2, #0x1f               ; =31
    7f04:      	b	0x7f3c <_stogir.vector-lanes.validate+0x1d0>
    7f08:      	add	x16, sp, #0x10
    7f0c:      	str	x5, [x16]
    7f10:      	add	x16, sp, #0x10
    7f14:      	str	x6, [x16, #0x8]
    7f18:      	cmp	x1, #0x0
    7f1c:      	b.gt	0x7f64 <_stogir.vector-lanes.validate+0x1f8>
    7f20:      	mov	x19, x8
    7f24:      	adrp	x16, 0x7000 <_stogir.conversion.validate+0x398>
		0000000000007f24:  ARM64_RELOC_PAGE21	l_stogir.411
    7f28:      	ldr	x16, [x16]
		0000000000007f28:  ARM64_RELOC_PAGEOFF12	l_stogir.411
    7f2c:      	orr	x0, x16, xzr
    7f30:      	mov	x1, x0
    7f34:      	mov	x0, #0x1                ; =1
    7f38:      	mov	x2, #0x25               ; =37
    7f3c:      	str	x0, [x19]
    7f40:      	str	x1, [x19, #0x8]
    7f44:      	str	x2, [x19, #0x10]
    7f48:      	ldr	x19, [sp, #0x40]
    7f4c:      	ldr	x29, [sp]
    7f50:      	ldr	x30, [sp, #0x8]
    7f54:      	add	sp, sp, #0x50
    7f58:      	ret
    7f5c:      	movz	x5, #0x0, lsl #48
    7f60:      	b	0x7e3c <_stogir.vector-lanes.validate+0xd0>
    7f64:      	uxtb	w5, w5
    7f68:      	orr	x1, x5, xzr
    7f6c:      	cmp	x1, #0x3d
    7f70:      	b.lt	0x808c <_stogir.vector-lanes.validate+0x320>
    7f74:      	cmp	x1, #0x3f
    7f78:      	b.gt	0x8094 <_stogir.vector-lanes.validate+0x328>
    7f7c:      	cmp	x1, #0x3e
    7f80:      	cset	w4, eq
    7f84:      	ldr	x6, [x0, #0x78]
    7f88:      	add	x3, x3, x6
    7f8c:      	ldr	w3, [x3]
    7f90:      	cmp	x1, #0x3d
    7f94:      	b.ne	0x8014 <_stogir.vector-lanes.validate+0x2a8>
    7f98:      	mov	x6, #0x2                ; =2
    7f9c:      	b	0x8028 <_stogir.vector-lanes.validate+0x2bc>
    7fa0:      	movz	x5, #0x0, lsl #48
    7fa4:      	b	0x7e34 <_stogir.vector-lanes.validate+0xc8>
    7fa8:      	movz	x4, #0x0, lsl #48
    7fac:      	lsr	w2, w2, #0
    7fb0:      	lsr	w6, w6, #0
    7fb4:      	lsr	w1, w1, #0
    7fb8:      	lsr	w5, w5, #0
    7fbc:      	lsr	w4, w4, #0
    7fc0:      	ubfx	x3, x3, #8, #8
    7fc4:      	lsr	w3, w3, #0
    7fc8:      	mov	x19, x8
    7fcc:      	add	x8, sp, #0x20
    7fd0:      	fmov	s31, w1
    7fd4:      	mov	w1, w5
    7fd8:      	fmov	w5, s31
    7fdc:      	fmov	s31, w2
    7fe0:      	mov	w2, w3
    7fe4:      	fmov	w3, s31
    7fe8:      	fmov	s31, w4
    7fec:      	mov	w4, w6
    7ff0:      	fmov	w6, s31
    7ff4:      	bl	0x7ff4 <_stogir.vector-lanes.validate+0x288>
		0000000000007ff4:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.operands
    7ff8:      	add	x16, sp, #0x20
    7ffc:      	ldr	x0, [x16]
    8000:      	add	x16, sp, #0x20
    8004:      	ldr	x1, [x16, #0x8]
    8008:      	add	x16, sp, #0x20
    800c:      	ldr	x2, [x16, #0x10]
    8010:      	b	0x7f3c <_stogir.vector-lanes.validate+0x1d0>
    8014:      	uxtb	w16, w4
    8018:      	cmp	w16, wzr
    801c:      	mov	x16, #0x3               ; =3
    8020:      	mov	x17, #0x1               ; =1
    8024:      	csel	x6, x16, x17, ne
    8028:      	sxtw	x3, w3
    802c:      	lsr	w6, w6, #0
    8030:      	sxtw	x6, w6
    8034:      	cmp	x3, x6
    8038:      	b.ne	0x809c <_stogir.vector-lanes.validate+0x330>
    803c:      	add	x16, sp, #0x10
    8040:      	ldr	w3, [x16]
    8044:      	add	x16, sp, #0x10
    8048:      	ldr	w6, [x16, #0x4]
    804c:      	cmp	x1, #0x3f
    8050:      	b.ne	0x805c <_stogir.vector-lanes.validate+0x2f0>
    8054:      	movz	x1, #0x0, lsl #48
    8058:      	b	0x8068 <_stogir.vector-lanes.validate+0x2fc>
    805c:      	add	x16, sp, #0x10
    8060:      	ldr	w1, [x16, #0x8]
    8064:      	sxtw	x1, w1
    8068:      	uxtb	w16, w4
    806c:      	cmp	w16, wzr
    8070:      	b.eq	0x7fa8 <_stogir.vector-lanes.validate+0x23c>
    8074:      	add	x16, sp, #0x10
    8078:      	ldr	w4, [x16, #0xc]
    807c:      	sxtw	x4, w4
    8080:      	b	0x7fac <_stogir.vector-lanes.validate+0x240>
    8084:      	brk	#0
    8088:      	b	0x8084 <_stogir.vector-lanes.validate+0x318>
    808c:      	mov	x19, x8
    8090:      	b	0x7f24 <_stogir.vector-lanes.validate+0x1b8>
    8094:      	mov	x19, x8
    8098:      	b	0x7f24 <_stogir.vector-lanes.validate+0x1b8>
    809c:      	mov	x19, x8
    80a0:      	b	0x7f24 <_stogir.vector-lanes.validate+0x1b8>

00000000000080a4 <_stogir.vector-comparison.node?>:
    80a4:      	sxtw	x1, w1
    80a8:      	cmp	x1, #0x0
    80ac:      	cset	w2, gt
    80b0:      	movz	x16, #0x0, lsl #48
    80b4:      	sub	x3, x16, x1
    80b8:      	sub	x4, x3, #0x1
    80bc:      	uxtb	w16, w2
    80c0:      	cmp	w16, wzr
    80c4:      	b.eq	0x8108 <_stogir.vector-comparison.node?+0x64>
    80c8:      	ldr	x3, [x0, #0x8]
    80cc:      	cmp	x1, x3
    80d0:      	b.ge	0x815c <_stogir.vector-comparison.node?+0xb8>
    80d4:      	add	x3, x0, #0x78
    80d8:      	ldr	x3, [x3, #0x8]
    80dc:      	cmp	x1, x3
    80e0:      	b.ge	0x8244 <_stogir.vector-comparison.node?+0x1a0>
    80e4:      	lsl	x3, x1, #2
    80e8:      	ldr	x5, [x0, #0x78]
    80ec:      	add	x3, x3, x5
    80f0:      	ldr	w3, [x3]
    80f4:      	sxtw	x3, w3
    80f8:      	cmp	x3, #0x0
    80fc:      	cset	w3, ge
    8100:      	ubfx	x3, x3, #0, #8
    8104:      	b	0x8248 <_stogir.vector-comparison.node?+0x1a4>
    8108:      	cmp	x1, #0x0
    810c:      	b.ge	0x8164 <_stogir.vector-comparison.node?+0xc0>
    8110:      	add	x5, x0, #0x28
    8114:      	add	x6, x0, #0x50
    8118:      	ldr	x5, [x5, #0x8]
    811c:      	ldr	x6, [x6, #0x8]
    8120:      	cmp	x5, x6
    8124:      	b.ne	0x8154 <_stogir.vector-comparison.node?+0xb0>
    8128:      	cmp	x3, x5
    812c:      	b.gt	0x824c <_stogir.vector-comparison.node?+0x1a8>
    8130:      	lsl	x3, x4, #2
    8134:      	ldr	x5, [x0, #0x50]
    8138:      	add	x3, x3, x5
    813c:      	ldr	w3, [x3]
    8140:      	sxtw	x3, w3
    8144:      	cmp	x3, #0x0
    8148:      	cset	w3, gt
    814c:      	ubfx	x3, x3, #0, #8
    8150:      	b	0x8250 <_stogir.vector-comparison.node?+0x1ac>
    8154:      	movz	x3, #0x0, lsl #48
    8158:      	b	0x8168 <_stogir.vector-comparison.node?+0xc4>
    815c:      	movz	x3, #0x0, lsl #48
    8160:      	b	0x8168 <_stogir.vector-comparison.node?+0xc4>
    8164:      	movz	x3, #0x0, lsl #48
    8168:      	cmp	x3, #0x0
    816c:      	b.eq	0x81ac <_stogir.vector-comparison.node?+0x108>
    8170:      	uxtb	w16, w2
    8174:      	cmp	w16, wzr
    8178:      	b.eq	0x8190 <_stogir.vector-comparison.node?+0xec>
    817c:      	lsl	x1, x1, #4
    8180:      	ldr	x0, [x0]
    8184:      	add	x0, x1, x0
    8188:      	ldr	x0, [x0]
    818c:      	b	0x81a0 <_stogir.vector-comparison.node?+0xfc>
    8190:      	lsl	x1, x4, #4
    8194:      	ldr	x0, [x0, #0x28]
    8198:      	add	x0, x1, x0
    819c:      	ldr	x0, [x0]
    81a0:      	mov	x1, x0
    81a4:      	mov	x0, #0x1                ; =1
    81a8:      	b	0x81b4 <_stogir.vector-comparison.node?+0x110>
    81ac:      	movz	x0, #0x0, lsl #48
    81b0:      	movz	x1, #0x0, lsl #48
    81b4:      	lsr	w0, w0, #0
    81b8:      	lsr	x16, x0, #0
    81bc:      	cmp	x16, #0x1
    81c0:      	b.eq	0x81dc <_stogir.vector-comparison.node?+0x138>
    81c4:      	b.lo	0x81cc <_stogir.vector-comparison.node?+0x128>
    81c8:      	b	0x81e0 <_stogir.vector-comparison.node?+0x13c>
    81cc:      	cmp	x16, #0x0
    81d0:      	b.eq	0x81d8 <_stogir.vector-comparison.node?+0x134>
    81d4:      	b	0x81e0 <_stogir.vector-comparison.node?+0x13c>
    81d8:      	b	0x81e4 <_stogir.vector-comparison.node?+0x140>
    81dc:      	b	0x81f4 <_stogir.vector-comparison.node?+0x150>
    81e0:      	b	0x826c <_stogir.vector-comparison.node?+0x1c8>
    81e4:      	movz	x0, #0x0, lsl #48
    81e8:      	b	0x81f0 <_stogir.vector-comparison.node?+0x14c>
    81ec:      	movz	x0, #0x0, lsl #48
    81f0:      	ret
    81f4:      	uxtb	w0, w1
    81f8:      	cmp	x0, #0xe
    81fc:      	b.lt	0x81ec <_stogir.vector-comparison.node?+0x148>
    8200:      	cmp	x0, #0x19
    8204:      	b.gt	0x81ec <_stogir.vector-comparison.node?+0x148>
    8208:      	lsr	w1, w1, #0
    820c:      	ubfx	x0, x1, #8, #8
    8210:      	cmp	x0, #0xf
    8214:      	b.le	0x8254 <_stogir.vector-comparison.node?+0x1b0>
    8218:      	cmp	x0, #0x80
    821c:      	b.ge	0x825c <_stogir.vector-comparison.node?+0x1b8>
    8220:      	and	x0, x0, #0xf
    8224:      	lsr	w0, w0, #0
    8228:      	sxtw	x0, w0
    822c:      	cmp	x0, #0x1
    8230:      	b.lt	0x8264 <_stogir.vector-comparison.node?+0x1c0>
    8234:      	cmp	x0, #0xd
    8238:      	cset	w0, le
    823c:      	ubfx	x0, x0, #0, #8
    8240:      	b	0x8268 <_stogir.vector-comparison.node?+0x1c4>
    8244:      	movz	x3, #0x0, lsl #48
    8248:      	b	0x8160 <_stogir.vector-comparison.node?+0xbc>
    824c:      	movz	x3, #0x0, lsl #48
    8250:      	b	0x8158 <_stogir.vector-comparison.node?+0xb4>
    8254:      	movz	x0, #0x0, lsl #48
    8258:      	b	0x81f0 <_stogir.vector-comparison.node?+0x14c>
    825c:      	movz	x0, #0x0, lsl #48
    8260:      	b	0x8258 <_stogir.vector-comparison.node?+0x1b4>
    8264:      	movz	x0, #0x0, lsl #48
    8268:      	b	0x8260 <_stogir.vector-comparison.node?+0x1bc>
    826c:      	brk	#0
    8270:      	b	0x826c <_stogir.vector-comparison.node?+0x1c8>

0000000000008274 <_stogir.vector-comparison.validate>:
    8274:      	sub	sp, sp, #0x50
    8278:      	str	x29, [sp]
    827c:      	str	x30, [sp, #0x8]
    8280:      	mov	x29, sp
    8284:      	str	x19, [sp, #0x40]
    8288:      	sxtw	x1, w1
    828c:      	lsl	x3, x1, #2
    8290:      	cmp	x1, #0x0
    8294:      	cset	w4, gt
    8298:      	movz	x16, #0x0, lsl #48
    829c:      	sub	x5, x16, x1
    82a0:      	sub	x6, x5, #0x1
    82a4:      	uxtb	w16, w4
    82a8:      	cmp	w16, wzr
    82ac:      	b.eq	0x82ec <_stogir.vector-comparison.validate+0x78>
    82b0:      	ldr	x5, [x0, #0x8]
    82b4:      	cmp	x1, x5
    82b8:      	b.ge	0x8340 <_stogir.vector-comparison.validate+0xcc>
    82bc:      	add	x5, x0, #0x78
    82c0:      	ldr	x5, [x5, #0x8]
    82c4:      	cmp	x1, x5
    82c8:      	b.ge	0x8464 <_stogir.vector-comparison.validate+0x1f0>
    82cc:      	ldr	x5, [x0, #0x78]
    82d0:      	add	x5, x3, x5
    82d4:      	ldr	w5, [x5]
    82d8:      	sxtw	x5, w5
    82dc:      	cmp	x5, #0x0
    82e0:      	cset	w5, ge
    82e4:      	ubfx	x5, x5, #0, #8
    82e8:      	b	0x8468 <_stogir.vector-comparison.validate+0x1f4>
    82ec:      	cmp	x1, #0x0
    82f0:      	b.ge	0x8348 <_stogir.vector-comparison.validate+0xd4>
    82f4:      	add	x7, x0, #0x28
    82f8:      	add	x9, x0, #0x50
    82fc:      	ldr	x7, [x7, #0x8]
    8300:      	ldr	x9, [x9, #0x8]
    8304:      	cmp	x7, x9
    8308:      	b.ne	0x8338 <_stogir.vector-comparison.validate+0xc4>
    830c:      	cmp	x5, x7
    8310:      	b.gt	0x84b8 <_stogir.vector-comparison.validate+0x244>
    8314:      	lsl	x5, x6, #2
    8318:      	ldr	x7, [x0, #0x50]
    831c:      	add	x5, x5, x7
    8320:      	ldr	w5, [x5]
    8324:      	sxtw	x5, w5
    8328:      	cmp	x5, #0x0
    832c:      	cset	w5, gt
    8330:      	ubfx	x5, x5, #0, #8
    8334:      	b	0x84bc <_stogir.vector-comparison.validate+0x248>
    8338:      	movz	x5, #0x0, lsl #48
    833c:      	b	0x834c <_stogir.vector-comparison.validate+0xd8>
    8340:      	movz	x5, #0x0, lsl #48
    8344:      	b	0x834c <_stogir.vector-comparison.validate+0xd8>
    8348:      	movz	x5, #0x0, lsl #48
    834c:      	lsl	x7, x1, #4
    8350:      	cmp	x5, #0x0
    8354:      	b.eq	0x83b4 <_stogir.vector-comparison.validate+0x140>
    8358:      	uxtb	w16, w4
    835c:      	cmp	w16, wzr
    8360:      	b.eq	0x8384 <_stogir.vector-comparison.validate+0x110>
    8364:      	ldr	x4, [x0]
    8368:      	add	x4, x7, x4
    836c:      	ldr	x5, [x4]
    8370:      	ldr	x4, [x4, #0x8]
    8374:      	fmov	d31, x4
    8378:      	mov	x4, x5
    837c:      	fmov	x5, d31
    8380:      	b	0x83a4 <_stogir.vector-comparison.validate+0x130>
    8384:      	lsl	x4, x6, #4
    8388:      	ldr	x5, [x0, #0x28]
    838c:      	add	x4, x4, x5
    8390:      	ldr	x5, [x4]
    8394:      	ldr	x4, [x4, #0x8]
    8398:      	fmov	d31, x4
    839c:      	mov	x4, x5
    83a0:      	fmov	x5, d31
    83a4:      	mov	x6, x5
    83a8:      	mov	x5, x4
    83ac:      	mov	x4, #0x1                ; =1
    83b0:      	b	0x83c0 <_stogir.vector-comparison.validate+0x14c>
    83b4:      	movz	x4, #0x0, lsl #48
    83b8:      	movz	x5, #0x0, lsl #48
    83bc:      	movz	x6, #0x0, lsl #48
    83c0:      	lsr	w4, w4, #0
    83c4:      	lsr	x16, x4, #0
    83c8:      	cmp	x16, #0x1
    83cc:      	b.eq	0x83e8 <_stogir.vector-comparison.validate+0x174>
    83d0:      	b.lo	0x83d8 <_stogir.vector-comparison.validate+0x164>
    83d4:      	b	0x83ec <_stogir.vector-comparison.validate+0x178>
    83d8:      	cmp	x16, #0x0
    83dc:      	b.eq	0x83e4 <_stogir.vector-comparison.validate+0x170>
    83e0:      	b	0x83ec <_stogir.vector-comparison.validate+0x178>
    83e4:      	b	0x83f0 <_stogir.vector-comparison.validate+0x17c>
    83e8:      	b	0x842c <_stogir.vector-comparison.validate+0x1b8>
    83ec:      	b	0x85cc <_stogir.vector-comparison.validate+0x358>
    83f0:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		00000000000083f0:  ARM64_RELOC_PAGE21	l_stogir.412
    83f4:      	ldr	x16, [x16]
		00000000000083f4:  ARM64_RELOC_PAGEOFF12	l_stogir.412
    83f8:      	orr	x0, x16, xzr
    83fc:      	mov	x19, x8
    8400:      	mov	x1, x0
    8404:      	mov	x0, #0x1                ; =1
    8408:      	mov	x2, #0x25               ; =37
    840c:      	str	x0, [x19]
    8410:      	str	x1, [x19, #0x8]
    8414:      	str	x2, [x19, #0x10]
    8418:      	ldr	x19, [sp, #0x40]
    841c:      	ldr	x29, [sp]
    8420:      	ldr	x30, [sp, #0x8]
    8424:      	add	sp, sp, #0x50
    8428:      	ret
    842c:      	add	x16, sp, #0x10
    8430:      	str	x5, [x16]
    8434:      	add	x16, sp, #0x10
    8438:      	str	x6, [x16, #0x8]
    843c:      	cmp	x1, #0x0
    8440:      	b.gt	0x846c <_stogir.vector-comparison.validate+0x1f8>
    8444:      	mov	x19, x8
    8448:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008448:  ARM64_RELOC_PAGE21	l_stogir.413
    844c:      	ldr	x16, [x16]
		000000000000844c:  ARM64_RELOC_PAGEOFF12	l_stogir.413
    8450:      	orr	x0, x16, xzr
    8454:      	mov	x1, x0
    8458:      	mov	x0, #0x1                ; =1
    845c:      	mov	x2, #0x2b               ; =43
    8460:      	b	0x840c <_stogir.vector-comparison.validate+0x198>
    8464:      	movz	x5, #0x0, lsl #48
    8468:      	b	0x8344 <_stogir.vector-comparison.validate+0xd0>
    846c:      	ldr	x4, [x0, #0x8]
    8470:      	cmp	x1, x4
    8474:      	b.ge	0x84c0 <_stogir.vector-comparison.validate+0x24c>
    8478:      	add	x4, x0, #0x78
    847c:      	ldr	x4, [x4, #0x8]
    8480:      	cmp	x1, x4
    8484:      	b.ge	0x84c0 <_stogir.vector-comparison.validate+0x24c>
    8488:      	ldr	x1, [x0, #0x78]
    848c:      	add	x1, x3, x1
    8490:      	ldr	w1, [x1]
    8494:      	sxtw	x1, w1
    8498:      	cmp	x1, #0x0
    849c:      	b.lt	0x84c0 <_stogir.vector-comparison.validate+0x24c>
    84a0:      	ldr	x1, [x0]
    84a4:      	add	x1, x7, x1
    84a8:      	ldr	x1, [x1]
    84ac:      	mov	x4, x1
    84b0:      	mov	x1, #0x1                ; =1
    84b4:      	b	0x84c8 <_stogir.vector-comparison.validate+0x254>
    84b8:      	movz	x5, #0x0, lsl #48
    84bc:      	b	0x833c <_stogir.vector-comparison.validate+0xc8>
    84c0:      	movz	x1, #0x0, lsl #48
    84c4:      	movz	x4, #0x0, lsl #48
    84c8:      	lsr	w1, w1, #0
    84cc:      	lsr	x16, x1, #0
    84d0:      	cmp	x16, #0x1
    84d4:      	b.eq	0x84f0 <_stogir.vector-comparison.validate+0x27c>
    84d8:      	b.lo	0x84e0 <_stogir.vector-comparison.validate+0x26c>
    84dc:      	b	0x84f4 <_stogir.vector-comparison.validate+0x280>
    84e0:      	cmp	x16, #0x0
    84e4:      	b.eq	0x84ec <_stogir.vector-comparison.validate+0x278>
    84e8:      	b	0x84f4 <_stogir.vector-comparison.validate+0x280>
    84ec:      	b	0x84f8 <_stogir.vector-comparison.validate+0x284>
    84f0:      	b	0x8500 <_stogir.vector-comparison.validate+0x28c>
    84f4:      	b	0x85d4 <_stogir.vector-comparison.validate+0x360>
    84f8:      	mov	x19, x8
    84fc:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    8500:      	uxtb	w1, w4
    8504:      	cmp	x1, #0xe
    8508:      	b.lt	0x85dc <_stogir.vector-comparison.validate+0x368>
    850c:      	cmp	x1, #0x19
    8510:      	b.gt	0x85e4 <_stogir.vector-comparison.validate+0x370>
    8514:      	lsr	w4, w4, #0
    8518:      	ubfx	x1, x4, #8, #8
    851c:      	cmp	x1, #0xf
    8520:      	b.le	0x85ec <_stogir.vector-comparison.validate+0x378>
    8524:      	cmp	x1, #0x80
    8528:      	b.ge	0x85f4 <_stogir.vector-comparison.validate+0x380>
    852c:      	and	x1, x1, #0xf
    8530:      	lsr	w1, w1, #0
    8534:      	sxtw	x1, w1
    8538:      	cmp	x1, #0x1
    853c:      	b.lt	0x85fc <_stogir.vector-comparison.validate+0x388>
    8540:      	cmp	x1, #0xd
    8544:      	b.gt	0x8604 <_stogir.vector-comparison.validate+0x390>
    8548:      	ldr	x1, [x0, #0x78]
    854c:      	add	x1, x3, x1
    8550:      	ldr	w1, [x1]
    8554:      	sxtw	x1, w1
    8558:      	cmp	x1, #0x2
    855c:      	b.ne	0x860c <_stogir.vector-comparison.validate+0x398>
    8560:      	lsr	w2, w2, #0
    8564:      	add	x16, sp, #0x10
    8568:      	ldr	w1, [x16]
    856c:      	uxtb	w3, w1
    8570:      	add	x16, sp, #0x10
    8574:      	ldr	w4, [x16, #0x4]
    8578:      	lsr	w3, w3, #0
    857c:      	ubfx	x1, x1, #8, #8
    8580:      	add	x16, sp, #0x10
    8584:      	ldr	w5, [x16, #0x8]
    8588:      	lsr	w4, w4, #0
    858c:      	lsr	w5, w5, #0
    8590:      	lsr	w1, w1, #0
    8594:      	mov	x19, x8
    8598:      	add	x8, sp, #0x20
    859c:      	fmov	s31, w1
    85a0:      	mov	w1, w3
    85a4:      	mov	w3, w2
    85a8:      	fmov	w2, s31
    85ac:      	bl	0x85ac <_stogir.vector-comparison.validate+0x338>
		00000000000085ac:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.operands
    85b0:      	add	x16, sp, #0x20
    85b4:      	ldr	x0, [x16]
    85b8:      	add	x16, sp, #0x20
    85bc:      	ldr	x1, [x16, #0x8]
    85c0:      	add	x16, sp, #0x20
    85c4:      	ldr	x2, [x16, #0x10]
    85c8:      	b	0x8460 <_stogir.vector-comparison.validate+0x1ec>
    85cc:      	brk	#0
    85d0:      	b	0x85cc <_stogir.vector-comparison.validate+0x358>
    85d4:      	brk	#0
    85d8:      	b	0x85d4 <_stogir.vector-comparison.validate+0x360>
    85dc:      	mov	x19, x8
    85e0:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    85e4:      	mov	x19, x8
    85e8:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    85ec:      	mov	x19, x8
    85f0:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    85f4:      	mov	x19, x8
    85f8:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    85fc:      	mov	x19, x8
    8600:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    8604:      	mov	x19, x8
    8608:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>
    860c:      	mov	x19, x8
    8610:      	b	0x8448 <_stogir.vector-comparison.validate+0x1d4>

0000000000008614 <_stogir.vector-arithmetic.node?>:
    8614:      	sxtw	x1, w1
    8618:      	cmp	x1, #0x0
    861c:      	cset	w2, gt
    8620:      	movz	x16, #0x0, lsl #48
    8624:      	sub	x3, x16, x1
    8628:      	sub	x4, x3, #0x1
    862c:      	uxtb	w16, w2
    8630:      	cmp	w16, wzr
    8634:      	b.eq	0x8678 <_stogir.vector-arithmetic.node?+0x64>
    8638:      	ldr	x3, [x0, #0x8]
    863c:      	cmp	x1, x3
    8640:      	b.ge	0x86cc <_stogir.vector-arithmetic.node?+0xb8>
    8644:      	add	x3, x0, #0x78
    8648:      	ldr	x3, [x3, #0x8]
    864c:      	cmp	x1, x3
    8650:      	b.ge	0x87fc <_stogir.vector-arithmetic.node?+0x1e8>
    8654:      	lsl	x3, x1, #2
    8658:      	ldr	x5, [x0, #0x78]
    865c:      	add	x3, x3, x5
    8660:      	ldr	w3, [x3]
    8664:      	sxtw	x3, w3
    8668:      	cmp	x3, #0x0
    866c:      	cset	w3, ge
    8670:      	ubfx	x3, x3, #0, #8
    8674:      	b	0x8800 <_stogir.vector-arithmetic.node?+0x1ec>
    8678:      	cmp	x1, #0x0
    867c:      	b.ge	0x86d4 <_stogir.vector-arithmetic.node?+0xc0>
    8680:      	add	x5, x0, #0x28
    8684:      	add	x6, x0, #0x50
    8688:      	ldr	x5, [x5, #0x8]
    868c:      	ldr	x6, [x6, #0x8]
    8690:      	cmp	x5, x6
    8694:      	b.ne	0x86c4 <_stogir.vector-arithmetic.node?+0xb0>
    8698:      	cmp	x3, x5
    869c:      	b.gt	0x880c <_stogir.vector-arithmetic.node?+0x1f8>
    86a0:      	lsl	x3, x4, #2
    86a4:      	ldr	x5, [x0, #0x50]
    86a8:      	add	x3, x3, x5
    86ac:      	ldr	w3, [x3]
    86b0:      	sxtw	x3, w3
    86b4:      	cmp	x3, #0x0
    86b8:      	cset	w3, gt
    86bc:      	ubfx	x3, x3, #0, #8
    86c0:      	b	0x8810 <_stogir.vector-arithmetic.node?+0x1fc>
    86c4:      	movz	x3, #0x0, lsl #48
    86c8:      	b	0x86d8 <_stogir.vector-arithmetic.node?+0xc4>
    86cc:      	movz	x3, #0x0, lsl #48
    86d0:      	b	0x86d8 <_stogir.vector-arithmetic.node?+0xc4>
    86d4:      	movz	x3, #0x0, lsl #48
    86d8:      	cmp	x3, #0x0
    86dc:      	b.eq	0x871c <_stogir.vector-arithmetic.node?+0x108>
    86e0:      	uxtb	w16, w2
    86e4:      	cmp	w16, wzr
    86e8:      	b.eq	0x8700 <_stogir.vector-arithmetic.node?+0xec>
    86ec:      	lsl	x1, x1, #4
    86f0:      	ldr	x0, [x0]
    86f4:      	add	x0, x1, x0
    86f8:      	ldr	x0, [x0]
    86fc:      	b	0x8710 <_stogir.vector-arithmetic.node?+0xfc>
    8700:      	lsl	x1, x4, #4
    8704:      	ldr	x0, [x0, #0x28]
    8708:      	add	x0, x1, x0
    870c:      	ldr	x0, [x0]
    8710:      	mov	x1, x0
    8714:      	mov	x0, #0x1                ; =1
    8718:      	b	0x8724 <_stogir.vector-arithmetic.node?+0x110>
    871c:      	movz	x0, #0x0, lsl #48
    8720:      	movz	x1, #0x0, lsl #48
    8724:      	lsr	w0, w0, #0
    8728:      	lsr	x16, x0, #0
    872c:      	cmp	x16, #0x1
    8730:      	b.eq	0x874c <_stogir.vector-arithmetic.node?+0x138>
    8734:      	b.lo	0x873c <_stogir.vector-arithmetic.node?+0x128>
    8738:      	b	0x8750 <_stogir.vector-arithmetic.node?+0x13c>
    873c:      	cmp	x16, #0x0
    8740:      	b.eq	0x8748 <_stogir.vector-arithmetic.node?+0x134>
    8744:      	b	0x8750 <_stogir.vector-arithmetic.node?+0x13c>
    8748:      	b	0x8754 <_stogir.vector-arithmetic.node?+0x140>
    874c:      	b	0x8764 <_stogir.vector-arithmetic.node?+0x150>
    8750:      	b	0x881c <_stogir.vector-arithmetic.node?+0x208>
    8754:      	movz	x0, #0x0, lsl #48
    8758:      	b	0x8760 <_stogir.vector-arithmetic.node?+0x14c>
    875c:      	movz	x0, #0x0, lsl #48
    8760:      	ret
    8764:      	uxtb	w0, w1
    8768:      	cmp	x0, #0x1f
    876c:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8770:      	cmp	x0, #0x20
    8774:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8778:      	cmp	x0, #0x2d
    877c:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8780:      	cmp	x0, #0x36
    8784:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8788:      	cmp	x0, #0x37
    878c:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8790:      	cmp	x0, #0x38
    8794:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8798:      	cmp	x0, #0x39
    879c:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    87a0:      	cmp	x0, #0x3a
    87a4:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    87a8:      	cmp	x0, #0x3b
    87ac:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    87b0:      	cmp	x0, #0x31
    87b4:      	b.lt	0x8824 <_stogir.vector-arithmetic.node?+0x210>
    87b8:      	cmp	x0, #0x35
    87bc:      	b.gt	0x8824 <_stogir.vector-arithmetic.node?+0x210>
    87c0:      	lsr	w1, w1, #0
    87c4:      	ubfx	x0, x1, #8, #8
    87c8:      	cmp	x0, #0xf
    87cc:      	b.le	0x875c <_stogir.vector-arithmetic.node?+0x148>
    87d0:      	cmp	x0, #0x80
    87d4:      	b.ge	0x8804 <_stogir.vector-arithmetic.node?+0x1f0>
    87d8:      	and	x0, x0, #0xf
    87dc:      	lsr	w0, w0, #0
    87e0:      	sxtw	x0, w0
    87e4:      	cmp	x0, #0x1
    87e8:      	b.lt	0x8814 <_stogir.vector-arithmetic.node?+0x200>
    87ec:      	cmp	x0, #0xd
    87f0:      	cset	w0, le
    87f4:      	ubfx	x0, x0, #0, #8
    87f8:      	b	0x8818 <_stogir.vector-arithmetic.node?+0x204>
    87fc:      	movz	x3, #0x0, lsl #48
    8800:      	b	0x86d0 <_stogir.vector-arithmetic.node?+0xbc>
    8804:      	movz	x0, #0x0, lsl #48
    8808:      	b	0x8760 <_stogir.vector-arithmetic.node?+0x14c>
    880c:      	movz	x3, #0x0, lsl #48
    8810:      	b	0x86c8 <_stogir.vector-arithmetic.node?+0xb4>
    8814:      	movz	x0, #0x0, lsl #48
    8818:      	b	0x8808 <_stogir.vector-arithmetic.node?+0x1f4>
    881c:      	brk	#0
    8820:      	b	0x881c <_stogir.vector-arithmetic.node?+0x208>
    8824:      	cmp	x0, #0x1a
    8828:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    882c:      	cmp	x0, #0x1b
    8830:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8834:      	cmp	x0, #0x1c
    8838:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    883c:      	cmp	x0, #0x1d
    8840:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8844:      	cmp	x0, #0x1e
    8848:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    884c:      	cmp	x0, #0x2e
    8850:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8854:      	cmp	x0, #0x2f
    8858:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    885c:      	cmp	x0, #0x30
    8860:      	b.eq	0x87c0 <_stogir.vector-arithmetic.node?+0x1ac>
    8864:      	movz	x0, #0x0, lsl #48
    8868:      	b	0x8760 <_stogir.vector-arithmetic.node?+0x14c>

000000000000886c <_stogir.vector-arithmetic.validate>:
    886c:      	sub	sp, sp, #0x60
    8870:      	str	x29, [sp]
    8874:      	str	x30, [sp, #0x8]
    8878:      	mov	x29, sp
    887c:      	str	x19, [sp, #0x40]
    8880:      	str	x20, [sp, #0x48]
    8884:      	str	x21, [sp, #0x50]
    8888:      	str	x22, [sp, #0x58]
    888c:      	sxtw	x2, w1
    8890:      	lsl	x19, x2, #2
    8894:      	cmp	x2, #0x0
    8898:      	cset	w3, gt
    889c:      	movz	x16, #0x0, lsl #48
    88a0:      	sub	x4, x16, x2
    88a4:      	sub	x5, x4, #0x1
    88a8:      	uxtb	w16, w3
    88ac:      	cmp	w16, wzr
    88b0:      	b.eq	0x88f0 <_stogir.vector-arithmetic.validate+0x84>
    88b4:      	ldr	x4, [x0, #0x8]
    88b8:      	cmp	x2, x4
    88bc:      	b.ge	0x8944 <_stogir.vector-arithmetic.validate+0xd8>
    88c0:      	add	x4, x0, #0x78
    88c4:      	ldr	x4, [x4, #0x8]
    88c8:      	cmp	x2, x4
    88cc:      	b.ge	0x8a70 <_stogir.vector-arithmetic.validate+0x204>
    88d0:      	ldr	x4, [x0, #0x78]
    88d4:      	add	x4, x19, x4
    88d8:      	ldr	w4, [x4]
    88dc:      	sxtw	x4, w4
    88e0:      	cmp	x4, #0x0
    88e4:      	cset	w4, ge
    88e8:      	ubfx	x4, x4, #0, #8
    88ec:      	b	0x8a74 <_stogir.vector-arithmetic.validate+0x208>
    88f0:      	cmp	x2, #0x0
    88f4:      	b.ge	0x894c <_stogir.vector-arithmetic.validate+0xe0>
    88f8:      	add	x6, x0, #0x28
    88fc:      	add	x7, x0, #0x50
    8900:      	ldr	x6, [x6, #0x8]
    8904:      	ldr	x7, [x7, #0x8]
    8908:      	cmp	x6, x7
    890c:      	b.ne	0x893c <_stogir.vector-arithmetic.validate+0xd0>
    8910:      	cmp	x4, x6
    8914:      	b.gt	0x8b0c <_stogir.vector-arithmetic.validate+0x2a0>
    8918:      	lsl	x4, x5, #2
    891c:      	ldr	x6, [x0, #0x50]
    8920:      	add	x4, x4, x6
    8924:      	ldr	w4, [x4]
    8928:      	sxtw	x4, w4
    892c:      	cmp	x4, #0x0
    8930:      	cset	w4, gt
    8934:      	ubfx	x4, x4, #0, #8
    8938:      	b	0x8b10 <_stogir.vector-arithmetic.validate+0x2a4>
    893c:      	movz	x4, #0x0, lsl #48
    8940:      	b	0x8950 <_stogir.vector-arithmetic.validate+0xe4>
    8944:      	movz	x4, #0x0, lsl #48
    8948:      	b	0x8950 <_stogir.vector-arithmetic.validate+0xe4>
    894c:      	movz	x4, #0x0, lsl #48
    8950:      	cmp	x4, #0x0
    8954:      	b.eq	0x89b4 <_stogir.vector-arithmetic.validate+0x148>
    8958:      	uxtb	w16, w3
    895c:      	cmp	w16, wzr
    8960:      	b.eq	0x8988 <_stogir.vector-arithmetic.validate+0x11c>
    8964:      	lsl	x3, x2, #4
    8968:      	ldr	x4, [x0]
    896c:      	add	x3, x3, x4
    8970:      	ldr	x4, [x3]
    8974:      	ldr	x3, [x3, #0x8]
    8978:      	fmov	d31, x3
    897c:      	mov	x3, x4
    8980:      	fmov	x4, d31
    8984:      	b	0x89a8 <_stogir.vector-arithmetic.validate+0x13c>
    8988:      	lsl	x3, x5, #4
    898c:      	ldr	x4, [x0, #0x28]
    8990:      	add	x3, x3, x4
    8994:      	ldr	x4, [x3]
    8998:      	ldr	x3, [x3, #0x8]
    899c:      	fmov	d31, x3
    89a0:      	mov	x3, x4
    89a4:      	fmov	x4, d31
    89a8:      	mov	x20, x3
    89ac:      	mov	x3, #0x1                ; =1
    89b0:      	b	0x89c0 <_stogir.vector-arithmetic.validate+0x154>
    89b4:      	movz	x3, #0x0, lsl #48
    89b8:      	movz	x20, #0x0, lsl #48
    89bc:      	movz	x4, #0x0, lsl #48
    89c0:      	lsr	w3, w3, #0
    89c4:      	lsr	x16, x3, #0
    89c8:      	cmp	x16, #0x1
    89cc:      	b.eq	0x89e8 <_stogir.vector-arithmetic.validate+0x17c>
    89d0:      	b.lo	0x89d8 <_stogir.vector-arithmetic.validate+0x16c>
    89d4:      	b	0x89ec <_stogir.vector-arithmetic.validate+0x180>
    89d8:      	cmp	x16, #0x0
    89dc:      	b.eq	0x89e4 <_stogir.vector-arithmetic.validate+0x178>
    89e0:      	b	0x89ec <_stogir.vector-arithmetic.validate+0x180>
    89e4:      	b	0x89f0 <_stogir.vector-arithmetic.validate+0x184>
    89e8:      	b	0x8a10 <_stogir.vector-arithmetic.validate+0x1a4>
    89ec:      	b	0x8bc0 <_stogir.vector-arithmetic.validate+0x354>
    89f0:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		00000000000089f0:  ARM64_RELOC_PAGE21	l_stogir.414
    89f4:      	ldr	x16, [x16]
		00000000000089f4:  ARM64_RELOC_PAGEOFF12	l_stogir.414
    89f8:      	orr	x0, x16, xzr
    89fc:      	mov	x21, x8
    8a00:      	mov	x1, x0
    8a04:      	mov	x0, #0x1                ; =1
    8a08:      	mov	x2, #0x25               ; =37
    8a0c:      	b	0x8a44 <_stogir.vector-arithmetic.validate+0x1d8>
    8a10:      	add	x16, sp, #0x10
    8a14:      	str	x20, [x16]
    8a18:      	add	x16, sp, #0x10
    8a1c:      	str	x4, [x16, #0x8]
    8a20:      	cmp	x2, #0x0
    8a24:      	b.gt	0x8a78 <_stogir.vector-arithmetic.validate+0x20c>
    8a28:      	mov	x21, x8
    8a2c:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008a2c:  ARM64_RELOC_PAGE21	l_stogir.415
    8a30:      	ldr	x16, [x16]
		0000000000008a30:  ARM64_RELOC_PAGEOFF12	l_stogir.415
    8a34:      	orr	x0, x16, xzr
    8a38:      	mov	x1, x0
    8a3c:      	mov	x0, #0x1                ; =1
    8a40:      	mov	x2, #0x2b               ; =43
    8a44:      	str	x0, [x21]
    8a48:      	str	x1, [x21, #0x8]
    8a4c:      	str	x2, [x21, #0x10]
    8a50:      	ldr	x19, [sp, #0x40]
    8a54:      	ldr	x20, [sp, #0x48]
    8a58:      	ldr	x21, [sp, #0x50]
    8a5c:      	ldr	x22, [sp, #0x58]
    8a60:      	ldr	x29, [sp]
    8a64:      	ldr	x30, [sp, #0x8]
    8a68:      	add	sp, sp, #0x60
    8a6c:      	ret
    8a70:      	movz	x4, #0x0, lsl #48
    8a74:      	b	0x8948 <_stogir.vector-arithmetic.validate+0xdc>
    8a78:      	lsr	w1, w1, #0
    8a7c:      	mov	x21, x8
    8a80:      	mov	x22, x0
    8a84:      	bl	0x8a84 <_stogir.vector-arithmetic.validate+0x218>
		0000000000008a84:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.node?
    8a88:      	cmp	x0, #0x0
    8a8c:      	b.eq	0x8a2c <_stogir.vector-arithmetic.validate+0x1c0>
    8a90:      	uxtb	w20, w20
    8a94:      	orr	x0, x20, xzr
    8a98:      	ldr	x1, [x22, #0x78]
    8a9c:      	cmp	x0, #0x1d
    8aa0:      	cset	w2, eq
    8aa4:      	cmp	x0, #0x1e
    8aa8:      	cset	w3, eq
    8aac:      	add	x1, x19, x1
    8ab0:      	ldr	w1, [x1]
    8ab4:      	cmp	x0, #0x1f
    8ab8:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8abc:      	cmp	x0, #0x20
    8ac0:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8ac4:      	cmp	x0, #0x2d
    8ac8:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8acc:      	cmp	x0, #0x36
    8ad0:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8ad4:      	cmp	x0, #0x37
    8ad8:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8adc:      	cmp	x0, #0x38
    8ae0:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8ae4:      	cmp	x0, #0x39
    8ae8:      	b.eq	0x8b70 <_stogir.vector-arithmetic.validate+0x304>
    8aec:      	uxtb	w16, w2
    8af0:      	cmp	w16, wzr
    8af4:      	b.ne	0x8bc8 <_stogir.vector-arithmetic.validate+0x35c>
    8af8:      	uxtb	w16, w3
    8afc:      	cmp	w16, wzr
    8b00:      	b.ne	0x8bc8 <_stogir.vector-arithmetic.validate+0x35c>
    8b04:      	mov	x0, #0x2                ; =2
    8b08:      	b	0x8bcc <_stogir.vector-arithmetic.validate+0x360>
    8b0c:      	movz	x4, #0x0, lsl #48
    8b10:      	b	0x8940 <_stogir.vector-arithmetic.validate+0xd4>
    8b14:      	add	x16, sp, #0x10
    8b18:      	ldr	w2, [x16, #0xc]
    8b1c:      	sxtw	x2, w2
    8b20:      	lsr	w1, w1, #0
    8b24:      	lsr	w4, w4, #0
    8b28:      	lsr	w20, w20, #0
    8b2c:      	lsr	w2, w2, #0
    8b30:      	ubfx	x0, x0, #8, #8
    8b34:      	lsr	w0, w0, #0
    8b38:      	add	x8, sp, #0x20
    8b3c:      	mov	w3, w1
    8b40:      	mov	w1, w20
    8b44:      	mov	w5, w2
    8b48:      	mov	w2, w0
    8b4c:      	mov	x0, x22
    8b50:      	bl	0x8b50 <_stogir.vector-arithmetic.validate+0x2e4>
		0000000000008b50:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.operands
    8b54:      	add	x16, sp, #0x20
    8b58:      	ldr	x0, [x16]
    8b5c:      	add	x16, sp, #0x20
    8b60:      	ldr	x1, [x16, #0x8]
    8b64:      	add	x16, sp, #0x20
    8b68:      	ldr	x2, [x16, #0x10]
    8b6c:      	b	0x8a44 <_stogir.vector-arithmetic.validate+0x1d8>
    8b70:      	mov	x0, #0x1                ; =1
    8b74:      	sxtw	x1, w1
    8b78:      	lsr	w0, w0, #0
    8b7c:      	sxtw	x0, w0
    8b80:      	cmp	x1, x0
    8b84:      	b.ne	0x8a2c <_stogir.vector-arithmetic.validate+0x1c0>
    8b88:      	add	x16, sp, #0x10
    8b8c:      	ldr	w0, [x16]
    8b90:      	add	x16, sp, #0x10
    8b94:      	ldr	w1, [x16, #0x4]
    8b98:      	add	x16, sp, #0x10
    8b9c:      	ldr	w4, [x16, #0x8]
    8ba0:      	uxtb	w16, w2
    8ba4:      	cmp	w16, wzr
    8ba8:      	b.ne	0x8b14 <_stogir.vector-arithmetic.validate+0x2a8>
    8bac:      	uxtb	w16, w3
    8bb0:      	cmp	w16, wzr
    8bb4:      	b.ne	0x8b14 <_stogir.vector-arithmetic.validate+0x2a8>
    8bb8:      	movz	x2, #0x0, lsl #48
    8bbc:      	b	0x8b20 <_stogir.vector-arithmetic.validate+0x2b4>
    8bc0:      	brk	#0
    8bc4:      	b	0x8bc0 <_stogir.vector-arithmetic.validate+0x354>
    8bc8:      	mov	x0, #0x3                ; =3
    8bcc:      	b	0x8b74 <_stogir.vector-arithmetic.validate+0x308>

0000000000008bd0 <_stogir.vector.memory-inputs>:
    8bd0:      	sub	sp, sp, #0x40
    8bd4:      	str	x29, [sp]
    8bd8:      	str	x30, [sp, #0x8]
    8bdc:      	mov	x29, sp
    8be0:      	str	x19, [sp, #0x10]
    8be4:      	str	x20, [sp, #0x18]
    8be8:      	str	x21, [sp, #0x20]
    8bec:      	str	x22, [sp, #0x28]
    8bf0:      	str	x23, [sp, #0x30]
    8bf4:      	str	x24, [sp, #0x38]
    8bf8:      	sxtw	x5, w1
    8bfc:      	cmp	x5, #0xf
    8c00:      	b.le	0x90bc <_stogir.vector.memory-inputs+0x4ec>
    8c04:      	cmp	x5, #0x80
    8c08:      	b.ge	0x90c4 <_stogir.vector.memory-inputs+0x4f4>
    8c0c:      	and	x6, x5, #0xf
    8c10:      	lsr	w6, w6, #0
    8c14:      	sxtw	x6, w6
    8c18:      	cmp	x6, #0x1
    8c1c:      	b.lt	0x90cc <_stogir.vector.memory-inputs+0x4fc>
    8c20:      	and	x5, x5, #0xf
    8c24:      	lsr	w5, w5, #0
    8c28:      	sxtw	x5, w5
    8c2c:      	cmp	x5, #0xd
    8c30:      	b.gt	0x90d4 <_stogir.vector.memory-inputs+0x504>
    8c34:      	lsr	w1, w1, #0
    8c38:      	lsr	w2, w2, #0
    8c3c:      	mov	x19, x8
    8c40:      	mov	x20, x0
    8c44:      	mov	w0, w1
    8c48:      	mov	w21, w1
    8c4c:      	mov	w1, w2
    8c50:      	mov	w22, w2
    8c54:      	mov	w23, w3
    8c58:      	mov	w24, w4
    8c5c:      	bl	0x8c5c <_stogir.vector.memory-inputs+0x8c>
		0000000000008c5c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    8c60:      	lsr	w0, w0, #0
    8c64:      	sxtw	x0, w0
    8c68:      	cmp	x0, #0x0
    8c6c:      	b.le	0x8cd4 <_stogir.vector.memory-inputs+0x104>
    8c70:      	sxtw	x23, w23
    8c74:      	cmp	x23, #0x0
    8c78:      	cset	w0, gt
    8c7c:      	movz	x16, #0x0, lsl #48
    8c80:      	sub	x1, x16, x23
    8c84:      	sub	x2, x1, #0x1
    8c88:      	uxtb	w16, w0
    8c8c:      	cmp	w16, wzr
    8c90:      	b.eq	0x8dc4 <_stogir.vector.memory-inputs+0x1f4>
    8c94:      	ldr	x1, [x20, #0x8]
    8c98:      	cmp	x23, x1
    8c9c:      	b.ge	0x8dbc <_stogir.vector.memory-inputs+0x1ec>
    8ca0:      	add	x1, x20, #0x78
    8ca4:      	ldr	x1, [x1, #0x8]
    8ca8:      	cmp	x23, x1
    8cac:      	b.ge	0x8e6c <_stogir.vector.memory-inputs+0x29c>
    8cb0:      	lsl	x1, x23, #2
    8cb4:      	ldr	x3, [x20, #0x78]
    8cb8:      	add	x1, x1, x3
    8cbc:      	ldr	w1, [x1]
    8cc0:      	sxtw	x1, w1
    8cc4:      	cmp	x1, #0x0
    8cc8:      	cset	w1, ge
    8ccc:      	ubfx	x1, x1, #0, #8
    8cd0:      	b	0x8e70 <_stogir.vector.memory-inputs+0x2a0>
    8cd4:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008cd4:  ARM64_RELOC_PAGE21	l_stogir.416
    8cd8:      	ldr	x16, [x16]
		0000000000008cd8:  ARM64_RELOC_PAGEOFF12	l_stogir.416
    8cdc:      	orr	x0, x16, xzr
    8ce0:      	mov	x1, x0
    8ce4:      	mov	x0, #0x1                ; =1
    8ce8:      	mov	x2, #0x32               ; =50
    8cec:      	str	x0, [x19]
    8cf0:      	str	x1, [x19, #0x8]
    8cf4:      	str	x2, [x19, #0x10]
    8cf8:      	ldr	x19, [sp, #0x10]
    8cfc:      	ldr	x20, [sp, #0x18]
    8d00:      	ldr	x21, [sp, #0x20]
    8d04:      	ldr	x22, [sp, #0x28]
    8d08:      	ldr	x23, [sp, #0x30]
    8d0c:      	ldr	x24, [sp, #0x38]
    8d10:      	ldr	x29, [sp]
    8d14:      	ldr	x30, [sp, #0x8]
    8d18:      	add	sp, sp, #0x40
    8d1c:      	ret
    8d20:      	movz	x0, #0x0, lsl #48
    8d24:      	movz	x1, #0x0, lsl #48
    8d28:      	lsr	w0, w0, #0
    8d2c:      	lsr	x16, x0, #0
    8d30:      	cmp	x16, #0x1
    8d34:      	b.eq	0x8d50 <_stogir.vector.memory-inputs+0x180>
    8d38:      	b.lo	0x8d40 <_stogir.vector.memory-inputs+0x170>
    8d3c:      	b	0x8d54 <_stogir.vector.memory-inputs+0x184>
    8d40:      	cmp	x16, #0x0
    8d44:      	b.eq	0x8d4c <_stogir.vector.memory-inputs+0x17c>
    8d48:      	b	0x8d54 <_stogir.vector.memory-inputs+0x184>
    8d4c:      	b	0x8d58 <_stogir.vector.memory-inputs+0x188>
    8d50:      	b	0x8e10 <_stogir.vector.memory-inputs+0x240>
    8d54:      	b	0x90a4 <_stogir.vector.memory-inputs+0x4d4>
    8d58:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008d58:  ARM64_RELOC_PAGE21	l_stogir.417
    8d5c:      	ldr	x16, [x16]
		0000000000008d5c:  ARM64_RELOC_PAGEOFF12	l_stogir.417
    8d60:      	orr	x0, x16, xzr
    8d64:      	mov	x1, x0
    8d68:      	mov	x0, #0x1                ; =1
    8d6c:      	mov	x2, #0x1d               ; =29
    8d70:      	b	0x8cec <_stogir.vector.memory-inputs+0x11c>
    8d74:      	lsl	x0, x2, #4
    8d78:      	ldr	x1, [x20, #0x28]
    8d7c:      	add	x0, x0, x1
    8d80:      	ldr	x0, [x0]
    8d84:      	mov	x1, x0
    8d88:      	mov	x0, #0x1                ; =1
    8d8c:      	b	0x8d28 <_stogir.vector.memory-inputs+0x158>
    8d90:      	movz	x1, #0x0, lsl #48
    8d94:      	cmp	x1, #0x0
    8d98:      	b.eq	0x8d20 <_stogir.vector.memory-inputs+0x150>
    8d9c:      	uxtb	w16, w0
    8da0:      	cmp	w16, wzr
    8da4:      	b.eq	0x8d74 <_stogir.vector.memory-inputs+0x1a4>
    8da8:      	lsl	x0, x23, #4
    8dac:      	ldr	x1, [x20]
    8db0:      	add	x0, x0, x1
    8db4:      	ldr	x0, [x0]
    8db8:      	b	0x8d84 <_stogir.vector.memory-inputs+0x1b4>
    8dbc:      	movz	x1, #0x0, lsl #48
    8dc0:      	b	0x8d94 <_stogir.vector.memory-inputs+0x1c4>
    8dc4:      	cmp	x23, #0x0
    8dc8:      	b.ge	0x8d90 <_stogir.vector.memory-inputs+0x1c0>
    8dcc:      	add	x3, x20, #0x28
    8dd0:      	add	x4, x20, #0x50
    8dd4:      	ldr	x3, [x3, #0x8]
    8dd8:      	ldr	x4, [x4, #0x8]
    8ddc:      	cmp	x3, x4
    8de0:      	b.ne	0x8e64 <_stogir.vector.memory-inputs+0x294>
    8de4:      	cmp	x1, x3
    8de8:      	b.gt	0x8e74 <_stogir.vector.memory-inputs+0x2a4>
    8dec:      	lsl	x1, x2, #2
    8df0:      	ldr	x3, [x20, #0x50]
    8df4:      	add	x1, x1, x3
    8df8:      	ldr	w1, [x1]
    8dfc:      	sxtw	x1, w1
    8e00:      	cmp	x1, #0x0
    8e04:      	cset	w1, gt
    8e08:      	ubfx	x1, x1, #0, #8
    8e0c:      	b	0x8e78 <_stogir.vector.memory-inputs+0x2a8>
    8e10:      	cmp	x23, #0x0
    8e14:      	b.le	0x8e48 <_stogir.vector.memory-inputs+0x278>
    8e18:      	uxtb	w1, w1
    8e1c:      	cmp	x1, #0x83
    8e20:      	cset	w0, lt
    8e24:      	uxtb	w16, w0
    8e28:      	cmp	w16, wzr
    8e2c:      	b.eq	0x8e7c <_stogir.vector.memory-inputs+0x2ac>
    8e30:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008e30:  ARM64_RELOC_PAGE21	l_stogir.418
    8e34:      	ldr	x16, [x16]
		0000000000008e34:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8e38:      	orr	x2, x16, xzr
    8e3c:      	add	x2, x1, x2
    8e40:      	ldrb	w2, [x2]
    8e44:      	b	0x8e80 <_stogir.vector.memory-inputs+0x2b0>
    8e48:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008e48:  ARM64_RELOC_PAGE21	l_stogir.419
    8e4c:      	ldr	x16, [x16]
		0000000000008e4c:  ARM64_RELOC_PAGEOFF12	l_stogir.419
    8e50:      	orr	x0, x16, xzr
    8e54:      	mov	x1, x0
    8e58:      	mov	x0, #0x1                ; =1
    8e5c:      	mov	x2, #0x2c               ; =44
    8e60:      	b	0x8d70 <_stogir.vector.memory-inputs+0x1a0>
    8e64:      	movz	x1, #0x0, lsl #48
    8e68:      	b	0x8d94 <_stogir.vector.memory-inputs+0x1c4>
    8e6c:      	movz	x1, #0x0, lsl #48
    8e70:      	b	0x8dc0 <_stogir.vector.memory-inputs+0x1f0>
    8e74:      	movz	x1, #0x0, lsl #48
    8e78:      	b	0x8e68 <_stogir.vector.memory-inputs+0x298>
    8e7c:      	movz	x2, #0x0, lsl #48
    8e80:      	uxtb	w2, w2
    8e84:      	and	x2, x2, #0x1
    8e88:      	uxtb	w2, w2
    8e8c:      	cmp	x2, #0x0
    8e90:      	b.eq	0x8e48 <_stogir.vector.memory-inputs+0x278>
    8e94:      	uxtb	w16, w0
    8e98:      	cmp	w16, wzr
    8e9c:      	b.eq	0x8eb8 <_stogir.vector.memory-inputs+0x2e8>
    8ea0:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008ea0:  ARM64_RELOC_PAGE21	l_stogir.418
    8ea4:      	ldr	x16, [x16]
		0000000000008ea4:  ARM64_RELOC_PAGEOFF12	l_stogir.418
    8ea8:      	orr	x0, x16, xzr
    8eac:      	add	x0, x1, x0
    8eb0:      	ldrb	w0, [x0]
    8eb4:      	b	0x8ebc <_stogir.vector.memory-inputs+0x2ec>
    8eb8:      	movz	x0, #0x0, lsl #48
    8ebc:      	uxtb	w0, w0
    8ec0:      	and	x0, x0, #0x4
    8ec4:      	uxtb	w0, w0
    8ec8:      	cmp	x0, #0x0
    8ecc:      	b.ne	0x8e48 <_stogir.vector.memory-inputs+0x278>
    8ed0:      	sxtw	x24, w24
    8ed4:      	cmp	x24, #0x0
    8ed8:      	cset	w0, gt
    8edc:      	movz	x16, #0x0, lsl #48
    8ee0:      	sub	x1, x16, x24
    8ee4:      	sub	x2, x1, #0x1
    8ee8:      	uxtb	w16, w0
    8eec:      	cmp	w16, wzr
    8ef0:      	b.eq	0x8f50 <_stogir.vector.memory-inputs+0x380>
    8ef4:      	ldr	x1, [x20, #0x8]
    8ef8:      	cmp	x24, x1
    8efc:      	b.ge	0x8f9c <_stogir.vector.memory-inputs+0x3cc>
    8f00:      	add	x1, x20, #0x78
    8f04:      	ldr	x1, [x1, #0x8]
    8f08:      	cmp	x24, x1
    8f0c:      	b.ge	0x909c <_stogir.vector.memory-inputs+0x4cc>
    8f10:      	lsl	x1, x24, #2
    8f14:      	ldr	x3, [x20, #0x78]
    8f18:      	add	x1, x1, x3
    8f1c:      	ldr	w1, [x1]
    8f20:      	sxtw	x1, w1
    8f24:      	cmp	x1, #0x0
    8f28:      	cset	w1, ge
    8f2c:      	ubfx	x1, x1, #0, #8
    8f30:      	b	0x90a0 <_stogir.vector.memory-inputs+0x4d0>
    8f34:      	adrp	x16, 0x8000 <_stogir.vector-lanes.validate+0x294>
		0000000000008f34:  ARM64_RELOC_PAGE21	l_stogir.420
    8f38:      	ldr	x16, [x16]
		0000000000008f38:  ARM64_RELOC_PAGEOFF12	l_stogir.420
    8f3c:      	orr	x0, x16, xzr
    8f40:      	mov	x1, x0
    8f44:      	mov	x0, #0x1                ; =1
    8f48:      	mov	x2, #0x2b               ; =43
    8f4c:      	b	0x8e60 <_stogir.vector.memory-inputs+0x290>
    8f50:      	cmp	x24, #0x0
    8f54:      	b.ge	0x8fa4 <_stogir.vector.memory-inputs+0x3d4>
    8f58:      	add	x3, x20, #0x28
    8f5c:      	add	x4, x20, #0x50
    8f60:      	ldr	x3, [x3, #0x8]
    8f64:      	ldr	x4, [x4, #0x8]
    8f68:      	cmp	x3, x4
    8f6c:      	b.ne	0x9094 <_stogir.vector.memory-inputs+0x4c4>
    8f70:      	cmp	x1, x3
    8f74:      	b.gt	0x90ac <_stogir.vector.memory-inputs+0x4dc>
    8f78:      	lsl	x1, x2, #2
    8f7c:      	ldr	x3, [x20, #0x50]
    8f80:      	add	x1, x1, x3
    8f84:      	ldr	w1, [x1]
    8f88:      	sxtw	x1, w1
    8f8c:      	cmp	x1, #0x0
    8f90:      	cset	w1, gt
    8f94:      	ubfx	x1, x1, #0, #8
    8f98:      	b	0x90b0 <_stogir.vector.memory-inputs+0x4e0>
    8f9c:      	movz	x1, #0x0, lsl #48
    8fa0:      	b	0x8fa8 <_stogir.vector.memory-inputs+0x3d8>
    8fa4:      	movz	x1, #0x0, lsl #48
    8fa8:      	cmp	x1, #0x0
    8fac:      	b.eq	0x8fec <_stogir.vector.memory-inputs+0x41c>
    8fb0:      	uxtb	w16, w0
    8fb4:      	cmp	w16, wzr
    8fb8:      	b.eq	0x8fd0 <_stogir.vector.memory-inputs+0x400>
    8fbc:      	lsl	x0, x24, #4
    8fc0:      	ldr	x1, [x20]
    8fc4:      	add	x0, x0, x1
    8fc8:      	ldr	x0, [x0]
    8fcc:      	b	0x8fe0 <_stogir.vector.memory-inputs+0x410>
    8fd0:      	lsl	x0, x2, #4
    8fd4:      	ldr	x1, [x20, #0x28]
    8fd8:      	add	x0, x0, x1
    8fdc:      	ldr	x0, [x0]
    8fe0:      	mov	x1, x0
    8fe4:      	mov	x0, #0x1                ; =1
    8fe8:      	b	0x8ff4 <_stogir.vector.memory-inputs+0x424>
    8fec:      	movz	x0, #0x0, lsl #48
    8ff0:      	movz	x1, #0x0, lsl #48
    8ff4:      	lsr	w0, w0, #0
    8ff8:      	lsr	x16, x0, #0
    8ffc:      	cmp	x16, #0x1
    9000:      	b.eq	0x901c <_stogir.vector.memory-inputs+0x44c>
    9004:      	b.lo	0x900c <_stogir.vector.memory-inputs+0x43c>
    9008:      	b	0x9020 <_stogir.vector.memory-inputs+0x450>
    900c:      	cmp	x16, #0x0
    9010:      	b.eq	0x9018 <_stogir.vector.memory-inputs+0x448>
    9014:      	b	0x9020 <_stogir.vector.memory-inputs+0x450>
    9018:      	b	0x9024 <_stogir.vector.memory-inputs+0x454>
    901c:      	b	0x9040 <_stogir.vector.memory-inputs+0x470>
    9020:      	b	0x90b4 <_stogir.vector.memory-inputs+0x4e4>
    9024:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009024:  ARM64_RELOC_PAGE21	l_stogir.421
    9028:      	ldr	x16, [x16]
		0000000000009028:  ARM64_RELOC_PAGEOFF12	l_stogir.421
    902c:      	orr	x0, x16, xzr
    9030:      	mov	x1, x0
    9034:      	mov	x0, #0x1                ; =1
    9038:      	mov	x2, #0x1d               ; =29
    903c:      	b	0x8f4c <_stogir.vector.memory-inputs+0x37c>
    9040:      	lsr	w0, w1, #0
    9044:      	ubfx	x0, x0, #8, #8
    9048:      	cmp	x0, #0x6
    904c:      	b.ne	0x8f34 <_stogir.vector.memory-inputs+0x364>
    9050:      	uxtb	w1, w1
    9054:      	cmp	x1, #0x48
    9058:      	b.eq	0x8f34 <_stogir.vector.memory-inputs+0x364>
    905c:      	cmp	x1, #0x46
    9060:      	b.eq	0x8f34 <_stogir.vector.memory-inputs+0x364>
    9064:      	lsr	w21, w21, #0
    9068:      	lsr	w22, w22, #0
    906c:      	mov	w0, w21
    9070:      	mov	w1, w22
    9074:      	bl	0x9074 <_stogir.vector.memory-inputs+0x4a4>
		0000000000009074:  ARM64_RELOC_BRANCH26	_stogir.types.size
    9078:      	lsr	w0, w0, #0
    907c:      	sxtw	x0, w0
    9080:      	and	x0, x0, #0xffffffff
    9084:      	mov	x1, x0
    9088:      	movz	x0, #0x0, lsl #48
    908c:      	movz	x2, #0x0, lsl #48
    9090:      	b	0x8f4c <_stogir.vector.memory-inputs+0x37c>
    9094:      	movz	x1, #0x0, lsl #48
    9098:      	b	0x8fa8 <_stogir.vector.memory-inputs+0x3d8>
    909c:      	movz	x1, #0x0, lsl #48
    90a0:      	b	0x8fa0 <_stogir.vector.memory-inputs+0x3d0>
    90a4:      	brk	#0
    90a8:      	b	0x90a4 <_stogir.vector.memory-inputs+0x4d4>
    90ac:      	movz	x1, #0x0, lsl #48
    90b0:      	b	0x9098 <_stogir.vector.memory-inputs+0x4c8>
    90b4:      	brk	#0
    90b8:      	b	0x90b4 <_stogir.vector.memory-inputs+0x4e4>
    90bc:      	mov	x19, x8
    90c0:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x104>
    90c4:      	mov	x19, x8
    90c8:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x104>
    90cc:      	mov	x19, x8
    90d0:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x104>
    90d4:      	mov	x19, x8
    90d8:      	b	0x8cd4 <_stogir.vector.memory-inputs+0x104>

00000000000090dc <_stogir.vector.store-inputs>:
    90dc:      	sub	sp, sp, #0x40
    90e0:      	str	x29, [sp]
    90e4:      	str	x30, [sp, #0x8]
    90e8:      	mov	x29, sp
    90ec:      	str	x19, [sp, #0x30]
    90f0:      	sxtw	x4, w4
    90f4:      	cmp	x4, #0x0
    90f8:      	cset	w5, gt
    90fc:      	movz	x16, #0x0, lsl #48
    9100:      	sub	x6, x16, x4
    9104:      	sub	x7, x6, #0x1
    9108:      	uxtb	w16, w5
    910c:      	cmp	w16, wzr
    9110:      	b.eq	0x9154 <_stogir.vector.store-inputs+0x78>
    9114:      	ldr	x6, [x0, #0x8]
    9118:      	cmp	x4, x6
    911c:      	b.ge	0x91a8 <_stogir.vector.store-inputs+0xcc>
    9120:      	add	x6, x0, #0x78
    9124:      	ldr	x6, [x6, #0x8]
    9128:      	cmp	x4, x6
    912c:      	b.ge	0x92c0 <_stogir.vector.store-inputs+0x1e4>
    9130:      	lsl	x6, x4, #2
    9134:      	ldr	x9, [x0, #0x78]
    9138:      	add	x6, x6, x9
    913c:      	ldr	w6, [x6]
    9140:      	sxtw	x6, w6
    9144:      	cmp	x6, #0x0
    9148:      	cset	w6, ge
    914c:      	ubfx	x6, x6, #0, #8
    9150:      	b	0x92c4 <_stogir.vector.store-inputs+0x1e8>
    9154:      	cmp	x4, #0x0
    9158:      	b.ge	0x91b0 <_stogir.vector.store-inputs+0xd4>
    915c:      	add	x9, x0, #0x28
    9160:      	add	x10, x0, #0x50
    9164:      	ldr	x9, [x9, #0x8]
    9168:      	ldr	x10, [x10, #0x8]
    916c:      	cmp	x9, x10
    9170:      	b.ne	0x91a0 <_stogir.vector.store-inputs+0xc4>
    9174:      	cmp	x6, x9
    9178:      	b.gt	0x92c8 <_stogir.vector.store-inputs+0x1ec>
    917c:      	lsl	x6, x7, #2
    9180:      	ldr	x9, [x0, #0x50]
    9184:      	add	x6, x6, x9
    9188:      	ldr	w6, [x6]
    918c:      	sxtw	x6, w6
    9190:      	cmp	x6, #0x0
    9194:      	cset	w6, gt
    9198:      	ubfx	x6, x6, #0, #8
    919c:      	b	0x92cc <_stogir.vector.store-inputs+0x1f0>
    91a0:      	movz	x6, #0x0, lsl #48
    91a4:      	b	0x91b4 <_stogir.vector.store-inputs+0xd8>
    91a8:      	movz	x6, #0x0, lsl #48
    91ac:      	b	0x91b4 <_stogir.vector.store-inputs+0xd8>
    91b0:      	movz	x6, #0x0, lsl #48
    91b4:      	cmp	x6, #0x0
    91b8:      	b.eq	0x91f8 <_stogir.vector.store-inputs+0x11c>
    91bc:      	uxtb	w16, w5
    91c0:      	cmp	w16, wzr
    91c4:      	b.eq	0x91dc <_stogir.vector.store-inputs+0x100>
    91c8:      	lsl	x4, x4, #4
    91cc:      	ldr	x5, [x0]
    91d0:      	add	x4, x4, x5
    91d4:      	ldr	x4, [x4]
    91d8:      	b	0x91ec <_stogir.vector.store-inputs+0x110>
    91dc:      	lsl	x4, x7, #4
    91e0:      	ldr	x5, [x0, #0x28]
    91e4:      	add	x4, x4, x5
    91e8:      	ldr	x4, [x4]
    91ec:      	mov	x5, x4
    91f0:      	mov	x4, #0x1                ; =1
    91f4:      	b	0x9200 <_stogir.vector.store-inputs+0x124>
    91f8:      	movz	x4, #0x0, lsl #48
    91fc:      	movz	x5, #0x0, lsl #48
    9200:      	lsr	w4, w4, #0
    9204:      	lsr	x16, x4, #0
    9208:      	cmp	x16, #0x1
    920c:      	b.eq	0x9228 <_stogir.vector.store-inputs+0x14c>
    9210:      	b.lo	0x9218 <_stogir.vector.store-inputs+0x13c>
    9214:      	b	0x922c <_stogir.vector.store-inputs+0x150>
    9218:      	cmp	x16, #0x0
    921c:      	b.eq	0x9224 <_stogir.vector.store-inputs+0x148>
    9220:      	b	0x922c <_stogir.vector.store-inputs+0x150>
    9224:      	b	0x9230 <_stogir.vector.store-inputs+0x154>
    9228:      	b	0x9250 <_stogir.vector.store-inputs+0x174>
    922c:      	b	0x92d0 <_stogir.vector.store-inputs+0x1f4>
    9230:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009230:  ARM64_RELOC_PAGE21	l_stogir.422
    9234:      	ldr	x16, [x16]
		0000000000009234:  ARM64_RELOC_PAGEOFF12	l_stogir.422
    9238:      	orr	x0, x16, xzr
    923c:      	mov	x19, x8
    9240:      	mov	x1, x0
    9244:      	mov	x0, #0x1                ; =1
    9248:      	mov	x2, #0x1a               ; =26
    924c:      	b	0x92a0 <_stogir.vector.store-inputs+0x1c4>
    9250:      	lsr	w1, w1, #0
    9254:      	lsr	w2, w2, #0
    9258:      	lsr	w3, w3, #0
    925c:      	lsr	w5, w5, #0
    9260:      	ubfx	x4, x5, #8, #8
    9264:      	lsr	w4, w4, #0
    9268:      	mov	x19, x8
    926c:      	add	x8, sp, #0x10
    9270:      	fmov	s31, w1
    9274:      	mov	w1, w4
    9278:      	mov	w4, w3
    927c:      	mov	w3, w2
    9280:      	fmov	w2, s31
    9284:      	bl	0x9284 <_stogir.vector.store-inputs+0x1a8>
		0000000000009284:  ARM64_RELOC_BRANCH26	_stogir.vector.memory-inputs
    9288:      	add	x16, sp, #0x10
    928c:      	ldr	x0, [x16]
    9290:      	add	x16, sp, #0x10
    9294:      	ldr	x1, [x16, #0x8]
    9298:      	add	x16, sp, #0x10
    929c:      	ldr	x2, [x16, #0x10]
    92a0:      	str	x0, [x19]
    92a4:      	str	x1, [x19, #0x8]
    92a8:      	str	x2, [x19, #0x10]
    92ac:      	ldr	x19, [sp, #0x30]
    92b0:      	ldr	x29, [sp]
    92b4:      	ldr	x30, [sp, #0x8]
    92b8:      	add	sp, sp, #0x40
    92bc:      	ret
    92c0:      	movz	x6, #0x0, lsl #48
    92c4:      	b	0x91ac <_stogir.vector.store-inputs+0xd0>
    92c8:      	movz	x6, #0x0, lsl #48
    92cc:      	b	0x91a4 <_stogir.vector.store-inputs+0xc8>
    92d0:      	brk	#0
    92d4:      	b	0x92d0 <_stogir.vector.store-inputs+0x1f4>

00000000000092d8 <_stogir.types.size>:
    92d8:      	sub	sp, sp, #0x60
    92dc:      	str	x29, [sp]
    92e0:      	str	x30, [sp, #0x8]
    92e4:      	mov	x29, sp
    92e8:      	str	x19, [sp, #0x10]
    92ec:      	str	x20, [sp, #0x18]
    92f0:      	str	x21, [sp, #0x20]
    92f4:      	str	x22, [sp, #0x28]
    92f8:      	str	x23, [sp, #0x30]
    92fc:      	str	x24, [sp, #0x38]
    9300:      	str	x25, [sp, #0x40]
    9304:      	str	x26, [sp, #0x48]
    9308:      	str	x27, [sp, #0x50]
    930c:      	str	x28, [sp, #0x58]
    9310:      	sxtw	x19, w0
    9314:      	sxtw	x20, w1
    9318:      	cmp	x19, #0xf
    931c:      	cset	w21, gt
    9320:      	cmp	x19, #0x0
    9324:      	cset	w22, eq
    9328:      	cmp	x20, #0x4
    932c:      	cset	w23, eq
    9330:      	cmp	x20, #0x8
    9334:      	cset	w24, eq
    9338:      	uxtb	w16, w21
    933c:      	cmp	w16, wzr
    9340:      	b.eq	0x93a4 <_stogir.types.size+0xcc>
    9344:      	cmp	x19, #0x80
    9348:      	cset	w25, lt
    934c:      	uxtb	w16, w25
    9350:      	cmp	w16, wzr
    9354:      	b.eq	0x93a4 <_stogir.types.size+0xcc>
    9358:      	and	x1, x19, #0xf
    935c:      	lsr	w1, w1, #0
    9360:      	sxtw	x26, w1
    9364:      	cmp	x26, #0x1
    9368:      	cset	w27, ge
    936c:      	uxtb	w16, w27
    9370:      	cmp	w16, wzr
    9374:      	b.eq	0x93a4 <_stogir.types.size+0xcc>
    9378:      	cmp	x26, #0xd
    937c:      	cset	w28, le
    9380:      	uxtb	w16, w28
    9384:      	cmp	w16, wzr
    9388:      	b.eq	0x93a4 <_stogir.types.size+0xcc>
    938c:      	lsr	w0, w0, #0
    9390:      	bl	0x9390 <_stogir.types.size+0xb8>
		0000000000009390:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    9394:      	cmp	x0, #0x0
    9398:      	b.eq	0x9484 <_stogir.types.size+0x1ac>
    939c:      	mov	x0, x26
    93a0:      	b	0x9488 <_stogir.types.size+0x1b0>
    93a4:      	uxtb	w16, w23
    93a8:      	cmp	w16, wzr
    93ac:      	b.ne	0x93c4 <_stogir.types.size+0xec>
    93b0:      	uxtb	w16, w24
    93b4:      	cmp	w16, wzr
    93b8:      	b.ne	0x93c4 <_stogir.types.size+0xec>
    93bc:      	movn	x0, #0x0, lsl #48
    93c0:      	b	0x93dc <_stogir.types.size+0x104>
    93c4:      	uxtb	w16, w22
    93c8:      	cmp	w16, wzr
    93cc:      	b.eq	0x9414 <_stogir.types.size+0x13c>
    93d0:      	movz	x0, #0x0, lsl #48
    93d4:      	b	0x93dc <_stogir.types.size+0x104>
    93d8:      	mov	x0, #0x1                ; =1
    93dc:      	ldr	x19, [sp, #0x10]
    93e0:      	ldr	x20, [sp, #0x18]
    93e4:      	ldr	x21, [sp, #0x20]
    93e8:      	ldr	x22, [sp, #0x28]
    93ec:      	ldr	x23, [sp, #0x30]
    93f0:      	ldr	x24, [sp, #0x38]
    93f4:      	ldr	x25, [sp, #0x40]
    93f8:      	ldr	x26, [sp, #0x48]
    93fc:      	ldr	x27, [sp, #0x50]
    9400:      	ldr	x28, [sp, #0x58]
    9404:      	ldr	x29, [sp]
    9408:      	ldr	x30, [sp, #0x8]
    940c:      	add	sp, sp, #0x60
    9410:      	ret
    9414:      	cmp	x19, #0x1
    9418:      	b.eq	0x93d8 <_stogir.types.size+0x100>
    941c:      	cmp	x19, #0x2
    9420:      	b.eq	0x93d8 <_stogir.types.size+0x100>
    9424:      	cmp	x19, #0x7
    9428:      	b.eq	0x93d8 <_stogir.types.size+0x100>
    942c:      	cmp	x19, #0x8
    9430:      	b.eq	0x93d8 <_stogir.types.size+0x100>
    9434:      	cmp	x19, #0x3
    9438:      	b.eq	0x95f4 <_stogir.types.size+0x31c>
    943c:      	cmp	x19, #0x9
    9440:      	b.eq	0x95f4 <_stogir.types.size+0x31c>
    9444:      	cmp	x19, #0x4
    9448:      	b.eq	0x961c <_stogir.types.size+0x344>
    944c:      	cmp	x19, #0xa
    9450:      	b.eq	0x961c <_stogir.types.size+0x344>
    9454:      	cmp	x19, #0xd
    9458:      	b.eq	0x961c <_stogir.types.size+0x344>
    945c:      	cmp	x19, #0x5
    9460:      	b.eq	0x962c <_stogir.types.size+0x354>
    9464:      	cmp	x19, #0xb
    9468:      	b.eq	0x962c <_stogir.types.size+0x354>
    946c:      	cmp	x19, #0xc
    9470:      	b.eq	0x962c <_stogir.types.size+0x354>
    9474:      	cmp	x19, #0x6
    9478:      	b.ne	0x963c <_stogir.types.size+0x364>
    947c:      	mov	x0, x20
    9480:      	b	0x9640 <_stogir.types.size+0x368>
    9484:      	movn	x0, #0x0, lsl #48
    9488:      	uxtb	w16, w23
    948c:      	cmp	w16, wzr
    9490:      	b.ne	0x94a8 <_stogir.types.size+0x1d0>
    9494:      	uxtb	w16, w24
    9498:      	cmp	w16, wzr
    949c:      	b.ne	0x94a8 <_stogir.types.size+0x1d0>
    94a0:      	movn	x0, #0x0, lsl #48
    94a4:      	b	0x94c4 <_stogir.types.size+0x1ec>
    94a8:      	lsr	w0, w0, #0
    94ac:      	sxtw	x0, w0
    94b0:      	cmp	x0, #0x0
    94b4:      	b.ne	0x9584 <_stogir.types.size+0x2ac>
    94b8:      	movz	x0, #0x0, lsl #48
    94bc:      	b	0x94c4 <_stogir.types.size+0x1ec>
    94c0:      	mov	x0, #0x1                ; =1
    94c4:      	lsr	w0, w0, #0
    94c8:      	sxtw	x0, w0
    94cc:      	cmp	x0, #0x0
    94d0:      	b.ge	0x952c <_stogir.types.size+0x254>
    94d4:      	movn	x0, #0x0, lsl #48
    94d8:      	b	0x94f4 <_stogir.types.size+0x21c>
    94dc:      	movn	x1, #0x0, lsl #48
    94e0:      	lsr	w1, w1, #0
    94e4:      	sxtw	x1, w1
    94e8:      	mul	x0, x1, x0
    94ec:      	lsr	w0, w0, #0
    94f0:      	sxtw	x0, w0
    94f4:      	ldr	x19, [sp, #0x10]
    94f8:      	ldr	x20, [sp, #0x18]
    94fc:      	ldr	x21, [sp, #0x20]
    9500:      	ldr	x22, [sp, #0x28]
    9504:      	ldr	x23, [sp, #0x30]
    9508:      	ldr	x24, [sp, #0x38]
    950c:      	ldr	x25, [sp, #0x40]
    9510:      	ldr	x26, [sp, #0x48]
    9514:      	ldr	x27, [sp, #0x50]
    9518:      	ldr	x28, [sp, #0x58]
    951c:      	ldr	x29, [sp]
    9520:      	ldr	x30, [sp, #0x8]
    9524:      	add	sp, sp, #0x60
    9528:      	ret
    952c:      	uxtb	w16, w21
    9530:      	cmp	w16, wzr
    9534:      	b.eq	0x95fc <_stogir.types.size+0x324>
    9538:      	uxtb	w16, w25
    953c:      	cmp	w16, wzr
    9540:      	b.eq	0x95fc <_stogir.types.size+0x324>
    9544:      	uxtb	w16, w27
    9548:      	cmp	w16, wzr
    954c:      	b.eq	0x95fc <_stogir.types.size+0x324>
    9550:      	uxtb	w16, w28
    9554:      	cmp	w16, wzr
    9558:      	b.eq	0x95fc <_stogir.types.size+0x324>
    955c:      	ubfx	x1, x19, #4, #32
    9560:      	sxtw	x1, w1
    9564:      	sub	x1, x1, #0x1
    9568:      	lsr	w1, w1, #0
    956c:      	sxtw	x1, w1
    9570:      	mov	x16, #0x1               ; =1
    9574:      	lsl	x1, x16, x1
    9578:      	lsr	w1, w1, #0
    957c:      	sxtw	x1, w1
    9580:      	b	0x94e0 <_stogir.types.size+0x208>
    9584:      	cmp	x0, #0x1
    9588:      	b.eq	0x94c0 <_stogir.types.size+0x1e8>
    958c:      	cmp	x0, #0x2
    9590:      	b.eq	0x94c0 <_stogir.types.size+0x1e8>
    9594:      	cmp	x0, #0x7
    9598:      	b.eq	0x94c0 <_stogir.types.size+0x1e8>
    959c:      	cmp	x0, #0x8
    95a0:      	b.eq	0x94c0 <_stogir.types.size+0x1e8>
    95a4:      	cmp	x0, #0x3
    95a8:      	b.eq	0x9624 <_stogir.types.size+0x34c>
    95ac:      	cmp	x0, #0x9
    95b0:      	b.eq	0x9624 <_stogir.types.size+0x34c>
    95b4:      	cmp	x0, #0x4
    95b8:      	b.eq	0x9634 <_stogir.types.size+0x35c>
    95bc:      	cmp	x0, #0xa
    95c0:      	b.eq	0x9634 <_stogir.types.size+0x35c>
    95c4:      	cmp	x0, #0xd
    95c8:      	b.eq	0x9634 <_stogir.types.size+0x35c>
    95cc:      	cmp	x0, #0x5
    95d0:      	b.eq	0x9644 <_stogir.types.size+0x36c>
    95d4:      	cmp	x0, #0xb
    95d8:      	b.eq	0x9644 <_stogir.types.size+0x36c>
    95dc:      	cmp	x0, #0xc
    95e0:      	b.eq	0x9644 <_stogir.types.size+0x36c>
    95e4:      	cmp	x0, #0x6
    95e8:      	b.ne	0x964c <_stogir.types.size+0x374>
    95ec:      	mov	x0, x20
    95f0:      	b	0x9650 <_stogir.types.size+0x378>
    95f4:      	mov	x0, #0x2                ; =2
    95f8:      	b	0x93dc <_stogir.types.size+0x104>
    95fc:      	cmp	x19, #0x0
    9600:      	b.lt	0x94dc <_stogir.types.size+0x204>
    9604:      	cmp	x19, #0xd
    9608:      	b.gt	0x94dc <_stogir.types.size+0x204>
    960c:      	uxtb	w16, w22
    9610:      	cmp	w16, wzr
    9614:      	cset	x1, eq
    9618:      	b	0x94e0 <_stogir.types.size+0x208>
    961c:      	mov	x0, #0x4                ; =4
    9620:      	b	0x95f8 <_stogir.types.size+0x320>
    9624:      	mov	x0, #0x2                ; =2
    9628:      	b	0x94c4 <_stogir.types.size+0x1ec>
    962c:      	mov	x0, #0x8                ; =8
    9630:      	b	0x9620 <_stogir.types.size+0x348>
    9634:      	mov	x0, #0x4                ; =4
    9638:      	b	0x9628 <_stogir.types.size+0x350>
    963c:      	movn	x0, #0x0, lsl #48
    9640:      	b	0x9630 <_stogir.types.size+0x358>
    9644:      	mov	x0, #0x8                ; =8
    9648:      	b	0x9638 <_stogir.types.size+0x360>
    964c:      	movn	x0, #0x0, lsl #48
    9650:      	b	0x9648 <_stogir.types.size+0x370>

0000000000009654 <_stogir.opcode.properties>:
    9654:      	sxtw	x0, w0
    9658:      	cmp	x0, #0x0
    965c:      	b.lt	0x9684 <_stogir.opcode.properties+0x30>
    9660:      	cmp	x0, #0x83
    9664:      	b.ge	0x9684 <_stogir.opcode.properties+0x30>
    9668:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009668:  ARM64_RELOC_PAGE21	l_stogir.423
    966c:      	ldr	x16, [x16]
		000000000000966c:  ARM64_RELOC_PAGEOFF12	l_stogir.423
    9670:      	orr	x1, x16, xzr
    9674:      	lsr	x0, x0, #0
    9678:      	add	x0, x0, x1
    967c:      	ldrb	w0, [x0]
    9680:      	b	0x9688 <_stogir.opcode.properties+0x34>
    9684:      	movz	x0, #0x0, lsl #48
    9688:      	ret

000000000000968c <_stogir.checked.projection>:
    968c:      	sub	sp, sp, #0x40
    9690:      	str	x29, [sp]
    9694:      	str	x30, [sp, #0x8]
    9698:      	mov	x29, sp
    969c:      	str	x19, [sp, #0x30]
    96a0:      	sxtw	x2, w1
    96a4:      	cmp	x2, #0x0
    96a8:      	cset	w3, gt
    96ac:      	movz	x16, #0x0, lsl #48
    96b0:      	sub	x4, x16, x2
    96b4:      	sub	x5, x4, #0x1
    96b8:      	uxtb	w16, w3
    96bc:      	cmp	w16, wzr
    96c0:      	b.eq	0x9704 <_stogir.checked.projection+0x78>
    96c4:      	ldr	x4, [x0, #0x8]
    96c8:      	cmp	x2, x4
    96cc:      	b.ge	0x9758 <_stogir.checked.projection+0xcc>
    96d0:      	add	x4, x0, #0x78
    96d4:      	ldr	x4, [x4, #0x8]
    96d8:      	cmp	x2, x4
    96dc:      	b.ge	0x9878 <_stogir.checked.projection+0x1ec>
    96e0:      	lsl	x4, x2, #2
    96e4:      	ldr	x6, [x0, #0x78]
    96e8:      	add	x4, x4, x6
    96ec:      	ldr	w4, [x4]
    96f0:      	sxtw	x4, w4
    96f4:      	cmp	x4, #0x0
    96f8:      	cset	w4, ge
    96fc:      	ubfx	x4, x4, #0, #8
    9700:      	b	0x987c <_stogir.checked.projection+0x1f0>
    9704:      	cmp	x2, #0x0
    9708:      	b.ge	0x9760 <_stogir.checked.projection+0xd4>
    970c:      	add	x6, x0, #0x28
    9710:      	add	x7, x0, #0x50
    9714:      	ldr	x6, [x6, #0x8]
    9718:      	ldr	x7, [x7, #0x8]
    971c:      	cmp	x6, x7
    9720:      	b.ne	0x9750 <_stogir.checked.projection+0xc4>
    9724:      	cmp	x4, x6
    9728:      	b.gt	0x98a8 <_stogir.checked.projection+0x21c>
    972c:      	lsl	x4, x5, #2
    9730:      	ldr	x6, [x0, #0x50]
    9734:      	add	x4, x4, x6
    9738:      	ldr	w4, [x4]
    973c:      	sxtw	x4, w4
    9740:      	cmp	x4, #0x0
    9744:      	cset	w4, gt
    9748:      	ubfx	x4, x4, #0, #8
    974c:      	b	0x98ac <_stogir.checked.projection+0x220>
    9750:      	movz	x4, #0x0, lsl #48
    9754:      	b	0x9764 <_stogir.checked.projection+0xd8>
    9758:      	movz	x4, #0x0, lsl #48
    975c:      	b	0x9764 <_stogir.checked.projection+0xd8>
    9760:      	movz	x4, #0x0, lsl #48
    9764:      	cmp	x4, #0x0
    9768:      	b.eq	0x97a8 <_stogir.checked.projection+0x11c>
    976c:      	uxtb	w16, w3
    9770:      	cmp	w16, wzr
    9774:      	b.eq	0x978c <_stogir.checked.projection+0x100>
    9778:      	lsl	x2, x2, #4
    977c:      	ldr	x3, [x0]
    9780:      	add	x2, x2, x3
    9784:      	ldr	x2, [x2]
    9788:      	b	0x979c <_stogir.checked.projection+0x110>
    978c:      	lsl	x2, x5, #4
    9790:      	ldr	x3, [x0, #0x28]
    9794:      	add	x2, x2, x3
    9798:      	ldr	x2, [x2]
    979c:      	mov	x3, x2
    97a0:      	mov	x2, #0x1                ; =1
    97a4:      	b	0x97b0 <_stogir.checked.projection+0x124>
    97a8:      	movz	x2, #0x0, lsl #48
    97ac:      	movz	x3, #0x0, lsl #48
    97b0:      	lsr	w2, w2, #0
    97b4:      	lsr	x16, x2, #0
    97b8:      	cmp	x16, #0x1
    97bc:      	b.eq	0x97d8 <_stogir.checked.projection+0x14c>
    97c0:      	b.lo	0x97c8 <_stogir.checked.projection+0x13c>
    97c4:      	b	0x97dc <_stogir.checked.projection+0x150>
    97c8:      	cmp	x16, #0x0
    97cc:      	b.eq	0x97d4 <_stogir.checked.projection+0x148>
    97d0:      	b	0x97dc <_stogir.checked.projection+0x150>
    97d4:      	b	0x97e0 <_stogir.checked.projection+0x154>
    97d8:      	b	0x9838 <_stogir.checked.projection+0x1ac>
    97dc:      	b	0x98b0 <_stogir.checked.projection+0x224>
    97e0:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		00000000000097e0:  ARM64_RELOC_PAGE21	l_stogir.424
    97e4:      	ldr	x16, [x16]
		00000000000097e4:  ARM64_RELOC_PAGEOFF12	l_stogir.424
    97e8:      	orr	x0, x16, xzr
    97ec:      	mov	x19, x8
    97f0:      	mov	x1, x0
    97f4:      	mov	x0, #0x1                ; =1
    97f8:      	mov	x2, #0x17               ; =23
    97fc:      	b	0x9818 <_stogir.checked.projection+0x18c>
    9800:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009800:  ARM64_RELOC_PAGE21	l_stogir.425
    9804:      	ldr	x16, [x16]
		0000000000009804:  ARM64_RELOC_PAGEOFF12	l_stogir.425
    9808:      	orr	x0, x16, xzr
    980c:      	mov	x1, x0
    9810:      	mov	x0, #0x1                ; =1
    9814:      	mov	x2, #0x20               ; =32
    9818:      	str	x0, [x19]
    981c:      	str	x1, [x19, #0x8]
    9820:      	str	x2, [x19, #0x10]
    9824:      	ldr	x19, [sp, #0x30]
    9828:      	ldr	x29, [sp]
    982c:      	ldr	x30, [sp, #0x8]
    9830:      	add	sp, sp, #0x40
    9834:      	ret
    9838:      	uxtb	w2, w3
    983c:      	cmp	x2, #0x29
    9840:      	b.lt	0x98b8 <_stogir.checked.projection+0x22c>
    9844:      	cmp	x2, #0x2b
    9848:      	b.gt	0x98c0 <_stogir.checked.projection+0x234>
    984c:      	lsr	w1, w1, #0
    9850:      	mov	x19, x8
    9854:      	add	x8, sp, #0x10
    9858:      	bl	0x9858 <_stogir.checked.projection+0x1cc>
		0000000000009858:  ARM64_RELOC_BRANCH26	_stogir.checked.validate
    985c:      	add	x16, sp, #0x10
    9860:      	ldr	x0, [x16]
    9864:      	add	x16, sp, #0x10
    9868:      	ldr	x1, [x16, #0x8]
    986c:      	add	x16, sp, #0x10
    9870:      	ldr	x2, [x16, #0x10]
    9874:      	b	0x9818 <_stogir.checked.projection+0x18c>
    9878:      	movz	x4, #0x0, lsl #48
    987c:      	b	0x975c <_stogir.checked.projection+0xd0>
    9880:      	lsr	w3, w3, #0
    9884:      	ubfx	x0, x3, #8, #8
    9888:      	cmp	x0, #0x0
    988c:      	b.eq	0x9800 <_stogir.checked.projection+0x174>
    9890:      	cmp	x0, #0xd
    9894:      	b.gt	0x9800 <_stogir.checked.projection+0x174>
    9898:      	movz	x0, #0x0, lsl #48
    989c:      	movz	x1, #0x0, lsl #48
    98a0:      	movz	x2, #0x0, lsl #48
    98a4:      	b	0x9818 <_stogir.checked.projection+0x18c>
    98a8:      	movz	x4, #0x0, lsl #48
    98ac:      	b	0x9754 <_stogir.checked.projection+0xc8>
    98b0:      	brk	#0
    98b4:      	b	0x98b0 <_stogir.checked.projection+0x224>
    98b8:      	mov	x19, x8
    98bc:      	b	0x9880 <_stogir.checked.projection+0x1f4>
    98c0:      	mov	x19, x8
    98c4:      	b	0x9880 <_stogir.checked.projection+0x1f4>

00000000000098c8 <_stogir.checked.operands>:
    98c8:      	sub	sp, sp, #0x50
    98cc:      	str	x29, [sp]
    98d0:      	str	x30, [sp, #0x8]
    98d4:      	mov	x29, sp
    98d8:      	str	x19, [sp, #0x30]
    98dc:      	str	x20, [sp, #0x38]
    98e0:      	str	x21, [sp, #0x40]
    98e4:      	str	x22, [sp, #0x48]
    98e8:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		00000000000098e8:  ARM64_RELOC_PAGE21	l_stogir.426
    98ec:      	ldr	x16, [x16]
		00000000000098ec:  ARM64_RELOC_PAGEOFF12	l_stogir.426
    98f0:      	orr	x5, x16, xzr
    98f4:      	sxtw	x1, w1
    98f8:      	sxtw	x19, w2
    98fc:      	cmp	x1, #0x29
    9900:      	b.lt	0x9940 <_stogir.checked.operands+0x78>
    9904:      	cmp	x1, #0x2b
    9908:      	b.gt	0x9940 <_stogir.checked.operands+0x78>
    990c:      	cmp	x19, #0x1
    9910:      	b.lt	0x9940 <_stogir.checked.operands+0x78>
    9914:      	cmp	x19, #0xb
    9918:      	b.gt	0x9940 <_stogir.checked.operands+0x78>
    991c:      	cmp	x19, #0x1
    9920:      	b.eq	0x9940 <_stogir.checked.operands+0x78>
    9924:      	mov	x1, x5
    9928:      	movz	x2, #0x0, lsl #48
    992c:      	b	0x9950 <_stogir.checked.operands+0x88>
    9930:      	movz	x4, #0x0, lsl #48
    9934:      	b	0x99b8 <_stogir.checked.operands+0xf0>
    9938:      	movz	x4, #0x0, lsl #48
    993c:      	b	0x99cc <_stogir.checked.operands+0x104>
    9940:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009940:  ARM64_RELOC_PAGE21	l_stogir.427
    9944:      	ldr	x16, [x16]
		0000000000009944:  ARM64_RELOC_PAGEOFF12	l_stogir.427
    9948:      	orr	x1, x16, xzr
    994c:      	mov	x2, #0x36               ; =54
    9950:      	add	x16, sp, #0x20
    9954:      	orr	x6, x16, xzr
    9958:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009958:  ARM64_RELOC_PAGE21	l_stogir.428
    995c:      	ldr	x16, [x16]
		000000000000995c:  ARM64_RELOC_PAGEOFF12	l_stogir.428
    9960:      	orr	x7, x16, xzr
    9964:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009964:  ARM64_RELOC_PAGE21	l_stogir.429
    9968:      	ldr	x16, [x16]
		0000000000009968:  ARM64_RELOC_PAGEOFF12	l_stogir.429
    996c:      	orr	x9, x16, xzr
    9970:      	lsr	w3, w3, #0
    9974:      	lsr	w4, w4, #0
    9978:      	add	x10, x0, #0x78
    997c:      	add	x11, x0, #0x28
    9980:      	add	x12, x0, #0x50
    9984:      	add	x16, sp, #0x10
    9988:      	str	w3, [x16]
    998c:      	add	x16, sp, #0x10
    9990:      	str	w4, [x16, #0x4]
    9994:      	add	x16, sp, #0x10
    9998:      	ldr	x3, [x16]
    999c:      	add	x16, sp, #0x20
    99a0:      	str	x3, [x16]
    99a4:      	mov	x20, x1
    99a8:      	mov	x21, x2
    99ac:      	movz	x1, #0x0, lsl #48
    99b0:      	b	0x9a74 <_stogir.checked.operands+0x1ac>
    99b4:      	movz	x4, #0x0, lsl #48
    99b8:      	fmov	d31, x3
    99bc:      	mov	x3, x4
    99c0:      	fmov	x4, d31
    99c4:      	b	0x99d8 <_stogir.checked.operands+0x110>
    99c8:      	movz	x4, #0x0, lsl #48
    99cc:      	fmov	d31, x3
    99d0:      	mov	x3, x4
    99d4:      	fmov	x4, d31
    99d8:      	cmp	x3, #0x0
    99dc:      	b.eq	0x9a1c <_stogir.checked.operands+0x154>
    99e0:      	uxtb	w16, w1
    99e4:      	cmp	w16, wzr
    99e8:      	b.eq	0x9a00 <_stogir.checked.operands+0x138>
    99ec:      	lsl	x1, x2, #4
    99f0:      	ldr	x2, [x0]
    99f4:      	add	x1, x1, x2
    99f8:      	ldr	x1, [x1]
    99fc:      	b	0x9a10 <_stogir.checked.operands+0x148>
    9a00:      	lsl	x1, x13, #4
    9a04:      	ldr	x2, [x0, #0x28]
    9a08:      	add	x1, x1, x2
    9a0c:      	ldr	x1, [x1]
    9a10:      	mov	x2, x1
    9a14:      	mov	x1, #0x1                ; =1
    9a18:      	b	0x9a24 <_stogir.checked.operands+0x15c>
    9a1c:      	movz	x1, #0x0, lsl #48
    9a20:      	movz	x2, #0x0, lsl #48
    9a24:      	lsr	w1, w1, #0
    9a28:      	lsr	x16, x1, #0
    9a2c:      	cmp	x16, #0x1
    9a30:      	b.eq	0x9a4c <_stogir.checked.operands+0x184>
    9a34:      	b.lo	0x9a3c <_stogir.checked.operands+0x174>
    9a38:      	b	0x9a50 <_stogir.checked.operands+0x188>
    9a3c:      	cmp	x16, #0x0
    9a40:      	b.eq	0x9a48 <_stogir.checked.operands+0x180>
    9a44:      	b	0x9a50 <_stogir.checked.operands+0x188>
    9a48:      	b	0x9a54 <_stogir.checked.operands+0x18c>
    9a4c:      	b	0x9c10 <_stogir.checked.operands+0x348>
    9a50:      	b	0x9c3c <_stogir.checked.operands+0x374>
    9a54:      	mov	x1, x7
    9a58:      	mov	x2, #0x22               ; =34
    9a5c:      	b	0x9a68 <_stogir.checked.operands+0x1a0>
    9a60:      	mov	x1, x9
    9a64:      	mov	x2, #0x28               ; =40
    9a68:      	mov	x20, x1
    9a6c:      	mov	x21, x2
    9a70:      	mov	x1, x4
    9a74:      	cmp	x1, #0x2
    9a78:      	b.ge	0x9aa4 <_stogir.checked.operands+0x1dc>
    9a7c:      	add	x2, x1, #0x1
    9a80:      	lsl	x1, x1, #2
    9a84:      	add	x1, x1, x6
    9a88:      	ldr	w1, [x1]
    9a8c:      	sxtw	x1, w1
    9a90:      	and	x1, x1, #0xffffffff
    9a94:      	mov	x3, x2
    9a98:      	mov	x2, x1
    9a9c:      	mov	x1, #0x1                ; =1
    9aa0:      	b	0x9ab0 <_stogir.checked.operands+0x1e8>
    9aa4:      	mov	x3, x1
    9aa8:      	movz	x1, #0x0, lsl #48
    9aac:      	movz	x2, #0x0, lsl #48
    9ab0:      	lsr	w1, w1, #0
    9ab4:      	lsr	x16, x1, #0
    9ab8:      	cmp	x16, #0x1
    9abc:      	b.eq	0x9ad8 <_stogir.checked.operands+0x210>
    9ac0:      	b.lo	0x9ac8 <_stogir.checked.operands+0x200>
    9ac4:      	b	0x9adc <_stogir.checked.operands+0x214>
    9ac8:      	cmp	x16, #0x0
    9acc:      	b.eq	0x9ad4 <_stogir.checked.operands+0x20c>
    9ad0:      	b	0x9adc <_stogir.checked.operands+0x214>
    9ad4:      	b	0x9b44 <_stogir.checked.operands+0x27c>
    9ad8:      	b	0x9ae0 <_stogir.checked.operands+0x218>
    9adc:      	b	0x9c34 <_stogir.checked.operands+0x36c>
    9ae0:      	lsr	w2, w2, #0
    9ae4:      	sxtw	x2, w2
    9ae8:      	cmp	x2, #0x0
    9aec:      	cset	w1, gt
    9af0:      	movz	x16, #0x0, lsl #48
    9af4:      	sub	x4, x16, x2
    9af8:      	sub	x13, x4, #0x1
    9afc:      	uxtb	w16, w1
    9b00:      	cmp	w16, wzr
    9b04:      	b.eq	0x9b6c <_stogir.checked.operands+0x2a4>
    9b08:      	ldr	x4, [x0, #0x8]
    9b0c:      	cmp	x2, x4
    9b10:      	b.ge	0x99b4 <_stogir.checked.operands+0xec>
    9b14:      	ldr	x4, [x10, #0x8]
    9b18:      	cmp	x2, x4
    9b1c:      	b.ge	0x9930 <_stogir.checked.operands+0x68>
    9b20:      	lsl	x4, x2, #2
    9b24:      	ldr	x14, [x0, #0x78]
    9b28:      	add	x4, x4, x14
    9b2c:      	ldr	w4, [x4]
    9b30:      	sxtw	x4, w4
    9b34:      	cmp	x4, #0x0
    9b38:      	cset	w4, ge
    9b3c:      	ubfx	x4, x4, #0, #8
    9b40:      	b	0x9934 <_stogir.checked.operands+0x6c>
    9b44:      	cmp	x21, #0x0
    9b48:      	b.ne	0x9c44 <_stogir.checked.operands+0x37c>
    9b4c:      	cmp	x21, #0x0
    9b50:      	b.ne	0x9bb0 <_stogir.checked.operands+0x2e8>
    9b54:      	mov	x22, x8
    9b58:      	and	x0, x19, #0xffffffff
    9b5c:      	mov	x1, x0
    9b60:      	movz	x0, #0x0, lsl #48
    9b64:      	movz	x2, #0x0, lsl #48
    9b68:      	b	0x9be4 <_stogir.checked.operands+0x31c>
    9b6c:      	cmp	x2, #0x0
    9b70:      	b.ge	0x99c8 <_stogir.checked.operands+0x100>
    9b74:      	ldr	x14, [x11, #0x8]
    9b78:      	ldr	x15, [x12, #0x8]
    9b7c:      	cmp	x14, x15
    9b80:      	b.ne	0x9938 <_stogir.checked.operands+0x70>
    9b84:      	cmp	x4, x14
    9b88:      	b.gt	0x9c2c <_stogir.checked.operands+0x364>
    9b8c:      	lsl	x4, x13, #2
    9b90:      	ldr	x14, [x0, #0x50]
    9b94:      	add	x4, x4, x14
    9b98:      	ldr	w4, [x4]
    9b9c:      	sxtw	x4, w4
    9ba0:      	cmp	x4, #0x0
    9ba4:      	cset	w4, gt
    9ba8:      	ubfx	x4, x4, #0, #8
    9bac:      	b	0x9c30 <_stogir.checked.operands+0x368>
    9bb0:      	lsr	x0, x21, #0
    9bb4:      	mov	x1, x5
    9bb8:      	mov	x2, x0
    9bbc:      	mov	x0, x20
    9bc0:      	mov	x22, x8
    9bc4:      	bl	0x9bc4 <_stogir.checked.operands+0x2fc>
		0000000000009bc4:  ARM64_RELOC_BRANCH26	_memcmp
    9bc8:      	lsr	w0, w0, #0
    9bcc:      	sxtw	x0, w0
    9bd0:      	cmp	x0, #0x0
    9bd4:      	b.eq	0x9b58 <_stogir.checked.operands+0x290>
    9bd8:      	mov	x1, x20
    9bdc:      	mov	x2, x21
    9be0:      	mov	x0, #0x1                ; =1
    9be4:      	str	x0, [x22]
    9be8:      	str	x1, [x22, #0x8]
    9bec:      	str	x2, [x22, #0x10]
    9bf0:      	ldr	x19, [sp, #0x30]
    9bf4:      	ldr	x20, [sp, #0x38]
    9bf8:      	ldr	x21, [sp, #0x40]
    9bfc:      	ldr	x22, [sp, #0x48]
    9c00:      	ldr	x29, [sp]
    9c04:      	ldr	x30, [sp, #0x8]
    9c08:      	add	sp, sp, #0x50
    9c0c:      	ret
    9c10:      	lsr	w2, w2, #0
    9c14:      	ubfx	x1, x2, #8, #8
    9c18:      	cmp	x1, x19
    9c1c:      	b.ne	0x9a60 <_stogir.checked.operands+0x198>
    9c20:      	mov	x1, x20
    9c24:      	mov	x2, x21
    9c28:      	b	0x9a68 <_stogir.checked.operands+0x1a0>
    9c2c:      	movz	x4, #0x0, lsl #48
    9c30:      	b	0x993c <_stogir.checked.operands+0x74>
    9c34:      	brk	#0
    9c38:      	b	0x9c34 <_stogir.checked.operands+0x36c>
    9c3c:      	brk	#0
    9c40:      	b	0x9c3c <_stogir.checked.operands+0x374>
    9c44:      	mov	x22, x8
    9c48:      	b	0x9bd8 <_stogir.checked.operands+0x310>

0000000000009c4c <_stogir.opcode.control?>:
    9c4c:      	sxtw	x0, w0
    9c50:      	cmp	x0, #0x0
    9c54:      	b.lt	0x9c7c <_stogir.opcode.control?+0x30>
    9c58:      	cmp	x0, #0x83
    9c5c:      	b.ge	0x9c7c <_stogir.opcode.control?+0x30>
    9c60:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009c60:  ARM64_RELOC_PAGE21	l_stogir.430
    9c64:      	ldr	x16, [x16]
		0000000000009c64:  ARM64_RELOC_PAGEOFF12	l_stogir.430
    9c68:      	orr	x1, x16, xzr
    9c6c:      	lsr	x0, x0, #0
    9c70:      	add	x0, x0, x1
    9c74:      	ldrb	w0, [x0]
    9c78:      	b	0x9c80 <_stogir.opcode.control?+0x34>
    9c7c:      	movz	x0, #0x0, lsl #48
    9c80:      	uxtb	w0, w0
    9c84:      	and	x0, x0, #0x1
    9c88:      	uxtb	w0, w0
    9c8c:      	ret

0000000000009c90 <_stogir.opcode.block-end?>:
    9c90:      	sxtw	x0, w0
    9c94:      	cmp	x0, #0x0
    9c98:      	b.lt	0x9cc0 <_stogir.opcode.block-end?+0x30>
    9c9c:      	cmp	x0, #0x83
    9ca0:      	b.ge	0x9cc0 <_stogir.opcode.block-end?+0x30>
    9ca4:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009ca4:  ARM64_RELOC_PAGE21	l_stogir.431
    9ca8:      	ldr	x16, [x16]
		0000000000009ca8:  ARM64_RELOC_PAGEOFF12	l_stogir.431
    9cac:      	orr	x1, x16, xzr
    9cb0:      	lsr	x0, x0, #0
    9cb4:      	add	x0, x0, x1
    9cb8:      	ldrb	w0, [x0]
    9cbc:      	b	0x9cc4 <_stogir.opcode.block-end?+0x34>
    9cc0:      	movz	x0, #0x0, lsl #48
    9cc4:      	uxtb	w0, w0
    9cc8:      	and	x0, x0, #0x4
    9ccc:      	uxtb	w0, w0
    9cd0:      	cmp	x0, #0x0
    9cd4:      	cset	w0, eq
    9cd8:      	uxtb	w16, w0
    9cdc:      	cmp	w16, wzr
    9ce0:      	cset	x0, eq
    9ce4:      	ret

0000000000009ce8 <_stogir.atomic.ordinary?>:
    9ce8:      	sxtw	x1, w1
    9cec:      	cmp	x1, #0x0
    9cf0:      	cset	w3, gt
    9cf4:      	movz	x16, #0x0, lsl #48
    9cf8:      	sub	x4, x16, x1
    9cfc:      	sub	x5, x4, #0x1
    9d00:      	uxtb	w16, w3
    9d04:      	cmp	w16, wzr
    9d08:      	b.eq	0x9d4c <_stogir.atomic.ordinary?+0x64>
    9d0c:      	ldr	x4, [x0, #0x8]
    9d10:      	cmp	x1, x4
    9d14:      	b.ge	0x9da0 <_stogir.atomic.ordinary?+0xb8>
    9d18:      	add	x4, x0, #0x78
    9d1c:      	ldr	x4, [x4, #0x8]
    9d20:      	cmp	x1, x4
    9d24:      	b.ge	0x9e60 <_stogir.atomic.ordinary?+0x178>
    9d28:      	lsl	x4, x1, #2
    9d2c:      	ldr	x6, [x0, #0x78]
    9d30:      	add	x4, x4, x6
    9d34:      	ldr	w4, [x4]
    9d38:      	sxtw	x4, w4
    9d3c:      	cmp	x4, #0x0
    9d40:      	cset	w4, ge
    9d44:      	ubfx	x4, x4, #0, #8
    9d48:      	b	0x9e64 <_stogir.atomic.ordinary?+0x17c>
    9d4c:      	cmp	x1, #0x0
    9d50:      	b.ge	0x9da8 <_stogir.atomic.ordinary?+0xc0>
    9d54:      	add	x6, x0, #0x28
    9d58:      	add	x7, x0, #0x50
    9d5c:      	ldr	x6, [x6, #0x8]
    9d60:      	ldr	x7, [x7, #0x8]
    9d64:      	cmp	x6, x7
    9d68:      	b.ne	0x9d98 <_stogir.atomic.ordinary?+0xb0>
    9d6c:      	cmp	x4, x6
    9d70:      	b.gt	0x9e80 <_stogir.atomic.ordinary?+0x198>
    9d74:      	lsl	x4, x5, #2
    9d78:      	ldr	x6, [x0, #0x50]
    9d7c:      	add	x4, x4, x6
    9d80:      	ldr	w4, [x4]
    9d84:      	sxtw	x4, w4
    9d88:      	cmp	x4, #0x0
    9d8c:      	cset	w4, gt
    9d90:      	ubfx	x4, x4, #0, #8
    9d94:      	b	0x9e84 <_stogir.atomic.ordinary?+0x19c>
    9d98:      	movz	x4, #0x0, lsl #48
    9d9c:      	b	0x9dac <_stogir.atomic.ordinary?+0xc4>
    9da0:      	movz	x4, #0x0, lsl #48
    9da4:      	b	0x9dac <_stogir.atomic.ordinary?+0xc4>
    9da8:      	movz	x4, #0x0, lsl #48
    9dac:      	cmp	x4, #0x0
    9db0:      	b.eq	0x9df0 <_stogir.atomic.ordinary?+0x108>
    9db4:      	uxtb	w16, w3
    9db8:      	cmp	w16, wzr
    9dbc:      	b.eq	0x9dd4 <_stogir.atomic.ordinary?+0xec>
    9dc0:      	lsl	x1, x1, #4
    9dc4:      	ldr	x0, [x0]
    9dc8:      	add	x0, x1, x0
    9dcc:      	ldr	x0, [x0]
    9dd0:      	b	0x9de4 <_stogir.atomic.ordinary?+0xfc>
    9dd4:      	lsl	x1, x5, #4
    9dd8:      	ldr	x0, [x0, #0x28]
    9ddc:      	add	x0, x1, x0
    9de0:      	ldr	x0, [x0]
    9de4:      	mov	x1, x0
    9de8:      	mov	x0, #0x1                ; =1
    9dec:      	b	0x9df8 <_stogir.atomic.ordinary?+0x110>
    9df0:      	movz	x0, #0x0, lsl #48
    9df4:      	movz	x1, #0x0, lsl #48
    9df8:      	lsr	w0, w0, #0
    9dfc:      	lsr	x16, x0, #0
    9e00:      	cmp	x16, #0x1
    9e04:      	b.eq	0x9e20 <_stogir.atomic.ordinary?+0x138>
    9e08:      	b.lo	0x9e10 <_stogir.atomic.ordinary?+0x128>
    9e0c:      	b	0x9e24 <_stogir.atomic.ordinary?+0x13c>
    9e10:      	cmp	x16, #0x0
    9e14:      	b.eq	0x9e1c <_stogir.atomic.ordinary?+0x134>
    9e18:      	b	0x9e24 <_stogir.atomic.ordinary?+0x13c>
    9e1c:      	b	0x9e28 <_stogir.atomic.ordinary?+0x140>
    9e20:      	b	0x9e38 <_stogir.atomic.ordinary?+0x150>
    9e24:      	b	0x9e88 <_stogir.atomic.ordinary?+0x1a0>
    9e28:      	movz	x0, #0x0, lsl #48
    9e2c:      	b	0x9e34 <_stogir.atomic.ordinary?+0x14c>
    9e30:      	movz	x0, #0x0, lsl #48
    9e34:      	ret
    9e38:      	sxtw	x2, w2
    9e3c:      	lsr	w0, w1, #0
    9e40:      	ubfx	x0, x0, #8, #8
    9e44:      	cmp	x0, x2
    9e48:      	b.ne	0x9e30 <_stogir.atomic.ordinary?+0x148>
    9e4c:      	uxtb	w1, w1
    9e50:      	cmp	x1, #0x46
    9e54:      	b.ne	0x9e68 <_stogir.atomic.ordinary?+0x180>
    9e58:      	movz	x0, #0x0, lsl #48
    9e5c:      	b	0x9e7c <_stogir.atomic.ordinary?+0x194>
    9e60:      	movz	x4, #0x0, lsl #48
    9e64:      	b	0x9da4 <_stogir.atomic.ordinary?+0xbc>
    9e68:      	cmp	x1, #0x48
    9e6c:      	cset	w0, eq
    9e70:      	uxtb	w16, w0
    9e74:      	cmp	w16, wzr
    9e78:      	cset	x0, eq
    9e7c:      	b	0x9e34 <_stogir.atomic.ordinary?+0x14c>
    9e80:      	movz	x4, #0x0, lsl #48
    9e84:      	b	0x9d9c <_stogir.atomic.ordinary?+0xb4>
    9e88:      	brk	#0
    9e8c:      	b	0x9e88 <_stogir.atomic.ordinary?+0x1a0>

0000000000009e90 <_stogir.types.scalar-size>:
    9e90:      	sxtw	x1, w1
    9e94:      	cmp	x1, #0x4
    9e98:      	b.eq	0x9eac <_stogir.types.scalar-size+0x1c>
    9e9c:      	cmp	x1, #0x8
    9ea0:      	b.eq	0x9eac <_stogir.types.scalar-size+0x1c>
    9ea4:      	movn	x0, #0x0, lsl #48
    9ea8:      	b	0x9ec4 <_stogir.types.scalar-size+0x34>
    9eac:      	sxtw	x0, w0
    9eb0:      	cmp	x0, #0x0
    9eb4:      	b.ne	0x9ec8 <_stogir.types.scalar-size+0x38>
    9eb8:      	movz	x0, #0x0, lsl #48
    9ebc:      	b	0x9ec4 <_stogir.types.scalar-size+0x34>
    9ec0:      	mov	x0, #0x1                ; =1
    9ec4:      	ret
    9ec8:      	cmp	x0, #0x1
    9ecc:      	b.eq	0x9ec0 <_stogir.types.scalar-size+0x30>
    9ed0:      	cmp	x0, #0x2
    9ed4:      	b.eq	0x9ec0 <_stogir.types.scalar-size+0x30>
    9ed8:      	cmp	x0, #0x7
    9edc:      	b.eq	0x9ec0 <_stogir.types.scalar-size+0x30>
    9ee0:      	cmp	x0, #0x8
    9ee4:      	b.eq	0x9ec0 <_stogir.types.scalar-size+0x30>
    9ee8:      	cmp	x0, #0x3
    9eec:      	b.eq	0x9f38 <_stogir.types.scalar-size+0xa8>
    9ef0:      	cmp	x0, #0x9
    9ef4:      	b.eq	0x9f38 <_stogir.types.scalar-size+0xa8>
    9ef8:      	cmp	x0, #0x4
    9efc:      	b.eq	0x9f40 <_stogir.types.scalar-size+0xb0>
    9f00:      	cmp	x0, #0xa
    9f04:      	b.eq	0x9f40 <_stogir.types.scalar-size+0xb0>
    9f08:      	cmp	x0, #0xd
    9f0c:      	b.eq	0x9f40 <_stogir.types.scalar-size+0xb0>
    9f10:      	cmp	x0, #0x5
    9f14:      	b.eq	0x9f48 <_stogir.types.scalar-size+0xb8>
    9f18:      	cmp	x0, #0xb
    9f1c:      	b.eq	0x9f48 <_stogir.types.scalar-size+0xb8>
    9f20:      	cmp	x0, #0xc
    9f24:      	b.eq	0x9f48 <_stogir.types.scalar-size+0xb8>
    9f28:      	cmp	x0, #0x6
    9f2c:      	b.ne	0x9f50 <_stogir.types.scalar-size+0xc0>
    9f30:      	mov	x0, x1
    9f34:      	b	0x9f54 <_stogir.types.scalar-size+0xc4>
    9f38:      	mov	x0, #0x2                ; =2
    9f3c:      	b	0x9ec4 <_stogir.types.scalar-size+0x34>
    9f40:      	mov	x0, #0x4                ; =4
    9f44:      	b	0x9f3c <_stogir.types.scalar-size+0xac>
    9f48:      	mov	x0, #0x8                ; =8
    9f4c:      	b	0x9f44 <_stogir.types.scalar-size+0xb4>
    9f50:      	movn	x0, #0x0, lsl #48
    9f54:      	b	0x9f4c <_stogir.types.scalar-size+0xbc>

0000000000009f58 <_stogir.terminal.inputs>:
    9f58:      	sxtw	x1, w1
    9f5c:      	cmp	x1, #0x60
    9f60:      	cset	w4, eq
    9f64:      	uxtb	w16, w4
    9f68:      	cmp	w16, wzr
    9f6c:      	b.ne	0x9fa0 <_stogir.terminal.inputs+0x48>
    9f70:      	cmp	x1, #0x79
    9f74:      	b.eq	0x9fa0 <_stogir.terminal.inputs+0x48>
    9f78:      	adrp	x16, 0x9000 <_stogir.vector.memory-inputs+0x430>
		0000000000009f78:  ARM64_RELOC_PAGE21	l_stogir.432
    9f7c:      	ldr	x16, [x16]
		0000000000009f7c:  ARM64_RELOC_PAGEOFF12	l_stogir.432
    9f80:      	orr	x0, x16, xzr
    9f84:      	mov	x1, x0
    9f88:      	mov	x0, #0x1                ; =1
    9f8c:      	mov	x2, #0x25               ; =37
    9f90:      	str	x0, [x8]
    9f94:      	str	x1, [x8, #0x8]
    9f98:      	str	x2, [x8, #0x10]
    9f9c:      	ret
    9fa0:      	sxtw	x3, w3
    9fa4:      	uxtb	w16, w4
    9fa8:      	cmp	w16, wzr
    9fac:      	b.eq	0x9fb8 <_stogir.terminal.inputs+0x60>
    9fb0:      	cmp	x3, #0x0
    9fb4:      	b.ne	0x9f78 <_stogir.terminal.inputs+0x20>
    9fb8:      	sxtw	x2, w2
    9fbc:      	cmp	x2, #0x0
    9fc0:      	cset	w1, gt
    9fc4:      	movz	x16, #0x0, lsl #48
    9fc8:      	sub	x4, x16, x2
    9fcc:      	sub	x5, x4, #0x1
    9fd0:      	uxtb	w16, w1
    9fd4:      	cmp	w16, wzr
    9fd8:      	b.eq	0xa0c0 <_stogir.terminal.inputs+0x168>
    9fdc:      	ldr	x4, [x0, #0x8]
    9fe0:      	cmp	x2, x4
    9fe4:      	b.ge	0xa0b8 <_stogir.terminal.inputs+0x160>
    9fe8:      	add	x4, x0, #0x78
    9fec:      	ldr	x4, [x4, #0x8]
    9ff0:      	cmp	x2, x4
    9ff4:      	b.ge	0xa168 <_stogir.terminal.inputs+0x210>
    9ff8:      	lsl	x4, x2, #2
    9ffc:      	ldr	x6, [x0, #0x78]
    a000:      	add	x4, x4, x6
    a004:      	ldr	w4, [x4]
    a008:      	sxtw	x4, w4
    a00c:      	cmp	x4, #0x0
    a010:      	cset	w4, ge
    a014:      	ubfx	x4, x4, #0, #8
    a018:      	b	0xa16c <_stogir.terminal.inputs+0x214>
    a01c:      	movz	x1, #0x0, lsl #48
    a020:      	movz	x4, #0x0, lsl #48
    a024:      	lsr	w1, w1, #0
    a028:      	lsr	x16, x1, #0
    a02c:      	cmp	x16, #0x1
    a030:      	b.eq	0xa04c <_stogir.terminal.inputs+0xf4>
    a034:      	b.lo	0xa03c <_stogir.terminal.inputs+0xe4>
    a038:      	b	0xa050 <_stogir.terminal.inputs+0xf8>
    a03c:      	cmp	x16, #0x0
    a040:      	b.eq	0xa048 <_stogir.terminal.inputs+0xf0>
    a044:      	b	0xa050 <_stogir.terminal.inputs+0xf8>
    a048:      	b	0xa054 <_stogir.terminal.inputs+0xfc>
    a04c:      	b	0xa10c <_stogir.terminal.inputs+0x1b4>
    a050:      	b	0xa2c0 <_stogir.terminal.inputs+0x368>
    a054:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a054:  ARM64_RELOC_PAGE21	l_stogir.433
    a058:      	ldr	x16, [x16]
		000000000000a058:  ARM64_RELOC_PAGEOFF12	l_stogir.433
    a05c:      	orr	x0, x16, xzr
    a060:      	mov	x1, x0
    a064:      	mov	x0, #0x1                ; =1
    a068:      	mov	x2, #0x1d               ; =29
    a06c:      	b	0x9f90 <_stogir.terminal.inputs+0x38>
    a070:      	lsl	x1, x5, #4
    a074:      	ldr	x4, [x0, #0x28]
    a078:      	add	x1, x1, x4
    a07c:      	ldr	x1, [x1]
    a080:      	mov	x4, x1
    a084:      	mov	x1, #0x1                ; =1
    a088:      	b	0xa024 <_stogir.terminal.inputs+0xcc>
    a08c:      	movz	x4, #0x0, lsl #48
    a090:      	cmp	x4, #0x0
    a094:      	b.eq	0xa01c <_stogir.terminal.inputs+0xc4>
    a098:      	uxtb	w16, w1
    a09c:      	cmp	w16, wzr
    a0a0:      	b.eq	0xa070 <_stogir.terminal.inputs+0x118>
    a0a4:      	lsl	x1, x2, #4
    a0a8:      	ldr	x4, [x0]
    a0ac:      	add	x1, x1, x4
    a0b0:      	ldr	x1, [x1]
    a0b4:      	b	0xa080 <_stogir.terminal.inputs+0x128>
    a0b8:      	movz	x4, #0x0, lsl #48
    a0bc:      	b	0xa090 <_stogir.terminal.inputs+0x138>
    a0c0:      	cmp	x2, #0x0
    a0c4:      	b.ge	0xa08c <_stogir.terminal.inputs+0x134>
    a0c8:      	add	x6, x0, #0x28
    a0cc:      	add	x7, x0, #0x50
    a0d0:      	ldr	x6, [x6, #0x8]
    a0d4:      	ldr	x7, [x7, #0x8]
    a0d8:      	cmp	x6, x7
    a0dc:      	b.ne	0xa160 <_stogir.terminal.inputs+0x208>
    a0e0:      	cmp	x4, x6
    a0e4:      	b.gt	0xa170 <_stogir.terminal.inputs+0x218>
    a0e8:      	lsl	x4, x5, #2
    a0ec:      	ldr	x6, [x0, #0x50]
    a0f0:      	add	x4, x4, x6
    a0f4:      	ldr	w4, [x4]
    a0f8:      	sxtw	x4, w4
    a0fc:      	cmp	x4, #0x0
    a100:      	cset	w4, gt
    a104:      	ubfx	x4, x4, #0, #8
    a108:      	b	0xa174 <_stogir.terminal.inputs+0x21c>
    a10c:      	cmp	x2, #0x0
    a110:      	b.le	0xa144 <_stogir.terminal.inputs+0x1ec>
    a114:      	uxtb	w4, w4
    a118:      	cmp	x4, #0x83
    a11c:      	cset	w1, lt
    a120:      	uxtb	w16, w1
    a124:      	cmp	w16, wzr
    a128:      	b.eq	0xa178 <_stogir.terminal.inputs+0x220>
    a12c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a12c:  ARM64_RELOC_PAGE21	l_stogir.434
    a130:      	ldr	x16, [x16]
		000000000000a130:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a134:      	orr	x2, x16, xzr
    a138:      	add	x2, x4, x2
    a13c:      	ldrb	w2, [x2]
    a140:      	b	0xa17c <_stogir.terminal.inputs+0x224>
    a144:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a144:  ARM64_RELOC_PAGE21	l_stogir.435
    a148:      	ldr	x16, [x16]
		000000000000a148:  ARM64_RELOC_PAGEOFF12	l_stogir.435
    a14c:      	orr	x0, x16, xzr
    a150:      	mov	x1, x0
    a154:      	mov	x0, #0x1                ; =1
    a158:      	mov	x2, #0x2c               ; =44
    a15c:      	b	0xa06c <_stogir.terminal.inputs+0x114>
    a160:      	movz	x4, #0x0, lsl #48
    a164:      	b	0xa090 <_stogir.terminal.inputs+0x138>
    a168:      	movz	x4, #0x0, lsl #48
    a16c:      	b	0xa0bc <_stogir.terminal.inputs+0x164>
    a170:      	movz	x4, #0x0, lsl #48
    a174:      	b	0xa164 <_stogir.terminal.inputs+0x20c>
    a178:      	movz	x2, #0x0, lsl #48
    a17c:      	uxtb	w2, w2
    a180:      	and	x2, x2, #0x1
    a184:      	uxtb	w2, w2
    a188:      	cmp	x2, #0x0
    a18c:      	b.eq	0xa144 <_stogir.terminal.inputs+0x1ec>
    a190:      	uxtb	w16, w1
    a194:      	cmp	w16, wzr
    a198:      	b.eq	0xa1b4 <_stogir.terminal.inputs+0x25c>
    a19c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a19c:  ARM64_RELOC_PAGE21	l_stogir.434
    a1a0:      	ldr	x16, [x16]
		000000000000a1a0:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a1a4:      	orr	x1, x16, xzr
    a1a8:      	add	x1, x4, x1
    a1ac:      	ldrb	w1, [x1]
    a1b0:      	b	0xa1b8 <_stogir.terminal.inputs+0x260>
    a1b4:      	movz	x1, #0x0, lsl #48
    a1b8:      	uxtb	w1, w1
    a1bc:      	and	x1, x1, #0x4
    a1c0:      	uxtb	w1, w1
    a1c4:      	cmp	x1, #0x0
    a1c8:      	cset	w1, eq
    a1cc:      	uxtb	w16, w1
    a1d0:      	cmp	w16, wzr
    a1d4:      	cset	x1, eq
    a1d8:      	cmp	x1, #0x0
    a1dc:      	b.ne	0xa144 <_stogir.terminal.inputs+0x1ec>
    a1e0:      	cmp	x3, #0x0
    a1e4:      	b.ne	0xa1f8 <_stogir.terminal.inputs+0x2a0>
    a1e8:      	movz	x0, #0x0, lsl #48
    a1ec:      	movz	x1, #0x0, lsl #48
    a1f0:      	movz	x2, #0x0, lsl #48
    a1f4:      	b	0xa15c <_stogir.terminal.inputs+0x204>
    a1f8:      	cmp	x3, #0x0
    a1fc:      	cset	w1, gt
    a200:      	movz	x16, #0x0, lsl #48
    a204:      	sub	x2, x16, x3
    a208:      	sub	x4, x2, #0x1
    a20c:      	uxtb	w16, w1
    a210:      	cmp	w16, wzr
    a214:      	b.eq	0xa274 <_stogir.terminal.inputs+0x31c>
    a218:      	ldr	x2, [x0, #0x8]
    a21c:      	cmp	x3, x2
    a220:      	b.ge	0xa2c8 <_stogir.terminal.inputs+0x370>
    a224:      	add	x2, x0, #0x78
    a228:      	ldr	x2, [x2, #0x8]
    a22c:      	cmp	x3, x2
    a230:      	b.ge	0xa3a0 <_stogir.terminal.inputs+0x448>
    a234:      	lsl	x2, x3, #2
    a238:      	ldr	x5, [x0, #0x78]
    a23c:      	add	x2, x2, x5
    a240:      	ldr	w2, [x2]
    a244:      	sxtw	x2, w2
    a248:      	cmp	x2, #0x0
    a24c:      	cset	w2, ge
    a250:      	ubfx	x2, x2, #0, #8
    a254:      	b	0xa3a4 <_stogir.terminal.inputs+0x44c>
    a258:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a258:  ARM64_RELOC_PAGE21	l_stogir.436
    a25c:      	ldr	x16, [x16]
		000000000000a25c:  ARM64_RELOC_PAGEOFF12	l_stogir.436
    a260:      	orr	x0, x16, xzr
    a264:      	mov	x1, x0
    a268:      	mov	x0, #0x1                ; =1
    a26c:      	mov	x2, #0x2e               ; =46
    a270:      	b	0xa1f4 <_stogir.terminal.inputs+0x29c>
    a274:      	cmp	x3, #0x0
    a278:      	b.ge	0xa2d0 <_stogir.terminal.inputs+0x378>
    a27c:      	add	x5, x0, #0x28
    a280:      	add	x6, x0, #0x50
    a284:      	ldr	x5, [x5, #0x8]
    a288:      	ldr	x6, [x6, #0x8]
    a28c:      	cmp	x5, x6
    a290:      	b.ne	0xa398 <_stogir.terminal.inputs+0x440>
    a294:      	cmp	x2, x5
    a298:      	b.gt	0xa3a8 <_stogir.terminal.inputs+0x450>
    a29c:      	lsl	x2, x4, #2
    a2a0:      	ldr	x5, [x0, #0x50]
    a2a4:      	add	x2, x2, x5
    a2a8:      	ldr	w2, [x2]
    a2ac:      	sxtw	x2, w2
    a2b0:      	cmp	x2, #0x0
    a2b4:      	cset	w2, gt
    a2b8:      	ubfx	x2, x2, #0, #8
    a2bc:      	b	0xa3ac <_stogir.terminal.inputs+0x454>
    a2c0:      	brk	#0
    a2c4:      	b	0xa2c0 <_stogir.terminal.inputs+0x368>
    a2c8:      	movz	x2, #0x0, lsl #48
    a2cc:      	b	0xa2d4 <_stogir.terminal.inputs+0x37c>
    a2d0:      	movz	x2, #0x0, lsl #48
    a2d4:      	cmp	x2, #0x0
    a2d8:      	b.eq	0xa318 <_stogir.terminal.inputs+0x3c0>
    a2dc:      	uxtb	w16, w1
    a2e0:      	cmp	w16, wzr
    a2e4:      	b.eq	0xa2fc <_stogir.terminal.inputs+0x3a4>
    a2e8:      	lsl	x1, x3, #4
    a2ec:      	ldr	x0, [x0]
    a2f0:      	add	x0, x1, x0
    a2f4:      	ldr	x0, [x0]
    a2f8:      	b	0xa30c <_stogir.terminal.inputs+0x3b4>
    a2fc:      	lsl	x1, x4, #4
    a300:      	ldr	x0, [x0, #0x28]
    a304:      	add	x0, x1, x0
    a308:      	ldr	x0, [x0]
    a30c:      	mov	x1, x0
    a310:      	mov	x0, #0x1                ; =1
    a314:      	b	0xa320 <_stogir.terminal.inputs+0x3c8>
    a318:      	movz	x0, #0x0, lsl #48
    a31c:      	movz	x1, #0x0, lsl #48
    a320:      	lsr	w0, w0, #0
    a324:      	lsr	x16, x0, #0
    a328:      	cmp	x16, #0x1
    a32c:      	b.eq	0xa348 <_stogir.terminal.inputs+0x3f0>
    a330:      	b.lo	0xa338 <_stogir.terminal.inputs+0x3e0>
    a334:      	b	0xa34c <_stogir.terminal.inputs+0x3f4>
    a338:      	cmp	x16, #0x0
    a33c:      	b.eq	0xa344 <_stogir.terminal.inputs+0x3ec>
    a340:      	b	0xa34c <_stogir.terminal.inputs+0x3f4>
    a344:      	b	0xa350 <_stogir.terminal.inputs+0x3f8>
    a348:      	b	0xa36c <_stogir.terminal.inputs+0x414>
    a34c:      	b	0xa3f0 <_stogir.terminal.inputs+0x498>
    a350:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a350:  ARM64_RELOC_PAGE21	l_stogir.437
    a354:      	ldr	x16, [x16]
		000000000000a354:  ARM64_RELOC_PAGEOFF12	l_stogir.437
    a358:      	orr	x0, x16, xzr
    a35c:      	mov	x1, x0
    a360:      	mov	x0, #0x1                ; =1
    a364:      	mov	x2, #0x1d               ; =29
    a368:      	b	0xa270 <_stogir.terminal.inputs+0x318>
    a36c:      	cmp	x3, #0x0
    a370:      	b.le	0xa258 <_stogir.terminal.inputs+0x300>
    a374:      	uxtb	w1, w1
    a378:      	cmp	x1, #0x83
    a37c:      	b.ge	0xa3b0 <_stogir.terminal.inputs+0x458>
    a380:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a380:  ARM64_RELOC_PAGE21	l_stogir.434
    a384:      	ldr	x16, [x16]
		000000000000a384:  ARM64_RELOC_PAGEOFF12	l_stogir.434
    a388:      	orr	x0, x16, xzr
    a38c:      	add	x0, x1, x0
    a390:      	ldrb	w0, [x0]
    a394:      	b	0xa3b4 <_stogir.terminal.inputs+0x45c>
    a398:      	movz	x2, #0x0, lsl #48
    a39c:      	b	0xa2d4 <_stogir.terminal.inputs+0x37c>
    a3a0:      	movz	x2, #0x0, lsl #48
    a3a4:      	b	0xa2cc <_stogir.terminal.inputs+0x374>
    a3a8:      	movz	x2, #0x0, lsl #48
    a3ac:      	b	0xa39c <_stogir.terminal.inputs+0x444>
    a3b0:      	movz	x0, #0x0, lsl #48
    a3b4:      	uxtb	w0, w0
    a3b8:      	and	x0, x0, #0x8
    a3bc:      	uxtb	w0, w0
    a3c0:      	cmp	x0, #0x0
    a3c4:      	cset	w0, eq
    a3c8:      	uxtb	w16, w0
    a3cc:      	cmp	w16, wzr
    a3d0:      	cset	x0, eq
    a3d4:      	cmp	x0, #0x0
    a3d8:      	b.eq	0xa258 <_stogir.terminal.inputs+0x300>
    a3dc:      	and	x0, x3, #0xffffffff
    a3e0:      	mov	x1, x0
    a3e4:      	movz	x0, #0x0, lsl #48
    a3e8:      	movz	x2, #0x0, lsl #48
    a3ec:      	b	0xa270 <_stogir.terminal.inputs+0x318>
    a3f0:      	brk	#0
    a3f4:      	b	0xa3f0 <_stogir.terminal.inputs+0x498>

000000000000a3f8 <_stogir.switch.switch-inputs>:
    a3f8:      	sxtw	x1, w1
    a3fc:      	cmp	x1, #0x0
    a400:      	cset	w3, gt
    a404:      	movz	x16, #0x0, lsl #48
    a408:      	sub	x4, x16, x1
    a40c:      	sub	x5, x4, #0x1
    a410:      	uxtb	w16, w3
    a414:      	cmp	w16, wzr
    a418:      	b.eq	0xa45c <_stogir.switch.switch-inputs+0x64>
    a41c:      	ldr	x4, [x0, #0x8]
    a420:      	cmp	x1, x4
    a424:      	b.ge	0xa4cc <_stogir.switch.switch-inputs+0xd4>
    a428:      	add	x4, x0, #0x78
    a42c:      	ldr	x4, [x4, #0x8]
    a430:      	cmp	x1, x4
    a434:      	b.ge	0xa5b4 <_stogir.switch.switch-inputs+0x1bc>
    a438:      	lsl	x4, x1, #2
    a43c:      	ldr	x6, [x0, #0x78]
    a440:      	add	x4, x4, x6
    a444:      	ldr	w4, [x4]
    a448:      	sxtw	x4, w4
    a44c:      	cmp	x4, #0x0
    a450:      	cset	w4, ge
    a454:      	ubfx	x4, x4, #0, #8
    a458:      	b	0xa5b8 <_stogir.switch.switch-inputs+0x1c0>
    a45c:      	cmp	x1, #0x0
    a460:      	b.ge	0xa4d4 <_stogir.switch.switch-inputs+0xdc>
    a464:      	add	x6, x0, #0x28
    a468:      	add	x7, x0, #0x50
    a46c:      	ldr	x6, [x6, #0x8]
    a470:      	ldr	x7, [x7, #0x8]
    a474:      	cmp	x6, x7
    a478:      	b.ne	0xa4a8 <_stogir.switch.switch-inputs+0xb0>
    a47c:      	cmp	x4, x6
    a480:      	b.gt	0xa5bc <_stogir.switch.switch-inputs+0x1c4>
    a484:      	lsl	x4, x5, #2
    a488:      	ldr	x6, [x0, #0x50]
    a48c:      	add	x4, x4, x6
    a490:      	ldr	w4, [x4]
    a494:      	sxtw	x4, w4
    a498:      	cmp	x4, #0x0
    a49c:      	cset	w4, gt
    a4a0:      	ubfx	x4, x4, #0, #8
    a4a4:      	b	0xa5c0 <_stogir.switch.switch-inputs+0x1c8>
    a4a8:      	movz	x4, #0x0, lsl #48
    a4ac:      	b	0xa4d8 <_stogir.switch.switch-inputs+0xe0>
    a4b0:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a4b0:  ARM64_RELOC_PAGE21	l_stogir.438
    a4b4:      	ldr	x16, [x16]
		000000000000a4b4:  ARM64_RELOC_PAGEOFF12	l_stogir.438
    a4b8:      	orr	x0, x16, xzr
    a4bc:      	mov	x1, x0
    a4c0:      	mov	x0, #0x1                ; =1
    a4c4:      	mov	x2, #0x16               ; =22
    a4c8:      	b	0xa56c <_stogir.switch.switch-inputs+0x174>
    a4cc:      	movz	x4, #0x0, lsl #48
    a4d0:      	b	0xa4d8 <_stogir.switch.switch-inputs+0xe0>
    a4d4:      	movz	x4, #0x0, lsl #48
    a4d8:      	cmp	x4, #0x0
    a4dc:      	b.eq	0xa51c <_stogir.switch.switch-inputs+0x124>
    a4e0:      	uxtb	w16, w3
    a4e4:      	cmp	w16, wzr
    a4e8:      	b.eq	0xa500 <_stogir.switch.switch-inputs+0x108>
    a4ec:      	lsl	x3, x1, #4
    a4f0:      	ldr	x4, [x0]
    a4f4:      	add	x3, x3, x4
    a4f8:      	ldr	x3, [x3]
    a4fc:      	b	0xa510 <_stogir.switch.switch-inputs+0x118>
    a500:      	lsl	x3, x5, #4
    a504:      	ldr	x4, [x0, #0x28]
    a508:      	add	x3, x3, x4
    a50c:      	ldr	x3, [x3]
    a510:      	mov	x4, x3
    a514:      	mov	x3, #0x1                ; =1
    a518:      	b	0xa524 <_stogir.switch.switch-inputs+0x12c>
    a51c:      	movz	x3, #0x0, lsl #48
    a520:      	movz	x4, #0x0, lsl #48
    a524:      	lsr	w3, w3, #0
    a528:      	lsr	x16, x3, #0
    a52c:      	cmp	x16, #0x1
    a530:      	b.eq	0xa54c <_stogir.switch.switch-inputs+0x154>
    a534:      	b.lo	0xa53c <_stogir.switch.switch-inputs+0x144>
    a538:      	b	0xa550 <_stogir.switch.switch-inputs+0x158>
    a53c:      	cmp	x16, #0x0
    a540:      	b.eq	0xa548 <_stogir.switch.switch-inputs+0x150>
    a544:      	b	0xa550 <_stogir.switch.switch-inputs+0x158>
    a548:      	b	0xa554 <_stogir.switch.switch-inputs+0x15c>
    a54c:      	b	0xa57c <_stogir.switch.switch-inputs+0x184>
    a550:      	b	0xa7e4 <_stogir.switch.switch-inputs+0x3ec>
    a554:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a554:  ARM64_RELOC_PAGE21	l_stogir.439
    a558:      	ldr	x16, [x16]
		000000000000a558:  ARM64_RELOC_PAGEOFF12	l_stogir.439
    a55c:      	orr	x0, x16, xzr
    a560:      	mov	x1, x0
    a564:      	mov	x0, #0x1                ; =1
    a568:      	mov	x2, #0x16               ; =22
    a56c:      	str	x0, [x8]
    a570:      	str	x1, [x8, #0x8]
    a574:      	str	x2, [x8, #0x10]
    a578:      	ret
    a57c:      	cmp	x1, #0x0
    a580:      	b.le	0xa4b0 <_stogir.switch.switch-inputs+0xb8>
    a584:      	uxtb	w4, w4
    a588:      	cmp	x4, #0x83
    a58c:      	cset	w1, lt
    a590:      	uxtb	w16, w1
    a594:      	cmp	w16, wzr
    a598:      	b.eq	0xa5c4 <_stogir.switch.switch-inputs+0x1cc>
    a59c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a59c:  ARM64_RELOC_PAGE21	l_stogir.440
    a5a0:      	ldr	x16, [x16]
		000000000000a5a0:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a5a4:      	orr	x3, x16, xzr
    a5a8:      	add	x3, x4, x3
    a5ac:      	ldrb	w3, [x3]
    a5b0:      	b	0xa5c8 <_stogir.switch.switch-inputs+0x1d0>
    a5b4:      	movz	x4, #0x0, lsl #48
    a5b8:      	b	0xa4d0 <_stogir.switch.switch-inputs+0xd8>
    a5bc:      	movz	x4, #0x0, lsl #48
    a5c0:      	b	0xa4ac <_stogir.switch.switch-inputs+0xb4>
    a5c4:      	movz	x3, #0x0, lsl #48
    a5c8:      	uxtb	w3, w3
    a5cc:      	and	x3, x3, #0x1
    a5d0:      	uxtb	w3, w3
    a5d4:      	cmp	x3, #0x0
    a5d8:      	b.eq	0xa4b0 <_stogir.switch.switch-inputs+0xb8>
    a5dc:      	uxtb	w16, w1
    a5e0:      	cmp	w16, wzr
    a5e4:      	b.eq	0xa600 <_stogir.switch.switch-inputs+0x208>
    a5e8:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a5e8:  ARM64_RELOC_PAGE21	l_stogir.440
    a5ec:      	ldr	x16, [x16]
		000000000000a5ec:  ARM64_RELOC_PAGEOFF12	l_stogir.440
    a5f0:      	orr	x1, x16, xzr
    a5f4:      	add	x1, x4, x1
    a5f8:      	ldrb	w1, [x1]
    a5fc:      	b	0xa604 <_stogir.switch.switch-inputs+0x20c>
    a600:      	movz	x1, #0x0, lsl #48
    a604:      	uxtb	w1, w1
    a608:      	and	x1, x1, #0x4
    a60c:      	uxtb	w1, w1
    a610:      	cmp	x1, #0x0
    a614:      	cset	w1, eq
    a618:      	uxtb	w16, w1
    a61c:      	cmp	w16, wzr
    a620:      	cset	x1, eq
    a624:      	cmp	x1, #0x0
    a628:      	b.ne	0xa4b0 <_stogir.switch.switch-inputs+0xb8>
    a62c:      	sxtw	x2, w2
    a630:      	cmp	x2, #0x0
    a634:      	cset	w1, gt
    a638:      	movz	x16, #0x0, lsl #48
    a63c:      	sub	x3, x16, x2
    a640:      	sub	x4, x3, #0x1
    a644:      	uxtb	w16, w1
    a648:      	cmp	w16, wzr
    a64c:      	b.eq	0xa6ac <_stogir.switch.switch-inputs+0x2b4>
    a650:      	ldr	x3, [x0, #0x8]
    a654:      	cmp	x2, x3
    a658:      	b.ge	0xa6f8 <_stogir.switch.switch-inputs+0x300>
    a65c:      	add	x3, x0, #0x78
    a660:      	ldr	x3, [x3, #0x8]
    a664:      	cmp	x2, x3
    a668:      	b.ge	0xa7dc <_stogir.switch.switch-inputs+0x3e4>
    a66c:      	lsl	x3, x2, #2
    a670:      	ldr	x5, [x0, #0x78]
    a674:      	add	x3, x3, x5
    a678:      	ldr	w3, [x3]
    a67c:      	sxtw	x3, w3
    a680:      	cmp	x3, #0x0
    a684:      	cset	w3, ge
    a688:      	ubfx	x3, x3, #0, #8
    a68c:      	b	0xa7e0 <_stogir.switch.switch-inputs+0x3e8>
    a690:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a690:  ARM64_RELOC_PAGE21	l_stogir.441
    a694:      	ldr	x16, [x16]
		000000000000a694:  ARM64_RELOC_PAGEOFF12	l_stogir.441
    a698:      	orr	x0, x16, xzr
    a69c:      	mov	x1, x0
    a6a0:      	mov	x0, #0x1                ; =1
    a6a4:      	mov	x2, #0x20               ; =32
    a6a8:      	b	0xa4c8 <_stogir.switch.switch-inputs+0xd0>
    a6ac:      	cmp	x2, #0x0
    a6b0:      	b.ge	0xa700 <_stogir.switch.switch-inputs+0x308>
    a6b4:      	add	x5, x0, #0x28
    a6b8:      	add	x6, x0, #0x50
    a6bc:      	ldr	x5, [x5, #0x8]
    a6c0:      	ldr	x6, [x6, #0x8]
    a6c4:      	cmp	x5, x6
    a6c8:      	b.ne	0xa7d4 <_stogir.switch.switch-inputs+0x3dc>
    a6cc:      	cmp	x3, x5
    a6d0:      	b.gt	0xa7ec <_stogir.switch.switch-inputs+0x3f4>
    a6d4:      	lsl	x3, x4, #2
    a6d8:      	ldr	x5, [x0, #0x50]
    a6dc:      	add	x3, x3, x5
    a6e0:      	ldr	w3, [x3]
    a6e4:      	sxtw	x3, w3
    a6e8:      	cmp	x3, #0x0
    a6ec:      	cset	w3, gt
    a6f0:      	ubfx	x3, x3, #0, #8
    a6f4:      	b	0xa7f0 <_stogir.switch.switch-inputs+0x3f8>
    a6f8:      	movz	x3, #0x0, lsl #48
    a6fc:      	b	0xa704 <_stogir.switch.switch-inputs+0x30c>
    a700:      	movz	x3, #0x0, lsl #48
    a704:      	cmp	x3, #0x0
    a708:      	b.eq	0xa748 <_stogir.switch.switch-inputs+0x350>
    a70c:      	uxtb	w16, w1
    a710:      	cmp	w16, wzr
    a714:      	b.eq	0xa72c <_stogir.switch.switch-inputs+0x334>
    a718:      	lsl	x1, x2, #4
    a71c:      	ldr	x0, [x0]
    a720:      	add	x0, x1, x0
    a724:      	ldr	x0, [x0]
    a728:      	b	0xa73c <_stogir.switch.switch-inputs+0x344>
    a72c:      	lsl	x1, x4, #4
    a730:      	ldr	x0, [x0, #0x28]
    a734:      	add	x0, x1, x0
    a738:      	ldr	x0, [x0]
    a73c:      	mov	x1, x0
    a740:      	mov	x0, #0x1                ; =1
    a744:      	b	0xa750 <_stogir.switch.switch-inputs+0x358>
    a748:      	movz	x0, #0x0, lsl #48
    a74c:      	movz	x1, #0x0, lsl #48
    a750:      	lsr	w0, w0, #0
    a754:      	lsr	x16, x0, #0
    a758:      	cmp	x16, #0x1
    a75c:      	b.eq	0xa778 <_stogir.switch.switch-inputs+0x380>
    a760:      	b.lo	0xa768 <_stogir.switch.switch-inputs+0x370>
    a764:      	b	0xa77c <_stogir.switch.switch-inputs+0x384>
    a768:      	cmp	x16, #0x0
    a76c:      	b.eq	0xa774 <_stogir.switch.switch-inputs+0x37c>
    a770:      	b	0xa77c <_stogir.switch.switch-inputs+0x384>
    a774:      	b	0xa780 <_stogir.switch.switch-inputs+0x388>
    a778:      	b	0xa79c <_stogir.switch.switch-inputs+0x3a4>
    a77c:      	b	0xa7f4 <_stogir.switch.switch-inputs+0x3fc>
    a780:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a780:  ARM64_RELOC_PAGE21	l_stogir.442
    a784:      	ldr	x16, [x16]
		000000000000a784:  ARM64_RELOC_PAGEOFF12	l_stogir.442
    a788:      	orr	x0, x16, xzr
    a78c:      	mov	x1, x0
    a790:      	mov	x0, #0x1                ; =1
    a794:      	mov	x2, #0x17               ; =23
    a798:      	b	0xa6a8 <_stogir.switch.switch-inputs+0x2b0>
    a79c:      	lsr	w0, w1, #0
    a7a0:      	ubfx	x0, x0, #8, #8
    a7a4:      	cmp	x0, #0x1
    a7a8:      	b.lt	0xa690 <_stogir.switch.switch-inputs+0x298>
    a7ac:      	cmp	x0, #0xb
    a7b0:      	b.gt	0xa690 <_stogir.switch.switch-inputs+0x298>
    a7b4:      	uxtb	w1, w1
    a7b8:      	cmp	x1, #0x48
    a7bc:      	b.eq	0xa690 <_stogir.switch.switch-inputs+0x298>
    a7c0:      	and	x0, x0, #0xffffffff
    a7c4:      	mov	x1, x0
    a7c8:      	movz	x0, #0x0, lsl #48
    a7cc:      	movz	x2, #0x0, lsl #48
    a7d0:      	b	0xa6a8 <_stogir.switch.switch-inputs+0x2b0>
    a7d4:      	movz	x3, #0x0, lsl #48
    a7d8:      	b	0xa704 <_stogir.switch.switch-inputs+0x30c>
    a7dc:      	movz	x3, #0x0, lsl #48
    a7e0:      	b	0xa6fc <_stogir.switch.switch-inputs+0x304>
    a7e4:      	brk	#0
    a7e8:      	b	0xa7e4 <_stogir.switch.switch-inputs+0x3ec>
    a7ec:      	movz	x3, #0x0, lsl #48
    a7f0:      	b	0xa7d8 <_stogir.switch.switch-inputs+0x3e0>
    a7f4:      	brk	#0
    a7f8:      	b	0xa7f4 <_stogir.switch.switch-inputs+0x3fc>

000000000000a7fc <_stogir.switch.case-inputs>:
    a7fc:      	sub	sp, sp, #0xc0
    a800:      	str	x29, [sp]
    a804:      	str	x30, [sp, #0x8]
    a808:      	mov	x29, sp
    a80c:      	str	x19, [sp, #0x80]
    a810:      	str	x20, [sp, #0x88]
    a814:      	str	x21, [sp, #0x90]
    a818:      	str	x22, [sp, #0x98]
    a81c:      	str	x23, [sp, #0xa0]
    a820:      	str	x24, [sp, #0xa8]
    a824:      	str	x25, [sp, #0xb0]
    a828:      	str	x26, [sp, #0xb8]
    a82c:      	sxtw	x2, w2
    a830:      	lsl	x5, x2, #2
    a834:      	cmp	x2, #0x0
    a838:      	cset	w6, gt
    a83c:      	movz	x16, #0x0, lsl #48
    a840:      	sub	x7, x16, x2
    a844:      	sub	x9, x7, #0x1
    a848:      	uxtb	w16, w6
    a84c:      	cmp	w16, wzr
    a850:      	b.eq	0xa890 <_stogir.switch.case-inputs+0x94>
    a854:      	ldr	x7, [x0, #0x8]
    a858:      	cmp	x2, x7
    a85c:      	b.ge	0xa8e4 <_stogir.switch.case-inputs+0xe8>
    a860:      	add	x7, x0, #0x78
    a864:      	ldr	x7, [x7, #0x8]
    a868:      	cmp	x2, x7
    a86c:      	b.ge	0xaa24 <_stogir.switch.case-inputs+0x228>
    a870:      	ldr	x7, [x0, #0x78]
    a874:      	add	x7, x5, x7
    a878:      	ldr	w7, [x7]
    a87c:      	sxtw	x7, w7
    a880:      	cmp	x7, #0x0
    a884:      	cset	w7, ge
    a888:      	ubfx	x7, x7, #0, #8
    a88c:      	b	0xaa28 <_stogir.switch.case-inputs+0x22c>
    a890:      	cmp	x2, #0x0
    a894:      	b.ge	0xa8ec <_stogir.switch.case-inputs+0xf0>
    a898:      	add	x10, x0, #0x28
    a89c:      	add	x11, x0, #0x50
    a8a0:      	ldr	x10, [x10, #0x8]
    a8a4:      	ldr	x11, [x11, #0x8]
    a8a8:      	cmp	x10, x11
    a8ac:      	b.ne	0xa8dc <_stogir.switch.case-inputs+0xe0>
    a8b0:      	cmp	x7, x10
    a8b4:      	b.gt	0xab00 <_stogir.switch.case-inputs+0x304>
    a8b8:      	lsl	x7, x9, #2
    a8bc:      	ldr	x10, [x0, #0x50]
    a8c0:      	add	x7, x7, x10
    a8c4:      	ldr	w7, [x7]
    a8c8:      	sxtw	x7, w7
    a8cc:      	cmp	x7, #0x0
    a8d0:      	cset	w7, gt
    a8d4:      	ubfx	x7, x7, #0, #8
    a8d8:      	b	0xab04 <_stogir.switch.case-inputs+0x308>
    a8dc:      	movz	x7, #0x0, lsl #48
    a8e0:      	b	0xa8f0 <_stogir.switch.case-inputs+0xf4>
    a8e4:      	movz	x7, #0x0, lsl #48
    a8e8:      	b	0xa8f0 <_stogir.switch.case-inputs+0xf4>
    a8ec:      	movz	x7, #0x0, lsl #48
    a8f0:      	cmp	x7, #0x0
    a8f4:      	b.eq	0xa958 <_stogir.switch.case-inputs+0x15c>
    a8f8:      	uxtb	w16, w6
    a8fc:      	cmp	w16, wzr
    a900:      	b.eq	0xa928 <_stogir.switch.case-inputs+0x12c>
    a904:      	lsl	x6, x2, #4
    a908:      	ldr	x7, [x0]
    a90c:      	add	x6, x6, x7
    a910:      	ldr	x7, [x6]
    a914:      	ldr	x6, [x6, #0x8]
    a918:      	fmov	d31, x6
    a91c:      	mov	x6, x7
    a920:      	fmov	x7, d31
    a924:      	b	0xa948 <_stogir.switch.case-inputs+0x14c>
    a928:      	lsl	x6, x9, #4
    a92c:      	ldr	x7, [x0, #0x28]
    a930:      	add	x6, x6, x7
    a934:      	ldr	x7, [x6]
    a938:      	ldr	x6, [x6, #0x8]
    a93c:      	fmov	d31, x6
    a940:      	mov	x6, x7
    a944:      	fmov	x7, d31
    a948:      	mov	x9, x7
    a94c:      	mov	x7, x6
    a950:      	mov	x6, #0x1                ; =1
    a954:      	b	0xa964 <_stogir.switch.case-inputs+0x168>
    a958:      	movz	x6, #0x0, lsl #48
    a95c:      	movz	x7, #0x0, lsl #48
    a960:      	movz	x9, #0x0, lsl #48
    a964:      	lsr	w6, w6, #0
    a968:      	lsr	x16, x6, #0
    a96c:      	cmp	x16, #0x1
    a970:      	b.eq	0xa98c <_stogir.switch.case-inputs+0x190>
    a974:      	b.lo	0xa97c <_stogir.switch.case-inputs+0x180>
    a978:      	b	0xa990 <_stogir.switch.case-inputs+0x194>
    a97c:      	cmp	x16, #0x0
    a980:      	b.eq	0xa988 <_stogir.switch.case-inputs+0x18c>
    a984:      	b	0xa990 <_stogir.switch.case-inputs+0x194>
    a988:      	b	0xa994 <_stogir.switch.case-inputs+0x198>
    a98c:      	b	0xa9ec <_stogir.switch.case-inputs+0x1f0>
    a990:      	b	0xab08 <_stogir.switch.case-inputs+0x30c>
    a994:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000a994:  ARM64_RELOC_PAGE21	l_stogir.443
    a998:      	ldr	x16, [x16]
		000000000000a998:  ARM64_RELOC_PAGEOFF12	l_stogir.443
    a99c:      	orr	x0, x16, xzr
    a9a0:      	mov	x21, x8
    a9a4:      	mov	x1, x0
    a9a8:      	mov	x0, #0x1                ; =1
    a9ac:      	mov	x2, #0x1a               ; =26
    a9b0:      	str	x0, [x21]
    a9b4:      	str	x1, [x21, #0x8]
    a9b8:      	str	x2, [x21, #0x10]
    a9bc:      	ldr	x19, [sp, #0x80]
    a9c0:      	ldr	x20, [sp, #0x88]
    a9c4:      	ldr	x21, [sp, #0x90]
    a9c8:      	ldr	x22, [sp, #0x98]
    a9cc:      	ldr	x23, [sp, #0xa0]
    a9d0:      	ldr	x24, [sp, #0xa8]
    a9d4:      	ldr	x25, [sp, #0xb0]
    a9d8:      	ldr	x26, [sp, #0xb8]
    a9dc:      	ldr	x29, [sp]
    a9e0:      	ldr	x30, [sp, #0x8]
    a9e4:      	add	sp, sp, #0xc0
    a9e8:      	ret
    a9ec:      	add	x16, sp, #0x10
    a9f0:      	str	x7, [x16]
    a9f4:      	add	x16, sp, #0x10
    a9f8:      	str	x9, [x16, #0x8]
    a9fc:      	cmp	x2, #0x0
    aa00:      	b.gt	0xaa2c <_stogir.switch.case-inputs+0x230>
    aa04:      	mov	x21, x8
    aa08:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000aa08:  ARM64_RELOC_PAGE21	l_stogir.444
    aa0c:      	ldr	x16, [x16]
		000000000000aa0c:  ARM64_RELOC_PAGEOFF12	l_stogir.444
    aa10:      	orr	x0, x16, xzr
    aa14:      	mov	x1, x0
    aa18:      	mov	x0, #0x1                ; =1
    aa1c:      	mov	x2, #0x1f               ; =31
    aa20:      	b	0xa9b0 <_stogir.switch.case-inputs+0x1b4>
    aa24:      	movz	x7, #0x0, lsl #48
    aa28:      	b	0xa8e8 <_stogir.switch.case-inputs+0xec>
    aa2c:      	add	x16, sp, #0x10
    aa30:      	ldr	w2, [x16]
    aa34:      	uxtb	w6, w2
    aa38:      	cmp	x6, #0x75
    aa3c:      	b.ne	0xac98 <_stogir.switch.case-inputs+0x49c>
    aa40:      	ubfx	x2, x2, #8, #8
    aa44:      	cmp	x2, #0x0
    aa48:      	b.ne	0xaca0 <_stogir.switch.case-inputs+0x4a4>
    aa4c:      	ldr	x2, [x0, #0x78]
    aa50:      	add	x2, x5, x2
    aa54:      	ldr	w2, [x2]
    aa58:      	sxtw	x2, w2
    aa5c:      	cmp	x2, #0x2
    aa60:      	b.ne	0xaca8 <_stogir.switch.case-inputs+0x4ac>
    aa64:      	sxtw	x19, w1
    aa68:      	cmp	x19, #0x6d
    aa6c:      	b.lt	0xacb0 <_stogir.switch.case-inputs+0x4b4>
    aa70:      	cmp	x19, #0x6f
    aa74:      	b.gt	0xacb8 <_stogir.switch.case-inputs+0x4bc>
    aa78:      	add	x16, sp, #0x20
    aa7c:      	orr	x20, x16, xzr
    aa80:      	add	x16, sp, #0x10
    aa84:      	ldr	w1, [x16, #0x4]
    aa88:      	add	x16, sp, #0x10
    aa8c:      	ldr	w2, [x16, #0x8]
    aa90:      	lsr	w1, w1, #0
    aa94:      	lsr	w2, w2, #0
    aa98:      	mov	x21, x8
    aa9c:      	add	x8, sp, #0x20
    aaa0:      	mov	x22, x0
    aaa4:      	mov	w23, w3
    aaa8:      	mov	w24, w4
    aaac:      	bl	0xaaac <_stogir.switch.case-inputs+0x2b0>
		000000000000aaac:  ARM64_RELOC_BRANCH26	_stogir.switch.switch-inputs
    aab0:      	add	x16, sp, #0x20
    aab4:      	ldr	w0, [x16]
    aab8:      	lsr	x16, x0, #0
    aabc:      	cmp	x16, #0x1
    aac0:      	b.eq	0xaadc <_stogir.switch.case-inputs+0x2e0>
    aac4:      	b.lo	0xaacc <_stogir.switch.case-inputs+0x2d0>
    aac8:      	b	0xaae0 <_stogir.switch.case-inputs+0x2e4>
    aacc:      	cmp	x16, #0x0
    aad0:      	b.eq	0xaad8 <_stogir.switch.case-inputs+0x2dc>
    aad4:      	b	0xaae0 <_stogir.switch.case-inputs+0x2e4>
    aad8:      	b	0xab10 <_stogir.switch.case-inputs+0x314>
    aadc:      	b	0xaae4 <_stogir.switch.case-inputs+0x2e8>
    aae0:      	b	0xac80 <_stogir.switch.case-inputs+0x484>
    aae4:      	add	x0, x20, #0x8
    aae8:      	add	x16, sp, #0x20
    aaec:      	ldr	x1, [x16, #0x8]
    aaf0:      	ldr	x0, [x0, #0x8]
    aaf4:      	mov	x2, x0
    aaf8:      	mov	x0, #0x1                ; =1
    aafc:      	b	0xaa20 <_stogir.switch.case-inputs+0x224>
    ab00:      	movz	x7, #0x0, lsl #48
    ab04:      	b	0xa8e0 <_stogir.switch.case-inputs+0xe4>
    ab08:      	brk	#0
    ab0c:      	b	0xab08 <_stogir.switch.case-inputs+0x30c>
    ab10:      	add	x16, sp, #0x20
    ab14:      	ldr	w20, [x16, #0x8]
    ab18:      	sxtw	x0, w20
    ab1c:      	and	x25, x0, #0xffffffff
    ab20:      	cmp	x19, #0x6f
    ab24:      	b.ne	0xab38 <_stogir.switch.case-inputs+0x33c>
    ab28:      	mov	x1, x25
    ab2c:      	movz	x0, #0x0, lsl #48
    ab30:      	movz	x2, #0x0, lsl #48
    ab34:      	b	0xaafc <_stogir.switch.case-inputs+0x300>
    ab38:      	add	x16, sp, #0x40
    ab3c:      	orr	x26, x16, xzr
    ab40:      	lsr	w23, w23, #0
    ab44:      	lsr	w20, w20, #0
    ab48:      	add	x8, sp, #0x40
    ab4c:      	mov	x0, x22
    ab50:      	mov	w1, w23
    ab54:      	mov	w2, w20
    ab58:      	bl	0xab58 <_stogir.switch.case-inputs+0x35c>
		000000000000ab58:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    ab5c:      	add	x16, sp, #0x40
    ab60:      	ldr	w0, [x16]
    ab64:      	lsr	x16, x0, #0
    ab68:      	cmp	x16, #0x1
    ab6c:      	b.eq	0xab88 <_stogir.switch.case-inputs+0x38c>
    ab70:      	b.lo	0xab78 <_stogir.switch.case-inputs+0x37c>
    ab74:      	b	0xab8c <_stogir.switch.case-inputs+0x390>
    ab78:      	cmp	x16, #0x0
    ab7c:      	b.eq	0xab84 <_stogir.switch.case-inputs+0x388>
    ab80:      	b	0xab8c <_stogir.switch.case-inputs+0x390>
    ab84:      	b	0xabac <_stogir.switch.case-inputs+0x3b0>
    ab88:      	b	0xab90 <_stogir.switch.case-inputs+0x394>
    ab8c:      	b	0xac88 <_stogir.switch.case-inputs+0x48c>
    ab90:      	add	x0, x26, #0x8
    ab94:      	add	x16, sp, #0x40
    ab98:      	ldr	x1, [x16, #0x8]
    ab9c:      	ldr	x0, [x0, #0x8]
    aba0:      	mov	x2, x0
    aba4:      	mov	x0, #0x1                ; =1
    aba8:      	b	0xab34 <_stogir.switch.case-inputs+0x338>
    abac:      	add	x16, sp, #0x40
    abb0:      	ldr	x26, [x16, #0x8]
    abb4:      	cmp	x19, #0x6d
    abb8:      	b.ne	0xabd8 <_stogir.switch.case-inputs+0x3dc>
    abbc:      	sxtw	x23, w23
    abc0:      	mov	x0, x23
    abc4:      	b	0xabe0 <_stogir.switch.case-inputs+0x3e4>
    abc8:      	mov	x1, x25
    abcc:      	movz	x0, #0x0, lsl #48
    abd0:      	movz	x2, #0x0, lsl #48
    abd4:      	b	0xaba8 <_stogir.switch.case-inputs+0x3ac>
    abd8:      	sxtw	x24, w24
    abdc:      	mov	x0, x24
    abe0:      	add	x16, sp, #0x60
    abe4:      	orr	x19, x16, xzr
    abe8:      	lsr	w20, w20, #0
    abec:      	lsr	w0, w0, #0
    abf0:      	add	x8, sp, #0x60
    abf4:      	mov	w1, w0
    abf8:      	mov	x0, x22
    abfc:      	mov	w2, w20
    ac00:      	bl	0xac00 <_stogir.switch.case-inputs+0x404>
		000000000000ac00:  ARM64_RELOC_BRANCH26	_stogir.switch.key
    ac04:      	add	x16, sp, #0x60
    ac08:      	ldr	w0, [x16]
    ac0c:      	lsr	x16, x0, #0
    ac10:      	cmp	x16, #0x1
    ac14:      	b.eq	0xac30 <_stogir.switch.case-inputs+0x434>
    ac18:      	b.lo	0xac20 <_stogir.switch.case-inputs+0x424>
    ac1c:      	b	0xac34 <_stogir.switch.case-inputs+0x438>
    ac20:      	cmp	x16, #0x0
    ac24:      	b.eq	0xac2c <_stogir.switch.case-inputs+0x430>
    ac28:      	b	0xac34 <_stogir.switch.case-inputs+0x438>
    ac2c:      	b	0xac54 <_stogir.switch.case-inputs+0x458>
    ac30:      	b	0xac38 <_stogir.switch.case-inputs+0x43c>
    ac34:      	b	0xac90 <_stogir.switch.case-inputs+0x494>
    ac38:      	add	x0, x19, #0x8
    ac3c:      	add	x16, sp, #0x60
    ac40:      	ldr	x1, [x16, #0x8]
    ac44:      	ldr	x0, [x0, #0x8]
    ac48:      	mov	x2, x0
    ac4c:      	mov	x0, #0x1                ; =1
    ac50:      	b	0xabd4 <_stogir.switch.case-inputs+0x3d8>
    ac54:      	add	x16, sp, #0x60
    ac58:      	ldr	x0, [x16, #0x8]
    ac5c:      	cmp	x26, x0
    ac60:      	b.ls	0xabc8 <_stogir.switch.case-inputs+0x3cc>
    ac64:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000ac64:  ARM64_RELOC_PAGE21	l_stogir.445
    ac68:      	ldr	x16, [x16]
		000000000000ac68:  ARM64_RELOC_PAGEOFF12	l_stogir.445
    ac6c:      	orr	x0, x16, xzr
    ac70:      	mov	x1, x0
    ac74:      	mov	x0, #0x1                ; =1
    ac78:      	mov	x2, #0x1a               ; =26
    ac7c:      	b	0xabd4 <_stogir.switch.case-inputs+0x3d8>
    ac80:      	brk	#0
    ac84:      	b	0xac80 <_stogir.switch.case-inputs+0x484>
    ac88:      	brk	#0
    ac8c:      	b	0xac88 <_stogir.switch.case-inputs+0x48c>
    ac90:      	brk	#0
    ac94:      	b	0xac90 <_stogir.switch.case-inputs+0x494>
    ac98:      	mov	x21, x8
    ac9c:      	b	0xaa08 <_stogir.switch.case-inputs+0x20c>
    aca0:      	mov	x21, x8
    aca4:      	b	0xaa08 <_stogir.switch.case-inputs+0x20c>
    aca8:      	mov	x21, x8
    acac:      	b	0xaa08 <_stogir.switch.case-inputs+0x20c>
    acb0:      	mov	x21, x8
    acb4:      	b	0xaa08 <_stogir.switch.case-inputs+0x20c>
    acb8:      	mov	x21, x8
    acbc:      	b	0xaa08 <_stogir.switch.case-inputs+0x20c>

000000000000acc0 <_stogir.stack.validate-frame-address>:
    acc0:      	sxtw	x1, w1
    acc4:      	lsl	x2, x1, #2
    acc8:      	cmp	x1, #0x0
    accc:      	cset	w3, gt
    acd0:      	movz	x16, #0x0, lsl #48
    acd4:      	sub	x4, x16, x1
    acd8:      	sub	x5, x4, #0x1
    acdc:      	uxtb	w16, w3
    ace0:      	cmp	w16, wzr
    ace4:      	b.eq	0xad24 <_stogir.stack.validate-frame-address+0x64>
    ace8:      	ldr	x4, [x0, #0x8]
    acec:      	cmp	x1, x4
    acf0:      	b.ge	0xad78 <_stogir.stack.validate-frame-address+0xb8>
    acf4:      	add	x4, x0, #0x78
    acf8:      	ldr	x4, [x4, #0x8]
    acfc:      	cmp	x1, x4
    ad00:      	b.ge	0xae90 <_stogir.stack.validate-frame-address+0x1d0>
    ad04:      	ldr	x4, [x0, #0x78]
    ad08:      	add	x4, x2, x4
    ad0c:      	ldr	w4, [x4]
    ad10:      	sxtw	x4, w4
    ad14:      	cmp	x4, #0x0
    ad18:      	cset	w4, ge
    ad1c:      	ubfx	x4, x4, #0, #8
    ad20:      	b	0xae94 <_stogir.stack.validate-frame-address+0x1d4>
    ad24:      	cmp	x1, #0x0
    ad28:      	b.ge	0xad80 <_stogir.stack.validate-frame-address+0xc0>
    ad2c:      	add	x6, x0, #0x28
    ad30:      	add	x7, x0, #0x50
    ad34:      	ldr	x6, [x6, #0x8]
    ad38:      	ldr	x7, [x7, #0x8]
    ad3c:      	cmp	x6, x7
    ad40:      	b.ne	0xad70 <_stogir.stack.validate-frame-address+0xb0>
    ad44:      	cmp	x4, x6
    ad48:      	b.gt	0xae98 <_stogir.stack.validate-frame-address+0x1d8>
    ad4c:      	lsl	x4, x5, #2
    ad50:      	ldr	x6, [x0, #0x50]
    ad54:      	add	x4, x4, x6
    ad58:      	ldr	w4, [x4]
    ad5c:      	sxtw	x4, w4
    ad60:      	cmp	x4, #0x0
    ad64:      	cset	w4, gt
    ad68:      	ubfx	x4, x4, #0, #8
    ad6c:      	b	0xae9c <_stogir.stack.validate-frame-address+0x1dc>
    ad70:      	movz	x4, #0x0, lsl #48
    ad74:      	b	0xad84 <_stogir.stack.validate-frame-address+0xc4>
    ad78:      	movz	x4, #0x0, lsl #48
    ad7c:      	b	0xad84 <_stogir.stack.validate-frame-address+0xc4>
    ad80:      	movz	x4, #0x0, lsl #48
    ad84:      	cmp	x4, #0x0
    ad88:      	b.eq	0xadc8 <_stogir.stack.validate-frame-address+0x108>
    ad8c:      	uxtb	w16, w3
    ad90:      	cmp	w16, wzr
    ad94:      	b.eq	0xadac <_stogir.stack.validate-frame-address+0xec>
    ad98:      	lsl	x3, x1, #4
    ad9c:      	ldr	x4, [x0]
    ada0:      	add	x3, x3, x4
    ada4:      	ldr	x3, [x3]
    ada8:      	b	0xadbc <_stogir.stack.validate-frame-address+0xfc>
    adac:      	lsl	x3, x5, #4
    adb0:      	ldr	x4, [x0, #0x28]
    adb4:      	add	x3, x3, x4
    adb8:      	ldr	x3, [x3]
    adbc:      	mov	x4, x3
    adc0:      	mov	x3, #0x1                ; =1
    adc4:      	b	0xadd0 <_stogir.stack.validate-frame-address+0x110>
    adc8:      	movz	x3, #0x0, lsl #48
    adcc:      	movz	x4, #0x0, lsl #48
    add0:      	lsr	w3, w3, #0
    add4:      	lsr	x16, x3, #0
    add8:      	cmp	x16, #0x1
    addc:      	b.eq	0xadf8 <_stogir.stack.validate-frame-address+0x138>
    ade0:      	b.lo	0xade8 <_stogir.stack.validate-frame-address+0x128>
    ade4:      	b	0xadfc <_stogir.stack.validate-frame-address+0x13c>
    ade8:      	cmp	x16, #0x0
    adec:      	b.eq	0xadf4 <_stogir.stack.validate-frame-address+0x134>
    adf0:      	b	0xadfc <_stogir.stack.validate-frame-address+0x13c>
    adf4:      	b	0xae00 <_stogir.stack.validate-frame-address+0x140>
    adf8:      	b	0xae44 <_stogir.stack.validate-frame-address+0x184>
    adfc:      	b	0xaea0 <_stogir.stack.validate-frame-address+0x1e0>
    ae00:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000ae00:  ARM64_RELOC_PAGE21	l_stogir.446
    ae04:      	ldr	x16, [x16]
		000000000000ae04:  ARM64_RELOC_PAGEOFF12	l_stogir.446
    ae08:      	orr	x0, x16, xzr
    ae0c:      	mov	x1, x0
    ae10:      	mov	x0, #0x1                ; =1
    ae14:      	mov	x2, #0x21               ; =33
    ae18:      	b	0xae34 <_stogir.stack.validate-frame-address+0x174>
    ae1c:      	adrp	x16, 0xa000 <_stogir.terminal.inputs+0xa8>
		000000000000ae1c:  ARM64_RELOC_PAGE21	l_stogir.447
    ae20:      	ldr	x16, [x16]
		000000000000ae20:  ARM64_RELOC_PAGEOFF12	l_stogir.447
    ae24:      	orr	x0, x16, xzr
    ae28:      	mov	x1, x0
    ae2c:      	mov	x0, #0x1                ; =1
    ae30:      	mov	x2, #0x1e               ; =30
    ae34:      	str	x0, [x8]
    ae38:      	str	x1, [x8, #0x8]
    ae3c:      	str	x2, [x8, #0x10]
    ae40:      	ret
    ae44:      	cmp	x1, #0x0
    ae48:      	b.le	0xae1c <_stogir.stack.validate-frame-address+0x15c>
    ae4c:      	uxtb	w1, w4
    ae50:      	cmp	x1, #0x42
    ae54:      	b.ne	0xae1c <_stogir.stack.validate-frame-address+0x15c>
    ae58:      	lsr	w4, w4, #0
    ae5c:      	ubfx	x1, x4, #8, #8
    ae60:      	cmp	x1, #0x6
    ae64:      	b.ne	0xae1c <_stogir.stack.validate-frame-address+0x15c>
    ae68:      	ldr	x0, [x0, #0x78]
    ae6c:      	add	x0, x2, x0
    ae70:      	ldr	w0, [x0]
    ae74:      	sxtw	x0, w0
    ae78:      	cmp	x0, #0x0
    ae7c:      	b.ne	0xae1c <_stogir.stack.validate-frame-address+0x15c>
    ae80:      	movz	x0, #0x0, lsl #48
    ae84:      	mov	x1, #0x8                ; =8
    ae88:      	movz	x2, #0x0, lsl #48
    ae8c:      	b	0xae34 <_stogir.stack.validate-frame-address+0x174>
    ae90:      	movz	x4, #0x0, lsl #48
    ae94:      	b	0xad7c <_stogir.stack.validate-frame-address+0xbc>
    ae98:      	movz	x4, #0x0, lsl #48
    ae9c:      	b	0xad74 <_stogir.stack.validate-frame-address+0xb4>
    aea0:      	brk	#0
    aea4:      	b	0xaea0 <_stogir.stack.validate-frame-address+0x1e0>

000000000000aea8 <_stogir.stack.frame-object?>:
    aea8:      	ldr	w0, [x0]
    aeac:      	uxtb	w1, w0
    aeb0:      	cmp	x1, #0x51
    aeb4:      	b.ne	0xaecc <_stogir.stack.frame-object?+0x24>
    aeb8:      	ubfx	x0, x0, #16, #16
    aebc:      	cmp	x0, #0x8, lsl #12       ; =0x8000
    aec0:      	cset	w0, eq
    aec4:      	ubfx	x0, x0, #0, #8
    aec8:      	b	0xaed0 <_stogir.stack.frame-object?+0x28>
    aecc:      	movz	x0, #0x0, lsl #48
    aed0:      	ret

000000000000aed4 <_stogir.stack.valid-frame-object-inputs?>:
    aed4:      	sub	sp, sp, #0x50
    aed8:      	str	x29, [sp]
    aedc:      	str	x30, [sp, #0x8]
    aee0:      	mov	x29, sp
    aee4:      	str	x19, [sp, #0x30]
    aee8:      	str	x20, [sp, #0x38]
    aeec:      	str	x21, [sp, #0x40]
    aef0:      	add	x3, x0, #0x78
    aef4:      	add	x4, x0, #0x28
    aef8:      	add	x5, x0, #0x50
    aefc:      	add	x6, x0, #0x78
    af00:      	add	x7, x0, #0x28
    af04:      	add	x8, x0, #0x50
    af08:      	sxtw	x1, w1
    af0c:      	mov	x9, sp
    af10:      	sub	sp, sp, #0x10
    af14:      	mov	x10, sp
    af18:      	mov	x12, x1
    af1c:      	mov	x1, #0x1                ; =1
    af20:      	movz	x11, #0x0, lsl #48
    af24:      	b	0xb074 <_stogir.stack.valid-frame-object-inputs?+0x1a0>
    af28:      	movz	x15, #0x0, lsl #48
    af2c:      	b	0xafa4 <_stogir.stack.valid-frame-object-inputs?+0xd0>
    af30:      	movz	x13, #0x0, lsl #48
    af34:      	movz	x14, #0x0, lsl #48
    af38:      	lsr	w13, w13, #0
    af3c:      	lsr	x16, x13, #0
    af40:      	cmp	x16, #0x1
    af44:      	b.eq	0xaf60 <_stogir.stack.valid-frame-object-inputs?+0x8c>
    af48:      	b.lo	0xaf50 <_stogir.stack.valid-frame-object-inputs?+0x7c>
    af4c:      	b	0xaf64 <_stogir.stack.valid-frame-object-inputs?+0x90>
    af50:      	cmp	x16, #0x0
    af54:      	b.eq	0xaf5c <_stogir.stack.valid-frame-object-inputs?+0x88>
    af58:      	b	0xaf64 <_stogir.stack.valid-frame-object-inputs?+0x90>
    af5c:      	b	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    af60:      	b	0xaf68 <_stogir.stack.valid-frame-object-inputs?+0x94>
    af64:      	b	0xb35c <_stogir.stack.valid-frame-object-inputs?+0x488>
    af68:      	uxtb	w13, w14
    af6c:      	lsr	w14, w14, #0
    af70:      	ubfx	x14, x14, #8, #8
    af74:      	cmp	x13, x14
    af78:      	b.eq	0xb348 <_stogir.stack.valid-frame-object-inputs?+0x474>
    af7c:      	cmp	x13, #0x49
    af80:      	b.eq	0xb348 <_stogir.stack.valid-frame-object-inputs?+0x474>
    af84:      	movz	x1, #0x0, lsl #48
    af88:      	fmov	d31, x11
    af8c:      	mov	x11, x12
    af90:      	fmov	x12, d31
    af94:      	b	0xb158 <_stogir.stack.valid-frame-object-inputs?+0x284>
    af98:      	movz	x15, #0x0, lsl #48
    af9c:      	b	0xafac <_stogir.stack.valid-frame-object-inputs?+0xd8>
    afa0:      	movz	x15, #0x0, lsl #48
    afa4:      	b	0xafb4 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    afa8:      	movz	x15, #0x0, lsl #48
    afac:      	b	0xafb4 <_stogir.stack.valid-frame-object-inputs?+0xe0>
    afb0:      	movz	x15, #0x0, lsl #48
    afb4:      	cmp	x15, #0x0
    afb8:      	b.eq	0xb01c <_stogir.stack.valid-frame-object-inputs?+0x148>
    afbc:      	uxtb	w16, w14
    afc0:      	cmp	w16, wzr
    afc4:      	b.eq	0xafec <_stogir.stack.valid-frame-object-inputs?+0x118>
    afc8:      	lsl	x13, x13, #4
    afcc:      	ldr	x14, [x0]
    afd0:      	add	x13, x13, x14
    afd4:      	ldr	x14, [x13]
    afd8:      	ldr	x13, [x13, #0x8]
    afdc:      	fmov	d31, x13
    afe0:      	mov	x13, x14
    afe4:      	fmov	x14, d31
    afe8:      	b	0xb00c <_stogir.stack.valid-frame-object-inputs?+0x138>
    afec:      	lsl	x13, x19, #4
    aff0:      	ldr	x14, [x0, #0x28]
    aff4:      	add	x13, x13, x14
    aff8:      	ldr	x14, [x13]
    affc:      	ldr	x13, [x13, #0x8]
    b000:      	fmov	d31, x13
    b004:      	mov	x13, x14
    b008:      	fmov	x14, d31
    b00c:      	mov	x15, x14
    b010:      	mov	x14, x13
    b014:      	mov	x13, #0x1               ; =1
    b018:      	b	0xb028 <_stogir.stack.valid-frame-object-inputs?+0x154>
    b01c:      	movz	x13, #0x0, lsl #48
    b020:      	movz	x14, #0x0, lsl #48
    b024:      	movz	x15, #0x0, lsl #48
    b028:      	lsr	w13, w13, #0
    b02c:      	lsr	x16, x13, #0
    b030:      	cmp	x16, #0x1
    b034:      	b.eq	0xb050 <_stogir.stack.valid-frame-object-inputs?+0x17c>
    b038:      	b.lo	0xb040 <_stogir.stack.valid-frame-object-inputs?+0x16c>
    b03c:      	b	0xb054 <_stogir.stack.valid-frame-object-inputs?+0x180>
    b040:      	cmp	x16, #0x0
    b044:      	b.eq	0xb04c <_stogir.stack.valid-frame-object-inputs?+0x178>
    b048:      	b	0xb054 <_stogir.stack.valid-frame-object-inputs?+0x180>
    b04c:      	b	0xb058 <_stogir.stack.valid-frame-object-inputs?+0x184>
    b050:      	b	0xb12c <_stogir.stack.valid-frame-object-inputs?+0x258>
    b054:      	b	0xb2a4 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    b058:      	fmov	d31, x11
    b05c:      	mov	x11, x12
    b060:      	fmov	x12, d31
    b064:      	movz	x1, #0x0, lsl #48
    b068:      	fmov	d31, x11
    b06c:      	mov	x11, x12
    b070:      	fmov	x12, d31
    b074:      	cmp	x1, #0x0
    b078:      	b.eq	0xb1e8 <_stogir.stack.valid-frame-object-inputs?+0x314>
    b07c:      	cmp	x11, #0x0
    b080:      	b.ne	0xb1e8 <_stogir.stack.valid-frame-object-inputs?+0x314>
    b084:      	lsr	w13, w12, #0
    b088:      	sxtw	x13, w13
    b08c:      	cmp	x13, #0x0
    b090:      	cset	w14, gt
    b094:      	movz	x16, #0x0, lsl #48
    b098:      	sub	x15, x16, x13
    b09c:      	sub	x19, x15, #0x1
    b0a0:      	uxtb	w16, w14
    b0a4:      	cmp	w16, wzr
    b0a8:      	b.eq	0xb0e8 <_stogir.stack.valid-frame-object-inputs?+0x214>
    b0ac:      	ldr	x15, [x0, #0x8]
    b0b0:      	cmp	x13, x15
    b0b4:      	b.ge	0xafa8 <_stogir.stack.valid-frame-object-inputs?+0xd4>
    b0b8:      	ldr	x15, [x3, #0x8]
    b0bc:      	cmp	x13, x15
    b0c0:      	b.ge	0xaf98 <_stogir.stack.valid-frame-object-inputs?+0xc4>
    b0c4:      	lsl	x15, x13, #2
    b0c8:      	ldr	x20, [x0, #0x78]
    b0cc:      	add	x15, x15, x20
    b0d0:      	ldr	w15, [x15]
    b0d4:      	sxtw	x15, w15
    b0d8:      	cmp	x15, #0x0
    b0dc:      	cset	w15, ge
    b0e0:      	ubfx	x15, x15, #0, #8
    b0e4:      	b	0xaf9c <_stogir.stack.valid-frame-object-inputs?+0xc8>
    b0e8:      	cmp	x13, #0x0
    b0ec:      	b.ge	0xafb0 <_stogir.stack.valid-frame-object-inputs?+0xdc>
    b0f0:      	ldr	x20, [x4, #0x8]
    b0f4:      	ldr	x21, [x5, #0x8]
    b0f8:      	cmp	x20, x21
    b0fc:      	b.ne	0xafa0 <_stogir.stack.valid-frame-object-inputs?+0xcc>
    b100:      	cmp	x15, x20
    b104:      	b.gt	0xaf28 <_stogir.stack.valid-frame-object-inputs?+0x54>
    b108:      	lsl	x15, x19, #2
    b10c:      	ldr	x20, [x0, #0x50]
    b110:      	add	x15, x15, x20
    b114:      	ldr	w15, [x15]
    b118:      	sxtw	x15, w15
    b11c:      	cmp	x15, #0x0
    b120:      	cset	w15, gt
    b124:      	ubfx	x15, x15, #0, #8
    b128:      	b	0xaf2c <_stogir.stack.valid-frame-object-inputs?+0x58>
    b12c:      	uxtb	w13, w14
    b130:      	asr	x19, x14, #32
    b134:      	str	x14, [x10]
    b138:      	str	x15, [x10, #0x8]
    b13c:      	cmp	x13, #0x68
    b140:      	b.ne	0xb15c <_stogir.stack.valid-frame-object-inputs?+0x288>
    b144:      	cmp	x19, #0x0
    b148:      	cset	w1, eq
    b14c:      	ubfx	x1, x1, #0, #8
    b150:      	mov	x11, x12
    b154:      	mov	x12, #0x1               ; =1
    b158:      	b	0xb068 <_stogir.stack.valid-frame-object-inputs?+0x194>
    b15c:      	cmp	x12, #0x0
    b160:      	b.le	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b164:      	cmp	x13, #0x51
    b168:      	b.ne	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b16c:      	cmp	x19, #0x0
    b170:      	b.le	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b174:      	cmp	x19, x12
    b178:      	b.ge	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b17c:      	lsr	w15, w15, #0
    b180:      	sxtw	x15, w15
    b184:      	cmp	x15, #0x0
    b188:      	b.ge	0xaf84 <_stogir.stack.valid-frame-object-inputs?+0xb0>
    b18c:      	cmp	x15, #0x0
    b190:      	cset	w13, gt
    b194:      	movz	x16, #0x0, lsl #48
    b198:      	sub	x14, x16, x15
    b19c:      	sub	x19, x14, #0x1
    b1a0:      	uxtb	w16, w13
    b1a4:      	cmp	w16, wzr
    b1a8:      	b.eq	0xb2fc <_stogir.stack.valid-frame-object-inputs?+0x428>
    b1ac:      	ldr	x14, [x0, #0x8]
    b1b0:      	cmp	x15, x14
    b1b4:      	b.ge	0xb2f4 <_stogir.stack.valid-frame-object-inputs?+0x420>
    b1b8:      	ldr	x14, [x6, #0x8]
    b1bc:      	cmp	x15, x14
    b1c0:      	b.ge	0xb340 <_stogir.stack.valid-frame-object-inputs?+0x46c>
    b1c4:      	lsl	x14, x15, #2
    b1c8:      	ldr	x20, [x0, #0x78]
    b1cc:      	add	x14, x14, x20
    b1d0:      	ldr	w14, [x14]
    b1d4:      	sxtw	x14, w14
    b1d8:      	cmp	x14, #0x0
    b1dc:      	cset	w14, ge
    b1e0:      	ubfx	x14, x14, #0, #8
    b1e4:      	b	0xb344 <_stogir.stack.valid-frame-object-inputs?+0x470>
    b1e8:      	cmp	x1, #0x0
    b1ec:      	b.eq	0xb1f8 <_stogir.stack.valid-frame-object-inputs?+0x324>
    b1f0:      	mov	x1, x11
    b1f4:      	b	0xb1fc <_stogir.stack.valid-frame-object-inputs?+0x328>
    b1f8:      	movz	x1, #0x0, lsl #48
    b1fc:      	mov	sp, x9
    b200:      	cmp	x1, #0x0
    b204:      	b.eq	0xb260 <_stogir.stack.valid-frame-object-inputs?+0x38c>
    b208:      	sxtw	x1, w2
    b20c:      	cmp	x1, #0x0
    b210:      	b.ge	0xb284 <_stogir.stack.valid-frame-object-inputs?+0x3b0>
    b214:      	lsr	w2, w2, #0
    b218:      	add	x8, x29, #0x10
    b21c:      	mov	w1, w2
    b220:      	bl	0xb220 <_stogir.stack.valid-frame-object-inputs?+0x34c>
		000000000000b220:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size
    b224:      	add	x16, x29, #0x10
    b228:      	ldr	w0, [x16]
    b22c:      	lsr	x16, x0, #0
    b230:      	cmp	x16, #0x1
    b234:      	b.eq	0xb250 <_stogir.stack.valid-frame-object-inputs?+0x37c>
    b238:      	b.lo	0xb240 <_stogir.stack.valid-frame-object-inputs?+0x36c>
    b23c:      	b	0xb254 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b240:      	cmp	x16, #0x0
    b244:      	b.eq	0xb24c <_stogir.stack.valid-frame-object-inputs?+0x378>
    b248:      	b	0xb254 <_stogir.stack.valid-frame-object-inputs?+0x380>
    b24c:      	b	0xb28c <_stogir.stack.valid-frame-object-inputs?+0x3b8>
    b250:      	b	0xb258 <_stogir.stack.valid-frame-object-inputs?+0x384>
    b254:      	b	0xb354 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b258:      	movz	x0, #0x0, lsl #48
    b25c:      	b	0xb2a0 <_stogir.stack.valid-frame-object-inputs?+0x3cc>
    b260:      	movz	x0, #0x0, lsl #48
    b264:      	sub	sp, x29, #0x0
    b268:      	ldr	x19, [sp, #0x30]
    b26c:      	ldr	x20, [sp, #0x38]
    b270:      	ldr	x21, [sp, #0x40]
    b274:      	ldr	x29, [sp]
    b278:      	ldr	x30, [sp, #0x8]
    b27c:      	add	sp, sp, #0x50
    b280:      	ret
    b284:      	movz	x0, #0x0, lsl #48
    b288:      	b	0xb264 <_stogir.stack.valid-frame-object-inputs?+0x390>
    b28c:      	add	x16, x29, #0x10
    b290:      	ldr	x0, [x16, #0x8]
    b294:      	cmp	x0, #0x0
    b298:      	cset	w0, gt
    b29c:      	ubfx	x0, x0, #0, #8
    b2a0:      	b	0xb288 <_stogir.stack.valid-frame-object-inputs?+0x3b4>
    b2a4:      	brk	#0
    b2a8:      	b	0xb2a4 <_stogir.stack.valid-frame-object-inputs?+0x3d0>
    b2ac:      	lsl	x13, x19, #4
    b2b0:      	ldr	x14, [x0, #0x28]
    b2b4:      	add	x13, x13, x14
    b2b8:      	ldr	x13, [x13]
    b2bc:      	mov	x14, x13
    b2c0:      	mov	x13, #0x1               ; =1
    b2c4:      	b	0xaf38 <_stogir.stack.valid-frame-object-inputs?+0x64>
    b2c8:      	movz	x14, #0x0, lsl #48
    b2cc:      	cmp	x14, #0x0
    b2d0:      	b.eq	0xaf30 <_stogir.stack.valid-frame-object-inputs?+0x5c>
    b2d4:      	uxtb	w16, w13
    b2d8:      	cmp	w16, wzr
    b2dc:      	b.eq	0xb2ac <_stogir.stack.valid-frame-object-inputs?+0x3d8>
    b2e0:      	lsl	x13, x15, #4
    b2e4:      	ldr	x14, [x0]
    b2e8:      	add	x13, x13, x14
    b2ec:      	ldr	x13, [x13]
    b2f0:      	b	0xb2bc <_stogir.stack.valid-frame-object-inputs?+0x3e8>
    b2f4:      	movz	x14, #0x0, lsl #48
    b2f8:      	b	0xb2cc <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b2fc:      	ldr	x20, [x7, #0x8]
    b300:      	ldr	x21, [x8, #0x8]
    b304:      	cmp	x20, x21
    b308:      	b.ne	0xb2c8 <_stogir.stack.valid-frame-object-inputs?+0x3f4>
    b30c:      	cmp	x14, x20
    b310:      	b.gt	0xb338 <_stogir.stack.valid-frame-object-inputs?+0x464>
    b314:      	lsl	x14, x19, #2
    b318:      	ldr	x20, [x0, #0x50]
    b31c:      	add	x14, x14, x20
    b320:      	ldr	w14, [x14]
    b324:      	sxtw	x14, w14
    b328:      	cmp	x14, #0x0
    b32c:      	cset	w14, gt
    b330:      	ubfx	x14, x14, #0, #8
    b334:      	b	0xb33c <_stogir.stack.valid-frame-object-inputs?+0x468>
    b338:      	movz	x14, #0x0, lsl #48
    b33c:      	b	0xb2cc <_stogir.stack.valid-frame-object-inputs?+0x3f8>
    b340:      	movz	x14, #0x0, lsl #48
    b344:      	b	0xb2f8 <_stogir.stack.valid-frame-object-inputs?+0x424>
    b348:      	ldr	w12, [x10, #0x4]
    b34c:      	sxtw	x12, w12
    b350:      	b	0xaf88 <_stogir.stack.valid-frame-object-inputs?+0xb4>
    b354:      	brk	#0
    b358:      	b	0xb354 <_stogir.stack.valid-frame-object-inputs?+0x480>
    b35c:      	brk	#0
    b360:      	b	0xb35c <_stogir.stack.valid-frame-object-inputs?+0x488>

000000000000b364 <_stogir.stack.validate-scope-inputs>:
    b364:      	sxtw	x1, w1
    b368:      	cmp	x1, #0x53
    b36c:      	cset	w5, eq
    b370:      	uxtb	w16, w5
    b374:      	cmp	w16, wzr
    b378:      	b.ne	0xb3ac <_stogir.stack.validate-scope-inputs+0x48>
    b37c:      	cmp	x1, #0x54
    b380:      	b.eq	0xb3ac <_stogir.stack.validate-scope-inputs+0x48>
    b384:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b384:  ARM64_RELOC_PAGE21	l_stogir.448
    b388:      	ldr	x16, [x16]
		000000000000b388:  ARM64_RELOC_PAGEOFF12	l_stogir.448
    b38c:      	orr	x0, x16, xzr
    b390:      	mov	x1, x0
    b394:      	mov	x0, #0x1                ; =1
    b398:      	mov	x2, #0x22               ; =34
    b39c:      	str	x0, [x8]
    b3a0:      	str	x1, [x8, #0x8]
    b3a4:      	str	x2, [x8, #0x10]
    b3a8:      	ret
    b3ac:      	uxtb	w16, w5
    b3b0:      	cmp	w16, wzr
    b3b4:      	mov	x16, #0x6               ; =6
    b3b8:      	movz	x17, #0x0, lsl #48
    b3bc:      	csel	x1, x16, x17, ne
    b3c0:      	sxtw	x2, w2
    b3c4:      	lsr	w1, w1, #0
    b3c8:      	sxtw	x1, w1
    b3cc:      	cmp	x2, x1
    b3d0:      	b.ne	0xb384 <_stogir.stack.validate-scope-inputs+0x20>
    b3d4:      	sxtw	x3, w3
    b3d8:      	cmp	x3, #0x0
    b3dc:      	cset	w1, gt
    b3e0:      	movz	x16, #0x0, lsl #48
    b3e4:      	sub	x2, x16, x3
    b3e8:      	sub	x6, x2, #0x1
    b3ec:      	uxtb	w16, w1
    b3f0:      	cmp	w16, wzr
    b3f4:      	b.eq	0xb4dc <_stogir.stack.validate-scope-inputs+0x178>
    b3f8:      	ldr	x2, [x0, #0x8]
    b3fc:      	cmp	x3, x2
    b400:      	b.ge	0xb4d4 <_stogir.stack.validate-scope-inputs+0x170>
    b404:      	add	x2, x0, #0x78
    b408:      	ldr	x2, [x2, #0x8]
    b40c:      	cmp	x3, x2
    b410:      	b.ge	0xb584 <_stogir.stack.validate-scope-inputs+0x220>
    b414:      	lsl	x2, x3, #2
    b418:      	ldr	x7, [x0, #0x78]
    b41c:      	add	x2, x2, x7
    b420:      	ldr	w2, [x2]
    b424:      	sxtw	x2, w2
    b428:      	cmp	x2, #0x0
    b42c:      	cset	w2, ge
    b430:      	ubfx	x2, x2, #0, #8
    b434:      	b	0xb588 <_stogir.stack.validate-scope-inputs+0x224>
    b438:      	movz	x1, #0x0, lsl #48
    b43c:      	movz	x2, #0x0, lsl #48
    b440:      	lsr	w1, w1, #0
    b444:      	lsr	x16, x1, #0
    b448:      	cmp	x16, #0x1
    b44c:      	b.eq	0xb468 <_stogir.stack.validate-scope-inputs+0x104>
    b450:      	b.lo	0xb458 <_stogir.stack.validate-scope-inputs+0xf4>
    b454:      	b	0xb46c <_stogir.stack.validate-scope-inputs+0x108>
    b458:      	cmp	x16, #0x0
    b45c:      	b.eq	0xb464 <_stogir.stack.validate-scope-inputs+0x100>
    b460:      	b	0xb46c <_stogir.stack.validate-scope-inputs+0x108>
    b464:      	b	0xb470 <_stogir.stack.validate-scope-inputs+0x10c>
    b468:      	b	0xb528 <_stogir.stack.validate-scope-inputs+0x1c4>
    b46c:      	b	0xb758 <_stogir.stack.validate-scope-inputs+0x3f4>
    b470:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b470:  ARM64_RELOC_PAGE21	l_stogir.449
    b474:      	ldr	x16, [x16]
		000000000000b474:  ARM64_RELOC_PAGEOFF12	l_stogir.449
    b478:      	orr	x0, x16, xzr
    b47c:      	mov	x1, x0
    b480:      	mov	x0, #0x1                ; =1
    b484:      	mov	x2, #0x1b               ; =27
    b488:      	b	0xb39c <_stogir.stack.validate-scope-inputs+0x38>
    b48c:      	lsl	x1, x6, #4
    b490:      	ldr	x2, [x0, #0x28]
    b494:      	add	x1, x1, x2
    b498:      	ldr	x1, [x1]
    b49c:      	mov	x2, x1
    b4a0:      	mov	x1, #0x1                ; =1
    b4a4:      	b	0xb440 <_stogir.stack.validate-scope-inputs+0xdc>
    b4a8:      	movz	x2, #0x0, lsl #48
    b4ac:      	cmp	x2, #0x0
    b4b0:      	b.eq	0xb438 <_stogir.stack.validate-scope-inputs+0xd4>
    b4b4:      	uxtb	w16, w1
    b4b8:      	cmp	w16, wzr
    b4bc:      	b.eq	0xb48c <_stogir.stack.validate-scope-inputs+0x128>
    b4c0:      	lsl	x1, x3, #4
    b4c4:      	ldr	x2, [x0]
    b4c8:      	add	x1, x1, x2
    b4cc:      	ldr	x1, [x1]
    b4d0:      	b	0xb49c <_stogir.stack.validate-scope-inputs+0x138>
    b4d4:      	movz	x2, #0x0, lsl #48
    b4d8:      	b	0xb4ac <_stogir.stack.validate-scope-inputs+0x148>
    b4dc:      	cmp	x3, #0x0
    b4e0:      	b.ge	0xb4a8 <_stogir.stack.validate-scope-inputs+0x144>
    b4e4:      	add	x7, x0, #0x28
    b4e8:      	add	x9, x0, #0x50
    b4ec:      	ldr	x7, [x7, #0x8]
    b4f0:      	ldr	x9, [x9, #0x8]
    b4f4:      	cmp	x7, x9
    b4f8:      	b.ne	0xb57c <_stogir.stack.validate-scope-inputs+0x218>
    b4fc:      	cmp	x2, x7
    b500:      	b.gt	0xb58c <_stogir.stack.validate-scope-inputs+0x228>
    b504:      	lsl	x2, x6, #2
    b508:      	ldr	x7, [x0, #0x50]
    b50c:      	add	x2, x2, x7
    b510:      	ldr	w2, [x2]
    b514:      	sxtw	x2, w2
    b518:      	cmp	x2, #0x0
    b51c:      	cset	w2, gt
    b520:      	ubfx	x2, x2, #0, #8
    b524:      	b	0xb590 <_stogir.stack.validate-scope-inputs+0x22c>
    b528:      	cmp	x3, #0x0
    b52c:      	b.le	0xb560 <_stogir.stack.validate-scope-inputs+0x1fc>
    b530:      	uxtb	w2, w2
    b534:      	cmp	x2, #0x83
    b538:      	cset	w1, lt
    b53c:      	uxtb	w16, w1
    b540:      	cmp	w16, wzr
    b544:      	b.eq	0xb594 <_stogir.stack.validate-scope-inputs+0x230>
    b548:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b548:  ARM64_RELOC_PAGE21	l_stogir.450
    b54c:      	ldr	x16, [x16]
		000000000000b54c:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b550:      	orr	x3, x16, xzr
    b554:      	add	x3, x2, x3
    b558:      	ldrb	w3, [x3]
    b55c:      	b	0xb598 <_stogir.stack.validate-scope-inputs+0x234>
    b560:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b560:  ARM64_RELOC_PAGE21	l_stogir.451
    b564:      	ldr	x16, [x16]
		000000000000b564:  ARM64_RELOC_PAGEOFF12	l_stogir.451
    b568:      	orr	x0, x16, xzr
    b56c:      	mov	x1, x0
    b570:      	mov	x0, #0x1                ; =1
    b574:      	mov	x2, #0x1b               ; =27
    b578:      	b	0xb488 <_stogir.stack.validate-scope-inputs+0x124>
    b57c:      	movz	x2, #0x0, lsl #48
    b580:      	b	0xb4ac <_stogir.stack.validate-scope-inputs+0x148>
    b584:      	movz	x2, #0x0, lsl #48
    b588:      	b	0xb4d8 <_stogir.stack.validate-scope-inputs+0x174>
    b58c:      	movz	x2, #0x0, lsl #48
    b590:      	b	0xb580 <_stogir.stack.validate-scope-inputs+0x21c>
    b594:      	movz	x3, #0x0, lsl #48
    b598:      	uxtb	w3, w3
    b59c:      	and	x3, x3, #0x1
    b5a0:      	uxtb	w3, w3
    b5a4:      	cmp	x3, #0x0
    b5a8:      	b.eq	0xb560 <_stogir.stack.validate-scope-inputs+0x1fc>
    b5ac:      	uxtb	w16, w1
    b5b0:      	cmp	w16, wzr
    b5b4:      	b.eq	0xb5d0 <_stogir.stack.validate-scope-inputs+0x26c>
    b5b8:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b5b8:  ARM64_RELOC_PAGE21	l_stogir.450
    b5bc:      	ldr	x16, [x16]
		000000000000b5bc:  ARM64_RELOC_PAGEOFF12	l_stogir.450
    b5c0:      	orr	x1, x16, xzr
    b5c4:      	add	x1, x2, x1
    b5c8:      	ldrb	w1, [x1]
    b5cc:      	b	0xb5d4 <_stogir.stack.validate-scope-inputs+0x270>
    b5d0:      	movz	x1, #0x0, lsl #48
    b5d4:      	uxtb	w1, w1
    b5d8:      	and	x1, x1, #0x4
    b5dc:      	uxtb	w1, w1
    b5e0:      	cmp	x1, #0x0
    b5e4:      	b.ne	0xb560 <_stogir.stack.validate-scope-inputs+0x1fc>
    b5e8:      	uxtb	w16, w5
    b5ec:      	cmp	w16, wzr
    b5f0:      	b.eq	0xb604 <_stogir.stack.validate-scope-inputs+0x2a0>
    b5f4:      	movz	x0, #0x0, lsl #48
    b5f8:      	mov	x1, #0x8                ; =8
    b5fc:      	movz	x2, #0x0, lsl #48
    b600:      	b	0xb578 <_stogir.stack.validate-scope-inputs+0x214>
    b604:      	sxtw	x4, w4
    b608:      	cmp	x4, #0x0
    b60c:      	cset	w1, gt
    b610:      	movz	x16, #0x0, lsl #48
    b614:      	sub	x2, x16, x4
    b618:      	sub	x3, x2, #0x1
    b61c:      	uxtb	w16, w1
    b620:      	cmp	w16, wzr
    b624:      	b.eq	0xb70c <_stogir.stack.validate-scope-inputs+0x3a8>
    b628:      	ldr	x2, [x0, #0x8]
    b62c:      	cmp	x4, x2
    b630:      	b.ge	0xb704 <_stogir.stack.validate-scope-inputs+0x3a0>
    b634:      	add	x2, x0, #0x78
    b638:      	ldr	x2, [x2, #0x8]
    b63c:      	cmp	x4, x2
    b640:      	b.ge	0xb7b0 <_stogir.stack.validate-scope-inputs+0x44c>
    b644:      	lsl	x2, x4, #2
    b648:      	ldr	x5, [x0, #0x78]
    b64c:      	add	x2, x2, x5
    b650:      	ldr	w2, [x2]
    b654:      	sxtw	x2, w2
    b658:      	cmp	x2, #0x0
    b65c:      	cset	w2, ge
    b660:      	ubfx	x2, x2, #0, #8
    b664:      	b	0xb7b4 <_stogir.stack.validate-scope-inputs+0x450>
    b668:      	movz	x0, #0x0, lsl #48
    b66c:      	movz	x1, #0x0, lsl #48
    b670:      	lsr	w0, w0, #0
    b674:      	lsr	x16, x0, #0
    b678:      	cmp	x16, #0x1
    b67c:      	b.eq	0xb698 <_stogir.stack.validate-scope-inputs+0x334>
    b680:      	b.lo	0xb688 <_stogir.stack.validate-scope-inputs+0x324>
    b684:      	b	0xb69c <_stogir.stack.validate-scope-inputs+0x338>
    b688:      	cmp	x16, #0x0
    b68c:      	b.eq	0xb694 <_stogir.stack.validate-scope-inputs+0x330>
    b690:      	b	0xb69c <_stogir.stack.validate-scope-inputs+0x338>
    b694:      	b	0xb6a0 <_stogir.stack.validate-scope-inputs+0x33c>
    b698:      	b	0xb760 <_stogir.stack.validate-scope-inputs+0x3fc>
    b69c:      	b	0xb7c0 <_stogir.stack.validate-scope-inputs+0x45c>
    b6a0:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b6a0:  ARM64_RELOC_PAGE21	l_stogir.452
    b6a4:      	ldr	x16, [x16]
		000000000000b6a4:  ARM64_RELOC_PAGEOFF12	l_stogir.452
    b6a8:      	orr	x0, x16, xzr
    b6ac:      	mov	x1, x0
    b6b0:      	mov	x0, #0x1                ; =1
    b6b4:      	mov	x2, #0x1b               ; =27
    b6b8:      	b	0xb600 <_stogir.stack.validate-scope-inputs+0x29c>
    b6bc:      	lsl	x1, x3, #4
    b6c0:      	ldr	x0, [x0, #0x28]
    b6c4:      	add	x0, x1, x0
    b6c8:      	ldr	x0, [x0]
    b6cc:      	mov	x1, x0
    b6d0:      	mov	x0, #0x1                ; =1
    b6d4:      	b	0xb670 <_stogir.stack.validate-scope-inputs+0x30c>
    b6d8:      	movz	x2, #0x0, lsl #48
    b6dc:      	cmp	x2, #0x0
    b6e0:      	b.eq	0xb668 <_stogir.stack.validate-scope-inputs+0x304>
    b6e4:      	uxtb	w16, w1
    b6e8:      	cmp	w16, wzr
    b6ec:      	b.eq	0xb6bc <_stogir.stack.validate-scope-inputs+0x358>
    b6f0:      	lsl	x1, x4, #4
    b6f4:      	ldr	x0, [x0]
    b6f8:      	add	x0, x1, x0
    b6fc:      	ldr	x0, [x0]
    b700:      	b	0xb6cc <_stogir.stack.validate-scope-inputs+0x368>
    b704:      	movz	x2, #0x0, lsl #48
    b708:      	b	0xb6dc <_stogir.stack.validate-scope-inputs+0x378>
    b70c:      	cmp	x4, #0x0
    b710:      	b.ge	0xb6d8 <_stogir.stack.validate-scope-inputs+0x374>
    b714:      	add	x5, x0, #0x28
    b718:      	add	x6, x0, #0x50
    b71c:      	ldr	x5, [x5, #0x8]
    b720:      	ldr	x6, [x6, #0x8]
    b724:      	cmp	x5, x6
    b728:      	b.ne	0xb7a8 <_stogir.stack.validate-scope-inputs+0x444>
    b72c:      	cmp	x2, x5
    b730:      	b.gt	0xb7b8 <_stogir.stack.validate-scope-inputs+0x454>
    b734:      	lsl	x2, x3, #2
    b738:      	ldr	x5, [x0, #0x50]
    b73c:      	add	x2, x2, x5
    b740:      	ldr	w2, [x2]
    b744:      	sxtw	x2, w2
    b748:      	cmp	x2, #0x0
    b74c:      	cset	w2, gt
    b750:      	ubfx	x2, x2, #0, #8
    b754:      	b	0xb7bc <_stogir.stack.validate-scope-inputs+0x458>
    b758:      	brk	#0
    b75c:      	b	0xb758 <_stogir.stack.validate-scope-inputs+0x3f4>
    b760:      	lsr	w0, w1, #0
    b764:      	ubfx	x0, x0, #8, #8
    b768:      	cmp	x0, #0x6
    b76c:      	b.ne	0xb78c <_stogir.stack.validate-scope-inputs+0x428>
    b770:      	uxtb	w1, w1
    b774:      	cmp	x1, #0x48
    b778:      	b.eq	0xb78c <_stogir.stack.validate-scope-inputs+0x428>
    b77c:      	movz	x0, #0x0, lsl #48
    b780:      	mov	x1, #0x8                ; =8
    b784:      	movz	x2, #0x0, lsl #48
    b788:      	b	0xb7a4 <_stogir.stack.validate-scope-inputs+0x440>
    b78c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b78c:  ARM64_RELOC_PAGE21	l_stogir.453
    b790:      	ldr	x16, [x16]
		000000000000b790:  ARM64_RELOC_PAGEOFF12	l_stogir.453
    b794:      	orr	x0, x16, xzr
    b798:      	mov	x1, x0
    b79c:      	mov	x0, #0x1                ; =1
    b7a0:      	mov	x2, #0x29               ; =41
    b7a4:      	b	0xb6b8 <_stogir.stack.validate-scope-inputs+0x354>
    b7a8:      	movz	x2, #0x0, lsl #48
    b7ac:      	b	0xb6dc <_stogir.stack.validate-scope-inputs+0x378>
    b7b0:      	movz	x2, #0x0, lsl #48
    b7b4:      	b	0xb708 <_stogir.stack.validate-scope-inputs+0x3a4>
    b7b8:      	movz	x2, #0x0, lsl #48
    b7bc:      	b	0xb7ac <_stogir.stack.validate-scope-inputs+0x448>
    b7c0:      	brk	#0
    b7c4:      	b	0xb7c0 <_stogir.stack.validate-scope-inputs+0x45c>

000000000000b7c8 <_stogir.stack.validate-inputs>:
    b7c8:      	sub	sp, sp, #0x110
    b7cc:      	str	x29, [sp]
    b7d0:      	str	x30, [sp, #0x8]
    b7d4:      	mov	x29, sp
    b7d8:      	str	x19, [sp, #0xb8]
    b7dc:      	str	x20, [sp, #0xc0]
    b7e0:      	str	x21, [sp, #0xc8]
    b7e4:      	str	x22, [sp, #0xd0]
    b7e8:      	str	x23, [sp, #0xd8]
    b7ec:      	str	x24, [sp, #0xe0]
    b7f0:      	str	x25, [sp, #0xe8]
    b7f4:      	str	x26, [sp, #0xf0]
    b7f8:      	str	x27, [sp, #0xf8]
    b7fc:      	str	x28, [sp, #0x100]
    b800:      	sxtw	x1, w1
    b804:      	cmp	x1, #0x51
    b808:      	cset	w19, eq
    b80c:      	uxtb	w16, w19
    b810:      	cmp	w16, wzr
    b814:      	b.ne	0xb884 <_stogir.stack.validate-inputs+0xbc>
    b818:      	cmp	x1, #0x52
    b81c:      	b.eq	0xb884 <_stogir.stack.validate-inputs+0xbc>
    b820:      	str	x8, [sp, #0x90]
    b824:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b824:  ARM64_RELOC_PAGE21	l_stogir.454
    b828:      	ldr	x16, [x16]
		000000000000b828:  ARM64_RELOC_PAGEOFF12	l_stogir.454
    b82c:      	orr	x0, x16, xzr
    b830:      	mov	x1, x0
    b834:      	mov	x0, #0x1                ; =1
    b838:      	mov	x2, #0x29               ; =41
    b83c:      	ldr	x3, [sp, #0x90]
    b840:      	str	x0, [x3]
    b844:      	str	x1, [x3, #0x8]
    b848:      	str	x2, [x3, #0x10]
    b84c:      	ldr	x19, [sp, #0xb8]
    b850:      	ldr	x20, [sp, #0xc0]
    b854:      	ldr	x21, [sp, #0xc8]
    b858:      	ldr	x22, [sp, #0xd0]
    b85c:      	ldr	x23, [sp, #0xd8]
    b860:      	ldr	x24, [sp, #0xe0]
    b864:      	ldr	x25, [sp, #0xe8]
    b868:      	ldr	x26, [sp, #0xf0]
    b86c:      	ldr	x27, [sp, #0xf8]
    b870:      	ldr	x28, [sp, #0x100]
    b874:      	ldr	x29, [sp]
    b878:      	ldr	x30, [sp, #0x8]
    b87c:      	add	sp, sp, #0x110
    b880:      	ret
    b884:      	uxtb	w16, w19
    b888:      	cmp	w16, wzr
    b88c:      	mov	x16, #0x6               ; =6
    b890:      	movz	x17, #0x0, lsl #48
    b894:      	csel	x1, x16, x17, ne
    b898:      	sxtw	x2, w2
    b89c:      	lsr	w1, w1, #0
    b8a0:      	sxtw	x1, w1
    b8a4:      	cmp	x2, x1
    b8a8:      	b.ne	0xbe08 <_stogir.stack.validate-inputs+0x640>
    b8ac:      	sxtw	x20, w5
    b8b0:      	uxtb	w16, w19
    b8b4:      	cmp	w16, wzr
    b8b8:      	b.eq	0xb8e4 <_stogir.stack.validate-inputs+0x11c>
    b8bc:      	cmp	x20, #0x0
    b8c0:      	b.eq	0xb8e4 <_stogir.stack.validate-inputs+0x11c>
    b8c4:      	cmp	x20, #0x0
    b8c8:      	b.le	0xb9bc <_stogir.stack.validate-inputs+0x1f4>
    b8cc:      	sub	x1, x20, #0x1
    b8d0:      	and	x1, x1, x20
    b8d4:      	cmp	x1, #0x0
    b8d8:      	cset	w1, eq
    b8dc:      	ubfx	x1, x1, #0, #8
    b8e0:      	b	0xb9c0 <_stogir.stack.validate-inputs+0x1f8>
    b8e4:      	lsr	w3, w3, #0
    b8e8:      	mov	w1, w3
    b8ec:      	mov	x21, x8
    b8f0:      	add	x8, sp, #0x10
    b8f4:      	mov	x22, x0
    b8f8:      	mov	w23, w3
    b8fc:      	mov	w24, w4
    b900:      	bl	0xb900 <_stogir.stack.validate-inputs+0x138>
		000000000000b900:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    b904:      	add	x16, sp, #0x10
    b908:      	ldr	w0, [x16]
    b90c:      	lsr	x16, x0, #0
    b910:      	cmp	x16, #0x1
    b914:      	b.eq	0xb930 <_stogir.stack.validate-inputs+0x168>
    b918:      	b.lo	0xb920 <_stogir.stack.validate-inputs+0x158>
    b91c:      	b	0xb934 <_stogir.stack.validate-inputs+0x16c>
    b920:      	cmp	x16, #0x0
    b924:      	b.eq	0xb92c <_stogir.stack.validate-inputs+0x164>
    b928:      	b	0xb934 <_stogir.stack.validate-inputs+0x16c>
    b92c:      	b	0xb938 <_stogir.stack.validate-inputs+0x170>
    b930:      	b	0xb958 <_stogir.stack.validate-inputs+0x190>
    b934:      	b	0xbb80 <_stogir.stack.validate-inputs+0x3b8>
    b938:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b938:  ARM64_RELOC_PAGE21	l_stogir.455
    b93c:      	ldr	x16, [x16]
		000000000000b93c:  ARM64_RELOC_PAGEOFF12	l_stogir.455
    b940:      	orr	x0, x16, xzr
    b944:      	str	x21, [sp, #0x90]
    b948:      	mov	x1, x0
    b94c:      	mov	x0, #0x1                ; =1
    b950:      	mov	x2, #0x1f               ; =31
    b954:      	b	0xb83c <_stogir.stack.validate-inputs+0x74>
    b958:      	sxtw	x23, w23
    b95c:      	add	x16, sp, #0x10
    b960:      	ldr	x0, [x16, #0x8]
    b964:      	cmp	x23, #0x0
    b968:      	b.gt	0xb98c <_stogir.stack.validate-inputs+0x1c4>
    b96c:      	str	x21, [sp, #0x90]
    b970:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b970:  ARM64_RELOC_PAGE21	l_stogir.456
    b974:      	ldr	x16, [x16]
		000000000000b974:  ARM64_RELOC_PAGEOFF12	l_stogir.456
    b978:      	orr	x0, x16, xzr
    b97c:      	mov	x1, x0
    b980:      	mov	x0, #0x1                ; =1
    b984:      	mov	x2, #0x1f               ; =31
    b988:      	b	0xb954 <_stogir.stack.validate-inputs+0x18c>
    b98c:      	uxtb	w0, w0
    b990:      	cmp	x0, #0x83
    b994:      	cset	w1, lt
    b998:      	uxtb	w16, w1
    b99c:      	cmp	w16, wzr
    b9a0:      	b.eq	0xb9d0 <_stogir.stack.validate-inputs+0x208>
    b9a4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b9a4:  ARM64_RELOC_PAGE21	l_stogir.457
    b9a8:      	ldr	x16, [x16]
		000000000000b9a8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b9ac:      	orr	x2, x16, xzr
    b9b0:      	add	x2, x0, x2
    b9b4:      	ldrb	w2, [x2]
    b9b8:      	b	0xb9d4 <_stogir.stack.validate-inputs+0x20c>
    b9bc:      	movz	x1, #0x0, lsl #48
    b9c0:      	cmp	x1, #0x0
    b9c4:      	b.ne	0xb8e4 <_stogir.stack.validate-inputs+0x11c>
    b9c8:      	str	x8, [sp, #0x90]
    b9cc:      	b	0xb824 <_stogir.stack.validate-inputs+0x5c>
    b9d0:      	movz	x2, #0x0, lsl #48
    b9d4:      	uxtb	w2, w2
    b9d8:      	and	x2, x2, #0x1
    b9dc:      	uxtb	w2, w2
    b9e0:      	cmp	x2, #0x0
    b9e4:      	b.eq	0xbe10 <_stogir.stack.validate-inputs+0x648>
    b9e8:      	uxtb	w16, w1
    b9ec:      	cmp	w16, wzr
    b9f0:      	b.eq	0xba0c <_stogir.stack.validate-inputs+0x244>
    b9f4:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000b9f4:  ARM64_RELOC_PAGE21	l_stogir.457
    b9f8:      	ldr	x16, [x16]
		000000000000b9f8:  ARM64_RELOC_PAGEOFF12	l_stogir.457
    b9fc:      	orr	x1, x16, xzr
    ba00:      	add	x0, x0, x1
    ba04:      	ldrb	w0, [x0]
    ba08:      	b	0xba10 <_stogir.stack.validate-inputs+0x248>
    ba0c:      	movz	x0, #0x0, lsl #48
    ba10:      	uxtb	w0, w0
    ba14:      	and	x0, x0, #0x4
    ba18:      	uxtb	w0, w0
    ba1c:      	cmp	x0, #0x0
    ba20:      	b.ne	0xbe18 <_stogir.stack.validate-inputs+0x650>
    ba24:      	lsr	w24, w24, #0
    ba28:      	add	x8, sp, #0x40
    ba2c:      	mov	x0, x22
    ba30:      	mov	w1, w24
    ba34:      	bl	0xba34 <_stogir.stack.validate-inputs+0x26c>
		000000000000ba34:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    ba38:      	add	x16, sp, #0x40
    ba3c:      	ldr	w0, [x16]
    ba40:      	lsr	x16, x0, #0
    ba44:      	cmp	x16, #0x1
    ba48:      	b.eq	0xba64 <_stogir.stack.validate-inputs+0x29c>
    ba4c:      	b.lo	0xba54 <_stogir.stack.validate-inputs+0x28c>
    ba50:      	b	0xba68 <_stogir.stack.validate-inputs+0x2a0>
    ba54:      	cmp	x16, #0x0
    ba58:      	b.eq	0xba60 <_stogir.stack.validate-inputs+0x298>
    ba5c:      	b	0xba68 <_stogir.stack.validate-inputs+0x2a0>
    ba60:      	b	0xba6c <_stogir.stack.validate-inputs+0x2a4>
    ba64:      	b	0xba8c <_stogir.stack.validate-inputs+0x2c4>
    ba68:      	b	0xbd10 <_stogir.stack.validate-inputs+0x548>
    ba6c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000ba6c:  ARM64_RELOC_PAGE21	l_stogir.458
    ba70:      	ldr	x16, [x16]
		000000000000ba70:  ARM64_RELOC_PAGEOFF12	l_stogir.458
    ba74:      	orr	x0, x16, xzr
    ba78:      	str	x21, [sp, #0x90]
    ba7c:      	mov	x1, x0
    ba80:      	mov	x0, #0x1                ; =1
    ba84:      	mov	x2, #0x18               ; =24
    ba88:      	b	0xb988 <_stogir.stack.validate-inputs+0x1c0>
    ba8c:      	add	x16, sp, #0x40
    ba90:      	ldr	x0, [x16, #0x8]
    ba94:      	lsr	w1, w0, #0
    ba98:      	ubfx	x1, x1, #8, #8
    ba9c:      	cmp	x1, #0x1
    baa0:      	b.lt	0xbe20 <_stogir.stack.validate-inputs+0x658>
    baa4:      	cmp	x1, #0xb
    baa8:      	b.gt	0xbe28 <_stogir.stack.validate-inputs+0x660>
    baac:      	uxtb	w0, w0
    bab0:      	cmp	x0, #0x48
    bab4:      	b.eq	0xbe30 <_stogir.stack.validate-inputs+0x668>
    bab8:      	sxtw	x0, w24
    babc:      	cmp	x1, #0x0
    bac0:      	cset	w23, eq
    bac4:      	cmp	x1, #0x1
    bac8:      	cset	w25, eq
    bacc:      	cmp	x1, #0x2
    bad0:      	cset	w26, eq
    bad4:      	cmp	x1, #0x7
    bad8:      	cset	w27, eq
    badc:      	cmp	x1, #0x8
    bae0:      	cset	w28, eq
    bae4:      	cmp	x1, #0x3
    bae8:      	cset	w2, eq
    baec:      	cmp	x1, #0x9
    baf0:      	cset	w3, eq
    baf4:      	cmp	x1, #0x4
    baf8:      	cset	w4, eq
    bafc:      	cmp	x1, #0xa
    bb00:      	cset	w5, eq
    bb04:      	cmp	x1, #0xd
    bb08:      	cset	w6, eq
    bb0c:      	cmp	x1, #0x5
    bb10:      	cset	w7, eq
    bb14:      	cmp	x1, #0xb
    bb18:      	cset	w8, eq
    bb1c:      	cmp	x1, #0xc
    bb20:      	cset	w9, eq
    bb24:      	cmp	x1, #0x6
    bb28:      	cset	w1, eq
    bb2c:      	uxtb	w16, w1
    bb30:      	cmp	w16, wzr
    bb34:      	mov	x16, #0x8               ; =8
    bb38:      	movn	x17, #0x0, lsl #48
    bb3c:      	csel	x1, x16, x17, ne
    bb40:      	cmp	x0, #0x0
    bb44:      	b.ge	0xbe38 <_stogir.stack.validate-inputs+0x670>
    bb48:      	uxtb	w16, w19
    bb4c:      	cmp	w16, wzr
    bb50:      	b.eq	0xbc74 <_stogir.stack.validate-inputs+0x4ac>
    bb54:      	cmp	x20, #0x10
    bb58:      	b.le	0xbc74 <_stogir.stack.validate-inputs+0x4ac>
    bb5c:      	mov	x0, x20
    bb60:      	b	0xbc78 <_stogir.stack.validate-inputs+0x4b0>
    bb64:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000bb64:  ARM64_RELOC_PAGE21	l_stogir.459
    bb68:      	ldr	x16, [x16]
		000000000000bb68:  ARM64_RELOC_PAGEOFF12	l_stogir.459
    bb6c:      	orr	x0, x16, xzr
    bb70:      	mov	x1, x0
    bb74:      	mov	x0, #0x1                ; =1
    bb78:      	mov	x2, #0x29               ; =41
    bb7c:      	b	0xba88 <_stogir.stack.validate-inputs+0x2c0>
    bb80:      	brk	#0
    bb84:      	b	0xbb80 <_stogir.stack.validate-inputs+0x3b8>
    bb88:      	mov	x0, #0x1                ; =1
    bb8c:      	lsr	w0, w0, #0
    bb90:      	sxtw	x0, w0
    bb94:      	and	x0, x0, #0xffffffff
    bb98:      	mov	x1, x0
    bb9c:      	movz	x0, #0x0, lsl #48
    bba0:      	movz	x2, #0x0, lsl #48
    bba4:      	b	0xbb7c <_stogir.stack.validate-inputs+0x3b4>
    bba8:      	uxtb	w16, w23
    bbac:      	cmp	w16, wzr
    bbb0:      	b.eq	0xbbdc <_stogir.stack.validate-inputs+0x414>
    bbb4:      	movz	x0, #0x0, lsl #48
    bbb8:      	b	0xbb8c <_stogir.stack.validate-inputs+0x3c4>
    bbbc:      	mov	x0, #0x1                ; =1
    bbc0:      	lsr	w0, w0, #0
    bbc4:      	sxtw	x0, w0
    bbc8:      	and	x0, x0, #0xffffffff
    bbcc:      	mov	x1, x0
    bbd0:      	movz	x0, #0x0, lsl #48
    bbd4:      	movz	x2, #0x0, lsl #48
    bbd8:      	b	0xbba4 <_stogir.stack.validate-inputs+0x3dc>
    bbdc:      	uxtb	w16, w25
    bbe0:      	cmp	w16, wzr
    bbe4:      	b.ne	0xbb88 <_stogir.stack.validate-inputs+0x3c0>
    bbe8:      	uxtb	w16, w26
    bbec:      	cmp	w16, wzr
    bbf0:      	b.ne	0xbb88 <_stogir.stack.validate-inputs+0x3c0>
    bbf4:      	uxtb	w16, w27
    bbf8:      	cmp	w16, wzr
    bbfc:      	b.ne	0xbb88 <_stogir.stack.validate-inputs+0x3c0>
    bc00:      	uxtb	w16, w28
    bc04:      	cmp	w16, wzr
    bc08:      	b.ne	0xbb88 <_stogir.stack.validate-inputs+0x3c0>
    bc0c:      	uxtb	w16, w19
    bc10:      	cmp	w16, wzr
    bc14:      	b.ne	0xbdd0 <_stogir.stack.validate-inputs+0x608>
    bc18:      	uxtb	w16, w20
    bc1c:      	cmp	w16, wzr
    bc20:      	b.ne	0xbdd0 <_stogir.stack.validate-inputs+0x608>
    bc24:      	uxtb	w16, w22
    bc28:      	cmp	w16, wzr
    bc2c:      	b.ne	0xbde8 <_stogir.stack.validate-inputs+0x620>
    bc30:      	uxtb	w16, w24
    bc34:      	cmp	w16, wzr
    bc38:      	b.ne	0xbde8 <_stogir.stack.validate-inputs+0x620>
    bc3c:      	uxtb	w16, w21
    bc40:      	cmp	w16, wzr
    bc44:      	b.ne	0xbde8 <_stogir.stack.validate-inputs+0x620>
    bc48:      	uxtb	w16, w0
    bc4c:      	cmp	w16, wzr
    bc50:      	b.ne	0xbdf8 <_stogir.stack.validate-inputs+0x630>
    bc54:      	uxtb	w16, w1
    bc58:      	cmp	w16, wzr
    bc5c:      	b.ne	0xbdf8 <_stogir.stack.validate-inputs+0x630>
    bc60:      	uxtb	w16, w2
    bc64:      	cmp	w16, wzr
    bc68:      	b.ne	0xbdf8 <_stogir.stack.validate-inputs+0x630>
    bc6c:      	ldr	x0, [sp, #0xb0]
    bc70:      	b	0xbdfc <_stogir.stack.validate-inputs+0x634>
    bc74:      	mov	x0, #0x10               ; =16
    bc78:      	lsr	w24, w24, #0
    bc7c:      	mov	w19, w2
    bc80:      	mov	x2, x0
    bc84:      	mov	x0, x22
    bc88:      	mov	w20, w3
    bc8c:      	mov	w22, w4
    bc90:      	str	w7, [sp, #0x98]
    bc94:      	str	w8, [sp, #0xa0]
    bc98:      	add	x8, sp, #0x70
    bc9c:      	str	w9, [sp, #0xa8]
    bca0:      	str	x1, [sp, #0xb0]
    bca4:      	mov	w1, w24
    bca8:      	mov	w24, w5
    bcac:      	str	x21, [sp, #0x90]
    bcb0:      	mov	w21, w6
    bcb4:      	bl	0xbcb4 <_stogir.stack.validate-inputs+0x4ec>
		000000000000bcb4:  ARM64_RELOC_BRANCH26	_stogir.stack.constant-size-aligned
    bcb8:      	add	x16, sp, #0x70
    bcbc:      	ldr	w0, [x16]
    bcc0:      	lsr	x16, x0, #0
    bcc4:      	cmp	x16, #0x1
    bcc8:      	b.eq	0xbce4 <_stogir.stack.validate-inputs+0x51c>
    bccc:      	b.lo	0xbcd4 <_stogir.stack.validate-inputs+0x50c>
    bcd0:      	b	0xbce8 <_stogir.stack.validate-inputs+0x520>
    bcd4:      	cmp	x16, #0x0
    bcd8:      	b.eq	0xbce0 <_stogir.stack.validate-inputs+0x518>
    bcdc:      	b	0xbce8 <_stogir.stack.validate-inputs+0x520>
    bce0:      	b	0xbd18 <_stogir.stack.validate-inputs+0x550>
    bce4:      	b	0xbcec <_stogir.stack.validate-inputs+0x524>
    bce8:      	b	0xbde0 <_stogir.stack.validate-inputs+0x618>
    bcec:      	add	x16, sp, #0x70
    bcf0:      	orr	x0, x16, xzr
    bcf4:      	add	x0, x0, #0x8
    bcf8:      	add	x16, sp, #0x70
    bcfc:      	ldr	x1, [x16, #0x8]
    bd00:      	ldr	x0, [x0, #0x8]
    bd04:      	mov	x2, x0
    bd08:      	mov	x0, #0x1                ; =1
    bd0c:      	b	0xbbd8 <_stogir.stack.validate-inputs+0x410>
    bd10:      	brk	#0
    bd14:      	b	0xbd10 <_stogir.stack.validate-inputs+0x548>
    bd18:      	uxtb	w16, w23
    bd1c:      	cmp	w16, wzr
    bd20:      	b.eq	0xbd2c <_stogir.stack.validate-inputs+0x564>
    bd24:      	movz	x0, #0x0, lsl #48
    bd28:      	b	0xbbc0 <_stogir.stack.validate-inputs+0x3f8>
    bd2c:      	uxtb	w16, w25
    bd30:      	cmp	w16, wzr
    bd34:      	b.ne	0xbbbc <_stogir.stack.validate-inputs+0x3f4>
    bd38:      	uxtb	w16, w26
    bd3c:      	cmp	w16, wzr
    bd40:      	b.ne	0xbbbc <_stogir.stack.validate-inputs+0x3f4>
    bd44:      	uxtb	w16, w27
    bd48:      	cmp	w16, wzr
    bd4c:      	b.ne	0xbbbc <_stogir.stack.validate-inputs+0x3f4>
    bd50:      	uxtb	w16, w28
    bd54:      	cmp	w16, wzr
    bd58:      	b.ne	0xbbbc <_stogir.stack.validate-inputs+0x3f4>
    bd5c:      	uxtb	w16, w19
    bd60:      	cmp	w16, wzr
    bd64:      	b.ne	0xbdd8 <_stogir.stack.validate-inputs+0x610>
    bd68:      	uxtb	w16, w20
    bd6c:      	cmp	w16, wzr
    bd70:      	b.ne	0xbdd8 <_stogir.stack.validate-inputs+0x610>
    bd74:      	uxtb	w16, w22
    bd78:      	cmp	w16, wzr
    bd7c:      	b.ne	0xbdf0 <_stogir.stack.validate-inputs+0x628>
    bd80:      	uxtb	w16, w24
    bd84:      	cmp	w16, wzr
    bd88:      	b.ne	0xbdf0 <_stogir.stack.validate-inputs+0x628>
    bd8c:      	uxtb	w16, w21
    bd90:      	cmp	w16, wzr
    bd94:      	b.ne	0xbdf0 <_stogir.stack.validate-inputs+0x628>
    bd98:      	ldr	w0, [sp, #0x98]
    bd9c:      	uxtb	w16, w0
    bda0:      	cmp	w16, wzr
    bda4:      	b.ne	0xbe00 <_stogir.stack.validate-inputs+0x638>
    bda8:      	ldr	w1, [sp, #0xa0]
    bdac:      	uxtb	w16, w1
    bdb0:      	cmp	w16, wzr
    bdb4:      	b.ne	0xbe00 <_stogir.stack.validate-inputs+0x638>
    bdb8:      	ldr	w2, [sp, #0xa8]
    bdbc:      	uxtb	w16, w2
    bdc0:      	cmp	w16, wzr
    bdc4:      	b.ne	0xbe00 <_stogir.stack.validate-inputs+0x638>
    bdc8:      	ldr	x0, [sp, #0xb0]
    bdcc:      	b	0xbe04 <_stogir.stack.validate-inputs+0x63c>
    bdd0:      	mov	x0, #0x2                ; =2
    bdd4:      	b	0xbb8c <_stogir.stack.validate-inputs+0x3c4>
    bdd8:      	mov	x0, #0x2                ; =2
    bddc:      	b	0xbbc0 <_stogir.stack.validate-inputs+0x3f8>
    bde0:      	brk	#0
    bde4:      	b	0xbde0 <_stogir.stack.validate-inputs+0x618>
    bde8:      	mov	x0, #0x4                ; =4
    bdec:      	b	0xbdd4 <_stogir.stack.validate-inputs+0x60c>
    bdf0:      	mov	x0, #0x4                ; =4
    bdf4:      	b	0xbddc <_stogir.stack.validate-inputs+0x614>
    bdf8:      	mov	x0, #0x8                ; =8
    bdfc:      	b	0xbdec <_stogir.stack.validate-inputs+0x624>
    be00:      	mov	x0, #0x8                ; =8
    be04:      	b	0xbdf4 <_stogir.stack.validate-inputs+0x62c>
    be08:      	str	x8, [sp, #0x90]
    be0c:      	b	0xb824 <_stogir.stack.validate-inputs+0x5c>
    be10:      	str	x21, [sp, #0x90]
    be14:      	b	0xb970 <_stogir.stack.validate-inputs+0x1a8>
    be18:      	str	x21, [sp, #0x90]
    be1c:      	b	0xb970 <_stogir.stack.validate-inputs+0x1a8>
    be20:      	str	x21, [sp, #0x90]
    be24:      	b	0xbb64 <_stogir.stack.validate-inputs+0x39c>
    be28:      	str	x21, [sp, #0x90]
    be2c:      	b	0xbb64 <_stogir.stack.validate-inputs+0x39c>
    be30:      	str	x21, [sp, #0x90]
    be34:      	b	0xbb64 <_stogir.stack.validate-inputs+0x39c>
    be38:      	str	x21, [sp, #0x90]
    be3c:      	str	x1, [sp, #0xb0]
    be40:      	mov	w19, w2
    be44:      	mov	w20, w3
    be48:      	mov	w22, w4
    be4c:      	mov	w24, w5
    be50:      	mov	w21, w6
    be54:      	mov	w0, w7
    be58:      	mov	w1, w8
    be5c:      	mov	w2, w9
    be60:      	b	0xbba8 <_stogir.stack.validate-inputs+0x3e0>

000000000000be64 <_stogir.locals.shape>:
    be64:      	sub	sp, sp, #0x40
    be68:      	str	x29, [sp]
    be6c:      	str	x30, [sp, #0x8]
    be70:      	mov	x29, sp
    be74:      	str	x19, [sp, #0x20]
    be78:      	str	x20, [sp, #0x28]
    be7c:      	str	x21, [sp, #0x30]
    be80:      	str	x22, [sp, #0x38]
    be84:      	sxtw	x19, w1
    be88:      	lsl	x20, x19, #2
    be8c:      	cmp	x19, #0x0
    be90:      	cset	w1, gt
    be94:      	movz	x16, #0x0, lsl #48
    be98:      	sub	x3, x16, x19
    be9c:      	sub	x4, x3, #0x1
    bea0:      	uxtb	w16, w1
    bea4:      	cmp	w16, wzr
    bea8:      	b.eq	0xbee8 <_stogir.locals.shape+0x84>
    beac:      	ldr	x3, [x0, #0x8]
    beb0:      	cmp	x19, x3
    beb4:      	b.ge	0xbf58 <_stogir.locals.shape+0xf4>
    beb8:      	add	x3, x0, #0x78
    bebc:      	ldr	x3, [x3, #0x8]
    bec0:      	cmp	x19, x3
    bec4:      	b.ge	0xc12c <_stogir.locals.shape+0x2c8>
    bec8:      	ldr	x3, [x0, #0x78]
    becc:      	add	x3, x20, x3
    bed0:      	ldr	w3, [x3]
    bed4:      	sxtw	x3, w3
    bed8:      	cmp	x3, #0x0
    bedc:      	cset	w3, ge
    bee0:      	ubfx	x3, x3, #0, #8
    bee4:      	b	0xc130 <_stogir.locals.shape+0x2cc>
    bee8:      	cmp	x19, #0x0
    beec:      	b.ge	0xbf60 <_stogir.locals.shape+0xfc>
    bef0:      	add	x5, x0, #0x28
    bef4:      	add	x6, x0, #0x50
    bef8:      	ldr	x5, [x5, #0x8]
    befc:      	ldr	x6, [x6, #0x8]
    bf00:      	cmp	x5, x6
    bf04:      	b.ne	0xbf34 <_stogir.locals.shape+0xd0>
    bf08:      	cmp	x3, x5
    bf0c:      	b.gt	0xc19c <_stogir.locals.shape+0x338>
    bf10:      	lsl	x3, x4, #2
    bf14:      	ldr	x5, [x0, #0x50]
    bf18:      	add	x3, x3, x5
    bf1c:      	ldr	w3, [x3]
    bf20:      	sxtw	x3, w3
    bf24:      	cmp	x3, #0x0
    bf28:      	cset	w3, gt
    bf2c:      	ubfx	x3, x3, #0, #8
    bf30:      	b	0xc1a0 <_stogir.locals.shape+0x33c>
    bf34:      	movz	x3, #0x0, lsl #48
    bf38:      	b	0xbf64 <_stogir.locals.shape+0x100>
    bf3c:      	adrp	x16, 0xb000 <_stogir.stack.valid-frame-object-inputs?+0x12c>
		000000000000bf3c:  ARM64_RELOC_PAGE21	l_stogir.460
    bf40:      	ldr	x16, [x16]
		000000000000bf40:  ARM64_RELOC_PAGEOFF12	l_stogir.460
    bf44:      	orr	x0, x16, xzr
    bf48:      	mov	x1, x0
    bf4c:      	mov	x0, #0x1                ; =1
    bf50:      	mov	x2, #0x1c               ; =28
    bf54:      	b	0xc024 <_stogir.locals.shape+0x1c0>
    bf58:      	movz	x3, #0x0, lsl #48
    bf5c:      	b	0xbf64 <_stogir.locals.shape+0x100>
    bf60:      	movz	x3, #0x0, lsl #48
    bf64:      	cmp	x3, #0x0
    bf68:      	b.eq	0xbfcc <_stogir.locals.shape+0x168>
    bf6c:      	uxtb	w16, w1
    bf70:      	cmp	w16, wzr
    bf74:      	b.eq	0xbf9c <_stogir.locals.shape+0x138>
    bf78:      	lsl	x1, x19, #4
    bf7c:      	ldr	x3, [x0]
    bf80:      	add	x1, x1, x3
    bf84:      	ldr	x3, [x1]
    bf88:      	ldr	x1, [x1, #0x8]
    bf8c:      	fmov	d31, x1
    bf90:      	mov	x1, x3
    bf94:      	fmov	x3, d31
    bf98:      	b	0xbfbc <_stogir.locals.shape+0x158>
    bf9c:      	lsl	x1, x4, #4
    bfa0:      	ldr	x3, [x0, #0x28]
    bfa4:      	add	x1, x1, x3
    bfa8:      	ldr	x3, [x1]
    bfac:      	ldr	x1, [x1, #0x8]
    bfb0:      	fmov	d31, x1
    bfb4:      	mov	x1, x3
    bfb8:      	fmov	x3, d31
    bfbc:      	mov	x4, x3
    bfc0:      	mov	x3, x1
    bfc4:      	mov	x1, #0x1                ; =1
    bfc8:      	b	0xbfd8 <_stogir.locals.shape+0x174>
    bfcc:      	movz	x1, #0x0, lsl #48
    bfd0:      	movz	x3, #0x0, lsl #48
    bfd4:      	movz	x4, #0x0, lsl #48
    bfd8:      	lsr	w1, w1, #0
    bfdc:      	lsr	x16, x1, #0
    bfe0:      	cmp	x16, #0x1
    bfe4:      	b.eq	0xc000 <_stogir.locals.shape+0x19c>
    bfe8:      	b.lo	0xbff0 <_stogir.locals.shape+0x18c>
    bfec:      	b	0xc004 <_stogir.locals.shape+0x1a0>
    bff0:      	cmp	x16, #0x0
    bff4:      	b.eq	0xbffc <_stogir.locals.shape+0x198>
    bff8:      	b	0xc004 <_stogir.locals.shape+0x1a0>
    bffc:      	b	0xc008 <_stogir.locals.shape+0x1a4>
    c000:      	b	0xc050 <_stogir.locals.shape+0x1ec>
    c004:      	b	0xc1f0 <_stogir.locals.shape+0x38c>
    c008:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c008:  ARM64_RELOC_PAGE21	l_stogir.461
    c00c:      	ldr	x16, [x16]
		000000000000c00c:  ARM64_RELOC_PAGEOFF12	l_stogir.461
    c010:      	orr	x0, x16, xzr
    c014:      	mov	x21, x8
    c018:      	mov	x1, x0
    c01c:      	mov	x0, #0x1                ; =1
    c020:      	mov	x2, #0x16               ; =22
    c024:      	str	x0, [x21]
    c028:      	str	x1, [x21, #0x8]
    c02c:      	str	x2, [x21, #0x10]
    c030:      	ldr	x19, [sp, #0x20]
    c034:      	ldr	x20, [sp, #0x28]
    c038:      	ldr	x21, [sp, #0x30]
    c03c:      	ldr	x22, [sp, #0x38]
    c040:      	ldr	x29, [sp]
    c044:      	ldr	x30, [sp, #0x8]
    c048:      	add	sp, sp, #0x40
    c04c:      	ret
    c050:      	lsr	w2, w2, #0
    c054:      	lsr	w1, w3, #0
    c058:      	add	x16, sp, #0x10
    c05c:      	str	x3, [x16]
    c060:      	add	x16, sp, #0x10
    c064:      	str	x4, [x16, #0x8]
    c068:      	ubfx	x1, x1, #8, #8
    c06c:      	lsr	w1, w1, #0
    c070:      	mov	x21, x8
    c074:      	mov	x22, x0
    c078:      	mov	w0, w1
    c07c:      	mov	w1, w2
    c080:      	bl	0xc080 <_stogir.locals.shape+0x21c>
		000000000000c080:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c084:      	lsr	w0, w0, #0
    c088:      	add	x16, sp, #0x10
    c08c:      	ldr	w1, [x16, #0xc]
    c090:      	sxtw	x0, w0
    c094:      	sxtw	x1, w1
    c098:      	cmp	x1, #0x0
    c09c:      	b.ne	0xc0a4 <_stogir.locals.shape+0x240>
    c0a0:      	mov	x1, x0
    c0a4:      	add	x16, sp, #0x10
    c0a8:      	ldr	w2, [x16, #0x8]
    c0ac:      	sxtw	x2, w2
    c0b0:      	cmp	x2, #0x0
    c0b4:      	cset	w3, eq
    c0b8:      	ubfx	x3, x3, #0, #8
    c0bc:      	cmp	x2, #0x0
    c0c0:      	b.le	0xc134 <_stogir.locals.shape+0x2d0>
    c0c4:      	cmp	x2, #0x0
    c0c8:      	b.le	0xc1ac <_stogir.locals.shape+0x348>
    c0cc:      	add	x4, x22, #0x110
    c0d0:      	add	x5, x4, #0x28
    c0d4:      	ldr	x5, [x5, #0x8]
    c0d8:      	cmp	x2, x5
    c0dc:      	b.gt	0xc1ac <_stogir.locals.shape+0x348>
    c0e0:      	sub	x2, x2, #0x1
    c0e4:      	mov	x17, #0x18              ; =24
    c0e8:      	mul	x2, x2, x17
    c0ec:      	ldr	x5, [x4, #0x28]
    c0f0:      	add	x2, x2, x5
    c0f4:      	ldr	x5, [x2]
    c0f8:      	ldr	x2, [x2, #0x8]
    c0fc:      	ldr	x4, [x4, #0x8]
    c100:      	cmp	x5, #0x0
    c104:      	b.lt	0xc1e8 <_stogir.locals.shape+0x384>
    c108:      	cmp	x5, x4
    c10c:      	b.gt	0xc1e8 <_stogir.locals.shape+0x384>
    c110:      	cmp	x2, #0x0
    c114:      	b.lt	0xc1e8 <_stogir.locals.shape+0x384>
    c118:      	sub	x4, x4, x5
    c11c:      	cmp	x2, x4
    c120:      	b.gt	0xc1e8 <_stogir.locals.shape+0x384>
    c124:      	mov	x2, #0x1                ; =1
    c128:      	b	0xc1ec <_stogir.locals.shape+0x388>
    c12c:      	movz	x3, #0x0, lsl #48
    c130:      	b	0xbf5c <_stogir.locals.shape+0xf8>
    c134:      	mov	x2, x3
    c138:      	cmp	x19, #0x0
    c13c:      	b.le	0xbf3c <_stogir.locals.shape+0xd8>
    c140:      	add	x16, sp, #0x10
    c144:      	ldr	w3, [x16]
    c148:      	uxtb	w3, w3
    c14c:      	cmp	x3, #0x48
    c150:      	b.ne	0xbf3c <_stogir.locals.shape+0xd8>
    c154:      	ldr	x3, [x22, #0x78]
    c158:      	add	x3, x20, x3
    c15c:      	ldr	w3, [x3]
    c160:      	sxtw	x3, w3
    c164:      	cmp	x3, #0x3
    c168:      	b.ne	0xbf3c <_stogir.locals.shape+0xd8>
    c16c:      	cmp	x0, #0x0
    c170:      	b.le	0xbf3c <_stogir.locals.shape+0xd8>
    c174:      	cmp	x2, #0x0
    c178:      	b.eq	0xbf3c <_stogir.locals.shape+0xd8>
    c17c:      	cmp	x1, #0x0
    c180:      	b.le	0xc1f8 <_stogir.locals.shape+0x394>
    c184:      	sub	x2, x1, #0x1
    c188:      	and	x2, x2, x1
    c18c:      	cmp	x2, #0x0
    c190:      	cset	w2, eq
    c194:      	ubfx	x2, x2, #0, #8
    c198:      	b	0xc1fc <_stogir.locals.shape+0x398>
    c19c:      	movz	x3, #0x0, lsl #48
    c1a0:      	b	0xbf38 <_stogir.locals.shape+0xd4>
    c1a4:      	mov	x2, #0x1                ; =1
    c1a8:      	b	0xc138 <_stogir.locals.shape+0x2d4>
    c1ac:      	movz	x2, #0x0, lsl #48
    c1b0:      	lsr	w2, w2, #0
    c1b4:      	lsr	x16, x2, #0
    c1b8:      	cmp	x16, #0x1
    c1bc:      	b.eq	0xc1d8 <_stogir.locals.shape+0x374>
    c1c0:      	b.lo	0xc1c8 <_stogir.locals.shape+0x364>
    c1c4:      	b	0xc1dc <_stogir.locals.shape+0x378>
    c1c8:      	cmp	x16, #0x0
    c1cc:      	b.eq	0xc1d4 <_stogir.locals.shape+0x370>
    c1d0:      	b	0xc1dc <_stogir.locals.shape+0x378>
    c1d4:      	b	0xc1e0 <_stogir.locals.shape+0x37c>
    c1d8:      	b	0xc1a4 <_stogir.locals.shape+0x340>
    c1dc:      	b	0xc2d8 <_stogir.locals.shape+0x474>
    c1e0:      	mov	x2, x3
    c1e4:      	b	0xc1a8 <_stogir.locals.shape+0x344>
    c1e8:      	movz	x2, #0x0, lsl #48
    c1ec:      	b	0xc1b0 <_stogir.locals.shape+0x34c>
    c1f0:      	brk	#0
    c1f4:      	b	0xc1f0 <_stogir.locals.shape+0x38c>
    c1f8:      	movz	x2, #0x0, lsl #48
    c1fc:      	cmp	x2, #0x0
    c200:      	b.eq	0xbf3c <_stogir.locals.shape+0xd8>
    c204:      	add	x16, sp, #0x10
    c208:      	ldr	w2, [x16, #0x4]
    c20c:      	sxtw	x2, w2
    c210:      	cmp	x2, #0x0
    c214:      	cset	w3, gt
    c218:      	movz	x16, #0x0, lsl #48
    c21c:      	sub	x4, x16, x2
    c220:      	sub	x5, x4, #0x1
    c224:      	uxtb	w16, w3
    c228:      	cmp	w16, wzr
    c22c:      	b.eq	0xc28c <_stogir.locals.shape+0x428>
    c230:      	ldr	x4, [x22, #0x8]
    c234:      	cmp	x2, x4
    c238:      	b.ge	0xc2e0 <_stogir.locals.shape+0x47c>
    c23c:      	add	x4, x22, #0x78
    c240:      	ldr	x4, [x4, #0x8]
    c244:      	cmp	x2, x4
    c248:      	b.ge	0xc3c4 <_stogir.locals.shape+0x560>
    c24c:      	lsl	x4, x2, #2
    c250:      	ldr	x6, [x22, #0x78]
    c254:      	add	x4, x4, x6
    c258:      	ldr	w4, [x4]
    c25c:      	sxtw	x4, w4
    c260:      	cmp	x4, #0x0
    c264:      	cset	w4, ge
    c268:      	ubfx	x4, x4, #0, #8
    c26c:      	b	0xc3c8 <_stogir.locals.shape+0x564>
    c270:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c270:  ARM64_RELOC_PAGE21	l_stogir.462
    c274:      	ldr	x16, [x16]
		000000000000c274:  ARM64_RELOC_PAGEOFF12	l_stogir.462
    c278:      	orr	x0, x16, xzr
    c27c:      	mov	x1, x0
    c280:      	mov	x0, #0x1                ; =1
    c284:      	mov	x2, #0x2c               ; =44
    c288:      	b	0xbf54 <_stogir.locals.shape+0xf0>
    c28c:      	cmp	x2, #0x0
    c290:      	b.ge	0xc2e8 <_stogir.locals.shape+0x484>
    c294:      	add	x6, x22, #0x28
    c298:      	add	x7, x22, #0x50
    c29c:      	ldr	x6, [x6, #0x8]
    c2a0:      	ldr	x7, [x7, #0x8]
    c2a4:      	cmp	x6, x7
    c2a8:      	b.ne	0xc3bc <_stogir.locals.shape+0x558>
    c2ac:      	cmp	x4, x6
    c2b0:      	b.gt	0xc3cc <_stogir.locals.shape+0x568>
    c2b4:      	lsl	x4, x5, #2
    c2b8:      	ldr	x6, [x22, #0x50]
    c2bc:      	add	x4, x4, x6
    c2c0:      	ldr	w4, [x4]
    c2c4:      	sxtw	x4, w4
    c2c8:      	cmp	x4, #0x0
    c2cc:      	cset	w4, gt
    c2d0:      	ubfx	x4, x4, #0, #8
    c2d4:      	b	0xc3d0 <_stogir.locals.shape+0x56c>
    c2d8:      	brk	#0
    c2dc:      	b	0xc2d8 <_stogir.locals.shape+0x474>
    c2e0:      	movz	x4, #0x0, lsl #48
    c2e4:      	b	0xc2ec <_stogir.locals.shape+0x488>
    c2e8:      	movz	x4, #0x0, lsl #48
    c2ec:      	cmp	x4, #0x0
    c2f0:      	b.eq	0xc330 <_stogir.locals.shape+0x4cc>
    c2f4:      	uxtb	w16, w3
    c2f8:      	cmp	w16, wzr
    c2fc:      	b.eq	0xc314 <_stogir.locals.shape+0x4b0>
    c300:      	lsl	x2, x2, #4
    c304:      	ldr	x3, [x22]
    c308:      	add	x2, x2, x3
    c30c:      	ldr	x2, [x2]
    c310:      	b	0xc324 <_stogir.locals.shape+0x4c0>
    c314:      	lsl	x2, x5, #4
    c318:      	ldr	x3, [x22, #0x28]
    c31c:      	add	x2, x2, x3
    c320:      	ldr	x2, [x2]
    c324:      	mov	x3, x2
    c328:      	mov	x2, #0x1                ; =1
    c32c:      	b	0xc338 <_stogir.locals.shape+0x4d4>
    c330:      	movz	x2, #0x0, lsl #48
    c334:      	movz	x3, #0x0, lsl #48
    c338:      	lsr	w2, w2, #0
    c33c:      	lsr	x16, x2, #0
    c340:      	cmp	x16, #0x1
    c344:      	b.eq	0xc360 <_stogir.locals.shape+0x4fc>
    c348:      	b.lo	0xc350 <_stogir.locals.shape+0x4ec>
    c34c:      	b	0xc364 <_stogir.locals.shape+0x500>
    c350:      	cmp	x16, #0x0
    c354:      	b.eq	0xc35c <_stogir.locals.shape+0x4f8>
    c358:      	b	0xc364 <_stogir.locals.shape+0x500>
    c35c:      	b	0xc368 <_stogir.locals.shape+0x504>
    c360:      	b	0xc384 <_stogir.locals.shape+0x520>
    c364:      	b	0xc3fc <_stogir.locals.shape+0x598>
    c368:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c368:  ARM64_RELOC_PAGE21	l_stogir.463
    c36c:      	ldr	x16, [x16]
		000000000000c36c:  ARM64_RELOC_PAGEOFF12	l_stogir.463
    c370:      	orr	x0, x16, xzr
    c374:      	mov	x1, x0
    c378:      	mov	x0, #0x1                ; =1
    c37c:      	mov	x2, #0x1d               ; =29
    c380:      	b	0xc288 <_stogir.locals.shape+0x424>
    c384:      	add	x16, sp, #0x10
    c388:      	ldr	w2, [x16, #0x4]
    c38c:      	sxtw	x2, w2
    c390:      	cmp	x2, #0x0
    c394:      	b.le	0xc270 <_stogir.locals.shape+0x40c>
    c398:      	uxtb	w3, w3
    c39c:      	cmp	x3, #0x83
    c3a0:      	b.ge	0xc3d4 <_stogir.locals.shape+0x570>
    c3a4:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c3a4:  ARM64_RELOC_PAGE21	l_stogir.464
    c3a8:      	ldr	x16, [x16]
		000000000000c3a8:  ARM64_RELOC_PAGEOFF12	l_stogir.464
    c3ac:      	orr	x2, x16, xzr
    c3b0:      	add	x2, x3, x2
    c3b4:      	ldrb	w2, [x2]
    c3b8:      	b	0xc3d8 <_stogir.locals.shape+0x574>
    c3bc:      	movz	x4, #0x0, lsl #48
    c3c0:      	b	0xc2ec <_stogir.locals.shape+0x488>
    c3c4:      	movz	x4, #0x0, lsl #48
    c3c8:      	b	0xc2e4 <_stogir.locals.shape+0x480>
    c3cc:      	movz	x4, #0x0, lsl #48
    c3d0:      	b	0xc3c0 <_stogir.locals.shape+0x55c>
    c3d4:      	movz	x2, #0x0, lsl #48
    c3d8:      	uxtb	w2, w2
    c3dc:      	and	x2, x2, #0x2
    c3e0:      	uxtb	w2, w2
    c3e4:      	cmp	x2, #0x0
    c3e8:      	b.eq	0xc270 <_stogir.locals.shape+0x40c>
    c3ec:      	mov	x2, x1
    c3f0:      	mov	x1, x0
    c3f4:      	movz	x0, #0x0, lsl #48
    c3f8:      	b	0xc288 <_stogir.locals.shape+0x424>
    c3fc:      	brk	#0
    c400:      	b	0xc3fc <_stogir.locals.shape+0x598>

000000000000c404 <_stogir.conversion.policy>:
    c404:      	sub	sp, sp, #0x70
    c408:      	str	x29, [sp]
    c40c:      	str	x30, [sp, #0x8]
    c410:      	mov	x29, sp
    c414:      	str	x19, [sp, #0x20]
    c418:      	str	x20, [sp, #0x28]
    c41c:      	str	x21, [sp, #0x30]
    c420:      	str	x22, [sp, #0x38]
    c424:      	str	x23, [sp, #0x40]
    c428:      	str	x24, [sp, #0x48]
    c42c:      	str	x25, [sp, #0x50]
    c430:      	str	x26, [sp, #0x58]
    c434:      	str	x27, [sp, #0x60]
    c438:      	str	x28, [sp, #0x68]
    c43c:      	sxtw	x19, w0
    c440:      	sxtw	x20, w1
    c444:      	sxtw	x21, w2
    c448:      	cmp	x19, #0x24
    c44c:      	b.ne	0xc49c <_stogir.conversion.policy+0x98>
    c450:      	cmp	x20, #0xf
    c454:      	b.le	0xc6b8 <_stogir.conversion.policy+0x2b4>
    c458:      	cmp	x20, #0x80
    c45c:      	b.ge	0xc6b8 <_stogir.conversion.policy+0x2b4>
    c460:      	and	x0, x20, #0xf
    c464:      	lsr	w0, w0, #0
    c468:      	sxtw	x0, w0
    c46c:      	cmp	x0, #0x1
    c470:      	b.lt	0xc6b8 <_stogir.conversion.policy+0x2b4>
    c474:      	and	x0, x20, #0xf
    c478:      	lsr	w0, w0, #0
    c47c:      	sxtw	x0, w0
    c480:      	cmp	x0, #0xd
    c484:      	b.gt	0xc6b8 <_stogir.conversion.policy+0x2b4>
    c488:      	mov	x0, #0x1                ; =1
    c48c:      	b	0xc494 <_stogir.conversion.policy+0x90>
    c490:      	movz	x0, #0x0, lsl #48
    c494:      	mov	x22, x0
    c498:      	b	0xc4a0 <_stogir.conversion.policy+0x9c>
    c49c:      	movz	x22, #0x0, lsl #48
    c4a0:      	sxtw	x23, w3
    c4a4:      	cmp	x20, #0xd
    c4a8:      	cset	w24, eq
    c4ac:      	cmp	x20, #0xc
    c4b0:      	cset	w25, eq
    c4b4:      	cmp	x23, #0x4
    c4b8:      	cset	w26, eq
    c4bc:      	cmp	x23, #0x8
    c4c0:      	cset	w27, eq
    c4c4:      	cmp	x22, #0x0
    c4c8:      	b.eq	0xc9ac <_stogir.conversion.policy+0x5a8>
    c4cc:      	lsr	w1, w1, #0
    c4d0:      	lsr	w3, w3, #0
    c4d4:      	mov	w0, w1
    c4d8:      	mov	w1, w3
    c4dc:      	str	x8, [sp, #0x18]
    c4e0:      	mov	w28, w3
    c4e4:      	str	x23, [sp, #0x10]
    c4e8:      	mov	w23, w2
    c4ec:      	bl	0xc4ec <_stogir.conversion.policy+0xe8>
		000000000000c4ec:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c4f0:      	lsr	w0, w0, #0
    c4f4:      	sxtw	x0, w0
    c4f8:      	b	0xc508 <_stogir.conversion.policy+0x104>
    c4fc:      	mov	x0, #0x1                ; =1
    c500:      	lsr	w0, w0, #0
    c504:      	sxtw	x0, w0
    c508:      	cmp	x21, #0xd
    c50c:      	cset	w1, eq
    c510:      	cmp	x21, #0xc
    c514:      	cset	w2, eq
    c518:      	cmp	x22, #0x0
    c51c:      	b.eq	0xc9c0 <_stogir.conversion.policy+0x5bc>
    c520:      	lsr	w23, w23, #0
    c524:      	lsr	w28, w28, #0
    c528:      	mov	x22, x0
    c52c:      	mov	w0, w23
    c530:      	mov	w23, w1
    c534:      	mov	w1, w28
    c538:      	mov	w28, w2
    c53c:      	bl	0xc53c <_stogir.conversion.policy+0x138>
		000000000000c53c:  ARM64_RELOC_BRANCH26	_stogir.types.size
    c540:      	lsr	w0, w0, #0
    c544:      	sxtw	x0, w0
    c548:      	b	0xc558 <_stogir.conversion.policy+0x154>
    c54c:      	mov	x0, #0x1                ; =1
    c550:      	lsr	w0, w0, #0
    c554:      	sxtw	x0, w0
    c558:      	cmp	x19, #0x21
    c55c:      	b.lt	0xc638 <_stogir.conversion.policy+0x234>
    c560:      	cmp	x19, #0x27
    c564:      	b.gt	0xc638 <_stogir.conversion.policy+0x234>
    c568:      	lsl	x1, x22, #3
    c56c:      	lsr	w1, w1, #0
    c570:      	sxtw	x1, w1
    c574:      	cmp	x1, #0x0
    c578:      	b.le	0xc638 <_stogir.conversion.policy+0x234>
    c57c:      	lsl	x0, x0, #3
    c580:      	lsr	w0, w0, #0
    c584:      	sxtw	x0, w0
    c588:      	cmp	x0, #0x0
    c58c:      	b.le	0xc638 <_stogir.conversion.policy+0x234>
    c590:      	cmp	x19, #0x26
    c594:      	cset	w2, eq
    c598:      	cmp	x20, #0x1
    c59c:      	cset	w3, ge
    c5a0:      	cmp	x20, #0xb
    c5a4:      	cset	w4, le
    c5a8:      	cmp	x21, #0x1
    c5ac:      	cset	w5, ge
    c5b0:      	cmp	x21, #0xb
    c5b4:      	cset	w6, le
    c5b8:      	cmp	x19, #0x25
    c5bc:      	b.lt	0xc84c <_stogir.conversion.policy+0x448>
    c5c0:      	ubfx	x23, x23, #0, #8
    c5c4:      	cmp	x19, #0x25
    c5c8:      	b.ne	0xc8bc <_stogir.conversion.policy+0x4b8>
    c5cc:      	uxtb	w16, w3
    c5d0:      	cmp	w16, wzr
    c5d4:      	b.eq	0xc8b4 <_stogir.conversion.policy+0x4b0>
    c5d8:      	uxtb	w16, w4
    c5dc:      	cmp	w16, wzr
    c5e0:      	b.eq	0xc8b4 <_stogir.conversion.policy+0x4b0>
    c5e4:      	uxtb	w16, w28
    c5e8:      	cmp	w16, wzr
    c5ec:      	b.eq	0xc930 <_stogir.conversion.policy+0x52c>
    c5f0:      	mov	x3, #0x1                ; =1
    c5f4:      	b	0xc934 <_stogir.conversion.policy+0x530>
    c5f8:      	uxtb	w16, w26
    c5fc:      	cmp	w16, wzr
    c600:      	b.ne	0xc698 <_stogir.conversion.policy+0x294>
    c604:      	uxtb	w16, w27
    c608:      	cmp	w16, wzr
    c60c:      	b.ne	0xc698 <_stogir.conversion.policy+0x294>
    c610:      	movn	x0, #0x0, lsl #48
    c614:      	b	0xc550 <_stogir.conversion.policy+0x14c>
    c618:      	uxtb	w16, w26
    c61c:      	cmp	w16, wzr
    c620:      	b.ne	0xc6a8 <_stogir.conversion.policy+0x2a4>
    c624:      	uxtb	w16, w27
    c628:      	cmp	w16, wzr
    c62c:      	b.ne	0xc6a8 <_stogir.conversion.policy+0x2a4>
    c630:      	movn	x0, #0x0, lsl #48
    c634:      	b	0xc500 <_stogir.conversion.policy+0xfc>
    c638:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c638:  ARM64_RELOC_PAGE21	l_stogir.465
    c63c:      	ldr	x16, [x16]
		000000000000c63c:  ARM64_RELOC_PAGEOFF12	l_stogir.465
    c640:      	orr	x0, x16, xzr
    c644:      	mov	x1, x0
    c648:      	mov	x0, #0x1                ; =1
    c64c:      	mov	x2, #0x22               ; =34
    c650:      	ldr	x3, [sp, #0x18]
    c654:      	str	x0, [x3]
    c658:      	str	x1, [x3, #0x8]
    c65c:      	str	x2, [x3, #0x10]
    c660:      	ldr	x19, [sp, #0x20]
    c664:      	ldr	x20, [sp, #0x28]
    c668:      	ldr	x21, [sp, #0x30]
    c66c:      	ldr	x22, [sp, #0x38]
    c670:      	ldr	x23, [sp, #0x40]
    c674:      	ldr	x24, [sp, #0x48]
    c678:      	ldr	x25, [sp, #0x50]
    c67c:      	ldr	x26, [sp, #0x58]
    c680:      	ldr	x27, [sp, #0x60]
    c684:      	ldr	x28, [sp, #0x68]
    c688:      	ldr	x29, [sp]
    c68c:      	ldr	x30, [sp, #0x8]
    c690:      	add	sp, sp, #0x70
    c694:      	ret
    c698:      	cmp	x21, #0x0
    c69c:      	b.ne	0xc700 <_stogir.conversion.policy+0x2fc>
    c6a0:      	movz	x0, #0x0, lsl #48
    c6a4:      	b	0xc550 <_stogir.conversion.policy+0x14c>
    c6a8:      	cmp	x20, #0x0
    c6ac:      	b.ne	0xc778 <_stogir.conversion.policy+0x374>
    c6b0:      	movz	x0, #0x0, lsl #48
    c6b4:      	b	0xc500 <_stogir.conversion.policy+0xfc>
    c6b8:      	cmp	x21, #0xf
    c6bc:      	b.le	0xc490 <_stogir.conversion.policy+0x8c>
    c6c0:      	cmp	x21, #0x80
    c6c4:      	b.ge	0xc6f8 <_stogir.conversion.policy+0x2f4>
    c6c8:      	and	x0, x21, #0xf
    c6cc:      	lsr	w0, w0, #0
    c6d0:      	sxtw	x0, w0
    c6d4:      	cmp	x0, #0x1
    c6d8:      	b.lt	0xc7f0 <_stogir.conversion.policy+0x3ec>
    c6dc:      	and	x0, x21, #0xf
    c6e0:      	lsr	w0, w0, #0
    c6e4:      	sxtw	x0, w0
    c6e8:      	cmp	x0, #0xd
    c6ec:      	cset	w0, le
    c6f0:      	ubfx	x0, x0, #0, #8
    c6f4:      	b	0xc7f4 <_stogir.conversion.policy+0x3f0>
    c6f8:      	movz	x0, #0x0, lsl #48
    c6fc:      	b	0xc494 <_stogir.conversion.policy+0x90>
    c700:      	cmp	x21, #0x1
    c704:      	b.eq	0xc54c <_stogir.conversion.policy+0x148>
    c708:      	cmp	x21, #0x2
    c70c:      	b.eq	0xc54c <_stogir.conversion.policy+0x148>
    c710:      	cmp	x21, #0x7
    c714:      	b.eq	0xc54c <_stogir.conversion.policy+0x148>
    c718:      	cmp	x21, #0x8
    c71c:      	b.eq	0xc54c <_stogir.conversion.policy+0x148>
    c720:      	cmp	x21, #0x3
    c724:      	b.eq	0xc8e8 <_stogir.conversion.policy+0x4e4>
    c728:      	cmp	x21, #0x9
    c72c:      	b.eq	0xc8e8 <_stogir.conversion.policy+0x4e4>
    c730:      	cmp	x21, #0x4
    c734:      	b.eq	0xc958 <_stogir.conversion.policy+0x554>
    c738:      	cmp	x21, #0xa
    c73c:      	b.eq	0xc958 <_stogir.conversion.policy+0x554>
    c740:      	uxtb	w16, w23
    c744:      	cmp	w16, wzr
    c748:      	b.ne	0xc958 <_stogir.conversion.policy+0x554>
    c74c:      	cmp	x21, #0x5
    c750:      	b.eq	0xc98c <_stogir.conversion.policy+0x588>
    c754:      	cmp	x21, #0xb
    c758:      	b.eq	0xc98c <_stogir.conversion.policy+0x588>
    c75c:      	uxtb	w16, w28
    c760:      	cmp	w16, wzr
    c764:      	b.ne	0xc98c <_stogir.conversion.policy+0x588>
    c768:      	cmp	x21, #0x6
    c76c:      	b.ne	0xc99c <_stogir.conversion.policy+0x598>
    c770:      	ldr	x0, [sp, #0x10]
    c774:      	b	0xc9a0 <_stogir.conversion.policy+0x59c>
    c778:      	cmp	x20, #0x1
    c77c:      	b.eq	0xc4fc <_stogir.conversion.policy+0xf8>
    c780:      	cmp	x20, #0x2
    c784:      	b.eq	0xc4fc <_stogir.conversion.policy+0xf8>
    c788:      	cmp	x20, #0x7
    c78c:      	b.eq	0xc4fc <_stogir.conversion.policy+0xf8>
    c790:      	cmp	x20, #0x8
    c794:      	b.eq	0xc4fc <_stogir.conversion.policy+0xf8>
    c798:      	cmp	x20, #0x3
    c79c:      	b.eq	0xc8f0 <_stogir.conversion.policy+0x4ec>
    c7a0:      	cmp	x20, #0x9
    c7a4:      	b.eq	0xc8f0 <_stogir.conversion.policy+0x4ec>
    c7a8:      	cmp	x20, #0x4
    c7ac:      	b.eq	0xc960 <_stogir.conversion.policy+0x55c>
    c7b0:      	cmp	x20, #0xa
    c7b4:      	b.eq	0xc960 <_stogir.conversion.policy+0x55c>
    c7b8:      	uxtb	w16, w24
    c7bc:      	cmp	w16, wzr
    c7c0:      	b.ne	0xc960 <_stogir.conversion.policy+0x55c>
    c7c4:      	cmp	x20, #0x5
    c7c8:      	b.eq	0xc994 <_stogir.conversion.policy+0x590>
    c7cc:      	cmp	x20, #0xb
    c7d0:      	b.eq	0xc994 <_stogir.conversion.policy+0x590>
    c7d4:      	uxtb	w16, w25
    c7d8:      	cmp	w16, wzr
    c7dc:      	b.ne	0xc994 <_stogir.conversion.policy+0x590>
    c7e0:      	cmp	x20, #0x6
    c7e4:      	b.ne	0xc9a4 <_stogir.conversion.policy+0x5a0>
    c7e8:      	ldr	x0, [sp, #0x10]
    c7ec:      	b	0xc9a8 <_stogir.conversion.policy+0x5a4>
    c7f0:      	movz	x0, #0x0, lsl #48
    c7f4:      	b	0xc6fc <_stogir.conversion.policy+0x2f8>
    c7f8:      	mov	x3, #0x1                ; =1
    c7fc:      	cmp	x3, #0x0
    c800:      	b.ne	0xc638 <_stogir.conversion.policy+0x234>
    c804:      	cmp	x19, #0x23
    c808:      	b.eq	0xc81c <_stogir.conversion.policy+0x418>
    c80c:      	uxtb	w16, w2
    c810:      	cmp	w16, wzr
    c814:      	b.ne	0xc81c <_stogir.conversion.policy+0x418>
    c818:      	mov	x0, x1
    c81c:      	and	x0, x0, #0xffffffff
    c820:      	mov	x1, x0
    c824:      	movz	x0, #0x0, lsl #48
    c828:      	movz	x2, #0x0, lsl #48
    c82c:      	b	0xc650 <_stogir.conversion.policy+0x24c>
    c830:      	movz	x3, #0x0, lsl #48
    c834:      	cmp	x3, #0x0
    c838:      	cset	w3, ne
    c83c:      	uxtb	w16, w3
    c840:      	cmp	w16, wzr
    c844:      	cset	x3, eq
    c848:      	b	0xc7fc <_stogir.conversion.policy+0x3f8>
    c84c:      	cmp	x19, #0x24
    c850:      	b.ne	0xc86c <_stogir.conversion.policy+0x468>
    c854:      	cmp	x1, x0
    c858:      	cset	w3, eq
    c85c:      	uxtb	w16, w3
    c860:      	cmp	w16, wzr
    c864:      	cset	x3, eq
    c868:      	b	0xc7fc <_stogir.conversion.policy+0x3f8>
    c86c:      	uxtb	w16, w3
    c870:      	cmp	w16, wzr
    c874:      	b.eq	0xc7f8 <_stogir.conversion.policy+0x3f4>
    c878:      	uxtb	w16, w4
    c87c:      	cmp	w16, wzr
    c880:      	b.eq	0xc7f8 <_stogir.conversion.policy+0x3f4>
    c884:      	uxtb	w16, w5
    c888:      	cmp	w16, wzr
    c88c:      	b.eq	0xc928 <_stogir.conversion.policy+0x524>
    c890:      	uxtb	w16, w6
    c894:      	cmp	w16, wzr
    c898:      	b.eq	0xc928 <_stogir.conversion.policy+0x524>
    c89c:      	cmp	x19, #0x23
    c8a0:      	b.ne	0xc97c <_stogir.conversion.policy+0x578>
    c8a4:      	cmp	x0, x1
    c8a8:      	cset	w3, ge
    c8ac:      	ubfx	x3, x3, #0, #8
    c8b0:      	b	0xc988 <_stogir.conversion.policy+0x584>
    c8b4:      	movz	x3, #0x0, lsl #48
    c8b8:      	b	0xc834 <_stogir.conversion.policy+0x430>
    c8bc:      	uxtb	w16, w2
    c8c0:      	cmp	w16, wzr
    c8c4:      	b.eq	0xc900 <_stogir.conversion.policy+0x4fc>
    c8c8:      	uxtb	w16, w25
    c8cc:      	cmp	w16, wzr
    c8d0:      	b.ne	0xc940 <_stogir.conversion.policy+0x53c>
    c8d4:      	uxtb	w16, w24
    c8d8:      	cmp	w16, wzr
    c8dc:      	b.ne	0xc940 <_stogir.conversion.policy+0x53c>
    c8e0:      	movz	x3, #0x0, lsl #48
    c8e4:      	b	0xc8fc <_stogir.conversion.policy+0x4f8>
    c8e8:      	mov	x0, #0x2                ; =2
    c8ec:      	b	0xc550 <_stogir.conversion.policy+0x14c>
    c8f0:      	mov	x0, #0x2                ; =2
    c8f4:      	b	0xc500 <_stogir.conversion.policy+0xfc>
    c8f8:      	movz	x3, #0x0, lsl #48
    c8fc:      	b	0xc834 <_stogir.conversion.policy+0x430>
    c900:      	cmp	x19, #0x27
    c904:      	b.ne	0xc830 <_stogir.conversion.policy+0x42c>
    c908:      	uxtb	w16, w25
    c90c:      	cmp	w16, wzr
    c910:      	b.ne	0xc968 <_stogir.conversion.policy+0x564>
    c914:      	uxtb	w16, w24
    c918:      	cmp	w16, wzr
    c91c:      	b.ne	0xc968 <_stogir.conversion.policy+0x564>
    c920:      	movz	x3, #0x0, lsl #48
    c924:      	b	0xc93c <_stogir.conversion.policy+0x538>
    c928:      	mov	x3, #0x1                ; =1
    c92c:      	b	0xc7fc <_stogir.conversion.policy+0x3f8>
    c930:      	mov	x3, x23
    c934:      	b	0xc8b8 <_stogir.conversion.policy+0x4b4>
    c938:      	mov	x3, x23
    c93c:      	b	0xc834 <_stogir.conversion.policy+0x430>
    c940:      	uxtb	w16, w5
    c944:      	cmp	w16, wzr
    c948:      	b.eq	0xc8f8 <_stogir.conversion.policy+0x4f4>
    c94c:      	ubfx	x6, x6, #0, #8
    c950:      	mov	x3, x6
    c954:      	b	0xc8fc <_stogir.conversion.policy+0x4f8>
    c958:      	mov	x0, #0x4                ; =4
    c95c:      	b	0xc8ec <_stogir.conversion.policy+0x4e8>
    c960:      	mov	x0, #0x4                ; =4
    c964:      	b	0xc8f4 <_stogir.conversion.policy+0x4f0>
    c968:      	uxtb	w16, w28
    c96c:      	cmp	w16, wzr
    c970:      	b.eq	0xc938 <_stogir.conversion.policy+0x534>
    c974:      	mov	x3, #0x1                ; =1
    c978:      	b	0xc93c <_stogir.conversion.policy+0x538>
    c97c:      	cmp	x0, x1
    c980:      	cset	w3, le
    c984:      	ubfx	x3, x3, #0, #8
    c988:      	b	0xc92c <_stogir.conversion.policy+0x528>
    c98c:      	mov	x0, #0x8                ; =8
    c990:      	b	0xc95c <_stogir.conversion.policy+0x558>
    c994:      	mov	x0, #0x8                ; =8
    c998:      	b	0xc964 <_stogir.conversion.policy+0x560>
    c99c:      	movn	x0, #0x0, lsl #48
    c9a0:      	b	0xc990 <_stogir.conversion.policy+0x58c>
    c9a4:      	movn	x0, #0x0, lsl #48
    c9a8:      	b	0xc998 <_stogir.conversion.policy+0x594>
    c9ac:      	str	x8, [sp, #0x18]
    c9b0:      	mov	w28, w3
    c9b4:      	str	x23, [sp, #0x10]
    c9b8:      	mov	w23, w2
    c9bc:      	b	0xc618 <_stogir.conversion.policy+0x214>
    c9c0:      	mov	x22, x0
    c9c4:      	mov	w23, w1
    c9c8:      	mov	w28, w2
    c9cc:      	b	0xc5f8 <_stogir.conversion.policy+0x1f4>

000000000000c9d0 <_stogir.conditional.operands>:
    c9d0:      	sub	sp, sp, #0x70
    c9d4:      	str	x29, [sp]
    c9d8:      	str	x30, [sp, #0x8]
    c9dc:      	mov	x29, sp
    c9e0:      	str	x19, [sp, #0x30]
    c9e4:      	str	x20, [sp, #0x38]
    c9e8:      	str	x21, [sp, #0x40]
    c9ec:      	str	x22, [sp, #0x48]
    c9f0:      	str	x23, [sp, #0x50]
    c9f4:      	str	x24, [sp, #0x58]
    c9f8:      	str	x25, [sp, #0x60]
    c9fc:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000c9fc:  ARM64_RELOC_PAGE21	l_stogir.466
    ca00:      	ldr	x16, [x16]
		000000000000ca00:  ARM64_RELOC_PAGEOFF12	l_stogir.466
    ca04:      	orr	x19, x16, xzr
    ca08:      	sxtw	x20, w1
    ca0c:      	cmp	x20, #0x0
    ca10:      	b.ne	0xcaf4 <_stogir.conditional.operands+0x124>
    ca14:      	mov	x21, x8
    ca18:      	mov	x22, x0
    ca1c:      	mov	w23, w2
    ca20:      	mov	w24, w3
    ca24:      	mov	w25, w4
    ca28:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000ca28:  ARM64_RELOC_PAGE21	l_stogir.467
    ca2c:      	ldr	x16, [x16]
		000000000000ca2c:  ARM64_RELOC_PAGEOFF12	l_stogir.467
    ca30:      	orr	x0, x16, xzr
    ca34:      	mov	x1, #0x2b               ; =43
    ca38:      	sxtw	x23, w23
    ca3c:      	cmp	x23, #0x0
    ca40:      	cset	w2, gt
    ca44:      	movz	x16, #0x0, lsl #48
    ca48:      	sub	x3, x16, x23
    ca4c:      	sub	x4, x3, #0x1
    ca50:      	uxtb	w16, w2
    ca54:      	cmp	w16, wzr
    ca58:      	b.eq	0xcaa8 <_stogir.conditional.operands+0xd8>
    ca5c:      	ldr	x3, [x22, #0x8]
    ca60:      	cmp	x23, x3
    ca64:      	b.ge	0xcb38 <_stogir.conditional.operands+0x168>
    ca68:      	add	x3, x22, #0x78
    ca6c:      	ldr	x3, [x3, #0x8]
    ca70:      	cmp	x23, x3
    ca74:      	b.ge	0xcf40 <_stogir.conditional.operands+0x570>
    ca78:      	lsl	x3, x23, #2
    ca7c:      	ldr	x5, [x22, #0x78]
    ca80:      	add	x3, x3, x5
    ca84:      	ldr	w3, [x3]
    ca88:      	sxtw	x3, w3
    ca8c:      	cmp	x3, #0x0
    ca90:      	cset	w3, ge
    ca94:      	ubfx	x3, x3, #0, #8
    ca98:      	fmov	d31, x0
    ca9c:      	mov	x0, x3
    caa0:      	fmov	x3, d31
    caa4:      	b	0xcf48 <_stogir.conditional.operands+0x578>
    caa8:      	cmp	x23, #0x0
    caac:      	b.ge	0xcb48 <_stogir.conditional.operands+0x178>
    cab0:      	add	x5, x22, #0x28
    cab4:      	add	x6, x22, #0x50
    cab8:      	ldr	x5, [x5, #0x8]
    cabc:      	ldr	x6, [x6, #0x8]
    cac0:      	cmp	x5, x6
    cac4:      	b.ne	0xcb28 <_stogir.conditional.operands+0x158>
    cac8:      	cmp	x3, x5
    cacc:      	b.gt	0xcfa0 <_stogir.conditional.operands+0x5d0>
    cad0:      	lsl	x3, x4, #2
    cad4:      	ldr	x5, [x22, #0x50]
    cad8:      	add	x3, x3, x5
    cadc:      	ldr	w3, [x3]
    cae0:      	sxtw	x3, w3
    cae4:      	cmp	x3, #0x0
    cae8:      	cset	w3, gt
    caec:      	ubfx	x3, x3, #0, #8
    caf0:      	b	0xcfa4 <_stogir.conditional.operands+0x5d4>
    caf4:      	lsr	w1, w1, #0
    caf8:      	mov	x21, x8
    cafc:      	mov	x22, x0
    cb00:      	mov	w0, w1
    cb04:      	mov	w23, w2
    cb08:      	mov	w24, w3
    cb0c:      	mov	w25, w4
    cb10:      	bl	0xcb10 <_stogir.conditional.operands+0x140>
		000000000000cb10:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    cb14:      	cmp	x0, #0x0
    cb18:      	b.eq	0xca28 <_stogir.conditional.operands+0x58>
    cb1c:      	mov	x0, x19
    cb20:      	movz	x1, #0x0, lsl #48
    cb24:      	b	0xca38 <_stogir.conditional.operands+0x68>
    cb28:      	movz	x3, #0x0, lsl #48
    cb2c:      	b	0xcb4c <_stogir.conditional.operands+0x17c>
    cb30:      	movz	x9, #0x0, lsl #48
    cb34:      	b	0xcc0c <_stogir.conditional.operands+0x23c>
    cb38:      	mov	x3, x1
    cb3c:      	mov	x1, x0
    cb40:      	movz	x0, #0x0, lsl #48
    cb44:      	b	0xcb5c <_stogir.conditional.operands+0x18c>
    cb48:      	movz	x3, #0x0, lsl #48
    cb4c:      	fmov	d31, x0
    cb50:      	mov	x0, x3
    cb54:      	mov	x3, x1
    cb58:      	fmov	x1, d31
    cb5c:      	cmp	x0, #0x0
    cb60:      	b.eq	0xcba4 <_stogir.conditional.operands+0x1d4>
    cb64:      	uxtb	w16, w2
    cb68:      	cmp	w16, wzr
    cb6c:      	b.eq	0xcb84 <_stogir.conditional.operands+0x1b4>
    cb70:      	lsl	x0, x23, #4
    cb74:      	ldr	x2, [x22]
    cb78:      	add	x0, x0, x2
    cb7c:      	ldr	x0, [x0]
    cb80:      	b	0xcb94 <_stogir.conditional.operands+0x1c4>
    cb84:      	lsl	x0, x4, #4
    cb88:      	ldr	x2, [x22, #0x28]
    cb8c:      	add	x0, x0, x2
    cb90:      	ldr	x0, [x0]
    cb94:      	mov	x2, x1
    cb98:      	mov	x1, x0
    cb9c:      	mov	x0, #0x1                ; =1
    cba0:      	b	0xcbb0 <_stogir.conditional.operands+0x1e0>
    cba4:      	mov	x2, x1
    cba8:      	movz	x0, #0x0, lsl #48
    cbac:      	movz	x1, #0x0, lsl #48
    cbb0:      	lsr	w0, w0, #0
    cbb4:      	lsr	x16, x0, #0
    cbb8:      	cmp	x16, #0x1
    cbbc:      	b.eq	0xcbd8 <_stogir.conditional.operands+0x208>
    cbc0:      	b.lo	0xcbc8 <_stogir.conditional.operands+0x1f8>
    cbc4:      	b	0xcbdc <_stogir.conditional.operands+0x20c>
    cbc8:      	cmp	x16, #0x0
    cbcc:      	b.eq	0xcbd4 <_stogir.conditional.operands+0x204>
    cbd0:      	b	0xcbdc <_stogir.conditional.operands+0x20c>
    cbd4:      	b	0xcbe0 <_stogir.conditional.operands+0x210>
    cbd8:      	b	0xcf24 <_stogir.conditional.operands+0x554>
    cbdc:      	b	0xcfd0 <_stogir.conditional.operands+0x600>
    cbe0:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000cbe0:  ARM64_RELOC_PAGE21	l_stogir.468
    cbe4:      	ldr	x16, [x16]
		000000000000cbe4:  ARM64_RELOC_PAGEOFF12	l_stogir.468
    cbe8:      	orr	x0, x16, xzr
    cbec:      	mov	x1, #0x16               ; =22
    cbf0:      	b	0xcc18 <_stogir.conditional.operands+0x248>
    cbf4:      	movz	x9, #0x0, lsl #48
    cbf8:      	fmov	d31, x8
    cbfc:      	mov	x8, x9
    cc00:      	fmov	x9, d31
    cc04:      	b	0xcc84 <_stogir.conditional.operands+0x2b4>
    cc08:      	movz	x9, #0x0, lsl #48
    cc0c:      	b	0xcc8c <_stogir.conditional.operands+0x2bc>
    cc10:      	mov	x0, x1
    cc14:      	mov	x1, x2
    cc18:      	add	x16, sp, #0x20
    cc1c:      	orr	x2, x16, xzr
    cc20:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000cc20:  ARM64_RELOC_PAGE21	l_stogir.469
    cc24:      	ldr	x16, [x16]
		000000000000cc24:  ARM64_RELOC_PAGEOFF12	l_stogir.469
    cc28:      	orr	x3, x16, xzr
    cc2c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000cc2c:  ARM64_RELOC_PAGE21	l_stogir.470
    cc30:      	ldr	x16, [x16]
		000000000000cc30:  ARM64_RELOC_PAGEOFF12	l_stogir.470
    cc34:      	orr	x4, x16, xzr
    cc38:      	lsr	w24, w24, #0
    cc3c:      	lsr	w25, w25, #0
    cc40:      	add	x5, x22, #0x78
    cc44:      	add	x6, x22, #0x28
    cc48:      	add	x7, x22, #0x50
    cc4c:      	add	x16, sp, #0x10
    cc50:      	str	w24, [x16]
    cc54:      	add	x16, sp, #0x10
    cc58:      	str	w25, [x16, #0x4]
    cc5c:      	add	x16, sp, #0x10
    cc60:      	ldr	x8, [x16]
    cc64:      	add	x16, sp, #0x20
    cc68:      	str	x8, [x16]
    cc6c:      	mov	x8, x1
    cc70:      	mov	x1, x0
    cc74:      	movz	x0, #0x0, lsl #48
    cc78:      	b	0xcd58 <_stogir.conditional.operands+0x388>
    cc7c:      	mov	x9, x8
    cc80:      	movz	x8, #0x0, lsl #48
    cc84:      	b	0xcc98 <_stogir.conditional.operands+0x2c8>
    cc88:      	movz	x9, #0x0, lsl #48
    cc8c:      	fmov	d31, x8
    cc90:      	mov	x8, x9
    cc94:      	fmov	x9, d31
    cc98:      	cmp	x8, #0x0
    cc9c:      	b.eq	0xcce0 <_stogir.conditional.operands+0x310>
    cca0:      	uxtb	w16, w0
    cca4:      	cmp	w16, wzr
    cca8:      	b.eq	0xccc0 <_stogir.conditional.operands+0x2f0>
    ccac:      	lsl	x0, x1, #4
    ccb0:      	ldr	x1, [x22]
    ccb4:      	add	x0, x0, x1
    ccb8:      	ldr	x0, [x0]
    ccbc:      	b	0xccd0 <_stogir.conditional.operands+0x300>
    ccc0:      	lsl	x0, x10, #4
    ccc4:      	ldr	x1, [x22, #0x28]
    ccc8:      	add	x0, x0, x1
    cccc:      	ldr	x0, [x0]
    ccd0:      	mov	x1, x0
    ccd4:      	mov	x8, x9
    ccd8:      	mov	x0, #0x1                ; =1
    ccdc:      	b	0xccec <_stogir.conditional.operands+0x31c>
    cce0:      	mov	x8, x9
    cce4:      	movz	x0, #0x0, lsl #48
    cce8:      	movz	x1, #0x0, lsl #48
    ccec:      	lsr	w0, w0, #0
    ccf0:      	lsr	x16, x0, #0
    ccf4:      	cmp	x16, #0x1
    ccf8:      	b.eq	0xcd14 <_stogir.conditional.operands+0x344>
    ccfc:      	b.lo	0xcd04 <_stogir.conditional.operands+0x334>
    cd00:      	b	0xcd18 <_stogir.conditional.operands+0x348>
    cd04:      	cmp	x16, #0x0
    cd08:      	b.eq	0xcd10 <_stogir.conditional.operands+0x340>
    cd0c:      	b	0xcd18 <_stogir.conditional.operands+0x348>
    cd10:      	b	0xcd1c <_stogir.conditional.operands+0x34c>
    cd14:      	b	0xcef4 <_stogir.conditional.operands+0x524>
    cd18:      	b	0xcfc8 <_stogir.conditional.operands+0x5f8>
    cd1c:      	mov	x0, x8
    cd20:      	mov	x1, x3
    cd24:      	mov	x8, #0x10               ; =16
    cd28:      	b	0xcd58 <_stogir.conditional.operands+0x388>
    cd2c:      	and	x0, x20, #0xffffffff
    cd30:      	mov	x1, x0
    cd34:      	movz	x0, #0x0, lsl #48
    cd38:      	movz	x2, #0x0, lsl #48
    cd3c:      	b	0xce78 <_stogir.conditional.operands+0x4a8>
    cd40:      	mov	x0, x4
    cd44:      	mov	x1, #0x21               ; =33
    cd48:      	fmov	d31, x0
    cd4c:      	mov	x0, x8
    cd50:      	mov	x8, x1
    cd54:      	fmov	x1, d31
    cd58:      	cmp	x0, #0x2
    cd5c:      	b.ge	0xcd90 <_stogir.conditional.operands+0x3c0>
    cd60:      	add	x9, x0, #0x1
    cd64:      	lsl	x0, x0, #2
    cd68:      	add	x0, x0, x2
    cd6c:      	ldr	w0, [x0]
    cd70:      	sxtw	x0, w0
    cd74:      	and	x0, x0, #0xffffffff
    cd78:      	mov	x23, x1
    cd7c:      	mov	x1, x0
    cd80:      	mov	x24, x8
    cd84:      	mov	x8, x9
    cd88:      	mov	x0, #0x1                ; =1
    cd8c:      	b	0xcda4 <_stogir.conditional.operands+0x3d4>
    cd90:      	mov	x23, x1
    cd94:      	mov	x24, x8
    cd98:      	mov	x8, x0
    cd9c:      	movz	x0, #0x0, lsl #48
    cda0:      	movz	x1, #0x0, lsl #48
    cda4:      	lsr	w0, w0, #0
    cda8:      	lsr	x16, x0, #0
    cdac:      	cmp	x16, #0x1
    cdb0:      	b.eq	0xcdcc <_stogir.conditional.operands+0x3fc>
    cdb4:      	b.lo	0xcdbc <_stogir.conditional.operands+0x3ec>
    cdb8:      	b	0xcdd0 <_stogir.conditional.operands+0x400>
    cdbc:      	cmp	x16, #0x0
    cdc0:      	b.eq	0xcdc8 <_stogir.conditional.operands+0x3f8>
    cdc4:      	b	0xcdd0 <_stogir.conditional.operands+0x400>
    cdc8:      	b	0xce38 <_stogir.conditional.operands+0x468>
    cdcc:      	b	0xcdd4 <_stogir.conditional.operands+0x404>
    cdd0:      	b	0xcfc0 <_stogir.conditional.operands+0x5f0>
    cdd4:      	lsr	w1, w1, #0
    cdd8:      	sxtw	x1, w1
    cddc:      	cmp	x1, #0x0
    cde0:      	cset	w0, gt
    cde4:      	movz	x16, #0x0, lsl #48
    cde8:      	sub	x9, x16, x1
    cdec:      	sub	x10, x9, #0x1
    cdf0:      	uxtb	w16, w0
    cdf4:      	cmp	w16, wzr
    cdf8:      	b.eq	0xceb0 <_stogir.conditional.operands+0x4e0>
    cdfc:      	ldr	x9, [x22, #0x8]
    ce00:      	cmp	x1, x9
    ce04:      	b.ge	0xcc7c <_stogir.conditional.operands+0x2ac>
    ce08:      	ldr	x9, [x5, #0x8]
    ce0c:      	cmp	x1, x9
    ce10:      	b.ge	0xcbf4 <_stogir.conditional.operands+0x224>
    ce14:      	lsl	x9, x1, #2
    ce18:      	ldr	x11, [x22, #0x78]
    ce1c:      	add	x9, x9, x11
    ce20:      	ldr	w9, [x9]
    ce24:      	sxtw	x9, w9
    ce28:      	cmp	x9, #0x0
    ce2c:      	cset	w9, ge
    ce30:      	ubfx	x9, x9, #0, #8
    ce34:      	b	0xcbf8 <_stogir.conditional.operands+0x228>
    ce38:      	cmp	x24, #0x0
    ce3c:      	b.ne	0xce6c <_stogir.conditional.operands+0x49c>
    ce40:      	cmp	x24, #0x0
    ce44:      	b.eq	0xcd2c <_stogir.conditional.operands+0x35c>
    ce48:      	lsr	x0, x24, #0
    ce4c:      	mov	x1, x19
    ce50:      	mov	x2, x0
    ce54:      	mov	x0, x23
    ce58:      	bl	0xce58 <_stogir.conditional.operands+0x488>
		000000000000ce58:  ARM64_RELOC_BRANCH26	_memcmp
    ce5c:      	lsr	w0, w0, #0
    ce60:      	sxtw	x0, w0
    ce64:      	cmp	x0, #0x0
    ce68:      	b.eq	0xcd2c <_stogir.conditional.operands+0x35c>
    ce6c:      	mov	x1, x23
    ce70:      	mov	x2, x24
    ce74:      	mov	x0, #0x1                ; =1
    ce78:      	str	x0, [x21]
    ce7c:      	str	x1, [x21, #0x8]
    ce80:      	str	x2, [x21, #0x10]
    ce84:      	ldr	x19, [sp, #0x30]
    ce88:      	ldr	x20, [sp, #0x38]
    ce8c:      	ldr	x21, [sp, #0x40]
    ce90:      	ldr	x22, [sp, #0x48]
    ce94:      	ldr	x23, [sp, #0x50]
    ce98:      	ldr	x24, [sp, #0x58]
    ce9c:      	ldr	x25, [sp, #0x60]
    cea0:      	ldr	x29, [sp]
    cea4:      	ldr	x30, [sp, #0x8]
    cea8:      	add	sp, sp, #0x70
    ceac:      	ret
    ceb0:      	cmp	x1, #0x0
    ceb4:      	b.ge	0xcc88 <_stogir.conditional.operands+0x2b8>
    ceb8:      	ldr	x11, [x6, #0x8]
    cebc:      	ldr	x12, [x7, #0x8]
    cec0:      	cmp	x11, x12
    cec4:      	b.ne	0xcc08 <_stogir.conditional.operands+0x238>
    cec8:      	cmp	x9, x11
    cecc:      	b.gt	0xcb30 <_stogir.conditional.operands+0x160>
    ced0:      	lsl	x9, x10, #2
    ced4:      	ldr	x11, [x22, #0x50]
    ced8:      	add	x9, x9, x11
    cedc:      	ldr	w9, [x9]
    cee0:      	sxtw	x9, w9
    cee4:      	cmp	x9, #0x0
    cee8:      	cset	w9, gt
    ceec:      	ubfx	x9, x9, #0, #8
    cef0:      	b	0xcb34 <_stogir.conditional.operands+0x164>
    cef4:      	uxtb	w0, w1
    cef8:      	cmp	x0, #0x48
    cefc:      	b.eq	0xcd40 <_stogir.conditional.operands+0x370>
    cf00:      	cmp	x0, #0x46
    cf04:      	b.eq	0xcd40 <_stogir.conditional.operands+0x370>
    cf08:      	lsr	w1, w1, #0
    cf0c:      	ubfx	x0, x1, #8, #8
    cf10:      	cmp	x0, x20
    cf14:      	b.ne	0xcd40 <_stogir.conditional.operands+0x370>
    cf18:      	mov	x0, x23
    cf1c:      	mov	x1, x24
    cf20:      	b	0xcd48 <_stogir.conditional.operands+0x378>
    cf24:      	uxtb	w0, w1
    cf28:      	cmp	x0, #0x48
    cf2c:      	b.ne	0xcf90 <_stogir.conditional.operands+0x5c0>
    cf30:      	mov	x1, x2
    cf34:      	mov	x2, x3
    cf38:      	mov	x0, #0x1                ; =1
    cf3c:      	b	0xcf74 <_stogir.conditional.operands+0x5a4>
    cf40:      	mov	x3, x0
    cf44:      	movz	x0, #0x0, lsl #48
    cf48:      	fmov	d31, x1
    cf4c:      	mov	x1, x3
    cf50:      	fmov	x3, d31
    cf54:      	b	0xcb44 <_stogir.conditional.operands+0x174>
    cf58:      	cmp	x0, #0xd
    cf5c:      	cset	w0, le
    cf60:      	uxtb	w16, w0
    cf64:      	cmp	w16, wzr
    cf68:      	cset	x0, eq
    cf6c:      	mov	x1, x2
    cf70:      	mov	x2, x3
    cf74:      	cmp	x0, #0x0
    cf78:      	b.eq	0xcc10 <_stogir.conditional.operands+0x240>
    cf7c:      	adrp	x16, 0xc000 <_stogir.locals.shape+0x19c>
		000000000000cf7c:  ARM64_RELOC_PAGE21	l_stogir.471
    cf80:      	ldr	x16, [x16]
		000000000000cf80:  ARM64_RELOC_PAGEOFF12	l_stogir.471
    cf84:      	orr	x0, x16, xzr
    cf88:      	mov	x1, #0x2a               ; =42
    cf8c:      	b	0xcc18 <_stogir.conditional.operands+0x248>
    cf90:      	cmp	x0, #0x46
    cf94:      	b.ne	0xcfa8 <_stogir.conditional.operands+0x5d8>
    cf98:      	mov	x0, #0x1                ; =1
    cf9c:      	b	0xcf6c <_stogir.conditional.operands+0x59c>
    cfa0:      	movz	x3, #0x0, lsl #48
    cfa4:      	b	0xcb2c <_stogir.conditional.operands+0x15c>
    cfa8:      	lsr	w1, w1, #0
    cfac:      	ubfx	x0, x1, #8, #8
    cfb0:      	cmp	x0, #0x0
    cfb4:      	b.ne	0xcf58 <_stogir.conditional.operands+0x588>
    cfb8:      	mov	x0, #0x1                ; =1
    cfbc:      	b	0xcf6c <_stogir.conditional.operands+0x59c>
    cfc0:      	brk	#0
    cfc4:      	b	0xcfc0 <_stogir.conditional.operands+0x5f0>
    cfc8:      	brk	#0
    cfcc:      	b	0xcfc8 <_stogir.conditional.operands+0x5f8>
    cfd0:      	brk	#0
    cfd4:      	b	0xcfd0 <_stogir.conditional.operands+0x600>

000000000000cfd8 <_stogir.floating.unary?>:
    cfd8:      	sxtw	x0, w0
    cfdc:      	cmp	x0, #0x1f
    cfe0:      	b.ne	0xcfec <_stogir.floating.unary?+0x14>
    cfe4:      	mov	x0, #0x1                ; =1
    cfe8:      	b	0xcff8 <_stogir.floating.unary?+0x20>
    cfec:      	cmp	x0, #0x20
    cff0:      	cset	w0, eq
    cff4:      	ubfx	x0, x0, #0, #8
    cff8:      	ret

000000000000cffc <_stogir.floating.comparison?>:
    cffc:      	sxtw	x0, w0
    d000:      	cmp	x0, #0xe
    d004:      	b.lt	0xd018 <_stogir.floating.comparison?+0x1c>
    d008:      	cmp	x0, #0x19
    d00c:      	cset	w0, le
    d010:      	ubfx	x0, x0, #0, #8
    d014:      	b	0xd01c <_stogir.floating.comparison?+0x20>
    d018:      	movz	x0, #0x0, lsl #48
    d01c:      	ret

000000000000d020 <_stogir.floating.operands>:
    d020:      	sub	sp, sp, #0x90
    d024:      	str	x29, [sp]
    d028:      	str	x30, [sp, #0x8]
    d02c:      	mov	x29, sp
    d030:      	str	x19, [sp, #0x60]
    d034:      	str	x20, [sp, #0x68]
    d038:      	str	x21, [sp, #0x70]
    d03c:      	str	x22, [sp, #0x78]
    d040:      	str	x23, [sp, #0x80]
    d044:      	str	x24, [sp, #0x88]
    d048:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d048:  ARM64_RELOC_PAGE21	l_stogir.472
    d04c:      	ldr	x16, [x16]
		000000000000d04c:  ARM64_RELOC_PAGEOFF12	l_stogir.472
    d050:      	orr	x19, x16, xzr
    d054:      	sxtw	x1, w1
    d058:      	sxtw	x20, w2
    d05c:      	cmp	x1, #0x1f
    d060:      	cset	w2, eq
    d064:      	cmp	x1, #0x20
    d068:      	cset	w6, eq
    d06c:      	cmp	x1, #0xe
    d070:      	b.lt	0xd0ac <_stogir.floating.operands+0x8c>
    d074:      	cmp	x1, #0x19
    d078:      	b.gt	0xd0ac <_stogir.floating.operands+0x8c>
    d07c:      	cmp	x20, #0xc
    d080:      	b.ne	0xd08c <_stogir.floating.operands+0x6c>
    d084:      	mov	x7, #0x1                ; =1
    d088:      	b	0xd098 <_stogir.floating.operands+0x78>
    d08c:      	cmp	x20, #0xd
    d090:      	cset	w7, eq
    d094:      	ubfx	x7, x7, #0, #8
    d098:      	cmp	x7, #0x0
    d09c:      	b.eq	0xd0e4 <_stogir.floating.operands+0xc4>
    d0a0:      	mov	x7, x19
    d0a4:      	movz	x9, #0x0, lsl #48
    d0a8:      	b	0xd0f4 <_stogir.floating.operands+0xd4>
    d0ac:      	uxtb	w16, w2
    d0b0:      	cmp	w16, wzr
    d0b4:      	b.ne	0xd07c <_stogir.floating.operands+0x5c>
    d0b8:      	uxtb	w16, w6
    d0bc:      	cmp	w16, wzr
    d0c0:      	b.ne	0xd07c <_stogir.floating.operands+0x5c>
    d0c4:      	cmp	x1, #0x1a
    d0c8:      	b.lt	0xd0d4 <_stogir.floating.operands+0xb4>
    d0cc:      	cmp	x1, #0x1d
    d0d0:      	b.le	0xd07c <_stogir.floating.operands+0x5c>
    d0d4:      	cmp	x1, #0x3a
    d0d8:      	b.eq	0xd07c <_stogir.floating.operands+0x5c>
    d0dc:      	cmp	x1, #0x3b
    d0e0:      	b.eq	0xd07c <_stogir.floating.operands+0x5c>
    d0e4:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d0e4:  ARM64_RELOC_PAGE21	l_stogir.473
    d0e8:      	ldr	x16, [x16]
		000000000000d0e8:  ARM64_RELOC_PAGEOFF12	l_stogir.473
    d0ec:      	orr	x7, x16, xzr
    d0f0:      	mov	x9, #0x22               ; =34
    d0f4:      	lsr	w3, w3, #0
    d0f8:      	add	x16, sp, #0x10
    d0fc:      	str	w3, [x16]
    d100:      	uxtb	w16, w2
    d104:      	cmp	w16, wzr
    d108:      	b.eq	0xd118 <_stogir.floating.operands+0xf8>
    d10c:      	mov	x6, x7
    d110:      	mov	x2, #0x1                ; =1
    d114:      	b	0xd124 <_stogir.floating.operands+0x104>
    d118:      	ubfx	x6, x6, #0, #8
    d11c:      	mov	x2, x6
    d120:      	mov	x6, x7
    d124:      	cmp	x2, #0x0
    d128:      	b.eq	0xd164 <_stogir.floating.operands+0x144>
    d12c:      	sxtw	x3, w3
    d130:      	mov	x2, x3
    d134:      	mov	x3, x6
    d138:      	b	0xd170 <_stogir.floating.operands+0x150>
    d13c:      	mov	x0, x1
    d140:      	mov	x1, x2
    d144:      	b	0xd2ac <_stogir.floating.operands+0x28c>
    d148:      	movz	x15, #0x0, lsl #48
    d14c:      	fmov	d31, x9
    d150:      	mov	x9, x15
    d154:      	fmov	x15, d31
    d158:      	b	0xd1c8 <_stogir.floating.operands+0x1a8>
    d15c:      	movz	x15, #0x0, lsl #48
    d160:      	b	0xd1d0 <_stogir.floating.operands+0x1b0>
    d164:      	sxtw	x4, w4
    d168:      	mov	x2, x4
    d16c:      	mov	x3, x6
    d170:      	add	x16, sp, #0x20
    d174:      	orr	x4, x16, xzr
    d178:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d178:  ARM64_RELOC_PAGE21	l_stogir.474
    d17c:      	ldr	x16, [x16]
		000000000000d17c:  ARM64_RELOC_PAGEOFF12	l_stogir.474
    d180:      	orr	x6, x16, xzr
    d184:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d184:  ARM64_RELOC_PAGE21	l_stogir.475
    d188:      	ldr	x16, [x16]
		000000000000d188:  ARM64_RELOC_PAGEOFF12	l_stogir.475
    d18c:      	orr	x7, x16, xzr
    d190:      	add	x10, x0, #0x78
    d194:      	add	x11, x0, #0x28
    d198:      	add	x12, x0, #0x50
    d19c:      	lsr	w2, w2, #0
    d1a0:      	add	x16, sp, #0x10
    d1a4:      	str	w2, [x16, #0x4]
    d1a8:      	add	x16, sp, #0x10
    d1ac:      	ldr	x2, [x16]
    d1b0:      	add	x16, sp, #0x20
    d1b4:      	str	x2, [x16]
    d1b8:      	movz	x2, #0x0, lsl #48
    d1bc:      	b	0xd2d0 <_stogir.floating.operands+0x2b0>
    d1c0:      	mov	x15, x9
    d1c4:      	movz	x9, #0x0, lsl #48
    d1c8:      	b	0xd1dc <_stogir.floating.operands+0x1bc>
    d1cc:      	movz	x15, #0x0, lsl #48
    d1d0:      	fmov	d31, x9
    d1d4:      	mov	x9, x15
    d1d8:      	fmov	x15, d31
    d1dc:      	cmp	x9, #0x0
    d1e0:      	b.eq	0xd224 <_stogir.floating.operands+0x204>
    d1e4:      	uxtb	w16, w2
    d1e8:      	cmp	w16, wzr
    d1ec:      	b.eq	0xd204 <_stogir.floating.operands+0x1e4>
    d1f0:      	lsl	x2, x3, #4
    d1f4:      	ldr	x3, [x0]
    d1f8:      	add	x2, x2, x3
    d1fc:      	ldr	x2, [x2]
    d200:      	b	0xd214 <_stogir.floating.operands+0x1f4>
    d204:      	lsl	x2, x21, #4
    d208:      	ldr	x3, [x0, #0x28]
    d20c:      	add	x2, x2, x3
    d210:      	ldr	x2, [x2]
    d214:      	mov	x3, x2
    d218:      	mov	x9, x15
    d21c:      	mov	x2, #0x1                ; =1
    d220:      	b	0xd230 <_stogir.floating.operands+0x210>
    d224:      	mov	x9, x15
    d228:      	movz	x2, #0x0, lsl #48
    d22c:      	movz	x3, #0x0, lsl #48
    d230:      	lsr	w2, w2, #0
    d234:      	lsr	x16, x2, #0
    d238:      	cmp	x16, #0x1
    d23c:      	b.eq	0xd258 <_stogir.floating.operands+0x238>
    d240:      	b.lo	0xd248 <_stogir.floating.operands+0x228>
    d244:      	b	0xd25c <_stogir.floating.operands+0x23c>
    d248:      	cmp	x16, #0x0
    d24c:      	b.eq	0xd254 <_stogir.floating.operands+0x234>
    d250:      	b	0xd25c <_stogir.floating.operands+0x23c>
    d254:      	b	0xd260 <_stogir.floating.operands+0x240>
    d258:      	b	0xd4b8 <_stogir.floating.operands+0x498>
    d25c:      	b	0xd5f0 <_stogir.floating.operands+0x5d0>
    d260:      	mov	x2, x9
    d264:      	mov	x3, x6
    d268:      	mov	x9, #0x18               ; =24
    d26c:      	b	0xd2d0 <_stogir.floating.operands+0x2b0>
    d270:      	and	x0, x20, #0xffffffff
    d274:      	mov	x1, x0
    d278:      	movz	x0, #0x0, lsl #48
    d27c:      	movz	x2, #0x0, lsl #48
    d280:      	b	0xd440 <_stogir.floating.operands+0x420>
    d284:      	mov	x22, x3
    d288:      	mov	x23, x4
    d28c:      	mov	x1, #0x1                ; =1
    d290:      	cmp	x1, #0x0
    d294:      	b.eq	0xd4d4 <_stogir.floating.operands+0x4b4>
    d298:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d298:  ARM64_RELOC_PAGE21	l_stogir.476
    d29c:      	ldr	x16, [x16]
		000000000000d29c:  ARM64_RELOC_PAGEOFF12	l_stogir.476
    d2a0:      	orr	x0, x16, xzr
    d2a4:      	mov	x24, x8
    d2a8:      	mov	x1, #0x21               ; =33
    d2ac:      	mov	x21, x0
    d2b0:      	mov	x22, x1
    d2b4:      	b	0xd400 <_stogir.floating.operands+0x3e0>
    d2b8:      	mov	x2, x7
    d2bc:      	mov	x3, #0x1e               ; =30
    d2c0:      	fmov	d31, x2
    d2c4:      	mov	x2, x9
    d2c8:      	mov	x9, x3
    d2cc:      	fmov	x3, d31
    d2d0:      	cmp	x2, #0x2
    d2d4:      	b.ge	0xd308 <_stogir.floating.operands+0x2e8>
    d2d8:      	add	x13, x2, #0x1
    d2dc:      	lsl	x2, x2, #2
    d2e0:      	add	x2, x2, x4
    d2e4:      	ldr	w2, [x2]
    d2e8:      	sxtw	x2, w2
    d2ec:      	and	x2, x2, #0xffffffff
    d2f0:      	mov	x14, x9
    d2f4:      	mov	x9, x13
    d2f8:      	mov	x13, x3
    d2fc:      	mov	x3, x2
    d300:      	mov	x2, #0x1                ; =1
    d304:      	b	0xd31c <_stogir.floating.operands+0x2fc>
    d308:      	mov	x13, x3
    d30c:      	mov	x14, x9
    d310:      	mov	x9, x2
    d314:      	movz	x2, #0x0, lsl #48
    d318:      	movz	x3, #0x0, lsl #48
    d31c:      	lsr	w2, w2, #0
    d320:      	lsr	x16, x2, #0
    d324:      	cmp	x16, #0x1
    d328:      	b.eq	0xd344 <_stogir.floating.operands+0x324>
    d32c:      	b.lo	0xd334 <_stogir.floating.operands+0x314>
    d330:      	b	0xd348 <_stogir.floating.operands+0x328>
    d334:      	cmp	x16, #0x0
    d338:      	b.eq	0xd340 <_stogir.floating.operands+0x320>
    d33c:      	b	0xd348 <_stogir.floating.operands+0x328>
    d340:      	b	0xd3b0 <_stogir.floating.operands+0x390>
    d344:      	b	0xd34c <_stogir.floating.operands+0x32c>
    d348:      	b	0xd5a4 <_stogir.floating.operands+0x584>
    d34c:      	lsr	w3, w3, #0
    d350:      	sxtw	x3, w3
    d354:      	cmp	x3, #0x0
    d358:      	cset	w2, gt
    d35c:      	movz	x16, #0x0, lsl #48
    d360:      	sub	x15, x16, x3
    d364:      	sub	x21, x15, #0x1
    d368:      	uxtb	w16, w2
    d36c:      	cmp	w16, wzr
    d370:      	b.eq	0xd474 <_stogir.floating.operands+0x454>
    d374:      	ldr	x15, [x0, #0x8]
    d378:      	cmp	x3, x15
    d37c:      	b.ge	0xd1c0 <_stogir.floating.operands+0x1a0>
    d380:      	ldr	x15, [x10, #0x8]
    d384:      	cmp	x3, x15
    d388:      	b.ge	0xd148 <_stogir.floating.operands+0x128>
    d38c:      	lsl	x15, x3, #2
    d390:      	ldr	x22, [x0, #0x78]
    d394:      	add	x15, x15, x22
    d398:      	ldr	w15, [x15]
    d39c:      	sxtw	x15, w15
    d3a0:      	cmp	x15, #0x0
    d3a4:      	cset	w15, ge
    d3a8:      	ubfx	x15, x15, #0, #8
    d3ac:      	b	0xd14c <_stogir.floating.operands+0x12c>
    d3b0:      	sxtw	x21, w5
    d3b4:      	cmp	x21, #0x0
    d3b8:      	b.ne	0xd3cc <_stogir.floating.operands+0x3ac>
    d3bc:      	mov	x3, x13
    d3c0:      	mov	x4, x14
    d3c4:      	movz	x2, #0x0, lsl #48
    d3c8:      	b	0xd3d8 <_stogir.floating.operands+0x3b8>
    d3cc:      	mov	x3, x13
    d3d0:      	mov	x4, x14
    d3d4:      	mov	x2, #0x1                ; =1
    d3d8:      	cmp	x2, #0x0
    d3dc:      	b.eq	0xd600 <_stogir.floating.operands+0x5e0>
    d3e0:      	cmp	x1, #0x1d
    d3e4:      	b.ne	0xd284 <_stogir.floating.operands+0x264>
    d3e8:      	mov	x22, x3
    d3ec:      	mov	x23, x4
    d3f0:      	movz	x1, #0x0, lsl #48
    d3f4:      	b	0xd290 <_stogir.floating.operands+0x270>
    d3f8:      	mov	x21, x3
    d3fc:      	mov	x22, x4
    d400:      	cmp	x22, #0x0
    d404:      	b.ne	0xd434 <_stogir.floating.operands+0x414>
    d408:      	cmp	x22, #0x0
    d40c:      	b.eq	0xd270 <_stogir.floating.operands+0x250>
    d410:      	lsr	x0, x22, #0
    d414:      	mov	x1, x19
    d418:      	mov	x2, x0
    d41c:      	mov	x0, x21
    d420:      	bl	0xd420 <_stogir.floating.operands+0x400>
		000000000000d420:  ARM64_RELOC_BRANCH26	_memcmp
    d424:      	lsr	w0, w0, #0
    d428:      	sxtw	x0, w0
    d42c:      	cmp	x0, #0x0
    d430:      	b.eq	0xd270 <_stogir.floating.operands+0x250>
    d434:      	mov	x1, x21
    d438:      	mov	x2, x22
    d43c:      	mov	x0, #0x1                ; =1
    d440:      	str	x0, [x24]
    d444:      	str	x1, [x24, #0x8]
    d448:      	str	x2, [x24, #0x10]
    d44c:      	ldr	x19, [sp, #0x60]
    d450:      	ldr	x20, [sp, #0x68]
    d454:      	ldr	x21, [sp, #0x70]
    d458:      	ldr	x22, [sp, #0x78]
    d45c:      	ldr	x23, [sp, #0x80]
    d460:      	ldr	x24, [sp, #0x88]
    d464:      	ldr	x29, [sp]
    d468:      	ldr	x30, [sp, #0x8]
    d46c:      	add	sp, sp, #0x90
    d470:      	ret
    d474:      	cmp	x3, #0x0
    d478:      	b.ge	0xd1cc <_stogir.floating.operands+0x1ac>
    d47c:      	ldr	x22, [x11, #0x8]
    d480:      	ldr	x23, [x12, #0x8]
    d484:      	cmp	x22, x23
    d488:      	b.ne	0xd15c <_stogir.floating.operands+0x13c>
    d48c:      	cmp	x15, x22
    d490:      	b.gt	0xd530 <_stogir.floating.operands+0x510>
    d494:      	lsl	x15, x21, #2
    d498:      	ldr	x22, [x0, #0x50]
    d49c:      	add	x15, x15, x22
    d4a0:      	ldr	w15, [x15]
    d4a4:      	sxtw	x15, w15
    d4a8:      	cmp	x15, #0x0
    d4ac:      	cset	w15, gt
    d4b0:      	ubfx	x15, x15, #0, #8
    d4b4:      	b	0xd534 <_stogir.floating.operands+0x514>
    d4b8:      	lsr	w3, w3, #0
    d4bc:      	ubfx	x2, x3, #8, #8
    d4c0:      	cmp	x2, x20
    d4c4:      	b.ne	0xd2b8 <_stogir.floating.operands+0x298>
    d4c8:      	mov	x2, x13
    d4cc:      	mov	x3, x14
    d4d0:      	b	0xd2c0 <_stogir.floating.operands+0x2a0>
    d4d4:      	lsr	w5, w5, #0
    d4d8:      	mov	w1, w5
    d4dc:      	mov	x24, x8
    d4e0:      	add	x8, sp, #0x30
    d4e4:      	bl	0xd4e4 <_stogir.floating.operands+0x4c4>
		000000000000d4e4:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    d4e8:      	add	x16, sp, #0x30
    d4ec:      	ldr	w0, [x16]
    d4f0:      	lsr	x16, x0, #0
    d4f4:      	cmp	x16, #0x1
    d4f8:      	b.eq	0xd514 <_stogir.floating.operands+0x4f4>
    d4fc:      	b.lo	0xd504 <_stogir.floating.operands+0x4e4>
    d500:      	b	0xd518 <_stogir.floating.operands+0x4f8>
    d504:      	cmp	x16, #0x0
    d508:      	b.eq	0xd510 <_stogir.floating.operands+0x4f0>
    d50c:      	b	0xd518 <_stogir.floating.operands+0x4f8>
    d510:      	b	0xd51c <_stogir.floating.operands+0x4fc>
    d514:      	b	0xd538 <_stogir.floating.operands+0x518>
    d518:      	b	0xd5f8 <_stogir.floating.operands+0x5d8>
    d51c:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d51c:  ARM64_RELOC_PAGE21	l_stogir.477
    d520:      	ldr	x16, [x16]
		000000000000d520:  ARM64_RELOC_PAGEOFF12	l_stogir.477
    d524:      	orr	x0, x16, xzr
    d528:      	mov	x1, #0x16               ; =22
    d52c:      	b	0xd144 <_stogir.floating.operands+0x124>
    d530:      	movz	x15, #0x0, lsl #48
    d534:      	b	0xd160 <_stogir.floating.operands+0x140>
    d538:      	add	x16, sp, #0x30
    d53c:      	ldr	x0, [x16, #0x8]
    d540:      	cmp	x21, #0x0
    d544:      	b.ge	0xd580 <_stogir.floating.operands+0x560>
    d548:      	mov	x1, x22
    d54c:      	mov	x2, x23
    d550:      	mov	x0, #0x1                ; =1
    d554:      	b	0xd564 <_stogir.floating.operands+0x544>
    d558:      	movz	x0, #0x0, lsl #48
    d55c:      	mov	x1, x22
    d560:      	mov	x2, x23
    d564:      	cmp	x0, #0x0
    d568:      	b.eq	0xd13c <_stogir.floating.operands+0x11c>
    d56c:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d56c:  ARM64_RELOC_PAGE21	l_stogir.478
    d570:      	ldr	x16, [x16]
		000000000000d570:  ARM64_RELOC_PAGEOFF12	l_stogir.478
    d574:      	orr	x0, x16, xzr
    d578:      	mov	x1, #0x2d               ; =45
    d57c:      	b	0xd144 <_stogir.floating.operands+0x124>
    d580:      	uxtb	w0, w0
    d584:      	cmp	x0, #0x83
    d588:      	b.ge	0xd5ac <_stogir.floating.operands+0x58c>
    d58c:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d58c:  ARM64_RELOC_PAGE21	l_stogir.479
    d590:      	ldr	x16, [x16]
		000000000000d590:  ARM64_RELOC_PAGEOFF12	l_stogir.479
    d594:      	orr	x1, x16, xzr
    d598:      	add	x1, x0, x1
    d59c:      	ldrb	w1, [x1]
    d5a0:      	b	0xd5b0 <_stogir.floating.operands+0x590>
    d5a4:      	brk	#0
    d5a8:      	b	0xd5a4 <_stogir.floating.operands+0x584>
    d5ac:      	movz	x1, #0x0, lsl #48
    d5b0:      	uxtb	w1, w1
    d5b4:      	and	x1, x1, #0x2
    d5b8:      	uxtb	w1, w1
    d5bc:      	cmp	x1, #0x0
    d5c0:      	cset	w1, eq
    d5c4:      	uxtb	w16, w1
    d5c8:      	cmp	w16, wzr
    d5cc:      	cset	x1, eq
    d5d0:      	cmp	x1, #0x0
    d5d4:      	b.ne	0xd558 <_stogir.floating.operands+0x538>
    d5d8:      	cmp	x0, #0x65
    d5dc:      	b.eq	0xd558 <_stogir.floating.operands+0x538>
    d5e0:      	cmp	x0, #0x66
    d5e4:      	b.eq	0xd558 <_stogir.floating.operands+0x538>
    d5e8:      	mov	x0, #0x1                ; =1
    d5ec:      	b	0xd55c <_stogir.floating.operands+0x53c>
    d5f0:      	brk	#0
    d5f4:      	b	0xd5f0 <_stogir.floating.operands+0x5d0>
    d5f8:      	brk	#0
    d5fc:      	b	0xd5f8 <_stogir.floating.operands+0x5d8>
    d600:      	mov	x24, x8
    d604:      	b	0xd3f8 <_stogir.floating.operands+0x3d8>

000000000000d608 <_stogir.types.signed?>:
    d608:      	sxtw	x0, w0
    d60c:      	cmp	x0, #0x7
    d610:      	b.lt	0xd624 <_stogir.types.signed?+0x1c>
    d614:      	cmp	x0, #0xb
    d618:      	cset	w0, le
    d61c:      	ubfx	x0, x0, #0, #8
    d620:      	b	0xd628 <_stogir.types.signed?+0x20>
    d624:      	movz	x0, #0x0, lsl #48
    d628:      	ret

000000000000d62c <_stogir.integer-binary.logical?>:
    d62c:      	sxtw	x0, w0
    d630:      	cmp	x0, #0x2e
    d634:      	b.ne	0xd650 <_stogir.integer-binary.logical?+0x24>
    d638:      	mov	x0, #0x1                ; =1
    d63c:      	b	0xd64c <_stogir.integer-binary.logical?+0x20>
    d640:      	cmp	x0, #0x30
    d644:      	cset	w0, eq
    d648:      	ubfx	x0, x0, #0, #8
    d64c:      	ret
    d650:      	cmp	x0, #0x2f
    d654:      	b.ne	0xd640 <_stogir.integer-binary.logical?+0x14>
    d658:      	mov	x0, #0x1                ; =1
    d65c:      	b	0xd64c <_stogir.integer-binary.logical?+0x20>

000000000000d660 <_inherent$slice$data__i8>:
    d660:      	ret

000000000000d664 <_inherent$slice$data__u32>:
    d664:      	ret

000000000000d668 <_inherent$coil.arraylist.ArrayList$slice__stogir.node.Node>:
    d668:      	sub	sp, sp, #0x10
    d66c:      	mov	x1, sp
    d670:      	ldr	x2, [x0]
    d674:      	ldr	x0, [x0, #0x8]
    d678:      	str	x2, [x1]
    d67c:      	str	x0, [x1, #0x8]
    d680:      	ldr	x0, [sp]
    d684:      	ldr	x1, [sp, #0x8]
    d688:      	add	sp, sp, #0x10
    d68c:      	ret

000000000000d690 <_inherent$slice$at__stogir.node.Node>:
    d690:      	lsl	x1, x2, #4
    d694:      	add	x0, x1, x0
    d698:      	ret

000000000000d69c <_inherent$slice$new__u8>:
    d69c:      	sub	sp, sp, #0x10
    d6a0:      	mov	x2, sp
    d6a4:      	str	x0, [x2]
    d6a8:      	str	x1, [x2, #0x8]
    d6ac:      	ldr	x0, [sp]
    d6b0:      	ldr	x1, [sp, #0x8]
    d6b4:      	add	sp, sp, #0x10
    d6b8:      	ret

000000000000d6bc <_stogir.vector-lanes.operands>:
    d6bc:      	sub	sp, sp, #0x120
    d6c0:      	str	x29, [sp]
    d6c4:      	str	x30, [sp, #0x8]
    d6c8:      	mov	x29, sp
    d6cc:      	str	x19, [sp, #0xc8]
    d6d0:      	str	x20, [sp, #0xd0]
    d6d4:      	str	x21, [sp, #0xd8]
    d6d8:      	str	x22, [sp, #0xe0]
    d6dc:      	str	x23, [sp, #0xe8]
    d6e0:      	str	x24, [sp, #0xf0]
    d6e4:      	str	x25, [sp, #0xf8]
    d6e8:      	str	x26, [sp, #0x100]
    d6ec:      	str	x27, [sp, #0x108]
    d6f0:      	str	x28, [sp, #0x110]
    d6f4:      	sxtw	x4, w4
    d6f8:      	cmp	x4, #0x0
    d6fc:      	cset	w7, gt
    d700:      	movz	x16, #0x0, lsl #48
    d704:      	sub	x9, x16, x4
    d708:      	sub	x10, x9, #0x1
    d70c:      	uxtb	w16, w7
    d710:      	cmp	w16, wzr
    d714:      	b.eq	0xd758 <_stogir.vector-lanes.operands+0x9c>
    d718:      	ldr	x9, [x0, #0x8]
    d71c:      	cmp	x4, x9
    d720:      	b.ge	0xd80c <_stogir.vector-lanes.operands+0x150>
    d724:      	add	x9, x0, #0x78
    d728:      	ldr	x9, [x9, #0x8]
    d72c:      	cmp	x4, x9
    d730:      	b.ge	0xd91c <_stogir.vector-lanes.operands+0x260>
    d734:      	lsl	x9, x4, #2
    d738:      	ldr	x11, [x0, #0x78]
    d73c:      	add	x9, x9, x11
    d740:      	ldr	w9, [x9]
    d744:      	sxtw	x9, w9
    d748:      	cmp	x9, #0x0
    d74c:      	cset	w9, ge
    d750:      	ubfx	x9, x9, #0, #8
    d754:      	b	0xd920 <_stogir.vector-lanes.operands+0x264>
    d758:      	cmp	x4, #0x0
    d75c:      	b.ge	0xd814 <_stogir.vector-lanes.operands+0x158>
    d760:      	add	x11, x0, #0x28
    d764:      	add	x12, x0, #0x50
    d768:      	ldr	x11, [x11, #0x8]
    d76c:      	ldr	x12, [x12, #0x8]
    d770:      	cmp	x11, x12
    d774:      	b.ne	0xd7a4 <_stogir.vector-lanes.operands+0xe8>
    d778:      	cmp	x9, x11
    d77c:      	b.gt	0xda98 <_stogir.vector-lanes.operands+0x3dc>
    d780:      	lsl	x9, x10, #2
    d784:      	ldr	x11, [x0, #0x50]
    d788:      	add	x9, x9, x11
    d78c:      	ldr	w9, [x9]
    d790:      	sxtw	x9, w9
    d794:      	cmp	x9, #0x0
    d798:      	cset	w9, gt
    d79c:      	ubfx	x9, x9, #0, #8
    d7a0:      	b	0xda9c <_stogir.vector-lanes.operands+0x3e0>
    d7a4:      	movz	x9, #0x0, lsl #48
    d7a8:      	b	0xd818 <_stogir.vector-lanes.operands+0x15c>
    d7ac:      	mov	x0, x1
    d7b0:      	mov	x1, x23
    d7b4:      	str	x21, [sp, #0x98]
    d7b8:      	str	x19, [sp, #0xa0]
    d7bc:      	str	x22, [sp, #0x88]
    d7c0:      	mov	x19, x0
    d7c4:      	mov	x20, x1
    d7c8:      	cmp	x20, #0x0
    d7cc:      	b.ne	0xd7fc <_stogir.vector-lanes.operands+0x140>
    d7d0:      	cmp	x20, #0x0
    d7d4:      	b.eq	0xdaa0 <_stogir.vector-lanes.operands+0x3e4>
    d7d8:      	lsr	x0, x20, #0
    d7dc:      	ldr	x1, [sp, #0x88]
    d7e0:      	mov	x2, x0
    d7e4:      	mov	x0, x19
    d7e8:      	bl	0xd7e8 <_stogir.vector-lanes.operands+0x12c>
		000000000000d7e8:  ARM64_RELOC_BRANCH26	_memcmp
    d7ec:      	lsr	w0, w0, #0
    d7f0:      	sxtw	x0, w0
    d7f4:      	cmp	x0, #0x0
    d7f8:      	b.eq	0xdaa0 <_stogir.vector-lanes.operands+0x3e4>
    d7fc:      	mov	x1, x19
    d800:      	mov	x2, x20
    d804:      	mov	x0, #0x1                ; =1
    d808:      	b	0xd8b0 <_stogir.vector-lanes.operands+0x1f4>
    d80c:      	movz	x9, #0x0, lsl #48
    d810:      	b	0xd818 <_stogir.vector-lanes.operands+0x15c>
    d814:      	movz	x9, #0x0, lsl #48
    d818:      	cmp	x9, #0x0
    d81c:      	b.eq	0xd85c <_stogir.vector-lanes.operands+0x1a0>
    d820:      	uxtb	w16, w7
    d824:      	cmp	w16, wzr
    d828:      	b.eq	0xd840 <_stogir.vector-lanes.operands+0x184>
    d82c:      	lsl	x4, x4, #4
    d830:      	ldr	x7, [x0]
    d834:      	add	x4, x4, x7
    d838:      	ldr	x4, [x4]
    d83c:      	b	0xd850 <_stogir.vector-lanes.operands+0x194>
    d840:      	lsl	x4, x10, #4
    d844:      	ldr	x7, [x0, #0x28]
    d848:      	add	x4, x4, x7
    d84c:      	ldr	x4, [x4]
    d850:      	mov	x7, x4
    d854:      	mov	x4, #0x1                ; =1
    d858:      	b	0xd864 <_stogir.vector-lanes.operands+0x1a8>
    d85c:      	movz	x4, #0x0, lsl #48
    d860:      	movz	x7, #0x0, lsl #48
    d864:      	lsr	w4, w4, #0
    d868:      	lsr	x16, x4, #0
    d86c:      	cmp	x16, #0x1
    d870:      	b.eq	0xd88c <_stogir.vector-lanes.operands+0x1d0>
    d874:      	b.lo	0xd87c <_stogir.vector-lanes.operands+0x1c0>
    d878:      	b	0xd890 <_stogir.vector-lanes.operands+0x1d4>
    d87c:      	cmp	x16, #0x0
    d880:      	b.eq	0xd888 <_stogir.vector-lanes.operands+0x1cc>
    d884:      	b	0xd890 <_stogir.vector-lanes.operands+0x1d4>
    d888:      	b	0xd894 <_stogir.vector-lanes.operands+0x1d8>
    d88c:      	b	0xd8f8 <_stogir.vector-lanes.operands+0x23c>
    d890:      	b	0xdec4 <_stogir.vector-lanes.operands+0x808>
    d894:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d894:  ARM64_RELOC_PAGE21	l_stogir.480
    d898:      	ldr	x16, [x16]
		000000000000d898:  ARM64_RELOC_PAGEOFF12	l_stogir.480
    d89c:      	orr	x0, x16, xzr
    d8a0:      	str	x8, [sp, #0xa0]
    d8a4:      	mov	x1, x0
    d8a8:      	mov	x0, #0x1                ; =1
    d8ac:      	mov	x2, #0x1b               ; =27
    d8b0:      	ldr	x3, [sp, #0xa0]
    d8b4:      	str	x0, [x3]
    d8b8:      	str	x1, [x3, #0x8]
    d8bc:      	str	x2, [x3, #0x10]
    d8c0:      	ldr	x19, [sp, #0xc8]
    d8c4:      	ldr	x20, [sp, #0xd0]
    d8c8:      	ldr	x21, [sp, #0xd8]
    d8cc:      	ldr	x22, [sp, #0xe0]
    d8d0:      	ldr	x23, [sp, #0xe8]
    d8d4:      	ldr	x24, [sp, #0xf0]
    d8d8:      	ldr	x25, [sp, #0xf8]
    d8dc:      	ldr	x26, [sp, #0x100]
    d8e0:      	ldr	x27, [sp, #0x108]
    d8e4:      	ldr	x28, [sp, #0x110]
    d8e8:      	ldr	x29, [sp]
    d8ec:      	ldr	x30, [sp, #0x8]
    d8f0:      	add	sp, sp, #0x120
    d8f4:      	ret
    d8f8:      	sxtw	x19, w1
    d8fc:      	sxtw	x1, w2
    d900:      	lsr	w4, w7, #0
    d904:      	ubfx	x4, x4, #8, #8
    d908:      	orr	x20, x4, xzr
    d90c:      	cmp	x19, #0x3d
    d910:      	b.ne	0xd924 <_stogir.vector-lanes.operands+0x268>
    d914:      	mov	x21, x20
    d918:      	b	0xd928 <_stogir.vector-lanes.operands+0x26c>
    d91c:      	movz	x9, #0x0, lsl #48
    d920:      	b	0xd810 <_stogir.vector-lanes.operands+0x154>
    d924:      	mov	x21, x1
    d928:      	cmp	x19, #0x3d
    d92c:      	b.eq	0xd934 <_stogir.vector-lanes.operands+0x278>
    d930:      	mov	x1, x20
    d934:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d934:  ARM64_RELOC_PAGE21	l_stogir.481
    d938:      	ldr	x16, [x16]
		000000000000d938:  ARM64_RELOC_PAGEOFF12	l_stogir.481
    d93c:      	orr	x22, x16, xzr
    d940:      	lsr	w23, w21, #0
    d944:      	sxtw	x24, w23
    d948:      	cmp	x24, #0xf
    d94c:      	cset	w25, gt
    d950:      	cmp	x24, #0x80
    d954:      	cset	w26, lt
    d958:      	and	x4, x24, #0xf
    d95c:      	lsr	w4, w4, #0
    d960:      	sxtw	x4, w4
    d964:      	cmp	x4, #0x1
    d968:      	cset	w27, ge
    d96c:      	cmp	x4, #0xd
    d970:      	cset	w28, le
    d974:      	cmp	x19, #0x3d
    d978:      	b.lt	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d97c:      	cmp	x19, #0x3f
    d980:      	b.gt	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d984:      	uxtb	w16, w25
    d988:      	cmp	w16, wzr
    d98c:      	b.eq	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d990:      	uxtb	w16, w26
    d994:      	cmp	w16, wzr
    d998:      	b.eq	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d99c:      	uxtb	w16, w27
    d9a0:      	cmp	w16, wzr
    d9a4:      	b.eq	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d9a8:      	uxtb	w16, w28
    d9ac:      	cmp	w16, wzr
    d9b0:      	b.eq	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    d9b4:      	sxtw	x4, w3
    d9b8:      	cmp	x4, #0x4
    d9bc:      	b.eq	0xdfc4 <_stogir.vector-lanes.operands+0x908>
    d9c0:      	cmp	x4, #0x8
    d9c4:      	b.eq	0xdfc4 <_stogir.vector-lanes.operands+0x908>
    d9c8:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000d9c8:  ARM64_RELOC_PAGE21	l_stogir.482
    d9cc:      	ldr	x16, [x16]
		000000000000d9cc:  ARM64_RELOC_PAGEOFF12	l_stogir.482
    d9d0:      	orr	x4, x16, xzr
    d9d4:      	mov	x7, #0x36               ; =54
    d9d8:      	sxtw	x9, w5
    d9dc:      	sxtw	x10, w6
    d9e0:      	cmp	x10, #0x0
    d9e4:      	cset	w10, eq
    d9e8:      	cmp	x19, #0x3f
    d9ec:      	b.ne	0xe010 <_stogir.vector-lanes.operands+0x954>
    d9f0:      	lsr	w1, w1, #0
    d9f4:      	lsr	w3, w3, #0
    d9f8:      	mov	w0, w23
    d9fc:      	mov	w2, w3
    da00:      	mov	x19, x8
    da04:      	mov	x20, x4
    da08:      	mov	x23, x7
    da0c:      	mov	x24, x9
    da10:      	mov	w25, w10
    da14:      	bl	0xda14 <_stogir.vector-lanes.operands+0x358>
		000000000000da14:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    da18:      	cmp	x0, #0x0
    da1c:      	b.eq	0xdb0c <_stogir.vector-lanes.operands+0x450>
    da20:      	mov	x1, x20
    da24:      	movz	x0, #0x0, lsl #48
    da28:      	b	0xdb14 <_stogir.vector-lanes.operands+0x458>
    da2c:      	cmp	x19, #0x3d
    da30:      	b.ne	0xe020 <_stogir.vector-lanes.operands+0x964>
    da34:      	lsr	w2, w2, #0
    da38:      	lsr	w3, w3, #0
    da3c:      	str	x0, [sp, #0x80]
    da40:      	mov	w0, w23
    da44:      	str	w3, [sp, #0xb8]
    da48:      	str	x1, [sp, #0xa0]
    da4c:      	mov	w1, w2
    da50:      	mov	w2, w3
    da54:      	str	x4, [sp, #0xa8]
    da58:      	str	x7, [sp, #0xb0]
    da5c:      	str	w9, [sp, #0xc0]
    da60:      	str	x22, [sp, #0x88]
    da64:      	mov	x22, x8
    da68:      	str	w23, [sp, #0x90]
    da6c:      	mov	w23, w5
    da70:      	str	x21, [sp, #0x98]
    da74:      	mov	w21, w6
    da78:      	bl	0xda78 <_stogir.vector-lanes.operands+0x3bc>
		000000000000da78:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    da7c:      	cmp	x0, #0x0
    da80:      	b.ne	0xdb24 <_stogir.vector-lanes.operands+0x468>
    da84:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000da84:  ARM64_RELOC_PAGE21	l_stogir.483
    da88:      	ldr	x16, [x16]
		000000000000da88:  ARM64_RELOC_PAGEOFF12	l_stogir.483
    da8c:      	orr	x0, x16, xzr
    da90:      	mov	x1, #0x26               ; =38
    da94:      	b	0xdb2c <_stogir.vector-lanes.operands+0x470>
    da98:      	movz	x9, #0x0, lsl #48
    da9c:      	b	0xd7a8 <_stogir.vector-lanes.operands+0xec>
    daa0:      	ldr	x0, [sp, #0x98]
    daa4:      	and	x0, x0, #0xffffffff
    daa8:      	mov	x1, x0
    daac:      	movz	x0, #0x0, lsl #48
    dab0:      	movz	x2, #0x0, lsl #48
    dab4:      	b	0xd808 <_stogir.vector-lanes.operands+0x14c>
    dab8:      	ldr	w0, [sp, #0xc0]
    dabc:      	uxtb	w16, w0
    dac0:      	cmp	w16, wzr
    dac4:      	b.eq	0xddc8 <_stogir.vector-lanes.operands+0x70c>
    dac8:      	mov	x0, x20
    dacc:      	mov	x1, x22
    dad0:      	mov	x19, x0
    dad4:      	mov	x20, x1
    dad8:      	b	0xd7c8 <_stogir.vector-lanes.operands+0x10c>
    dadc:      	cmp	x24, #0x0
    dae0:      	b.ne	0xdcb8 <_stogir.vector-lanes.operands+0x5fc>
    dae4:      	uxtb	w16, w25
    dae8:      	cmp	w16, wzr
    daec:      	cset	x0, eq
    daf0:      	cmp	x0, #0x0
    daf4:      	b.eq	0xd7ac <_stogir.vector-lanes.operands+0xf0>
    daf8:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000daf8:  ARM64_RELOC_PAGE21	l_stogir.484
    dafc:      	ldr	x16, [x16]
		000000000000dafc:  ARM64_RELOC_PAGEOFF12	l_stogir.484
    db00:      	orr	x0, x16, xzr
    db04:      	mov	x1, #0x24               ; =36
    db08:      	b	0xd7b4 <_stogir.vector-lanes.operands+0xf8>
    db0c:      	mov	x1, x20
    db10:      	mov	x0, #0x1                ; =1
    db14:      	cmp	x0, #0x0
    db18:      	b.eq	0xdadc <_stogir.vector-lanes.operands+0x420>
    db1c:      	mov	x0, #0x1                ; =1
    db20:      	b	0xdaf0 <_stogir.vector-lanes.operands+0x434>
    db24:      	ldr	x0, [sp, #0xa8]
    db28:      	ldr	x1, [sp, #0xb0]
    db2c:      	cmp	x19, #0x3e
    db30:      	b.ne	0xdb60 <_stogir.vector-lanes.operands+0x4a4>
    db34:      	cmp	x20, x24
    db38:      	b.ne	0xdb48 <_stogir.vector-lanes.operands+0x48c>
    db3c:      	mov	x2, x0
    db40:      	movz	x0, #0x0, lsl #48
    db44:      	b	0xdb50 <_stogir.vector-lanes.operands+0x494>
    db48:      	mov	x2, x0
    db4c:      	mov	x0, #0x1                ; =1
    db50:      	fmov	d31, x1
    db54:      	mov	x1, x2
    db58:      	fmov	x2, d31
    db5c:      	b	0xdb6c <_stogir.vector-lanes.operands+0x4b0>
    db60:      	mov	x2, x1
    db64:      	mov	x1, x0
    db68:      	movz	x0, #0x0, lsl #48
    db6c:      	cmp	x0, #0x0
    db70:      	b.eq	0xdb8c <_stogir.vector-lanes.operands+0x4d0>
    db74:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000db74:  ARM64_RELOC_PAGE21	l_stogir.485
    db78:      	ldr	x16, [x16]
		000000000000db78:  ARM64_RELOC_PAGEOFF12	l_stogir.485
    db7c:      	orr	x0, x16, xzr
    db80:      	mov	x20, x0
    db84:      	mov	x0, #0x27               ; =39
    db88:      	b	0xdb94 <_stogir.vector-lanes.operands+0x4d8>
    db8c:      	mov	x20, x1
    db90:      	mov	x0, x2
    db94:      	lsr	w23, w23, #0
    db98:      	add	x8, sp, #0x10
    db9c:      	mov	w1, w23
    dba0:      	mov	x23, x0
    dba4:      	ldr	x0, [sp, #0x80]
    dba8:      	bl	0xdba8 <_stogir.vector-lanes.operands+0x4ec>
		000000000000dba8:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    dbac:      	add	x16, sp, #0x10
    dbb0:      	ldr	w0, [x16]
    dbb4:      	lsr	x16, x0, #0
    dbb8:      	cmp	x16, #0x1
    dbbc:      	b.eq	0xdbd8 <_stogir.vector-lanes.operands+0x51c>
    dbc0:      	b.lo	0xdbc8 <_stogir.vector-lanes.operands+0x50c>
    dbc4:      	b	0xdbdc <_stogir.vector-lanes.operands+0x520>
    dbc8:      	cmp	x16, #0x0
    dbcc:      	b.eq	0xdbd4 <_stogir.vector-lanes.operands+0x518>
    dbd0:      	b	0xdbdc <_stogir.vector-lanes.operands+0x520>
    dbd4:      	b	0xdbe0 <_stogir.vector-lanes.operands+0x524>
    dbd8:      	b	0xdc58 <_stogir.vector-lanes.operands+0x59c>
    dbdc:      	b	0xe000 <_stogir.vector-lanes.operands+0x944>
    dbe0:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000dbe0:  ARM64_RELOC_PAGE21	l_stogir.486
    dbe4:      	ldr	x16, [x16]
		000000000000dbe4:  ARM64_RELOC_PAGEOFF12	l_stogir.486
    dbe8:      	orr	x0, x16, xzr
    dbec:      	mov	x20, x0
    dbf0:      	mov	x22, #0x19              ; =25
    dbf4:      	cmp	x19, #0x3e
    dbf8:      	b.ne	0xdab8 <_stogir.vector-lanes.operands+0x3fc>
    dbfc:      	lsr	w21, w21, #0
    dc00:      	add	x8, sp, #0x50
    dc04:      	ldr	x0, [sp, #0x80]
    dc08:      	mov	w1, w21
    dc0c:      	bl	0xdc0c <_stogir.vector-lanes.operands+0x550>
		000000000000dc0c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    dc10:      	add	x16, sp, #0x50
    dc14:      	ldr	w0, [x16]
    dc18:      	lsr	x16, x0, #0
    dc1c:      	cmp	x16, #0x1
    dc20:      	b.eq	0xdc3c <_stogir.vector-lanes.operands+0x580>
    dc24:      	b.lo	0xdc2c <_stogir.vector-lanes.operands+0x570>
    dc28:      	b	0xdc40 <_stogir.vector-lanes.operands+0x584>
    dc2c:      	cmp	x16, #0x0
    dc30:      	b.eq	0xdc38 <_stogir.vector-lanes.operands+0x57c>
    dc34:      	b	0xdc40 <_stogir.vector-lanes.operands+0x584>
    dc38:      	b	0xdc44 <_stogir.vector-lanes.operands+0x588>
    dc3c:      	b	0xdddc <_stogir.vector-lanes.operands+0x720>
    dc40:      	b	0xe008 <_stogir.vector-lanes.operands+0x94c>
    dc44:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000dc44:  ARM64_RELOC_PAGE21	l_stogir.487
    dc48:      	ldr	x16, [x16]
		000000000000dc48:  ARM64_RELOC_PAGEOFF12	l_stogir.487
    dc4c:      	orr	x0, x16, xzr
    dc50:      	mov	x1, #0x20               ; =32
    dc54:      	b	0xdcc8 <_stogir.vector-lanes.operands+0x60c>
    dc58:      	add	x16, sp, #0x10
    dc5c:      	orr	x0, x16, xzr
    dc60:      	add	x0, x0, #0x8
    dc64:      	add	x16, sp, #0x10
    dc68:      	ldr	x1, [x16, #0x8]
    dc6c:      	add	x16, sp, #0x40
    dc70:      	str	x1, [x16]
    dc74:      	lsr	w1, w1, #0
    dc78:      	ldr	x0, [x0, #0x8]
    dc7c:      	add	x16, sp, #0x40
    dc80:      	str	x0, [x16, #0x8]
    dc84:      	ubfx	x0, x1, #8, #8
    dc88:      	cmp	x0, #0x1
    dc8c:      	b.lt	0xdccc <_stogir.vector-lanes.operands+0x610>
    dc90:      	cmp	x0, #0xb
    dc94:      	cset	w0, le
    dc98:      	ubfx	x0, x0, #0, #8
    dc9c:      	mov	x1, x20
    dca0:      	b	0xdcd4 <_stogir.vector-lanes.operands+0x618>
    dca4:      	mov	x0, x1
    dca8:      	mov	x1, x2
    dcac:      	mov	x20, x0
    dcb0:      	mov	x22, x1
    dcb4:      	b	0xdbf4 <_stogir.vector-lanes.operands+0x538>
    dcb8:      	mov	x0, #0x1                ; =1
    dcbc:      	b	0xdaf0 <_stogir.vector-lanes.operands+0x434>
    dcc0:      	mov	x0, x1
    dcc4:      	mov	x1, x22
    dcc8:      	b	0xdad0 <_stogir.vector-lanes.operands+0x414>
    dccc:      	mov	x1, x20
    dcd0:      	movz	x0, #0x0, lsl #48
    dcd4:      	cmp	x0, #0x0
    dcd8:      	b.eq	0xdce4 <_stogir.vector-lanes.operands+0x628>
    dcdc:      	movz	x0, #0x0, lsl #48
    dce0:      	b	0xdce8 <_stogir.vector-lanes.operands+0x62c>
    dce4:      	mov	x0, #0x1                ; =1
    dce8:      	cmp	x0, #0x0
    dcec:      	b.eq	0xdd98 <_stogir.vector-lanes.operands+0x6dc>
    dcf0:      	mov	x0, #0x1                ; =1
    dcf4:      	b	0xdd20 <_stogir.vector-lanes.operands+0x664>
    dcf8:      	cmp	x0, #0x46
    dcfc:      	cset	w0, eq
    dd00:      	uxtb	w16, w0
    dd04:      	cmp	w16, wzr
    dd08:      	cset	x0, eq
    dd0c:      	cmp	x0, #0x0
    dd10:      	cset	w0, ne
    dd14:      	uxtb	w16, w0
    dd18:      	cmp	w16, wzr
    dd1c:      	cset	x0, eq
    dd20:      	cmp	x0, #0x0
    dd24:      	b.eq	0xdd3c <_stogir.vector-lanes.operands+0x680>
    dd28:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000dd28:  ARM64_RELOC_PAGE21	l_stogir.488
    dd2c:      	ldr	x16, [x16]
		000000000000dd2c:  ARM64_RELOC_PAGEOFF12	l_stogir.488
    dd30:      	orr	x0, x16, xzr
    dd34:      	mov	x1, #0x2b               ; =43
    dd38:      	b	0xdd44 <_stogir.vector-lanes.operands+0x688>
    dd3c:      	mov	x0, x1
    dd40:      	mov	x1, x23
    dd44:      	cmp	x22, #0x0
    dd48:      	b.ge	0xdd70 <_stogir.vector-lanes.operands+0x6b4>
    dd4c:      	add	x16, sp, #0x40
    dd50:      	ldr	w2, [x16]
    dd54:      	uxtb	w3, w2
    dd58:      	ubfx	x2, x2, #8, #8
    dd5c:      	cmp	x3, x2
    dd60:      	b.ne	0xddfc <_stogir.vector-lanes.operands+0x740>
    dd64:      	mov	x2, x0
    dd68:      	mov	x0, #0x1                ; =1
    dd6c:      	b	0xde14 <_stogir.vector-lanes.operands+0x758>
    dd70:      	mov	x2, x1
    dd74:      	mov	x1, x0
    dd78:      	movz	x0, #0x0, lsl #48
    dd7c:      	cmp	x0, #0x0
    dd80:      	b.eq	0xdca4 <_stogir.vector-lanes.operands+0x5e8>
    dd84:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000dd84:  ARM64_RELOC_PAGE21	l_stogir.489
    dd88:      	ldr	x16, [x16]
		000000000000dd88:  ARM64_RELOC_PAGEOFF12	l_stogir.489
    dd8c:      	orr	x0, x16, xzr
    dd90:      	mov	x1, #0x28               ; =40
    dd94:      	b	0xdcac <_stogir.vector-lanes.operands+0x5f0>
    dd98:      	add	x16, sp, #0x40
    dd9c:      	ldr	w0, [x16]
    dda0:      	uxtb	w0, w0
    dda4:      	cmp	x0, #0x48
    dda8:      	b.ne	0xdcf8 <_stogir.vector-lanes.operands+0x63c>
    ddac:      	movz	x0, #0x0, lsl #48
    ddb0:      	b	0xdd0c <_stogir.vector-lanes.operands+0x650>
    ddb4:      	fmov	d31, x1
    ddb8:      	mov	x1, x2
    ddbc:      	fmov	x2, d31
    ddc0:      	movz	x0, #0x0, lsl #48
    ddc4:      	b	0xdd7c <_stogir.vector-lanes.operands+0x6c0>
    ddc8:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000ddc8:  ARM64_RELOC_PAGE21	l_stogir.490
    ddcc:      	ldr	x16, [x16]
		000000000000ddcc:  ARM64_RELOC_PAGEOFF12	l_stogir.490
    ddd0:      	orr	x0, x16, xzr
    ddd4:      	mov	x1, #0x20               ; =32
    ddd8:      	b	0xdad0 <_stogir.vector-lanes.operands+0x414>
    dddc:      	add	x16, sp, #0x50
    dde0:      	ldr	x0, [x16, #0x8]
    dde4:      	uxtb	w1, w0
    dde8:      	cmp	x1, #0x48
    ddec:      	b.ne	0xdf40 <_stogir.vector-lanes.operands+0x884>
    ddf0:      	mov	x2, x20
    ddf4:      	movz	x1, #0x0, lsl #48
    ddf8:      	b	0xdf58 <_stogir.vector-lanes.operands+0x89c>
    ddfc:      	cmp	x3, #0x49
    de00:      	cset	w2, eq
    de04:      	ubfx	x2, x2, #0, #8
    de08:      	fmov	d31, x0
    de0c:      	mov	x0, x2
    de10:      	fmov	x2, d31
    de14:      	cmp	x0, #0x0
    de18:      	b.eq	0xddb4 <_stogir.vector-lanes.operands+0x6f8>
    de1c:      	add	x16, sp, #0x40
    de20:      	ldr	w0, [x16, #0x8]
    de24:      	add	x16, sp, #0x40
    de28:      	ldr	w3, [x16, #0xc]
    de2c:      	uxtb	w16, w25
    de30:      	cmp	w16, wzr
    de34:      	b.eq	0xde60 <_stogir.vector-lanes.operands+0x7a4>
    de38:      	uxtb	w16, w26
    de3c:      	cmp	w16, wzr
    de40:      	b.eq	0xdf94 <_stogir.vector-lanes.operands+0x8d8>
    de44:      	uxtb	w16, w27
    de48:      	cmp	w16, wzr
    de4c:      	b.eq	0xdfa8 <_stogir.vector-lanes.operands+0x8ec>
    de50:      	ubfx	x28, x28, #0, #8
    de54:      	mov	x4, x2
    de58:      	mov	x2, x28
    de5c:      	b	0xdfb0 <_stogir.vector-lanes.operands+0x8f4>
    de60:      	mov	x4, x1
    de64:      	movz	x1, #0x0, lsl #48
    de68:      	cmp	x1, #0x0
    de6c:      	b.eq	0xdf6c <_stogir.vector-lanes.operands+0x8b0>
    de70:      	ubfx	x1, x24, #4, #32
    de74:      	sxtw	x1, w1
    de78:      	sub	x1, x1, #0x1
    de7c:      	lsr	w1, w1, #0
    de80:      	sxtw	x1, w1
    de84:      	mov	x16, #0x1               ; =1
    de88:      	lsl	x1, x16, x1
    de8c:      	lsr	w1, w1, #0
    de90:      	sxtw	x1, w1
    de94:      	ubfx	x0, x0, #0, #32
    de98:      	ubfx	x3, x3, #0, #32
    de9c:      	lsl	x3, x3, #32
    dea0:      	orr	x0, x3, x0
    dea4:      	lsr	w1, w1, #0
    dea8:      	sxtw	x1, w1
    deac:      	cmp	x0, x1
    deb0:      	cset	w0, hs
    deb4:      	ubfx	x0, x0, #0, #8
    deb8:      	mov	x1, x2
    debc:      	mov	x2, x4
    dec0:      	b	0xddc4 <_stogir.vector-lanes.operands+0x708>
    dec4:      	brk	#0
    dec8:      	b	0xdec4 <_stogir.vector-lanes.operands+0x808>
    decc:      	ldr	w1, [sp, #0xb8]
    ded0:      	lsr	w1, w1, #0
    ded4:      	lsr	w0, w0, #0
    ded8:      	ubfx	x0, x0, #8, #8
    dedc:      	lsr	w0, w0, #0
    dee0:      	mov	w2, w1
    dee4:      	mov	w1, w0
    dee8:      	ldr	w0, [sp, #0x90]
    deec:      	bl	0xdeec <_stogir.vector-lanes.operands+0x830>
		000000000000deec:  ARM64_RELOC_BRANCH26	_stogir.vector-lanes.compatible?
    def0:      	cmp	x0, #0x0
    def4:      	cset	w0, ne
    def8:      	uxtb	w16, w0
    defc:      	cmp	w16, wzr
    df00:      	cset	x0, eq
    df04:      	mov	x1, x19
    df08:      	cmp	x0, #0x0
    df0c:      	b.eq	0xdcc0 <_stogir.vector-lanes.operands+0x604>
    df10:      	adrp	x16, 0xd000 <_stogir.floating.comparison?+0x4>
		000000000000df10:  ARM64_RELOC_PAGE21	l_stogir.491
    df14:      	ldr	x16, [x16]
		000000000000df14:  ARM64_RELOC_PAGEOFF12	l_stogir.491
    df18:      	orr	x0, x16, xzr
    df1c:      	mov	x1, #0x27               ; =39
    df20:      	b	0xdcc8 <_stogir.vector-lanes.operands+0x60c>
    df24:      	mov	x19, x2
    df28:      	mov	x1, #0x1                ; =1
    df2c:      	cmp	x1, #0x0
    df30:      	b.eq	0xdecc <_stogir.vector-lanes.operands+0x810>
    df34:      	mov	x1, x19
    df38:      	mov	x0, #0x1                ; =1
    df3c:      	b	0xdf08 <_stogir.vector-lanes.operands+0x84c>
    df40:      	cmp	x1, #0x46
    df44:      	cset	w1, eq
    df48:      	uxtb	w16, w1
    df4c:      	cmp	w16, wzr
    df50:      	cset	x1, eq
    df54:      	mov	x2, x20
    df58:      	cmp	x1, #0x0
    df5c:      	b.eq	0xdf24 <_stogir.vector-lanes.operands+0x868>
    df60:      	mov	x19, x2
    df64:      	movz	x1, #0x0, lsl #48
    df68:      	b	0xdf2c <_stogir.vector-lanes.operands+0x870>
    df6c:      	cmp	x24, #0x0
    df70:      	b.lt	0xdfa0 <_stogir.vector-lanes.operands+0x8e4>
    df74:      	cmp	x24, #0xd
    df78:      	b.gt	0xdfa0 <_stogir.vector-lanes.operands+0x8e4>
    df7c:      	cmp	x24, #0x0
    df80:      	cset	w1, eq
    df84:      	uxtb	w16, w1
    df88:      	cmp	w16, wzr
    df8c:      	cset	x1, eq
    df90:      	b	0xdfa4 <_stogir.vector-lanes.operands+0x8e8>
    df94:      	mov	x4, x1
    df98:      	movz	x1, #0x0, lsl #48
    df9c:      	b	0xde68 <_stogir.vector-lanes.operands+0x7ac>
    dfa0:      	movn	x1, #0x0, lsl #48
    dfa4:      	b	0xde94 <_stogir.vector-lanes.operands+0x7d8>
    dfa8:      	mov	x4, x2
    dfac:      	movz	x2, #0x0, lsl #48
    dfb0:      	fmov	d31, x1
    dfb4:      	mov	x1, x2
    dfb8:      	mov	x2, x4
    dfbc:      	fmov	x4, d31
    dfc0:      	b	0xdf9c <_stogir.vector-lanes.operands+0x8e0>
    dfc4:      	uxtb	w7, w7
    dfc8:      	cmp	x7, #0x48
    dfcc:      	b.ne	0xdfd8 <_stogir.vector-lanes.operands+0x91c>
    dfd0:      	movz	x4, #0x0, lsl #48
    dfd4:      	b	0xdfec <_stogir.vector-lanes.operands+0x930>
    dfd8:      	cmp	x7, #0x46
    dfdc:      	cset	w4, eq
    dfe0:      	uxtb	w16, w4
    dfe4:      	cmp	w16, wzr
    dfe8:      	cset	x4, eq
    dfec:      	cmp	x4, #0x0
    dff0:      	b.eq	0xd9c8 <_stogir.vector-lanes.operands+0x30c>
    dff4:      	mov	x4, x22
    dff8:      	movz	x7, #0x0, lsl #48
    dffc:      	b	0xd9d8 <_stogir.vector-lanes.operands+0x31c>
    e000:      	brk	#0
    e004:      	b	0xe000 <_stogir.vector-lanes.operands+0x944>
    e008:      	brk	#0
    e00c:      	b	0xe008 <_stogir.vector-lanes.operands+0x94c>
    e010:      	mov	x1, x8
    e014:      	mov	x8, x9
    e018:      	mov	w9, w10
    e01c:      	b	0xda2c <_stogir.vector-lanes.operands+0x370>
    e020:      	str	x21, [sp, #0x98]
    e024:      	str	x1, [sp, #0xa0]
    e028:      	str	x0, [sp, #0x80]
    e02c:      	str	w3, [sp, #0xb8]
    e030:      	mov	w21, w6
    e034:      	str	x22, [sp, #0x88]
    e038:      	mov	x22, x8
    e03c:      	str	w23, [sp, #0x90]
    e040:      	mov	w23, w5
    e044:      	str	w9, [sp, #0xc0]
    e048:      	str	x4, [sp, #0xa8]
    e04c:      	str	x7, [sp, #0xb0]
    e050:      	b	0xdb24 <_stogir.vector-lanes.operands+0x468>

000000000000e054 <_stogir.vector-comparison.operation?>:
    e054:      	sxtw	x0, w0
    e058:      	cmp	x0, #0xe
    e05c:      	b.lt	0xe070 <_stogir.vector-comparison.operation?+0x1c>
    e060:      	cmp	x0, #0x19
    e064:      	cset	w0, le
    e068:      	ubfx	x0, x0, #0, #8
    e06c:      	b	0xe074 <_stogir.vector-comparison.operation?+0x20>
    e070:      	movz	x0, #0x0, lsl #48
    e074:      	ret

000000000000e078 <_stogir.vector-comparison.operands>:
    e078:      	sub	sp, sp, #0xe0
    e07c:      	str	x29, [sp]
    e080:      	str	x30, [sp, #0x8]
    e084:      	mov	x29, sp
    e088:      	str	x19, [sp, #0x90]
    e08c:      	str	x20, [sp, #0x98]
    e090:      	str	x21, [sp, #0xa0]
    e094:      	str	x22, [sp, #0xa8]
    e098:      	str	x23, [sp, #0xb0]
    e09c:      	str	x24, [sp, #0xb8]
    e0a0:      	str	x25, [sp, #0xc0]
    e0a4:      	str	x26, [sp, #0xc8]
    e0a8:      	str	x27, [sp, #0xd0]
    e0ac:      	str	x28, [sp, #0xd8]
    e0b0:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e0b0:  ARM64_RELOC_PAGE21	l_stogir.492
    e0b4:      	ldr	x16, [x16]
		000000000000e0b4:  ARM64_RELOC_PAGEOFF12	l_stogir.492
    e0b8:      	orr	x19, x16, xzr
    e0bc:      	lsr	w4, w4, #0
    e0c0:      	mov	x20, x8
    e0c4:      	add	x8, sp, #0x10
    e0c8:      	mov	x21, x0
    e0cc:      	mov	w22, w1
    e0d0:      	mov	w1, w4
    e0d4:      	mov	w23, w2
    e0d8:      	mov	w24, w3
    e0dc:      	mov	w25, w5
    e0e0:      	bl	0xe0e0 <_stogir.vector-comparison.operands+0x68>
		000000000000e0e0:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e0e4:      	add	x16, sp, #0x10
    e0e8:      	ldr	w0, [x16]
    e0ec:      	lsr	x16, x0, #0
    e0f0:      	cmp	x16, #0x1
    e0f4:      	b.eq	0xe110 <_stogir.vector-comparison.operands+0x98>
    e0f8:      	b.lo	0xe100 <_stogir.vector-comparison.operands+0x88>
    e0fc:      	b	0xe114 <_stogir.vector-comparison.operands+0x9c>
    e100:      	cmp	x16, #0x0
    e104:      	b.eq	0xe10c <_stogir.vector-comparison.operands+0x94>
    e108:      	b	0xe114 <_stogir.vector-comparison.operands+0x9c>
    e10c:      	b	0xe118 <_stogir.vector-comparison.operands+0xa0>
    e110:      	b	0xe168 <_stogir.vector-comparison.operands+0xf0>
    e114:      	b	0xe318 <_stogir.vector-comparison.operands+0x2a0>
    e118:      	mov	x1, x19
    e11c:      	mov	x0, #0x1                ; =1
    e120:      	mov	x2, #0x21               ; =33
    e124:      	str	x0, [x20]
    e128:      	str	x1, [x20, #0x8]
    e12c:      	str	x2, [x20, #0x10]
    e130:      	ldr	x19, [sp, #0x90]
    e134:      	ldr	x20, [sp, #0x98]
    e138:      	ldr	x21, [sp, #0xa0]
    e13c:      	ldr	x22, [sp, #0xa8]
    e140:      	ldr	x23, [sp, #0xb0]
    e144:      	ldr	x24, [sp, #0xb8]
    e148:      	ldr	x25, [sp, #0xc0]
    e14c:      	ldr	x26, [sp, #0xc8]
    e150:      	ldr	x27, [sp, #0xd0]
    e154:      	ldr	x28, [sp, #0xd8]
    e158:      	ldr	x29, [sp]
    e15c:      	ldr	x30, [sp, #0x8]
    e160:      	add	sp, sp, #0xe0
    e164:      	ret
    e168:      	lsr	w25, w25, #0
    e16c:      	add	x16, sp, #0x10
    e170:      	ldr	x26, [x16, #0x8]
    e174:      	add	x8, sp, #0x40
    e178:      	mov	x0, x21
    e17c:      	mov	w1, w25
    e180:      	bl	0xe180 <_stogir.vector-comparison.operands+0x108>
		000000000000e180:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    e184:      	add	x16, sp, #0x40
    e188:      	ldr	w0, [x16]
    e18c:      	lsr	x16, x0, #0
    e190:      	cmp	x16, #0x1
    e194:      	b.eq	0xe1b0 <_stogir.vector-comparison.operands+0x138>
    e198:      	b.lo	0xe1a0 <_stogir.vector-comparison.operands+0x128>
    e19c:      	b	0xe1b4 <_stogir.vector-comparison.operands+0x13c>
    e1a0:      	cmp	x16, #0x0
    e1a4:      	b.eq	0xe1ac <_stogir.vector-comparison.operands+0x134>
    e1a8:      	b	0xe1b4 <_stogir.vector-comparison.operands+0x13c>
    e1ac:      	b	0xe1b8 <_stogir.vector-comparison.operands+0x140>
    e1b0:      	b	0xe1c8 <_stogir.vector-comparison.operands+0x150>
    e1b4:      	b	0xe320 <_stogir.vector-comparison.operands+0x2a8>
    e1b8:      	mov	x1, x19
    e1bc:      	mov	x0, #0x1                ; =1
    e1c0:      	mov	x2, #0x21               ; =33
    e1c4:      	b	0xe124 <_stogir.vector-comparison.operands+0xac>
    e1c8:      	sxtw	x19, w24
    e1cc:      	cmp	x19, #0x4
    e1d0:      	cset	w21, eq
    e1d4:      	cmp	x19, #0x8
    e1d8:      	cset	w25, eq
    e1dc:      	add	x16, sp, #0x40
    e1e0:      	ldr	x27, [x16, #0x8]
    e1e4:      	uxtb	w16, w21
    e1e8:      	cmp	w16, wzr
    e1ec:      	b.ne	0xe218 <_stogir.vector-comparison.operands+0x1a0>
    e1f0:      	uxtb	w16, w25
    e1f4:      	cmp	w16, wzr
    e1f8:      	b.ne	0xe218 <_stogir.vector-comparison.operands+0x1a0>
    e1fc:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e1fc:  ARM64_RELOC_PAGE21	l_stogir.493
    e200:      	ldr	x16, [x16]
		000000000000e200:  ARM64_RELOC_PAGEOFF12	l_stogir.493
    e204:      	orr	x0, x16, xzr
    e208:      	mov	x1, x0
    e20c:      	mov	x0, #0x1                ; =1
    e210:      	mov	x2, #0x33               ; =51
    e214:      	b	0xe1c4 <_stogir.vector-comparison.operands+0x14c>
    e218:      	lsr	w22, w22, #0
    e21c:      	lsr	w0, w26, #0
    e220:      	ubfx	x28, x0, #8, #8
    e224:      	orr	x0, x28, xzr
    e228:      	lsr	w0, w0, #0
    e22c:      	mov	w1, w0
    e230:      	fmov	s31, w0
    e234:      	mov	w0, w22
    e238:      	fmov	w22, s31
    e23c:      	bl	0xe23c <_stogir.vector-comparison.operands+0x1c4>
		000000000000e23c:  ARM64_RELOC_BRANCH26	_stogir.vector-comparison.valid-type?
    e240:      	cmp	x0, #0x0
    e244:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e248:      	lsr	w0, w27, #0
    e24c:      	ubfx	x0, x0, #8, #8
    e250:      	cmp	x28, x0
    e254:      	b.ne	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e258:      	uxtb	w26, w26
    e25c:      	cmp	x26, #0x48
    e260:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e264:      	cmp	x26, #0x46
    e268:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e26c:      	uxtb	w27, w27
    e270:      	cmp	x27, #0x48
    e274:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e278:      	cmp	x27, #0x46
    e27c:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e280:      	sxtw	x26, w23
    e284:      	cmp	x26, #0xf
    e288:      	cset	w27, gt
    e28c:      	uxtb	w16, w27
    e290:      	cmp	w16, wzr
    e294:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e298:      	cmp	x26, #0x80
    e29c:      	cset	w0, lt
    e2a0:      	uxtb	w16, w0
    e2a4:      	cmp	w16, wzr
    e2a8:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e2ac:      	and	x1, x26, #0xf
    e2b0:      	lsr	w1, w1, #0
    e2b4:      	sxtw	x1, w1
    e2b8:      	cmp	x1, #0x1
    e2bc:      	cset	w2, ge
    e2c0:      	uxtb	w16, w2
    e2c4:      	cmp	w16, wzr
    e2c8:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e2cc:      	cmp	x1, #0xd
    e2d0:      	cset	w3, le
    e2d4:      	uxtb	w16, w3
    e2d8:      	cmp	w16, wzr
    e2dc:      	b.eq	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e2e0:      	lsr	w23, w23, #0
    e2e4:      	str	x1, [sp, #0x78]
    e2e8:      	str	x19, [sp, #0x70]
    e2ec:      	mov	w19, w0
    e2f0:      	mov	w0, w23
    e2f4:      	str	w22, [sp, #0x80]
    e2f8:      	mov	w22, w2
    e2fc:      	str	w23, [sp, #0x88]
    e300:      	mov	w23, w3
    e304:      	bl	0xe304 <_stogir.vector-comparison.operands+0x28c>
		000000000000e304:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e308:      	cmp	x0, #0x0
    e30c:      	b.eq	0xe328 <_stogir.vector-comparison.operands+0x2b0>
    e310:      	ldr	x0, [sp, #0x78]
    e314:      	b	0xe32c <_stogir.vector-comparison.operands+0x2b4>
    e318:      	brk	#0
    e31c:      	b	0xe318 <_stogir.vector-comparison.operands+0x2a0>
    e320:      	brk	#0
    e324:      	b	0xe320 <_stogir.vector-comparison.operands+0x2a8>
    e328:      	movn	x0, #0x0, lsl #48
    e32c:      	lsr	w0, w0, #0
    e330:      	sxtw	x0, w0
    e334:      	cmp	x0, #0x1
    e338:      	b.lt	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e33c:      	cmp	x0, #0xb
    e340:      	b.gt	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e344:      	uxtb	w16, w27
    e348:      	cmp	w16, wzr
    e34c:      	b.eq	0xe3d0 <_stogir.vector-comparison.operands+0x358>
    e350:      	uxtb	w16, w19
    e354:      	cmp	w16, wzr
    e358:      	b.eq	0xe3d0 <_stogir.vector-comparison.operands+0x358>
    e35c:      	uxtb	w16, w22
    e360:      	cmp	w16, wzr
    e364:      	b.eq	0xe3d0 <_stogir.vector-comparison.operands+0x358>
    e368:      	uxtb	w16, w23
    e36c:      	cmp	w16, wzr
    e370:      	b.eq	0xe3d0 <_stogir.vector-comparison.operands+0x358>
    e374:      	ubfx	x0, x26, #4, #32
    e378:      	sxtw	x0, w0
    e37c:      	sub	x0, x0, #0x1
    e380:      	lsr	w0, w0, #0
    e384:      	sxtw	x0, w0
    e388:      	mov	x16, #0x1               ; =1
    e38c:      	lsl	x0, x16, x0
    e390:      	lsr	w0, w0, #0
    e394:      	sxtw	x0, w0
    e398:      	b	0xe3fc <_stogir.vector-comparison.operands+0x384>
    e39c:      	movn	x1, #0x0, lsl #48
    e3a0:      	lsr	w0, w0, #0
    e3a4:      	sxtw	x0, w0
    e3a8:      	lsr	w1, w1, #0
    e3ac:      	sxtw	x1, w1
    e3b0:      	cmp	x0, x1
    e3b4:      	b.ne	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e3b8:      	ldr	w0, [sp, #0x88]
    e3bc:      	bl	0xe3bc <_stogir.vector-comparison.operands+0x344>
		000000000000e3bc:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e3c0:      	cmp	x0, #0x0
    e3c4:      	b.eq	0xe4b4 <_stogir.vector-comparison.operands+0x43c>
    e3c8:      	ldr	x0, [sp, #0x78]
    e3cc:      	b	0xe4b8 <_stogir.vector-comparison.operands+0x440>
    e3d0:      	cmp	x26, #0x0
    e3d4:      	b.lt	0xe3f8 <_stogir.vector-comparison.operands+0x380>
    e3d8:      	cmp	x26, #0xd
    e3dc:      	b.gt	0xe3f8 <_stogir.vector-comparison.operands+0x380>
    e3e0:      	cmp	x26, #0x0
    e3e4:      	cset	w0, eq
    e3e8:      	uxtb	w16, w0
    e3ec:      	cmp	w16, wzr
    e3f0:      	cset	x0, eq
    e3f4:      	b	0xe3fc <_stogir.vector-comparison.operands+0x384>
    e3f8:      	movn	x0, #0x0, lsl #48
    e3fc:      	and	x1, x28, #0xf
    e400:      	lsr	w1, w1, #0
    e404:      	sxtw	x19, w1
    e408:      	cmp	x28, #0xf
    e40c:      	b.le	0xe450 <_stogir.vector-comparison.operands+0x3d8>
    e410:      	cmp	x28, #0x80
    e414:      	b.ge	0xe450 <_stogir.vector-comparison.operands+0x3d8>
    e418:      	cmp	x19, #0x1
    e41c:      	b.lt	0xe450 <_stogir.vector-comparison.operands+0x3d8>
    e420:      	cmp	x19, #0xd
    e424:      	b.gt	0xe450 <_stogir.vector-comparison.operands+0x3d8>
    e428:      	ubfx	x1, x28, #4, #32
    e42c:      	sxtw	x1, w1
    e430:      	sub	x1, x1, #0x1
    e434:      	lsr	w1, w1, #0
    e438:      	sxtw	x1, w1
    e43c:      	mov	x16, #0x1               ; =1
    e440:      	lsl	x1, x16, x1
    e444:      	lsr	w1, w1, #0
    e448:      	sxtw	x1, w1
    e44c:      	b	0xe3a0 <_stogir.vector-comparison.operands+0x328>
    e450:      	cmp	x28, #0xd
    e454:      	b.gt	0xe39c <_stogir.vector-comparison.operands+0x324>
    e458:      	cmp	x28, #0x0
    e45c:      	cset	w1, eq
    e460:      	uxtb	w16, w1
    e464:      	cmp	w16, wzr
    e468:      	cset	x1, eq
    e46c:      	b	0xe3a0 <_stogir.vector-comparison.operands+0x328>
    e470:      	movn	x0, #0x0, lsl #48
    e474:      	lsr	w24, w24, #0
    e478:      	lsr	w21, w21, #0
    e47c:      	sxtw	x21, w21
    e480:      	lsr	w0, w0, #0
    e484:      	lsr	w0, w0, #0
    e488:      	mov	w1, w24
    e48c:      	bl	0xe48c <_stogir.vector-comparison.operands+0x414>
		000000000000e48c:  ARM64_RELOC_BRANCH26	_stogir.types.scalar-size
    e490:      	lsr	w0, w0, #0
    e494:      	sxtw	x0, w0
    e498:      	cmp	x21, x0
    e49c:      	b.ne	0xe1fc <_stogir.vector-comparison.operands+0x184>
    e4a0:      	and	x0, x28, #0xffffffff
    e4a4:      	mov	x1, x0
    e4a8:      	movz	x0, #0x0, lsl #48
    e4ac:      	movz	x2, #0x0, lsl #48
    e4b0:      	b	0xe214 <_stogir.vector-comparison.operands+0x19c>
    e4b4:      	movn	x0, #0x0, lsl #48
    e4b8:      	uxtb	w16, w21
    e4bc:      	cmp	w16, wzr
    e4c0:      	b.ne	0xe4f8 <_stogir.vector-comparison.operands+0x480>
    e4c4:      	uxtb	w16, w25
    e4c8:      	cmp	w16, wzr
    e4cc:      	b.ne	0xe4f8 <_stogir.vector-comparison.operands+0x480>
    e4d0:      	movn	x21, #0x0, lsl #48
    e4d4:      	b	0xe4e0 <_stogir.vector-comparison.operands+0x468>
    e4d8:      	mov	x0, #0x1                ; =1
    e4dc:      	mov	x21, x0
    e4e0:      	ldr	w0, [sp, #0x80]
    e4e4:      	bl	0xe4e4 <_stogir.vector-comparison.operands+0x46c>
		000000000000e4e4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    e4e8:      	cmp	x0, #0x0
    e4ec:      	b.eq	0xe470 <_stogir.vector-comparison.operands+0x3f8>
    e4f0:      	mov	x0, x19
    e4f4:      	b	0xe474 <_stogir.vector-comparison.operands+0x3fc>
    e4f8:      	lsr	w0, w0, #0
    e4fc:      	sxtw	x0, w0
    e500:      	cmp	x0, #0x0
    e504:      	b.ne	0xe510 <_stogir.vector-comparison.operands+0x498>
    e508:      	movz	x0, #0x0, lsl #48
    e50c:      	b	0xe4dc <_stogir.vector-comparison.operands+0x464>
    e510:      	cmp	x0, #0x1
    e514:      	b.eq	0xe4d8 <_stogir.vector-comparison.operands+0x460>
    e518:      	cmp	x0, #0x2
    e51c:      	b.eq	0xe4d8 <_stogir.vector-comparison.operands+0x460>
    e520:      	cmp	x0, #0x7
    e524:      	b.eq	0xe4d8 <_stogir.vector-comparison.operands+0x460>
    e528:      	cmp	x0, #0x8
    e52c:      	b.eq	0xe4d8 <_stogir.vector-comparison.operands+0x460>
    e530:      	cmp	x0, #0x3
    e534:      	b.eq	0xe580 <_stogir.vector-comparison.operands+0x508>
    e538:      	cmp	x0, #0x9
    e53c:      	b.eq	0xe580 <_stogir.vector-comparison.operands+0x508>
    e540:      	cmp	x0, #0x4
    e544:      	b.eq	0xe588 <_stogir.vector-comparison.operands+0x510>
    e548:      	cmp	x0, #0xa
    e54c:      	b.eq	0xe588 <_stogir.vector-comparison.operands+0x510>
    e550:      	cmp	x0, #0xd
    e554:      	b.eq	0xe588 <_stogir.vector-comparison.operands+0x510>
    e558:      	cmp	x0, #0x5
    e55c:      	b.eq	0xe590 <_stogir.vector-comparison.operands+0x518>
    e560:      	cmp	x0, #0xb
    e564:      	b.eq	0xe590 <_stogir.vector-comparison.operands+0x518>
    e568:      	cmp	x0, #0xc
    e56c:      	b.eq	0xe590 <_stogir.vector-comparison.operands+0x518>
    e570:      	cmp	x0, #0x6
    e574:      	b.ne	0xe598 <_stogir.vector-comparison.operands+0x520>
    e578:      	ldr	x0, [sp, #0x70]
    e57c:      	b	0xe59c <_stogir.vector-comparison.operands+0x524>
    e580:      	mov	x0, #0x2                ; =2
    e584:      	b	0xe4dc <_stogir.vector-comparison.operands+0x464>
    e588:      	mov	x0, #0x4                ; =4
    e58c:      	b	0xe584 <_stogir.vector-comparison.operands+0x50c>
    e590:      	mov	x0, #0x8                ; =8
    e594:      	b	0xe58c <_stogir.vector-comparison.operands+0x514>
    e598:      	movn	x0, #0x0, lsl #48
    e59c:      	b	0xe594 <_stogir.vector-comparison.operands+0x51c>

000000000000e5a0 <_stogir.vector-arithmetic.operation?>:
    e5a0:      	sxtw	x0, w0
    e5a4:      	cmp	x0, #0x1f
    e5a8:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5ac:      	cmp	x0, #0x20
    e5b0:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5b4:      	cmp	x0, #0x2d
    e5b8:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5bc:      	cmp	x0, #0x36
    e5c0:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5c4:      	cmp	x0, #0x37
    e5c8:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5cc:      	cmp	x0, #0x38
    e5d0:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5d4:      	cmp	x0, #0x39
    e5d8:      	b.eq	0xe604 <_stogir.vector-arithmetic.operation?+0x64>
    e5dc:      	cmp	x0, #0x3a
    e5e0:      	b.eq	0xe60c <_stogir.vector-arithmetic.operation?+0x6c>
    e5e4:      	cmp	x0, #0x3b
    e5e8:      	b.eq	0xe60c <_stogir.vector-arithmetic.operation?+0x6c>
    e5ec:      	cmp	x0, #0x31
    e5f0:      	b.lt	0xe624 <_stogir.vector-arithmetic.operation?+0x84>
    e5f4:      	cmp	x0, #0x35
    e5f8:      	b.gt	0xe624 <_stogir.vector-arithmetic.operation?+0x84>
    e5fc:      	mov	x0, #0x1                ; =1
    e600:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e604:      	mov	x0, #0x1                ; =1
    e608:      	ret
    e60c:      	mov	x0, #0x1                ; =1
    e610:      	b	0xe608 <_stogir.vector-arithmetic.operation?+0x68>
    e614:      	cmp	x0, #0x30
    e618:      	cset	w0, eq
    e61c:      	ubfx	x0, x0, #0, #8
    e620:      	b	0xe610 <_stogir.vector-arithmetic.operation?+0x70>
    e624:      	cmp	x0, #0x1a
    e628:      	b.ne	0xe634 <_stogir.vector-arithmetic.operation?+0x94>
    e62c:      	mov	x0, #0x1                ; =1
    e630:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e634:      	cmp	x0, #0x1b
    e638:      	b.ne	0xe644 <_stogir.vector-arithmetic.operation?+0xa4>
    e63c:      	mov	x0, #0x1                ; =1
    e640:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e644:      	cmp	x0, #0x1c
    e648:      	b.ne	0xe654 <_stogir.vector-arithmetic.operation?+0xb4>
    e64c:      	mov	x0, #0x1                ; =1
    e650:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e654:      	cmp	x0, #0x1d
    e658:      	b.ne	0xe664 <_stogir.vector-arithmetic.operation?+0xc4>
    e65c:      	mov	x0, #0x1                ; =1
    e660:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e664:      	cmp	x0, #0x1e
    e668:      	b.ne	0xe674 <_stogir.vector-arithmetic.operation?+0xd4>
    e66c:      	mov	x0, #0x1                ; =1
    e670:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e674:      	cmp	x0, #0x2e
    e678:      	b.ne	0xe684 <_stogir.vector-arithmetic.operation?+0xe4>
    e67c:      	mov	x0, #0x1                ; =1
    e680:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>
    e684:      	cmp	x0, #0x2f
    e688:      	b.ne	0xe614 <_stogir.vector-arithmetic.operation?+0x74>
    e68c:      	mov	x0, #0x1                ; =1
    e690:      	b	0xe620 <_stogir.vector-arithmetic.operation?+0x80>

000000000000e694 <_stogir.vector-arithmetic.unary?>:
    e694:      	sxtw	x0, w0
    e698:      	cmp	x0, #0x1f
    e69c:      	b.ne	0xe6b8 <_stogir.vector-arithmetic.unary?+0x24>
    e6a0:      	mov	x0, #0x1                ; =1
    e6a4:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>
    e6a8:      	cmp	x0, #0x39
    e6ac:      	cset	w0, eq
    e6b0:      	ubfx	x0, x0, #0, #8
    e6b4:      	ret
    e6b8:      	cmp	x0, #0x20
    e6bc:      	b.ne	0xe6c8 <_stogir.vector-arithmetic.unary?+0x34>
    e6c0:      	mov	x0, #0x1                ; =1
    e6c4:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>
    e6c8:      	cmp	x0, #0x2d
    e6cc:      	b.ne	0xe6d8 <_stogir.vector-arithmetic.unary?+0x44>
    e6d0:      	mov	x0, #0x1                ; =1
    e6d4:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>
    e6d8:      	cmp	x0, #0x36
    e6dc:      	b.ne	0xe6e8 <_stogir.vector-arithmetic.unary?+0x54>
    e6e0:      	mov	x0, #0x1                ; =1
    e6e4:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>
    e6e8:      	cmp	x0, #0x37
    e6ec:      	b.ne	0xe6f8 <_stogir.vector-arithmetic.unary?+0x64>
    e6f0:      	mov	x0, #0x1                ; =1
    e6f4:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>
    e6f8:      	cmp	x0, #0x38
    e6fc:      	b.ne	0xe6a8 <_stogir.vector-arithmetic.unary?+0x14>
    e700:      	mov	x0, #0x1                ; =1
    e704:      	b	0xe6b4 <_stogir.vector-arithmetic.unary?+0x20>

000000000000e708 <_stogir.vector-arithmetic.operands>:
    e708:      	sub	sp, sp, #0xc0
    e70c:      	str	x29, [sp]
    e710:      	str	x30, [sp, #0x8]
    e714:      	mov	x29, sp
    e718:      	str	x19, [sp, #0x68]
    e71c:      	str	x20, [sp, #0x70]
    e720:      	str	x21, [sp, #0x78]
    e724:      	str	x22, [sp, #0x80]
    e728:      	str	x23, [sp, #0x88]
    e72c:      	str	x24, [sp, #0x90]
    e730:      	str	x25, [sp, #0x98]
    e734:      	str	x26, [sp, #0xa0]
    e738:      	str	x27, [sp, #0xa8]
    e73c:      	str	x28, [sp, #0xb0]
    e740:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e740:  ARM64_RELOC_PAGE21	l_stogir.494
    e744:      	ldr	x16, [x16]
		000000000000e744:  ARM64_RELOC_PAGEOFF12	l_stogir.494
    e748:      	orr	x19, x16, xzr
    e74c:      	lsr	w1, w1, #0
    e750:      	lsr	w2, w2, #0
    e754:      	mov	x20, x8
    e758:      	mov	x21, x0
    e75c:      	mov	w0, w1
    e760:      	mov	w22, w1
    e764:      	mov	w1, w2
    e768:      	mov	w23, w2
    e76c:      	mov	w24, w3
    e770:      	mov	w25, w4
    e774:      	mov	w26, w5
    e778:      	bl	0xe778 <_stogir.vector-arithmetic.operands+0x70>
		000000000000e778:  ARM64_RELOC_BRANCH26	_stogir.vector-arithmetic.valid-type?
    e77c:      	cmp	x0, #0x0
    e780:      	b.eq	0xe790 <_stogir.vector-arithmetic.operands+0x88>
    e784:      	mov	x0, x19
    e788:      	movz	x1, #0x0, lsl #48
    e78c:      	b	0xe7a0 <_stogir.vector-arithmetic.operands+0x98>
    e790:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e790:  ARM64_RELOC_PAGE21	l_stogir.495
    e794:      	ldr	x16, [x16]
		000000000000e794:  ARM64_RELOC_PAGEOFF12	l_stogir.495
    e798:      	orr	x0, x16, xzr
    e79c:      	mov	x1, #0x37               ; =55
    e7a0:      	sxtw	x22, w22
    e7a4:      	sxtw	x23, w23
    e7a8:      	sxtw	x24, w24
    e7ac:      	sxtw	x25, w25
    e7b0:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e7b0:  ARM64_RELOC_PAGE21	l_stogir.496
    e7b4:      	ldr	x16, [x16]
		000000000000e7b4:  ARM64_RELOC_PAGEOFF12	l_stogir.496
    e7b8:      	orr	x2, x16, xzr
    e7bc:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000e7bc:  ARM64_RELOC_PAGE21	l_stogir.497
    e7c0:      	ldr	x16, [x16]
		000000000000e7c0:  ARM64_RELOC_PAGEOFF12	l_stogir.497
    e7c4:      	orr	x3, x16, xzr
    e7c8:      	add	x4, x21, #0x78
    e7cc:      	add	x5, x21, #0x28
    e7d0:      	add	x6, x21, #0x50
    e7d4:      	cmp	x22, #0x31
    e7d8:      	cset	w7, ge
    e7dc:      	cmp	x22, #0x35
    e7e0:      	cset	w8, le
    e7e4:      	cmp	x22, #0x1f
    e7e8:      	cset	w9, eq
    e7ec:      	cmp	x22, #0x20
    e7f0:      	cset	w10, eq
    e7f4:      	cmp	x22, #0x2d
    e7f8:      	cset	w11, eq
    e7fc:      	cmp	x22, #0x36
    e800:      	cset	w12, eq
    e804:      	cmp	x22, #0x37
    e808:      	cset	w13, eq
    e80c:      	cmp	x22, #0x38
    e810:      	cset	w14, eq
    e814:      	cmp	x22, #0x39
    e818:      	cset	w15, eq
    e81c:      	ubfx	x15, x15, #0, #8
    e820:      	mov	x27, x1
    e824:      	mov	x1, x0
    e828:      	movz	x0, #0x0, lsl #48
    e82c:      	b	0xe90c <_stogir.vector-arithmetic.operands+0x204>
    e830:      	movz	x3, #0x0, lsl #48
    e834:      	b	0xe844 <_stogir.vector-arithmetic.operands+0x13c>
    e838:      	movz	x3, #0x0, lsl #48
    e83c:      	b	0xe84c <_stogir.vector-arithmetic.operands+0x144>
    e840:      	movz	x3, #0x0, lsl #48
    e844:      	b	0xe858 <_stogir.vector-arithmetic.operands+0x150>
    e848:      	movz	x3, #0x0, lsl #48
    e84c:      	str	x5, [sp, #0x60]
    e850:      	b	0xe858 <_stogir.vector-arithmetic.operands+0x150>
    e854:      	movz	x3, #0x0, lsl #48
    e858:      	cmp	x3, #0x0
    e85c:      	b.eq	0xe89c <_stogir.vector-arithmetic.operands+0x194>
    e860:      	uxtb	w16, w2
    e864:      	cmp	w16, wzr
    e868:      	b.eq	0xe880 <_stogir.vector-arithmetic.operands+0x178>
    e86c:      	lsl	x1, x1, #4
    e870:      	ldr	x2, [x21]
    e874:      	add	x1, x1, x2
    e878:      	ldr	x1, [x1]
    e87c:      	b	0xe890 <_stogir.vector-arithmetic.operands+0x188>
    e880:      	lsl	x1, x9, #4
    e884:      	ldr	x2, [x21, #0x28]
    e888:      	add	x1, x1, x2
    e88c:      	ldr	x1, [x1]
    e890:      	mov	x2, x1
    e894:      	mov	x1, #0x1                ; =1
    e898:      	b	0xe8a4 <_stogir.vector-arithmetic.operands+0x19c>
    e89c:      	movz	x1, #0x0, lsl #48
    e8a0:      	movz	x2, #0x0, lsl #48
    e8a4:      	lsr	w1, w1, #0
    e8a8:      	lsr	x16, x1, #0
    e8ac:      	cmp	x16, #0x1
    e8b0:      	b.eq	0xe8cc <_stogir.vector-arithmetic.operands+0x1c4>
    e8b4:      	b.lo	0xe8bc <_stogir.vector-arithmetic.operands+0x1b4>
    e8b8:      	b	0xe8d0 <_stogir.vector-arithmetic.operands+0x1c8>
    e8bc:      	cmp	x16, #0x0
    e8c0:      	b.eq	0xe8c8 <_stogir.vector-arithmetic.operands+0x1c0>
    e8c4:      	b	0xe8d0 <_stogir.vector-arithmetic.operands+0x1c8>
    e8c8:      	b	0xe8d4 <_stogir.vector-arithmetic.operands+0x1cc>
    e8cc:      	b	0xea3c <_stogir.vector-arithmetic.operands+0x334>
    e8d0:      	b	0xec88 <_stogir.vector-arithmetic.operands+0x580>
    e8d4:      	ldr	x1, [sp, #0x40]
    e8d8:      	mov	x2, #0x21               ; =33
    e8dc:      	b	0xe8e8 <_stogir.vector-arithmetic.operands+0x1e0>
    e8e0:      	ldr	x1, [sp, #0x48]
    e8e4:      	mov	x2, #0x32               ; =50
    e8e8:      	add	x0, x0, #0x1
    e8ec:      	lsr	w0, w0, #0
    e8f0:      	sxtw	x0, w0
    e8f4:      	ldr	x3, [sp, #0x48]
    e8f8:      	ldr	w9, [sp, #0x50]
    e8fc:      	ldr	x4, [sp, #0x58]
    e900:      	ldr	x5, [sp, #0x60]
    e904:      	mov	x27, x2
    e908:      	ldr	x2, [sp, #0x40]
    e90c:      	uxtb	w16, w9
    e910:      	cmp	w16, wzr
    e914:      	b.eq	0xe968 <_stogir.vector-arithmetic.operands+0x260>
    e918:      	mov	x28, x27
    e91c:      	mov	x27, x1
    e920:      	mov	x1, #0x1                ; =1
    e924:      	b	0xe93c <_stogir.vector-arithmetic.operands+0x234>
    e928:      	mov	x28, x15
    e92c:      	fmov	d31, x1
    e930:      	mov	x1, x28
    e934:      	mov	x28, x27
    e938:      	fmov	x27, d31
    e93c:      	cmp	x1, #0x0
    e940:      	b.eq	0xe94c <_stogir.vector-arithmetic.operands+0x244>
    e944:      	mov	x1, #0x1                ; =1
    e948:      	b	0xe950 <_stogir.vector-arithmetic.operands+0x248>
    e94c:      	mov	x1, #0x2                ; =2
    e950:      	cmp	x0, x1
    e954:      	b.ge	0xeac4 <_stogir.vector-arithmetic.operands+0x3bc>
    e958:      	cmp	x0, #0x0
    e95c:      	b.ne	0xe97c <_stogir.vector-arithmetic.operands+0x274>
    e960:      	mov	x1, x24
    e964:      	b	0xe980 <_stogir.vector-arithmetic.operands+0x278>
    e968:      	uxtb	w16, w10
    e96c:      	cmp	w16, wzr
    e970:      	b.eq	0xea9c <_stogir.vector-arithmetic.operands+0x394>
    e974:      	mov	x28, #0x1               ; =1
    e978:      	b	0xe92c <_stogir.vector-arithmetic.operands+0x224>
    e97c:      	mov	x1, x25
    e980:      	lsr	w1, w1, #0
    e984:      	sxtw	x1, w1
    e988:      	str	x2, [sp, #0x40]
    e98c:      	cmp	x1, #0x0
    e990:      	cset	w2, gt
    e994:      	str	x3, [sp, #0x48]
    e998:      	movz	x16, #0x0, lsl #48
    e99c:      	sub	x3, x16, x1
    e9a0:      	str	w9, [sp, #0x50]
    e9a4:      	sub	x9, x3, #0x1
    e9a8:      	uxtb	w16, w2
    e9ac:      	cmp	w16, wzr
    e9b0:      	b.eq	0xed48 <_stogir.vector-arithmetic.operands+0x640>
    e9b4:      	ldr	x3, [x21, #0x8]
    e9b8:      	cmp	x1, x3
    e9bc:      	b.ge	0xed50 <_stogir.vector-arithmetic.operands+0x648>
    e9c0:      	ldr	x3, [x4, #0x8]
    e9c4:      	cmp	x1, x3
    e9c8:      	b.ge	0xed58 <_stogir.vector-arithmetic.operands+0x650>
    e9cc:      	lsl	x3, x1, #2
    e9d0:      	str	x4, [sp, #0x58]
    e9d4:      	ldr	x4, [x21, #0x78]
    e9d8:      	add	x3, x3, x4
    e9dc:      	ldr	w3, [x3]
    e9e0:      	sxtw	x3, w3
    e9e4:      	cmp	x3, #0x0
    e9e8:      	cset	w3, ge
    e9ec:      	ubfx	x3, x3, #0, #8
    e9f0:      	b	0xe83c <_stogir.vector-arithmetic.operands+0x134>
    e9f4:      	cmp	x1, #0x0
    e9f8:      	b.ge	0xed60 <_stogir.vector-arithmetic.operands+0x658>
    e9fc:      	ldr	x4, [x5, #0x8]
    ea00:      	str	x5, [sp, #0x60]
    ea04:      	ldr	x5, [x6, #0x8]
    ea08:      	cmp	x4, x5
    ea0c:      	b.ne	0xe840 <_stogir.vector-arithmetic.operands+0x138>
    ea10:      	cmp	x3, x4
    ea14:      	b.gt	0xe830 <_stogir.vector-arithmetic.operands+0x128>
    ea18:      	lsl	x3, x9, #2
    ea1c:      	ldr	x4, [x21, #0x50]
    ea20:      	add	x3, x3, x4
    ea24:      	ldr	w3, [x3]
    ea28:      	sxtw	x3, w3
    ea2c:      	cmp	x3, #0x0
    ea30:      	cset	w3, gt
    ea34:      	ubfx	x3, x3, #0, #8
    ea38:      	b	0xe834 <_stogir.vector-arithmetic.operands+0x12c>
    ea3c:      	lsr	w1, w2, #0
    ea40:      	ubfx	x1, x1, #8, #8
    ea44:      	cmp	x1, x23
    ea48:      	b.eq	0xea7c <_stogir.vector-arithmetic.operands+0x374>
    ea4c:      	cmp	x0, #0x1
    ea50:      	b.ne	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea54:      	uxtb	w16, w7
    ea58:      	cmp	w16, wzr
    ea5c:      	b.eq	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea60:      	uxtb	w16, w8
    ea64:      	cmp	w16, wzr
    ea68:      	b.eq	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea6c:      	cmp	x1, #0x1
    ea70:      	b.lt	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea74:      	cmp	x1, #0xb
    ea78:      	b.gt	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea7c:      	uxtb	w2, w2
    ea80:      	cmp	x2, #0x48
    ea84:      	b.eq	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea88:      	cmp	x2, #0x46
    ea8c:      	b.eq	0xe8e0 <_stogir.vector-arithmetic.operands+0x1d8>
    ea90:      	mov	x1, x27
    ea94:      	mov	x2, x28
    ea98:      	b	0xe8e8 <_stogir.vector-arithmetic.operands+0x1e0>
    ea9c:      	uxtb	w16, w11
    eaa0:      	cmp	w16, wzr
    eaa4:      	b.eq	0xeab0 <_stogir.vector-arithmetic.operands+0x3a8>
    eaa8:      	mov	x28, #0x1               ; =1
    eaac:      	b	0xe92c <_stogir.vector-arithmetic.operands+0x224>
    eab0:      	uxtb	w16, w12
    eab4:      	cmp	w16, wzr
    eab8:      	b.eq	0xeae0 <_stogir.vector-arithmetic.operands+0x3d8>
    eabc:      	mov	x28, #0x1               ; =1
    eac0:      	b	0xe92c <_stogir.vector-arithmetic.operands+0x224>
    eac4:      	sxtw	x24, w26
    eac8:      	cmp	x24, #0x0
    eacc:      	b.ne	0xeaf4 <_stogir.vector-arithmetic.operands+0x3ec>
    ead0:      	mov	x1, x27
    ead4:      	mov	x2, x28
    ead8:      	movz	x0, #0x0, lsl #48
    eadc:      	b	0xeb00 <_stogir.vector-arithmetic.operands+0x3f8>
    eae0:      	uxtb	w16, w13
    eae4:      	cmp	w16, wzr
    eae8:      	b.eq	0xebe8 <_stogir.vector-arithmetic.operands+0x4e0>
    eaec:      	mov	x28, #0x1               ; =1
    eaf0:      	b	0xe92c <_stogir.vector-arithmetic.operands+0x224>
    eaf4:      	mov	x1, x27
    eaf8:      	mov	x2, x28
    eafc:      	mov	x0, #0x1                ; =1
    eb00:      	cmp	x0, #0x0
    eb04:      	b.eq	0xeb18 <_stogir.vector-arithmetic.operands+0x410>
    eb08:      	cmp	x22, #0x1d
    eb0c:      	b.ne	0xec58 <_stogir.vector-arithmetic.operands+0x550>
    eb10:      	mov	x0, #0x1                ; =1
    eb14:      	b	0xec64 <_stogir.vector-arithmetic.operands+0x55c>
    eb18:      	mov	x21, x1
    eb1c:      	mov	x22, x2
    eb20:      	cmp	x22, #0x0
    eb24:      	b.ne	0xeb54 <_stogir.vector-arithmetic.operands+0x44c>
    eb28:      	cmp	x22, #0x0
    eb2c:      	b.eq	0xebd4 <_stogir.vector-arithmetic.operands+0x4cc>
    eb30:      	lsr	x0, x22, #0
    eb34:      	mov	x1, x19
    eb38:      	mov	x2, x0
    eb3c:      	mov	x0, x21
    eb40:      	bl	0xeb40 <_stogir.vector-arithmetic.operands+0x438>
		000000000000eb40:  ARM64_RELOC_BRANCH26	_memcmp
    eb44:      	lsr	w0, w0, #0
    eb48:      	sxtw	x0, w0
    eb4c:      	cmp	x0, #0x0
    eb50:      	b.eq	0xebd4 <_stogir.vector-arithmetic.operands+0x4cc>
    eb54:      	mov	x1, x21
    eb58:      	mov	x2, x22
    eb5c:      	mov	x0, #0x1                ; =1
    eb60:      	str	x0, [x20]
    eb64:      	str	x1, [x20, #0x8]
    eb68:      	str	x2, [x20, #0x10]
    eb6c:      	ldr	x19, [sp, #0x68]
    eb70:      	ldr	x20, [sp, #0x70]
    eb74:      	ldr	x21, [sp, #0x78]
    eb78:      	ldr	x22, [sp, #0x80]
    eb7c:      	ldr	x23, [sp, #0x88]
    eb80:      	ldr	x24, [sp, #0x90]
    eb84:      	ldr	x25, [sp, #0x98]
    eb88:      	ldr	x26, [sp, #0xa0]
    eb8c:      	ldr	x27, [sp, #0xa8]
    eb90:      	ldr	x28, [sp, #0xb0]
    eb94:      	ldr	x29, [sp]
    eb98:      	ldr	x30, [sp, #0x8]
    eb9c:      	add	sp, sp, #0xc0
    eba0:      	ret
    eba4:      	mov	x22, x1
    eba8:      	mov	x25, x2
    ebac:      	mov	x0, #0x1                ; =1
    ebb0:      	cmp	x0, #0x0
    ebb4:      	b.eq	0xebfc <_stogir.vector-arithmetic.operands+0x4f4>
    ebb8:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000ebb8:  ARM64_RELOC_PAGE21	l_stogir.498
    ebbc:      	ldr	x16, [x16]
		000000000000ebbc:  ARM64_RELOC_PAGEOFF12	l_stogir.498
    ebc0:      	orr	x0, x16, xzr
    ebc4:      	mov	x1, #0x23               ; =35
    ebc8:      	mov	x21, x0
    ebcc:      	mov	x22, x1
    ebd0:      	b	0xeb20 <_stogir.vector-arithmetic.operands+0x418>
    ebd4:      	and	x0, x23, #0xffffffff
    ebd8:      	mov	x1, x0
    ebdc:      	movz	x0, #0x0, lsl #48
    ebe0:      	movz	x2, #0x0, lsl #48
    ebe4:      	b	0xeb60 <_stogir.vector-arithmetic.operands+0x458>
    ebe8:      	uxtb	w16, w14
    ebec:      	cmp	w16, wzr
    ebf0:      	b.eq	0xe928 <_stogir.vector-arithmetic.operands+0x220>
    ebf4:      	mov	x28, #0x1               ; =1
    ebf8:      	b	0xe92c <_stogir.vector-arithmetic.operands+0x224>
    ebfc:      	lsr	w26, w26, #0
    ec00:      	add	x8, sp, #0x10
    ec04:      	mov	x0, x21
    ec08:      	mov	w1, w26
    ec0c:      	bl	0xec0c <_stogir.vector-arithmetic.operands+0x504>
		000000000000ec0c:  ARM64_RELOC_BRANCH26	_stogir.graph.lookup
    ec10:      	add	x16, sp, #0x10
    ec14:      	ldr	w0, [x16]
    ec18:      	lsr	x16, x0, #0
    ec1c:      	cmp	x16, #0x1
    ec20:      	b.eq	0xec3c <_stogir.vector-arithmetic.operands+0x534>
    ec24:      	b.lo	0xec2c <_stogir.vector-arithmetic.operands+0x524>
    ec28:      	b	0xec40 <_stogir.vector-arithmetic.operands+0x538>
    ec2c:      	cmp	x16, #0x0
    ec30:      	b.eq	0xec38 <_stogir.vector-arithmetic.operands+0x530>
    ec34:      	b	0xec40 <_stogir.vector-arithmetic.operands+0x538>
    ec38:      	b	0xec44 <_stogir.vector-arithmetic.operands+0x53c>
    ec3c:      	b	0xec90 <_stogir.vector-arithmetic.operands+0x588>
    ec40:      	b	0xed40 <_stogir.vector-arithmetic.operands+0x638>
    ec44:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000ec44:  ARM64_RELOC_PAGE21	l_stogir.499
    ec48:      	ldr	x16, [x16]
		000000000000ec48:  ARM64_RELOC_PAGEOFF12	l_stogir.499
    ec4c:      	orr	x0, x16, xzr
    ec50:      	mov	x1, #0x1d               ; =29
    ec54:      	b	0xec84 <_stogir.vector-arithmetic.operands+0x57c>
    ec58:      	cmp	x22, #0x1e
    ec5c:      	cset	w0, eq
    ec60:      	ubfx	x0, x0, #0, #8
    ec64:      	cmp	x0, #0x0
    ec68:      	b.eq	0xeba4 <_stogir.vector-arithmetic.operands+0x49c>
    ec6c:      	mov	x22, x1
    ec70:      	mov	x25, x2
    ec74:      	movz	x0, #0x0, lsl #48
    ec78:      	b	0xebb0 <_stogir.vector-arithmetic.operands+0x4a8>
    ec7c:      	mov	x0, x1
    ec80:      	mov	x1, x2
    ec84:      	b	0xebc8 <_stogir.vector-arithmetic.operands+0x4c0>
    ec88:      	brk	#0
    ec8c:      	b	0xec88 <_stogir.vector-arithmetic.operands+0x580>
    ec90:      	add	x16, sp, #0x10
    ec94:      	ldr	x0, [x16, #0x8]
    ec98:      	cmp	x24, #0x0
    ec9c:      	b.gt	0xecd8 <_stogir.vector-arithmetic.operands+0x5d0>
    eca0:      	mov	x1, x22
    eca4:      	mov	x2, x25
    eca8:      	mov	x0, #0x1                ; =1
    ecac:      	b	0xecbc <_stogir.vector-arithmetic.operands+0x5b4>
    ecb0:      	movz	x0, #0x0, lsl #48
    ecb4:      	mov	x1, x22
    ecb8:      	mov	x2, x25
    ecbc:      	cmp	x0, #0x0
    ecc0:      	b.eq	0xec7c <_stogir.vector-arithmetic.operands+0x574>
    ecc4:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000ecc4:  ARM64_RELOC_PAGE21	l_stogir.500
    ecc8:      	ldr	x16, [x16]
		000000000000ecc8:  ARM64_RELOC_PAGEOFF12	l_stogir.500
    eccc:      	orr	x0, x16, xzr
    ecd0:      	mov	x1, #0x34               ; =52
    ecd4:      	b	0xec84 <_stogir.vector-arithmetic.operands+0x57c>
    ecd8:      	uxtb	w0, w0
    ecdc:      	cmp	x0, #0x83
    ece0:      	b.ge	0xecfc <_stogir.vector-arithmetic.operands+0x5f4>
    ece4:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000ece4:  ARM64_RELOC_PAGE21	l_stogir.501
    ece8:      	ldr	x16, [x16]
		000000000000ece8:  ARM64_RELOC_PAGEOFF12	l_stogir.501
    ecec:      	orr	x1, x16, xzr
    ecf0:      	add	x1, x0, x1
    ecf4:      	ldrb	w1, [x1]
    ecf8:      	b	0xed00 <_stogir.vector-arithmetic.operands+0x5f8>
    ecfc:      	movz	x1, #0x0, lsl #48
    ed00:      	uxtb	w1, w1
    ed04:      	and	x1, x1, #0x2
    ed08:      	uxtb	w1, w1
    ed0c:      	cmp	x1, #0x0
    ed10:      	cset	w1, eq
    ed14:      	uxtb	w16, w1
    ed18:      	cmp	w16, wzr
    ed1c:      	cset	x1, eq
    ed20:      	cmp	x1, #0x0
    ed24:      	b.ne	0xecb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ed28:      	cmp	x0, #0x65
    ed2c:      	b.eq	0xecb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ed30:      	cmp	x0, #0x66
    ed34:      	b.eq	0xecb0 <_stogir.vector-arithmetic.operands+0x5a8>
    ed38:      	mov	x0, #0x1                ; =1
    ed3c:      	b	0xecb4 <_stogir.vector-arithmetic.operands+0x5ac>
    ed40:      	brk	#0
    ed44:      	b	0xed40 <_stogir.vector-arithmetic.operands+0x638>
    ed48:      	str	x4, [sp, #0x58]
    ed4c:      	b	0xe9f4 <_stogir.vector-arithmetic.operands+0x2ec>
    ed50:      	str	x4, [sp, #0x58]
    ed54:      	b	0xe848 <_stogir.vector-arithmetic.operands+0x140>
    ed58:      	str	x4, [sp, #0x58]
    ed5c:      	b	0xe838 <_stogir.vector-arithmetic.operands+0x130>
    ed60:      	str	x5, [sp, #0x60]
    ed64:      	b	0xe854 <_stogir.vector-arithmetic.operands+0x14c>

000000000000ed68 <_stogir.types.base-type>:
    ed68:      	sub	sp, sp, #0x20
    ed6c:      	str	x29, [sp]
    ed70:      	str	x30, [sp, #0x8]
    ed74:      	mov	x29, sp
    ed78:      	str	x19, [sp, #0x10]
    ed7c:      	lsr	w0, w0, #0
    ed80:      	mov	w19, w0
    ed84:      	bl	0xed84 <_stogir.types.base-type+0x1c>
		000000000000ed84:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
    ed88:      	cmp	x0, #0x0
    ed8c:      	b.eq	0xeda4 <_stogir.types.base-type+0x3c>
    ed90:      	sxtw	x19, w19
    ed94:      	and	x0, x19, #0xf
    ed98:      	lsr	w0, w0, #0
    ed9c:      	sxtw	x0, w0
    eda0:      	b	0xeda8 <_stogir.types.base-type+0x40>
    eda4:      	movn	x0, #0x0, lsl #48
    eda8:      	ldr	x19, [sp, #0x10]
    edac:      	ldr	x29, [sp]
    edb0:      	ldr	x30, [sp, #0x8]
    edb4:      	add	sp, sp, #0x20
    edb8:      	ret

000000000000edbc <_stogir.types.lanes>:
    edbc:      	sxtw	x0, w0
    edc0:      	cmp	x0, #0xf
    edc4:      	b.le	0xee14 <_stogir.types.lanes+0x58>
    edc8:      	cmp	x0, #0x80
    edcc:      	b.ge	0xee14 <_stogir.types.lanes+0x58>
    edd0:      	and	x1, x0, #0xf
    edd4:      	lsr	w1, w1, #0
    edd8:      	sxtw	x1, w1
    eddc:      	cmp	x1, #0x1
    ede0:      	b.lt	0xee14 <_stogir.types.lanes+0x58>
    ede4:      	cmp	x1, #0xd
    ede8:      	b.gt	0xee14 <_stogir.types.lanes+0x58>
    edec:      	ubfx	x0, x0, #4, #32
    edf0:      	sxtw	x0, w0
    edf4:      	sub	x0, x0, #0x1
    edf8:      	lsr	w0, w0, #0
    edfc:      	sxtw	x0, w0
    ee00:      	mov	x16, #0x1               ; =1
    ee04:      	lsl	x0, x16, x0
    ee08:      	lsr	w0, w0, #0
    ee0c:      	sxtw	x0, w0
    ee10:      	b	0xee40 <_stogir.types.lanes+0x84>
    ee14:      	cmp	x0, #0x0
    ee18:      	b.lt	0xee3c <_stogir.types.lanes+0x80>
    ee1c:      	cmp	x0, #0xd
    ee20:      	b.gt	0xee3c <_stogir.types.lanes+0x80>
    ee24:      	cmp	x0, #0x0
    ee28:      	cset	w0, eq
    ee2c:      	uxtb	w16, w0
    ee30:      	cmp	w16, wzr
    ee34:      	cset	x0, eq
    ee38:      	b	0xee40 <_stogir.types.lanes+0x84>
    ee3c:      	movn	x0, #0x0, lsl #48
    ee40:      	ret

000000000000ee44 <_coil.core.Get$slice$get__u8>:
    ee44:      	lsr	x1, x2, #0
    ee48:      	add	x0, x1, x0
    ee4c:      	ldrb	w0, [x0]
    ee50:      	ret

000000000000ee54 <_stogir.checked.valid-type?>:
    ee54:      	sxtw	x0, w0
    ee58:      	cmp	x0, #0x1
    ee5c:      	b.lt	0xee80 <_stogir.checked.valid-type?+0x2c>
    ee60:      	cmp	x0, #0xb
    ee64:      	b.gt	0xee80 <_stogir.checked.valid-type?+0x2c>
    ee68:      	cmp	x0, #0x1
    ee6c:      	cset	w0, eq
    ee70:      	uxtb	w16, w0
    ee74:      	cmp	w16, wzr
    ee78:      	cset	x0, eq
    ee7c:      	b	0xee84 <_stogir.checked.valid-type?+0x30>
    ee80:      	movz	x0, #0x0, lsl #48
    ee84:      	ret

000000000000ee88 <_coil.core.Iterable$slice$iter__i32>:
    ee88:      	str	x0, [x8]
    ee8c:      	str	x1, [x8, #0x8]
    ee90:      	movz	x17, #0x0, lsl #48
    ee94:      	str	x17, [x8, #0x10]
    ee98:      	ret

000000000000ee9c <_coil.core.Iterator$coil.slice.SliceIter$next__i32>:
    ee9c:      	sub	sp, sp, #0x10
    eea0:      	mov	x1, sp
    eea4:      	ldr	x2, [x0, #0x10]
    eea8:      	ldr	x3, [x0]
    eeac:      	ldr	x4, [x0, #0x8]
    eeb0:      	cmp	x2, x4
    eeb4:      	b.ge	0xeee0 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x44>
    eeb8:      	add	x4, x2, #0x1
    eebc:      	lsl	x2, x2, #2
    eec0:      	add	x2, x2, x3
    eec4:      	str	x4, [x0, #0x10]
    eec8:      	ldr	w0, [x2]
    eecc:      	sxtw	x0, w0
    eed0:      	and	x0, x0, #0xffffffff
    eed4:      	mov	x2, x0
    eed8:      	mov	x0, #0x1                ; =1
    eedc:      	b	0xeee8 <_coil.core.Iterator$coil.slice.SliceIter$next__i32+0x4c>
    eee0:      	movz	x0, #0x0, lsl #48
    eee4:      	movz	x2, #0x0, lsl #48
    eee8:      	str	x0, [x1]
    eeec:      	str	x2, [x1, #0x8]
    eef0:      	ldr	x0, [sp]
    eef4:      	ldr	x1, [sp, #0x8]
    eef8:      	add	sp, sp, #0x10
    eefc:      	ret

000000000000ef00 <_stogir.terminal.previous-input>:
    ef00:      	sxtw	x1, w1
    ef04:      	cmp	x1, #0x0
    ef08:      	b.ne	0xef28 <_stogir.terminal.previous-input+0x28>
    ef0c:      	movz	x0, #0x0, lsl #48
    ef10:      	movz	x1, #0x0, lsl #48
    ef14:      	movz	x2, #0x0, lsl #48
    ef18:      	str	x0, [x8]
    ef1c:      	str	x1, [x8, #0x8]
    ef20:      	str	x2, [x8, #0x10]
    ef24:      	ret
    ef28:      	cmp	x1, #0x0
    ef2c:      	cset	w2, gt
    ef30:      	movz	x16, #0x0, lsl #48
    ef34:      	sub	x3, x16, x1
    ef38:      	sub	x4, x3, #0x1
    ef3c:      	uxtb	w16, w2
    ef40:      	cmp	w16, wzr
    ef44:      	b.eq	0xefa4 <_stogir.terminal.previous-input+0xa4>
    ef48:      	ldr	x3, [x0, #0x8]
    ef4c:      	cmp	x1, x3
    ef50:      	b.ge	0xeff0 <_stogir.terminal.previous-input+0xf0>
    ef54:      	add	x3, x0, #0x78
    ef58:      	ldr	x3, [x3, #0x8]
    ef5c:      	cmp	x1, x3
    ef60:      	b.ge	0xf0c8 <_stogir.terminal.previous-input+0x1c8>
    ef64:      	lsl	x3, x1, #2
    ef68:      	ldr	x5, [x0, #0x78]
    ef6c:      	add	x3, x3, x5
    ef70:      	ldr	w3, [x3]
    ef74:      	sxtw	x3, w3
    ef78:      	cmp	x3, #0x0
    ef7c:      	cset	w3, ge
    ef80:      	ubfx	x3, x3, #0, #8
    ef84:      	b	0xf0cc <_stogir.terminal.previous-input+0x1cc>
    ef88:      	adrp	x16, 0xe000 <_stogir.vector-lanes.operands+0x944>
		000000000000ef88:  ARM64_RELOC_PAGE21	l_stogir.502
    ef8c:      	ldr	x16, [x16]
		000000000000ef8c:  ARM64_RELOC_PAGEOFF12	l_stogir.502
    ef90:      	orr	x0, x16, xzr
    ef94:      	mov	x1, x0
    ef98:      	mov	x0, #0x1                ; =1
    ef9c:      	mov	x2, #0x2e               ; =46
    efa0:      	b	0xef18 <_stogir.terminal.previous-input+0x18>
    efa4:      	cmp	x1, #0x0
    efa8:      	b.ge	0xeff8 <_stogir.terminal.previous-input+0xf8>
    efac:      	add	x5, x0, #0x28
    efb0:      	add	x6, x0, #0x50
    efb4:      	ldr	x5, [x5, #0x8]
    efb8:      	ldr	x6, [x6, #0x8]
    efbc:      	cmp	x5, x6
    efc0:      	b.ne	0xf0c0 <_stogir.terminal.previous-input+0x1c0>
    efc4:      	cmp	x3, x5
    efc8:      	b.gt	0xf0d0 <_stogir.terminal.previous-input+0x1d0>
    efcc:      	lsl	x3, x4, #2
    efd0:      	ldr	x5, [x0, #0x50]
    efd4:      	add	x3, x3, x5
    efd8:      	ldr	w3, [x3]
    efdc:      	sxtw	x3, w3
    efe0:      	cmp	x3, #0x0
    efe4:      	cset	w3, gt
    efe8:      	ubfx	x3, x3, #0, #8
    efec:      	b	0xf0d4 <_stogir.terminal.previous-input+0x1d4>
    eff0:      	movz	x3, #0x0, lsl #48
    eff4:      	b	0xeffc <_stogir.terminal.previous-input+0xfc>
    eff8:      	movz	x3, #0x0, lsl #48
    effc:      	cmp	x3, #0x0
    f000:      	b.eq	0xf040 <_stogir.terminal.previous-input+0x140>
    f004:      	uxtb	w16, w2
    f008:      	cmp	w16, wzr
    f00c:      	b.eq	0xf024 <_stogir.terminal.previous-input+0x124>
    f010:      	lsl	x2, x1, #4
    f014:      	ldr	x0, [x0]
    f018:      	add	x0, x2, x0
    f01c:      	ldr	x0, [x0]
    f020:      	b	0xf034 <_stogir.terminal.previous-input+0x134>
    f024:      	lsl	x2, x4, #4
    f028:      	ldr	x0, [x0, #0x28]
    f02c:      	add	x0, x2, x0
    f030:      	ldr	x0, [x0]
    f034:      	mov	x2, x0
    f038:      	mov	x0, #0x1                ; =1
    f03c:      	b	0xf048 <_stogir.terminal.previous-input+0x148>
    f040:      	movz	x0, #0x0, lsl #48
    f044:      	movz	x2, #0x0, lsl #48
    f048:      	lsr	w0, w0, #0
    f04c:      	lsr	x16, x0, #0
    f050:      	cmp	x16, #0x1
    f054:      	b.eq	0xf070 <_stogir.terminal.previous-input+0x170>
    f058:      	b.lo	0xf060 <_stogir.terminal.previous-input+0x160>
    f05c:      	b	0xf074 <_stogir.terminal.previous-input+0x174>
    f060:      	cmp	x16, #0x0
    f064:      	b.eq	0xf06c <_stogir.terminal.previous-input+0x16c>
    f068:      	b	0xf074 <_stogir.terminal.previous-input+0x174>
    f06c:      	b	0xf078 <_stogir.terminal.previous-input+0x178>
    f070:      	b	0xf094 <_stogir.terminal.previous-input+0x194>
    f074:      	b	0xf118 <_stogir.terminal.previous-input+0x218>
    f078:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f078:  ARM64_RELOC_PAGE21	l_stogir.503
    f07c:      	ldr	x16, [x16]
		000000000000f07c:  ARM64_RELOC_PAGEOFF12	l_stogir.503
    f080:      	orr	x0, x16, xzr
    f084:      	mov	x1, x0
    f088:      	mov	x0, #0x1                ; =1
    f08c:      	mov	x2, #0x1d               ; =29
    f090:      	b	0xefa0 <_stogir.terminal.previous-input+0xa0>
    f094:      	cmp	x1, #0x0
    f098:      	b.le	0xef88 <_stogir.terminal.previous-input+0x88>
    f09c:      	uxtb	w2, w2
    f0a0:      	cmp	x2, #0x83
    f0a4:      	b.ge	0xf0d8 <_stogir.terminal.previous-input+0x1d8>
    f0a8:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f0a8:  ARM64_RELOC_PAGE21	l_stogir.504
    f0ac:      	ldr	x16, [x16]
		000000000000f0ac:  ARM64_RELOC_PAGEOFF12	l_stogir.504
    f0b0:      	orr	x0, x16, xzr
    f0b4:      	add	x0, x2, x0
    f0b8:      	ldrb	w0, [x0]
    f0bc:      	b	0xf0dc <_stogir.terminal.previous-input+0x1dc>
    f0c0:      	movz	x3, #0x0, lsl #48
    f0c4:      	b	0xeffc <_stogir.terminal.previous-input+0xfc>
    f0c8:      	movz	x3, #0x0, lsl #48
    f0cc:      	b	0xeff4 <_stogir.terminal.previous-input+0xf4>
    f0d0:      	movz	x3, #0x0, lsl #48
    f0d4:      	b	0xf0c4 <_stogir.terminal.previous-input+0x1c4>
    f0d8:      	movz	x0, #0x0, lsl #48
    f0dc:      	uxtb	w0, w0
    f0e0:      	and	x0, x0, #0x8
    f0e4:      	uxtb	w0, w0
    f0e8:      	cmp	x0, #0x0
    f0ec:      	cset	w0, eq
    f0f0:      	uxtb	w16, w0
    f0f4:      	cmp	w16, wzr
    f0f8:      	cset	x0, eq
    f0fc:      	cmp	x0, #0x0
    f100:      	b.eq	0xef88 <_stogir.terminal.previous-input+0x88>
    f104:      	and	x0, x1, #0xffffffff
    f108:      	mov	x1, x0
    f10c:      	movz	x0, #0x0, lsl #48
    f110:      	movz	x2, #0x0, lsl #48
    f114:      	b	0xefa0 <_stogir.terminal.previous-input+0xa0>
    f118:      	brk	#0
    f11c:      	b	0xf118 <_stogir.terminal.previous-input+0x218>

000000000000f120 <_stogir.switch.selector-type>:
    f120:      	sxtw	x1, w1
    f124:      	cmp	x1, #0x0
    f128:      	cset	w2, gt
    f12c:      	movz	x16, #0x0, lsl #48
    f130:      	sub	x3, x16, x1
    f134:      	sub	x4, x3, #0x1
    f138:      	uxtb	w16, w2
    f13c:      	cmp	w16, wzr
    f140:      	b.eq	0xf184 <_stogir.switch.selector-type+0x64>
    f144:      	ldr	x3, [x0, #0x8]
    f148:      	cmp	x1, x3
    f14c:      	b.ge	0xf1d8 <_stogir.switch.selector-type+0xb8>
    f150:      	add	x3, x0, #0x78
    f154:      	ldr	x3, [x3, #0x8]
    f158:      	cmp	x1, x3
    f15c:      	b.ge	0xf2dc <_stogir.switch.selector-type+0x1bc>
    f160:      	lsl	x3, x1, #2
    f164:      	ldr	x5, [x0, #0x78]
    f168:      	add	x3, x3, x5
    f16c:      	ldr	w3, [x3]
    f170:      	sxtw	x3, w3
    f174:      	cmp	x3, #0x0
    f178:      	cset	w3, ge
    f17c:      	ubfx	x3, x3, #0, #8
    f180:      	b	0xf2e0 <_stogir.switch.selector-type+0x1c0>
    f184:      	cmp	x1, #0x0
    f188:      	b.ge	0xf1e0 <_stogir.switch.selector-type+0xc0>
    f18c:      	add	x5, x0, #0x28
    f190:      	add	x6, x0, #0x50
    f194:      	ldr	x5, [x5, #0x8]
    f198:      	ldr	x6, [x6, #0x8]
    f19c:      	cmp	x5, x6
    f1a0:      	b.ne	0xf1d0 <_stogir.switch.selector-type+0xb0>
    f1a4:      	cmp	x3, x5
    f1a8:      	b.gt	0xf2e4 <_stogir.switch.selector-type+0x1c4>
    f1ac:      	lsl	x3, x4, #2
    f1b0:      	ldr	x5, [x0, #0x50]
    f1b4:      	add	x3, x3, x5
    f1b8:      	ldr	w3, [x3]
    f1bc:      	sxtw	x3, w3
    f1c0:      	cmp	x3, #0x0
    f1c4:      	cset	w3, gt
    f1c8:      	ubfx	x3, x3, #0, #8
    f1cc:      	b	0xf2e8 <_stogir.switch.selector-type+0x1c8>
    f1d0:      	movz	x3, #0x0, lsl #48
    f1d4:      	b	0xf1e4 <_stogir.switch.selector-type+0xc4>
    f1d8:      	movz	x3, #0x0, lsl #48
    f1dc:      	b	0xf1e4 <_stogir.switch.selector-type+0xc4>
    f1e0:      	movz	x3, #0x0, lsl #48
    f1e4:      	cmp	x3, #0x0
    f1e8:      	b.eq	0xf228 <_stogir.switch.selector-type+0x108>
    f1ec:      	uxtb	w16, w2
    f1f0:      	cmp	w16, wzr
    f1f4:      	b.eq	0xf20c <_stogir.switch.selector-type+0xec>
    f1f8:      	lsl	x1, x1, #4
    f1fc:      	ldr	x0, [x0]
    f200:      	add	x0, x1, x0
    f204:      	ldr	x0, [x0]
    f208:      	b	0xf21c <_stogir.switch.selector-type+0xfc>
    f20c:      	lsl	x1, x4, #4
    f210:      	ldr	x0, [x0, #0x28]
    f214:      	add	x0, x1, x0
    f218:      	ldr	x0, [x0]
    f21c:      	mov	x1, x0
    f220:      	mov	x0, #0x1                ; =1
    f224:      	b	0xf230 <_stogir.switch.selector-type+0x110>
    f228:      	movz	x0, #0x0, lsl #48
    f22c:      	movz	x1, #0x0, lsl #48
    f230:      	lsr	w0, w0, #0
    f234:      	lsr	x16, x0, #0
    f238:      	cmp	x16, #0x1
    f23c:      	b.eq	0xf258 <_stogir.switch.selector-type+0x138>
    f240:      	b.lo	0xf248 <_stogir.switch.selector-type+0x128>
    f244:      	b	0xf25c <_stogir.switch.selector-type+0x13c>
    f248:      	cmp	x16, #0x0
    f24c:      	b.eq	0xf254 <_stogir.switch.selector-type+0x134>
    f250:      	b	0xf25c <_stogir.switch.selector-type+0x13c>
    f254:      	b	0xf260 <_stogir.switch.selector-type+0x140>
    f258:      	b	0xf2a4 <_stogir.switch.selector-type+0x184>
    f25c:      	b	0xf2ec <_stogir.switch.selector-type+0x1cc>
    f260:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f260:  ARM64_RELOC_PAGE21	l_stogir.505
    f264:      	ldr	x16, [x16]
		000000000000f264:  ARM64_RELOC_PAGEOFF12	l_stogir.505
    f268:      	orr	x0, x16, xzr
    f26c:      	mov	x1, x0
    f270:      	mov	x0, #0x1                ; =1
    f274:      	mov	x2, #0x17               ; =23
    f278:      	b	0xf294 <_stogir.switch.selector-type+0x174>
    f27c:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f27c:  ARM64_RELOC_PAGE21	l_stogir.506
    f280:      	ldr	x16, [x16]
		000000000000f280:  ARM64_RELOC_PAGEOFF12	l_stogir.506
    f284:      	orr	x0, x16, xzr
    f288:      	mov	x1, x0
    f28c:      	mov	x0, #0x1                ; =1
    f290:      	mov	x2, #0x20               ; =32
    f294:      	str	x0, [x8]
    f298:      	str	x1, [x8, #0x8]
    f29c:      	str	x2, [x8, #0x10]
    f2a0:      	ret
    f2a4:      	lsr	w0, w1, #0
    f2a8:      	ubfx	x0, x0, #8, #8
    f2ac:      	cmp	x0, #0x1
    f2b0:      	b.lt	0xf27c <_stogir.switch.selector-type+0x15c>
    f2b4:      	cmp	x0, #0xb
    f2b8:      	b.gt	0xf27c <_stogir.switch.selector-type+0x15c>
    f2bc:      	uxtb	w1, w1
    f2c0:      	cmp	x1, #0x48
    f2c4:      	b.eq	0xf27c <_stogir.switch.selector-type+0x15c>
    f2c8:      	and	x0, x0, #0xffffffff
    f2cc:      	mov	x1, x0
    f2d0:      	movz	x0, #0x0, lsl #48
    f2d4:      	movz	x2, #0x0, lsl #48
    f2d8:      	b	0xf294 <_stogir.switch.selector-type+0x174>
    f2dc:      	movz	x3, #0x0, lsl #48
    f2e0:      	b	0xf1dc <_stogir.switch.selector-type+0xbc>
    f2e4:      	movz	x3, #0x0, lsl #48
    f2e8:      	b	0xf1d4 <_stogir.switch.selector-type+0xb4>
    f2ec:      	brk	#0
    f2f0:      	b	0xf2ec <_stogir.switch.selector-type+0x1cc>

000000000000f2f4 <_stogir.switch.key>:
    f2f4:      	sub	sp, sp, #0x30
    f2f8:      	str	x19, [sp]
    f2fc:      	str	x20, [sp, #0x8]
    f300:      	str	x21, [sp, #0x10]
    f304:      	str	x22, [sp, #0x18]
    f308:      	str	x23, [sp, #0x20]
    f30c:      	sxtw	x2, w2
    f310:      	cmp	x2, #0x1
    f314:      	b.lt	0xf390 <_stogir.switch.key+0x9c>
    f318:      	cmp	x2, #0xb
    f31c:      	cset	w3, le
    f320:      	uxtb	w16, w3
    f324:      	cmp	w16, wzr
    f328:      	b.eq	0xf390 <_stogir.switch.key+0x9c>
    f32c:      	sxtw	x1, w1
    f330:      	cmp	x1, #0x0
    f334:      	cset	w4, gt
    f338:      	movz	x16, #0x0, lsl #48
    f33c:      	sub	x5, x16, x1
    f340:      	sub	x6, x5, #0x1
    f344:      	uxtb	w16, w4
    f348:      	cmp	w16, wzr
    f34c:      	b.eq	0xf414 <_stogir.switch.key+0x120>
    f350:      	ldr	x5, [x0, #0x8]
    f354:      	cmp	x1, x5
    f358:      	b.ge	0xf460 <_stogir.switch.key+0x16c>
    f35c:      	add	x5, x0, #0x78
    f360:      	ldr	x5, [x5, #0x8]
    f364:      	cmp	x1, x5
    f368:      	b.ge	0xf5cc <_stogir.switch.key+0x2d8>
    f36c:      	lsl	x5, x1, #2
    f370:      	ldr	x7, [x0, #0x78]
    f374:      	add	x5, x5, x7
    f378:      	ldr	w5, [x5]
    f37c:      	sxtw	x5, w5
    f380:      	cmp	x5, #0x0
    f384:      	cset	w5, ge
    f388:      	ubfx	x5, x5, #0, #8
    f38c:      	b	0xf5d0 <_stogir.switch.key+0x2dc>
    f390:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f390:  ARM64_RELOC_PAGE21	l_stogir.507
    f394:      	ldr	x16, [x16]
		000000000000f394:  ARM64_RELOC_PAGEOFF12	l_stogir.507
    f398:      	orr	x0, x16, xzr
    f39c:      	mov	x1, x0
    f3a0:      	mov	x0, #0x1                ; =1
    f3a4:      	mov	x2, #0x24               ; =36
    f3a8:      	str	x0, [x8]
    f3ac:      	str	x1, [x8, #0x8]
    f3b0:      	str	x2, [x8, #0x10]
    f3b4:      	ldr	x19, [sp]
    f3b8:      	ldr	x20, [sp, #0x8]
    f3bc:      	ldr	x21, [sp, #0x10]
    f3c0:      	ldr	x22, [sp, #0x18]
    f3c4:      	ldr	x23, [sp, #0x20]
    f3c8:      	add	sp, sp, #0x30
    f3cc:      	ret
    f3d0:      	mov	x23, #0x1               ; =1
    f3d4:      	cmp	x1, #0x0
    f3d8:      	b.ge	0xf3f8 <_stogir.switch.key+0x104>
    f3dc:      	lsr	w1, w4, #0
    f3e0:      	uxtb	w4, w4
    f3e4:      	ubfx	x1, x1, #8, #8
    f3e8:      	cmp	x4, x1
    f3ec:      	b.eq	0xf674 <_stogir.switch.key+0x380>
    f3f0:      	cmp	x4, #0x49
    f3f4:      	b.eq	0xf674 <_stogir.switch.key+0x380>
    f3f8:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f3f8:  ARM64_RELOC_PAGE21	l_stogir.508
    f3fc:      	ldr	x16, [x16]
		000000000000f3fc:  ARM64_RELOC_PAGEOFF12	l_stogir.508
    f400:      	orr	x0, x16, xzr
    f404:      	mov	x1, x0
    f408:      	mov	x0, #0x1                ; =1
    f40c:      	mov	x2, #0x30               ; =48
    f410:      	b	0xf3a8 <_stogir.switch.key+0xb4>
    f414:      	cmp	x1, #0x0
    f418:      	b.ge	0xf468 <_stogir.switch.key+0x174>
    f41c:      	add	x7, x0, #0x28
    f420:      	add	x9, x0, #0x50
    f424:      	ldr	x7, [x7, #0x8]
    f428:      	ldr	x9, [x9, #0x8]
    f42c:      	cmp	x7, x9
    f430:      	b.ne	0xf5c4 <_stogir.switch.key+0x2d0>
    f434:      	cmp	x5, x7
    f438:      	b.gt	0xf66c <_stogir.switch.key+0x378>
    f43c:      	lsl	x5, x6, #2
    f440:      	ldr	x7, [x0, #0x50]
    f444:      	add	x5, x5, x7
    f448:      	ldr	w5, [x5]
    f44c:      	sxtw	x5, w5
    f450:      	cmp	x5, #0x0
    f454:      	cset	w5, gt
    f458:      	ubfx	x5, x5, #0, #8
    f45c:      	b	0xf670 <_stogir.switch.key+0x37c>
    f460:      	movz	x5, #0x0, lsl #48
    f464:      	b	0xf46c <_stogir.switch.key+0x178>
    f468:      	movz	x5, #0x0, lsl #48
    f46c:      	cmp	x5, #0x0
    f470:      	b.eq	0xf4d4 <_stogir.switch.key+0x1e0>
    f474:      	uxtb	w16, w4
    f478:      	cmp	w16, wzr
    f47c:      	b.eq	0xf4a4 <_stogir.switch.key+0x1b0>
    f480:      	lsl	x4, x1, #4
    f484:      	ldr	x0, [x0]
    f488:      	add	x0, x4, x0
    f48c:      	ldr	x4, [x0]
    f490:      	ldr	x0, [x0, #0x8]
    f494:      	fmov	d31, x0
    f498:      	mov	x0, x4
    f49c:      	fmov	x4, d31
    f4a0:      	b	0xf4c4 <_stogir.switch.key+0x1d0>
    f4a4:      	lsl	x4, x6, #4
    f4a8:      	ldr	x0, [x0, #0x28]
    f4ac:      	add	x0, x4, x0
    f4b0:      	ldr	x4, [x0]
    f4b4:      	ldr	x0, [x0, #0x8]
    f4b8:      	fmov	d31, x0
    f4bc:      	mov	x0, x4
    f4c0:      	fmov	x4, d31
    f4c4:      	mov	x5, x4
    f4c8:      	mov	x4, x0
    f4cc:      	mov	x0, #0x1                ; =1
    f4d0:      	b	0xf4e0 <_stogir.switch.key+0x1ec>
    f4d4:      	movz	x0, #0x0, lsl #48
    f4d8:      	movz	x4, #0x0, lsl #48
    f4dc:      	movz	x5, #0x0, lsl #48
    f4e0:      	lsr	w0, w0, #0
    f4e4:      	lsr	x16, x0, #0
    f4e8:      	cmp	x16, #0x1
    f4ec:      	b.eq	0xf508 <_stogir.switch.key+0x214>
    f4f0:      	b.lo	0xf4f8 <_stogir.switch.key+0x204>
    f4f4:      	b	0xf50c <_stogir.switch.key+0x218>
    f4f8:      	cmp	x16, #0x0
    f4fc:      	b.eq	0xf504 <_stogir.switch.key+0x210>
    f500:      	b	0xf50c <_stogir.switch.key+0x218>
    f504:      	b	0xf510 <_stogir.switch.key+0x21c>
    f508:      	b	0xf52c <_stogir.switch.key+0x238>
    f50c:      	b	0xf718 <_stogir.switch.key+0x424>
    f510:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000f510:  ARM64_RELOC_PAGE21	l_stogir.509
    f514:      	ldr	x16, [x16]
		000000000000f514:  ARM64_RELOC_PAGEOFF12	l_stogir.509
    f518:      	orr	x0, x16, xzr
    f51c:      	mov	x1, x0
    f520:      	mov	x0, #0x1                ; =1
    f524:      	mov	x2, #0x1c               ; =28
    f528:      	b	0xf410 <_stogir.switch.key+0x11c>
    f52c:      	cmp	x2, #0x1
    f530:      	cset	w0, eq
    f534:      	cmp	x2, #0x0
    f538:      	cset	w6, eq
    f53c:      	cmp	x2, #0x2
    f540:      	cset	w7, eq
    f544:      	cmp	x2, #0x7
    f548:      	cset	w9, eq
    f54c:      	cmp	x2, #0x8
    f550:      	cset	w10, eq
    f554:      	cmp	x2, #0x3
    f558:      	cset	w11, eq
    f55c:      	cmp	x2, #0x9
    f560:      	cset	w12, eq
    f564:      	cmp	x2, #0x4
    f568:      	cset	w13, eq
    f56c:      	cmp	x2, #0xa
    f570:      	cset	w14, eq
    f574:      	cmp	x2, #0xd
    f578:      	cset	w15, eq
    f57c:      	cmp	x2, #0x5
    f580:      	cset	w19, eq
    f584:      	cmp	x2, #0xb
    f588:      	cset	w20, eq
    f58c:      	cmp	x2, #0xc
    f590:      	cset	w21, eq
    f594:      	cmp	x2, #0x6
    f598:      	cset	w22, eq
    f59c:      	uxtb	w16, w22
    f5a0:      	cmp	w16, wzr
    f5a4:      	mov	x16, #0x8               ; =8
    f5a8:      	movn	x17, #0x0, lsl #48
    f5ac:      	csel	x22, x16, x17, ne
    f5b0:      	uxtb	w16, w6
    f5b4:      	cmp	w16, wzr
    f5b8:      	b.eq	0xf5d4 <_stogir.switch.key+0x2e0>
    f5bc:      	movz	x23, #0x0, lsl #48
    f5c0:      	b	0xf3d4 <_stogir.switch.key+0xe0>
    f5c4:      	movz	x5, #0x0, lsl #48
    f5c8:      	b	0xf46c <_stogir.switch.key+0x178>
    f5cc:      	movz	x5, #0x0, lsl #48
    f5d0:      	b	0xf464 <_stogir.switch.key+0x170>
    f5d4:      	uxtb	w16, w0
    f5d8:      	cmp	w16, wzr
    f5dc:      	b.ne	0xf3d0 <_stogir.switch.key+0xdc>
    f5e0:      	uxtb	w16, w7
    f5e4:      	cmp	w16, wzr
    f5e8:      	b.ne	0xf3d0 <_stogir.switch.key+0xdc>
    f5ec:      	uxtb	w16, w9
    f5f0:      	cmp	w16, wzr
    f5f4:      	b.ne	0xf3d0 <_stogir.switch.key+0xdc>
    f5f8:      	uxtb	w16, w10
    f5fc:      	cmp	w16, wzr
    f600:      	b.ne	0xf3d0 <_stogir.switch.key+0xdc>
    f604:      	uxtb	w16, w11
    f608:      	cmp	w16, wzr
    f60c:      	b.ne	0xf710 <_stogir.switch.key+0x41c>
    f610:      	uxtb	w16, w12
    f614:      	cmp	w16, wzr
    f618:      	b.ne	0xf710 <_stogir.switch.key+0x41c>
    f61c:      	uxtb	w16, w13
    f620:      	cmp	w16, wzr
    f624:      	b.ne	0xf7e8 <_stogir.switch.key+0x4f4>
    f628:      	uxtb	w16, w14
    f62c:      	cmp	w16, wzr
    f630:      	b.ne	0xf7e8 <_stogir.switch.key+0x4f4>
    f634:      	uxtb	w16, w15
    f638:      	cmp	w16, wzr
    f63c:      	b.ne	0xf7e8 <_stogir.switch.key+0x4f4>
    f640:      	uxtb	w16, w19
    f644:      	cmp	w16, wzr
    f648:      	b.ne	0xf7f0 <_stogir.switch.key+0x4fc>
    f64c:      	uxtb	w16, w20
    f650:      	cmp	w16, wzr
    f654:      	b.ne	0xf7f0 <_stogir.switch.key+0x4fc>
    f658:      	uxtb	w16, w21
    f65c:      	cmp	w16, wzr
    f660:      	b.ne	0xf7f0 <_stogir.switch.key+0x4fc>
    f664:      	mov	x23, x22
    f668:      	b	0xf7f4 <_stogir.switch.key+0x500>
    f66c:      	movz	x5, #0x0, lsl #48
    f670:      	b	0xf5c8 <_stogir.switch.key+0x2d4>
    f674:      	cmp	x1, x2
    f678:      	b.ne	0xf3f8 <_stogir.switch.key+0x104>
    f67c:      	lsr	w23, w23, #0
    f680:      	lsr	w1, w5, #0
    f684:      	sxtw	x23, w23
    f688:      	ubfx	x1, x1, #0, #32
    f68c:      	lsr	x4, x5, #32
    f690:      	lsl	x5, x23, #3
    f694:      	ubfx	x4, x4, #0, #32
    f698:      	lsr	w5, w5, #0
    f69c:      	lsl	x4, x4, #32
    f6a0:      	sxtw	x5, w5
    f6a4:      	orr	x1, x4, x1
    f6a8:      	cmp	x5, #0x40
    f6ac:      	b.ge	0xf6bc <_stogir.switch.key+0x3c8>
    f6b0:      	lsr	x4, x1, x5
    f6b4:      	cmp	x4, #0x0
    f6b8:      	b.ne	0xf3f8 <_stogir.switch.key+0x104>
    f6bc:      	uxtb	w16, w0
    f6c0:      	cmp	w16, wzr
    f6c4:      	b.eq	0xf6d0 <_stogir.switch.key+0x3dc>
    f6c8:      	cmp	x1, #0x1
    f6cc:      	b.hi	0xf3f8 <_stogir.switch.key+0x104>
    f6d0:      	cmp	x2, #0x7
    f6d4:      	b.lt	0xf6f8 <_stogir.switch.key+0x404>
    f6d8:      	uxtb	w16, w3
    f6dc:      	cmp	w16, wzr
    f6e0:      	b.eq	0xf6f8 <_stogir.switch.key+0x404>
    f6e4:      	uxtb	w16, w6
    f6e8:      	cmp	w16, wzr
    f6ec:      	b.eq	0xf750 <_stogir.switch.key+0x45c>
    f6f0:      	movz	x0, #0x0, lsl #48
    f6f4:      	b	0xf724 <_stogir.switch.key+0x430>
    f6f8:      	movz	x0, #0x0, lsl #48
    f6fc:      	eor	x0, x0, x1
    f700:      	mov	x1, x0
    f704:      	movz	x0, #0x0, lsl #48
    f708:      	movz	x2, #0x0, lsl #48
    f70c:      	b	0xf410 <_stogir.switch.key+0x11c>
    f710:      	mov	x23, #0x2               ; =2
    f714:      	b	0xf3d4 <_stogir.switch.key+0xe0>
    f718:      	brk	#0
    f71c:      	b	0xf718 <_stogir.switch.key+0x424>
    f720:      	mov	x0, #0x1                ; =1
    f724:      	lsr	w0, w0, #0
    f728:      	sxtw	x0, w0
    f72c:      	lsl	x0, x0, #3
    f730:      	lsr	w0, w0, #0
    f734:      	sxtw	x0, w0
    f738:      	sub	x0, x0, #0x1
    f73c:      	lsr	w0, w0, #0
    f740:      	sxtw	x0, w0
    f744:      	mov	x16, #0x1               ; =1
    f748:      	lsl	x0, x16, x0
    f74c:      	b	0xf6fc <_stogir.switch.key+0x408>
    f750:      	uxtb	w16, w0
    f754:      	cmp	w16, wzr
    f758:      	b.ne	0xf720 <_stogir.switch.key+0x42c>
    f75c:      	uxtb	w16, w7
    f760:      	cmp	w16, wzr
    f764:      	b.ne	0xf720 <_stogir.switch.key+0x42c>
    f768:      	uxtb	w16, w9
    f76c:      	cmp	w16, wzr
    f770:      	b.ne	0xf720 <_stogir.switch.key+0x42c>
    f774:      	uxtb	w16, w10
    f778:      	cmp	w16, wzr
    f77c:      	b.ne	0xf720 <_stogir.switch.key+0x42c>
    f780:      	uxtb	w16, w11
    f784:      	cmp	w16, wzr
    f788:      	b.ne	0xf7f8 <_stogir.switch.key+0x504>
    f78c:      	uxtb	w16, w12
    f790:      	cmp	w16, wzr
    f794:      	b.ne	0xf7f8 <_stogir.switch.key+0x504>
    f798:      	uxtb	w16, w13
    f79c:      	cmp	w16, wzr
    f7a0:      	b.ne	0xf800 <_stogir.switch.key+0x50c>
    f7a4:      	uxtb	w16, w14
    f7a8:      	cmp	w16, wzr
    f7ac:      	b.ne	0xf800 <_stogir.switch.key+0x50c>
    f7b0:      	uxtb	w16, w15
    f7b4:      	cmp	w16, wzr
    f7b8:      	b.ne	0xf800 <_stogir.switch.key+0x50c>
    f7bc:      	uxtb	w16, w19
    f7c0:      	cmp	w16, wzr
    f7c4:      	b.ne	0xf808 <_stogir.switch.key+0x514>
    f7c8:      	uxtb	w16, w20
    f7cc:      	cmp	w16, wzr
    f7d0:      	b.ne	0xf808 <_stogir.switch.key+0x514>
    f7d4:      	uxtb	w16, w21
    f7d8:      	cmp	w16, wzr
    f7dc:      	b.ne	0xf808 <_stogir.switch.key+0x514>
    f7e0:      	mov	x0, x22
    f7e4:      	b	0xf80c <_stogir.switch.key+0x518>
    f7e8:      	mov	x23, #0x4               ; =4
    f7ec:      	b	0xf714 <_stogir.switch.key+0x420>
    f7f0:      	mov	x23, #0x8               ; =8
    f7f4:      	b	0xf7ec <_stogir.switch.key+0x4f8>
    f7f8:      	mov	x0, #0x2                ; =2
    f7fc:      	b	0xf724 <_stogir.switch.key+0x430>
    f800:      	mov	x0, #0x4                ; =4
    f804:      	b	0xf7fc <_stogir.switch.key+0x508>
    f808:      	mov	x0, #0x8                ; =8
    f80c:      	b	0xf804 <_stogir.switch.key+0x510>

000000000000f810 <_stogir.stack.entry-allocation?>:
    f810:      	sub	sp, sp, #0x10
    f814:      	add	x2, x0, #0x78
    f818:      	add	x3, x0, #0x28
    f81c:      	add	x4, x0, #0x50
    f820:      	add	x5, x0, #0x78
    f824:      	add	x6, x0, #0x28
    f828:      	add	x7, x0, #0x50
    f82c:      	sxtw	x1, w1
    f830:      	mov	x9, x1
    f834:      	mov	x1, #0x1                ; =1
    f838:      	movz	x8, #0x0, lsl #48
    f83c:      	b	0xf98c <_stogir.stack.entry-allocation?+0x17c>
    f840:      	movz	x12, #0x0, lsl #48
    f844:      	b	0xf8bc <_stogir.stack.entry-allocation?+0xac>
    f848:      	movz	x10, #0x0, lsl #48
    f84c:      	movz	x11, #0x0, lsl #48
    f850:      	lsr	w10, w10, #0
    f854:      	lsr	x16, x10, #0
    f858:      	cmp	x16, #0x1
    f85c:      	b.eq	0xf878 <_stogir.stack.entry-allocation?+0x68>
    f860:      	b.lo	0xf868 <_stogir.stack.entry-allocation?+0x58>
    f864:      	b	0xf87c <_stogir.stack.entry-allocation?+0x6c>
    f868:      	cmp	x16, #0x0
    f86c:      	b.eq	0xf874 <_stogir.stack.entry-allocation?+0x64>
    f870:      	b	0xf87c <_stogir.stack.entry-allocation?+0x6c>
    f874:      	b	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    f878:      	b	0xf880 <_stogir.stack.entry-allocation?+0x70>
    f87c:      	b	0xfbd8 <_stogir.stack.entry-allocation?+0x3c8>
    f880:      	uxtb	w10, w11
    f884:      	lsr	w11, w11, #0
    f888:      	ubfx	x11, x11, #8, #8
    f88c:      	cmp	x10, x11
    f890:      	b.eq	0xfbc8 <_stogir.stack.entry-allocation?+0x3b8>
    f894:      	cmp	x10, #0x49
    f898:      	b.eq	0xfbc8 <_stogir.stack.entry-allocation?+0x3b8>
    f89c:      	movz	x1, #0x0, lsl #48
    f8a0:      	fmov	d31, x8
    f8a4:      	mov	x8, x9
    f8a8:      	fmov	x9, d31
    f8ac:      	b	0xfa78 <_stogir.stack.entry-allocation?+0x268>
    f8b0:      	movz	x12, #0x0, lsl #48
    f8b4:      	b	0xf8c4 <_stogir.stack.entry-allocation?+0xb4>
    f8b8:      	movz	x12, #0x0, lsl #48
    f8bc:      	b	0xf8cc <_stogir.stack.entry-allocation?+0xbc>
    f8c0:      	movz	x12, #0x0, lsl #48
    f8c4:      	b	0xf8cc <_stogir.stack.entry-allocation?+0xbc>
    f8c8:      	movz	x12, #0x0, lsl #48
    f8cc:      	cmp	x12, #0x0
    f8d0:      	b.eq	0xf934 <_stogir.stack.entry-allocation?+0x124>
    f8d4:      	uxtb	w16, w11
    f8d8:      	cmp	w16, wzr
    f8dc:      	b.eq	0xf904 <_stogir.stack.entry-allocation?+0xf4>
    f8e0:      	lsl	x10, x10, #4
    f8e4:      	ldr	x11, [x0]
    f8e8:      	add	x10, x10, x11
    f8ec:      	ldr	x11, [x10]
    f8f0:      	ldr	x10, [x10, #0x8]
    f8f4:      	fmov	d31, x10
    f8f8:      	mov	x10, x11
    f8fc:      	fmov	x11, d31
    f900:      	b	0xf924 <_stogir.stack.entry-allocation?+0x114>
    f904:      	lsl	x10, x13, #4
    f908:      	ldr	x11, [x0, #0x28]
    f90c:      	add	x10, x10, x11
    f910:      	ldr	x11, [x10]
    f914:      	ldr	x10, [x10, #0x8]
    f918:      	fmov	d31, x10
    f91c:      	mov	x10, x11
    f920:      	fmov	x11, d31
    f924:      	mov	x12, x11
    f928:      	mov	x11, x10
    f92c:      	mov	x10, #0x1               ; =1
    f930:      	b	0xf940 <_stogir.stack.entry-allocation?+0x130>
    f934:      	movz	x10, #0x0, lsl #48
    f938:      	movz	x11, #0x0, lsl #48
    f93c:      	movz	x12, #0x0, lsl #48
    f940:      	lsr	w10, w10, #0
    f944:      	lsr	x16, x10, #0
    f948:      	cmp	x16, #0x1
    f94c:      	b.eq	0xf968 <_stogir.stack.entry-allocation?+0x158>
    f950:      	b.lo	0xf958 <_stogir.stack.entry-allocation?+0x148>
    f954:      	b	0xf96c <_stogir.stack.entry-allocation?+0x15c>
    f958:      	cmp	x16, #0x0
    f95c:      	b.eq	0xf964 <_stogir.stack.entry-allocation?+0x154>
    f960:      	b	0xf96c <_stogir.stack.entry-allocation?+0x15c>
    f964:      	b	0xf970 <_stogir.stack.entry-allocation?+0x160>
    f968:      	b	0xfa44 <_stogir.stack.entry-allocation?+0x234>
    f96c:      	b	0xfb24 <_stogir.stack.entry-allocation?+0x314>
    f970:      	fmov	d31, x8
    f974:      	mov	x8, x9
    f978:      	fmov	x9, d31
    f97c:      	movz	x1, #0x0, lsl #48
    f980:      	fmov	d31, x8
    f984:      	mov	x8, x9
    f988:      	fmov	x9, d31
    f98c:      	cmp	x1, #0x0
    f990:      	b.eq	0xfb08 <_stogir.stack.entry-allocation?+0x2f8>
    f994:      	cmp	x8, #0x0
    f998:      	b.ne	0xfb08 <_stogir.stack.entry-allocation?+0x2f8>
    f99c:      	lsr	w10, w9, #0
    f9a0:      	sxtw	x10, w10
    f9a4:      	cmp	x10, #0x0
    f9a8:      	cset	w11, gt
    f9ac:      	movz	x16, #0x0, lsl #48
    f9b0:      	sub	x12, x16, x10
    f9b4:      	sub	x13, x12, #0x1
    f9b8:      	uxtb	w16, w11
    f9bc:      	cmp	w16, wzr
    f9c0:      	b.eq	0xfa00 <_stogir.stack.entry-allocation?+0x1f0>
    f9c4:      	ldr	x12, [x0, #0x8]
    f9c8:      	cmp	x10, x12
    f9cc:      	b.ge	0xf8c0 <_stogir.stack.entry-allocation?+0xb0>
    f9d0:      	ldr	x12, [x2, #0x8]
    f9d4:      	cmp	x10, x12
    f9d8:      	b.ge	0xf8b0 <_stogir.stack.entry-allocation?+0xa0>
    f9dc:      	lsl	x12, x10, #2
    f9e0:      	ldr	x14, [x0, #0x78]
    f9e4:      	add	x12, x12, x14
    f9e8:      	ldr	w12, [x12]
    f9ec:      	sxtw	x12, w12
    f9f0:      	cmp	x12, #0x0
    f9f4:      	cset	w12, ge
    f9f8:      	ubfx	x12, x12, #0, #8
    f9fc:      	b	0xf8b4 <_stogir.stack.entry-allocation?+0xa4>
    fa00:      	cmp	x10, #0x0
    fa04:      	b.ge	0xf8c8 <_stogir.stack.entry-allocation?+0xb8>
    fa08:      	ldr	x14, [x3, #0x8]
    fa0c:      	ldr	x15, [x4, #0x8]
    fa10:      	cmp	x14, x15
    fa14:      	b.ne	0xf8b8 <_stogir.stack.entry-allocation?+0xa8>
    fa18:      	cmp	x12, x14
    fa1c:      	b.gt	0xf840 <_stogir.stack.entry-allocation?+0x30>
    fa20:      	lsl	x12, x13, #2
    fa24:      	ldr	x14, [x0, #0x50]
    fa28:      	add	x12, x12, x14
    fa2c:      	ldr	w12, [x12]
    fa30:      	sxtw	x12, w12
    fa34:      	cmp	x12, #0x0
    fa38:      	cset	w12, gt
    fa3c:      	ubfx	x12, x12, #0, #8
    fa40:      	b	0xf844 <_stogir.stack.entry-allocation?+0x34>
    fa44:      	uxtb	w10, w11
    fa48:      	asr	x13, x11, #32
    fa4c:      	mov	x16, sp
    fa50:      	str	x11, [x16]
    fa54:      	mov	x16, sp
    fa58:      	str	x12, [x16, #0x8]
    fa5c:      	cmp	x10, #0x68
    fa60:      	b.ne	0xfa7c <_stogir.stack.entry-allocation?+0x26c>
    fa64:      	cmp	x13, #0x0
    fa68:      	cset	w1, eq
    fa6c:      	ubfx	x1, x1, #0, #8
    fa70:      	mov	x8, x9
    fa74:      	mov	x9, #0x1                ; =1
    fa78:      	b	0xf980 <_stogir.stack.entry-allocation?+0x170>
    fa7c:      	cmp	x9, #0x0
    fa80:      	b.le	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    fa84:      	cmp	x10, #0x51
    fa88:      	b.ne	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    fa8c:      	cmp	x13, #0x0
    fa90:      	b.le	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    fa94:      	cmp	x13, x9
    fa98:      	b.ge	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    fa9c:      	lsr	w12, w12, #0
    faa0:      	sxtw	x12, w12
    faa4:      	cmp	x12, #0x0
    faa8:      	b.ge	0xf89c <_stogir.stack.entry-allocation?+0x8c>
    faac:      	cmp	x12, #0x0
    fab0:      	cset	w10, gt
    fab4:      	movz	x16, #0x0, lsl #48
    fab8:      	sub	x11, x16, x12
    fabc:      	sub	x13, x11, #0x1
    fac0:      	uxtb	w16, w10
    fac4:      	cmp	w16, wzr
    fac8:      	b.eq	0xfb7c <_stogir.stack.entry-allocation?+0x36c>
    facc:      	ldr	x11, [x0, #0x8]
    fad0:      	cmp	x12, x11
    fad4:      	b.ge	0xfb74 <_stogir.stack.entry-allocation?+0x364>
    fad8:      	ldr	x11, [x5, #0x8]
    fadc:      	cmp	x12, x11
    fae0:      	b.ge	0xfbc0 <_stogir.stack.entry-allocation?+0x3b0>
    fae4:      	lsl	x11, x12, #2
    fae8:      	ldr	x14, [x0, #0x78]
    faec:      	add	x11, x11, x14
    faf0:      	ldr	w11, [x11]
    faf4:      	sxtw	x11, w11
    faf8:      	cmp	x11, #0x0
    fafc:      	cset	w11, ge
    fb00:      	ubfx	x11, x11, #0, #8
    fb04:      	b	0xfbc4 <_stogir.stack.entry-allocation?+0x3b4>
    fb08:      	cmp	x1, #0x0
    fb0c:      	b.eq	0xfb18 <_stogir.stack.entry-allocation?+0x308>
    fb10:      	mov	x0, x8
    fb14:      	b	0xfb1c <_stogir.stack.entry-allocation?+0x30c>
    fb18:      	movz	x0, #0x0, lsl #48
    fb1c:      	add	sp, sp, #0x10
    fb20:      	ret
    fb24:      	brk	#0
    fb28:      	b	0xfb24 <_stogir.stack.entry-allocation?+0x314>
    fb2c:      	lsl	x10, x13, #4
    fb30:      	ldr	x11, [x0, #0x28]
    fb34:      	add	x10, x10, x11
    fb38:      	ldr	x10, [x10]
    fb3c:      	mov	x11, x10
    fb40:      	mov	x10, #0x1               ; =1
    fb44:      	b	0xf850 <_stogir.stack.entry-allocation?+0x40>
    fb48:      	movz	x11, #0x0, lsl #48
    fb4c:      	cmp	x11, #0x0
    fb50:      	b.eq	0xf848 <_stogir.stack.entry-allocation?+0x38>
    fb54:      	uxtb	w16, w10
    fb58:      	cmp	w16, wzr
    fb5c:      	b.eq	0xfb2c <_stogir.stack.entry-allocation?+0x31c>
    fb60:      	lsl	x10, x12, #4
    fb64:      	ldr	x11, [x0]
    fb68:      	add	x10, x10, x11
    fb6c:      	ldr	x10, [x10]
    fb70:      	b	0xfb3c <_stogir.stack.entry-allocation?+0x32c>
    fb74:      	movz	x11, #0x0, lsl #48
    fb78:      	b	0xfb4c <_stogir.stack.entry-allocation?+0x33c>
    fb7c:      	ldr	x14, [x6, #0x8]
    fb80:      	ldr	x15, [x7, #0x8]
    fb84:      	cmp	x14, x15
    fb88:      	b.ne	0xfb48 <_stogir.stack.entry-allocation?+0x338>
    fb8c:      	cmp	x11, x14
    fb90:      	b.gt	0xfbb8 <_stogir.stack.entry-allocation?+0x3a8>
    fb94:      	lsl	x11, x13, #2
    fb98:      	ldr	x14, [x0, #0x50]
    fb9c:      	add	x11, x11, x14
    fba0:      	ldr	w11, [x11]
    fba4:      	sxtw	x11, w11
    fba8:      	cmp	x11, #0x0
    fbac:      	cset	w11, gt
    fbb0:      	ubfx	x11, x11, #0, #8
    fbb4:      	b	0xfbbc <_stogir.stack.entry-allocation?+0x3ac>
    fbb8:      	movz	x11, #0x0, lsl #48
    fbbc:      	b	0xfb4c <_stogir.stack.entry-allocation?+0x33c>
    fbc0:      	movz	x11, #0x0, lsl #48
    fbc4:      	b	0xfb78 <_stogir.stack.entry-allocation?+0x368>
    fbc8:      	mov	x16, sp
    fbcc:      	ldr	w9, [x16, #0x4]
    fbd0:      	sxtw	x9, w9
    fbd4:      	b	0xf8a0 <_stogir.stack.entry-allocation?+0x90>
    fbd8:      	brk	#0
    fbdc:      	b	0xfbd8 <_stogir.stack.entry-allocation?+0x3c8>

000000000000fbe0 <_stogir.stack.constant-size>:
    fbe0:      	sub	sp, sp, #0x10
    fbe4:      	str	x29, [sp]
    fbe8:      	str	x30, [sp, #0x8]
    fbec:      	mov	x29, sp
    fbf0:      	mov	x2, sp
    fbf4:      	sxtw	x1, w1
    fbf8:      	sub	sp, sp, #0x10
    fbfc:      	mov	x3, sp
    fc00:      	cmp	x1, #0x0
    fc04:      	cset	w4, gt
    fc08:      	movz	x16, #0x0, lsl #48
    fc0c:      	sub	x5, x16, x1
    fc10:      	sub	x6, x5, #0x1
    fc14:      	uxtb	w16, w4
    fc18:      	cmp	w16, wzr
    fc1c:      	b.eq	0xfc60 <_stogir.stack.constant-size+0x80>
    fc20:      	ldr	x5, [x0, #0x8]
    fc24:      	cmp	x1, x5
    fc28:      	b.ge	0xfcb4 <_stogir.stack.constant-size+0xd4>
    fc2c:      	add	x5, x0, #0x78
    fc30:      	ldr	x5, [x5, #0x8]
    fc34:      	cmp	x1, x5
    fc38:      	b.ge	0xfe28 <_stogir.stack.constant-size+0x248>
    fc3c:      	lsl	x5, x1, #2
    fc40:      	ldr	x7, [x0, #0x78]
    fc44:      	add	x5, x5, x7
    fc48:      	ldr	w5, [x5]
    fc4c:      	sxtw	x5, w5
    fc50:      	cmp	x5, #0x0
    fc54:      	cset	w5, ge
    fc58:      	ubfx	x5, x5, #0, #8
    fc5c:      	b	0xfe2c <_stogir.stack.constant-size+0x24c>
    fc60:      	cmp	x1, #0x0
    fc64:      	b.ge	0xfcbc <_stogir.stack.constant-size+0xdc>
    fc68:      	add	x7, x0, #0x28
    fc6c:      	add	x9, x0, #0x50
    fc70:      	ldr	x7, [x7, #0x8]
    fc74:      	ldr	x9, [x9, #0x8]
    fc78:      	cmp	x7, x9
    fc7c:      	b.ne	0xfcac <_stogir.stack.constant-size+0xcc>
    fc80:      	cmp	x5, x7
    fc84:      	b.gt	0xfeb0 <_stogir.stack.constant-size+0x2d0>
    fc88:      	lsl	x5, x6, #2
    fc8c:      	ldr	x7, [x0, #0x50]
    fc90:      	add	x5, x5, x7
    fc94:      	ldr	w5, [x5]
    fc98:      	sxtw	x5, w5
    fc9c:      	cmp	x5, #0x0
    fca0:      	cset	w5, gt
    fca4:      	ubfx	x5, x5, #0, #8
    fca8:      	b	0xfeb4 <_stogir.stack.constant-size+0x2d4>
    fcac:      	movz	x5, #0x0, lsl #48
    fcb0:      	b	0xfcc0 <_stogir.stack.constant-size+0xe0>
    fcb4:      	movz	x5, #0x0, lsl #48
    fcb8:      	b	0xfcc0 <_stogir.stack.constant-size+0xe0>
    fcbc:      	movz	x5, #0x0, lsl #48
    fcc0:      	cmp	x5, #0x0
    fcc4:      	b.eq	0xfd28 <_stogir.stack.constant-size+0x148>
    fcc8:      	uxtb	w16, w4
    fccc:      	cmp	w16, wzr
    fcd0:      	b.eq	0xfcf8 <_stogir.stack.constant-size+0x118>
    fcd4:      	lsl	x4, x1, #4
    fcd8:      	ldr	x0, [x0]
    fcdc:      	add	x0, x4, x0
    fce0:      	ldr	x4, [x0]
    fce4:      	ldr	x0, [x0, #0x8]
    fce8:      	fmov	d31, x0
    fcec:      	mov	x0, x4
    fcf0:      	fmov	x4, d31
    fcf4:      	b	0xfd18 <_stogir.stack.constant-size+0x138>
    fcf8:      	lsl	x4, x6, #4
    fcfc:      	ldr	x0, [x0, #0x28]
    fd00:      	add	x0, x4, x0
    fd04:      	ldr	x4, [x0]
    fd08:      	ldr	x0, [x0, #0x8]
    fd0c:      	fmov	d31, x0
    fd10:      	mov	x0, x4
    fd14:      	fmov	x4, d31
    fd18:      	mov	x5, x4
    fd1c:      	mov	x4, x0
    fd20:      	mov	x0, #0x1                ; =1
    fd24:      	b	0xfd34 <_stogir.stack.constant-size+0x154>
    fd28:      	movz	x0, #0x0, lsl #48
    fd2c:      	movz	x4, #0x0, lsl #48
    fd30:      	movz	x5, #0x0, lsl #48
    fd34:      	lsr	w0, w0, #0
    fd38:      	lsr	x16, x0, #0
    fd3c:      	cmp	x16, #0x1
    fd40:      	b.eq	0xfd5c <_stogir.stack.constant-size+0x17c>
    fd44:      	b.lo	0xfd4c <_stogir.stack.constant-size+0x16c>
    fd48:      	b	0xfd60 <_stogir.stack.constant-size+0x180>
    fd4c:      	cmp	x16, #0x0
    fd50:      	b.eq	0xfd58 <_stogir.stack.constant-size+0x178>
    fd54:      	b	0xfd60 <_stogir.stack.constant-size+0x180>
    fd58:      	b	0xfd64 <_stogir.stack.constant-size+0x184>
    fd5c:      	b	0xfe08 <_stogir.stack.constant-size+0x228>
    fd60:      	b	0xff68 <_stogir.stack.constant-size+0x388>
    fd64:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000fd64:  ARM64_RELOC_PAGE21	l_stogir.510
    fd68:      	ldr	x16, [x16]
		000000000000fd68:  ARM64_RELOC_PAGEOFF12	l_stogir.510
    fd6c:      	orr	x0, x16, xzr
    fd70:      	mov	x1, x0
    fd74:      	mov	x0, #0x1                ; =1
    fd78:      	mov	x3, #0x18               ; =24
    fd7c:      	b	0xfde4 <_stogir.stack.constant-size+0x204>
    fd80:      	mov	x4, #0x1                ; =1
    fd84:      	ldr	w5, [x3, #0x8]
    fd88:      	ldr	w6, [x3, #0xc]
    fd8c:      	cmp	x1, #0x0
    fd90:      	b.ge	0xfdcc <_stogir.stack.constant-size+0x1ec>
    fd94:      	cmp	x0, #0x1
    fd98:      	b.lt	0xfdcc <_stogir.stack.constant-size+0x1ec>
    fd9c:      	cmp	x0, #0xb
    fda0:      	cset	w1, le
    fda4:      	uxtb	w16, w1
    fda8:      	cmp	w16, wzr
    fdac:      	b.eq	0xfdcc <_stogir.stack.constant-size+0x1ec>
    fdb0:      	ldr	w3, [x3]
    fdb4:      	uxtb	w7, w3
    fdb8:      	ubfx	x3, x3, #8, #8
    fdbc:      	cmp	x7, x3
    fdc0:      	b.eq	0xfeb8 <_stogir.stack.constant-size+0x2d8>
    fdc4:      	cmp	x7, #0x49
    fdc8:      	b.eq	0xfeb8 <_stogir.stack.constant-size+0x2d8>
    fdcc:      	adrp	x16, 0xf000 <_stogir.terminal.previous-input+0x100>
		000000000000fdcc:  ARM64_RELOC_PAGE21	l_stogir.511
    fdd0:      	ldr	x16, [x16]
		000000000000fdd0:  ARM64_RELOC_PAGEOFF12	l_stogir.511
    fdd4:      	orr	x0, x16, xzr
    fdd8:      	mov	x1, x0
    fddc:      	mov	x0, #0x1                ; =1
    fde0:      	mov	x3, #0x30               ; =48
    fde4:      	mov	sp, x2
    fde8:      	str	x0, [x8]
    fdec:      	str	x1, [x8, #0x8]
    fdf0:      	str	x3, [x8, #0x10]
    fdf4:      	sub	sp, x29, #0x0
    fdf8:      	ldr	x29, [sp]
    fdfc:      	ldr	x30, [sp, #0x8]
    fe00:      	add	sp, sp, #0x10
    fe04:      	ret
    fe08:      	lsr	w0, w4, #0
    fe0c:      	str	x4, [x3]
    fe10:      	str	x5, [x3, #0x8]
    fe14:      	ubfx	x0, x0, #8, #8
    fe18:      	cmp	x0, #0x0
    fe1c:      	b.ne	0xfe30 <_stogir.stack.constant-size+0x250>
    fe20:      	movz	x4, #0x0, lsl #48
    fe24:      	b	0xfd84 <_stogir.stack.constant-size+0x1a4>
    fe28:      	movz	x5, #0x0, lsl #48
    fe2c:      	b	0xfcb8 <_stogir.stack.constant-size+0xd8>
    fe30:      	cmp	x0, #0x1
    fe34:      	b.eq	0xfd80 <_stogir.stack.constant-size+0x1a0>
    fe38:      	cmp	x0, #0x2
    fe3c:      	b.eq	0xfd80 <_stogir.stack.constant-size+0x1a0>
    fe40:      	cmp	x0, #0x7
    fe44:      	b.eq	0xfd80 <_stogir.stack.constant-size+0x1a0>
    fe48:      	cmp	x0, #0x8
    fe4c:      	b.eq	0xfd80 <_stogir.stack.constant-size+0x1a0>
    fe50:      	cmp	x0, #0x3
    fe54:      	b.eq	0xff60 <_stogir.stack.constant-size+0x380>
    fe58:      	cmp	x0, #0x9
    fe5c:      	b.eq	0xff60 <_stogir.stack.constant-size+0x380>
    fe60:      	cmp	x0, #0x4
    fe64:      	b.eq	0xff70 <_stogir.stack.constant-size+0x390>
    fe68:      	cmp	x0, #0xa
    fe6c:      	b.eq	0xff70 <_stogir.stack.constant-size+0x390>
    fe70:      	cmp	x0, #0xd
    fe74:      	b.eq	0xff70 <_stogir.stack.constant-size+0x390>
    fe78:      	cmp	x0, #0x5
    fe7c:      	b.eq	0xff78 <_stogir.stack.constant-size+0x398>
    fe80:      	cmp	x0, #0xb
    fe84:      	b.eq	0xff78 <_stogir.stack.constant-size+0x398>
    fe88:      	cmp	x0, #0xc
    fe8c:      	b.eq	0xff78 <_stogir.stack.constant-size+0x398>
    fe90:      	cmp	x0, #0x6
    fe94:      	cset	w4, eq
    fe98:      	uxtb	w16, w4
    fe9c:      	cmp	w16, wzr
    fea0:      	mov	x16, #0x8               ; =8
    fea4:      	movn	x17, #0x0, lsl #48
    fea8:      	csel	x4, x16, x17, ne
    feac:      	b	0xff7c <_stogir.stack.constant-size+0x39c>
    feb0:      	movz	x5, #0x0, lsl #48
    feb4:      	b	0xfcb0 <_stogir.stack.constant-size+0xd0>
    feb8:      	lsr	w4, w4, #0
    febc:      	sxtw	x4, w4
    fec0:      	cmp	x4, #0x0
    fec4:      	b.le	0xfdcc <_stogir.stack.constant-size+0x1ec>
    fec8:      	ubfx	x5, x5, #0, #32
    fecc:      	ubfx	x6, x6, #0, #32
    fed0:      	lsl	x3, x6, #32
    fed4:      	orr	x3, x3, x5
    fed8:      	cmp	x4, #0x8
    fedc:      	b.ge	0xfef8 <_stogir.stack.constant-size+0x318>
    fee0:      	lsl	x5, x4, #3
    fee4:      	lsr	w5, w5, #0
    fee8:      	sxtw	x5, w5
    feec:      	lsr	x5, x3, x5
    fef0:      	cmp	x5, #0x0
    fef4:      	b.ne	0xfdcc <_stogir.stack.constant-size+0x1ec>
    fef8:      	cmp	x0, #0x7
    fefc:      	b.lt	0xff38 <_stogir.stack.constant-size+0x358>
    ff00:      	uxtb	w16, w1
    ff04:      	cmp	w16, wzr
    ff08:      	b.eq	0xff38 <_stogir.stack.constant-size+0x358>
    ff0c:      	lsl	x0, x4, #3
    ff10:      	lsr	w0, w0, #0
    ff14:      	sxtw	x0, w0
    ff18:      	sub	x0, x0, #0x1
    ff1c:      	lsr	w0, w0, #0
    ff20:      	sxtw	x0, w0
    ff24:      	mov	x16, #0x1               ; =1
    ff28:      	lsl	x0, x16, x0
    ff2c:      	and	x0, x0, x3
    ff30:      	cmp	x0, #0x0
    ff34:      	b.ne	0xfdcc <_stogir.stack.constant-size+0x1ec>
    ff38:      	mov	x17, #-0x10             ; =-16
    ff3c:      	movk	x17, #0x7fff, lsl #48
    ff40:      	cmp	x3, x17
    ff44:      	b.hi	0xfdcc <_stogir.stack.constant-size+0x1ec>
    ff48:      	add	x0, x3, #0xf
    ff4c:      	and	x0, x0, #0xfffffffffffffff0
    ff50:      	mov	x1, x0
    ff54:      	movz	x0, #0x0, lsl #48
    ff58:      	movz	x3, #0x0, lsl #48
    ff5c:      	b	0xfde4 <_stogir.stack.constant-size+0x204>
    ff60:      	mov	x4, #0x2                ; =2
    ff64:      	b	0xfd84 <_stogir.stack.constant-size+0x1a4>
    ff68:      	brk	#0
    ff6c:      	b	0xff68 <_stogir.stack.constant-size+0x388>
    ff70:      	mov	x4, #0x4                ; =4
    ff74:      	b	0xff64 <_stogir.stack.constant-size+0x384>
    ff78:      	mov	x4, #0x8                ; =8
    ff7c:      	b	0xff74 <_stogir.stack.constant-size+0x394>

000000000000ff80 <_stogir.frame.valid-alignment?>:
    ff80:      	cmp	x0, #0x0
    ff84:      	b.le	0xffa0 <_stogir.frame.valid-alignment?+0x20>
    ff88:      	sub	x1, x0, #0x1
    ff8c:      	and	x0, x1, x0
    ff90:      	cmp	x0, #0x0
    ff94:      	cset	w0, eq
    ff98:      	ubfx	x0, x0, #0, #8
    ff9c:      	b	0xffa4 <_stogir.frame.valid-alignment?+0x24>
    ffa0:      	movz	x0, #0x0, lsl #48
    ffa4:      	ret

000000000000ffa8 <_stogir.stack.constant-size-aligned>:
    ffa8:      	sub	sp, sp, #0x10
    ffac:      	cmp	x2, #0x10
    ffb0:      	b.lt	0x10030 <_stogir.stack.constant-size-aligned+0x88>
    ffb4:      	cmp	x2, #0x0
    ffb8:      	b.le	0x10030 <_stogir.stack.constant-size-aligned+0x88>
    ffbc:      	sub	x3, x2, #0x1
    ffc0:      	and	x3, x3, x2
    ffc4:      	cmp	x3, #0x0
    ffc8:      	b.ne	0x10030 <_stogir.stack.constant-size-aligned+0x88>
    ffcc:      	sxtw	x1, w1
    ffd0:      	cmp	x1, #0x0
    ffd4:      	cset	w3, gt
    ffd8:      	movz	x16, #0x0, lsl #48
    ffdc:      	sub	x4, x16, x1
    ffe0:      	sub	x5, x4, #0x1
    ffe4:      	uxtb	w16, w3
    ffe8:      	cmp	w16, wzr
    ffec:      	b.eq	0x100d0 <_stogir.stack.constant-size-aligned+0x128>
    fff0:      	ldr	x4, [x0, #0x8]
    fff4:      	cmp	x1, x4
    fff8:      	b.ge	0x1011c <_stogir.stack.constant-size-aligned+0x174>
    fffc:      	add	x4, x0, #0x78
   10000:      	ldr	x4, [x4, #0x8]
   10004:      	cmp	x1, x4
   10008:      	b.ge	0x10218 <_stogir.stack.constant-size-aligned+0x270>
   1000c:      	lsl	x4, x1, #2
   10010:      	ldr	x6, [x0, #0x78]
   10014:      	add	x4, x4, x6
   10018:      	ldr	w4, [x4]
   1001c:      	sxtw	x4, w4
   10020:      	cmp	x4, #0x0
   10024:      	cset	w4, ge
   10028:      	ubfx	x4, x4, #0, #8
   1002c:      	b	0x1021c <_stogir.stack.constant-size-aligned+0x274>
   10030:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x58>
		0000000000010030:  ARM64_RELOC_PAGE21	l_stogir.512
   10034:      	ldr	x16, [x16]
		0000000000010034:  ARM64_RELOC_PAGEOFF12	l_stogir.512
   10038:      	orr	x0, x16, xzr
   1003c:      	mov	x1, x0
   10040:      	mov	x0, #0x1                ; =1
   10044:      	mov	x2, #0x20               ; =32
   10048:      	str	x0, [x8]
   1004c:      	str	x1, [x8, #0x8]
   10050:      	str	x2, [x8, #0x10]
   10054:      	add	sp, sp, #0x10
   10058:      	ret
   1005c:      	mov	x3, #0x1                ; =1
   10060:      	mov	x16, sp
   10064:      	ldr	w4, [x16, #0x8]
   10068:      	mov	x16, sp
   1006c:      	ldr	w5, [x16, #0xc]
   10070:      	cmp	x1, #0x0
   10074:      	b.ge	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   10078:      	cmp	x0, #0x1
   1007c:      	b.lt	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   10080:      	cmp	x0, #0xb
   10084:      	cset	w1, le
   10088:      	uxtb	w16, w1
   1008c:      	cmp	w16, wzr
   10090:      	b.eq	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   10094:      	mov	x16, sp
   10098:      	ldr	w6, [x16]
   1009c:      	uxtb	w7, w6
   100a0:      	ubfx	x6, x6, #8, #8
   100a4:      	cmp	x7, x6
   100a8:      	b.eq	0x102a8 <_stogir.stack.constant-size-aligned+0x300>
   100ac:      	cmp	x7, #0x49
   100b0:      	b.eq	0x102a8 <_stogir.stack.constant-size-aligned+0x300>
   100b4:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x58>
		00000000000100b4:  ARM64_RELOC_PAGE21	l_stogir.513
   100b8:      	ldr	x16, [x16]
		00000000000100b8:  ARM64_RELOC_PAGEOFF12	l_stogir.513
   100bc:      	orr	x0, x16, xzr
   100c0:      	mov	x1, x0
   100c4:      	mov	x0, #0x1                ; =1
   100c8:      	mov	x2, #0x30               ; =48
   100cc:      	b	0x10048 <_stogir.stack.constant-size-aligned+0xa0>
   100d0:      	cmp	x1, #0x0
   100d4:      	b.ge	0x10124 <_stogir.stack.constant-size-aligned+0x17c>
   100d8:      	add	x6, x0, #0x28
   100dc:      	add	x7, x0, #0x50
   100e0:      	ldr	x6, [x6, #0x8]
   100e4:      	ldr	x7, [x7, #0x8]
   100e8:      	cmp	x6, x7
   100ec:      	b.ne	0x10210 <_stogir.stack.constant-size-aligned+0x268>
   100f0:      	cmp	x4, x6
   100f4:      	b.gt	0x102a0 <_stogir.stack.constant-size-aligned+0x2f8>
   100f8:      	lsl	x4, x5, #2
   100fc:      	ldr	x6, [x0, #0x50]
   10100:      	add	x4, x4, x6
   10104:      	ldr	w4, [x4]
   10108:      	sxtw	x4, w4
   1010c:      	cmp	x4, #0x0
   10110:      	cset	w4, gt
   10114:      	ubfx	x4, x4, #0, #8
   10118:      	b	0x102a4 <_stogir.stack.constant-size-aligned+0x2fc>
   1011c:      	movz	x4, #0x0, lsl #48
   10120:      	b	0x10128 <_stogir.stack.constant-size-aligned+0x180>
   10124:      	movz	x4, #0x0, lsl #48
   10128:      	cmp	x4, #0x0
   1012c:      	b.eq	0x10190 <_stogir.stack.constant-size-aligned+0x1e8>
   10130:      	uxtb	w16, w3
   10134:      	cmp	w16, wzr
   10138:      	b.eq	0x10160 <_stogir.stack.constant-size-aligned+0x1b8>
   1013c:      	lsl	x3, x1, #4
   10140:      	ldr	x0, [x0]
   10144:      	add	x0, x3, x0
   10148:      	ldr	x3, [x0]
   1014c:      	ldr	x0, [x0, #0x8]
   10150:      	fmov	d31, x0
   10154:      	mov	x0, x3
   10158:      	fmov	x3, d31
   1015c:      	b	0x10180 <_stogir.stack.constant-size-aligned+0x1d8>
   10160:      	lsl	x3, x5, #4
   10164:      	ldr	x0, [x0, #0x28]
   10168:      	add	x0, x3, x0
   1016c:      	ldr	x3, [x0]
   10170:      	ldr	x0, [x0, #0x8]
   10174:      	fmov	d31, x0
   10178:      	mov	x0, x3
   1017c:      	fmov	x3, d31
   10180:      	mov	x4, x3
   10184:      	mov	x3, x0
   10188:      	mov	x0, #0x1                ; =1
   1018c:      	b	0x1019c <_stogir.stack.constant-size-aligned+0x1f4>
   10190:      	movz	x0, #0x0, lsl #48
   10194:      	movz	x3, #0x0, lsl #48
   10198:      	movz	x4, #0x0, lsl #48
   1019c:      	lsr	w0, w0, #0
   101a0:      	lsr	x16, x0, #0
   101a4:      	cmp	x16, #0x1
   101a8:      	b.eq	0x101c4 <_stogir.stack.constant-size-aligned+0x21c>
   101ac:      	b.lo	0x101b4 <_stogir.stack.constant-size-aligned+0x20c>
   101b0:      	b	0x101c8 <_stogir.stack.constant-size-aligned+0x220>
   101b4:      	cmp	x16, #0x0
   101b8:      	b.eq	0x101c0 <_stogir.stack.constant-size-aligned+0x218>
   101bc:      	b	0x101c8 <_stogir.stack.constant-size-aligned+0x220>
   101c0:      	b	0x101cc <_stogir.stack.constant-size-aligned+0x224>
   101c4:      	b	0x101e8 <_stogir.stack.constant-size-aligned+0x240>
   101c8:      	b	0x10368 <_stogir.stack.constant-size-aligned+0x3c0>
   101cc:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x58>
		00000000000101cc:  ARM64_RELOC_PAGE21	l_stogir.514
   101d0:      	ldr	x16, [x16]
		00000000000101d0:  ARM64_RELOC_PAGEOFF12	l_stogir.514
   101d4:      	orr	x0, x16, xzr
   101d8:      	mov	x1, x0
   101dc:      	mov	x0, #0x1                ; =1
   101e0:      	mov	x2, #0x18               ; =24
   101e4:      	b	0x100cc <_stogir.stack.constant-size-aligned+0x124>
   101e8:      	lsr	w0, w3, #0
   101ec:      	mov	x16, sp
   101f0:      	str	x3, [x16]
   101f4:      	mov	x16, sp
   101f8:      	str	x4, [x16, #0x8]
   101fc:      	ubfx	x0, x0, #8, #8
   10200:      	cmp	x0, #0x0
   10204:      	b.ne	0x10220 <_stogir.stack.constant-size-aligned+0x278>
   10208:      	movz	x3, #0x0, lsl #48
   1020c:      	b	0x10060 <_stogir.stack.constant-size-aligned+0xb8>
   10210:      	movz	x4, #0x0, lsl #48
   10214:      	b	0x10128 <_stogir.stack.constant-size-aligned+0x180>
   10218:      	movz	x4, #0x0, lsl #48
   1021c:      	b	0x10120 <_stogir.stack.constant-size-aligned+0x178>
   10220:      	cmp	x0, #0x1
   10224:      	b.eq	0x1005c <_stogir.stack.constant-size-aligned+0xb4>
   10228:      	cmp	x0, #0x2
   1022c:      	b.eq	0x1005c <_stogir.stack.constant-size-aligned+0xb4>
   10230:      	cmp	x0, #0x7
   10234:      	b.eq	0x1005c <_stogir.stack.constant-size-aligned+0xb4>
   10238:      	cmp	x0, #0x8
   1023c:      	b.eq	0x1005c <_stogir.stack.constant-size-aligned+0xb4>
   10240:      	cmp	x0, #0x3
   10244:      	b.eq	0x10360 <_stogir.stack.constant-size-aligned+0x3b8>
   10248:      	cmp	x0, #0x9
   1024c:      	b.eq	0x10360 <_stogir.stack.constant-size-aligned+0x3b8>
   10250:      	cmp	x0, #0x4
   10254:      	b.eq	0x10370 <_stogir.stack.constant-size-aligned+0x3c8>
   10258:      	cmp	x0, #0xa
   1025c:      	b.eq	0x10370 <_stogir.stack.constant-size-aligned+0x3c8>
   10260:      	cmp	x0, #0xd
   10264:      	b.eq	0x10370 <_stogir.stack.constant-size-aligned+0x3c8>
   10268:      	cmp	x0, #0x5
   1026c:      	b.eq	0x10378 <_stogir.stack.constant-size-aligned+0x3d0>
   10270:      	cmp	x0, #0xb
   10274:      	b.eq	0x10378 <_stogir.stack.constant-size-aligned+0x3d0>
   10278:      	cmp	x0, #0xc
   1027c:      	b.eq	0x10378 <_stogir.stack.constant-size-aligned+0x3d0>
   10280:      	cmp	x0, #0x6
   10284:      	cset	w3, eq
   10288:      	uxtb	w16, w3
   1028c:      	cmp	w16, wzr
   10290:      	mov	x16, #0x8               ; =8
   10294:      	movn	x17, #0x0, lsl #48
   10298:      	csel	x3, x16, x17, ne
   1029c:      	b	0x1037c <_stogir.stack.constant-size-aligned+0x3d4>
   102a0:      	movz	x4, #0x0, lsl #48
   102a4:      	b	0x10214 <_stogir.stack.constant-size-aligned+0x26c>
   102a8:      	lsr	w3, w3, #0
   102ac:      	sxtw	x3, w3
   102b0:      	cmp	x3, #0x0
   102b4:      	b.le	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   102b8:      	ubfx	x4, x4, #0, #32
   102bc:      	ubfx	x5, x5, #0, #32
   102c0:      	lsl	x5, x5, #32
   102c4:      	orr	x4, x5, x4
   102c8:      	cmp	x3, #0x8
   102cc:      	b.ge	0x102e8 <_stogir.stack.constant-size-aligned+0x340>
   102d0:      	lsl	x5, x3, #3
   102d4:      	lsr	w5, w5, #0
   102d8:      	sxtw	x5, w5
   102dc:      	lsr	x5, x4, x5
   102e0:      	cmp	x5, #0x0
   102e4:      	b.ne	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   102e8:      	cmp	x0, #0x7
   102ec:      	b.lt	0x10328 <_stogir.stack.constant-size-aligned+0x380>
   102f0:      	uxtb	w16, w1
   102f4:      	cmp	w16, wzr
   102f8:      	b.eq	0x10328 <_stogir.stack.constant-size-aligned+0x380>
   102fc:      	lsl	x0, x3, #3
   10300:      	lsr	w0, w0, #0
   10304:      	sxtw	x0, w0
   10308:      	sub	x0, x0, #0x1
   1030c:      	lsr	w0, w0, #0
   10310:      	sxtw	x0, w0
   10314:      	mov	x16, #0x1               ; =1
   10318:      	lsl	x0, x16, x0
   1031c:      	and	x0, x0, x4
   10320:      	cmp	x0, #0x0
   10324:      	b.ne	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   10328:      	sub	x0, x2, #0x1
   1032c:      	mov	x16, #0x7fffffffffffffff ; =9223372036854775807
   10330:      	sub	x0, x16, x0
   10334:      	cmp	x4, x0
   10338:      	b.hi	0x100b4 <_stogir.stack.constant-size-aligned+0x10c>
   1033c:      	sub	x0, x2, #0x1
   10340:      	movz	x16, #0x0, lsl #48
   10344:      	sub	x1, x16, x2
   10348:      	add	x0, x0, x4
   1034c:      	and	x0, x1, x0
   10350:      	mov	x1, x0
   10354:      	movz	x0, #0x0, lsl #48
   10358:      	movz	x2, #0x0, lsl #48
   1035c:      	b	0x100cc <_stogir.stack.constant-size-aligned+0x124>
   10360:      	mov	x3, #0x2                ; =2
   10364:      	b	0x10060 <_stogir.stack.constant-size-aligned+0xb8>
   10368:      	brk	#0
   1036c:      	b	0x10368 <_stogir.stack.constant-size-aligned+0x3c0>
   10370:      	mov	x3, #0x4                ; =4
   10374:      	b	0x10364 <_stogir.stack.constant-size-aligned+0x3bc>
   10378:      	mov	x3, #0x8                ; =8
   1037c:      	b	0x10374 <_stogir.stack.constant-size-aligned+0x3cc>

0000000000010380 <_stogir.numeric-conversion.operation?>:
   10380:      	sxtw	x0, w0
   10384:      	cmp	x0, #0x25
   10388:      	b.lt	0x1039c <_stogir.numeric-conversion.operation?+0x1c>
   1038c:      	cmp	x0, #0x27
   10390:      	cset	w0, le
   10394:      	ubfx	x0, x0, #0, #8
   10398:      	b	0x103a0 <_stogir.numeric-conversion.operation?+0x20>
   1039c:      	movz	x0, #0x0, lsl #48
   103a0:      	ret

00000000000103a4 <_stogir.numeric-conversion.valid-types?>:
   103a4:      	sxtw	x0, w0
   103a8:      	sxtw	x1, w1
   103ac:      	sxtw	x2, w2
   103b0:      	cmp	x2, #0xc
   103b4:      	cset	w3, eq
   103b8:      	cmp	x2, #0xd
   103bc:      	cset	w4, eq
   103c0:      	ubfx	x4, x4, #0, #8
   103c4:      	cmp	x0, #0x25
   103c8:      	b.ne	0x103f0 <_stogir.numeric-conversion.valid-types?+0x4c>
   103cc:      	cmp	x1, #0x1
   103d0:      	b.lt	0x10458 <_stogir.numeric-conversion.valid-types?+0xb4>
   103d4:      	cmp	x1, #0xb
   103d8:      	b.gt	0x10458 <_stogir.numeric-conversion.valid-types?+0xb4>
   103dc:      	uxtb	w16, w3
   103e0:      	cmp	w16, wzr
   103e4:      	b.eq	0x10468 <_stogir.numeric-conversion.valid-types?+0xc4>
   103e8:      	mov	x0, #0x1                ; =1
   103ec:      	b	0x1046c <_stogir.numeric-conversion.valid-types?+0xc8>
   103f0:      	cmp	x1, #0xc
   103f4:      	cset	w5, eq
   103f8:      	cmp	x1, #0xd
   103fc:      	cset	w1, eq
   10400:      	cmp	x0, #0x26
   10404:      	b.ne	0x10428 <_stogir.numeric-conversion.valid-types?+0x84>
   10408:      	uxtb	w16, w5
   1040c:      	cmp	w16, wzr
   10410:      	b.ne	0x10478 <_stogir.numeric-conversion.valid-types?+0xd4>
   10414:      	uxtb	w16, w1
   10418:      	cmp	w16, wzr
   1041c:      	b.ne	0x10478 <_stogir.numeric-conversion.valid-types?+0xd4>
   10420:      	movz	x0, #0x0, lsl #48
   10424:      	b	0x10454 <_stogir.numeric-conversion.valid-types?+0xb0>
   10428:      	cmp	x0, #0x27
   1042c:      	b.ne	0x10460 <_stogir.numeric-conversion.valid-types?+0xbc>
   10430:      	uxtb	w16, w5
   10434:      	cmp	w16, wzr
   10438:      	b.ne	0x10490 <_stogir.numeric-conversion.valid-types?+0xec>
   1043c:      	uxtb	w16, w1
   10440:      	cmp	w16, wzr
   10444:      	b.ne	0x10490 <_stogir.numeric-conversion.valid-types?+0xec>
   10448:      	movz	x0, #0x0, lsl #48
   1044c:      	b	0x10474 <_stogir.numeric-conversion.valid-types?+0xd0>
   10450:      	movz	x0, #0x0, lsl #48
   10454:      	b	0x10464 <_stogir.numeric-conversion.valid-types?+0xc0>
   10458:      	movz	x0, #0x0, lsl #48
   1045c:      	b	0x10464 <_stogir.numeric-conversion.valid-types?+0xc0>
   10460:      	movz	x0, #0x0, lsl #48
   10464:      	ret
   10468:      	mov	x0, x4
   1046c:      	b	0x1045c <_stogir.numeric-conversion.valid-types?+0xb8>
   10470:      	mov	x0, x4
   10474:      	b	0x10464 <_stogir.numeric-conversion.valid-types?+0xc0>
   10478:      	cmp	x2, #0x1
   1047c:      	b.lt	0x10450 <_stogir.numeric-conversion.valid-types?+0xac>
   10480:      	cmp	x2, #0xb
   10484:      	cset	w0, le
   10488:      	ubfx	x0, x0, #0, #8
   1048c:      	b	0x10454 <_stogir.numeric-conversion.valid-types?+0xb0>
   10490:      	uxtb	w16, w3
   10494:      	cmp	w16, wzr
   10498:      	b.eq	0x10470 <_stogir.numeric-conversion.valid-types?+0xcc>
   1049c:      	mov	x0, #0x1                ; =1
   104a0:      	b	0x10474 <_stogir.numeric-conversion.valid-types?+0xd0>

00000000000104a4 <_inherent$slice$new__stogir.node.Node>:
   104a4:      	sub	sp, sp, #0x10
   104a8:      	mov	x2, sp
   104ac:      	str	x0, [x2]
   104b0:      	str	x1, [x2, #0x8]
   104b4:      	ldr	x0, [sp]
   104b8:      	ldr	x1, [sp, #0x8]
   104bc:      	add	sp, sp, #0x10
   104c0:      	ret

00000000000104c4 <_inherent$slice$data__stogir.node.Node>:
   104c4:      	ret

00000000000104c8 <_coil.slice.element-ref__stogir.node.Node>:
   104c8:      	ret

00000000000104cc <_stogir.vector-lanes.ordinary?>:
   104cc:      	ldr	w0, [x0]
   104d0:      	uxtb	w0, w0
   104d4:      	cmp	x0, #0x48
   104d8:      	b.ne	0x104e4 <_stogir.vector-lanes.ordinary?+0x18>
   104dc:      	movz	x0, #0x0, lsl #48
   104e0:      	b	0x104f8 <_stogir.vector-lanes.ordinary?+0x2c>
   104e4:      	cmp	x0, #0x46
   104e8:      	cset	w0, eq
   104ec:      	uxtb	w16, w0
   104f0:      	cmp	w16, wzr
   104f4:      	cset	x0, eq
   104f8:      	ret

00000000000104fc <_stogir.vector-lanes.compatible?>:
   104fc:      	sub	sp, sp, #0x30
   10500:      	str	x29, [sp]
   10504:      	str	x30, [sp, #0x8]
   10508:      	mov	x29, sp
   1050c:      	str	x19, [sp, #0x10]
   10510:      	str	x20, [sp, #0x18]
   10514:      	str	x21, [sp, #0x20]
   10518:      	lsr	w3, w0, #0
   1051c:      	sxtw	x19, w0
   10520:      	mov	w0, w3
   10524:      	mov	w20, w1
   10528:      	mov	w21, w2
   1052c:      	bl	0x1052c <_stogir.vector-lanes.compatible?+0x30>
		000000000001052c:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10530:      	and	x1, x19, #0xf
   10534:      	lsr	w1, w1, #0
   10538:      	sxtw	x1, w1
   1053c:      	cmp	x0, #0x0
   10540:      	b.eq	0x1054c <_stogir.vector-lanes.compatible?+0x50>
   10544:      	mov	x0, x1
   10548:      	b	0x10550 <_stogir.vector-lanes.compatible?+0x54>
   1054c:      	movn	x0, #0x0, lsl #48
   10550:      	cmp	x19, #0xf
   10554:      	b.le	0x105a4 <_stogir.vector-lanes.compatible?+0xa8>
   10558:      	cmp	x19, #0x80
   1055c:      	b.ge	0x105a4 <_stogir.vector-lanes.compatible?+0xa8>
   10560:      	cmp	x1, #0x1
   10564:      	b.lt	0x105a4 <_stogir.vector-lanes.compatible?+0xa8>
   10568:      	cmp	x1, #0xd
   1056c:      	b.gt	0x105a4 <_stogir.vector-lanes.compatible?+0xa8>
   10570:      	sxtw	x21, w21
   10574:      	cmp	x21, #0x4
   10578:      	cset	w1, eq
   1057c:      	cmp	x21, #0x8
   10580:      	cset	w2, eq
   10584:      	uxtb	w16, w1
   10588:      	cmp	w16, wzr
   1058c:      	b.ne	0x105cc <_stogir.vector-lanes.compatible?+0xd0>
   10590:      	uxtb	w16, w2
   10594:      	cmp	w16, wzr
   10598:      	b.ne	0x105cc <_stogir.vector-lanes.compatible?+0xd0>
   1059c:      	movz	x0, #0x0, lsl #48
   105a0:      	b	0x105c8 <_stogir.vector-lanes.compatible?+0xcc>
   105a4:      	movz	x0, #0x0, lsl #48
   105a8:      	ldr	x19, [sp, #0x10]
   105ac:      	ldr	x20, [sp, #0x18]
   105b0:      	ldr	x21, [sp, #0x20]
   105b4:      	ldr	x29, [sp]
   105b8:      	ldr	x30, [sp, #0x8]
   105bc:      	add	sp, sp, #0x30
   105c0:      	ret
   105c4:      	movz	x0, #0x0, lsl #48
   105c8:      	b	0x105a8 <_stogir.vector-lanes.compatible?+0xac>
   105cc:      	sxtw	x20, w20
   105d0:      	cmp	x20, #0x0
   105d4:      	b.lt	0x105c4 <_stogir.vector-lanes.compatible?+0xc8>
   105d8:      	cmp	x20, #0xd
   105dc:      	b.gt	0x105c4 <_stogir.vector-lanes.compatible?+0xc8>
   105e0:      	cmp	x20, #0x0
   105e4:      	b.le	0x10600 <_stogir.vector-lanes.compatible?+0x104>
   105e8:      	lsr	w0, w0, #0
   105ec:      	sxtw	x0, w0
   105f0:      	cmp	x0, x20
   105f4:      	b.ne	0x10608 <_stogir.vector-lanes.compatible?+0x10c>
   105f8:      	mov	x0, #0x1                ; =1
   105fc:      	b	0x10604 <_stogir.vector-lanes.compatible?+0x108>
   10600:      	movz	x0, #0x0, lsl #48
   10604:      	b	0x105c8 <_stogir.vector-lanes.compatible?+0xcc>
   10608:      	cmp	x0, #0x1
   1060c:      	b.lt	0x10648 <_stogir.vector-lanes.compatible?+0x14c>
   10610:      	cmp	x0, #0xb
   10614:      	b.gt	0x10648 <_stogir.vector-lanes.compatible?+0x14c>
   10618:      	cmp	x20, #0x1
   1061c:      	b.lt	0x10650 <_stogir.vector-lanes.compatible?+0x154>
   10620:      	cmp	x20, #0xb
   10624:      	b.gt	0x10650 <_stogir.vector-lanes.compatible?+0x154>
   10628:      	uxtb	w16, w1
   1062c:      	cmp	w16, wzr
   10630:      	b.ne	0x1067c <_stogir.vector-lanes.compatible?+0x180>
   10634:      	uxtb	w16, w2
   10638:      	cmp	w16, wzr
   1063c:      	b.ne	0x1067c <_stogir.vector-lanes.compatible?+0x180>
   10640:      	movn	x0, #0x0, lsl #48
   10644:      	b	0x10690 <_stogir.vector-lanes.compatible?+0x194>
   10648:      	movz	x0, #0x0, lsl #48
   1064c:      	b	0x105fc <_stogir.vector-lanes.compatible?+0x100>
   10650:      	movz	x0, #0x0, lsl #48
   10654:      	b	0x1064c <_stogir.vector-lanes.compatible?+0x150>
   10658:      	mov	x1, #0x1                ; =1
   1065c:      	lsr	w0, w0, #0
   10660:      	sxtw	x0, w0
   10664:      	lsr	w1, w1, #0
   10668:      	sxtw	x1, w1
   1066c:      	cmp	x0, x1
   10670:      	cset	w0, eq
   10674:      	ubfx	x0, x0, #0, #8
   10678:      	b	0x10654 <_stogir.vector-lanes.compatible?+0x158>
   1067c:      	cmp	x0, #0x0
   10680:      	b.ne	0x10730 <_stogir.vector-lanes.compatible?+0x234>
   10684:      	movz	x0, #0x0, lsl #48
   10688:      	b	0x10690 <_stogir.vector-lanes.compatible?+0x194>
   1068c:      	mov	x0, #0x1                ; =1
   10690:      	uxtb	w16, w1
   10694:      	cmp	w16, wzr
   10698:      	b.ne	0x106b0 <_stogir.vector-lanes.compatible?+0x1b4>
   1069c:      	uxtb	w16, w2
   106a0:      	cmp	w16, wzr
   106a4:      	b.ne	0x106b0 <_stogir.vector-lanes.compatible?+0x1b4>
   106a8:      	movn	x1, #0x0, lsl #48
   106ac:      	b	0x1065c <_stogir.vector-lanes.compatible?+0x160>
   106b0:      	cmp	x20, #0x0
   106b4:      	b.ne	0x106c0 <_stogir.vector-lanes.compatible?+0x1c4>
   106b8:      	movz	x1, #0x0, lsl #48
   106bc:      	b	0x1065c <_stogir.vector-lanes.compatible?+0x160>
   106c0:      	cmp	x20, #0x1
   106c4:      	b.eq	0x10658 <_stogir.vector-lanes.compatible?+0x15c>
   106c8:      	cmp	x20, #0x2
   106cc:      	b.eq	0x10658 <_stogir.vector-lanes.compatible?+0x15c>
   106d0:      	cmp	x20, #0x7
   106d4:      	b.eq	0x10658 <_stogir.vector-lanes.compatible?+0x15c>
   106d8:      	cmp	x20, #0x8
   106dc:      	b.eq	0x10658 <_stogir.vector-lanes.compatible?+0x15c>
   106e0:      	cmp	x20, #0x3
   106e4:      	b.eq	0x107a0 <_stogir.vector-lanes.compatible?+0x2a4>
   106e8:      	cmp	x20, #0x9
   106ec:      	b.eq	0x107a0 <_stogir.vector-lanes.compatible?+0x2a4>
   106f0:      	cmp	x20, #0x4
   106f4:      	b.eq	0x107b0 <_stogir.vector-lanes.compatible?+0x2b4>
   106f8:      	cmp	x20, #0xa
   106fc:      	b.eq	0x107b0 <_stogir.vector-lanes.compatible?+0x2b4>
   10700:      	cmp	x20, #0xd
   10704:      	b.eq	0x107b0 <_stogir.vector-lanes.compatible?+0x2b4>
   10708:      	cmp	x20, #0x5
   1070c:      	b.eq	0x107c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10710:      	cmp	x20, #0xb
   10714:      	b.eq	0x107c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10718:      	cmp	x20, #0xc
   1071c:      	b.eq	0x107c0 <_stogir.vector-lanes.compatible?+0x2c4>
   10720:      	cmp	x20, #0x6
   10724:      	b.ne	0x107d0 <_stogir.vector-lanes.compatible?+0x2d4>
   10728:      	mov	x1, x21
   1072c:      	b	0x107d4 <_stogir.vector-lanes.compatible?+0x2d8>
   10730:      	cmp	x0, #0x1
   10734:      	b.eq	0x1068c <_stogir.vector-lanes.compatible?+0x190>
   10738:      	cmp	x0, #0x2
   1073c:      	b.eq	0x1068c <_stogir.vector-lanes.compatible?+0x190>
   10740:      	cmp	x0, #0x7
   10744:      	b.eq	0x1068c <_stogir.vector-lanes.compatible?+0x190>
   10748:      	cmp	x0, #0x8
   1074c:      	b.eq	0x1068c <_stogir.vector-lanes.compatible?+0x190>
   10750:      	cmp	x0, #0x3
   10754:      	b.eq	0x107a8 <_stogir.vector-lanes.compatible?+0x2ac>
   10758:      	cmp	x0, #0x9
   1075c:      	b.eq	0x107a8 <_stogir.vector-lanes.compatible?+0x2ac>
   10760:      	cmp	x0, #0x4
   10764:      	b.eq	0x107b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10768:      	cmp	x0, #0xa
   1076c:      	b.eq	0x107b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10770:      	cmp	x0, #0xd
   10774:      	b.eq	0x107b8 <_stogir.vector-lanes.compatible?+0x2bc>
   10778:      	cmp	x0, #0x5
   1077c:      	b.eq	0x107c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10780:      	cmp	x0, #0xb
   10784:      	b.eq	0x107c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10788:      	cmp	x0, #0xc
   1078c:      	b.eq	0x107c8 <_stogir.vector-lanes.compatible?+0x2cc>
   10790:      	cmp	x0, #0x6
   10794:      	b.ne	0x107d8 <_stogir.vector-lanes.compatible?+0x2dc>
   10798:      	mov	x0, x21
   1079c:      	b	0x107dc <_stogir.vector-lanes.compatible?+0x2e0>
   107a0:      	mov	x1, #0x2                ; =2
   107a4:      	b	0x1065c <_stogir.vector-lanes.compatible?+0x160>
   107a8:      	mov	x0, #0x2                ; =2
   107ac:      	b	0x10690 <_stogir.vector-lanes.compatible?+0x194>
   107b0:      	mov	x1, #0x4                ; =4
   107b4:      	b	0x107a4 <_stogir.vector-lanes.compatible?+0x2a8>
   107b8:      	mov	x0, #0x4                ; =4
   107bc:      	b	0x107ac <_stogir.vector-lanes.compatible?+0x2b0>
   107c0:      	mov	x1, #0x8                ; =8
   107c4:      	b	0x107b4 <_stogir.vector-lanes.compatible?+0x2b8>
   107c8:      	mov	x0, #0x8                ; =8
   107cc:      	b	0x107bc <_stogir.vector-lanes.compatible?+0x2c0>
   107d0:      	movn	x1, #0x0, lsl #48
   107d4:      	b	0x107c4 <_stogir.vector-lanes.compatible?+0x2c8>
   107d8:      	movn	x0, #0x0, lsl #48
   107dc:      	b	0x107cc <_stogir.vector-lanes.compatible?+0x2d0>

00000000000107e0 <_stogir.symbols.numeric?>:
   107e0:      	ldr	w0, [x0]
   107e4:      	uxtb	w1, w0
   107e8:      	ubfx	x0, x0, #8, #8
   107ec:      	cmp	x1, x0
   107f0:      	b.ne	0x107fc <_stogir.symbols.numeric?+0x1c>
   107f4:      	mov	x0, #0x1                ; =1
   107f8:      	b	0x10808 <_stogir.symbols.numeric?+0x28>
   107fc:      	cmp	x1, #0x49
   10800:      	cset	w0, eq
   10804:      	ubfx	x0, x0, #0, #8
   10808:      	ret

000000000001080c <_stogir.node.constant-bits>:
   1080c:      	ldr	w1, [x0, #0x8]
   10810:      	ubfx	x1, x1, #0, #32
   10814:      	ldr	w0, [x0, #0xc]
   10818:      	ubfx	x0, x0, #0, #32
   1081c:      	lsl	x0, x0, #32
   10820:      	orr	x0, x0, x1
   10824:      	ret

0000000000010828 <_stogir.vector-comparison.valid-type?>:
   10828:      	sub	sp, sp, #0x30
   1082c:      	str	x29, [sp]
   10830:      	str	x30, [sp, #0x8]
   10834:      	mov	x29, sp
   10838:      	str	x19, [sp, #0x10]
   1083c:      	str	x20, [sp, #0x18]
   10840:      	str	x21, [sp, #0x20]
   10844:      	sxtw	x19, w0
   10848:      	cmp	x19, #0xe
   1084c:      	b.lt	0x108a4 <_stogir.vector-comparison.valid-type?+0x7c>
   10850:      	cmp	x19, #0x19
   10854:      	b.gt	0x108a4 <_stogir.vector-comparison.valid-type?+0x7c>
   10858:      	sxtw	x0, w1
   1085c:      	cmp	x0, #0xf
   10860:      	b.le	0x108c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10864:      	cmp	x0, #0x80
   10868:      	b.ge	0x108c4 <_stogir.vector-comparison.valid-type?+0x9c>
   1086c:      	and	x0, x0, #0xf
   10870:      	lsr	w0, w0, #0
   10874:      	sxtw	x20, w0
   10878:      	cmp	x20, #0x1
   1087c:      	b.lt	0x108c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10880:      	cmp	x20, #0xd
   10884:      	b.gt	0x108c4 <_stogir.vector-comparison.valid-type?+0x9c>
   10888:      	lsr	w21, w1, #0
   1088c:      	mov	w0, w21
   10890:      	bl	0x10890 <_stogir.vector-comparison.valid-type?+0x68>
		0000000000010890:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   10894:      	cmp	x0, #0x0
   10898:      	b.eq	0x108d4 <_stogir.vector-comparison.valid-type?+0xac>
   1089c:      	mov	x0, x20
   108a0:      	b	0x108d8 <_stogir.vector-comparison.valid-type?+0xb0>
   108a4:      	movz	x0, #0x0, lsl #48
   108a8:      	ldr	x19, [sp, #0x10]
   108ac:      	ldr	x20, [sp, #0x18]
   108b0:      	ldr	x21, [sp, #0x20]
   108b4:      	ldr	x29, [sp]
   108b8:      	ldr	x30, [sp, #0x8]
   108bc:      	add	sp, sp, #0x30
   108c0:      	ret
   108c4:      	movz	x0, #0x0, lsl #48
   108c8:      	b	0x108a8 <_stogir.vector-comparison.valid-type?+0x80>
   108cc:      	mov	x0, #0x1                ; =1
   108d0:      	b	0x108c8 <_stogir.vector-comparison.valid-type?+0xa0>
   108d4:      	movn	x0, #0x0, lsl #48
   108d8:      	lsr	w0, w0, #0
   108dc:      	sxtw	x0, w0
   108e0:      	cmp	x0, #0xc
   108e4:      	b.eq	0x108cc <_stogir.vector-comparison.valid-type?+0xa4>
   108e8:      	cmp	x0, #0xd
   108ec:      	b.eq	0x108cc <_stogir.vector-comparison.valid-type?+0xa4>
   108f0:      	mov	w0, w21
   108f4:      	bl	0x108f4 <_stogir.vector-comparison.valid-type?+0xcc>
		00000000000108f4:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   108f8:      	cmp	x0, #0x0
   108fc:      	b.eq	0x10910 <_stogir.vector-comparison.valid-type?+0xe8>
   10900:      	mov	x0, x20
   10904:      	b	0x10914 <_stogir.vector-comparison.valid-type?+0xec>
   10908:      	movz	x0, #0x0, lsl #48
   1090c:      	b	0x108d0 <_stogir.vector-comparison.valid-type?+0xa8>
   10910:      	movn	x0, #0x0, lsl #48
   10914:      	lsr	w0, w0, #0
   10918:      	sxtw	x0, w0
   1091c:      	cmp	x0, #0x1
   10920:      	b.lt	0x10908 <_stogir.vector-comparison.valid-type?+0xe0>
   10924:      	cmp	x0, #0xb
   10928:      	b.gt	0x10908 <_stogir.vector-comparison.valid-type?+0xe0>
   1092c:      	cmp	x19, #0x17
   10930:      	cset	w0, le
   10934:      	ubfx	x0, x0, #0, #8
   10938:      	b	0x1090c <_stogir.vector-comparison.valid-type?+0xe4>

000000000001093c <_stogir.vector-arithmetic.extrema?>:
   1093c:      	sxtw	x0, w0
   10940:      	cmp	x0, #0x3a
   10944:      	b.ne	0x10950 <_stogir.vector-arithmetic.extrema?+0x14>
   10948:      	mov	x0, #0x1                ; =1
   1094c:      	b	0x1095c <_stogir.vector-arithmetic.extrema?+0x20>
   10950:      	cmp	x0, #0x3b
   10954:      	cset	w0, eq
   10958:      	ubfx	x0, x0, #0, #8
   1095c:      	ret

0000000000010960 <_stogir.vector-arithmetic.shift?>:
   10960:      	sxtw	x0, w0
   10964:      	cmp	x0, #0x31
   10968:      	b.lt	0x1097c <_stogir.vector-arithmetic.shift?+0x1c>
   1096c:      	cmp	x0, #0x35
   10970:      	cset	w0, le
   10974:      	ubfx	x0, x0, #0, #8
   10978:      	b	0x10980 <_stogir.vector-arithmetic.shift?+0x20>
   1097c:      	movz	x0, #0x0, lsl #48
   10980:      	ret

0000000000010984 <_stogir.vector-arithmetic.valid-type?>:
   10984:      	sub	sp, sp, #0x40
   10988:      	str	x29, [sp]
   1098c:      	str	x30, [sp, #0x8]
   10990:      	mov	x29, sp
   10994:      	str	x19, [sp, #0x10]
   10998:      	str	x20, [sp, #0x18]
   1099c:      	str	x21, [sp, #0x20]
   109a0:      	str	x22, [sp, #0x28]
   109a4:      	str	x23, [sp, #0x30]
   109a8:      	lsr	w2, w1, #0
   109ac:      	sxtw	x19, w1
   109b0:      	mov	w20, w0
   109b4:      	mov	w0, w2
   109b8:      	bl	0x109b8 <_stogir.vector-arithmetic.valid-type?+0x34>
		00000000000109b8:  ARM64_RELOC_BRANCH26	_stogir.types.valid?
   109bc:      	and	x1, x19, #0xf
   109c0:      	lsr	w1, w1, #0
   109c4:      	sxtw	x1, w1
   109c8:      	cmp	x0, #0x0
   109cc:      	b.eq	0x109d8 <_stogir.vector-arithmetic.valid-type?+0x54>
   109d0:      	mov	x0, x1
   109d4:      	b	0x109dc <_stogir.vector-arithmetic.valid-type?+0x58>
   109d8:      	movn	x0, #0x0, lsl #48
   109dc:      	cmp	x19, #0xf
   109e0:      	b.le	0x10bc0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   109e4:      	cmp	x19, #0x80
   109e8:      	b.ge	0x10bc0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   109ec:      	cmp	x1, #0x1
   109f0:      	b.lt	0x10bc0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   109f4:      	cmp	x1, #0xd
   109f8:      	b.gt	0x10bc0 <_stogir.vector-arithmetic.valid-type?+0x23c>
   109fc:      	sxtw	x1, w20
   10a00:      	cmp	x1, #0x1f
   10a04:      	cset	w19, eq
   10a08:      	cmp	x1, #0x20
   10a0c:      	cset	w21, eq
   10a10:      	cmp	x1, #0x2e
   10a14:      	cset	w2, eq
   10a18:      	cmp	x1, #0x2f
   10a1c:      	cset	w3, eq
   10a20:      	cmp	x1, #0x30
   10a24:      	cset	w4, eq
   10a28:      	cmp	x1, #0x1e
   10a2c:      	cset	w5, eq
   10a30:      	cmp	x1, #0x31
   10a34:      	cset	w6, ge
   10a38:      	cmp	x1, #0x35
   10a3c:      	cset	w7, le
   10a40:      	cmp	x1, #0x3a
   10a44:      	cset	w8, eq
   10a48:      	cmp	x1, #0x3b
   10a4c:      	cset	w9, eq
   10a50:      	cmp	x1, #0x2d
   10a54:      	cset	w10, eq
   10a58:      	cmp	x1, #0x36
   10a5c:      	cset	w11, eq
   10a60:      	cmp	x1, #0x37
   10a64:      	cset	w12, eq
   10a68:      	cmp	x1, #0x38
   10a6c:      	cset	w13, eq
   10a70:      	cmp	x1, #0x39
   10a74:      	cset	w14, eq
   10a78:      	uxtb	w16, w19
   10a7c:      	cmp	w16, wzr
   10a80:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10a84:      	uxtb	w16, w21
   10a88:      	cmp	w16, wzr
   10a8c:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10a90:      	uxtb	w16, w10
   10a94:      	cmp	w16, wzr
   10a98:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10a9c:      	uxtb	w16, w11
   10aa0:      	cmp	w16, wzr
   10aa4:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10aa8:      	uxtb	w16, w12
   10aac:      	cmp	w16, wzr
   10ab0:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10ab4:      	uxtb	w16, w13
   10ab8:      	cmp	w16, wzr
   10abc:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10ac0:      	uxtb	w16, w14
   10ac4:      	cmp	w16, wzr
   10ac8:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10acc:      	uxtb	w16, w8
   10ad0:      	cmp	w16, wzr
   10ad4:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10ad8:      	uxtb	w16, w9
   10adc:      	cmp	w16, wzr
   10ae0:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10ae4:      	uxtb	w16, w6
   10ae8:      	cmp	w16, wzr
   10aec:      	b.eq	0x10ce8 <_stogir.vector-arithmetic.valid-type?+0x364>
   10af0:      	uxtb	w16, w7
   10af4:      	cmp	w16, wzr
   10af8:      	b.eq	0x10ce8 <_stogir.vector-arithmetic.valid-type?+0x364>
   10afc:      	lsr	w0, w0, #0
   10b00:      	sxtw	x1, w0
   10b04:      	cmp	x1, #0xc
   10b08:      	cset	w22, eq
   10b0c:      	cmp	x1, #0xd
   10b10:      	cset	w23, eq
   10b14:      	uxtb	w16, w19
   10b18:      	cmp	w16, wzr
   10b1c:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b20:      	uxtb	w16, w21
   10b24:      	cmp	w16, wzr
   10b28:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b2c:      	uxtb	w16, w10
   10b30:      	cmp	w16, wzr
   10b34:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b38:      	uxtb	w16, w11
   10b3c:      	cmp	w16, wzr
   10b40:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b44:      	uxtb	w16, w12
   10b48:      	cmp	w16, wzr
   10b4c:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b50:      	uxtb	w16, w13
   10b54:      	cmp	w16, wzr
   10b58:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b5c:      	uxtb	w16, w14
   10b60:      	cmp	w16, wzr
   10b64:      	b.ne	0x10bf4 <_stogir.vector-arithmetic.valid-type?+0x270>
   10b68:      	cmp	x1, #0x1
   10b6c:      	cset	w0, eq
   10b70:      	cmp	x1, #0x1
   10b74:      	cset	w10, ge
   10b78:      	cmp	x1, #0xb
   10b7c:      	cset	w1, le
   10b80:      	uxtb	w16, w6
   10b84:      	cmp	w16, wzr
   10b88:      	b.eq	0x10c54 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10b8c:      	uxtb	w16, w7
   10b90:      	cmp	w16, wzr
   10b94:      	b.eq	0x10c54 <_stogir.vector-arithmetic.valid-type?+0x2d0>
   10b98:      	uxtb	w16, w10
   10b9c:      	cmp	w16, wzr
   10ba0:      	b.eq	0x10ce0 <_stogir.vector-arithmetic.valid-type?+0x35c>
   10ba4:      	uxtb	w16, w1
   10ba8:      	cmp	w16, wzr
   10bac:      	b.eq	0x10ce0 <_stogir.vector-arithmetic.valid-type?+0x35c>
   10bb0:      	uxtb	w16, w0
   10bb4:      	cmp	w16, wzr
   10bb8:      	cset	x0, eq
   10bbc:      	b	0x10ce4 <_stogir.vector-arithmetic.valid-type?+0x360>
   10bc0:      	movz	x0, #0x0, lsl #48
   10bc4:      	ldr	x19, [sp, #0x10]
   10bc8:      	ldr	x20, [sp, #0x18]
   10bcc:      	ldr	x21, [sp, #0x20]
   10bd0:      	ldr	x22, [sp, #0x28]
   10bd4:      	ldr	x23, [sp, #0x30]
   10bd8:      	ldr	x29, [sp]
   10bdc:      	ldr	x30, [sp, #0x8]
   10be0:      	add	sp, sp, #0x40
   10be4:      	ret
   10be8:      	ubfx	x21, x21, #0, #8
   10bec:      	mov	x0, x21
   10bf0:      	b	0x10bc4 <_stogir.vector-arithmetic.valid-type?+0x240>
   10bf4:      	lsr	w20, w20, #0
   10bf8:      	lsr	w0, w0, #0
   10bfc:      	mov	w1, w0
   10c00:      	mov	w0, w20
   10c04:      	bl	0x10c04 <_stogir.vector-arithmetic.valid-type?+0x280>
		0000000000010c04:  ARM64_RELOC_BRANCH26	_stogir.integer-unary.valid-type?
   10c08:      	cmp	x0, #0x0
   10c0c:      	b.eq	0x10c18 <_stogir.vector-arithmetic.valid-type?+0x294>
   10c10:      	mov	x0, #0x1                ; =1
   10c14:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10c18:      	uxtb	w16, w22
   10c1c:      	cmp	w16, wzr
   10c20:      	b.ne	0x10c38 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10c24:      	uxtb	w16, w23
   10c28:      	cmp	w16, wzr
   10c2c:      	b.ne	0x10c38 <_stogir.vector-arithmetic.valid-type?+0x2b4>
   10c30:      	movz	x0, #0x0, lsl #48
   10c34:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10c38:      	uxtb	w16, w19
   10c3c:      	cmp	w16, wzr
   10c40:      	b.eq	0x10be8 <_stogir.vector-arithmetic.valid-type?+0x264>
   10c44:      	mov	x0, #0x1                ; =1
   10c48:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10c4c:      	movz	x0, #0x0, lsl #48
   10c50:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10c54:      	uxtb	w16, w2
   10c58:      	cmp	w16, wzr
   10c5c:      	b.ne	0x10cc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10c60:      	uxtb	w16, w3
   10c64:      	cmp	w16, wzr
   10c68:      	b.ne	0x10cc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10c6c:      	uxtb	w16, w4
   10c70:      	cmp	w16, wzr
   10c74:      	b.ne	0x10cc8 <_stogir.vector-arithmetic.valid-type?+0x344>
   10c78:      	uxtb	w16, w22
   10c7c:      	cmp	w16, wzr
   10c80:      	b.ne	0x10d40 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10c84:      	uxtb	w16, w23
   10c88:      	cmp	w16, wzr
   10c8c:      	b.ne	0x10d40 <_stogir.vector-arithmetic.valid-type?+0x3bc>
   10c90:      	uxtb	w16, w10
   10c94:      	cmp	w16, wzr
   10c98:      	b.eq	0x10d50 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10c9c:      	uxtb	w16, w1
   10ca0:      	cmp	w16, wzr
   10ca4:      	b.eq	0x10d50 <_stogir.vector-arithmetic.valid-type?+0x3cc>
   10ca8:      	uxtb	w16, w0
   10cac:      	cmp	w16, wzr
   10cb0:      	b.eq	0x10d58 <_stogir.vector-arithmetic.valid-type?+0x3d4>
   10cb4:      	uxtb	w16, w8
   10cb8:      	cmp	w16, wzr
   10cbc:      	b.eq	0x10d60 <_stogir.vector-arithmetic.valid-type?+0x3dc>
   10cc0:      	mov	x0, #0x1                ; =1
   10cc4:      	b	0x10d68 <_stogir.vector-arithmetic.valid-type?+0x3e4>
   10cc8:      	uxtb	w16, w10
   10ccc:      	cmp	w16, wzr
   10cd0:      	b.eq	0x10c4c <_stogir.vector-arithmetic.valid-type?+0x2c8>
   10cd4:      	ubfx	x1, x1, #0, #8
   10cd8:      	mov	x0, x1
   10cdc:      	b	0x10c50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10ce0:      	movz	x0, #0x0, lsl #48
   10ce4:      	b	0x10c50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10ce8:      	cmp	x1, #0x1a
   10cec:      	b.eq	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10cf0:      	cmp	x1, #0x1b
   10cf4:      	b.eq	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10cf8:      	cmp	x1, #0x1c
   10cfc:      	b.eq	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d00:      	cmp	x1, #0x1d
   10d04:      	b.eq	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d08:      	uxtb	w16, w5
   10d0c:      	cmp	w16, wzr
   10d10:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d14:      	uxtb	w16, w2
   10d18:      	cmp	w16, wzr
   10d1c:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d20:      	uxtb	w16, w3
   10d24:      	cmp	w16, wzr
   10d28:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d2c:      	uxtb	w16, w4
   10d30:      	cmp	w16, wzr
   10d34:      	b.ne	0x10afc <_stogir.vector-arithmetic.valid-type?+0x178>
   10d38:      	movz	x0, #0x0, lsl #48
   10d3c:      	b	0x10bf0 <_stogir.vector-arithmetic.valid-type?+0x26c>
   10d40:      	uxtb	w16, w5
   10d44:      	cmp	w16, wzr
   10d48:      	cset	x0, eq
   10d4c:      	b	0x10c50 <_stogir.vector-arithmetic.valid-type?+0x2cc>
   10d50:      	movz	x0, #0x0, lsl #48
   10d54:      	b	0x10d4c <_stogir.vector-arithmetic.valid-type?+0x3c8>
   10d58:      	mov	x0, #0x1                ; =1
   10d5c:      	b	0x10d54 <_stogir.vector-arithmetic.valid-type?+0x3d0>
   10d60:      	ubfx	x9, x9, #0, #8
   10d64:      	mov	x0, x9
   10d68:      	b	0x10d5c <_stogir.vector-arithmetic.valid-type?+0x3d8>

0000000000010d6c <_coil.core.Len$slice$len__i32>:
   10d6c:      	mov	x0, x1
   10d70:      	ret

0000000000010d74 <_inherent$slice$data__i32>:
   10d74:      	ret

0000000000010d78 <_stogir.opcode.terminator?>:
   10d78:      	sxtw	x0, w0
   10d7c:      	cmp	x0, #0x0
   10d80:      	b.lt	0x10da8 <_stogir.opcode.terminator?+0x30>
   10d84:      	cmp	x0, #0x83
   10d88:      	b.ge	0x10da8 <_stogir.opcode.terminator?+0x30>
   10d8c:      	adrp	x16, 0x10000 <_stogir.stack.constant-size-aligned+0x58>
		0000000000010d8c:  ARM64_RELOC_PAGE21	l_stogir.515
   10d90:      	ldr	x16, [x16]
		0000000000010d90:  ARM64_RELOC_PAGEOFF12	l_stogir.515
   10d94:      	orr	x1, x16, xzr
   10d98:      	lsr	x0, x0, #0
   10d9c:      	add	x0, x0, x1
   10da0:      	ldrb	w0, [x0]
   10da4:      	b	0x10dac <_stogir.opcode.terminator?+0x34>
   10da8:      	movz	x0, #0x0, lsl #48
   10dac:      	uxtb	w0, w0
   10db0:      	and	x0, x0, #0x8
   10db4:      	uxtb	w0, w0
   10db8:      	cmp	x0, #0x0
   10dbc:      	cset	w0, eq
   10dc0:      	uxtb	w16, w0
   10dc4:      	cmp	w16, wzr
   10dc8:      	cset	x0, eq
   10dcc:      	ret

0000000000010dd0 <_stogir.switch.sign-mask>:
   10dd0:      	sxtw	x0, w0
   10dd4:      	cmp	x0, #0x7
   10dd8:      	b.lt	0x10df4 <_stogir.switch.sign-mask+0x24>
   10ddc:      	cmp	x0, #0xb
   10de0:      	b.gt	0x10df4 <_stogir.switch.sign-mask+0x24>
   10de4:      	cmp	x0, #0x0
   10de8:      	b.ne	0x10e2c <_stogir.switch.sign-mask+0x5c>
   10dec:      	movz	x0, #0x0, lsl #48
   10df0:      	b	0x10e00 <_stogir.switch.sign-mask+0x30>
   10df4:      	movz	x0, #0x0, lsl #48
   10df8:      	ret
   10dfc:      	mov	x0, #0x1                ; =1
   10e00:      	lsr	w0, w0, #0
   10e04:      	sxtw	x0, w0
   10e08:      	lsl	x0, x0, #3
   10e0c:      	lsr	w0, w0, #0
   10e10:      	sxtw	x0, w0
   10e14:      	sub	x0, x0, #0x1
   10e18:      	lsr	w0, w0, #0
   10e1c:      	sxtw	x0, w0
   10e20:      	mov	x16, #0x1               ; =1
   10e24:      	lsl	x0, x16, x0
   10e28:      	b	0x10df8 <_stogir.switch.sign-mask+0x28>
   10e2c:      	cmp	x0, #0x1
   10e30:      	b.eq	0x10dfc <_stogir.switch.sign-mask+0x2c>
   10e34:      	cmp	x0, #0x2
   10e38:      	b.eq	0x10dfc <_stogir.switch.sign-mask+0x2c>
   10e3c:      	cmp	x0, #0x7
   10e40:      	b.eq	0x10dfc <_stogir.switch.sign-mask+0x2c>
   10e44:      	cmp	x0, #0x8
   10e48:      	b.eq	0x10dfc <_stogir.switch.sign-mask+0x2c>
   10e4c:      	cmp	x0, #0x3
   10e50:      	b.eq	0x10eac <_stogir.switch.sign-mask+0xdc>
   10e54:      	cmp	x0, #0x9
   10e58:      	b.eq	0x10eac <_stogir.switch.sign-mask+0xdc>
   10e5c:      	cmp	x0, #0x4
   10e60:      	b.eq	0x10eb4 <_stogir.switch.sign-mask+0xe4>
   10e64:      	cmp	x0, #0xa
   10e68:      	b.eq	0x10eb4 <_stogir.switch.sign-mask+0xe4>
   10e6c:      	cmp	x0, #0xd
   10e70:      	b.eq	0x10eb4 <_stogir.switch.sign-mask+0xe4>
   10e74:      	cmp	x0, #0x5
   10e78:      	b.eq	0x10ebc <_stogir.switch.sign-mask+0xec>
   10e7c:      	cmp	x0, #0xb
   10e80:      	b.eq	0x10ebc <_stogir.switch.sign-mask+0xec>
   10e84:      	cmp	x0, #0xc
   10e88:      	b.eq	0x10ebc <_stogir.switch.sign-mask+0xec>
   10e8c:      	cmp	x0, #0x6
   10e90:      	cset	w0, eq
   10e94:      	uxtb	w16, w0
   10e98:      	cmp	w16, wzr
   10e9c:      	mov	x16, #0x8               ; =8
   10ea0:      	movn	x17, #0x0, lsl #48
   10ea4:      	csel	x0, x16, x17, ne
   10ea8:      	b	0x10ec0 <_stogir.switch.sign-mask+0xf0>
   10eac:      	mov	x0, #0x2                ; =2
   10eb0:      	b	0x10e00 <_stogir.switch.sign-mask+0x30>
   10eb4:      	mov	x0, #0x4                ; =4
   10eb8:      	b	0x10eb0 <_stogir.switch.sign-mask+0xe0>
   10ebc:      	mov	x0, #0x8                ; =8
   10ec0:      	b	0x10eb8 <_stogir.switch.sign-mask+0xe8>
